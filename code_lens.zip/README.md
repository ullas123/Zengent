# Code Lens

A Python application for scanning source code repositories to identify legacy table and field references.

## Features

- Upload Excel mapping files with legacy table names and field/attribute names
- Upload source code repositories in ZIP format (PySpark, Python, Shell projects)
- Scan repositories to find occurrences of tables and fields
- View results organized by table/field, by file, or in a detailed filterable table
- Export results to CSV

## Installation

1. Make sure you have Python 3.8+ installed

2. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Running the Application

Start the Streamlit server:
```bash
streamlit run app.py --server.port 5000
```

The application will open in your default web browser at `http://localhost:5000`

## Excel File Format

Your Excel mapping file should have the following structure:
- **Column 1:** Legacy Table Name (e.g., CRPS, MNS, Triumph)
- **Column 2:** Attribute/Field Name (e.g., firstname, email, age)
- Additional columns are optional
- Each sheet can contain mappings for different tables

## Supported Source Code File Types

The scanner processes the following file extensions:
- `.py`, `.pyspark` - Python/PySpark files
- `.sh` - Shell scripts
- `.sql` - SQL files
- `.scala`, `.java` - JVM languages
- `.conf`, `.cfg`, `.yaml`, `.yml` - Configuration files
- `.json`, `.txt` - Data and text files

## Usage

1. Upload your Excel mapping file using the sidebar
2. Upload your source code repository as a ZIP file
3. Click "Scan Repository"
4. View results in three different formats:
   - Summary by Table/Field
   - Summary by File
   - Detailed Results (with filters)
5. Download results as CSV for further analysis
