# Code Lens

A Streamlit application for scanning source code repositories to identify legacy table and field references, with integrated data lineage and workflow visualization.

## Features

### Legacy Table/Field Scanning
- Upload an Excel mapping file with legacy table names and field/attribute names
- Upload a source code repository in ZIP format (PySpark, Python, Shell, SQL projects)
- **SQL Alias Detection**: Correctly attributes fields like `d.mbr_since_dt` to parent tables by parsing table aliases
- **Multi-line Query Detection**: Handles continuation keywords and comma-separated column lists
- View results organized by table/field, by file, or in a detailed filterable table
- **Service ID Search**: Search for specific service identifiers across the codebase
- Export results to CSV

### Data Lineage & Workflow Visualization
- Extract data lineage from PySpark and SQL/HQL files
- **Lineage Diagram**: Graphviz visualization showing table sources and targets
- **Workflow Diagram**: Interactive PyVis diagram showing script dependencies
- **SQL Query Diagrams**: Visual representation of individual SQL queries
- Filter by keyword or center on specific nodes
- Export lineage data as JSON

## Installation

### Option 1: Run on Replit
Upload to Replit and run with the pre-configured workflow.

### Option 2: Run Locally
```bash
pip install -r requirements.txt
streamlit run app.py --server.port 5000
```

## Dependencies
- streamlit
- pandas
- openpyxl
- networkx
- pyvis
- graphviz
- sqlparse

## Supported File Types
`.py`, `.pyspark`, `.sh`, `.sql`, `.hql`, `.hive`, `.scala`, `.java`, `.conf`, `.cfg`, `.yaml`, `.yml`, `.json`, `.txt`

## Excel File Format
- **Column 1:** Legacy Table Name (e.g., CRPS, MNS, Triumph)
- **Column 2:** Attribute/Field Name (e.g., firstname, email, age)
- Additional columns are optional
- Each sheet can contain mappings for different tables

## Usage

1. Upload your Excel mapping file using the sidebar
2. Upload your source code repository as a ZIP file
3. Optionally enter comma-separated Service IDs to search
4. Click "Scan Repository"
5. View results in multiple tabs:
   - Summary by Table/Field
   - Summary by File  
   - Detailed Results with filters
   - SQL Queries (with extracted queries and alias analysis)
   - Table-Attribute Occurrence Summary
   - Service ID Occurrences

6. For Data Lineage:
   - Scroll to "Data Lineage & Workflow Visualization" section
   - Expand "Data Lineage Scanner"
   - Click "Generate Lineage Diagrams"
   - Explore Overview, Lineage Diagram, Workflow Diagram, and SQL Query Diagrams tabs
