import streamlit as st
import pandas as pd
import zipfile
import os
import re
import tempfile
import shutil
from io import BytesIO
from collections import defaultdict

st.set_page_config(
    page_title="Code Lens",
    page_icon="🔍",
    layout="wide"
)

st.title("🔍 Code Lens")
st.markdown("**Scan source code repositories to identify legacy table and field references**")

# Supported file extensions for scanning
SUPPORTED_EXTENSIONS = {'.py', '.pyspark', '.sh', '.sql', '.scala', '.java', '.conf', '.cfg', '.yaml', '.yml', '.json', '.txt'}


def parse_excel_mappings(excel_file):
    """
    Parse Excel file to extract table names, fields and C360 mappings from all sheets.
    Column 1: Legacy Table Name
    Column 2: Field/Attribute Name
    Column 3: C360_Mapping (optional)
    Returns a dictionary with sheet names as keys and list of mappings as values.
    """
    mappings = {}
    all_tables = set()
    all_fields = set()
    table_field_mapping = defaultdict(set)
    field_c360_mapping = {}  # Map field name to C360_Mapping
    
    try:
        excel_data = pd.ExcelFile(excel_file)
        
        for sheet_name in excel_data.sheet_names:
            df = pd.read_excel(excel_data, sheet_name=sheet_name)
            
            if len(df.columns) < 2:
                st.warning(f"Sheet '{sheet_name}' has less than 2 columns, skipping...")
                continue
            
            sheet_mappings = []
            
            # Get table, field, and c360 mapping columns
            table_col = df.columns[0]
            field_col = df.columns[1]
            c360_col = df.columns[2] if len(df.columns) >= 3 else None
            
            for _, row in df.iterrows():
                table_name = str(row[table_col]).strip() if pd.notna(row[table_col]) else ""
                field_name = str(row[field_col]).strip() if pd.notna(row[field_col]) else ""
                c360_mapping = ""
                if c360_col is not None:
                    c360_mapping = str(row[c360_col]).strip() if pd.notna(row[c360_col]) else ""
                    if c360_mapping.lower() == 'nan':
                        c360_mapping = ""
                
                if table_name and table_name.lower() != 'nan':
                    all_tables.add(table_name)
                    if field_name and field_name.lower() != 'nan':
                        all_fields.add(field_name)
                        table_field_mapping[table_name].add(field_name)
                        field_c360_mapping[field_name] = c360_mapping
                        sheet_mappings.append({
                            'table': table_name,
                            'field': field_name,
                            'c360_mapping': c360_mapping
                        })
            
            mappings[sheet_name] = sheet_mappings
        
        return mappings, all_tables, all_fields, table_field_mapping, field_c360_mapping
    
    except Exception as e:
        st.error(f"Error parsing Excel file: {str(e)}")
        return None, None, None, None, None


def extract_zip(zip_file, temp_dir):
    """Extract ZIP file to temporary directory."""
    try:
        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
        return True
    except Exception as e:
        st.error(f"Error extracting ZIP file: {str(e)}")
        return False


def get_all_files(directory):
    """Get all supported files from directory recursively."""
    files = []
    for root, dirs, filenames in os.walk(directory):
        # Skip hidden directories and common non-code directories
        dirs[:] = [d for d in dirs if not d.startswith('.') and d not in {'__pycache__', 'node_modules', '.git', 'venv', 'env'}]
        
        for filename in filenames:
            ext = os.path.splitext(filename)[1].lower()
            if ext in SUPPORTED_EXTENSIONS or filename.endswith('.py') or filename.endswith('.sh'):
                files.append(os.path.join(root, filename))
    
    return files


def compile_patterns(tables, fields):
    """
    Precompile regex patterns for tables and fields for performance.
    Supports qualified identifiers (schema.table, alias.field) with flexible separators.
    """
    table_patterns = {}
    field_patterns = {}
    
    for table in tables:
        # Pattern allows optional prefix (schema., alias.) and matches table name
        # Supports: table_name, schema.table_name, `table_name`, "table_name"
        pattern_str = r'(?:^|[\s,(\[\'"`.]|FROM\s+|JOIN\s+|INTO\s+|UPDATE\s+|TABLE\s+)' + re.escape(table) + r'(?:$|[\s,)\]\'"`.])'
        table_patterns[table] = re.compile(pattern_str, re.IGNORECASE)
    
    for field in fields:
        if len(field) < 2:  # Skip very short field names
            continue
        # Pattern allows optional prefix (alias., table.) and matches field name
        # Supports: field_name, alias.field_name, table.field_name
        pattern_str = r'(?:^|[\s,(\[\'"`.]|SELECT\s+|WHERE\s+|AND\s+|OR\s+|BY\s+)' + re.escape(field) + r'(?:$|[\s,)\]\'"`.])'
        field_patterns[field] = re.compile(pattern_str, re.IGNORECASE)
    
    return table_patterns, field_patterns


def scan_file_for_matches(file_path, table_patterns, field_patterns, table_field_mapping, base_dir):
    """
    Scan a file for table and field matches using precompiled patterns.
    Returns list of matches with line number, occurrence, and context.
    """
    matches = []
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            lines = content.split('\n')
    except Exception as e:
        return matches
    
    relative_path = os.path.relpath(file_path, base_dir)
    filename = os.path.basename(file_path)
    
    # Track occurrences per table and field
    table_occurrences = defaultdict(list)
    field_occurrences = defaultdict(list)
    
    # Create lowercase lookup for quick substring check
    content_lower = content.lower()
    
    for line_num, line in enumerate(lines, 1):
        line_with_padding = ' ' + line + ' '  # Add padding for pattern matching at boundaries
        
        # Check for table matches
        for table, pattern in table_patterns.items():
            # Quick substring check before regex for performance
            if table.lower() not in line.lower():
                continue
            for match in pattern.finditer(line_with_padding):
                table_occurrences[table].append({
                    'line_number': line_num,
                    'line_content': line.strip(),
                    'match_position': match.start(),
                    'match_text': table
                })
        
        # Check for field matches
        for field, pattern in field_patterns.items():
            # Quick substring check before regex for performance
            if field.lower() not in line.lower():
                continue
            for match in pattern.finditer(line_with_padding):
                field_occurrences[field].append({
                    'line_number': line_num,
                    'line_content': line.strip(),
                    'match_position': match.start(),
                    'match_text': field
                })
    
    # Compile results
    for table, occurrences in table_occurrences.items():
        matches.append({
            'type': 'Table',
            'name': table,
            'file_name': filename,
            'file_path': relative_path,
            'occurrences': len(occurrences),
            'details': occurrences,
            'related_fields': list(table_field_mapping.get(table, []))
        })
    
    for field, occurrences in field_occurrences.items():
        # Find which table this field belongs to
        parent_tables = [t for t, fields_set in table_field_mapping.items() if field in fields_set]
        matches.append({
            'type': 'Field',
            'name': field,
            'file_name': filename,
            'file_path': relative_path,
            'occurrences': len(occurrences),
            'details': occurrences,
            'parent_tables': parent_tables
        })
    
    return matches


def scan_repository(temp_dir, tables, fields, table_field_mapping):
    """Scan entire repository for matches."""
    all_matches = []
    files = get_all_files(temp_dir)
    
    # Guard for empty file list
    if not files:
        st.warning("No supported source files found in the repository.")
        return all_matches, 0
    
    # Precompile patterns once for performance
    table_patterns, field_patterns = compile_patterns(tables, fields)
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    for idx, file_path in enumerate(files):
        status_text.text(f"Scanning: {os.path.basename(file_path)}")
        matches = scan_file_for_matches(file_path, table_patterns, field_patterns, table_field_mapping, temp_dir)
        all_matches.extend(matches)
        progress_bar.progress((idx + 1) / len(files))
    
    status_text.text("Scan complete!")
    progress_bar.empty()
    
    return all_matches, len(files)


def display_results(matches, mappings, total_excel_tables, total_excel_fields, field_c360_mapping=None):
    """Display scan results in organized format."""
    if field_c360_mapping is None:
        field_c360_mapping = {}
    
    if not matches:
        st.info("No matches found in the repository.")
        return
    
    # Summary statistics
    table_matches = [m for m in matches if m['type'] == 'Table']
    field_matches = [m for m in matches if m['type'] == 'Field']
    
    # Excel totals
    st.subheader("Excel File Summary")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Total Tables in Excel", total_excel_tables)
    with col2:
        st.metric("Total Fields in Excel", total_excel_fields)
    
    st.divider()
    
    # Match statistics
    st.subheader("Scan Results")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Matches", len(matches))
    with col2:
        st.metric("Table Matches", len(table_matches))
    with col3:
        st.metric("Field Matches", len(field_matches))
    
    # Tabs for different views
    tab1, tab2, tab3, tab4 = st.tabs(["📋 Legacy Table Summary", "📊 Attribute Mapping Details", "🔍 SQL Query Matches", "📋 Detailed Results"])
    
    with tab1:
        st.subheader("Legacy Tables Found in Project")
        st.markdown("*Scanning: Python (.py), PySpark (.pyspark), Shell (.sh) files*")
        
        # Build comprehensive table summary
        table_summary_data = []
        
        # Get unique tables from mappings
        all_table_names = set()
        table_to_fields = defaultdict(set)
        table_to_sheet = {}
        
        for sheet_name, sheet_mappings in mappings.items():
            for mapping in sheet_mappings:
                table_name = mapping['table']
                all_table_names.add(table_name)
                table_to_fields[table_name].add(mapping['field'])
                table_to_sheet[table_name] = sheet_name
        
        # Count matches per table
        for table_name in sorted(all_table_names):
            # Find table matches - only count .py, .pyspark, .sh files
            table_match_count = 0
            table_files = set()
            for match in table_matches:
                if match['name'] == table_name:
                    # Filter for py, pyspark, sh files only
                    if any(match['file_path'].endswith(ext) for ext in ['.py', '.pyspark', '.sh']):
                        table_match_count += match['occurrences']
                        table_files.add(match['file_path'])
            
            # Find field matches for this table
            fields_for_table = table_to_fields.get(table_name, set())
            fields_found = 0
            fields_found_list = []
            for match in field_matches:
                if match['name'] in fields_for_table:
                    # Filter for py, pyspark, sh files
                    if any(match['file_path'].endswith(ext) for ext in ['.py', '.pyspark', '.sh']):
                        fields_found += 1
                        fields_found_list.append(match['name'])
            
            table_summary_data.append({
                'Legacy Table': table_name,
                'Sheet': table_to_sheet.get(table_name, 'N/A'),
                'Total Attributes in Excel': len(fields_for_table),
                'Attributes Found in Code': len(set(fields_found_list)),
                'Table Occurrences': table_match_count,
                'Files with Table': len(table_files),
                'Status': '✅ Found' if table_match_count > 0 else '❌ Not Found'
            })
        
        if table_summary_data:
            summary_df = pd.DataFrame(table_summary_data)
            st.dataframe(summary_df, use_container_width=True, hide_index=True)
            
            # Statistics
            found_count = len([t for t in table_summary_data if t['Table Occurrences'] > 0])
            st.success(f"**Summary:** {found_count} of {len(table_summary_data)} legacy tables found in source code")
            
            csv = summary_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Legacy Table Summary as CSV",
                data=csv,
                file_name="legacy_table_summary.csv",
                mime="text/csv"
            )
    
    with tab2:
        st.subheader("Attribute Mapping Details")
        st.markdown("*Attributes found in Python, PySpark, and Shell files with C360 mapping*")
        
        # Build detailed attribute mapping table
        attribute_details = []
        
        for sheet_name, sheet_mappings in mappings.items():
            for mapping in sheet_mappings:
                table_name = mapping['table']
                field_name = mapping['field']
                c360_mapping = mapping.get('c360_mapping', field_c360_mapping.get(field_name, ''))
                
                # Find if this field was found in code
                field_found = False
                found_files = []
                found_lines = []
                
                for match in field_matches:
                    if match['name'] == field_name:
                        # Filter for py, pyspark, sh files
                        if any(match['file_path'].endswith(ext) for ext in ['.py', '.pyspark', '.sh']):
                            field_found = True
                            found_files.append(match['file_path'])
                            for detail in match['details']:
                                found_lines.append(f"L{detail['line_number']}")
                
                attribute_details.append({
                    'Legacy Table': table_name,
                    'Attribute': field_name,
                    'C360_Mapping': c360_mapping if c360_mapping else 'N/A',
                    'Found in Code': '✅ Yes' if field_found else '❌ No',
                    'Files': ', '.join(set(found_files)) if found_files else 'N/A',
                    'Line Numbers': ', '.join(found_lines[:10]) + ('...' if len(found_lines) > 10 else '') if found_lines else 'N/A'
                })
        
        if attribute_details:
            attr_df = pd.DataFrame(attribute_details)
            
            # Filters
            col1, col2 = st.columns(2)
            with col1:
                table_filter = st.multiselect("Filter by Table", options=attr_df['Legacy Table'].unique(), default=list(attr_df['Legacy Table'].unique()))
            with col2:
                found_filter = st.selectbox("Filter by Status", options=['All', 'Found Only', 'Not Found Only'])
            
            filtered_attr_df = attr_df[attr_df['Legacy Table'].isin(table_filter)]
            if found_filter == 'Found Only':
                filtered_attr_df = filtered_attr_df[filtered_attr_df['Found in Code'] == '✅ Yes']
            elif found_filter == 'Not Found Only':
                filtered_attr_df = filtered_attr_df[filtered_attr_df['Found in Code'] == '❌ No']
            
            st.dataframe(filtered_attr_df, use_container_width=True, hide_index=True, height=400)
            
            # Stats
            found_attrs = len([a for a in attribute_details if a['Found in Code'] == '✅ Yes'])
            st.info(f"**Attributes Found:** {found_attrs} of {len(attribute_details)} attributes identified in source code")
            
            csv = filtered_attr_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Attribute Mapping as CSV",
                data=csv,
                file_name="attribute_mapping_details.csv",
                mime="text/csv"
            )
    
    with tab3:
        st.subheader("SQL Queries Matching Legacy Tables")
        
        # Find all SQL-like queries that contain table names - only in .py, .pyspark, .sh files
        sql_matches = []
        sql_keywords = ['SELECT', 'FROM', 'JOIN', 'INSERT', 'UPDATE', 'DELETE', 'INTO', 'TABLE', 'WHERE', 'CREATE']
        
        for match in table_matches:
            # Filter for py, pyspark, sh files only
            if not any(match['file_path'].endswith(ext) for ext in ['.py', '.pyspark', '.sh']):
                continue
            for detail in match['details']:
                line_upper = detail['line_content'].upper()
                # Check if line contains SQL keywords
                if any(keyword in line_upper for keyword in sql_keywords):
                    sql_matches.append({
                        'Table Name': match['name'],
                        'File Name': match['file_name'],
                        'File Path': match['file_path'],
                        'Line Number': detail['line_number'],
                        'SQL Query': detail['line_content'][:300]
                    })
        
        if sql_matches:
            sql_df = pd.DataFrame(sql_matches)
            
            # Filter by table
            unique_tables = sql_df['Table Name'].unique()
            selected_tables = st.multiselect("Filter by Table", options=unique_tables, default=list(unique_tables), key="sql_table_filter")
            
            filtered_sql_df = sql_df[sql_df['Table Name'].isin(selected_tables)]
            st.dataframe(filtered_sql_df, use_container_width=True, hide_index=True, height=400)
            
            st.info(f"Found {len(filtered_sql_df)} SQL query matches with legacy table names")
            
            csv = filtered_sql_df.to_csv(index=False)
            st.download_button(
                label="📥 Download SQL Matches as CSV",
                data=csv,
                file_name="sql_query_matches.csv",
                mime="text/csv"
            )
        else:
            st.info("No SQL queries found matching legacy table names.")
    
    with tab4:
        st.subheader("Detailed Results Table")
        
        # Create detailed dataframe - only include .py, .pyspark, .sh files
        detailed_data = []
        for match in matches:
            # Filter for py, pyspark, sh files only
            if not any(match['file_path'].endswith(ext) for ext in ['.py', '.pyspark', '.sh']):
                continue
            for detail in match['details']:
                row = {
                    'Type': match['type'],
                    'Name': match['name'],
                    'File Name': match['file_name'],
                    'File Path': match['file_path'],
                    'Line Number': detail['line_number'],
                    'Line Content': detail['line_content'][:200]  # Truncate long lines
                }
                # Add parent table for fields
                if match['type'] == 'Field' and 'parent_tables' in match:
                    row['Parent Tables'] = ', '.join(match['parent_tables']) if match['parent_tables'] else 'N/A'
                # Add related fields for tables
                elif match['type'] == 'Table' and 'related_fields' in match:
                    row['Parent Tables'] = 'N/A'
                else:
                    row['Parent Tables'] = 'N/A'
                detailed_data.append(row)
        
        if detailed_data:
            df = pd.DataFrame(detailed_data)
            
            # Filters
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                type_filter = st.multiselect("Filter by Type", options=df['Type'].unique(), default=list(df['Type'].unique()), key="detailed_type_filter")
            with col2:
                # Get unique table names from Parent Tables column for fields, and Name column for tables
                all_table_names = set()
                for _, row in df.iterrows():
                    if row['Type'] == 'Table':
                        all_table_names.add(row['Name'])
                    elif row['Parent Tables'] != 'N/A':
                        for t in row['Parent Tables'].split(', '):
                            all_table_names.add(t.strip())
                table_options = sorted(list(all_table_names)) if all_table_names else []
                table_filter = st.multiselect("Filter by Table", options=table_options, default=table_options, key="detailed_table_filter")
            with col3:
                name_filter = st.text_input("Search by Name", "", key="detailed_name_filter")
            with col4:
                file_filter = st.text_input("Search by File", "", key="detailed_file_filter")
            
            filtered_df = df[df['Type'].isin(type_filter)]
            
            # Apply table filter
            if table_filter and len(table_filter) < len(table_options):
                def matches_table(row):
                    if row['Type'] == 'Table':
                        return row['Name'] in table_filter
                    elif row['Parent Tables'] != 'N/A':
                        parent_tables = [t.strip() for t in row['Parent Tables'].split(', ')]
                        return any(t in table_filter for t in parent_tables)
                    return False
                filtered_df = filtered_df[filtered_df.apply(matches_table, axis=1)]
            
            if name_filter:
                filtered_df = filtered_df[filtered_df['Name'].str.contains(name_filter, case=False)]
            if file_filter:
                filtered_df = filtered_df[filtered_df['File Path'].str.contains(file_filter, case=False)]
            
            st.dataframe(filtered_df, use_container_width=True, height=500)
            
            # Download button
            csv = filtered_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Results as CSV",
                data=csv,
                file_name="code_lens_results.csv",
                mime="text/csv"
            )


# Main application
st.sidebar.header("📤 Upload Files")

# Excel file upload
excel_file = st.sidebar.file_uploader(
    "Upload Excel Mapping File",
    type=['xlsx', 'xls'],
    help="Excel file with Legacy Table names in Column 1 and Field names in Column 2. Each sheet can contain different table mappings."
)

# ZIP file upload
zip_file = st.sidebar.file_uploader(
    "Upload Source Code Repository (ZIP)",
    type=['zip'],
    help="ZIP file containing PySpark, Python, or Shell project source code."
)

# Scan button
if st.sidebar.button("🔍 Scan Repository", type="primary", use_container_width=True):
    if not excel_file:
        st.error("Please upload an Excel mapping file.")
    elif not zip_file:
        st.error("Please upload a ZIP file containing the source code repository.")
    else:
        # Parse Excel
        with st.spinner("Parsing Excel mappings..."):
            mappings, tables, fields, table_field_mapping, field_c360_mapping = parse_excel_mappings(excel_file)
        
        if mappings is None:
            st.stop()
        
        # Display Excel summary
        st.success(f"✅ Loaded {len(tables) if tables else 0} tables and {len(fields) if fields else 0} fields from {len(mappings)} sheets")
        
        # Extract and scan ZIP
        temp_dir = tempfile.mkdtemp()
        
        try:
            with st.spinner("Extracting ZIP file..."):
                if not extract_zip(zip_file, temp_dir):
                    st.stop()
            
            st.success("✅ ZIP file extracted successfully")
            
            # Scan repository
            with st.spinner("Scanning repository..."):
                matches, files_scanned = scan_repository(temp_dir, tables, fields, table_field_mapping)
            
            st.success(f"✅ Scanned {files_scanned} files")
            
            # Display results
            st.header("📊 Scan Results")
            display_results(matches, mappings, len(tables) if tables else 0, len(fields) if fields else 0, field_c360_mapping)
            
        finally:
            # Cleanup
            shutil.rmtree(temp_dir, ignore_errors=True)

# Instructions
if not excel_file or not zip_file:
    st.markdown("---")
    st.header("📖 How to Use Code Lens")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("1️⃣ Prepare Excel Mapping File")
        st.markdown("""
        Create an Excel file with the following structure:
        - **Column 1:** Legacy Table Name
        - **Column 2:** Legacy Attribute Name
        - **Column 3:** C360_Mapping (optional)
        - Each sheet can contain mappings for different tables
        - The first row is treated as headers
        """)
        
        st.markdown("**Expected Excel Format:**")
        example_data = pd.DataFrame({
            'Legacy_Table': ['CRPS', 'CRPS', 'MNS', 'MNS', 'Triumph'],
            'Legacy_Attribute': ['firstname', 'secondName', 'email', 'city', 'age'],
            'C360_Mapping': ['360firstname', 'c360SecondName', 'email360', 'city360', '360age'],
            'Mapping_in_C360': ['Yes', 'Yes', 'Yes', 'Yes', 'Yes']
        })
        st.dataframe(example_data, use_container_width=True, hide_index=True)
        
        st.markdown("**Example Sheet Structure:**")
        st.markdown("""
        - **Sheet 1 (CRPS):** Contains CRPS table fields
        - **Sheet 2 (MNS):** Contains MNS table fields
        - **Sheet 3 (Triumph):** Contains Triumph table fields
        - Each sheet = One Legacy Table with its attributes
        """)
    
    with col2:
        st.subheader("2️⃣ Prepare Source Code Repository")
        st.markdown("""
        Create a ZIP file of your source code:
        - Supports Python (`.py`), PySpark, Shell (`.sh`) files
        - Also scans SQL, Scala, Java, and config files
        - Nested directory structures are supported
        
        **Scanned file types:**
        `.py`, `.pyspark`, `.sh`, `.sql`, `.scala`, `.java`, `.conf`, `.cfg`, `.yaml`, `.yml`, `.json`, `.txt`
        """)
    
    st.markdown("---")
    st.subheader("3️⃣ Review Results")
    st.markdown("""
    After scanning, Code Lens will show:
    - **Summary by Table/Field:** All occurrences grouped by table or field name
    - **Summary by File:** All matches organized by source file
    - **Detailed Results:** Filterable table with line numbers and content
    - **Export:** Download results as CSV for further analysis
    """)
