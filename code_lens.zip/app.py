import streamlit as st
import pandas as pd
import zipfile
import os
import re
import tempfile
import shutil
import ast
import json
from io import BytesIO
from collections import defaultdict
from datetime import datetime
import networkx as nx
import sqlparse
from pyvis.network import Network
import streamlit.components.v1 as components

st.set_page_config(
    page_title="Code Lens",
    page_icon="🔍",
    layout="wide"
)

st.title("🔍 Code Lens")
st.markdown("**Scan source code repositories to identify legacy table and field references**")

# Supported file extensions for scanning
SUPPORTED_EXTENSIONS = {'.py', '.pyspark', '.sh', '.sql', '.scala', '.java', '.conf', '.cfg', '.yaml', '.yml', '.json', '.txt', '.hql', '.hive'}

# Target file types for legacy scanning
TARGET_EXTENSIONS = ['.py', '.pyspark', '.sh', '.hql', '.hive']

# Folders to ignore when scanning for lineage
IGNORE_FOLDERS = {'.git', '__pycache__', '.venv', 'venv', 'node_modules', 'dist', 'build', '.pytest_cache'}

# ============== LINEAGE EXTRACTION FUNCTIONS ==============

def extract_sql_lineage(sql_content, file_path):
    """
    Extract table lineage from SQL/HQL content.
    Returns targets (tables written to) and sources (tables read from).
    """
    targets = []
    sources = []
    sql_blocks = []
    
    # Normalize content
    content = sql_content.upper()
    content_original = sql_content
    
    # Extract target tables (WRITE operations)
    # INSERT INTO / INSERT OVERWRITE
    insert_pattern = r'INSERT\s+(?:INTO|OVERWRITE)\s+(?:TABLE\s+)?([a-zA-Z_][a-zA-Z0-9_]*\.?[a-zA-Z0-9_]*)'
    for match in re.finditer(insert_pattern, sql_content, re.IGNORECASE):
        table = match.group(1).strip()
        if table and '.' in table or len(table) > 2:
            targets.append({'table': table, 'operation': 'INSERT', 'confidence': 'regex'})
    
    # CREATE TABLE AS SELECT (CTAS)
    ctas_pattern = r'CREATE\s+(?:EXTERNAL\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([a-zA-Z_][a-zA-Z0-9_]*\.?[a-zA-Z0-9_]*)\s+AS\s+SELECT'
    for match in re.finditer(ctas_pattern, sql_content, re.IGNORECASE):
        table = match.group(1).strip()
        if table:
            targets.append({'table': table, 'operation': 'CTAS', 'confidence': 'regex'})
    
    # CREATE VIEW AS SELECT
    view_pattern = r'CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+([a-zA-Z_][a-zA-Z0-9_]*\.?[a-zA-Z0-9_]*)\s+AS\s+SELECT'
    for match in re.finditer(view_pattern, sql_content, re.IGNORECASE):
        view = match.group(1).strip()
        if view:
            targets.append({'table': view, 'operation': 'CREATE_VIEW', 'confidence': 'regex'})
    
    # Extract source tables (READ operations)
    # FROM clause
    from_pattern = r'\bFROM\s+([a-zA-Z_][a-zA-Z0-9_]*\.?[a-zA-Z0-9_]*)'
    for match in re.finditer(from_pattern, sql_content, re.IGNORECASE):
        table = match.group(1).strip()
        # Exclude SQL keywords that might follow FROM
        if table.upper() not in ['SELECT', 'WHERE', 'GROUP', 'ORDER', 'LIMIT', 'UNION', 'HAVING', 'SET']:
            if table and (('.' in table) or len(table) > 2):
                sources.append({'table': table, 'operation': 'FROM', 'confidence': 'regex'})
    
    # JOIN clause
    join_pattern = r'\bJOIN\s+([a-zA-Z_][a-zA-Z0-9_]*\.?[a-zA-Z0-9_]*)'
    for match in re.finditer(join_pattern, sql_content, re.IGNORECASE):
        table = match.group(1).strip()
        if table.upper() not in ['ON', 'WHERE', 'AND', 'OR']:
            if table and (('.' in table) or len(table) > 2):
                sources.append({'table': table, 'operation': 'JOIN', 'confidence': 'regex'})
    
    # Extract file paths (LOCATION)
    location_pattern = r"LOCATION\s+['\"]([^'\"]+)['\"]"
    for match in re.finditer(location_pattern, sql_content, re.IGNORECASE):
        path = match.group(1).strip()
        sources.append({'table': path, 'operation': 'LOCATION', 'confidence': 'regex', 'is_path': True})
    
    # Build SQL blocks for diagram
    try:
        parsed = sqlparse.parse(sql_content)
        for stmt in parsed:
            stmt_str = str(stmt).strip()
            if stmt_str and len(stmt_str) > 10:
                sql_blocks.append({
                    'sql': stmt_str[:500],
                    'type': stmt.get_type() or 'UNKNOWN'
                })
    except:
        pass
    
    return targets, sources, sql_blocks


def extract_pyspark_lineage(py_content, file_path):
    """
    Extract table lineage from PySpark Python files.
    Returns targets, sources, imports, and orchestration calls.
    """
    targets = []
    sources = []
    imports = []
    orchestration = []
    sql_blocks = []
    
    # Extract spark.sql() blocks and parse them
    spark_sql_pattern = r'spark\.sql\s*\(\s*(?:"""|\'\'\')(.*?)(?:"""|\'\'\')\s*\)|spark\.sql\s*\(\s*["\'](.+?)["\']\s*\)'
    for match in re.finditer(spark_sql_pattern, py_content, re.DOTALL):
        sql_text = match.group(1) or match.group(2)
        if sql_text:
            sql_targets, sql_sources, blocks = extract_sql_lineage(sql_text, file_path)
            targets.extend(sql_targets)
            sources.extend(sql_sources)
            sql_blocks.append({'sql': sql_text[:500], 'type': 'spark.sql()'})
    
    # spark.table() / spark.read.table()
    table_read_pattern = r'spark\.(?:read\.)?table\s*\(\s*["\']([^"\']+)["\']\s*\)'
    for match in re.finditer(table_read_pattern, py_content):
        table = match.group(1).strip()
        sources.append({'table': table, 'operation': 'spark.table', 'confidence': 'regex'})
    
    # spark.read.parquet/csv/json/orc("path")
    read_path_pattern = r'spark\.read\.(?:parquet|csv|json|orc|text)\s*\(\s*["\']([^"\']+)["\']\s*\)'
    for match in re.finditer(read_path_pattern, py_content):
        path = match.group(1).strip()
        sources.append({'table': path, 'operation': 'spark.read', 'confidence': 'regex', 'is_path': True})
    
    # .saveAsTable() / .insertInto()
    save_table_pattern = r'\.(?:saveAsTable|insertInto)\s*\(\s*["\']([^"\']+)["\']\s*\)'
    for match in re.finditer(save_table_pattern, py_content):
        table = match.group(1).strip()
        targets.append({'table': table, 'operation': 'saveAsTable', 'confidence': 'regex'})
    
    # .write.save("path") / .save("path")
    write_path_pattern = r'\.write(?:\.[a-zA-Z]+\([^)]*\))*\.save\s*\(\s*["\']([^"\']+)["\']\s*\)'
    for match in re.finditer(write_path_pattern, py_content):
        path = match.group(1).strip()
        targets.append({'table': path, 'operation': 'write.save', 'confidence': 'regex', 'is_path': True})
    
    # Extract imports using AST
    try:
        tree = ast.parse(py_content)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append({'module': alias.name, 'type': 'import'})
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ''
                imports.append({'module': module, 'type': 'from_import'})
    except:
        # Fallback to regex for imports
        import_pattern = r'^(?:from\s+(\S+)\s+)?import\s+(.+)$'
        for match in re.finditer(import_pattern, py_content, re.MULTILINE):
            module = match.group(1) or match.group(2).split(',')[0].strip()
            imports.append({'module': module, 'type': 'regex'})
    
    # Orchestration calls
    subprocess_pattern = r'subprocess\.(?:run|call|Popen)\s*\(\s*["\']([^"\']+)["\']'
    for match in re.finditer(subprocess_pattern, py_content):
        cmd = match.group(1).strip()
        if 'spark-submit' in cmd or 'beeline' in cmd or 'hive' in cmd:
            orchestration.append({'command': cmd, 'type': 'subprocess'})
    
    os_system_pattern = r'os\.system\s*\(\s*["\']([^"\']+)["\']'
    for match in re.finditer(os_system_pattern, py_content):
        cmd = match.group(1).strip()
        if 'spark-submit' in cmd or 'beeline' in cmd or 'hive' in cmd:
            orchestration.append({'command': cmd, 'type': 'os.system'})
    
    return targets, sources, imports, orchestration, sql_blocks


def build_lineage_graph(scanned_files):
    """
    Build a unified directed graph from all scanned files.
    Node types: script, hive_table, file_path
    Edge types: READ, WRITE, IMPORTS
    """
    G = nx.DiGraph()
    
    for file_info in scanned_files:
        file_path = file_info['file_path']
        
        # Add script node
        G.add_node(file_path, type='script', label=os.path.basename(file_path))
        
        # Add target nodes and edges (WRITE)
        for target in file_info.get('targets', []):
            table = target['table']
            node_type = 'file_path' if target.get('is_path') else 'hive_table'
            G.add_node(table, type=node_type, label=table.split('/')[-1] if '/' in table else table)
            G.add_edge(file_path, table, type='WRITE', operation=target.get('operation', 'WRITE'))
        
        # Add source nodes and edges (READ)
        for source in file_info.get('sources', []):
            table = source['table']
            node_type = 'file_path' if source.get('is_path') else 'hive_table'
            G.add_node(table, type=node_type, label=table.split('/')[-1] if '/' in table else table)
            G.add_edge(table, file_path, type='READ', operation=source.get('operation', 'READ'))
        
        # Add import edges (for workflow)
        for imp in file_info.get('imports', []):
            module = imp['module']
            # Only add if it looks like a local module (not standard library)
            if module and not module.startswith(('os', 'sys', 're', 'json', 'datetime', 'collections', 'typing', 'pandas', 'numpy', 'pyspark')):
                module_file = module.replace('.', '/') + '.py'
                G.add_node(module_file, type='script', label=module)
                G.add_edge(file_path, module_file, type='IMPORTS', module=module)
    
    return G


def generate_lineage_dot(G, filter_keyword=None, max_hops=None, center_node=None):
    """
    Generate Graphviz DOT string for lineage diagram.
    """
    if center_node and max_hops:
        # Get neighborhood around center node
        try:
            nodes = set([center_node])
            for _ in range(max_hops):
                new_nodes = set()
                for n in nodes:
                    new_nodes.update(G.predecessors(n))
                    new_nodes.update(G.successors(n))
                nodes.update(new_nodes)
            G = G.subgraph(nodes)
        except:
            pass
    
    if filter_keyword:
        nodes = [n for n in G.nodes() if filter_keyword.lower() in n.lower()]
        # Also include connected nodes
        connected = set(nodes)
        for n in nodes:
            connected.update(G.predecessors(n))
            connected.update(G.successors(n))
        G = G.subgraph(connected)
    
    dot_lines = ['digraph Lineage {', '  rankdir=LR;', '  node [fontname="Arial"];', '  edge [fontname="Arial"];']
    
    # Group nodes by type
    tables = [n for n, d in G.nodes(data=True) if d.get('type') == 'hive_table']
    paths = [n for n, d in G.nodes(data=True) if d.get('type') == 'file_path']
    scripts = [n for n, d in G.nodes(data=True) if d.get('type') == 'script']
    
    # Add nodes with styling
    for node in tables:
        label = G.nodes[node].get('label', node)[:30]
        dot_lines.append(f'  "{node}" [label="{label}", shape=box, style="rounded,filled", fillcolor="#E8F5E9"];')
    
    for node in paths:
        label = G.nodes[node].get('label', node)[:30]
        dot_lines.append(f'  "{node}" [label="{label}", shape=folder, style=filled, fillcolor="#FFF3E0"];')
    
    for node in scripts:
        label = G.nodes[node].get('label', node)[:30]
        dot_lines.append(f'  "{node}" [label="{label}", shape=rect, style=filled, fillcolor="#E3F2FD"];')
    
    # Add edges
    for u, v, d in G.edges(data=True):
        edge_type = d.get('type', 'UNKNOWN')
        if edge_type == 'READ':
            dot_lines.append(f'  "{u}" -> "{v}" [color="#4CAF50", label="read"];')
        elif edge_type == 'WRITE':
            dot_lines.append(f'  "{u}" -> "{v}" [color="#F44336", label="write"];')
        elif edge_type == 'IMPORTS':
            dot_lines.append(f'  "{u}" -> "{v}" [color="#9E9E9E", style=dashed];')
    
    dot_lines.append('}')
    return '\n'.join(dot_lines)


def generate_workflow_pyvis(G, include_tables=False):
    """
    Generate PyVis network for workflow/control flow visualization.
    """
    net = Network(height="600px", width="100%", directed=True, bgcolor="#ffffff")
    net.barnes_hut(gravity=-3000, central_gravity=0.3, spring_length=200)
    
    # Filter to scripts only (or include tables if requested)
    for node, data in G.nodes(data=True):
        node_type = data.get('type', 'unknown')
        if node_type == 'script':
            net.add_node(node, label=data.get('label', node)[:20], color='#2196F3', shape='box')
        elif include_tables and node_type == 'hive_table':
            net.add_node(node, label=data.get('label', node)[:20], color='#4CAF50', shape='ellipse')
        elif include_tables and node_type == 'file_path':
            net.add_node(node, label=data.get('label', node)[:20], color='#FF9800', shape='triangle')
    
    for u, v, data in G.edges(data=True):
        edge_type = data.get('type', 'UNKNOWN')
        if u in net.get_nodes() and v in net.get_nodes():
            if edge_type == 'IMPORTS':
                net.add_edge(u, v, color='#9E9E9E', title='imports')
            elif edge_type == 'WRITE' and include_tables:
                net.add_edge(u, v, color='#F44336', title='writes')
            elif edge_type == 'READ' and include_tables:
                net.add_edge(u, v, color='#4CAF50', title='reads')
    
    return net


def generate_sql_diagram(sql_block, block_id):
    """
    Generate Graphviz DOT for a single SQL statement showing source -> query -> target.
    """
    sql_text = sql_block.get('sql', '')
    targets, sources, _ = extract_sql_lineage(sql_text, 'inline')
    
    dot_lines = [f'digraph SQL_{block_id} {{', '  rankdir=LR;', '  node [fontname="Arial"];']
    
    # Query node
    query_label = sql_block.get('type', 'QUERY')[:20]
    dot_lines.append(f'  "query_{block_id}" [label="{query_label}", shape=diamond, style=filled, fillcolor="#FFEB3B"];')
    
    # Source nodes
    for i, src in enumerate(sources[:5]):  # Limit to 5 sources
        table = src['table'][:25]
        dot_lines.append(f'  "src_{block_id}_{i}" [label="{table}", shape=box, style="rounded,filled", fillcolor="#E8F5E9"];')
        dot_lines.append(f'  "src_{block_id}_{i}" -> "query_{block_id}" [color="#4CAF50"];')
    
    # Target nodes
    for i, tgt in enumerate(targets[:3]):  # Limit to 3 targets
        table = tgt['table'][:25]
        dot_lines.append(f'  "tgt_{block_id}_{i}" [label="{table}", shape=box, style="rounded,filled", fillcolor="#FFCDD2"];')
        dot_lines.append(f'  "query_{block_id}" -> "tgt_{block_id}_{i}" [color="#F44336"];')
    
    dot_lines.append('}')
    return '\n'.join(dot_lines)


def scan_folder_for_lineage(folder_path):
    """
    Scan a folder for PySpark and SQL files and extract lineage.
    """
    scanned_files = []
    all_sql_blocks = []
    
    for root, dirs, files in os.walk(folder_path):
        # Skip ignored folders
        dirs[:] = [d for d in dirs if d not in IGNORE_FOLDERS]
        
        for file in files:
            file_path = os.path.join(root, file)
            rel_path = os.path.relpath(file_path, folder_path)
            ext = os.path.splitext(file)[1].lower()
            
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
            except:
                continue
            
            file_info = {
                'file_path': rel_path,
                'file_name': file,
                'extension': ext,
                'targets': [],
                'sources': [],
                'imports': [],
                'orchestration': [],
                'sql_blocks': []
            }
            
            if ext in ['.sql', '.hql', '.hive']:
                targets, sources, sql_blocks = extract_sql_lineage(content, rel_path)
                file_info['targets'] = targets
                file_info['sources'] = sources
                file_info['sql_blocks'] = sql_blocks
                all_sql_blocks.extend([{'file': rel_path, **b} for b in sql_blocks])
            
            elif ext in ['.py', '.pyspark']:
                targets, sources, imports, orchestration, sql_blocks = extract_pyspark_lineage(content, rel_path)
                file_info['targets'] = targets
                file_info['sources'] = sources
                file_info['imports'] = imports
                file_info['orchestration'] = orchestration
                file_info['sql_blocks'] = sql_blocks
                all_sql_blocks.extend([{'file': rel_path, **b} for b in sql_blocks])
            
            # Only include files with lineage data
            if file_info['targets'] or file_info['sources'] or file_info['imports']:
                scanned_files.append(file_info)
    
    return scanned_files, all_sql_blocks


# ============== END LINEAGE FUNCTIONS ==============


def parse_excel_mappings(excel_file):
    """
    Parse Excel file to extract table names, fields and C360 mappings from all sheets.
    Column 1: Legacy Table Name
    Column 2: Field/Attribute Name
    Column 3: C360_Mapping (optional)
    Returns a dictionary with sheet names as keys and list of mappings as values.
    """
    mappings = {}
    all_tables = set()
    all_fields = set()
    table_field_mapping = defaultdict(set)
    field_c360_mapping = {}  # Map field name to C360_Mapping
    
    try:
        excel_data = pd.ExcelFile(excel_file)
        
        for sheet_name in excel_data.sheet_names:
            df = pd.read_excel(excel_data, sheet_name=sheet_name)
            
            if len(df.columns) < 2:
                st.warning(f"Sheet '{sheet_name}' has less than 2 columns, skipping...")
                continue
            
            sheet_mappings = []
            
            # Get table, field, and c360 mapping columns
            table_col = df.columns[0]
            field_col = df.columns[1]
            c360_col = df.columns[2] if len(df.columns) >= 3 else None
            
            for _, row in df.iterrows():
                table_name = str(row[table_col]).strip() if pd.notna(row[table_col]) else ""
                field_name = str(row[field_col]).strip() if pd.notna(row[field_col]) else ""
                c360_mapping = ""
                if c360_col is not None:
                    c360_mapping = str(row[c360_col]).strip() if pd.notna(row[c360_col]) else ""
                    if c360_mapping.lower() == 'nan':
                        c360_mapping = ""
                
                if table_name and table_name.lower() != 'nan':
                    all_tables.add(table_name)
                    if field_name and field_name.lower() != 'nan':
                        all_fields.add(field_name)
                        table_field_mapping[table_name].add(field_name)
                        field_c360_mapping[field_name] = c360_mapping
                        sheet_mappings.append({
                            'table': table_name,
                            'field': field_name,
                            'c360_mapping': c360_mapping
                        })
            
            mappings[sheet_name] = sheet_mappings
        
        return mappings, all_tables, all_fields, table_field_mapping, field_c360_mapping
    
    except Exception as e:
        st.error(f"Error parsing Excel file: {str(e)}")
        return None, None, None, None, None


def extract_zip(zip_file, temp_dir):
    """Extract ZIP file to temporary directory."""
    try:
        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
        return True
    except Exception as e:
        st.error(f"Error extracting ZIP file: {str(e)}")
        return False


def get_all_files(directory):
    """Get all supported files from directory recursively."""
    files = []
    for root, dirs, filenames in os.walk(directory):
        # Skip hidden directories and common non-code directories
        dirs[:] = [d for d in dirs if not d.startswith('.') and d not in {'__pycache__', 'node_modules', '.git', 'venv', 'env'}]
        
        for filename in filenames:
            ext = os.path.splitext(filename)[1].lower()
            if ext in SUPPORTED_EXTENSIONS or filename.endswith('.py') or filename.endswith('.sh'):
                files.append(os.path.join(root, filename))
    
    return files


def compile_patterns(tables, fields):
    """
    Precompile regex patterns for tables and fields for performance.
    Supports qualified identifiers (schema.table, alias.field) with flexible separators.
    """
    table_patterns = {}
    field_patterns = {}
    
    for table in tables:
        # Pattern allows optional prefix (schema., alias.) and matches table name
        # Supports: table_name, schema.table_name, `table_name`, "table_name"
        pattern_str = r'(?:^|[\s,(\[\'"`.]|FROM\s+|JOIN\s+|INTO\s+|UPDATE\s+|TABLE\s+)' + re.escape(table) + r'(?:$|[\s,)\]\'"`.])'
        table_patterns[table] = re.compile(pattern_str, re.IGNORECASE)
    
    for field in fields:
        if len(field) < 2:  # Skip very short field names
            continue
        # Pattern allows optional prefix (alias., table.) and matches field name
        # Supports: field_name, alias.field_name, table.field_name
        pattern_str = r'(?:^|[\s,(\[\'"`.]|SELECT\s+|WHERE\s+|AND\s+|OR\s+|BY\s+)' + re.escape(field) + r'(?:$|[\s,)\]\'"`.])'
        field_patterns[field] = re.compile(pattern_str, re.IGNORECASE)
    
    return table_patterns, field_patterns


def extract_queries_from_content(content, lines):
    """
    Extract SQL-like queries from file content.
    Returns list of query objects with query text, start/end line numbers.
    """
    queries = []
    
    # Pattern to find SQL statement starts
    sql_start_pattern = re.compile(r'\b(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP|ALTER|MERGE)\b', re.IGNORECASE)
    
    # SQL continuation keywords - lines with these are likely part of an ongoing query
    sql_continuation_keywords = ['FROM', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 'OUTER', 'CROSS', 'FULL', 
                                  'ON', 'WHERE', 'AND', 'OR', 'GROUP', 'ORDER', 'HAVING', 'LIMIT', 
                                  'OFFSET', 'UNION', 'EXCEPT', 'INTERSECT', 'INTO', 'VALUES', 'SET',
                                  'AS', 'WHEN', 'THEN', 'ELSE', 'END', 'CASE', 'WITH', 'PARTITION', 
                                  'OVER', 'USING', 'BETWEEN', 'LIKE', 'IN', 'NOT', 'NULL', 'IS']
    
    i = 0
    while i < len(lines):
        line = lines[i]
        
        # Check if line starts a SQL query
        match = sql_start_pattern.search(line)
        if match:
            query_lines = [line]
            start_line = i + 1  # 1-indexed
            end_line = i + 1
            
            # Track parentheses and quotes for proper query boundary detection
            j = i + 1
            open_parens = line.count('(') - line.count(')')
            # Check for triple quotes (multi-line strings)
            in_triple_quote = ('"""' in line and line.count('"""') == 1) or ("'''" in line and line.count("'''") == 1)
            open_quotes = (line.count("'") % 2) + (line.count('"') % 2) if not in_triple_quote else 1
            
            # Track if previous line ended with comma (likely more columns coming)
            prev_line_continues = line.rstrip().endswith(',') or line.rstrip().endswith('(')
            
            while j < len(lines):
                next_line = lines[j]
                next_line_stripped = next_line.strip()
                next_line_upper = next_line_stripped.upper()
                
                # Check for triple quote ending
                if in_triple_quote and ('"""' in next_line or "'''" in next_line):
                    query_lines.append(next_line)
                    end_line = j + 1
                    in_triple_quote = False
                    j += 1
                    continue
                
                # If in triple quote, always continue
                if in_triple_quote:
                    query_lines.append(next_line)
                    end_line = j + 1
                    j += 1
                    if j - i > 100:
                        break
                    continue
                
                # Empty line might end query (unless inside parens/quotes or prev line continues)
                if not next_line_stripped:
                    if open_parens <= 0 and open_quotes == 0 and not prev_line_continues:
                        break
                    query_lines.append(next_line)
                    end_line = j + 1
                    j += 1
                    continue
                
                # Check if this line starts with a SQL continuation keyword
                first_word = next_line_stripped.split()[0].upper() if next_line_stripped.split() else ''
                is_continuation_keyword = first_word in sql_continuation_keywords
                
                # Check if this line contains SQL keywords
                has_sql_content = any(kw in next_line_upper for kw in sql_continuation_keywords)
                
                # Check if previous line suggests continuation (ends with comma, operator, etc.)
                continues_from_prev = prev_line_continues
                
                # Check if line looks like part of a SQL query (has table/column patterns, commas, etc.)
                looks_like_sql = bool(re.search(r'[a-zA-Z_]\.[a-zA-Z_]|,\s*$|^\s*[a-zA-Z_]+\s*,', next_line))
                
                # Continue if: continuation keyword, inside parens/quotes, has SQL content, or continues from prev
                if is_continuation_keyword or open_parens > 0 or open_quotes > 0 or has_sql_content or continues_from_prev or looks_like_sql:
                    query_lines.append(next_line)
                    end_line = j + 1
                    open_parens += next_line.count('(') - next_line.count(')')
                    
                    # Update quote tracking
                    if '"""' in next_line or "'''" in next_line:
                        if next_line.count('"""') == 1 or next_line.count("'''") == 1:
                            in_triple_quote = not in_triple_quote
                    if not in_triple_quote:
                        open_quotes = (open_quotes + next_line.count("'")) % 2 + (next_line.count('"') % 2)
                    
                    # Update prev line continues flag
                    prev_line_continues = next_line.rstrip().endswith(',') or next_line.rstrip().endswith('(')
                    
                    # Check for statement terminator
                    if ';' in next_line_stripped and open_parens <= 0 and not in_triple_quote:
                        break
                    
                    j += 1
                    if j - i > 100:  # Limit query size to 100 lines
                        break
                else:
                    # Check if next line starts a new SQL statement
                    if sql_start_pattern.match(next_line_stripped):
                        break
                    break
            
            query_text = '\n'.join(query_lines)
            queries.append({
                'query_text': query_text,
                'start_line': start_line,
                'end_line': end_line,
                'query_lines': query_lines
            })
            i = j + 1
        else:
            i += 1
    
    return queries


def extract_table_aliases(query_text, table_patterns):
    """
    Extract table aliases from a SQL query.
    Returns a dict mapping alias -> table_name for legacy tables found in query.
    Handles patterns like:
    - table_name alias
    - table_name AS alias
    - table_name as alias
    """
    aliases = {}
    query_upper = query_text.upper()
    
    for table in table_patterns.keys():
        table_lower = table.lower()
        table_upper = table.upper()
        
        # Pattern: table_name alias (no AS keyword)
        # Matches: FROM legacy_table lt, JOIN legacy_table lt ON
        pattern1 = re.compile(
            rf'\b{re.escape(table)}\s+([a-zA-Z_][a-zA-Z0-9_]*)\b(?!\s*\.)',
            re.IGNORECASE
        )
        
        # Pattern: table_name AS alias
        pattern2 = re.compile(
            rf'\b{re.escape(table)}\s+AS\s+([a-zA-Z_][a-zA-Z0-9_]*)\b',
            re.IGNORECASE
        )
        
        # Find all matches
        for match in pattern2.finditer(query_text):
            alias = match.group(1)
            # Exclude SQL keywords as aliases
            if alias.upper() not in ['ON', 'WHERE', 'AND', 'OR', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 
                                      'OUTER', 'CROSS', 'FULL', 'GROUP', 'ORDER', 'HAVING', 'LIMIT',
                                      'SELECT', 'FROM', 'SET', 'INTO', 'VALUES', 'AS', 'UNION']:
                aliases[alias.lower()] = table
        
        for match in pattern1.finditer(query_text):
            alias = match.group(1)
            # Exclude SQL keywords as aliases
            if alias.upper() not in ['ON', 'WHERE', 'AND', 'OR', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 
                                      'OUTER', 'CROSS', 'FULL', 'GROUP', 'ORDER', 'HAVING', 'LIMIT',
                                      'SELECT', 'FROM', 'SET', 'INTO', 'VALUES', 'AS', 'UNION']:
                # Don't overwrite if already found via AS pattern
                if alias.lower() not in aliases:
                    aliases[alias.lower()] = table
    
    return aliases


def find_field_with_alias(query_text, field, aliases, table_field_mapping):
    """
    Find a field in query text and determine which table it belongs to based on alias.
    Returns the table name if field is found with correct alias, None otherwise.
    Also returns True if field is found without alias prefix (standalone).
    """
    field_lower = field.lower()
    query_lower = query_text.lower()
    
    if field_lower not in query_lower:
        return None, False
    
    # Pattern to find alias.field_name
    alias_field_pattern = re.compile(
        rf'\b([a-zA-Z_][a-zA-Z0-9_]*)\.{re.escape(field)}\b',
        re.IGNORECASE
    )
    
    found_tables = set()
    found_standalone = False
    
    for match in alias_field_pattern.finditer(query_text):
        alias = match.group(1).lower()
        if alias in aliases:
            # Field is prefixed with a known table alias
            found_tables.add(aliases[alias])
        else:
            # Field has an alias prefix but it's not a known legacy table alias
            # Could be another table's field
            pass
    
    # Check for standalone field (no alias prefix)
    # Pattern: field not preceded by alias.
    standalone_pattern = re.compile(
        rf'(?<![a-zA-Z0-9_]\.)\b{re.escape(field)}\b(?!\.)',
        re.IGNORECASE
    )
    
    # Check if there are standalone occurrences
    for match in standalone_pattern.finditer(query_text):
        start = match.start()
        # Check that it's not preceded by alias.
        if start >= 2:
            prev_chars = query_text[max(0, start-20):start]
            if not re.search(r'[a-zA-Z_][a-zA-Z0-9_]*\.\s*$', prev_chars):
                found_standalone = True
    
    return found_tables, found_standalone


def scan_file_for_matches(file_path, table_patterns, field_patterns, table_field_mapping, base_dir):
    """
    Scan a file for table and field matches using query-based approach.
    First finds queries containing legacy tables, then scans those queries for attributes.
    Returns matches with query counts and attribute details.
    """
    matches = []
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            lines = content.split('\n')
    except Exception as e:
        return matches, []
    
    relative_path = os.path.relpath(file_path, base_dir)
    filename = os.path.basename(file_path)
    
    # Extract queries from the file
    queries = extract_queries_from_content(content, lines)
    
    # Track queries per table and attributes found in those queries
    table_queries = defaultdict(list)  # table -> list of queries containing it
    table_attributes = defaultdict(lambda: defaultdict(list))  # table -> attribute -> list of occurrences
    
    # Also track standalone line-based matches for non-query occurrences
    table_line_matches = defaultdict(list)
    field_line_matches = defaultdict(list)
    
    # Process each query
    for query in queries:
        query_text = query['query_text']
        query_text_padded = ' ' + query_text + ' '
        
        # Find which tables are in this query
        tables_in_query = []
        for table, pattern in table_patterns.items():
            if table.lower() in query_text.lower():
                if pattern.search(query_text_padded):
                    tables_in_query.append(table)
                    table_queries[table].append({
                        'query_text': query_text,
                        'start_line': query['start_line'],
                        'end_line': query['end_line'],
                        'file_path': relative_path,
                        'file_name': filename
                    })
        
        # Extract table aliases from the query (e.g., "legacy_table lt" -> alias 'lt' maps to 'legacy_table')
        aliases = extract_table_aliases(query_text, table_patterns)
        
        # For each table found in query, scan for its attributes using alias detection
        for table in tables_in_query:
            table_fields = table_field_mapping.get(table, set())
            for field in table_fields:
                if len(field) < 2:
                    continue
                if field.lower() in query_text.lower():
                    # Use alias-aware field detection
                    found_tables, found_standalone = find_field_with_alias(query_text, field, aliases, table_field_mapping)
                    
                    # Field is attributed to this table if:
                    # 1. It has an alias prefix that maps to this table, OR
                    # 2. It's found standalone (no alias) and this table is in the query
                    field_belongs_to_table = (table in found_tables) or (found_standalone and not found_tables)
                    
                    if field_belongs_to_table:
                        table_attributes[table][field].append({
                            'query_text': query_text,
                            'start_line': query['start_line'],
                            'end_line': query['end_line'],
                            'file_path': relative_path,
                            'file_name': filename,
                            'alias_used': next((a for a, t in aliases.items() if t == table), None)
                        })
    
    # Also scan line by line for matches (for display purposes)
    for line_num, line in enumerate(lines, 1):
        line_with_padding = ' ' + line + ' '
        
        for table, pattern in table_patterns.items():
            if table.lower() in line.lower():
                if pattern.search(line_with_padding):
                    # Check if this line falls within any query
                    in_query = False
                    containing_query = None
                    for query in queries:
                        if query['start_line'] <= line_num <= query['end_line']:
                            in_query = True
                            containing_query = query
                            break
                    
                    table_line_matches[table].append({
                        'line_number': line_num,
                        'line_content': line.strip(),
                        'match_text': table,
                        'in_query': in_query
                    })
                    
                    # If table found on a line within a query, add to table_queries
                    if in_query and containing_query:
                        # Check if this query is already added for this table
                        existing = False
                        for q in table_queries[table]:
                            if q['start_line'] == containing_query['start_line']:
                                existing = True
                                break
                        if not existing:
                            table_queries[table].append({
                                'query_text': containing_query['query_text'],
                                'start_line': containing_query['start_line'],
                                'end_line': containing_query['end_line'],
                                'file_path': relative_path,
                                'file_name': filename
                            })
        
        for field, pattern in field_patterns.items():
            if field.lower() in line.lower():
                if pattern.search(line_with_padding):
                    field_line_matches[field].append({
                        'line_number': line_num,
                        'line_content': line.strip(),
                        'match_text': field
                    })
    
    # Compile table results
    for table, query_list in table_queries.items():
        matches.append({
            'type': 'Table',
            'name': table,
            'file_name': filename,
            'file_path': relative_path,
            'query_count': len(query_list),
            'queries': query_list,
            'occurrences': len(table_line_matches.get(table, [])),
            'details': table_line_matches.get(table, []),
            'related_fields': list(table_field_mapping.get(table, [])),
            'attributes_found': dict(table_attributes.get(table, {}))
        })
    
    # Add tables that were found in lines but not in queries
    for table in table_line_matches:
        if table not in table_queries:
            matches.append({
                'type': 'Table',
                'name': table,
                'file_name': filename,
                'file_path': relative_path,
                'query_count': 0,
                'queries': [],
                'occurrences': len(table_line_matches[table]),
                'details': table_line_matches[table],
                'related_fields': list(table_field_mapping.get(table, [])),
                'attributes_found': {}
            })
    
    # Compile field results
    for field, occurrences in field_line_matches.items():
        parent_tables = [t for t, fields_set in table_field_mapping.items() if field in fields_set]
        # Check if this field was found in context of its parent table's query
        in_table_query = False
        for table in parent_tables:
            if field in table_attributes.get(table, {}):
                in_table_query = True
                break
        
        matches.append({
            'type': 'Field',
            'name': field,
            'file_name': filename,
            'file_path': relative_path,
            'occurrences': len(occurrences),
            'details': occurrences,
            'parent_tables': parent_tables,
            'in_table_query': in_table_query
        })
    
    return matches, queries


def scan_file_for_service_ids(file_path, service_ids, base_dir):
    """Scan a file for Service ID occurrences."""
    matches = []
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            lines = content.split('\n')
    except Exception as e:
        return matches
    
    relative_path = os.path.relpath(file_path, base_dir)
    filename = os.path.basename(file_path)
    
    for service_id in service_ids:
        service_id = service_id.strip()
        if not service_id:
            continue
        
        # Create pattern for service ID (case-insensitive, word boundary)
        pattern = re.compile(r'(?:^|[\s\'"=,:(\[])' + re.escape(service_id) + r'(?:$|[\s\'"=,:)\]])', re.IGNORECASE)
        
        occurrences = []
        for line_num, line in enumerate(lines, 1):
            if service_id.lower() in line.lower():
                if pattern.search(' ' + line + ' '):
                    occurrences.append({
                        'line_number': line_num,
                        'line_content': line.strip()[:200]
                    })
        
        if occurrences:
            matches.append({
                'service_id': service_id,
                'file_name': filename,
                'file_path': relative_path,
                'occurrences': len(occurrences),
                'details': occurrences
            })
    
    return matches


def scan_repository_for_service_ids(temp_dir, service_ids):
    """Scan repository for Service ID occurrences."""
    all_matches = []
    files = get_all_files(temp_dir)
    
    if not files or not service_ids:
        return all_matches
    
    for file_path in files:
        matches = scan_file_for_service_ids(file_path, service_ids, temp_dir)
        all_matches.extend(matches)
    
    return all_matches


def scan_repository(temp_dir, tables, fields, table_field_mapping):
    """Scan entire repository for matches."""
    all_matches = []
    all_queries = []
    files = get_all_files(temp_dir)
    
    # Track file stats by type
    file_stats = {
        'Python (.py)': {'scanned': 0, 'with_matches': 0, 'files': []},
        'Shell (.sh)': {'scanned': 0, 'with_matches': 0, 'files': []},
        'PySpark (.pyspark)': {'scanned': 0, 'with_matches': 0, 'files': []},
        'Hive/HQL (.hql, .hive)': {'scanned': 0, 'with_matches': 0, 'files': []},
        'SQL (.sql)': {'scanned': 0, 'with_matches': 0, 'files': []},
        'Other': {'scanned': 0, 'with_matches': 0, 'files': []}
    }
    
    def get_file_type(path):
        if path.endswith('.py'):
            return 'Python (.py)'
        elif path.endswith('.sh'):
            return 'Shell (.sh)'
        elif path.endswith('.pyspark'):
            return 'PySpark (.pyspark)'
        elif path.endswith('.hql') or path.endswith('.hive'):
            return 'Hive/HQL (.hql, .hive)'
        elif path.endswith('.sql'):
            return 'SQL (.sql)'
        else:
            return 'Other'
    
    # Guard for empty file list
    if not files:
        st.warning("No supported source files found in the repository.")
        return all_matches, 0, all_queries, file_stats
    
    # Precompile patterns once for performance
    table_patterns, field_patterns = compile_patterns(tables, fields)
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    for idx, file_path in enumerate(files):
        status_text.text(f"Scanning: {os.path.basename(file_path)}")
        file_type = get_file_type(file_path)
        file_stats[file_type]['scanned'] += 1
        
        matches, queries = scan_file_for_matches(file_path, table_patterns, field_patterns, table_field_mapping, temp_dir)
        
        if matches:
            file_stats[file_type]['with_matches'] += 1
            file_stats[file_type]['files'].append(os.path.basename(file_path))
        
        all_matches.extend(matches)
        all_queries.extend(queries)
        progress_bar.progress((idx + 1) / len(files))
    
    status_text.text("Scan complete!")
    progress_bar.empty()
    
    return all_matches, len(files), all_queries, file_stats


def generate_html_report(table_summary_data, field_summary_data, table_occurrences_data, field_occurrences_data, 
                          total_excel_tables, total_excel_fields, total_queries, scan_stats, file_stats=None):
    """Generate a comprehensive HTML report with all analysis."""
    
    report_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Build file scan summary HTML
    file_scan_html = "<p>No file scan data</p>"
    if file_stats:
        file_scan_data = []
        for file_type, stats in file_stats.items():
            if stats['scanned'] > 0:
                file_scan_data.append({
                    'File Type': file_type,
                    'Files Scanned': stats['scanned'],
                    'Files with Matches': stats['with_matches'],
                    'Match Rate': f"{(stats['with_matches']/stats['scanned']*100):.1f}%" if stats['scanned'] > 0 else "0%"
                })
        if file_scan_data:
            file_scan_html = pd.DataFrame(file_scan_data).to_html(index=False, classes='data-table', escape=False)
    
    # Convert dataframes to HTML tables
    table_summary_html = pd.DataFrame(table_summary_data).to_html(index=False, classes='data-table', escape=False) if table_summary_data else "<p>No data</p>"
    
    # Filter field summary to only show found attributes
    found_fields = [f for f in field_summary_data if f.get('In Table Query') == '✅ Yes' or f.get('Query Count', 0) > 0] if field_summary_data else []
    field_summary_html = pd.DataFrame(found_fields).to_html(index=False, classes='data-table', escape=False) if found_fields else "<p>No attributes found in table queries</p>"
    
    table_occ_html = pd.DataFrame(table_occurrences_data).to_html(index=False, classes='data-table', escape=False) if table_occurrences_data else "<p>No data</p>"
    field_occ_html = pd.DataFrame(field_occurrences_data).to_html(index=False, classes='data-table', escape=False) if field_occurrences_data else "<p>No data</p>"
    
    html_template = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Lens Analysis Report</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f7fa;
            color: #333;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}
        h1 {{
            color: #1a73e8;
            border-bottom: 3px solid #1a73e8;
            padding-bottom: 10px;
        }}
        h2 {{
            color: #34495e;
            margin-top: 30px;
            border-left: 4px solid #1a73e8;
            padding-left: 15px;
        }}
        h3 {{
            color: #555;
            margin-top: 20px;
        }}
        .header {{
            background: linear-gradient(135deg, #1a73e8, #4285f4);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .header h1 {{
            color: white;
            border-bottom: none;
            margin: 0;
        }}
        .header p {{
            margin: 10px 0 0 0;
            opacity: 0.9;
        }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }}
        .stat-card {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }}
        .stat-card .value {{
            font-size: 2.5em;
            font-weight: bold;
            color: #1a73e8;
        }}
        .stat-card .label {{
            color: #666;
            margin-top: 5px;
        }}
        .section {{
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .table-wrapper {{
            width: 100%;
            overflow-x: auto;
        }}
        .data-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 13px;
            table-layout: auto;
        }}
        .data-table th {{
            background-color: #1a73e8;
            color: white;
            padding: 10px 6px;
            text-align: left;
            position: sticky;
            top: 0;
            white-space: nowrap;
        }}
        .data-table td {{
            padding: 8px 6px;
            border-bottom: 1px solid #eee;
            word-wrap: break-word;
            max-width: 300px;
        }}
        .data-table tr:hover {{
            background-color: #f5f9ff;
        }}
        .data-table tr:nth-child(even) {{
            background-color: #fafafa;
        }}
        .found {{ color: #27ae60; font-weight: bold; }}
        .not-found {{ color: #e74c3c; }}
        .explanation {{
            background: #e8f4fd;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #1a73e8;
            margin: 20px 0;
        }}
        .explanation h3 {{
            margin-top: 0;
            color: #1a73e8;
        }}
        .footer {{
            text-align: center;
            color: #888;
            margin-top: 40px;
            padding: 20px;
            border-top: 1px solid #ddd;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 Code Lens Analysis Report</h1>
            <p>Generated on: {report_date}</p>
        </div>
        
        <div class="explanation">
            <h3>How Scanning Works</h3>
            <p><strong>Step 1:</strong> The Excel mapping file is parsed to extract Legacy Table names (Column 1) and Legacy Attribute names (Column 2).</p>
            <p><strong>Step 2:</strong> Source code files (.py, .pyspark, .sh, .hql, .hive) are scanned to find SQL-like queries (SELECT, INSERT, UPDATE, etc.).</p>
            <p><strong>Step 3:</strong> For each query, we first check if it contains any Legacy Table names.</p>
            <p><strong>Step 4:</strong> If a query contains a Legacy Table, we then scan that specific query for Legacy Attributes belonging to that table.</p>
            <p><strong>Step 5:</strong> This ensures attributes are only counted when found in context with their parent table.</p>
        </div>
        
        <h2>📊 Overview Statistics</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="value">{total_excel_tables}</div>
                <div class="label">Tables in Excel</div>
            </div>
            <div class="stat-card">
                <div class="value">{total_excel_fields}</div>
                <div class="label">Attributes in Excel</div>
            </div>
            <div class="stat-card">
                <div class="value">{scan_stats.get('tables_found', 0)}</div>
                <div class="label">Tables Found</div>
            </div>
            <div class="stat-card">
                <div class="value">{total_queries}</div>
                <div class="label">SQL Queries Found</div>
            </div>
            <div class="stat-card">
                <div class="value">{scan_stats.get('attrs_in_queries', 0)}</div>
                <div class="label">Attrs in Queries</div>
            </div>
            <div class="stat-card">
                <div class="value">{scan_stats.get('coverage', 0):.1f}%</div>
                <div class="label">Coverage</div>
            </div>
        </div>
        
        <div class="section">
            <h2>📁 Files Scanned by Type</h2>
            <p>Overview of source files scanned and matches found by file type.</p>
            <div class="table-wrapper">{file_scan_html}</div>
        </div>
        
        <div class="section">
            <h2>📋 Legacy Table Summary</h2>
            <p>Overview of all legacy tables from Excel and their presence in the codebase.</p>
            <div class="table-wrapper">{table_summary_html}</div>
        </div>
        
        <div class="section">
            <h2>📊 Attribute Summary (Found Only)</h2>
            <p>Attributes found within their parent table's queries.</p>
            <div class="table-wrapper">{field_summary_html}</div>
        </div>
        
        <div class="section">
            <h2>🔍 Table Occurrences (Detailed)</h2>
            <p>All occurrences of legacy table names in the scanned files.</p>
            <div class="table-wrapper">{table_occ_html}</div>
        </div>
        
        <div class="section">
            <h2>🔍 Field/Attribute Occurrences (Detailed)</h2>
            <p>All occurrences of legacy attributes in the scanned files.</p>
            <div class="table-wrapper">{field_occ_html}</div>
        </div>
        
        <div class="footer">
            <p>Generated by Code Lens - Legacy Table and Field Scanner</p>
        </div>
    </div>
</body>
</html>
"""
    return html_template


def display_results(matches, mappings, total_excel_tables, total_excel_fields, field_c360_mapping=None, file_stats=None, service_id_matches=None):
    """Display scan results in organized format."""
    if field_c360_mapping is None:
        field_c360_mapping = {}
    if file_stats is None:
        file_stats = {}
    if service_id_matches is None:
        service_id_matches = []
    
    if not matches:
        st.info("No matches found in the repository.")
        return
    
    # Summary statistics
    table_matches = [m for m in matches if m['type'] == 'Table']
    field_matches = [m for m in matches if m['type'] == 'Field']
    
    # Excel totals
    st.subheader("Excel File Summary")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Total Tables in Excel", total_excel_tables)
    with col2:
        st.metric("Total Fields in Excel", total_excel_fields)
    
    st.divider()
    
    # File Scan Summary Table
    if file_stats:
        st.subheader("📁 Files Scanned by Type")
        file_scan_data = []
        for file_type, stats in file_stats.items():
            if stats['scanned'] > 0:
                file_scan_data.append({
                    'File Type': file_type,
                    'Files Scanned': stats['scanned'],
                    'Files with Matches': stats['with_matches'],
                    'Match Rate': f"{(stats['with_matches']/stats['scanned']*100):.1f}%" if stats['scanned'] > 0 else "0%"
                })
        
        if file_scan_data:
            file_scan_df = pd.DataFrame(file_scan_data)
            st.dataframe(file_scan_df, use_container_width=True, hide_index=True)
        
        st.divider()
    
    # Match statistics
    st.subheader("Scan Results")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Matches", len(matches))
    with col2:
        st.metric("Table Matches", len(table_matches))
    with col3:
        st.metric("Field Matches", len(field_matches))
    
    # Tabs for different views - add Service ID tab if there are matches
    if service_id_matches:
        tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs(["📋 Legacy Table Summary", "📊 Attribute Mapping Details", "🔍 Table Occurrences", "🔍 Field Occurrences", "📁 Files to Correct", "🔑 Service IDs", "📥 Reports"])
    else:
        tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(["📋 Legacy Table Summary", "📊 Attribute Mapping Details", "🔍 Table Occurrences", "🔍 Field Occurrences", "📁 Files to Correct", "📥 Reports"])
        tab7 = None
    
    with tab1:
        st.subheader("Legacy Tables Found in Project")
        st.markdown("*Scanning: Python (.py), PySpark (.pyspark), Shell (.sh), Hive/HQL (.hql, .hive) files*")
        
        # Build comprehensive table summary
        table_summary_data = []
        
        # Get unique tables from mappings
        all_table_names = set()
        table_to_fields = defaultdict(set)
        table_to_sheet = {}
        
        for sheet_name, sheet_mappings in mappings.items():
            for mapping in sheet_mappings:
                table_name = mapping['table']
                all_table_names.add(table_name)
                table_to_fields[table_name].add(mapping['field'])
                table_to_sheet[table_name] = sheet_name
        
        # Count matches per table
        for table_name in sorted(all_table_names):
            # Find table matches - only count target file types
            table_query_count = 0
            table_occurrence_count = 0
            table_files = set()
            attributes_in_queries = set()
            
            for match in table_matches:
                if match['name'] == table_name:
                    # Filter for target file types only
                    if any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                        table_query_count += match.get('query_count', 0)
                        table_occurrence_count += match.get('occurrences', 0)
                        table_files.add(match['file_path'])
                        # Get attributes found in queries with this table
                        attrs_found = match.get('attributes_found', {})
                        attributes_in_queries.update(attrs_found.keys())
            
            # Find field matches for this table (in table's queries)
            fields_for_table = table_to_fields.get(table_name, set())
            
            table_summary_data.append({
                'Legacy Table': table_name,
                'Sheet': table_to_sheet.get(table_name, 'N/A'),
                'Attributes in Excel': len(fields_for_table),
                'Attributes in Queries': len(attributes_in_queries),
                'Query Count': table_query_count,
                'Occurrences': table_occurrence_count,
                'File Count': len(table_files),
                'File Names': ', '.join(sorted([os.path.basename(f) for f in table_files])) if table_files else 'N/A',
                'Status': '✅ Found' if table_query_count > 0 or table_occurrence_count > 0 else '❌ Not Found'
            })
        
        if table_summary_data:
            # Quick Overview
            st.markdown("### Quick Overview")
            total_tables = len(table_summary_data)
            found_tables = len([t for t in table_summary_data if t['Query Count'] > 0 or t['Occurrences'] > 0])
            total_queries = sum(t['Query Count'] for t in table_summary_data)
            total_attrs_in_queries = sum(t['Attributes in Queries'] for t in table_summary_data)
            total_attrs_in_excel = sum(t['Attributes in Excel'] for t in table_summary_data)
            
            col1, col2, col3, col4, col5 = st.columns(5)
            with col1:
                st.metric("Tables Found", f"{found_tables}/{total_tables}")
            with col2:
                st.metric("Total Queries", total_queries)
            with col3:
                st.metric("Attrs in Excel", total_attrs_in_excel)
            with col4:
                st.metric("Attrs in Queries", total_attrs_in_queries)
            with col5:
                coverage = (total_attrs_in_queries / total_attrs_in_excel * 100) if total_attrs_in_excel > 0 else 0
                st.metric("Coverage", f"{coverage:.1f}%")
            
            st.divider()
            
            summary_df = pd.DataFrame(table_summary_data)
            st.dataframe(summary_df, use_container_width=True, hide_index=True)
            
            # Statistics
            st.success(f"**Summary:** {found_tables} of {total_tables} legacy tables found in source code with {total_queries} queries")
            
            csv = summary_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Legacy Table Summary as CSV",
                data=csv,
                file_name="legacy_table_summary.csv",
                mime="text/csv"
            )
    
    with tab2:
        st.subheader("Attribute Mapping Details")
        st.markdown("*Attributes found within queries containing their parent Legacy Table*")
        
        # Build detailed attribute mapping table
        attribute_details = []
        
        # First, build a map of table -> attributes found in that table's queries
        table_attr_in_queries = defaultdict(lambda: defaultdict(list))
        for match in table_matches:
            if any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                attrs_found = match.get('attributes_found', {})
                for attr, occurrences in attrs_found.items():
                    for occ in occurrences:
                        table_attr_in_queries[match['name']][attr].append({
                            'file_path': match['file_path'],
                            'file_name': match['file_name'],
                            'start_line': occ.get('start_line', 0),
                            'query_text': occ.get('query_text', '')[:100],
                            'alias_used': occ.get('alias_used', '')
                        })
        
        # === NEW: Simplified Table-Attribute Summary ===
        st.markdown("### 📊 Table-Attribute Occurrence Summary")
        simple_summary = []
        for table_name, attrs in table_attr_in_queries.items():
            for attr_name, occurrences in attrs.items():
                files = list(set([occ['file_path'] for occ in occurrences]))
                aliases_used = list(set([occ.get('alias_used', '') for occ in occurrences if occ.get('alias_used')]))
                simple_summary.append({
                    'Legacy Table': table_name,
                    'Legacy Attribute': attr_name,
                    'Occurrences': len(occurrences),
                    'Files': ', '.join(files),
                    'Alias Used': ', '.join(aliases_used) if aliases_used else '-'
                })
        
        if simple_summary:
            simple_df = pd.DataFrame(simple_summary)
            simple_df = simple_df.sort_values(['Legacy Table', 'Legacy Attribute']).reset_index(drop=True)
            
            # Filters for simple summary
            col1, col2 = st.columns(2)
            with col1:
                simple_table_filter = st.multiselect("Filter by Legacy Table", 
                    options=list(simple_df['Legacy Table'].unique()), 
                    key="simple_table_filter")
            with col2:
                simple_attr_filter = st.multiselect("Filter by Attribute", 
                    options=list(simple_df['Legacy Attribute'].unique()), 
                    key="simple_attr_filter")
            
            filtered_simple_df = simple_df.copy()
            if simple_table_filter:
                filtered_simple_df = filtered_simple_df[filtered_simple_df['Legacy Table'].isin(simple_table_filter)]
            if simple_attr_filter:
                filtered_simple_df = filtered_simple_df[filtered_simple_df['Legacy Attribute'].isin(simple_attr_filter)]
            
            st.dataframe(filtered_simple_df, use_container_width=True, hide_index=True, height=300)
            
            st.info(f"**Found:** {len(simple_summary)} table-attribute combinations with {sum(s['Occurrences'] for s in simple_summary)} total occurrences")
            
            csv_simple = filtered_simple_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Table-Attribute Summary as CSV",
                data=csv_simple,
                file_name="table_attribute_summary.csv",
                mime="text/csv",
                key="download_simple_summary"
            )
        else:
            st.info("No attributes found in queries with their parent tables.")
        
        st.divider()
        st.markdown("### 📋 Full Attribute Mapping (from Excel)")
        
        for sheet_name, sheet_mappings in mappings.items():
            for mapping in sheet_mappings:
                table_name = mapping['table']
                field_name = mapping['field']
                c360_mapping = mapping.get('c360_mapping', field_c360_mapping.get(field_name, ''))
                
                # Check if this attribute was found in queries containing its parent table
                in_table_query = field_name in table_attr_in_queries.get(table_name, {})
                query_occurrences = table_attr_in_queries.get(table_name, {}).get(field_name, [])
                
                # Also check general field matches
                field_found_general = False
                found_files = []
                found_lines = []
                
                for match in field_matches:
                    if match['name'] == field_name:
                        if any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                            field_found_general = True
                            found_files.append(match['file_path'])
                            for detail in match['details']:
                                found_lines.append(f"L{detail['line_number']}")
                
                attribute_details.append({
                    'Legacy Table': table_name,
                    'Attribute': field_name,
                    'C360_Mapping': c360_mapping if c360_mapping else 'N/A',
                    'In Table Query': '✅ Yes' if in_table_query else '❌ No',
                    'Query Count': len(query_occurrences),
                    'Files': ', '.join(set([q['file_path'] for q in query_occurrences])) if query_occurrences else 'N/A',
                    'Also Found Elsewhere': '✅' if field_found_general and not in_table_query else ''
                })
        
        if attribute_details:
            attr_df = pd.DataFrame(attribute_details)
            
            # Filters
            col1, col2 = st.columns(2)
            all_tables = list(attr_df['Legacy Table'].unique())
            with col1:
                table_filter = st.multiselect("Filter by Table", options=all_tables, key="attr_table_filter")
            with col2:
                found_filter = st.selectbox("Filter by Status", options=['All', 'In Table Query Only', 'Not Found Only'], key="attr_status_filter")
            
            # Apply filters - if no selection, show all
            if table_filter:
                filtered_attr_df = attr_df[attr_df['Legacy Table'].isin(table_filter)]
            else:
                filtered_attr_df = attr_df
            if found_filter == 'In Table Query Only':
                filtered_attr_df = filtered_attr_df[filtered_attr_df['In Table Query'] == '✅ Yes']
            elif found_filter == 'Not Found Only':
                filtered_attr_df = filtered_attr_df[filtered_attr_df['In Table Query'] == '❌ No']
            
            st.dataframe(filtered_attr_df, use_container_width=True, hide_index=True, height=400)
            
            # Stats
            found_attrs = len([a for a in attribute_details if a['In Table Query'] == '✅ Yes'])
            st.info(f"**Attributes in Table Queries:** {found_attrs} of {len(attribute_details)} attributes found within their parent table's queries")
            
            csv = filtered_attr_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Attribute Mapping as CSV",
                data=csv,
                file_name="attribute_mapping_details.csv",
                mime="text/csv"
            )
    
    with tab3:
        st.subheader("Table Occurrences")
        st.markdown("*All occurrences of legacy table names in source files*")
        
        # Build table occurrences data
        table_occurrences_data = []
        for match in table_matches:
            if not any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                continue
            for detail in match['details']:
                table_occurrences_data.append({
                    'Legacy Table': match['name'],
                    'File Name': match['file_name'],
                    'File Path': match['file_path'],
                    'Line Number': detail['line_number'],
                    'Line Content': detail['line_content'][:300],
                    'Query Count': match.get('query_count', 0)
                })
        
        if table_occurrences_data:
            table_occ_df = pd.DataFrame(table_occurrences_data)
            
            # Filter by table
            unique_tables = list(table_occ_df['Legacy Table'].unique())
            selected_tables = st.multiselect("Filter by Table", options=unique_tables, key="table_occ_filter")
            
            # Apply filter - if no selection, show all
            if selected_tables:
                filtered_table_occ_df = table_occ_df[table_occ_df['Legacy Table'].isin(selected_tables)]
            else:
                filtered_table_occ_df = table_occ_df
            st.dataframe(filtered_table_occ_df, use_container_width=True, hide_index=True, height=400)
            
            st.info(f"Found {len(filtered_table_occ_df)} table occurrences across {len(filtered_table_occ_df['File Name'].unique())} files")
            
            csv = filtered_table_occ_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Table Occurrences as CSV",
                data=csv,
                file_name="table_occurrences.csv",
                mime="text/csv"
            )
        else:
            st.info("No table occurrences found.")
    
    with tab4:
        st.subheader("Field/Attribute Occurrences")
        st.markdown("*All occurrences of legacy attributes in source files*")
        
        # Build field occurrences data
        field_occurrences_data = []
        for match in field_matches:
            if not any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                continue
            for detail in match['details']:
                field_occurrences_data.append({
                    'Attribute': match['name'],
                    'Parent Table': ', '.join(match.get('parent_tables', [])) if match.get('parent_tables') else 'N/A',
                    'File Name': match['file_name'],
                    'File Path': match['file_path'],
                    'Line Number': detail['line_number'],
                    'Line Content': detail['line_content'][:300],
                    'In Table Query': '✅' if match.get('in_table_query', False) else ''
                })
        
        if field_occurrences_data:
            field_occ_df = pd.DataFrame(field_occurrences_data)
            
            # Filter by parent table
            unique_tables = set()
            for item in field_occurrences_data:
                if item['Parent Table'] != 'N/A':
                    for t in item['Parent Table'].split(', '):
                        unique_tables.add(t.strip())
            table_options = sorted(list(unique_tables))
            selected_tables = st.multiselect("Filter by Parent Table", options=table_options, key="field_occ_filter")
            
            # Apply filter - if no selection, show all
            if selected_tables:
                filtered_field_occ_df = field_occ_df[field_occ_df['Parent Table'].apply(
                    lambda x: any(t in x for t in selected_tables) if x != 'N/A' else False
                )]
            else:
                filtered_field_occ_df = field_occ_df
            st.dataframe(filtered_field_occ_df, use_container_width=True, hide_index=True, height=400)
            
            st.info(f"Found {len(filtered_field_occ_df)} field occurrences across {len(filtered_field_occ_df['File Name'].unique())} files")
            
            csv = filtered_field_occ_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Field Occurrences as CSV",
                data=csv,
                file_name="field_occurrences.csv",
                mime="text/csv"
            )
        else:
            st.info("No field occurrences found.")
    
    with tab5:
        st.subheader("Files to Correct")
        st.markdown("*Summary of files containing legacy references that need attention*")
        
        # Build file analysis data
        file_analysis = defaultdict(lambda: {
            'tables': set(),
            'fields': set(),
            'table_lines': [],
            'field_lines': [],
            'query_count': 0
        })
        
        # Collect data from table matches
        for match in table_matches:
            if not any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                continue
            file_path = match['file_path']
            file_analysis[file_path]['tables'].add(match['name'])
            file_analysis[file_path]['query_count'] += match.get('query_count', 0)
            for detail in match['details']:
                file_analysis[file_path]['table_lines'].append({
                    'table': match['name'],
                    'line': detail['line_number'],
                    'content': detail['line_content'][:100]
                })
        
        # Collect data from field matches
        for match in field_matches:
            if not any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                continue
            file_path = match['file_path']
            file_analysis[file_path]['fields'].add(match['name'])
            for detail in match['details']:
                file_analysis[file_path]['field_lines'].append({
                    'field': match['name'],
                    'line': detail['line_number'],
                    'content': detail['line_content'][:100]
                })
        
        # Count files by type
        py_files = [f for f in file_analysis.keys() if f.endswith('.py')]
        sh_files = [f for f in file_analysis.keys() if f.endswith('.sh')]
        hql_files = [f for f in file_analysis.keys() if f.endswith('.hql') or f.endswith('.hive')]
        pyspark_files = [f for f in file_analysis.keys() if f.endswith('.pyspark')]
        
        # Display file type summary
        st.markdown("### File Type Summary")
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Python Files (.py)", len(py_files))
        with col2:
            st.metric("Shell Scripts (.sh)", len(sh_files))
        with col3:
            st.metric("Hive/HQL Files", len(hql_files))
        with col4:
            st.metric("PySpark Files", len(pyspark_files))
        
        st.divider()
        
        # Build detailed file list
        files_to_correct = []
        for file_path, data in file_analysis.items():
            ext = os.path.splitext(file_path)[1]
            file_type = {'.py': 'Python', '.sh': 'Shell', '.hql': 'HQL', '.hive': 'Hive', '.pyspark': 'PySpark'}.get(ext, 'Other')
            
            files_to_correct.append({
                'File Name': os.path.basename(file_path),
                'File Type': file_type,
                'File Path': file_path,
                'Tables Found': len(data['tables']),
                'Tables': ', '.join(sorted(data['tables'])),
                'Fields Found': len(data['fields']),
                'Fields to Check': ', '.join(sorted(data['fields']))[:200] + ('...' if len(', '.join(sorted(data['fields']))) > 200 else ''),
                'Query Count': data['query_count']
            })
        
        if files_to_correct:
            files_df = pd.DataFrame(files_to_correct)
            files_df = files_df.sort_values(['File Type', 'Tables Found'], ascending=[True, False])
            
            # Filter by file type
            file_types = files_df['File Type'].unique()
            selected_types = st.multiselect("Filter by File Type", options=file_types, default=list(file_types), key="file_type_filter")
            
            filtered_files_df = files_df[files_df['File Type'].isin(selected_types)]
            st.dataframe(filtered_files_df, use_container_width=True, hide_index=True, height=400)
            
            st.success(f"**Total:** {len(filtered_files_df)} files need attention with {sum(filtered_files_df['Tables Found'])} table references and {sum(filtered_files_df['Fields Found'])} field references")
            
            csv = filtered_files_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Files to Correct as CSV",
                data=csv,
                file_name="files_to_correct.csv",
                mime="text/csv"
            )
            
            # Detailed view per file
            st.divider()
            st.markdown("### Detailed File Analysis")
            selected_file = st.selectbox("Select a file to see details", options=sorted(file_analysis.keys()))
            
            if selected_file:
                file_data = file_analysis[selected_file]
                
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown("**Tables in this file:**")
                    for table in sorted(file_data['tables']):
                        st.write(f"- {table}")
                
                with col2:
                    st.markdown("**Fields to check:**")
                    for field in sorted(file_data['fields']):
                        st.write(f"- {field}")
                
                st.markdown("**Lines with legacy references:**")
                all_lines = []
                for item in file_data['table_lines']:
                    all_lines.append({'Line': item['line'], 'Type': 'Table', 'Name': item['table'], 'Content': item['content']})
                for item in file_data['field_lines']:
                    all_lines.append({'Line': item['line'], 'Type': 'Field', 'Name': item['field'], 'Content': item['content']})
                
                if all_lines:
                    lines_df = pd.DataFrame(all_lines).sort_values('Line')
                    st.dataframe(lines_df, use_container_width=True, hide_index=True)
        else:
            st.info("No files found with legacy references.")
    
    # Service IDs Tab (tab6 when service_id_matches exist)
    if service_id_matches and tab6:
        with tab6:
            st.subheader("🔑 Service ID Occurrences")
            st.markdown("*Service IDs found in the scanned repository*")
            
            # Build Service ID summary
            service_id_summary = defaultdict(lambda: {'occurrences': 0, 'files': set(), 'details': []})
            for match in service_id_matches:
                sid = match['service_id']
                service_id_summary[sid]['occurrences'] += match['occurrences']
                service_id_summary[sid]['files'].add(match['file_path'])
                for detail in match['details']:
                    service_id_summary[sid]['details'].append({
                        'file': match['file_path'],
                        'line': detail['line_number'],
                        'content': detail['line_content']
                    })
            
            # Summary metrics
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Service IDs Searched", len(service_id_summary))
            with col2:
                st.metric("Total Occurrences", sum(s['occurrences'] for s in service_id_summary.values()))
            with col3:
                st.metric("Files with Service IDs", len(set(m['file_path'] for m in service_id_matches)))
            
            st.divider()
            
            # Summary table
            summary_data = []
            for sid, data in service_id_summary.items():
                summary_data.append({
                    'Service ID': sid,
                    'Occurrences': data['occurrences'],
                    'Files Count': len(data['files']),
                    'Files': ', '.join(sorted([os.path.basename(f) for f in data['files']]))
                })
            
            if summary_data:
                st.markdown("### Service ID Summary")
                summary_df = pd.DataFrame(summary_data)
                st.dataframe(summary_df, use_container_width=True, hide_index=True)
                
                # Detailed occurrences
                st.divider()
                st.markdown("### Detailed Occurrences")
                
                detail_data = []
                for match in service_id_matches:
                    for detail in match['details']:
                        detail_data.append({
                            'Service ID': match['service_id'],
                            'File': match['file_name'],
                            'Path': match['file_path'],
                            'Line': detail['line_number'],
                            'Content': detail['line_content']
                        })
                
                if detail_data:
                    detail_df = pd.DataFrame(detail_data)
                    
                    # Filter by Service ID
                    unique_sids = detail_df['Service ID'].unique()
                    selected_sids = st.multiselect("Filter by Service ID", options=unique_sids, key="service_id_filter")
                    
                    if selected_sids:
                        filtered_detail_df = detail_df[detail_df['Service ID'].isin(selected_sids)]
                    else:
                        filtered_detail_df = detail_df
                    
                    st.dataframe(filtered_detail_df, use_container_width=True, hide_index=True, height=400)
                    
                    csv = filtered_detail_df.to_csv(index=False)
                    st.download_button(
                        label="📥 Download Service ID Report as CSV",
                        data=csv,
                        file_name="service_id_occurrences.csv",
                        mime="text/csv"
                    )
    
    # Reports Tab (tab7 when service_id_matches exist, otherwise tab6)
    reports_tab = tab7 if service_id_matches else tab6
    with reports_tab:
        st.subheader("Download Reports")
        st.markdown("*Generate comprehensive reports with all analysis*")
        
        # Prepare data for HTML report
        scan_stats = {
            'tables_found': len([t for t in table_summary_data if t['Query Count'] > 0 or t['Occurrences'] > 0]) if table_summary_data else 0,
            'attrs_in_queries': sum(t['Attributes in Queries'] for t in table_summary_data) if table_summary_data else 0,
            'coverage': (sum(t['Attributes in Queries'] for t in table_summary_data) / sum(t['Attributes in Excel'] for t in table_summary_data) * 100) if table_summary_data and sum(t['Attributes in Excel'] for t in table_summary_data) > 0 else 0
        }
        
        total_queries = sum(t['Query Count'] for t in table_summary_data) if table_summary_data else 0
        
        # Generate HTML report
        html_report = generate_html_report(
            table_summary_data=table_summary_data,
            field_summary_data=attribute_details if 'attribute_details' in dir() else [],
            table_occurrences_data=table_occurrences_data if 'table_occurrences_data' in dir() else [],
            field_occurrences_data=field_occurrences_data if 'field_occurrences_data' in dir() else [],
            total_excel_tables=total_excel_tables,
            total_excel_fields=total_excel_fields,
            total_queries=total_queries,
            scan_stats=scan_stats,
            file_stats=file_stats
        )
        
        st.markdown("""
        ### How Scanning Works
        
        1. **Excel Parsing:** The mapping file is read to extract Legacy Table names (Column 1) and Legacy Attribute names (Column 2).
        
        2. **Query Detection:** Source files (.py, .pyspark, .sh, .hql, .hive) are scanned to find SQL-like queries (SELECT, INSERT, UPDATE, etc.).
        
        3. **Table Matching:** Each query is checked for Legacy Table references.
        
        4. **Attribute Matching:** For queries containing a Legacy Table, we scan for Attributes belonging to that table.
        
        5. **Context-Aware:** Attributes are only flagged when found within their parent table's query context.
        """)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.download_button(
                label="📥 Download HTML Report",
                data=html_report,
                file_name="code_lens_report.html",
                mime="text/html"
            )
        
        with col2:
            # Generate Excel report with multiple sheets
            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                # Overview sheet
                overview_data = {
                    'Metric': ['Total Tables in Excel', 'Total Fields in Excel', 'Tables Found', 'Total Queries', 'Attributes in Queries', 'Coverage %'],
                    'Value': [total_excel_tables, total_excel_fields, scan_stats.get('tables_found', 0), total_queries, scan_stats.get('attrs_in_queries', 0), f"{scan_stats.get('coverage', 0):.1f}%"]
                }
                pd.DataFrame(overview_data).to_excel(writer, sheet_name='Overview', index=False)
                
                # Table Summary sheet
                if table_summary_data:
                    pd.DataFrame(table_summary_data).to_excel(writer, sheet_name='Table Summary', index=False)
                
                # Attribute Details sheet
                if 'attribute_details' in dir() and attribute_details:
                    pd.DataFrame(attribute_details).to_excel(writer, sheet_name='Attribute Details', index=False)
                
                # Table Occurrences sheet
                if 'table_occurrences_data' in dir() and table_occurrences_data:
                    pd.DataFrame(table_occurrences_data).to_excel(writer, sheet_name='Table Occurrences', index=False)
                
                # Field Occurrences sheet
                if 'field_occurrences_data' in dir() and field_occurrences_data:
                    pd.DataFrame(field_occurrences_data).to_excel(writer, sheet_name='Field Occurrences', index=False)
                
                # Files to Correct sheet
                if 'files_to_correct' in dir() and files_to_correct:
                    pd.DataFrame(files_to_correct).to_excel(writer, sheet_name='Files to Correct', index=False)
                
                # Service IDs sheet (if available)
                if service_id_matches:
                    service_id_data = []
                    for match in service_id_matches:
                        for detail in match['details']:
                            service_id_data.append({
                                'Service ID': match['service_id'],
                                'File': match['file_name'],
                                'Path': match['file_path'],
                                'Line': detail['line_number'],
                                'Content': detail['line_content']
                            })
                    if service_id_data:
                        pd.DataFrame(service_id_data).to_excel(writer, sheet_name='Service IDs', index=False)
            
            excel_buffer.seek(0)
            st.download_button(
                label="📥 Download Excel Report",
                data=excel_buffer.getvalue(),
                file_name="code_lens_report.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )


# Main application
st.sidebar.header("📤 Upload Files")

# Excel file upload
excel_file = st.sidebar.file_uploader(
    "Upload Excel Mapping File",
    type=['xlsx', 'xls'],
    help="Excel file with Legacy Table names in Column 1 and Field names in Column 2. Each sheet can contain different table mappings."
)

# ZIP file upload
zip_file = st.sidebar.file_uploader(
    "Upload Source Code Repository (ZIP)",
    type=['zip'],
    help="ZIP file containing PySpark, Python, or Shell project source code."
)

# Service ID input
st.sidebar.markdown("---")
st.sidebar.subheader("🔑 Service ID Search (Optional)")
service_ids_input = st.sidebar.text_input(
    "Enter Service IDs",
    placeholder="e.g., SVC001, SVC002, API_KEY_123",
    help="Enter one or more Service IDs separated by commas. These will be searched in the codebase as API parameters, authentication tokens, or query identifiers."
)

# Scan button
if st.sidebar.button("🔍 Scan Repository", type="primary", use_container_width=True):
    if not excel_file:
        st.error("Please upload an Excel mapping file.")
    elif not zip_file:
        st.error("Please upload a ZIP file containing the source code repository.")
    else:
        # Parse Excel
        with st.spinner("Parsing Excel mappings..."):
            mappings, tables, fields, table_field_mapping, field_c360_mapping = parse_excel_mappings(excel_file)
        
        if mappings is None:
            st.stop()
        
        # Display Excel summary
        st.success(f"✅ Loaded {len(tables) if tables else 0} tables and {len(fields) if fields else 0} fields from {len(mappings)} sheets")
        
        # Clean up any previous temp_dir before creating new one
        if 'temp_dir' in st.session_state and st.session_state.temp_dir:
            if os.path.exists(st.session_state.temp_dir):
                shutil.rmtree(st.session_state.temp_dir, ignore_errors=True)
        
        # Extract and scan ZIP
        temp_dir = tempfile.mkdtemp()
        # Store temp_dir in session state for lineage scanner to use later
        st.session_state.temp_dir = temp_dir
        # Clear any previous lineage data
        st.session_state.lineage_graph = None
        st.session_state.scanned_lineage_files = None
        st.session_state.sql_blocks = None
        
        try:
            with st.spinner("Extracting ZIP file..."):
                if not extract_zip(zip_file, temp_dir):
                    st.stop()
            
            st.success("✅ ZIP file extracted successfully")
            
            # Scan repository
            with st.spinner("Scanning repository..."):
                matches, files_scanned, all_queries, file_stats = scan_repository(temp_dir, tables, fields, table_field_mapping)
            
            st.success(f"✅ Scanned {files_scanned} files, found {len(all_queries)} SQL queries")
            
            # Store scan results in session state for lineage feature
            st.session_state.scan_results = {
                'matches': matches,
                'files_scanned': files_scanned,
                'all_queries': all_queries,
                'file_stats': file_stats
            }
            
            # Scan for Service IDs if provided
            service_id_matches = []
            if service_ids_input:
                service_ids = [sid.strip() for sid in service_ids_input.split(',') if sid.strip()]
                if service_ids:
                    with st.spinner(f"Scanning for {len(service_ids)} Service IDs..."):
                        service_id_matches = scan_repository_for_service_ids(temp_dir, service_ids)
                    st.success(f"✅ Found {len(service_id_matches)} Service ID occurrences")
            
            # Display results
            st.header("📊 Scan Results")
            display_results(matches, mappings, len(tables) if tables else 0, len(fields) if fields else 0, field_c360_mapping, file_stats, service_id_matches)
            
            # Note: temp_dir is NOT cleaned up here so lineage feature can use it
            # It will be cleaned up on next scan or when session ends
            
        except Exception as e:
            st.error(f"Error during scan: {str(e)}")
            shutil.rmtree(temp_dir, ignore_errors=True)

# Instructions
if not excel_file or not zip_file:
    st.markdown("---")
    st.header("📖 How to Use Code Lens")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("1️⃣ Prepare Excel Mapping File")
        st.markdown("""
        Create an Excel file with the following structure:
        - **Column 1:** Legacy Table Name
        - **Column 2:** Legacy Attribute Name
        - **Column 3:** C360_Mapping (optional)
        - Each sheet can contain mappings for different tables
        - The first row is treated as headers
        """)
        
        st.markdown("**Expected Excel Format:**")
        example_data = pd.DataFrame({
            'Legacy_Table': ['CRPS', 'CRPS', 'MNS', 'MNS', 'Triumph'],
            'Legacy_Attribute': ['firstname', 'secondName', 'email', 'city', 'age'],
            'C360_Mapping': ['360firstname', 'c360SecondName', 'email360', 'city360', '360age'],
            'Mapping_in_C360': ['Yes', 'Yes', 'Yes', 'Yes', 'Yes']
        })
        st.dataframe(example_data, use_container_width=True, hide_index=True)
        
        st.markdown("**Example Sheet Structure:**")
        st.markdown("""
        - **Sheet 1 (CRPS):** Contains CRPS table fields
        - **Sheet 2 (MNS):** Contains MNS table fields
        - **Sheet 3 (Triumph):** Contains Triumph table fields
        - Each sheet = One Legacy Table with its attributes
        """)
    
    with col2:
        st.subheader("2️⃣ Prepare Source Code Repository")
        st.markdown("""
        Create a ZIP file of your source code:
        - Supports Python (`.py`), PySpark, Shell (`.sh`) files
        - Also scans SQL, Scala, Java, and config files
        - Nested directory structures are supported
        
        **Scanned file types:**
        `.py`, `.pyspark`, `.sh`, `.sql`, `.scala`, `.java`, `.conf`, `.cfg`, `.yaml`, `.yml`, `.json`, `.txt`
        """)
    
    st.markdown("---")
    st.subheader("3️⃣ Review Results")
    st.markdown("""
    After scanning, Code Lens will show:
    - **Summary by Table/Field:** All occurrences grouped by table or field name
    - **Summary by File:** All matches organized by source file
    - **Detailed Results:** Filterable table with line numbers and content
    - **Export:** Download results as CSV for further analysis
    """)

# ============== DATA LINEAGE & WORKFLOW SECTION ==============
st.markdown("---")
st.markdown("## 🔄 Data Lineage & Workflow Visualization")
st.markdown("*Scan your repository to extract table lineage, script dependencies, and generate visual diagrams*")

with st.expander("📊 Data Lineage Scanner", expanded=False):
    st.markdown("""
    This feature scans PySpark (.py) and SQL/HQL (.sql, .hql) files to:
    - Extract **data flow lineage** (which scripts read/write which tables)
    - Identify **script dependencies** (imports, orchestration calls)
    - Generate **visual diagrams** for architecture documentation
    """)
    
    # Lineage scanning uses the same ZIP file
    if 'scan_results' in st.session_state and st.session_state.scan_results:
        st.success("✅ Repository data available from legacy scan. Click 'Generate Lineage' to analyze.")
        
        if st.button("🔄 Generate Lineage Diagrams", key="gen_lineage"):
            with st.spinner("Extracting lineage from scanned files..."):
                # Use the temp directory from the scan
                if 'temp_dir' in st.session_state and os.path.exists(st.session_state.temp_dir):
                    scanned_files, sql_blocks = scan_folder_for_lineage(st.session_state.temp_dir)
                    
                    if scanned_files:
                        # Build the graph
                        lineage_graph = build_lineage_graph(scanned_files)
                        
                        # Store in session state
                        st.session_state.lineage_graph = lineage_graph
                        st.session_state.scanned_lineage_files = scanned_files
                        st.session_state.sql_blocks = sql_blocks
                        
                        st.success(f"✅ Lineage extracted from {len(scanned_files)} files with {lineage_graph.number_of_nodes()} nodes and {lineage_graph.number_of_edges()} edges")
                    else:
                        st.warning("No lineage data found in the repository.")
                else:
                    st.error("Please scan a repository first using the Legacy Scan section above.")
    else:
        st.info("👆 First upload and scan a repository in the Legacy Scan section above, then come back here to generate lineage diagrams.")
    
    # Display lineage results if available
    if 'lineage_graph' in st.session_state and st.session_state.lineage_graph:
        G = st.session_state.lineage_graph
        scanned_files = st.session_state.scanned_lineage_files
        sql_blocks = st.session_state.sql_blocks
        
        # Create tabs for different views
        lin_tab1, lin_tab2, lin_tab3, lin_tab4 = st.tabs(["📊 Overview", "🔀 Lineage Diagram", "🔗 Workflow Diagram", "📝 SQL Query Diagrams"])
        
        with lin_tab1:
            st.markdown("### Lineage Overview")
            
            # Summary metrics
            col1, col2, col3, col4 = st.columns(4)
            
            tables = [n for n, d in G.nodes(data=True) if d.get('type') == 'hive_table']
            paths = [n for n, d in G.nodes(data=True) if d.get('type') == 'file_path']
            scripts = [n for n, d in G.nodes(data=True) if d.get('type') == 'script']
            
            with col1:
                st.metric("Scripts", len(scripts))
            with col2:
                st.metric("Tables", len(tables))
            with col3:
                st.metric("File Paths", len(paths))
            with col4:
                st.metric("SQL Blocks", len(sql_blocks))
            
            st.divider()
            
            # Top tables by connections
            st.markdown("### Top Tables by Connections")
            table_connections = []
            for table in tables:
                in_deg = G.in_degree(table)
                out_deg = G.out_degree(table)
                table_connections.append({
                    'Table': table,
                    'Read By': in_deg,
                    'Written By': out_deg,
                    'Total': in_deg + out_deg
                })
            
            if table_connections:
                conn_df = pd.DataFrame(table_connections).sort_values('Total', ascending=False).head(20)
                st.dataframe(conn_df, use_container_width=True, hide_index=True)
            
            st.divider()
            
            # Scripts summary
            st.markdown("### Scripts with Lineage")
            script_summary = []
            for f in scanned_files:
                script_summary.append({
                    'Script': f['file_path'],
                    'Reads': len(f.get('sources', [])),
                    'Writes': len(f.get('targets', [])),
                    'Imports': len(f.get('imports', [])),
                    'SQL Blocks': len(f.get('sql_blocks', []))
                })
            
            if script_summary:
                script_df = pd.DataFrame(script_summary).sort_values('Reads', ascending=False)
                st.dataframe(script_df, use_container_width=True, hide_index=True, height=300)
            
            # Export options
            st.divider()
            st.markdown("### Export")
            
            # Export as JSON
            export_data = {
                'nodes': [{'id': n, **d} for n, d in G.nodes(data=True)],
                'edges': [{'from': u, 'to': v, **d} for u, v, d in G.edges(data=True)]
            }
            
            import json
            json_str = json.dumps(export_data, indent=2)
            st.download_button(
                label="📥 Download Lineage as JSON",
                data=json_str,
                file_name="lineage_graph.json",
                mime="application/json"
            )
        
        with lin_tab2:
            st.markdown("### Data Lineage Diagram")
            st.markdown("*Tables and file paths read/written by scripts*")
            
            # Filters
            col1, col2, col3 = st.columns(3)
            with col1:
                filter_keyword = st.text_input("Filter by keyword", key="lineage_filter", placeholder="e.g., staging, raw")
            with col2:
                center_node = st.selectbox("Center on node", options=[''] + list(G.nodes()), key="center_node")
            with col3:
                max_hops = st.slider("Max hops from center", 1, 5, 2, key="max_hops")
            
            # Generate DOT
            try:
                dot_string = generate_lineage_dot(
                    G, 
                    filter_keyword=filter_keyword if filter_keyword else None,
                    center_node=center_node if center_node else None,
                    max_hops=max_hops if center_node else None
                )
                
                st.graphviz_chart(dot_string, use_container_width=True)
                
                # Download DOT
                st.download_button(
                    label="📥 Download DOT file",
                    data=dot_string,
                    file_name="lineage.dot",
                    mime="text/plain"
                )
            except Exception as e:
                st.error(f"Error generating diagram: {str(e)}")
                st.text("DOT string for manual rendering:")
                st.code(dot_string, language="dot")
        
        with lin_tab3:
            st.markdown("### Workflow / Control Flow Diagram")
            st.markdown("*Script dependencies and orchestration*")
            
            include_tables = st.checkbox("Include tables in workflow", value=False, key="workflow_tables")
            
            try:
                net = generate_workflow_pyvis(G, include_tables=include_tables)
                
                # Save to temp file
                workflow_html = os.path.join(tempfile.gettempdir(), "workflow_graph.html")
                net.save_graph(workflow_html)
                
                # Read and display
                with open(workflow_html, 'r', encoding='utf-8') as f:
                    html_content = f.read()
                
                components.html(html_content, height=650, scrolling=True)
                
            except Exception as e:
                st.error(f"Error generating workflow diagram: {str(e)}")
        
        with lin_tab4:
            st.markdown("### SQL Query Diagrams")
            st.markdown("*Visual representation of individual SQL queries*")
            
            if sql_blocks:
                # Select a SQL block
                block_options = [f"{i+1}. {b.get('file', 'Unknown')} - {b.get('type', 'SQL')}" for i, b in enumerate(sql_blocks)]
                selected_block_idx = st.selectbox("Select SQL block", range(len(block_options)), format_func=lambda x: block_options[x], key="sql_block_select")
                
                if selected_block_idx is not None:
                    selected_block = sql_blocks[selected_block_idx]
                    
                    # Show SQL
                    st.markdown("**SQL:**")
                    st.code(selected_block.get('sql', '')[:1000], language="sql")
                    
                    # Generate diagram
                    try:
                        sql_dot = generate_sql_diagram(selected_block, selected_block_idx)
                        st.graphviz_chart(sql_dot, use_container_width=True)
                    except Exception as e:
                        st.error(f"Error generating SQL diagram: {str(e)}")
            else:
                st.info("No SQL blocks found in the scanned files.")
