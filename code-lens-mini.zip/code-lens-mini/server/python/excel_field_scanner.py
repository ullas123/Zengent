#!/usr/bin/env python3
"""
Excel Field Scanner for Demographic Data Detection
Scans source code files for exact matches of table.field combinations from Excel
Supports multi-sheet Excel files with 4-column format:
- Legacy-Table
- Column_or_Attr_name (may contain multiple comma-separated values)
- C360_Attribute
- Customer_Domain_or_Couchbase_Mapping_in_C360
"""

import sys
import json
import re
from pathlib import Path
from typing import List, Dict, Any, Tuple
import openpyxl

class ExcelFieldScanner:
    def __init__(self, excel_path: str):
        """Initialize scanner with Excel file path"""
        self.excel_path = excel_path
        self.field_mappings = []
        
    def parse_excel(self) -> List[Dict[str, str]]:
        """Parse Excel file and extract mappings from all sheets with 4-column format"""
        try:
            workbook = openpyxl.load_workbook(self.excel_path, read_only=True, data_only=True)
            all_mappings = []
            
            for sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]
                sheet_mappings = self._parse_sheet(sheet, sheet_name)
                all_mappings.extend(sheet_mappings)
            
            workbook.close()
            self.field_mappings = all_mappings
            return all_mappings
            
        except Exception as e:
            raise Exception(f"Error parsing Excel file: {str(e)}")
    
    def _parse_sheet(self, sheet, sheet_name: str) -> List[Dict[str, str]]:
        """Parse a single sheet and extract mappings"""
        mappings = []
        
        headers = []
        for cell in sheet[1]:
            headers.append(str(cell.value).strip() if cell.value else "")
        
        legacy_table_idx = None
        column_or_attr_idx = None
        c360_attr_idx = None
        customer_domain_idx = None
        
        table_col_idx = None
        field_col_idx = None
        
        for idx, header in enumerate(headers):
            header_lower = header.lower().strip().replace(' ', '_').replace('-', '_')
            
            if header_lower in ['legacy_table', 'legacytable', 'legacy-table']:
                legacy_table_idx = idx
            elif header_lower in ['column_or_attr_name', 'column_or_attr', 'columnorattr', 'column_or_attribute_name']:
                column_or_attr_idx = idx
            elif header_lower in ['c360_attribute', 'c360attribute', 'c360_attr']:
                c360_attr_idx = idx
            elif 'customer_domain' in header_lower or 'couchbase_mapping' in header_lower or header_lower.startswith('customer_domain'):
                customer_domain_idx = idx
            elif header_lower == 'table_name' or 'table' in header_lower:
                if table_col_idx is None:
                    table_col_idx = idx
            elif header_lower == 'field_name' or 'field' in header_lower:
                if field_col_idx is None:
                    field_col_idx = idx
        
        if legacy_table_idx is not None and column_or_attr_idx is not None:
            for row in sheet.iter_rows(min_row=2, values_only=True):
                if len(row) > max(legacy_table_idx, column_or_attr_idx):
                    legacy_table = self._clean_value(row[legacy_table_idx])
                    column_or_attr = self._clean_value(row[column_or_attr_idx])
                    c360_attr = self._clean_value(row[c360_attr_idx]) if c360_attr_idx is not None and len(row) > c360_attr_idx else ""
                    customer_domain = self._clean_value(row[customer_domain_idx]) if customer_domain_idx is not None and len(row) > customer_domain_idx else ""
                    
                    if legacy_table and column_or_attr:
                        field_names = self._split_field_names(column_or_attr)
                        
                        for field_name in field_names:
                            if field_name:
                                mappings.append({
                                    "tableName": legacy_table,
                                    "fieldName": field_name,
                                    "combined": f"{legacy_table}.{field_name}",
                                    "c360Attribute": c360_attr,
                                    "customerDomain": customer_domain,
                                    "sheetName": sheet_name,
                                    "originalColumnOrAttr": column_or_attr
                                })
        
        elif table_col_idx is not None and field_col_idx is not None:
            for row in sheet.iter_rows(min_row=2, values_only=True):
                if len(row) > max(table_col_idx, field_col_idx):
                    table_name = self._clean_value(row[table_col_idx])
                    field_name = self._clean_value(row[field_col_idx])
                    
                    if table_name and field_name:
                        mappings.append({
                            "tableName": table_name,
                            "fieldName": field_name,
                            "combined": f"{table_name}.{field_name}",
                            "c360Attribute": "",
                            "customerDomain": "",
                            "sheetName": sheet_name,
                            "originalColumnOrAttr": field_name
                        })
        
        return mappings
    
    def _clean_value(self, value) -> str:
        """Clean and normalize a cell value"""
        if value is None:
            return ""
        cleaned = str(value).strip()
        cleaned = ' '.join(cleaned.split())
        if cleaned.lower() == 'none':
            return ""
        return cleaned
    
    def _split_field_names(self, column_or_attr: str) -> List[str]:
        """Split Column_or_Attr_name which may contain multiple space-separated values"""
        if not column_or_attr:
            return []
        
        fields = column_or_attr.split()
        
        cleaned_fields = []
        for f in fields:
            cleaned = f.strip()
            if cleaned and cleaned.lower() != 'none':
                cleaned_fields.append(cleaned)
        
        return cleaned_fields
    
    def scan_source_files(self, source_files: List[Dict[str, str]]) -> Dict[str, Any]:
        """
        Scan source files for field names and table names separately
        
        Args:
            source_files: List of {relativePath, content} dictionaries
            
        Returns:
            Dictionary containing scan results with matches
        """
        results = {
            "totalFields": len(self.field_mappings),
            "matchedFields": 0,
            "matches": [],
            "unmatchedFields": [],
            "sheetSummary": {}
        }
        
        matched_fields = set()
        sheet_stats = {}
        
        for mapping in self.field_mappings:
            table_name = mapping["tableName"]
            field_name = mapping["fieldName"]
            combined = mapping["combined"]
            sheet_name = mapping.get("sheetName", "Sheet1")
            
            if sheet_name not in sheet_stats:
                sheet_stats[sheet_name] = {"total": 0, "matched": 0}
            sheet_stats[sheet_name]["total"] += 1
            
            field_matches = []
            table_matches = []
            
            for source_file in source_files:
                file_path = source_file["relativePath"]
                content = source_file["content"]
                
                field_found = self._find_field_name_matches(
                    content, 
                    field_name,
                    file_path
                )
                if field_found:
                    field_matches.extend(field_found)
                
                table_found = self._find_table_name_matches(
                    content,
                    table_name,
                    file_path
                )
                if table_found:
                    table_matches.extend(table_found)
            
            all_matches = field_matches + table_matches
            
            if all_matches:
                matched_fields.add(combined)
                sheet_stats[sheet_name]["matched"] += 1
                results["matches"].append({
                    "tableName": table_name,
                    "fieldName": field_name,
                    "combined": combined,
                    "matchCount": len(all_matches),
                    "locations": all_matches,
                    "fieldMatchCount": len(field_matches),
                    "tableMatchCount": len(table_matches),
                    "c360Attribute": mapping.get("c360Attribute", ""),
                    "customerDomain": mapping.get("customerDomain", ""),
                    "sheetName": sheet_name,
                    "originalColumnOrAttr": mapping.get("originalColumnOrAttr", "")
                })
            else:
                results["unmatchedFields"].append({
                    "tableName": table_name,
                    "fieldName": field_name,
                    "combined": combined,
                    "c360Attribute": mapping.get("c360Attribute", ""),
                    "customerDomain": mapping.get("customerDomain", ""),
                    "sheetName": sheet_name,
                    "originalColumnOrAttr": mapping.get("originalColumnOrAttr", "")
                })
        
        results["matchedFields"] = len(matched_fields)
        results["sheetSummary"] = sheet_stats
        return results
    
    def _find_field_name_matches(self, content: str, field_name: str, file_path: str) -> List[Dict[str, Any]]:
        """Find all matches of a field name in content (independent of table)"""
        matches = []
        lines = content.split('\n')
        file_ext = file_path.lower().split('.')[-1] if '.' in file_path else ''
        
        common_patterns = [
            rf'\b{re.escape(field_name)}\s*[:=]',
            rf'\.\s*{re.escape(field_name)}\b',
            rf'["\']{re.escape(field_name)}["\']',
            rf'\b{re.escape(field_name)}\b',
        ]
        
        java_kotlin_patterns = [
            rf'\b(private|public|protected|static|final|var|val)\s+\w+\s+{re.escape(field_name)}\b',
            rf'\b(get|set){re.escape(field_name[0].upper() + field_name[1:] if field_name else "")}\s*\(',
            rf'@Column\s*\(\s*name\s*=\s*["\']{re.escape(field_name)}["\']',
            rf'@Field\s*\(\s*["\']{re.escape(field_name)}["\']',
            rf'@JsonProperty\s*\(\s*["\']{re.escape(field_name)}["\']',
            rf'@SerializedName\s*\(\s*["\']{re.escape(field_name)}["\']',
            rf'\.get\s*\(\s*["\']{re.escape(field_name)}["\']\s*\)',
            rf'\.put\s*\(\s*["\']{re.escape(field_name)}["\']\s*,',
            rf'\.getString\s*\(\s*["\']{re.escape(field_name)}["\']\s*\)',
            rf'\.getInt\s*\(\s*["\']{re.escape(field_name)}["\']\s*\)',
        ]
        
        python_patterns = [
            rf'\[\s*["\']{re.escape(field_name)}["\']\s*\]',
            rf'\.get\s*\(\s*["\']{re.escape(field_name)}["\']',
            rf'{re.escape(field_name)}\s*=',
            rf'self\.{re.escape(field_name)}\b',
            rf'cls\.{re.escape(field_name)}\b',
            rf'@property.*{re.escape(field_name)}',
            rf'def\s+{re.escape(field_name)}\s*\(',
        ]
        
        pyspark_patterns = [
            rf'col\s*\(\s*["\']{re.escape(field_name)}["\']\s*\)',
            rf'F\.col\s*\(\s*["\']{re.escape(field_name)}["\']\s*\)',
            rf'\.select\s*\([^)]*["\']{re.escape(field_name)}["\']',
            rf'\.withColumn\s*\(\s*["\']{re.escape(field_name)}["\']',
            rf'\.withColumnRenamed\s*\([^,]+,\s*["\']{re.escape(field_name)}["\']',
            rf'\.drop\s*\(\s*["\']{re.escape(field_name)}["\']',
            rf'\.filter\s*\([^)]*["\']{re.escape(field_name)}["\']',
            rf'\.where\s*\([^)]*["\']{re.escape(field_name)}["\']',
            rf'\.groupBy\s*\([^)]*["\']{re.escape(field_name)}["\']',
            rf'\.orderBy\s*\([^)]*["\']{re.escape(field_name)}["\']',
            rf'\.agg\s*\([^)]*["\']{re.escape(field_name)}["\']',
            rf'\.alias\s*\(\s*["\']{re.escape(field_name)}["\']',
            rf'df\[["\']{re.escape(field_name)}["\']\]',
            rf'spark\.sql\s*\([^)]*{re.escape(field_name)}[^)]*\)',
        ]
        
        csharp_patterns = [
            rf'\b(private|public|protected|internal|static|readonly)\s+\w+\s+{re.escape(field_name)}\b',
            rf'\b(get|set)\s*;\s*}}.*{re.escape(field_name)}',
            rf'\[Column\s*\(\s*["\']{re.escape(field_name)}["\']\s*\)\]',
            rf'\[JsonProperty\s*\(\s*["\']{re.escape(field_name)}["\']\s*\)\]',
            rf'\[DataMember\s*\(\s*Name\s*=\s*["\']{re.escape(field_name)}["\']\s*\)\]',
            rf'nameof\s*\(\s*{re.escape(field_name)}\s*\)',
            rf'\.{re.escape(field_name)}\s*{{',
        ]
        
        sql_patterns = [
            rf'SELECT\s+[^;]*\b{re.escape(field_name)}\b',
            rf'WHERE\s+[^;]*\b{re.escape(field_name)}\b',
            rf'SET\s+{re.escape(field_name)}\s*=',
            rf'ORDER\s+BY\s+[^;]*\b{re.escape(field_name)}\b',
            rf'GROUP\s+BY\s+[^;]*\b{re.escape(field_name)}\b',
            rf'HAVING\s+[^;]*\b{re.escape(field_name)}\b',
            rf'AS\s+{re.escape(field_name)}\b',
            rf'INSERT\s+INTO\s+\w+\s*\([^)]*\b{re.escape(field_name)}\b',
        ]
        
        patterns = common_patterns + sql_patterns
        
        if file_ext in ['java', 'kt', 'kts']:
            patterns = java_kotlin_patterns + patterns
        elif file_ext in ['py']:
            patterns = python_patterns + pyspark_patterns + patterns
        elif file_ext in ['cs']:
            patterns = csharp_patterns + patterns
        elif file_ext in ['scala']:
            patterns = java_kotlin_patterns + pyspark_patterns + patterns
        else:
            patterns = java_kotlin_patterns + python_patterns + pyspark_patterns + csharp_patterns + patterns
        
        for line_num, line in enumerate(lines, 1):
            for pattern in patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    start_line = max(0, line_num - 2)
                    end_line = min(len(lines), line_num + 2)
                    context = '\n'.join(lines[start_line:end_line])
                    
                    matches.append({
                        "filePath": file_path,
                        "lineNumber": line_num,
                        "line": line.strip(),
                        "context": context,
                        "matchType": "field_name"
                    })
                    break
        
        return matches
    
    def _find_table_name_matches(self, content: str, table_name: str, file_path: str) -> List[Dict[str, Any]]:
        """Find all matches of a table name in SQL and code contexts"""
        matches = []
        lines = content.split('\n')
        file_ext = file_path.lower().split('.')[-1] if '.' in file_path else ''
        
        sql_patterns = [
            rf'CREATE\s+TABLE\s+(IF\s+NOT\s+EXISTS\s+)?["\']?{re.escape(table_name)}["\']?\b',
            rf'FROM\s+["\']?{re.escape(table_name)}["\']?\b',
            rf'JOIN\s+["\']?{re.escape(table_name)}["\']?\b',
            rf'INTO\s+["\']?{re.escape(table_name)}["\']?\b',
            rf'UPDATE\s+["\']?{re.escape(table_name)}["\']?\b',
            rf'DROP\s+TABLE\s+(IF\s+EXISTS\s+)?["\']?{re.escape(table_name)}["\']?\b',
            rf'ALTER\s+TABLE\s+["\']?{re.escape(table_name)}["\']?\b',
            rf'TRUNCATE\s+TABLE\s+["\']?{re.escape(table_name)}["\']?\b',
            rf'DELETE\s+FROM\s+["\']?{re.escape(table_name)}["\']?\b',
        ]
        
        java_kotlin_patterns = [
            rf'@Table\s*\(\s*name\s*=\s*["\']{re.escape(table_name)}["\']',
            rf'@Entity\s*\(\s*name\s*=\s*["\']{re.escape(table_name)}["\']',
            rf'class\s+{re.escape(table_name)}\b',
            rf'interface\s+{re.escape(table_name)}\b',
            rf'extends\s+{re.escape(table_name)}\b',
            rf'implements\s+{re.escape(table_name)}\b',
            rf'new\s+{re.escape(table_name)}\s*\(',
            rf'@Repository.*{re.escape(table_name)}',
        ]
        
        python_pyspark_patterns = [
            rf'class\s+{re.escape(table_name)}\s*[:\(]',
            rf'spark\.read\.[^)]*["\']{re.escape(table_name)}["\']',
            rf'spark\.table\s*\(\s*["\']{re.escape(table_name)}["\']',
            rf'\.write\.[^)]*["\']{re.escape(table_name)}["\']',
            rf'\.saveAsTable\s*\(\s*["\']{re.escape(table_name)}["\']',
            rf'\.insertInto\s*\(\s*["\']{re.escape(table_name)}["\']',
            rf'spark\.sql\s*\([^)]*{re.escape(table_name)}[^)]*\)',
            rf'createOrReplaceTempView\s*\(\s*["\']{re.escape(table_name)}["\']',
            rf'registerTempTable\s*\(\s*["\']{re.escape(table_name)}["\']',
            rf'pd\.read_sql.*["\']{re.escape(table_name)}["\']',
            rf'\.to_sql\s*\(\s*["\']{re.escape(table_name)}["\']',
            rf'{re.escape(table_name)}\s*=\s*spark\.',
            rf'{re.escape(table_name)}_df\b',
            rf'df_{re.escape(table_name)}\b',
        ]
        
        csharp_patterns = [
            rf'\[Table\s*\(\s*["\']{re.escape(table_name)}["\']\s*\)\]',
            rf'class\s+{re.escape(table_name)}\s*[:\{{]',
            rf'DbSet<{re.escape(table_name)}>',
            rf'IQueryable<{re.escape(table_name)}>',
            rf'IEnumerable<{re.escape(table_name)}>',
            rf'List<{re.escape(table_name)}>',
            rf'new\s+{re.escape(table_name)}\s*\(',
        ]
        
        common_patterns = [
            rf'["\']{re.escape(table_name)}["\']',
            rf'\b{re.escape(table_name)}\b',
        ]
        
        patterns = sql_patterns + common_patterns
        
        if file_ext in ['java', 'kt', 'kts']:
            patterns = java_kotlin_patterns + patterns
        elif file_ext in ['py']:
            patterns = python_pyspark_patterns + patterns
        elif file_ext in ['cs']:
            patterns = csharp_patterns + patterns
        elif file_ext in ['scala']:
            patterns = java_kotlin_patterns + python_pyspark_patterns + patterns
        else:
            patterns = java_kotlin_patterns + python_pyspark_patterns + csharp_patterns + patterns
        
        for line_num, line in enumerate(lines, 1):
            for pattern in patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    start_line = max(0, line_num - 2)
                    end_line = min(len(lines), line_num + 2)
                    context = '\n'.join(lines[start_line:end_line])
                    
                    matches.append({
                        "filePath": file_path,
                        "lineNumber": line_num,
                        "line": line.strip(),
                        "context": context,
                        "matchType": "table_name"
                    })
                    break
        
        return matches


def main():
    """Main entry point for CLI usage"""
    if len(sys.argv) < 3:
        print(json.dumps({
            "error": "Usage: python excel_field_scanner.py <excel_file> <source_files_json_path>"
        }))
        sys.exit(1)
    
    excel_path = sys.argv[1]
    source_files_path = sys.argv[2]
    
    try:
        with open(source_files_path, 'r', encoding='utf-8') as f:
            source_files = json.load(f)
        
        scanner = ExcelFieldScanner(excel_path)
        
        mappings = scanner.parse_excel()
        
        results = scanner.scan_source_files(source_files)
        
        output = {
            "success": True,
            "mappings": mappings,
            "results": results
        }
        
        print(json.dumps(output, indent=2))
        
    except Exception as e:
        print(json.dumps({
            "success": False,
            "error": str(e)
        }))
        sys.exit(1)

if __name__ == "__main__":
    main()
