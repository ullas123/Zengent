import { Router, Request, Response } from 'express';
import { langchainService } from '../services/langchainWrapper';

const router = Router();

router.get('/status', async (req: Request, res: Response) => {
  try {
    const [langchainStatus, langgraphStatus] = await Promise.all([
      langchainService.getLangChainStatus(),
      langchainService.getLangGraphStatus()
    ]);

    res.json({
      langchain: langchainStatus,
      langgraph: langgraphStatus,
      overall: {
        ready: langchainStatus.service_ready || langgraphStatus.service_ready,
        message: langchainStatus.service_ready 
          ? 'LangChain and LangGraph services are ready'
          : 'Services require OpenAI API key and dependencies'
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error instanceof Error ? error.message : 'Failed to get status'
    });
  }
});

router.post('/analyze', async (req: Request, res: Response) => {
  try {
    const { code, question } = req.body;

    if (!code) {
      return res.status(400).json({
        status: 'error',
        message: 'Code content is required'
      });
    }

    const result = await langchainService.analyzeArchitecture(code, question);
    res.json(result);
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error instanceof Error ? error.message : 'Analysis failed'
    });
  }
});

router.post('/explain', async (req: Request, res: Response) => {
  try {
    const { code, language } = req.body;

    if (!code) {
      return res.status(400).json({
        status: 'error',
        message: 'Code content is required'
      });
    }

    const result = await langchainService.explainCode(code, language || 'auto');
    res.json(result);
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error instanceof Error ? error.message : 'Explanation failed'
    });
  }
});

router.post('/patterns', async (req: Request, res: Response) => {
  try {
    const { code } = req.body;

    if (!code) {
      return res.status(400).json({
        status: 'error',
        message: 'Code content is required'
      });
    }

    const result = await langchainService.detectPatterns(code);
    res.json(result);
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error instanceof Error ? error.message : 'Pattern detection failed'
    });
  }
});

router.post('/migrate', async (req: Request, res: Response) => {
  try {
    const { code, targetTech } = req.body;

    if (!code) {
      return res.status(400).json({
        status: 'error',
        message: 'Code content is required'
      });
    }

    const result = await langchainService.generateMigrationPlan(code, targetTech || 'Spring Boot 3');
    res.json(result);
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error instanceof Error ? error.message : 'Migration planning failed'
    });
  }
});

router.post('/workflow/full', async (req: Request, res: Response) => {
  try {
    const { code, projectName } = req.body;

    if (!code) {
      return res.status(400).json({
        status: 'error',
        message: 'Code content is required'
      });
    }

    const result = await langchainService.runFullAnalysis(code, projectName || 'Unknown');
    res.json(result);
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error instanceof Error ? error.message : 'Full workflow failed'
    });
  }
});

router.post('/workflow/quick', async (req: Request, res: Response) => {
  try {
    const { code } = req.body;

    if (!code) {
      return res.status(400).json({
        status: 'error',
        message: 'Code content is required'
      });
    }

    const result = await langchainService.runQuickAnalysis(code);
    res.json(result);
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error instanceof Error ? error.message : 'Quick analysis failed'
    });
  }
});

export default router;
