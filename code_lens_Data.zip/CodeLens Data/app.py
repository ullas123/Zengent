import streamlit as st
import pandas as pd
import zipfile
import os
import re
import tempfile
import shutil
import ast
import json
import yaml
from io import BytesIO
from collections import defaultdict
from datetime import datetime
import networkx as nx
import sqlparse
from pyvis.network import Network
import streamlit.components.v1 as components

st.set_page_config(
    page_title="Code Lens- Data Imaging",
    page_icon="🔍",
    layout="wide"
)

st.title("🔍 Code Lens- Data Imaging")
st.markdown("**Scan source code repositories to identify legacy table and field references**")

with st.expander("📄 DOT to PNG Conversion Commands"):
    tab_mac, tab_win = st.tabs(["macOS / Linux", "Windows"])
    with tab_mac:
        st.markdown("""
**Install Graphviz** (if not already installed):
```bash
brew install graphviz          # macOS (Homebrew)
sudo apt-get install graphviz  # Ubuntu/Debian
```

**Convert a single DOT file to PNG:**
```bash
dot -Tpng lineage_diagram.dot -o lineage_diagram.png
```

**Convert with higher resolution (300 DPI):**
```bash
dot -Tpng -Gdpi=300 lineage_diagram.dot -o lineage_diagram.png
```

**Convert all DOT files in a folder:**
```bash
for file in *.dot; do dot -Tpng "$file" -o "${file%.dot}.png"; done
```

**Other output formats:**
```bash
dot -Tsvg lineage_diagram.dot -o lineage_diagram.svg   # SVG
dot -Tpdf lineage_diagram.dot -o lineage_diagram.pdf   # PDF
dot -Tjpg lineage_diagram.dot -o lineage_diagram.jpg   # JPEG
```
""")
    with tab_win:
        st.markdown("""
**Install Graphviz** (if not already installed):
```
choco install graphviz         # Using Chocolatey
winget install graphviz        # Using WinGet
```
Or download the installer from [graphviz.org/download](https://graphviz.org/download/) and add it to your PATH.

**Convert a single DOT file to PNG:**
```
dot -Tpng lineage_diagram.dot -o lineage_diagram.png
```

**Convert with higher resolution (300 DPI):**
```
dot -Tpng -Gdpi=300 lineage_diagram.dot -o lineage_diagram.png
```

**Convert all DOT files in a folder (PowerShell):**
```powershell
Get-ChildItem *.dot | ForEach-Object { dot -Tpng $_.FullName -o ($_.BaseName + ".png") }
```

**Convert all DOT files in a folder (Command Prompt):**
```cmd
for %f in (*.dot) do dot -Tpng "%f" -o "%~nf.png"
```

**Other output formats:**
```
dot -Tsvg lineage_diagram.dot -o lineage_diagram.svg   # SVG
dot -Tpdf lineage_diagram.dot -o lineage_diagram.pdf   # PDF
dot -Tjpg lineage_diagram.dot -o lineage_diagram.jpg   # JPEG
```
""")

# Supported file extensions for scanning
SUPPORTED_EXTENSIONS = {'.py', '.pyspark', '.sh', '.sql', '.scala', '.java', '.conf', '.cfg', '.yaml', '.yml', '.json', '.txt', '.hql', '.hive'}

# Target file types for legacy scanning
TARGET_EXTENSIONS = ['.py', '.pyspark', '.sh', '.hql', '.hive']

# Folders to ignore when scanning for lineage
IGNORE_FOLDERS = {'.git', '__pycache__', '.venv', 'venv', 'node_modules', 'dist', 'build', '.pytest_cache'}

# Extensions relevant for lineage scanning
SCAN_EXTENSIONS = {'.py', '.pyspark', '.sh', '.sql', '.hql', '.hive', '.scala', '.java', '.conf', '.cfg', '.yaml', '.yml', '.json', '.txt'}

# Config file extensions for alias/variable scanning
CONFIG_EXTENSIONS = {'.conf', '.cfg', '.env', '.properties', '.ini', '.yaml', '.yml', '.json', '.sh', '.bash', '.ksh', '.zsh', '.profile'}

# ============== CONFIG FILE SCANNING FUNCTIONS ==============

def get_config_files(directory):
    """Get all config files from directory recursively."""
    files = []
    for root, dirs, filenames in os.walk(directory):
        dirs[:] = [d for d in dirs if not d.startswith('.') and d not in {'__pycache__', 'node_modules', '.git', 'venv', 'env'}]
        for filename in filenames:
            ext = os.path.splitext(filename)[1].lower()
            if ext in CONFIG_EXTENSIONS or filename.startswith('.env'):
                files.append(os.path.join(root, filename))
    return files


def extract_kv_pairs_from_text(content, file_path):
    """Extract key=value pairs from shell-style config files (.conf, .cfg, .env, .properties, .ini, .sh)."""
    pairs = []
    lines = content.split('\n')
    for line_num, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith('#') or stripped.startswith(';') or stripped.startswith('//'):
            continue
        if stripped.startswith('['):
            continue
        
        match = re.match(r'^(?:export\s+|set\s+|declare\s+(?:-[a-zA-Z]+\s+)?)?([A-Za-z_][A-Za-z0-9_.]*)\s*[=:]\s*["\']?([^"\'#;\n]+?)["\']?\s*(?:#.*)?$', stripped)
        if match:
            key = match.group(1).strip()
            value = match.group(2).strip()
            if value:
                pairs.append({
                    'key': key,
                    'value': value,
                    'line_number': line_num,
                    'line_content': stripped
                })
        else:
            match2 = re.match(r'^(?:export\s+|set\s+|declare\s+(?:-[a-zA-Z]+\s+)?)?([A-Za-z_][A-Za-z0-9_.]*)\s*[=:]\s*"([^"]*)"', stripped)
            if not match2:
                match2 = re.match(r"^(?:export\s+|set\s+|declare\s+(?:-[a-zA-Z]+\s+)?)?([A-Za-z_][A-Za-z0-9_.]*)\s*[=:]\s*'([^']*)'", stripped)
            if match2:
                key = match2.group(1).strip()
                value = match2.group(2).strip()
                if value:
                    pairs.append({
                        'key': key,
                        'value': value,
                        'line_number': line_num,
                        'line_content': stripped
                    })
    return pairs


def extract_kv_pairs_from_yaml(content, file_path):
    """Extract key-value pairs from YAML files by flattening nested structures."""
    pairs = []
    try:
        data = yaml.safe_load(content)
        if isinstance(data, dict):
            _flatten_dict(data, '', pairs)
    except Exception:
        pass
    return pairs


def _flatten_dict(d, prefix, pairs):
    """Recursively flatten a dict into key-value pairs."""
    for key, value in d.items():
        full_key = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(value, dict):
            _flatten_dict(value, full_key, pairs)
        elif isinstance(value, list):
            for i, item in enumerate(value):
                if isinstance(item, dict):
                    _flatten_dict(item, f"{full_key}[{i}]", pairs)
                elif isinstance(item, str):
                    pairs.append({'key': f"{full_key}[{i}]", 'value': item, 'line_number': 0, 'line_content': f"{full_key}[{i}]: {item}"})
        elif isinstance(value, str):
            pairs.append({'key': full_key, 'value': value, 'line_number': 0, 'line_content': f"{full_key}: {value}"})


def extract_kv_pairs_from_json(content, file_path):
    """Extract key-value pairs from JSON files by flattening nested structures."""
    pairs = []
    try:
        data = json.loads(content)
        if isinstance(data, dict):
            _flatten_dict(data, '', pairs)
    except Exception:
        pass
    return pairs


def scan_config_files(temp_dir, tables):
    """
    Scan config files for legacy table name references and extract alias/variable mappings.
    Returns:
        config_matches: list of dicts with config file occurrences of legacy tables
        alias_map: dict mapping alias_name -> {'table': legacy_table, 'file': path, 'line': num, 'variable': var_name}
    """
    config_files = get_config_files(temp_dir)
    config_matches = []
    alias_map = {}
    
    tables_lower = {t.lower(): t for t in tables}
    
    for cfg_path in config_files:
        try:
            with open(cfg_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except Exception:
            continue
        
        relative_path = os.path.relpath(cfg_path, temp_dir)
        filename = os.path.basename(cfg_path)
        ext = os.path.splitext(filename)[1].lower()
        
        kv_pairs = []
        if ext in ('.yaml', '.yml'):
            kv_pairs = extract_kv_pairs_from_yaml(content, cfg_path)
        elif ext == '.json':
            kv_pairs = extract_kv_pairs_from_json(content, cfg_path)
        else:
            kv_pairs = extract_kv_pairs_from_text(content, cfg_path)
        
        for pair in kv_pairs:
            value_lower = pair['value'].lower().strip()
            for tbl_lower, tbl_original in tables_lower.items():
                value_match = (
                    tbl_lower == value_lower or
                    tbl_lower in value_lower.split('.') or
                    re.search(r'(?:^|[\s/,;:=\'"()\[\]])' + re.escape(tbl_lower) + r'(?:$|[\s/,;:=\'"()\[\]])', value_lower)
                )
                if value_match:
                    config_matches.append({
                        'table_name': tbl_original,
                        'variable_name': pair['key'],
                        'value': pair['value'],
                        'file_name': filename,
                        'file_path': relative_path,
                        'line_number': pair['line_number'],
                        'line_content': pair['line_content']
                    })
                    
                    var_name = pair['key'].split('.')[-1] if '.' in pair['key'] else pair['key']
                    if var_name.lower() != tbl_lower and len(var_name) >= 3:
                        alias_map[var_name] = {
                            'table': tbl_original,
                            'file': relative_path,
                            'line': pair['line_number'],
                            'variable': pair['key'],
                            'value': pair['value']
                        }
        
        lines = content.split('\n')
        for line_num, line in enumerate(lines, 1):
            line_lower = line.lower()
            for tbl_lower, tbl_original in tables_lower.items():
                if tbl_lower in line_lower:
                    already_matched = any(
                        m['file_path'] == relative_path and m['line_number'] == line_num and m['table_name'] == tbl_original
                        for m in config_matches
                    )
                    if not already_matched:
                        pattern = re.compile(r'(?:^|[\s\'"=,:(\[])' + re.escape(tbl_original) + r'(?:$|[\s\'"=,:)\]])', re.IGNORECASE)
                        if pattern.search(' ' + line + ' '):
                            config_matches.append({
                                'table_name': tbl_original,
                                'variable_name': '',
                                'value': '',
                                'file_name': filename,
                                'file_path': relative_path,
                                'line_number': line_num,
                                'line_content': line.strip()[:200]
                            })
    
    return config_matches, alias_map


# ============== LINEAGE EXTRACTION FUNCTIONS ==============

def extract_sql_lineage(sql_content, file_path):
    """
    Extract table lineage from SQL/HQL content.
    Returns targets (tables written to) and sources (tables read from).
    """
    targets = []
    sources = []
    sql_blocks = []
    
    # Normalize content
    content = sql_content.upper()
    content_original = sql_content
    
    # Extract target tables (WRITE operations)
    # INSERT INTO / INSERT OVERWRITE
    insert_pattern = r'INSERT\s+(?:INTO|OVERWRITE)\s+(?:TABLE\s+)?([a-zA-Z_][a-zA-Z0-9_]*\.?[a-zA-Z0-9_]*)'
    for match in re.finditer(insert_pattern, sql_content, re.IGNORECASE):
        table = match.group(1).strip()
        if table and '.' in table or len(table) > 2:
            targets.append({'table': table, 'operation': 'INSERT', 'confidence': 'regex'})
    
    # CREATE TABLE AS SELECT (CTAS)
    ctas_pattern = r'CREATE\s+(?:EXTERNAL\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([a-zA-Z_][a-zA-Z0-9_]*\.?[a-zA-Z0-9_]*)\s+AS\s+SELECT'
    for match in re.finditer(ctas_pattern, sql_content, re.IGNORECASE):
        table = match.group(1).strip()
        if table:
            targets.append({'table': table, 'operation': 'CTAS', 'confidence': 'regex'})
    
    # CREATE VIEW AS SELECT
    view_pattern = r'CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+([a-zA-Z_][a-zA-Z0-9_]*\.?[a-zA-Z0-9_]*)\s+AS\s+SELECT'
    for match in re.finditer(view_pattern, sql_content, re.IGNORECASE):
        view = match.group(1).strip()
        if view:
            targets.append({'table': view, 'operation': 'CREATE_VIEW', 'confidence': 'regex'})
    
    # Extract source tables (READ operations)
    # FROM clause
    from_pattern = r'\bFROM\s+([a-zA-Z_][a-zA-Z0-9_]*\.?[a-zA-Z0-9_]*)'
    for match in re.finditer(from_pattern, sql_content, re.IGNORECASE):
        table = match.group(1).strip()
        # Exclude SQL keywords that might follow FROM
        if table.upper() not in ['SELECT', 'WHERE', 'GROUP', 'ORDER', 'LIMIT', 'UNION', 'HAVING', 'SET']:
            if table and (('.' in table) or len(table) > 2):
                sources.append({'table': table, 'operation': 'FROM', 'confidence': 'regex'})
    
    # JOIN clause
    join_pattern = r'\bJOIN\s+([a-zA-Z_][a-zA-Z0-9_]*\.?[a-zA-Z0-9_]*)'
    for match in re.finditer(join_pattern, sql_content, re.IGNORECASE):
        table = match.group(1).strip()
        if table.upper() not in ['ON', 'WHERE', 'AND', 'OR']:
            if table and (('.' in table) or len(table) > 2):
                sources.append({'table': table, 'operation': 'JOIN', 'confidence': 'regex'})
    
    # Extract file paths (LOCATION)
    location_pattern = r"LOCATION\s+['\"]([^'\"]+)['\"]"
    for match in re.finditer(location_pattern, sql_content, re.IGNORECASE):
        path = match.group(1).strip()
        sources.append({'table': path, 'operation': 'LOCATION', 'confidence': 'regex', 'is_path': True})
    
    # Build SQL blocks for diagram with per-block sources/targets
    try:
        parsed = sqlparse.parse(sql_content)
        for stmt in parsed:
            stmt_str = str(stmt).strip()
            if stmt_str and len(stmt_str) > 10:
                block_targets = []
                block_sources = []
                for m in re.finditer(r'INSERT\s+(?:INTO|OVERWRITE)\s+(?:TABLE\s+)?([a-zA-Z_]\w*\.?\w*)', stmt_str, re.IGNORECASE):
                    t = m.group(1).strip()
                    if t and (('.' in t) or len(t) > 2):
                        block_targets.append(t)
                for m in re.finditer(r'CREATE\s+(?:EXTERNAL\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([a-zA-Z_]\w*\.?\w*)\s+AS\s+SELECT', stmt_str, re.IGNORECASE):
                    t = m.group(1).strip()
                    if t:
                        block_targets.append(t)
                for m in re.finditer(r'CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+([a-zA-Z_]\w*\.?\w*)\s+AS\s+SELECT', stmt_str, re.IGNORECASE):
                    t = m.group(1).strip()
                    if t:
                        block_targets.append(t)
                for m in re.finditer(r"LOCATION\s+['\"]([^'\"]+)['\"]", stmt_str, re.IGNORECASE):
                    block_sources.append(m.group(1).strip())
                for m in re.finditer(r'\bFROM\s+([a-zA-Z_]\w*\.?\w*)', stmt_str, re.IGNORECASE):
                    t = m.group(1).strip()
                    if t.upper() not in ('SELECT','WHERE','GROUP','ORDER','LIMIT','UNION','HAVING','SET') and (('.' in t) or len(t) > 2):
                        block_sources.append(t)
                for m in re.finditer(r'\bJOIN\s+([a-zA-Z_]\w*\.?\w*)', stmt_str, re.IGNORECASE):
                    t = m.group(1).strip()
                    if t.upper() not in ('ON','WHERE','AND','OR') and (('.' in t) or len(t) > 2):
                        block_sources.append(t)
                sql_blocks.append({
                    'sql': stmt_str[:500],
                    'type': stmt.get_type() or 'UNKNOWN',
                    'sources': list(dict.fromkeys(block_sources)),
                    'targets': list(dict.fromkeys(block_targets))
                })
    except:
        pass
    
    return targets, sources, sql_blocks


def extract_pyspark_lineage(py_content, file_path):
    """
    Extract table lineage from PySpark Python files.
    Returns targets, sources, imports, and orchestration calls.
    """
    targets = []
    sources = []
    imports = []
    orchestration = []
    sql_blocks = []
    
    # Extract spark.sql() blocks and parse them
    spark_sql_pattern = r'spark\.sql\s*\(\s*(?:"""|\'\'\')(.*?)(?:"""|\'\'\')\s*\)|spark\.sql\s*\(\s*["\'](.+?)["\']\s*\)'
    for match in re.finditer(spark_sql_pattern, py_content, re.DOTALL):
        sql_text = match.group(1) or match.group(2)
        if sql_text:
            sql_targets, sql_sources, blocks = extract_sql_lineage(sql_text, file_path)
            targets.extend(sql_targets)
            sources.extend(sql_sources)
            block_srcs = [s['table'] for s in sql_sources]
            block_tgts = [t['table'] for t in sql_targets]
            sql_blocks.append({'sql': sql_text[:500], 'type': 'spark.sql()', 'sources': block_srcs, 'targets': block_tgts})
    
    # spark.table() / spark.read.table()
    table_read_pattern = r'spark\.(?:read\.)?table\s*\(\s*["\']([^"\']+)["\']\s*\)'
    for match in re.finditer(table_read_pattern, py_content):
        table = match.group(1).strip()
        sources.append({'table': table, 'operation': 'spark.table', 'confidence': 'regex'})
    
    # spark.read.parquet/csv/json/orc("path")
    read_path_pattern = r'spark\.read\.(?:parquet|csv|json|orc|text)\s*\(\s*["\']([^"\']+)["\']\s*\)'
    for match in re.finditer(read_path_pattern, py_content):
        path = match.group(1).strip()
        sources.append({'table': path, 'operation': 'spark.read', 'confidence': 'regex', 'is_path': True})
    
    # .saveAsTable() / .insertInto()
    save_table_pattern = r'\.(?:saveAsTable|insertInto)\s*\(\s*["\']([^"\']+)["\']\s*\)'
    for match in re.finditer(save_table_pattern, py_content):
        table = match.group(1).strip()
        targets.append({'table': table, 'operation': 'saveAsTable', 'confidence': 'regex'})
    
    # .write.save("path") / .save("path")
    write_path_pattern = r'\.write(?:\.[a-zA-Z]+\([^)]*\))*\.save\s*\(\s*["\']([^"\']+)["\']\s*\)'
    for match in re.finditer(write_path_pattern, py_content):
        path = match.group(1).strip()
        targets.append({'table': path, 'operation': 'write.save', 'confidence': 'regex', 'is_path': True})
    
    # Extract imports using AST
    try:
        tree = ast.parse(py_content)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append({'module': alias.name, 'type': 'import'})
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ''
                imports.append({'module': module, 'type': 'from_import'})
    except:
        # Fallback to regex for imports
        import_pattern = r'^(?:from\s+(\S+)\s+)?import\s+(.+)$'
        for match in re.finditer(import_pattern, py_content, re.MULTILINE):
            module = match.group(1) or match.group(2).split(',')[0].strip()
            imports.append({'module': module, 'type': 'regex'})
    
    # Orchestration calls
    subprocess_pattern = r'subprocess\.(?:run|call|Popen)\s*\(\s*["\']([^"\']+)["\']'
    for match in re.finditer(subprocess_pattern, py_content):
        cmd = match.group(1).strip()
        if 'spark-submit' in cmd or 'beeline' in cmd or 'hive' in cmd:
            orchestration.append({'command': cmd, 'type': 'subprocess'})
    
    os_system_pattern = r'os\.system\s*\(\s*["\']([^"\']+)["\']'
    for match in re.finditer(os_system_pattern, py_content):
        cmd = match.group(1).strip()
        if 'spark-submit' in cmd or 'beeline' in cmd or 'hive' in cmd:
            orchestration.append({'command': cmd, 'type': 'os.system'})
    
    return targets, sources, imports, orchestration, sql_blocks


def build_lineage_graph(scanned_files):
    """
    Build a unified directed graph from all scanned files.
    Node types: script, hive_table, file_path
    Edge types: READ, WRITE, IMPORTS
    """
    G = nx.DiGraph()
    
    for file_info in scanned_files:
        file_path = file_info['file_path']
        
        # Add script node
        G.add_node(file_path, type='script', label=os.path.basename(file_path))
        
        # Add target nodes and edges (WRITE)
        for target in file_info.get('targets', []):
            if isinstance(target, dict):
                table = target.get('table', '')
                is_path = target.get('is_path', False)
                operation = target.get('operation', 'WRITE')
            elif isinstance(target, str):
                table = target
                is_path = '/' in target
                operation = 'WRITE'
            else:
                continue
            if not table:
                continue
            node_type = 'file_path' if is_path else 'hive_table'
            G.add_node(table, type=node_type, label=table.split('/')[-1] if '/' in table else table)
            G.add_edge(file_path, table, type='WRITE', operation=operation)
        
        # Add source nodes and edges (READ)
        for source in file_info.get('sources', []):
            if isinstance(source, dict):
                table = source.get('table', '')
                is_path = source.get('is_path', False)
                operation = source.get('operation', 'READ')
            elif isinstance(source, str):
                table = source
                is_path = '/' in source
                operation = 'READ'
            else:
                continue
            if not table:
                continue
            node_type = 'file_path' if is_path else 'hive_table'
            G.add_node(table, type=node_type, label=table.split('/')[-1] if '/' in table else table)
            G.add_edge(table, file_path, type='READ', operation=operation)
        
        # Add import edges (for workflow)
        for imp in file_info.get('imports', []):
            if not isinstance(imp, dict):
                continue
            module = imp.get('module', '')
            # Only add if it looks like a local module (not standard library)
            if module and not module.startswith(('os', 'sys', 're', 'json', 'datetime', 'collections', 'typing', 'pandas', 'numpy', 'pyspark')):
                module_file = module.replace('.', '/') + '.py'
                G.add_node(module_file, type='script', label=module)
                G.add_edge(file_path, module_file, type='IMPORTS', module=module)
    
    return G


def generate_lineage_dot(G, filter_keyword=None, max_hops=None, center_node=None):
    """
    Generate Graphviz DOT string for lineage diagram.
    """
    if center_node and max_hops:
        # Get neighborhood around center node
        try:
            nodes = set([center_node])
            for _ in range(max_hops):
                new_nodes = set()
                for n in nodes:
                    new_nodes.update(G.predecessors(n))
                    new_nodes.update(G.successors(n))
                nodes.update(new_nodes)
            G = G.subgraph(nodes)
        except:
            pass
    
    if filter_keyword:
        nodes = [n for n in G.nodes() if filter_keyword.lower() in n.lower()]
        # Also include connected nodes
        connected = set(nodes)
        for n in nodes:
            connected.update(G.predecessors(n))
            connected.update(G.successors(n))
        G = G.subgraph(connected)
    
    dot_lines = ['digraph Lineage {', '  rankdir=LR;', '  node [fontname="Arial"];', '  edge [fontname="Arial"];']
    
    # Group nodes by type
    tables = [n for n, d in G.nodes(data=True) if d.get('type') == 'hive_table']
    paths = [n for n, d in G.nodes(data=True) if d.get('type') == 'file_path']
    scripts = [n for n, d in G.nodes(data=True) if d.get('type') == 'script']
    
    # Add nodes with styling
    for node in tables:
        label = G.nodes[node].get('label', node)[:30]
        dot_lines.append(f'  "{node}" [label="{label}", shape=box, style="rounded,filled", fillcolor="#E8F5E9"];')
    
    for node in paths:
        label = G.nodes[node].get('label', node)[:30]
        dot_lines.append(f'  "{node}" [label="{label}", shape=folder, style=filled, fillcolor="#FFF3E0"];')
    
    for node in scripts:
        label = G.nodes[node].get('label', node)[:30]
        dot_lines.append(f'  "{node}" [label="{label}", shape=rect, style=filled, fillcolor="#E3F2FD"];')
    
    # Add edges
    for u, v, d in G.edges(data=True):
        edge_type = d.get('type', 'UNKNOWN')
        if edge_type == 'READ':
            dot_lines.append(f'  "{u}" -> "{v}" [color="#4CAF50", label="read"];')
        elif edge_type == 'WRITE':
            dot_lines.append(f'  "{u}" -> "{v}" [color="#F44336", label="write"];')
        elif edge_type == 'IMPORTS':
            dot_lines.append(f'  "{u}" -> "{v}" [color="#9E9E9E", style=dashed];')
    
    dot_lines.append('}')
    return '\n'.join(dot_lines)


def generate_workflow_pyvis(G, include_tables=False):
    """
    Generate PyVis network for workflow/control flow visualization.
    """
    net = Network(height="600px", width="100%", directed=True, bgcolor="#ffffff")
    net.barnes_hut(gravity=-3000, central_gravity=0.3, spring_length=200)
    
    # Filter to scripts only (or include tables if requested)
    for node, data in G.nodes(data=True):
        node_type = data.get('type', 'unknown')
        if node_type == 'script':
            net.add_node(node, label=data.get('label', node)[:20], color='#2196F3', shape='box')
        elif include_tables and node_type == 'hive_table':
            net.add_node(node, label=data.get('label', node)[:20], color='#4CAF50', shape='ellipse')
        elif include_tables and node_type == 'file_path':
            net.add_node(node, label=data.get('label', node)[:20], color='#FF9800', shape='triangle')
    
    for u, v, data in G.edges(data=True):
        edge_type = data.get('type', 'UNKNOWN')
        if u in net.get_nodes() and v in net.get_nodes():
            if edge_type == 'IMPORTS':
                net.add_edge(u, v, color='#9E9E9E', title='imports')
            elif edge_type == 'WRITE' and include_tables:
                net.add_edge(u, v, color='#F44336', title='writes')
            elif edge_type == 'READ' and include_tables:
                net.add_edge(u, v, color='#4CAF50', title='reads')
    
    return net


def generate_sql_diagram(sql_block, block_id):
    """
    Generate Graphviz DOT for a single SQL statement showing source -> query -> target.
    """
    if not isinstance(sql_block, dict):
        return f'digraph SQL_{block_id} {{ "empty" [label="No data"]; }}'
    sql_text = sql_block.get('sql', '')
    targets, sources, _ = extract_sql_lineage(sql_text, 'inline')
    
    dot_lines = [f'digraph SQL_{block_id} {{', '  rankdir=LR;', '  node [fontname="Arial"];']
    
    query_label = sql_block.get('type', 'QUERY')[:20]
    dot_lines.append(f'  "query_{block_id}" [label="{query_label}", shape=diamond, style=filled, fillcolor="#FFEB3B"];')
    
    for i, src in enumerate(sources[:5]):
        table = (src.get('table', str(src)) if isinstance(src, dict) else str(src))[:25]
        dot_lines.append(f'  "src_{block_id}_{i}" [label="{table}", shape=box, style="rounded,filled", fillcolor="#E8F5E9"];')
        dot_lines.append(f'  "src_{block_id}_{i}" -> "query_{block_id}" [color="#4CAF50"];')
    
    for i, tgt in enumerate(targets[:3]):
        table = (tgt.get('table', str(tgt)) if isinstance(tgt, dict) else str(tgt))[:25]
        dot_lines.append(f'  "tgt_{block_id}_{i}" [label="{table}", shape=box, style="rounded,filled", fillcolor="#FFCDD2"];')
        dot_lines.append(f'  "query_{block_id}" -> "tgt_{block_id}_{i}" [color="#F44336"];')
    
    dot_lines.append('}')
    return '\n'.join(dot_lines)


def get_found_tables_and_fields():
    """Extract set of found table names and field names from scan results in session_state."""
    found_tables = set()
    found_fields = set()
    scan_results = st.session_state.get('scan_results', {})
    matches = scan_results.get('matches', [])
    for m in matches:
        if not isinstance(m, dict):
            continue
        name = m.get('name', '')
        mtype = m.get('type', '')
        if name:
            if mtype == 'Table':
                found_tables.add(name.lower())
            elif mtype == 'Field':
                found_fields.add(name.lower())
    return found_tables, found_fields


def filter_lineage_to_found(G, found_tables):
    """Filter lineage graph to only include nodes related to found tables.
    Keeps: hive_table nodes matching found tables, scripts connected to them, and their edges.
    """
    if not found_tables:
        return G

    matching_table_nodes = set()
    for node, data in G.nodes(data=True):
        if data.get('type') == 'hive_table':
            node_lower = node.lower()
            node_short = node.split('.')[-1].lower() if '.' in node else node_lower
            if node_lower in found_tables or node_short in found_tables:
                matching_table_nodes.add(node)

    if not matching_table_nodes:
        return nx.DiGraph()

    keep_nodes = set(matching_table_nodes)
    for table_node in matching_table_nodes:
        keep_nodes.update(G.predecessors(table_node))
        keep_nodes.update(G.successors(table_node))

    return G.subgraph(keep_nodes).copy()


def filter_table_names_to_found(table_names, found_tables):
    """Filter a set of table name strings to only include those matching found legacy tables."""
    if not found_tables:
        return table_names
    filtered = set()
    for tbl in table_names:
        tbl_lower = tbl.lower()
        tbl_short = tbl.split('.')[-1].lower() if '.' in tbl else tbl_lower
        if tbl_lower in found_tables or tbl_short in found_tables:
            filtered.add(tbl)
    return filtered


def filter_sql_blocks_to_found(sql_blocks, found_tables):
    """Filter SQL blocks to only include those referencing found tables."""
    if not found_tables:
        return sql_blocks

    filtered = []
    for block in sql_blocks:
        if not isinstance(block, dict):
            continue
        srcs = block.get('sources', [])
        tgts = block.get('targets', [])
        all_tables_in_block = []
        for item in (srcs if isinstance(srcs, list) else []):
            t = item.get('table', str(item)) if isinstance(item, dict) else str(item)
            all_tables_in_block.append(t.lower())
        for item in (tgts if isinstance(tgts, list) else []):
            t = item.get('table', str(item)) if isinstance(item, dict) else str(item)
            all_tables_in_block.append(t.lower())

        for tbl in all_tables_in_block:
            tbl_short = tbl.split('.')[-1] if '.' in tbl else tbl
            if tbl in found_tables or tbl_short in found_tables:
                filtered.append(block)
                break

    return filtered


def scan_folder_for_lineage(folder_path, progress_callback=None):
    """
    Scan a folder for PySpark and SQL files and extract lineage.
    progress_callback(fraction, status_text) is called if provided.
    """
    scanned_files = []
    all_sql_blocks = []

    all_file_paths = []
    for root, dirs, files in os.walk(folder_path):
        dirs[:] = [d for d in dirs if d not in IGNORE_FOLDERS]
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in SCAN_EXTENSIONS:
                all_file_paths.append(os.path.join(root, file))

    total = len(all_file_paths) or 1
    for idx, file_path in enumerate(all_file_paths):
        rel_path = os.path.relpath(file_path, folder_path)
        ext = os.path.splitext(file_path)[1].lower()
        file = os.path.basename(file_path)

        if progress_callback:
            progress_callback((idx + 1) / total, f"Scanning {idx+1}/{total}: {file}")

        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except:
            continue

        file_info = {
            'file_path': rel_path,
            'file_name': file,
            'extension': ext,
            'targets': [],
            'sources': [],
            'imports': [],
            'orchestration': [],
            'sql_blocks': []
        }

        if ext in ['.sql', '.hql', '.hive']:
            targets, sources, sql_blocks = extract_sql_lineage(content, rel_path)
            file_info['targets'] = targets
            file_info['sources'] = sources
            file_info['sql_blocks'] = sql_blocks
            all_sql_blocks.extend([{'file': rel_path, **b} for b in sql_blocks if isinstance(b, dict)])

        elif ext in ['.py', '.pyspark']:
            targets, sources, imports, orchestration, sql_blocks = extract_pyspark_lineage(content, rel_path)
            file_info['targets'] = targets
            file_info['sources'] = sources
            file_info['imports'] = imports
            file_info['orchestration'] = orchestration
            file_info['sql_blocks'] = sql_blocks
            all_sql_blocks.extend([{'file': rel_path, **b} for b in sql_blocks if isinstance(b, dict)])

        if file_info['targets'] or file_info['sources'] or file_info['imports']:
            scanned_files.append(file_info)

    return scanned_files, all_sql_blocks


# ============== END LINEAGE FUNCTIONS ==============


def parse_excel_mappings(excel_file):
    """
    Parse Excel file to extract table names, fields and C360 mappings from all sheets.
    Column 1: Legacy Table Name
    Column 2: Field/Attribute Name
    Column 3: C360_Mapping (optional)
    Returns a dictionary with sheet names as keys and list of mappings as values.
    """
    mappings = {}
    all_tables = set()
    all_fields = set()
    table_field_mapping = defaultdict(set)
    field_c360_mapping = {}  # Map field name to C360_Mapping
    
    try:
        excel_data = pd.ExcelFile(excel_file)
        
        for sheet_name in excel_data.sheet_names:
            df = pd.read_excel(excel_data, sheet_name=sheet_name)
            
            if len(df.columns) < 2:
                st.warning(f"Sheet '{sheet_name}' has less than 2 columns, skipping...")
                continue
            
            sheet_mappings = []
            
            # Get table, field, and c360 mapping columns
            table_col = df.columns[0]
            field_col = df.columns[1]
            c360_col = df.columns[2] if len(df.columns) >= 3 else None
            
            for _, row in df.iterrows():
                table_name = str(row[table_col]).strip() if pd.notna(row[table_col]) else ""
                field_name = str(row[field_col]).strip() if pd.notna(row[field_col]) else ""
                c360_mapping = ""
                if c360_col is not None:
                    c360_mapping = str(row[c360_col]).strip() if pd.notna(row[c360_col]) else ""
                    if c360_mapping.lower() == 'nan':
                        c360_mapping = ""
                
                if table_name and table_name.lower() != 'nan':
                    all_tables.add(table_name)
                    if field_name and field_name.lower() != 'nan':
                        all_fields.add(field_name)
                        table_field_mapping[table_name].add(field_name)
                        field_c360_mapping[field_name] = c360_mapping
                        sheet_mappings.append({
                            'table': table_name,
                            'field': field_name,
                            'c360_mapping': c360_mapping
                        })
            
            mappings[sheet_name] = sheet_mappings
        
        return mappings, all_tables, all_fields, table_field_mapping, field_c360_mapping
    
    except Exception as e:
        st.error(f"Error parsing Excel file: {str(e)}")
        return None, None, None, None, None


def extract_zip(zip_file, temp_dir):
    """Extract ZIP file to temporary directory."""
    try:
        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
        return True
    except Exception as e:
        st.error(f"Error extracting ZIP file: {str(e)}")
        return False


def get_all_files(directory):
    """Get all supported files from directory recursively."""
    files = []
    for root, dirs, filenames in os.walk(directory):
        # Skip hidden directories and common non-code directories
        dirs[:] = [d for d in dirs if not d.startswith('.') and d not in {'__pycache__', 'node_modules', '.git', 'venv', 'env'}]
        
        for filename in filenames:
            ext = os.path.splitext(filename)[1].lower()
            if ext in SUPPORTED_EXTENSIONS or filename.endswith('.py') or filename.endswith('.sh'):
                files.append(os.path.join(root, filename))
    
    return files


def compile_patterns(tables, fields):
    """
    Precompile regex patterns for tables and fields for performance.
    Supports qualified identifiers (schema.table, alias.field) with flexible separators.
    """
    table_patterns = {}
    field_patterns = {}
    
    for table in tables:
        # Pattern allows optional prefix (schema., alias.) and matches table name
        # Supports: table_name, schema.table_name, `table_name`, "table_name"
        pattern_str = r'(?:^|[\s,(\[\'"`.]|FROM\s+|JOIN\s+|INTO\s+|UPDATE\s+|TABLE\s+)' + re.escape(table) + r'(?:$|[\s,)\]\'"`.])'
        table_patterns[table] = re.compile(pattern_str, re.IGNORECASE)
    
    for field in fields:
        if len(field) < 2:  # Skip very short field names
            continue
        # Pattern allows optional prefix (alias., table.) and matches field name
        # Supports: field_name, alias.field_name, table.field_name
        pattern_str = r'(?:^|[\s,(\[\'"`.]|SELECT\s+|WHERE\s+|AND\s+|OR\s+|BY\s+)' + re.escape(field) + r'(?:$|[\s,)\]\'"`.])'
        field_patterns[field] = re.compile(pattern_str, re.IGNORECASE)
    
    return table_patterns, field_patterns


def extract_queries_from_content(content, lines):
    """
    Extract SQL-like queries from file content.
    Returns list of query objects with query text, start/end line numbers.
    """
    queries = []
    
    # Pattern to find SQL statement starts
    sql_start_pattern = re.compile(r'\b(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP|ALTER|MERGE)\b', re.IGNORECASE)
    
    # SQL continuation keywords - lines with these are likely part of an ongoing query
    sql_continuation_keywords = ['FROM', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 'OUTER', 'CROSS', 'FULL', 
                                  'ON', 'WHERE', 'AND', 'OR', 'GROUP', 'ORDER', 'HAVING', 'LIMIT', 
                                  'OFFSET', 'UNION', 'EXCEPT', 'INTERSECT', 'INTO', 'VALUES', 'SET',
                                  'AS', 'WHEN', 'THEN', 'ELSE', 'END', 'CASE', 'WITH', 'PARTITION', 
                                  'OVER', 'USING', 'BETWEEN', 'LIKE', 'IN', 'NOT', 'NULL', 'IS']
    
    i = 0
    while i < len(lines):
        line = lines[i]
        
        # Check if line starts a SQL query
        match = sql_start_pattern.search(line)
        if match:
            query_lines = [line]
            start_line = i + 1  # 1-indexed
            end_line = i + 1
            
            # Track parentheses and quotes for proper query boundary detection
            j = i + 1
            open_parens = line.count('(') - line.count(')')
            # Check for triple quotes (multi-line strings)
            in_triple_quote = ('"""' in line and line.count('"""') == 1) or ("'''" in line and line.count("'''") == 1)
            open_quotes = (line.count("'") % 2) + (line.count('"') % 2) if not in_triple_quote else 1
            
            # Track if previous line ended with comma (likely more columns coming)
            prev_line_continues = line.rstrip().endswith(',') or line.rstrip().endswith('(')
            
            while j < len(lines):
                next_line = lines[j]
                next_line_stripped = next_line.strip()
                next_line_upper = next_line_stripped.upper()
                
                # Check for triple quote ending
                if in_triple_quote and ('"""' in next_line or "'''" in next_line):
                    query_lines.append(next_line)
                    end_line = j + 1
                    in_triple_quote = False
                    j += 1
                    continue
                
                # If in triple quote, always continue
                if in_triple_quote:
                    query_lines.append(next_line)
                    end_line = j + 1
                    j += 1
                    if j - i > 100:
                        break
                    continue
                
                # Empty line might end query (unless inside parens/quotes or prev line continues)
                if not next_line_stripped:
                    if open_parens <= 0 and open_quotes == 0 and not prev_line_continues:
                        break
                    query_lines.append(next_line)
                    end_line = j + 1
                    j += 1
                    continue
                
                # Check if this line starts with a SQL continuation keyword
                first_word = next_line_stripped.split()[0].upper() if next_line_stripped.split() else ''
                is_continuation_keyword = first_word in sql_continuation_keywords
                
                # Check if this line contains SQL keywords
                has_sql_content = any(kw in next_line_upper for kw in sql_continuation_keywords)
                
                # Check if previous line suggests continuation (ends with comma, operator, etc.)
                continues_from_prev = prev_line_continues
                
                # Check if line looks like part of a SQL query (has table/column patterns, commas, etc.)
                looks_like_sql = bool(re.search(r'[a-zA-Z_]\.[a-zA-Z_]|,\s*$|^\s*[a-zA-Z_]+\s*,', next_line))
                
                # Continue if: continuation keyword, inside parens/quotes, has SQL content, or continues from prev
                if is_continuation_keyword or open_parens > 0 or open_quotes > 0 or has_sql_content or continues_from_prev or looks_like_sql:
                    query_lines.append(next_line)
                    end_line = j + 1
                    open_parens += next_line.count('(') - next_line.count(')')
                    
                    # Update quote tracking
                    if '"""' in next_line or "'''" in next_line:
                        if next_line.count('"""') == 1 or next_line.count("'''") == 1:
                            in_triple_quote = not in_triple_quote
                    if not in_triple_quote:
                        open_quotes = (open_quotes + next_line.count("'")) % 2 + (next_line.count('"') % 2)
                    
                    # Update prev line continues flag
                    prev_line_continues = next_line.rstrip().endswith(',') or next_line.rstrip().endswith('(')
                    
                    # Check for statement terminator
                    if ';' in next_line_stripped and open_parens <= 0 and not in_triple_quote:
                        break
                    
                    j += 1
                    if j - i > 100:  # Limit query size to 100 lines
                        break
                else:
                    # Check if next line starts a new SQL statement
                    if sql_start_pattern.match(next_line_stripped):
                        break
                    break
            
            query_text = '\n'.join(query_lines)
            queries.append({
                'query_text': query_text,
                'start_line': start_line,
                'end_line': end_line,
                'query_lines': query_lines
            })
            i = j + 1
        else:
            i += 1
    
    return queries


def extract_table_aliases(query_text, table_patterns):
    """
    Extract table aliases from a SQL query.
    Returns a dict mapping alias -> table_name for legacy tables found in query.
    Handles patterns like:
    - table_name alias
    - table_name AS alias
    - table_name as alias
    Also maps physical table names (and their short forms) to themselves so that
    physical_table.field_name references are correctly attributed.
    """
    aliases = {}
    query_upper = query_text.upper()
    
    for table in table_patterns.keys():
        table_lower = table.lower()
        table_upper = table.upper()
        
        aliases[table_lower] = table
        if '.' in table:
            short_name = table.split('.')[-1].lower()
            if short_name not in aliases:
                aliases[short_name] = table
        
        # Pattern: table_name alias (no AS keyword)
        # Matches: FROM legacy_table lt, JOIN legacy_table lt ON
        pattern1 = re.compile(
            rf'\b{re.escape(table)}\s+([a-zA-Z_][a-zA-Z0-9_]*)\b(?!\s*\.)',
            re.IGNORECASE
        )
        
        # Pattern: table_name AS alias
        pattern2 = re.compile(
            rf'\b{re.escape(table)}\s+AS\s+([a-zA-Z_][a-zA-Z0-9_]*)\b',
            re.IGNORECASE
        )
        
        # Find all matches
        for match in pattern2.finditer(query_text):
            alias = match.group(1)
            # Exclude SQL keywords as aliases
            if alias.upper() not in ['ON', 'WHERE', 'AND', 'OR', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 
                                      'OUTER', 'CROSS', 'FULL', 'GROUP', 'ORDER', 'HAVING', 'LIMIT',
                                      'SELECT', 'FROM', 'SET', 'INTO', 'VALUES', 'AS', 'UNION']:
                aliases[alias.lower()] = table
        
        for match in pattern1.finditer(query_text):
            alias = match.group(1)
            # Exclude SQL keywords as aliases
            if alias.upper() not in ['ON', 'WHERE', 'AND', 'OR', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 
                                      'OUTER', 'CROSS', 'FULL', 'GROUP', 'ORDER', 'HAVING', 'LIMIT',
                                      'SELECT', 'FROM', 'SET', 'INTO', 'VALUES', 'AS', 'UNION']:
                # Don't overwrite if already found via AS pattern
                if alias.lower() not in aliases:
                    aliases[alias.lower()] = table
    
    return aliases


def find_field_with_alias(query_text, field, aliases, table_field_mapping):
    """
    Find a field in query text and determine which table it belongs to based on alias.
    Returns the table name if field is found with correct alias, None otherwise.
    Also returns True if field is found without alias prefix (standalone).
    """
    field_lower = field.lower()
    query_lower = query_text.lower()
    
    if field_lower not in query_lower:
        return None, False
    
    # Pattern to find alias.field_name
    alias_field_pattern = re.compile(
        rf'\b([a-zA-Z_][a-zA-Z0-9_]*)\.{re.escape(field)}\b',
        re.IGNORECASE
    )
    
    found_tables = set()
    found_standalone = False
    
    for match in alias_field_pattern.finditer(query_text):
        alias = match.group(1).lower()
        if alias in aliases:
            # Field is prefixed with a known table alias
            found_tables.add(aliases[alias])
        else:
            # Field has an alias prefix but it's not a known legacy table alias
            # Could be another table's field
            pass
    
    # Check for standalone field (no alias prefix)
    # Pattern: field not preceded by alias.
    standalone_pattern = re.compile(
        rf'(?<![a-zA-Z0-9_]\.)\b{re.escape(field)}\b(?!\.)',
        re.IGNORECASE
    )
    
    # Check if there are standalone occurrences
    for match in standalone_pattern.finditer(query_text):
        start = match.start()
        # Check that it's not preceded by alias.
        if start >= 2:
            prev_chars = query_text[max(0, start-20):start]
            if not re.search(r'[a-zA-Z_][a-zA-Z0-9_]*\.\s*$', prev_chars):
                found_standalone = True
    
    return found_tables, found_standalone


def scan_file_for_matches(file_path, table_patterns, field_patterns, table_field_mapping, base_dir):
    """
    Scan a file for table and field matches using query-based approach.
    First finds queries containing legacy tables, then scans those queries for attributes.
    Returns matches with query counts and attribute details.
    """
    matches = []
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            lines = content.split('\n')
    except Exception as e:
        return matches, []
    
    relative_path = os.path.relpath(file_path, base_dir)
    filename = os.path.basename(file_path)
    
    # Extract queries from the file
    queries = extract_queries_from_content(content, lines)
    
    # Track queries per table and attributes found in those queries
    table_queries = defaultdict(list)  # table -> list of queries containing it
    table_attributes = defaultdict(lambda: defaultdict(list))  # table -> attribute -> list of occurrences
    
    # Also track standalone line-based matches for non-query occurrences
    table_line_matches = defaultdict(list)
    field_line_matches = defaultdict(list)
    
    # Process each query
    for query in queries:
        query_text = query['query_text']
        query_text_padded = ' ' + query_text + ' '
        
        # Find which tables are in this query
        tables_in_query = []
        for table, pattern in table_patterns.items():
            if table.lower() in query_text.lower():
                if pattern.search(query_text_padded):
                    tables_in_query.append(table)
                    table_queries[table].append({
                        'query_text': query_text,
                        'start_line': query['start_line'],
                        'end_line': query['end_line'],
                        'file_path': relative_path,
                        'file_name': filename
                    })
        
        # Extract table aliases from the query (e.g., "legacy_table lt" -> alias 'lt' maps to 'legacy_table')
        aliases = extract_table_aliases(query_text, table_patterns)
        
        # For each table found in query, scan for its attributes using alias detection
        for table in tables_in_query:
            table_fields = table_field_mapping.get(table, set())
            for field in table_fields:
                if len(field) < 2:
                    continue
                if field.lower() in query_text.lower():
                    # Use alias-aware field detection
                    found_tables, found_standalone = find_field_with_alias(query_text, field, aliases, table_field_mapping)
                    
                    # Field is attributed to this table if:
                    # 1. It has an alias prefix that maps to this table, OR
                    # 2. It's found standalone (no alias) and this table is in the query
                    field_belongs_to_table = (table in found_tables) or (found_standalone and not found_tables)
                    
                    if field_belongs_to_table:
                        table_attributes[table][field].append({
                            'query_text': query_text,
                            'start_line': query['start_line'],
                            'end_line': query['end_line'],
                            'file_path': relative_path,
                            'file_name': filename,
                            'alias_used': next((a for a, t in aliases.items() if t == table), None)
                        })
    
    # Also scan line by line for matches (for display purposes)
    for line_num, line in enumerate(lines, 1):
        line_with_padding = ' ' + line + ' '
        
        for table, pattern in table_patterns.items():
            if table.lower() in line.lower():
                if pattern.search(line_with_padding):
                    # Check if this line falls within any query
                    in_query = False
                    containing_query = None
                    for query in queries:
                        if query['start_line'] <= line_num <= query['end_line']:
                            in_query = True
                            containing_query = query
                            break
                    
                    table_line_matches[table].append({
                        'line_number': line_num,
                        'line_content': line.strip(),
                        'match_text': table,
                        'in_query': in_query
                    })
                    
                    # If table found on a line within a query, add to table_queries
                    if in_query and containing_query:
                        # Check if this query is already added for this table
                        existing = False
                        for q in table_queries[table]:
                            if q['start_line'] == containing_query['start_line']:
                                existing = True
                                break
                        if not existing:
                            table_queries[table].append({
                                'query_text': containing_query['query_text'],
                                'start_line': containing_query['start_line'],
                                'end_line': containing_query['end_line'],
                                'file_path': relative_path,
                                'file_name': filename
                            })
        
        for field, pattern in field_patterns.items():
            if field.lower() in line.lower():
                if pattern.search(line_with_padding):
                    field_line_matches[field].append({
                        'line_number': line_num,
                        'line_content': line.strip(),
                        'match_text': field
                    })
    
    # Compile table results
    for table, query_list in table_queries.items():
        matches.append({
            'type': 'Table',
            'name': table,
            'file_name': filename,
            'file_path': relative_path,
            'query_count': len(query_list),
            'queries': query_list,
            'occurrences': len(table_line_matches.get(table, [])),
            'details': table_line_matches.get(table, []),
            'related_fields': list(table_field_mapping.get(table, [])),
            'attributes_found': dict(table_attributes.get(table, {}))
        })
    
    # Add tables that were found in lines but not in queries
    for table in table_line_matches:
        if table not in table_queries:
            matches.append({
                'type': 'Table',
                'name': table,
                'file_name': filename,
                'file_path': relative_path,
                'query_count': 0,
                'queries': [],
                'occurrences': len(table_line_matches[table]),
                'details': table_line_matches[table],
                'related_fields': list(table_field_mapping.get(table, [])),
                'attributes_found': {}
            })
    
    # Compile field results
    for field, occurrences in field_line_matches.items():
        parent_tables = [t for t, fields_set in table_field_mapping.items() if field in fields_set]
        # Check if this field was found in context of its parent table's query
        in_table_query = False
        for table in parent_tables:
            if field in table_attributes.get(table, {}):
                in_table_query = True
                break
        
        matches.append({
            'type': 'Field',
            'name': field,
            'file_name': filename,
            'file_path': relative_path,
            'occurrences': len(occurrences),
            'details': occurrences,
            'parent_tables': parent_tables,
            'in_table_query': in_table_query
        })
    
    return matches, queries


def scan_file_for_service_ids(file_path, service_ids, base_dir):
    """Scan a file for Service ID occurrences."""
    matches = []
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            lines = content.split('\n')
    except Exception as e:
        return matches
    
    relative_path = os.path.relpath(file_path, base_dir)
    filename = os.path.basename(file_path)
    
    for service_id in service_ids:
        service_id = service_id.strip()
        if not service_id:
            continue
        
        # Create pattern for service ID (case-insensitive, word boundary)
        pattern = re.compile(r'(?:^|[\s\'"=,:(\[])' + re.escape(service_id) + r'(?:$|[\s\'"=,:)\]])', re.IGNORECASE)
        
        occurrences = []
        for line_num, line in enumerate(lines, 1):
            if service_id.lower() in line.lower():
                if pattern.search(' ' + line + ' '):
                    occurrences.append({
                        'line_number': line_num,
                        'line_content': line.strip()[:200]
                    })
        
        if occurrences:
            matches.append({
                'service_id': service_id,
                'file_name': filename,
                'file_path': relative_path,
                'occurrences': len(occurrences),
                'details': occurrences
            })
    
    return matches


def scan_repository_for_service_ids(temp_dir, service_ids):
    """Scan repository for Service ID occurrences."""
    all_matches = []
    files = get_all_files(temp_dir)
    
    if not files or not service_ids:
        return all_matches
    
    for file_path in files:
        matches = scan_file_for_service_ids(file_path, service_ids, temp_dir)
        all_matches.extend(matches)
    
    return all_matches


def scan_files_for_alias_usages(temp_dir, alias_map):
    """
    Scan all source files for usages of config alias/variable names.
    For each alias defined in config (e.g., SRC_TABLE=legacy_table),
    search all code files for occurrences of the variable name (SRC_TABLE).
    Returns list of dicts with alias usage details.
    """
    usages = []
    if not alias_map:
        return usages
    
    files = get_all_files(temp_dir)
    config_files_set = set(os.path.relpath(f, temp_dir) for f in get_config_files(temp_dir))
    
    alias_patterns = {}
    for alias_name in alias_map:
        if len(alias_name) >= 2:
            alias_patterns[alias_name] = re.compile(
                r'(?:^|[^a-zA-Z0-9_])' + re.escape(alias_name) + r'(?:$|[^a-zA-Z0-9_])',
                re.IGNORECASE if alias_name.islower() else 0
            )
    
    for file_path in files:
        relative_path = os.path.relpath(file_path, temp_dir)
        if relative_path in config_files_set:
            continue
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except Exception:
            continue
        
        content_check = content.lower() if content else ''
        lines = content.split('\n')
        
        for alias_name, pattern in alias_patterns.items():
            if alias_name.lower() not in content_check:
                continue
            
            for line_num, line in enumerate(lines, 1):
                if pattern.search(line):
                    alias_info = alias_map[alias_name]
                    usages.append({
                        'alias_name': alias_name,
                        'legacy_table': alias_info['table'],
                        'config_file': alias_info['file'],
                        'config_variable': alias_info.get('variable', alias_name),
                        'config_value': alias_info.get('value', ''),
                        'usage_file': os.path.basename(file_path),
                        'usage_path': relative_path,
                        'usage_line': line_num,
                        'usage_content': line.strip()[:300]
                    })
    
    return usages


def scan_repository(temp_dir, tables, fields, table_field_mapping):
    """Scan entire repository for matches, including config file alias resolution."""
    all_matches = []
    all_queries = []
    files = get_all_files(temp_dir)
    
    file_stats = {
        'Python (.py)': {'scanned': 0, 'with_matches': 0, 'files': []},
        'Shell (.sh)': {'scanned': 0, 'with_matches': 0, 'files': []},
        'PySpark (.pyspark)': {'scanned': 0, 'with_matches': 0, 'files': []},
        'Hive/HQL (.hql, .hive)': {'scanned': 0, 'with_matches': 0, 'files': []},
        'SQL (.sql)': {'scanned': 0, 'with_matches': 0, 'files': []},
        'Config': {'scanned': 0, 'with_matches': 0, 'files': []},
        'Other': {'scanned': 0, 'with_matches': 0, 'files': []}
    }
    
    def get_file_type(path):
        if path.endswith('.py'):
            return 'Python (.py)'
        elif path.endswith('.sh'):
            return 'Shell (.sh)'
        elif path.endswith('.pyspark'):
            return 'PySpark (.pyspark)'
        elif path.endswith('.hql') or path.endswith('.hive'):
            return 'Hive/HQL (.hql, .hive)'
        elif path.endswith('.sql'):
            return 'SQL (.sql)'
        else:
            return 'Other'
    
    if not files:
        st.warning("No supported source files found in the repository.")
        return all_matches, 0, all_queries, file_stats, [], {}
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    status_text.text("Phase 1: Scanning config files for table aliases...")
    config_matches, alias_map = scan_config_files(temp_dir, tables)
    
    config_file_count = len(set(m['file_path'] for m in config_matches)) if config_matches else 0
    file_stats['Config']['scanned'] = len(get_config_files(temp_dir))
    file_stats['Config']['with_matches'] = config_file_count
    file_stats['Config']['files'] = list(set(m['file_name'] for m in config_matches))
    
    progress_bar.progress(0.1)
    
    extended_tables = set(tables) if tables else set()
    alias_to_table = {}
    for alias_name, alias_info in alias_map.items():
        extended_tables.add(alias_name)
        alias_to_table[alias_name] = alias_info['table']
    
    table_patterns, field_patterns = compile_patterns(list(extended_tables), fields)
    
    status_text.text("Phase 2: Scanning source code files...")
    total_files = len(files)
    
    alias_code_matches = []
    
    for idx, file_path in enumerate(files):
        status_text.text(f"Scanning: {os.path.basename(file_path)}")
        file_type = get_file_type(file_path)
        file_stats[file_type]['scanned'] += 1
        
        matches, queries = scan_file_for_matches(file_path, table_patterns, field_patterns, table_field_mapping, temp_dir)
        
        real_matches = []
        for m in matches:
            match_name = m.get('name', m.get('match_text', ''))
            if match_name in alias_to_table:
                original_table = alias_to_table[match_name]
                alias_code_matches.append({
                    'alias_name': match_name,
                    'original_table': original_table,
                    'file_name': m.get('file_name', os.path.basename(file_path)),
                    'file_path': m.get('file_path', os.path.relpath(file_path, temp_dir)),
                    'line_number': m.get('line_number', 0),
                    'line_content': m.get('line_content', ''),
                    'type': m.get('type', 'Table'),
                    'occurrences': m.get('occurrences', 1)
                })
                m_copy = dict(m)
                m_copy['is_alias'] = True
                m_copy['alias_for'] = original_table
                m_copy['alias_variable'] = match_name
                real_matches.append(m_copy)
            else:
                real_matches.append(m)
        
        if real_matches:
            file_stats[file_type]['with_matches'] += 1
            file_stats[file_type]['files'].append(os.path.basename(file_path))
        
        all_matches.extend(real_matches)
        all_queries.extend(queries)
        progress_bar.progress(0.1 + 0.9 * (idx + 1) / total_files)
    
    status_text.text("Phase 3: Tracing config alias usages in code...")
    alias_usages = scan_files_for_alias_usages(temp_dir, alias_map)
    
    status_text.text("Scan complete!")
    progress_bar.empty()
    
    return all_matches, len(files), all_queries, file_stats, config_matches, alias_map, alias_usages


def generate_html_report(table_summary_data, field_summary_data, table_occurrences_data, field_occurrences_data, 
                          total_excel_tables, total_excel_fields, total_queries, scan_stats, file_stats=None):
    """Generate a comprehensive HTML report with all analysis."""
    
    report_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Build file scan summary HTML
    file_scan_html = "<p>No file scan data</p>"
    if file_stats:
        file_scan_data = []
        for file_type, stats in file_stats.items():
            if stats['scanned'] > 0:
                file_scan_data.append({
                    'File Type': file_type,
                    'Files Scanned': stats['scanned'],
                    'Files with Matches': stats['with_matches'],
                    'Match Rate': f"{(stats['with_matches']/stats['scanned']*100):.1f}%" if stats['scanned'] > 0 else "0%"
                })
        if file_scan_data:
            file_scan_html = pd.DataFrame(file_scan_data).to_html(index=False, classes='data-table', escape=False)
    
    # Convert dataframes to HTML tables
    table_summary_html = pd.DataFrame(table_summary_data).to_html(index=False, classes='data-table', escape=False) if table_summary_data else "<p>No data</p>"
    
    # Filter field summary to only show found attributes
    found_fields = [f for f in field_summary_data if f.get('In Table Query') == '✅ Yes' or f.get('Query Count', 0) > 0] if field_summary_data else []
    field_summary_html = pd.DataFrame(found_fields).to_html(index=False, classes='data-table', escape=False) if found_fields else "<p>No attributes found in table queries</p>"
    
    table_occ_html = pd.DataFrame(table_occurrences_data).to_html(index=False, classes='data-table', escape=False) if table_occurrences_data else "<p>No data</p>"
    field_occ_html = pd.DataFrame(field_occurrences_data).to_html(index=False, classes='data-table', escape=False) if field_occurrences_data else "<p>No data</p>"
    
    html_template = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Lens- Data Imaging Analysis Report</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f7fa;
            color: #333;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}
        h1 {{
            color: #1a73e8;
            border-bottom: 3px solid #1a73e8;
            padding-bottom: 10px;
        }}
        h2 {{
            color: #34495e;
            margin-top: 30px;
            border-left: 4px solid #1a73e8;
            padding-left: 15px;
        }}
        h3 {{
            color: #555;
            margin-top: 20px;
        }}
        .header {{
            background: linear-gradient(135deg, #1a73e8, #4285f4);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .header h1 {{
            color: white;
            border-bottom: none;
            margin: 0;
        }}
        .header p {{
            margin: 10px 0 0 0;
            opacity: 0.9;
        }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }}
        .stat-card {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }}
        .stat-card .value {{
            font-size: 2.5em;
            font-weight: bold;
            color: #1a73e8;
        }}
        .stat-card .label {{
            color: #666;
            margin-top: 5px;
        }}
        .section {{
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .table-wrapper {{
            width: 100%;
            overflow-x: auto;
        }}
        .data-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 13px;
            table-layout: auto;
        }}
        .data-table th {{
            background-color: #1a73e8;
            color: white;
            padding: 10px 6px;
            text-align: left;
            position: sticky;
            top: 0;
            white-space: nowrap;
        }}
        .data-table td {{
            padding: 8px 6px;
            border-bottom: 1px solid #eee;
            word-wrap: break-word;
            max-width: 300px;
        }}
        .data-table tr:hover {{
            background-color: #f5f9ff;
        }}
        .data-table tr:nth-child(even) {{
            background-color: #fafafa;
        }}
        .found {{ color: #27ae60; font-weight: bold; }}
        .not-found {{ color: #e74c3c; }}
        .explanation {{
            background: #e8f4fd;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #1a73e8;
            margin: 20px 0;
        }}
        .explanation h3 {{
            margin-top: 0;
            color: #1a73e8;
        }}
        .footer {{
            text-align: center;
            color: #888;
            margin-top: 40px;
            padding: 20px;
            border-top: 1px solid #ddd;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 Code Lens- Data Imaging Analysis Report</h1>
            <p>Generated on: {report_date}</p>
        </div>
        
        <div class="explanation">
            <h3>How Scanning Works</h3>
            <p><strong>Step 1:</strong> The Excel mapping file is parsed to extract Legacy Table names (Column 1) and Legacy Attribute names (Column 2).</p>
            <p><strong>Step 2:</strong> Source code files (.py, .pyspark, .sh, .hql, .hive) are scanned to find SQL-like queries (SELECT, INSERT, UPDATE, etc.).</p>
            <p><strong>Step 3:</strong> For each query, we first check if it contains any Legacy Table names.</p>
            <p><strong>Step 4:</strong> If a query contains a Legacy Table, we then scan that specific query for Legacy Attributes belonging to that table.</p>
            <p><strong>Step 5:</strong> This ensures attributes are only counted when found in context with their parent table.</p>
        </div>
        
        <h2>📊 Overview Statistics</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="value">{total_excel_tables}</div>
                <div class="label">Tables in Excel</div>
            </div>
            <div class="stat-card">
                <div class="value">{total_excel_fields}</div>
                <div class="label">Attributes in Excel</div>
            </div>
            <div class="stat-card">
                <div class="value">{scan_stats.get('tables_found', 0)}</div>
                <div class="label">Tables Found</div>
            </div>
            <div class="stat-card">
                <div class="value">{total_queries}</div>
                <div class="label">SQL Queries Found</div>
            </div>
            <div class="stat-card">
                <div class="value">{scan_stats.get('attrs_in_queries', 0)}</div>
                <div class="label">Attrs in Queries</div>
            </div>
            <div class="stat-card">
                <div class="value">{scan_stats.get('coverage', 0):.1f}%</div>
                <div class="label">Coverage</div>
            </div>
        </div>
        
        <div class="section">
            <h2>📁 Files Scanned by Type</h2>
            <p>Overview of source files scanned and matches found by file type.</p>
            <div class="table-wrapper">{file_scan_html}</div>
        </div>
        
        <div class="section">
            <h2>📋 Legacy Table Summary</h2>
            <p>Overview of all legacy tables from Excel and their presence in the codebase.</p>
            <div class="table-wrapper">{table_summary_html}</div>
        </div>
        
        <div class="section">
            <h2>📊 Attribute Summary (Found Only)</h2>
            <p>Attributes found within their parent table's queries.</p>
            <div class="table-wrapper">{field_summary_html}</div>
        </div>
        
        <div class="section">
            <h2>🔍 Table Occurrences (Detailed)</h2>
            <p>All occurrences of legacy table names in the scanned files.</p>
            <div class="table-wrapper">{table_occ_html}</div>
        </div>
        
        <div class="section">
            <h2>🔍 Field/Attribute Occurrences (Detailed)</h2>
            <p>All occurrences of legacy attributes in the scanned files.</p>
            <div class="table-wrapper">{field_occ_html}</div>
        </div>
        
        <div class="footer">
            <p>Generated by Code Lens- Data Imaging - Legacy Table and Field Scanner</p>
        </div>
    </div>
</body>
</html>
"""
    return html_template


def display_results(matches, mappings, total_excel_tables, total_excel_fields, field_c360_mapping=None, file_stats=None, service_id_matches=None, config_matches=None, alias_map=None, alias_usages=None):
    """Display scan results in organized format."""
    if field_c360_mapping is None:
        field_c360_mapping = {}
    if file_stats is None:
        file_stats = {}
    if service_id_matches is None:
        service_id_matches = []
    if config_matches is None:
        config_matches = st.session_state.get('config_matches', [])
    if alias_map is None:
        alias_map = st.session_state.get('alias_map', {})
    if alias_usages is None:
        alias_usages = st.session_state.get('alias_usages', [])
    
    if not matches:
        st.info("No matches found in the repository.")
        return
    
    # Summary statistics
    table_matches = [m for m in matches if m['type'] == 'Table']
    field_matches = [m for m in matches if m['type'] == 'Field']
    
    # Excel totals
    st.subheader("Excel File Summary")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Total Tables in Excel", total_excel_tables)
    with col2:
        st.metric("Total Fields in Excel", total_excel_fields)
    
    st.divider()
    
    # File Scan Summary Table
    if file_stats:
        st.subheader("📁 Files Scanned by Type")
        file_scan_data = []
        for file_type, stats in file_stats.items():
            if stats['scanned'] > 0:
                file_scan_data.append({
                    'File Type': file_type,
                    'Files Scanned': stats['scanned'],
                    'Files with Matches': stats['with_matches'],
                    'Match Rate': f"{(stats['with_matches']/stats['scanned']*100):.1f}%" if stats['scanned'] > 0 else "0%"
                })
        
        if file_scan_data:
            file_scan_df = pd.DataFrame(file_scan_data)
            st.dataframe(file_scan_df, use_container_width=True, hide_index=True)
        
        st.divider()
    
    # Match statistics
    st.subheader("Scan Results")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Matches", len(matches))
    with col2:
        st.metric("Table Matches", len(table_matches))
    with col3:
        st.metric("Field Matches", len(field_matches))
    
    # Build dynamic tab list
    searched_ids = st.session_state.get('service_ids_searched', [])
    show_service_tab = bool(service_id_matches) or bool(searched_ids)
    show_config_tab = bool(config_matches) or bool(alias_map)
    show_alias_tracing_tab = bool(alias_usages) or bool(alias_map)
    
    tab_names = ["📋 Legacy Table Summary", "📊 Attribute Mapping Details", "🗺️ C360 Attribute Mapping", "🔍 Table Occurrences", "🔍 Field Occurrences", "📁 Files to Correct"]
    if show_config_tab:
        tab_names.append("⚙️ Config Matches")
    if show_alias_tracing_tab:
        tab_names.append("🔗 Alias Tracing")
    if show_service_tab:
        tab_names.append("🔑 Service IDs")
    tab_names.append("📥 Reports")
    
    all_tabs = st.tabs(tab_names)
    tab1, tab2, c360_tab, tab3, tab4, tab5 = all_tabs[0], all_tabs[1], all_tabs[2], all_tabs[3], all_tabs[4], all_tabs[5]
    
    idx = 6
    if show_config_tab:
        config_tab = all_tabs[idx]
        idx += 1
    else:
        config_tab = None
    if show_alias_tracing_tab:
        alias_tracing_tab = all_tabs[idx]
        idx += 1
    else:
        alias_tracing_tab = None
    if show_service_tab:
        tab6 = all_tabs[idx]
        idx += 1
    else:
        tab6 = None
    reports_tab_ref = all_tabs[idx]
    
    with tab1:
        st.subheader("Legacy Tables Found in Project")
        st.markdown("*Scanning: Python (.py), PySpark (.pyspark), Shell (.sh), Hive/HQL (.hql, .hive) files*")
        
        # Build comprehensive table summary
        table_summary_data = []
        
        # Get unique tables from mappings
        all_table_names = set()
        table_to_fields = defaultdict(set)
        table_to_sheet = {}
        
        for sheet_name, sheet_mappings in mappings.items():
            for mapping in sheet_mappings:
                table_name = mapping['table']
                all_table_names.add(table_name)
                table_to_fields[table_name].add(mapping['field'])
                table_to_sheet[table_name] = sheet_name
        
        # Count matches per table
        for table_name in sorted(all_table_names):
            # Find table matches - only count target file types
            table_query_count = 0
            table_occurrence_count = 0
            table_files = set()
            attributes_in_queries = set()
            
            for match in table_matches:
                if match['name'] == table_name:
                    # Filter for target file types only
                    if any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                        table_query_count += match.get('query_count', 0)
                        table_occurrence_count += match.get('occurrences', 0)
                        table_files.add(match['file_path'])
                        # Get attributes found in queries with this table
                        attrs_found = match.get('attributes_found', {})
                        attributes_in_queries.update(attrs_found.keys())
            
            # Find field matches for this table (in table's queries)
            fields_for_table = table_to_fields.get(table_name, set())
            
            table_summary_data.append({
                'Legacy Table': table_name,
                'Sheet': table_to_sheet.get(table_name, 'N/A'),
                'Attributes in Excel': len(fields_for_table),
                'Attributes in Queries': len(attributes_in_queries),
                'Query Count': table_query_count,
                'Occurrences': table_occurrence_count,
                'File Count': len(table_files),
                'File Names': ', '.join(sorted([os.path.basename(f) for f in table_files])) if table_files else 'N/A',
                'Status': '✅ Found' if table_query_count > 0 or table_occurrence_count > 0 else '❌ Not Found'
            })
        
        if table_summary_data:
            # Quick Overview
            st.markdown("### Quick Overview")
            total_tables = len(table_summary_data)
            found_tables = len([t for t in table_summary_data if t['Query Count'] > 0 or t['Occurrences'] > 0])
            total_queries = sum(t['Query Count'] for t in table_summary_data)
            total_attrs_in_queries = sum(t['Attributes in Queries'] for t in table_summary_data)
            total_attrs_in_excel = sum(t['Attributes in Excel'] for t in table_summary_data)
            
            col1, col2, col3, col4, col5 = st.columns(5)
            with col1:
                st.metric("Tables Found", f"{found_tables}/{total_tables}")
            with col2:
                st.metric("Total Queries", total_queries)
            with col3:
                st.metric("Attrs in Excel", total_attrs_in_excel)
            with col4:
                st.metric("Attrs in Queries", total_attrs_in_queries)
            with col5:
                coverage = (total_attrs_in_queries / total_attrs_in_excel * 100) if total_attrs_in_excel > 0 else 0
                st.metric("Coverage", f"{coverage:.1f}%")
            
            st.divider()
            
            summary_df = pd.DataFrame(table_summary_data)
            st.dataframe(summary_df, use_container_width=True, hide_index=True)
            
            # Statistics
            st.success(f"**Summary:** {found_tables} of {total_tables} legacy tables found in source code with {total_queries} queries")
            
            csv = summary_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Legacy Table Summary as CSV",
                data=csv,
                file_name="legacy_table_summary.csv",
                mime="text/csv"
            )
    
    with tab2:
        st.subheader("Attribute Mapping Details")
        st.markdown("*Attributes found within queries containing their parent Legacy Table*")
        
        # Build detailed attribute mapping table
        attribute_details = []
        
        # First, build a map of table -> attributes found in that table's queries
        table_attr_in_queries = defaultdict(lambda: defaultdict(list))
        for match in table_matches:
            if any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                attrs_found = match.get('attributes_found', {})
                for attr, occurrences in attrs_found.items():
                    for occ in occurrences:
                        table_attr_in_queries[match['name']][attr].append({
                            'file_path': match['file_path'],
                            'file_name': match['file_name'],
                            'start_line': occ.get('start_line', 0),
                            'query_text': occ.get('query_text', '')[:100],
                            'alias_used': occ.get('alias_used', '')
                        })
        
        # === NEW: Simplified Table-Attribute Summary ===
        st.markdown("### 📊 Table-Attribute Occurrence Summary")
        simple_summary = []
        for table_name, attrs in table_attr_in_queries.items():
            for attr_name, occurrences in attrs.items():
                files = list(set([occ['file_path'] for occ in occurrences]))
                aliases_used = list(set([occ.get('alias_used', '') for occ in occurrences if occ.get('alias_used')]))
                simple_summary.append({
                    'Legacy Table': table_name,
                    'Legacy Attribute': attr_name,
                    'Occurrences': len(occurrences),
                    'Files': ', '.join(files),
                    'Alias Used': ', '.join(aliases_used) if aliases_used else '-'
                })
        
        if simple_summary:
            simple_df = pd.DataFrame(simple_summary)
            simple_df = simple_df.sort_values(['Legacy Table', 'Legacy Attribute']).reset_index(drop=True)
            
            # Filters for simple summary
            col1, col2 = st.columns(2)
            with col1:
                simple_table_filter = st.multiselect("Filter by Legacy Table", 
                    options=list(simple_df['Legacy Table'].unique()), 
                    key="simple_table_filter")
            with col2:
                simple_attr_filter = st.multiselect("Filter by Attribute", 
                    options=list(simple_df['Legacy Attribute'].unique()), 
                    key="simple_attr_filter")
            
            filtered_simple_df = simple_df.copy()
            if simple_table_filter:
                filtered_simple_df = filtered_simple_df[filtered_simple_df['Legacy Table'].isin(simple_table_filter)]
            if simple_attr_filter:
                filtered_simple_df = filtered_simple_df[filtered_simple_df['Legacy Attribute'].isin(simple_attr_filter)]
            
            st.dataframe(filtered_simple_df, use_container_width=True, hide_index=True, height=300)
            
            st.info(f"**Found:** {len(simple_summary)} table-attribute combinations with {sum(s['Occurrences'] for s in simple_summary)} total occurrences")
            
            csv_simple = filtered_simple_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Table-Attribute Summary as CSV",
                data=csv_simple,
                file_name="table_attribute_summary.csv",
                mime="text/csv",
                key="download_simple_summary"
            )
        else:
            st.info("No attributes found in queries with their parent tables.")
        
        st.divider()
        st.markdown("### 📋 Full Attribute Mapping (from Excel)")
        
        for sheet_name, sheet_mappings in mappings.items():
            for mapping in sheet_mappings:
                table_name = mapping['table']
                field_name = mapping['field']
                c360_mapping = mapping.get('c360_mapping', field_c360_mapping.get(field_name, ''))
                
                # Check if this attribute was found in queries containing its parent table
                in_table_query = field_name in table_attr_in_queries.get(table_name, {})
                query_occurrences = table_attr_in_queries.get(table_name, {}).get(field_name, [])
                
                # Also check general field matches
                field_found_general = False
                found_files = []
                found_lines = []
                
                for match in field_matches:
                    if match['name'] == field_name:
                        if any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                            field_found_general = True
                            found_files.append(match['file_path'])
                            for detail in match['details']:
                                found_lines.append(f"L{detail['line_number']}")
                
                attribute_details.append({
                    'Legacy Table': table_name,
                    'Attribute': field_name,
                    'C360_Mapping': c360_mapping if c360_mapping else 'N/A',
                    'In Table Query': '✅ Yes' if in_table_query else '❌ No',
                    'Query Count': len(query_occurrences),
                    'Files': ', '.join(set([q['file_path'] for q in query_occurrences])) if query_occurrences else 'N/A',
                    'Also Found Elsewhere': '✅' if field_found_general and not in_table_query else ''
                })
        
        if attribute_details:
            attr_df = pd.DataFrame(attribute_details)
            
            # Filters
            col1, col2 = st.columns(2)
            all_tables = list(attr_df['Legacy Table'].unique())
            with col1:
                table_filter = st.multiselect("Filter by Table", options=all_tables, key="attr_table_filter")
            with col2:
                found_filter = st.selectbox("Filter by Status", options=['All', 'In Table Query Only', 'Not Found Only'], key="attr_status_filter")
            
            # Apply filters - if no selection, show all
            if table_filter:
                filtered_attr_df = attr_df[attr_df['Legacy Table'].isin(table_filter)]
            else:
                filtered_attr_df = attr_df
            if found_filter == 'In Table Query Only':
                filtered_attr_df = filtered_attr_df[filtered_attr_df['In Table Query'] == '✅ Yes']
            elif found_filter == 'Not Found Only':
                filtered_attr_df = filtered_attr_df[filtered_attr_df['In Table Query'] == '❌ No']
            
            st.dataframe(filtered_attr_df, use_container_width=True, hide_index=True, height=400)
            
            # Stats
            found_attrs = len([a for a in attribute_details if a['In Table Query'] == '✅ Yes'])
            st.info(f"**Attributes in Table Queries:** {found_attrs} of {len(attribute_details)} attributes found within their parent table's queries")
            
            csv = filtered_attr_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Attribute Mapping as CSV",
                data=csv,
                file_name="attribute_mapping_details.csv",
                mime="text/csv"
            )
    
    with c360_tab:
        st.subheader("C360 Attribute Mapping")
        st.markdown("*Legacy attributes found in the codebase mapped to their C360 target fields*")
        
        found_field_names = set()
        found_table_field_pairs = set()
        for match in field_matches:
            if any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                found_field_names.add(match['name'])
        for match in table_matches:
            if any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                for attr in match.get('attributes_found', {}).keys():
                    found_field_names.add(attr)
                    found_table_field_pairs.add((match['name'], attr))
        
        c360_rows = []
        for sheet_name, sheet_mappings in mappings.items():
            for mapping in sheet_mappings:
                table_name = mapping['table']
                field_name = mapping['field']
                c360_val = mapping.get('c360_mapping', field_c360_mapping.get(field_name, ''))
                
                is_found = (table_name, field_name) in found_table_field_pairs or field_name in found_field_names
                
                c360_rows.append({
                    'Legacy Table': table_name,
                    'Legacy Attribute': field_name,
                    'C360_Mapping': c360_val if c360_val else '',
                    'Found in Code': '✅ Yes' if is_found else '❌ No'
                })
        
        if c360_rows:
            c360_df = pd.DataFrame(c360_rows)
            
            total_attrs = len(c360_df)
            found_count = len(c360_df[c360_df['Found in Code'] == '✅ Yes'])
            mapped_count = len(c360_df[c360_df['C360_Mapping'] != ''])
            found_and_mapped = len(c360_df[(c360_df['Found in Code'] == '✅ Yes') & (c360_df['C360_Mapping'] != '')])
            
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total Attributes", total_attrs)
            with col2:
                st.metric("Found in Code", found_count)
            with col3:
                st.metric("Have C360 Mapping", mapped_count)
            with col4:
                st.metric("Found + Mapped", found_and_mapped)
            
            st.divider()
            
            col_f1, col_f2, col_f3 = st.columns(3)
            with col_f1:
                c360_table_filter = st.multiselect("Filter by Legacy Table", options=sorted(c360_df['Legacy Table'].unique()), key="c360_table_filter")
            with col_f2:
                c360_status_filter = st.selectbox("Filter by Status", options=['All', 'Found Only', 'Not Found Only'], key="c360_status_filter")
            with col_f3:
                c360_mapping_filter = st.selectbox("Filter by C360 Mapping", options=['All', 'With Mapping', 'Without Mapping'], key="c360_mapping_filter")
            
            filtered_c360 = c360_df.copy()
            if c360_table_filter:
                filtered_c360 = filtered_c360[filtered_c360['Legacy Table'].isin(c360_table_filter)]
            if c360_status_filter == 'Found Only':
                filtered_c360 = filtered_c360[filtered_c360['Found in Code'] == '✅ Yes']
            elif c360_status_filter == 'Not Found Only':
                filtered_c360 = filtered_c360[filtered_c360['Found in Code'] == '❌ No']
            if c360_mapping_filter == 'With Mapping':
                filtered_c360 = filtered_c360[filtered_c360['C360_Mapping'] != '']
            elif c360_mapping_filter == 'Without Mapping':
                filtered_c360 = filtered_c360[filtered_c360['C360_Mapping'] == '']
            
            st.dataframe(filtered_c360, use_container_width=True, hide_index=True, height=500)
            
            st.info(f"Showing {len(filtered_c360)} of {total_attrs} attributes")
            
            col_dl1, col_dl2 = st.columns(2)
            with col_dl1:
                csv_c360 = filtered_c360.to_csv(index=False)
                st.download_button(
                    label="📥 Download C360 Mapping as CSV",
                    data=csv_c360,
                    file_name="c360_attribute_mapping.csv",
                    mime="text/csv",
                    key="dl_c360_csv"
                )
            with col_dl2:
                found_only_df = c360_df[c360_df['Found in Code'] == '✅ Yes']
                if not found_only_df.empty:
                    csv_found = found_only_df[['Legacy Table', 'Legacy Attribute', 'C360_Mapping']].to_csv(index=False)
                    st.download_button(
                        label="📥 Download Found Attributes Only (CSV)",
                        data=csv_found,
                        file_name="c360_found_attributes.csv",
                        mime="text/csv",
                        key="dl_c360_found_csv"
                    )
        else:
            st.info("No attribute mappings available. Ensure the Excel file has table and field columns.")
    
    with tab3:
        st.subheader("Table Occurrences")
        st.markdown("*All occurrences of legacy table names in source files*")
        
        # Build table occurrences data
        table_occurrences_data = []
        for match in table_matches:
            if not any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                continue
            for detail in match['details']:
                table_occurrences_data.append({
                    'Legacy Table': match['name'],
                    'File Name': match['file_name'],
                    'File Path': match['file_path'],
                    'Line Number': detail['line_number'],
                    'Line Content': detail['line_content'][:300],
                    'Query Count': match.get('query_count', 0)
                })
        
        if table_occurrences_data:
            table_occ_df = pd.DataFrame(table_occurrences_data)
            
            # Filter by table
            unique_tables = list(table_occ_df['Legacy Table'].unique())
            selected_tables = st.multiselect("Filter by Table", options=unique_tables, key="table_occ_filter")
            
            # Apply filter - if no selection, show all
            if selected_tables:
                filtered_table_occ_df = table_occ_df[table_occ_df['Legacy Table'].isin(selected_tables)]
            else:
                filtered_table_occ_df = table_occ_df
            st.dataframe(filtered_table_occ_df, use_container_width=True, hide_index=True, height=400)
            
            st.info(f"Found {len(filtered_table_occ_df)} table occurrences across {len(filtered_table_occ_df['File Name'].unique())} files")
            
            csv = filtered_table_occ_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Table Occurrences as CSV",
                data=csv,
                file_name="table_occurrences.csv",
                mime="text/csv"
            )
        else:
            st.info("No table occurrences found.")
    
    with tab4:
        st.subheader("Field/Attribute Occurrences")
        st.markdown("*All occurrences of legacy attributes in source files*")
        
        # Build field occurrences data
        field_occurrences_data = []
        for match in field_matches:
            if not any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                continue
            for detail in match['details']:
                field_occurrences_data.append({
                    'Attribute': match['name'],
                    'Parent Table': ', '.join(match.get('parent_tables', [])) if match.get('parent_tables') else 'N/A',
                    'File Name': match['file_name'],
                    'File Path': match['file_path'],
                    'Line Number': detail['line_number'],
                    'Line Content': detail['line_content'][:300],
                    'In Table Query': '✅' if match.get('in_table_query', False) else ''
                })
        
        if field_occurrences_data:
            field_occ_df = pd.DataFrame(field_occurrences_data)
            
            # Filter by parent table
            unique_tables = set()
            for item in field_occurrences_data:
                if item['Parent Table'] != 'N/A':
                    for t in item['Parent Table'].split(', '):
                        unique_tables.add(t.strip())
            table_options = sorted(list(unique_tables))
            selected_tables = st.multiselect("Filter by Parent Table", options=table_options, key="field_occ_filter")
            
            # Apply filter - if no selection, show all
            if selected_tables:
                filtered_field_occ_df = field_occ_df[field_occ_df['Parent Table'].apply(
                    lambda x: any(t in x for t in selected_tables) if x != 'N/A' else False
                )]
            else:
                filtered_field_occ_df = field_occ_df
            st.dataframe(filtered_field_occ_df, use_container_width=True, hide_index=True, height=400)
            
            st.info(f"Found {len(filtered_field_occ_df)} field occurrences across {len(filtered_field_occ_df['File Name'].unique())} files")
            
            csv = filtered_field_occ_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Field Occurrences as CSV",
                data=csv,
                file_name="field_occurrences.csv",
                mime="text/csv"
            )
        else:
            st.info("No field occurrences found.")
    
    with tab5:
        st.subheader("Files to Correct")
        st.markdown("*Summary of files containing legacy references that need attention*")
        
        # Build file analysis data
        file_analysis = defaultdict(lambda: {
            'tables': set(),
            'fields': set(),
            'table_lines': [],
            'field_lines': [],
            'query_count': 0
        })
        
        # Collect data from table matches
        for match in table_matches:
            if not any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                continue
            file_path = match['file_path']
            file_analysis[file_path]['tables'].add(match['name'])
            file_analysis[file_path]['query_count'] += match.get('query_count', 0)
            for detail in match['details']:
                file_analysis[file_path]['table_lines'].append({
                    'table': match['name'],
                    'line': detail['line_number'],
                    'content': detail['line_content'][:100]
                })
        
        # Collect data from field matches
        for match in field_matches:
            if not any(match['file_path'].endswith(ext) for ext in TARGET_EXTENSIONS):
                continue
            file_path = match['file_path']
            file_analysis[file_path]['fields'].add(match['name'])
            for detail in match['details']:
                file_analysis[file_path]['field_lines'].append({
                    'field': match['name'],
                    'line': detail['line_number'],
                    'content': detail['line_content'][:100]
                })
        
        # Count files by type
        py_files = [f for f in file_analysis.keys() if f.endswith('.py')]
        sh_files = [f for f in file_analysis.keys() if f.endswith('.sh')]
        hql_files = [f for f in file_analysis.keys() if f.endswith('.hql') or f.endswith('.hive')]
        pyspark_files = [f for f in file_analysis.keys() if f.endswith('.pyspark')]
        
        # Display file type summary
        st.markdown("### File Type Summary")
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Python Files (.py)", len(py_files))
        with col2:
            st.metric("Shell Scripts (.sh)", len(sh_files))
        with col3:
            st.metric("Hive/HQL Files", len(hql_files))
        with col4:
            st.metric("PySpark Files", len(pyspark_files))
        
        st.divider()
        
        # Build detailed file list
        files_to_correct = []
        for file_path, data in file_analysis.items():
            ext = os.path.splitext(file_path)[1]
            file_type = {'.py': 'Python', '.sh': 'Shell', '.hql': 'HQL', '.hive': 'Hive', '.pyspark': 'PySpark'}.get(ext, 'Other')
            
            files_to_correct.append({
                'File Name': os.path.basename(file_path),
                'File Type': file_type,
                'File Path': file_path,
                'Tables Found': len(data['tables']),
                'Tables': ', '.join(sorted(data['tables'])),
                'Fields Found': len(data['fields']),
                'Fields to Check': ', '.join(sorted(data['fields']))[:200] + ('...' if len(', '.join(sorted(data['fields']))) > 200 else ''),
                'Query Count': data['query_count']
            })
        
        if files_to_correct:
            files_df = pd.DataFrame(files_to_correct)
            files_df = files_df.sort_values(['File Type', 'Tables Found'], ascending=[True, False])
            
            # Filter by file type
            file_types = files_df['File Type'].unique()
            selected_types = st.multiselect("Filter by File Type", options=file_types, default=list(file_types), key="file_type_filter")
            
            filtered_files_df = files_df[files_df['File Type'].isin(selected_types)]
            st.dataframe(filtered_files_df, use_container_width=True, hide_index=True, height=400)
            
            st.success(f"**Total:** {len(filtered_files_df)} files need attention with {sum(filtered_files_df['Tables Found'])} table references and {sum(filtered_files_df['Fields Found'])} field references")
            
            csv = filtered_files_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Files to Correct as CSV",
                data=csv,
                file_name="files_to_correct.csv",
                mime="text/csv"
            )
            
            # Detailed view per file
            st.divider()
            st.markdown("### Detailed File Analysis")
            selected_file = st.selectbox("Select a file to see details", options=sorted(file_analysis.keys()))
            
            if selected_file:
                file_data = file_analysis[selected_file]
                
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown("**Tables in this file:**")
                    for table in sorted(file_data['tables']):
                        st.write(f"- {table}")
                
                with col2:
                    st.markdown("**Fields to check:**")
                    for field in sorted(file_data['fields']):
                        st.write(f"- {field}")
                
                st.markdown("**Lines with legacy references:**")
                all_lines = []
                for item in file_data['table_lines']:
                    all_lines.append({'Line': item['line'], 'Type': 'Table', 'Name': item['table'], 'Content': item['content']})
                for item in file_data['field_lines']:
                    all_lines.append({'Line': item['line'], 'Type': 'Field', 'Name': item['field'], 'Content': item['content']})
                
                if all_lines:
                    lines_df = pd.DataFrame(all_lines).sort_values('Line')
                    st.dataframe(lines_df, use_container_width=True, hide_index=True)
        else:
            st.info("No files found with legacy references.")
    
    # Config Matches Tab
    if show_config_tab and config_tab:
        with config_tab:
            st.subheader("⚙️ Config File Matches")
            st.markdown("*Legacy table names found in config files (.conf, .cfg, .env, .properties, .ini, .yaml, .yml, .json, .sh, .bash, .ksh) and their alias/variable mappings*")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Config Files with Matches", len(set(m['file_path'] for m in config_matches)) if config_matches else 0)
            with col2:
                st.metric("Table References in Config", len(config_matches))
            with col3:
                st.metric("Alias/Variable Mappings", len(alias_map))
            
            st.divider()
            
            if alias_map:
                st.markdown("### Alias / Variable Mappings")
                st.markdown("*These variables in config files map to legacy table names. The alias names are also searched across all source code files.*")
                alias_data = []
                for alias_name, info in alias_map.items():
                    alias_matches_in_code = [m for m in matches if m.get('is_alias') and m.get('alias_variable') == alias_name]
                    alias_data.append({
                        'Variable / Alias': alias_name,
                        'Legacy Table': info['table'],
                        'Config File': info['file'],
                        'Config Value': info['value'],
                        'Used in Code': len(alias_matches_in_code) > 0,
                        'Code Occurrences': sum(m.get('occurrences', 1) for m in alias_matches_in_code)
                    })
                alias_df = pd.DataFrame(alias_data)
                st.dataframe(alias_df, use_container_width=True, hide_index=True)
            
            st.divider()
            
            if config_matches:
                st.markdown("### All Config File References")
                cfg_data = []
                for m in config_matches:
                    cfg_data.append({
                        'Legacy Table': m['table_name'],
                        'Variable': m['variable_name'] if m['variable_name'] else '(direct reference)',
                        'Value': m['value'] if m['value'] else '',
                        'File': m['file_name'],
                        'Path': m['file_path'],
                        'Line': m['line_number'],
                        'Content': m['line_content']
                    })
                cfg_df = pd.DataFrame(cfg_data)
                
                unique_tables = cfg_df['Legacy Table'].unique()
                selected_tables = st.multiselect("Filter by Legacy Table", options=unique_tables, key="config_table_filter")
                if selected_tables:
                    cfg_df = cfg_df[cfg_df['Legacy Table'].isin(selected_tables)]
                
                st.dataframe(cfg_df, use_container_width=True, hide_index=True, height=400)
                
                st.divider()
                st.markdown("### Download Config Scan Report")
                dl_col1, dl_col2 = st.columns(2)
                with dl_col1:
                    csv_cfg = cfg_df.to_csv(index=False)
                    st.download_button(
                        label="📥 Download Config Matches (CSV)",
                        data=csv_cfg,
                        file_name="config_matches.csv",
                        mime="text/csv"
                    )
                with dl_col2:
                    cfg_excel = BytesIO()
                    with pd.ExcelWriter(cfg_excel, engine='openpyxl') as writer:
                        pd.DataFrame(cfg_data).to_excel(writer, sheet_name='Config References', index=False)
                        if alias_map:
                            pd.DataFrame(alias_data).to_excel(writer, sheet_name='Alias Mappings', index=False)
                    cfg_excel.seek(0)
                    st.download_button(
                        label="📥 Download Config Report (Excel)",
                        data=cfg_excel.getvalue(),
                        file_name="config_scan_report.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
            else:
                st.info("No legacy table references found in config files.")
    
    # Alias Tracing Tab
    if show_alias_tracing_tab and alias_tracing_tab:
        with alias_tracing_tab:
            st.subheader("🔗 Alias Tracing — Config Variable to Code Usage")
            st.markdown("*Traces config file variables/aliases that map to legacy tables, showing where each variable is used across the codebase*")
            
            if alias_map:
                alias_summary = {}
                for alias_name, info in alias_map.items():
                    usage_list = [u for u in alias_usages if u['alias_name'] == alias_name]
                    alias_summary[alias_name] = {
                        'legacy_table': info['table'],
                        'config_file': info['file'],
                        'config_variable': info.get('variable', alias_name),
                        'config_value': info.get('value', ''),
                        'usages': usage_list,
                        'usage_count': len(usage_list),
                        'files_used_in': list(set(u['usage_path'] for u in usage_list))
                    }
                
                total_aliases = len(alias_map)
                aliases_with_usage = sum(1 for v in alias_summary.values() if v['usage_count'] > 0)
                total_usages = sum(v['usage_count'] for v in alias_summary.values())
                total_files_with_usage = len(set(f for v in alias_summary.values() for f in v['files_used_in']))
                
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Config Aliases", total_aliases)
                with col2:
                    st.metric("Aliases Used in Code", aliases_with_usage)
                with col3:
                    st.metric("Total Code Usages", total_usages)
                with col4:
                    st.metric("Files with Alias Usage", total_files_with_usage)
                
                st.divider()
                
                st.markdown("### Alias Mapping Summary")
                summary_data = []
                for alias_name, info in alias_summary.items():
                    summary_data.append({
                        'Config Variable': alias_name,
                        'Legacy Table': info['legacy_table'],
                        'Defined In': info['config_file'],
                        'Config Value': info['config_value'],
                        'Used in Code': 'Yes' if info['usage_count'] > 0 else 'No',
                        'Code Usages': info['usage_count'],
                        'Files Used In': len(info['files_used_in'])
                    })
                summary_df = pd.DataFrame(summary_data)
                st.dataframe(summary_df, use_container_width=True, hide_index=True)
                
                st.divider()
                
                st.markdown("### Detailed Alias Usage in Code")
                st.markdown("*Select a config variable to see all locations where it is used in source code*")
                
                alias_names_sorted = sorted(alias_summary.keys(), key=lambda x: alias_summary[x]['usage_count'], reverse=True)
                alias_options = [f"{a} → {alias_summary[a]['legacy_table']} ({alias_summary[a]['usage_count']} usages)" for a in alias_names_sorted]
                
                selected_alias_display = st.selectbox("Select Config Variable / Alias", alias_options, key="alias_trace_select")
                
                if selected_alias_display:
                    selected_alias = alias_names_sorted[alias_options.index(selected_alias_display)]
                    info = alias_summary[selected_alias]
                    
                    st.markdown(f"**Config Definition:** `{info['config_variable']}` = `{info['config_value']}` in `{info['config_file']}`")
                    st.markdown(f"**Maps to Legacy Table:** `{info['legacy_table']}`")
                    
                    if info['usages']:
                        usage_data = []
                        for u in info['usages']:
                            usage_data.append({
                                'File': u['usage_file'],
                                'Path': u['usage_path'],
                                'Line': u['usage_line'],
                                'Code': u['usage_content']
                            })
                        usage_df = pd.DataFrame(usage_data)
                        
                        unique_files = usage_df['Path'].unique()
                        file_filter = st.multiselect("Filter by File", options=unique_files, key="alias_trace_file_filter")
                        if file_filter:
                            usage_df = usage_df[usage_df['Path'].isin(file_filter)]
                        
                        st.dataframe(usage_df, use_container_width=True, hide_index=True, height=400)
                    else:
                        st.warning(f"Variable `{selected_alias}` was not found in any source code files.")
                
                st.divider()
                
                if alias_usages:
                    st.markdown("### All Alias Usages (Full List)")
                    all_usage_data = []
                    for u in alias_usages:
                        all_usage_data.append({
                            'Config Variable': u['alias_name'],
                            'Legacy Table': u['legacy_table'],
                            'Config File': u['config_file'],
                            'Usage File': u['usage_file'],
                            'Usage Path': u['usage_path'],
                            'Line': u['usage_line'],
                            'Code': u['usage_content']
                        })
                    all_usage_df = pd.DataFrame(all_usage_data)
                    
                    tbl_filter = st.multiselect("Filter by Legacy Table", options=sorted(all_usage_df['Legacy Table'].unique()), key="alias_trace_tbl_filter")
                    if tbl_filter:
                        all_usage_df = all_usage_df[all_usage_df['Legacy Table'].isin(tbl_filter)]
                    
                    st.dataframe(all_usage_df, use_container_width=True, hide_index=True, height=400)
                    
                    st.divider()
                    st.markdown("### Download Alias Tracing Report")
                    dl_col1, dl_col2 = st.columns(2)
                    with dl_col1:
                        csv_alias = all_usage_df.to_csv(index=False)
                        st.download_button(
                            label="📥 Download Alias Usages (CSV)",
                            data=csv_alias,
                            file_name="alias_tracing.csv",
                            mime="text/csv",
                            key="dl_alias_csv"
                        )
                    with dl_col2:
                        alias_excel = BytesIO()
                        with pd.ExcelWriter(alias_excel, engine='openpyxl') as writer:
                            summary_df.to_excel(writer, sheet_name='Alias Summary', index=False)
                            all_usage_df.to_excel(writer, sheet_name='All Usages', index=False)
                        alias_excel.seek(0)
                        st.download_button(
                            label="📥 Download Alias Report (Excel)",
                            data=alias_excel.getvalue(),
                            file_name="alias_tracing_report.xlsx",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            key="dl_alias_excel"
                        )
            else:
                st.info("No config alias/variable mappings were found during the scan.")
    
    # Service IDs Tab (tab6 when service IDs were searched)
    if show_service_tab and tab6:
        with tab6:
            st.subheader("🔑 Service ID Scan Report")
            st.markdown("*Service IDs searched and found in the scanned repository*")
            
            searched_ids = st.session_state.get('service_ids_searched', [])
            
            found_id_set = set(m['service_id'] for m in service_id_matches)
            not_found_ids = [sid for sid in searched_ids if sid not in found_id_set]
            
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Service IDs Searched", len(searched_ids))
            with col2:
                st.metric("Service IDs Found", len(found_id_set))
            with col3:
                st.metric("Total Occurrences", sum(m['occurrences'] for m in service_id_matches))
            with col4:
                st.metric("Files with Matches", len(set(m['file_path'] for m in service_id_matches)))
            
            if not_found_ids:
                st.warning(f"⚠️ **Not found in repository:** {', '.join(not_found_ids)}")
            
            st.divider()
            
            service_id_summary = defaultdict(lambda: {'occurrences': 0, 'files': set(), 'details': []})
            for match in service_id_matches:
                sid = match['service_id']
                service_id_summary[sid]['occurrences'] += match['occurrences']
                service_id_summary[sid]['files'].add(match['file_path'])
                for detail in match['details']:
                    service_id_summary[sid]['details'].append({
                        'file': match['file_path'],
                        'line': detail['line_number'],
                        'content': detail['line_content']
                    })
            
            summary_data = []
            for sid in searched_ids:
                if sid in service_id_summary:
                    data = service_id_summary[sid]
                    summary_data.append({
                        'Service ID': sid,
                        'Status': 'Found',
                        'Occurrences': data['occurrences'],
                        'Files Count': len(data['files']),
                        'Files': ', '.join(sorted([os.path.basename(f) for f in data['files']]))
                    })
                else:
                    summary_data.append({
                        'Service ID': sid,
                        'Status': 'Not Found',
                        'Occurrences': 0,
                        'Files Count': 0,
                        'Files': ''
                    })
            
            if summary_data:
                st.markdown("### Service ID Summary")
                summary_df = pd.DataFrame(summary_data)
                st.dataframe(summary_df, use_container_width=True, hide_index=True)
                
                st.divider()
                st.markdown("### Detailed Occurrences")
                
                detail_data = []
                for match in service_id_matches:
                    for detail in match['details']:
                        detail_data.append({
                            'Service ID': match['service_id'],
                            'File': match['file_name'],
                            'Path': match['file_path'],
                            'Line': detail['line_number'],
                            'Content': detail['line_content']
                        })
                
                if detail_data:
                    detail_df = pd.DataFrame(detail_data)
                    
                    unique_sids = detail_df['Service ID'].unique()
                    selected_sids = st.multiselect("Filter by Service ID", options=unique_sids, key="service_id_filter")
                    
                    if selected_sids:
                        filtered_detail_df = detail_df[detail_df['Service ID'].isin(selected_sids)]
                    else:
                        filtered_detail_df = detail_df
                    
                    st.dataframe(filtered_detail_df, use_container_width=True, hide_index=True, height=400)
                else:
                    filtered_detail_df = None
                
                st.divider()
                st.markdown("### Download Service ID Report")
                
                dl_col1, dl_col2 = st.columns(2)
                with dl_col1:
                    csv_rows = []
                    csv_rows.append({'Section': 'SUMMARY', 'Service ID': '', 'Status': '', 'File': '', 'Path': '', 'Line': '', 'Content': ''})
                    for row in summary_data:
                        csv_rows.append({'Section': '', 'Service ID': row['Service ID'], 'Status': row['Status'], 'File': '', 'Path': row['Files'], 'Line': str(row['Occurrences']), 'Content': ''})
                    csv_rows.append({'Section': '', 'Service ID': '', 'Status': '', 'File': '', 'Path': '', 'Line': '', 'Content': ''})
                    csv_rows.append({'Section': 'DETAILS', 'Service ID': '', 'Status': '', 'File': '', 'Path': '', 'Line': '', 'Content': ''})
                    for match in service_id_matches:
                        for detail in match['details']:
                            csv_rows.append({
                                'Section': '',
                                'Service ID': match['service_id'],
                                'Status': 'Found',
                                'File': match['file_name'],
                                'Path': match['file_path'],
                                'Line': str(detail['line_number']),
                                'Content': detail['line_content']
                            })
                    csv_report = pd.DataFrame(csv_rows).to_csv(index=False)
                    st.download_button(
                        label="📥 Download Service ID Report (CSV)",
                        data=csv_report,
                        file_name="service_id_scan_report.csv",
                        mime="text/csv"
                    )
                
                with dl_col2:
                    sid_excel = BytesIO()
                    with pd.ExcelWriter(sid_excel, engine='openpyxl') as writer:
                        overview = {
                            'Metric': ['Total Service IDs Searched', 'Service IDs Found', 'Service IDs Not Found', 'Total Occurrences', 'Files with Matches'],
                            'Value': [len(searched_ids), len(found_id_set), len(not_found_ids), sum(m['occurrences'] for m in service_id_matches), len(set(m['file_path'] for m in service_id_matches))]
                        }
                        pd.DataFrame(overview).to_excel(writer, sheet_name='Overview', index=False)
                        pd.DataFrame(summary_data).to_excel(writer, sheet_name='Summary', index=False)
                        if detail_data:
                            pd.DataFrame(detail_data).to_excel(writer, sheet_name='Details', index=False)
                        if not_found_ids:
                            pd.DataFrame({'Service ID': not_found_ids, 'Status': ['Not Found'] * len(not_found_ids)}).to_excel(writer, sheet_name='Not Found', index=False)
                    sid_excel.seek(0)
                    st.download_button(
                        label="📥 Download Service ID Report (Excel)",
                        data=sid_excel.getvalue(),
                        file_name="service_id_scan_report.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
    
    # Reports Tab (last tab)
    with reports_tab_ref:
        st.subheader("Download Reports")
        st.markdown("*Generate comprehensive reports with all analysis*")
        
        # Prepare data for HTML report
        scan_stats = {
            'tables_found': len([t for t in table_summary_data if t['Query Count'] > 0 or t['Occurrences'] > 0]) if table_summary_data else 0,
            'attrs_in_queries': sum(t['Attributes in Queries'] for t in table_summary_data) if table_summary_data else 0,
            'coverage': (sum(t['Attributes in Queries'] for t in table_summary_data) / sum(t['Attributes in Excel'] for t in table_summary_data) * 100) if table_summary_data and sum(t['Attributes in Excel'] for t in table_summary_data) > 0 else 0
        }
        
        total_queries = sum(t['Query Count'] for t in table_summary_data) if table_summary_data else 0
        
        # Generate HTML report
        html_report = generate_html_report(
            table_summary_data=table_summary_data,
            field_summary_data=attribute_details if 'attribute_details' in dir() else [],
            table_occurrences_data=table_occurrences_data if 'table_occurrences_data' in dir() else [],
            field_occurrences_data=field_occurrences_data if 'field_occurrences_data' in dir() else [],
            total_excel_tables=total_excel_tables,
            total_excel_fields=total_excel_fields,
            total_queries=total_queries,
            scan_stats=scan_stats,
            file_stats=file_stats
        )
        
        st.markdown("""
        ### How Scanning Works
        
        1. **Excel Parsing:** The mapping file is read to extract Legacy Table names (Column 1) and Legacy Attribute names (Column 2).
        
        2. **Query Detection:** Source files (.py, .pyspark, .sh, .hql, .hive) are scanned to find SQL-like queries (SELECT, INSERT, UPDATE, etc.).
        
        3. **Table Matching:** Each query is checked for Legacy Table references.
        
        4. **Attribute Matching:** For queries containing a Legacy Table, we scan for Attributes belonging to that table.
        
        5. **Context-Aware:** Attributes are only flagged when found within their parent table's query context.
        """)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.download_button(
                label="📥 Download HTML Report",
                data=html_report,
                file_name="code_lens_report.html",
                mime="text/html"
            )
        
        with col2:
            # Generate Excel report with multiple sheets
            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                # Overview sheet
                overview_data = {
                    'Metric': ['Total Tables in Excel', 'Total Fields in Excel', 'Tables Found', 'Total Queries', 'Attributes in Queries', 'Coverage %'],
                    'Value': [total_excel_tables, total_excel_fields, scan_stats.get('tables_found', 0), total_queries, scan_stats.get('attrs_in_queries', 0), f"{scan_stats.get('coverage', 0):.1f}%"]
                }
                pd.DataFrame(overview_data).to_excel(writer, sheet_name='Overview', index=False)
                
                # Table Summary sheet
                if table_summary_data:
                    pd.DataFrame(table_summary_data).to_excel(writer, sheet_name='Table Summary', index=False)
                
                # Attribute Details sheet
                if 'attribute_details' in dir() and attribute_details:
                    pd.DataFrame(attribute_details).to_excel(writer, sheet_name='Attribute Details', index=False)
                
                # Table Occurrences sheet
                if 'table_occurrences_data' in dir() and table_occurrences_data:
                    pd.DataFrame(table_occurrences_data).to_excel(writer, sheet_name='Table Occurrences', index=False)
                
                # Field Occurrences sheet
                if 'field_occurrences_data' in dir() and field_occurrences_data:
                    pd.DataFrame(field_occurrences_data).to_excel(writer, sheet_name='Field Occurrences', index=False)
                
                # Files to Correct sheet
                if 'files_to_correct' in dir() and files_to_correct:
                    pd.DataFrame(files_to_correct).to_excel(writer, sheet_name='Files to Correct', index=False)
                
                # Config Matches sheet (if available)
                if config_matches:
                    cfg_report_data = []
                    for m in config_matches:
                        cfg_report_data.append({
                            'Legacy Table': m['table_name'],
                            'Variable': m['variable_name'] if m['variable_name'] else '',
                            'Value': m['value'] if m['value'] else '',
                            'File': m['file_name'],
                            'Path': m['file_path'],
                            'Line': m['line_number'],
                            'Content': m['line_content']
                        })
                    if cfg_report_data:
                        pd.DataFrame(cfg_report_data).to_excel(writer, sheet_name='Config Matches', index=False)
                
                if alias_map:
                    alias_report_data = []
                    for alias_name, info in alias_map.items():
                        alias_report_data.append({
                            'Variable / Alias': alias_name,
                            'Legacy Table': info['table'],
                            'Config File': info['file'],
                            'Config Value': info['value']
                        })
                    if alias_report_data:
                        pd.DataFrame(alias_report_data).to_excel(writer, sheet_name='Alias Mappings', index=False)
                
                # Service IDs sheet (if available)
                if service_id_matches:
                    service_id_data = []
                    for match in service_id_matches:
                        for detail in match['details']:
                            service_id_data.append({
                                'Service ID': match['service_id'],
                                'File': match['file_name'],
                                'Path': match['file_path'],
                                'Line': detail['line_number'],
                                'Content': detail['line_content']
                            })
                    if service_id_data:
                        pd.DataFrame(service_id_data).to_excel(writer, sheet_name='Service IDs', index=False)
            
            excel_buffer.seek(0)
            st.download_button(
                label="📥 Download Excel Report",
                data=excel_buffer.getvalue(),
                file_name="code_lens_report.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )


# Main application
st.sidebar.header("📤 Upload Files")

# Excel file upload
excel_file = st.sidebar.file_uploader(
    "Upload Excel Mapping File",
    type=['xlsx', 'xls'],
    help="Excel file with Legacy Table names in Column 1 and Field names in Column 2. Each sheet can contain different table mappings."
)

# ZIP file upload
zip_file = st.sidebar.file_uploader(
    "Upload Source Code Repository (ZIP)",
    type=['zip'],
    help="ZIP file containing PySpark, Python, or Shell project source code."
)

# Service ID input
st.sidebar.markdown("---")
st.sidebar.subheader("🔑 Service ID Search (Optional)")
service_ids_input = st.sidebar.text_area(
    "Enter Service IDs (comma-separated)",
    placeholder="e.g., SVC001, SVC002, API_KEY_123",
    height=80,
    help="Enter one or more Service IDs separated by commas. These will be searched across all files in the repository. A scan report will be generated showing found and not-found IDs."
)

# Scan button
if st.sidebar.button("🔍 Scan Repository", type="primary", use_container_width=True):
    if not excel_file:
        st.error("Please upload an Excel mapping file.")
    elif not zip_file:
        st.error("Please upload a ZIP file containing the source code repository.")
    else:
        # Parse Excel
        with st.spinner("Parsing Excel mappings..."):
            mappings, tables, fields, table_field_mapping, field_c360_mapping = parse_excel_mappings(excel_file)
        
        if mappings is None:
            st.stop()
        
        # Display Excel summary
        st.success(f"✅ Loaded {len(tables) if tables else 0} tables and {len(fields) if fields else 0} fields from {len(mappings)} sheets")
        
        # Clean up any previous temp_dir before creating new one
        if 'temp_dir' in st.session_state and st.session_state.temp_dir:
            if os.path.exists(st.session_state.temp_dir):
                shutil.rmtree(st.session_state.temp_dir, ignore_errors=True)
        
        # Extract and scan ZIP
        temp_dir = tempfile.mkdtemp()
        # Store temp_dir in session state for lineage scanner to use later
        st.session_state.temp_dir = temp_dir
        # Clear any previous lineage data
        st.session_state.lineage_graph = None
        st.session_state.scanned_lineage_files = None
        st.session_state.sql_blocks = None
        
        try:
            with st.spinner("Extracting ZIP file..."):
                if not extract_zip(zip_file, temp_dir):
                    st.stop()
            
            st.success("✅ ZIP file extracted successfully")
            
            # Scan repository (includes config file alias resolution)
            with st.spinner("Scanning repository..."):
                matches, files_scanned, all_queries, file_stats, config_matches, alias_map, alias_usages = scan_repository(temp_dir, tables, fields, table_field_mapping)
            
            alias_count = len(alias_map)
            config_count = len(config_matches)
            alias_usage_count = len(alias_usages)
            st.success(f"✅ Scanned {files_scanned} files, found {len(all_queries)} SQL queries")
            if config_count > 0 or alias_count > 0:
                st.info(f"⚙️ Config scan: {config_count} table reference(s) in config files, {alias_count} alias/variable mapping(s) discovered, {alias_usage_count} alias usage(s) traced in code")
            
            st.session_state.config_matches = config_matches
            st.session_state.alias_map = alias_map
            st.session_state.alias_usages = alias_usages
            
            # Store scan results in session state for lineage feature
            st.session_state.scan_results = {
                'matches': matches,
                'files_scanned': files_scanned,
                'all_queries': all_queries,
                'file_stats': file_stats
            }
            
            # Scan for Service IDs if provided
            service_id_matches = []
            if service_ids_input:
                service_ids = [sid.strip() for sid in service_ids_input.split(',') if sid.strip()]
                if service_ids:
                    with st.spinner(f"Scanning for {len(service_ids)} Service ID(s)..."):
                        service_id_matches = scan_repository_for_service_ids(temp_dir, service_ids)
                    
                    found_ids = set(m['service_id'] for m in service_id_matches)
                    not_found_ids = [sid for sid in service_ids if sid not in found_ids]
                    
                    st.success(f"✅ Service ID scan complete — {len(service_id_matches)} occurrence(s) across {len(found_ids)} of {len(service_ids)} Service ID(s)")
                    if not_found_ids:
                        st.warning(f"⚠️ Not found in repository: {', '.join(not_found_ids)}")
                    
                    st.session_state.service_id_matches = service_id_matches
                    st.session_state.service_ids_searched = service_ids
                else:
                    st.session_state.service_id_matches = []
                    st.session_state.service_ids_searched = []
            else:
                st.session_state.service_id_matches = []
                st.session_state.service_ids_searched = []
            
            # Display results
            st.header("📊 Scan Results")
            display_results(matches, mappings, len(tables) if tables else 0, len(fields) if fields else 0, field_c360_mapping, file_stats, service_id_matches, config_matches, alias_map, alias_usages)
            
            # Note: temp_dir is NOT cleaned up here so lineage feature can use it
            # It will be cleaned up on next scan or when session ends
            
        except Exception as e:
            st.error(f"Error during scan: {str(e)}")
            shutil.rmtree(temp_dir, ignore_errors=True)

# Instructions
if not excel_file or not zip_file:
    st.markdown("---")
    st.header("📖 How to Use Code Lens- Data Imaging")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("1️⃣ Prepare Excel Mapping File")
        st.markdown("""
        Create an Excel file with the following structure:
        - **Column 1:** Legacy Table Name
        - **Column 2:** Legacy Attribute Name
        - **Column 3:** C360_Mapping (optional)
        - Each sheet can contain mappings for different tables
        - The first row is treated as headers
        """)
        
        st.markdown("**Expected Excel Format:**")
        example_data = pd.DataFrame({
            'Legacy_Table': ['CRPS', 'CRPS', 'MNS', 'MNS', 'Triumph'],
            'Legacy_Attribute': ['firstname', 'secondName', 'email', 'city', 'age'],
            'C360_Mapping': ['360firstname', 'c360SecondName', 'email360', 'city360', '360age'],
            'Mapping_in_C360': ['Yes', 'Yes', 'Yes', 'Yes', 'Yes']
        })
        st.dataframe(example_data, use_container_width=True, hide_index=True)
        
        st.markdown("**Example Sheet Structure:**")
        st.markdown("""
        - **Sheet 1 (CRPS):** Contains CRPS table fields
        - **Sheet 2 (MNS):** Contains MNS table fields
        - **Sheet 3 (Triumph):** Contains Triumph table fields
        - Each sheet = One Legacy Table with its attributes
        """)
    
    with col2:
        st.subheader("2️⃣ Prepare Source Code Repository")
        st.markdown("""
        Create a ZIP file of your source code:
        - Supports Python (`.py`), PySpark, Shell (`.sh`) files
        - Also scans SQL, Scala, Java, and config files
        - Nested directory structures are supported
        
        **Scanned file types:**
        `.py`, `.pyspark`, `.sh`, `.sql`, `.scala`, `.java`, `.conf`, `.cfg`, `.yaml`, `.yml`, `.json`, `.txt`
        """)
    
    st.markdown("---")
    st.subheader("3️⃣ Review Results")
    st.markdown("""
    After scanning, Code Lens- Data Imaging will show:
    - **Summary by Table/Field:** All occurrences grouped by table or field name
    - **Summary by File:** All matches organized by source file
    - **Detailed Results:** Filterable table with line numbers and content
    - **Export:** Download results as CSV for further analysis
    """)

# ============== DATA LINEAGE & WORKFLOW SECTION ==============
st.markdown("---")
st.markdown("## 🔄 Data Lineage & Workflow Visualization")
st.markdown("*Scan your repository to extract table lineage, script dependencies, and generate visual diagrams*")

with st.expander("📊 Data Lineage Scanner", expanded=False):
    st.markdown("""
    This feature scans PySpark (.py, .pyspark) and SQL/HQL (.sql, .hql, .hive) files to:
    - Extract **data flow lineage** (which scripts read/write which tables)
    - Identify **script dependencies** (imports, orchestration calls)
    - Generate **visual diagrams** for architecture documentation
    """)
    
    st.markdown("### What the Diagrams Detect")
    st.markdown("""
    **Hive / HQL Patterns:**
    - `INSERT INTO` / `INSERT OVERWRITE` → target tables
    - `CREATE TABLE ... AS SELECT` → target tables
    - `FROM` / `JOIN` clauses → source tables
    - Database-qualified names (e.g., `db_name.table_name`)
    
    **PySpark Patterns:**
    - `spark.table("...")` / `spark.read.table("...")` → source tables
    - `spark.sql("...")` → embedded SQL parsed for sources & targets
    - `.write.saveAsTable("...")` / `.insertInto("...")` → target tables
    - `.write.parquet("...")` / `.csv("...")` / `.save("...")` → file path targets
    - `spark.read.parquet("...")` / `.csv("...")` / `.load("...")` → file path sources
    - Module imports and subprocess calls → script dependencies
    """)
    
    st.divider()
    
    # Lineage scanning uses the same ZIP file
    if 'scan_results' in st.session_state and st.session_state.scan_results:
        st.success("✅ Repository data available from legacy scan. Click 'Generate Lineage' to analyze.")
        
        if st.button("🔄 Generate Lineage Diagrams", key="gen_lineage"):
            if 'temp_dir' in st.session_state and os.path.exists(st.session_state.temp_dir):
                progress_bar = st.progress(0, text="Starting lineage scan...")
                status_text = st.empty()

                def update_progress(fraction, text):
                    progress_bar.progress(min(fraction, 1.0), text=text)

                status_text.info("📂 Phase 1/4: Scanning files for lineage data...")
                scanned_files, sql_blocks = scan_folder_for_lineage(
                    st.session_state.temp_dir, progress_callback=update_progress
                )

                if scanned_files:
                    status_text.info("🔗 Phase 2/4: Building lineage graph...")
                    progress_bar.progress(0.0, text="Building graph...")
                    lineage_graph = build_lineage_graph(scanned_files)
                    
                    found_tables, found_fields = get_found_tables_and_fields()
                    if found_tables:
                        lineage_graph = filter_lineage_to_found(lineage_graph, found_tables)
                        status_text.info(f"🔗 Phase 2/4: Filtered to {lineage_graph.number_of_nodes()} nodes related to {len(found_tables)} found tables...")
                    
                    progress_bar.progress(0.5, text="Graph built. Generating DOT files...")

                    if found_tables:
                        sql_blocks = filter_sql_blocks_to_found(sql_blocks, found_tables)
                    
                    st.session_state.lineage_graph = lineage_graph
                    st.session_state.scanned_lineage_files = scanned_files
                    st.session_state.sql_blocks = sql_blocks
                    st.session_state.found_tables_for_lineage = found_tables

                    status_text.info("📄 Phase 3/4: Generating and saving DOT files...")
                    output_dir = os.path.join(st.session_state.temp_dir, 'codelens_output')
                    os.makedirs(output_dir, exist_ok=True)

                    lineage_dot = generate_lineage_dot(lineage_graph)
                    lineage_dot_path = os.path.join(output_dir, 'lineage_diagram.dot')
                    with open(lineage_dot_path, 'w') as f:
                        f.write(lineage_dot)
                    progress_bar.progress(0.7, text="Lineage DOT saved. Building workflow DOT...")

                    try:
                        import graphviz as gv
                        dot = gv.Digraph('workflow', format='svg')
                        dot.attr(rankdir='TB', bgcolor='white', label='Workflow Overview',
                                 labelloc='t', fontsize='16', size='20,20', ratio='fill', dpi='150')
                        dot.attr('node', fontname='Arial', fontsize='12', style='filled')
                        dot.attr('edge', fontname='Arial', fontsize='9')
                        for node, data in lineage_graph.nodes(data=True):
                            ntype = data.get('type', '')
                            node_id = node.replace('.', '_').replace('/', '_').replace('-', '_').replace(' ', '_')
                            if ntype == 'script':
                                dot.node(node_id, label=node, shape='box', fillcolor='#AED6F1')
                            elif ntype == 'hive_table':
                                dot.node(node_id, label=node, shape='cylinder', fillcolor='#ABEBC6')
                            elif ntype == 'file_path':
                                dot.node(node_id, label=node, shape='folder', fillcolor='#F9E79F')
                        for u, v, data in lineage_graph.edges(data=True):
                            u_id = u.replace('.', '_').replace('/', '_').replace('-', '_').replace(' ', '_')
                            v_id = v.replace('.', '_').replace('/', '_').replace('-', '_').replace(' ', '_')
                            etype = data.get('type', '')
                            if etype == 'IMPORTS':
                                dot.edge(u_id, v_id, label='imports', color='#3498DB', style='dashed')
                            elif etype == 'WRITE':
                                dot.edge(u_id, v_id, label='writes', color='#E74C3C', penwidth='2')
                            elif etype == 'READ':
                                dot.edge(u_id, v_id, label='reads', color='#27AE60')
                        workflow_dot_path = os.path.join(output_dir, 'workflow_diagram.dot')
                        with open(workflow_dot_path, 'w') as f:
                            f.write(dot.source)
                    except Exception:
                        pass
                    progress_bar.progress(0.85, text="Workflow DOT saved. Generating SQL DOT files...")

                    status_text.info("📊 Phase 4/4: Generating SQL diagram DOT files...")
                    norm_blocks = []
                    for blk in sql_blocks:
                        if not isinstance(blk, dict):
                            continue
                        nb = dict(blk)
                        for key in ('sources', 'targets'):
                            raw = nb.get(key, [])
                            if not isinstance(raw, list):
                                raw = [raw] if raw else []
                            nb[key] = [(item.get('table', str(item)) if isinstance(item, dict) else str(item)) for item in raw]
                        norm_blocks.append(nb)

                    if norm_blocks:
                        all_srcs = set()
                        all_tgts = set()
                        for b in norm_blocks:
                            all_srcs.update(b.get('sources', []))
                            all_tgts.update(b.get('targets', []))
                        if found_tables:
                            all_srcs = filter_table_names_to_found(all_srcs, found_tables)
                            all_tgts = filter_table_names_to_found(all_tgts, found_tables)
                        etl_dot = ['digraph ETL {', '  rankdir=LR;', '  node [fontname="Arial"];']
                        for s in sorted(all_srcs):
                            sid = ''.join(c if c.isalnum() else '_' for c in s)
                            etl_dot.append(f'  "src_{sid}" [label="{s}", shape=box, style="rounded,filled", fillcolor="#BBDEFB"];')
                        for t in sorted(all_tgts):
                            tid = ''.join(c if c.isalnum() else '_' for c in t)
                            etl_dot.append(f'  "tgt_{tid}" [label="{t}", shape=box, style="rounded,filled", fillcolor="#C8E6C9"];')
                        for bi, b in enumerate(norm_blocks):
                            nid = f'transform_{bi}'
                            etl_dot.append(f'  "{nid}" [label="{b.get("type","SQL")}", shape=diamond, style=filled, fillcolor="#FFE0B2"];')
                            for s in b.get('sources', []):
                                if s in all_srcs:
                                    sid = ''.join(c if c.isalnum() else '_' for c in s)
                                    etl_dot.append(f'  "src_{sid}" -> "{nid}";')
                            for t in b.get('targets', []):
                                if t in all_tgts:
                                    tid = ''.join(c if c.isalnum() else '_' for c in t)
                                    etl_dot.append(f'  "{nid}" -> "tgt_{tid}";')
                        etl_dot.append('}')
                        with open(os.path.join(output_dir, 'etl_flow.dot'), 'w') as f:
                            f.write('\n'.join(etl_dot))

                        dfd_dot = ['digraph DFD {', '  rankdir=LR;', '  node [fontname="Arial"];']
                        both = all_srcs & all_tgts
                        for s in sorted(all_srcs - all_tgts):
                            sid = ''.join(c if c.isalnum() else '_' for c in s)
                            dfd_dot.append(f'  "ds_{sid}" [label="{s}", shape=box, style="rounded,filled", fillcolor="#BBDEFB"];')
                        for t in sorted(both):
                            tid = ''.join(c if c.isalnum() else '_' for c in t)
                            dfd_dot.append(f'  "ds_{tid}" [label="{t}\\n(read+write)", shape=box, style="rounded,filled", fillcolor="#FFF9C4"];')
                        for t in sorted(all_tgts - all_srcs):
                            tid = ''.join(c if c.isalnum() else '_' for c in t)
                            dfd_dot.append(f'  "ds_{tid}" [label="{t}", shape=box, style="rounded,filled", fillcolor="#C8E6C9"];')
                        dfd_dot.append('}')
                        with open(os.path.join(output_dir, 'data_flow_dfd.dot'), 'w') as f:
                            f.write('\n'.join(dfd_dot))

                        erd_dot = ['digraph ERD {', '  rankdir=LR;', '  node [fontname="Arial"];']
                        for t in sorted(all_srcs | all_tgts):
                            tid = ''.join(c if c.isalnum() else '_' for c in t)
                            erd_dot.append(f'  "erd_{tid}" [label="{t}", shape=box, style="rounded,filled", fillcolor="#E1BEE7"];')
                        erd_dot.append('}')
                        with open(os.path.join(output_dir, 'erd.dot'), 'w') as f:
                            f.write('\n'.join(erd_dot))

                    progress_bar.progress(1.0, text="✅ All DOT files generated!")
                    st.session_state['dot_output_dir'] = output_dir

                    dot_files = [f for f in os.listdir(output_dir) if f.endswith('.dot')]
                    status_text.success(f"✅ Lineage extracted from {len(scanned_files)} files — {lineage_graph.number_of_nodes()} nodes, {lineage_graph.number_of_edges()} edges. {len(dot_files)} DOT files saved to output folder.")

                    st.info(f"📁 DOT files generated: {', '.join(dot_files)}")

                    import io, zipfile as zf_mod
                    dot_zip_buffer = io.BytesIO()
                    with zf_mod.ZipFile(dot_zip_buffer, 'w', zf_mod.ZIP_DEFLATED) as zf:
                        for df in dot_files:
                            zf.write(os.path.join(output_dir, df), df)
                    dot_zip_buffer.seek(0)
                    st.download_button("📥 Download All DOT Files (ZIP)", dot_zip_buffer.getvalue(), "codelens_dot_files.zip", "application/zip", key="dl_all_dots")
                else:
                    progress_bar.progress(1.0, text="No lineage data found")
                    st.warning("No lineage data found in the repository.")
            else:
                st.error("Please scan a repository first using the Legacy Scan section above.")
    else:
        st.info("👆 First upload and scan a repository in the Legacy Scan section above, then come back here to generate lineage diagrams.")
    
    # Display lineage results if available
    if 'lineage_graph' in st.session_state and st.session_state.lineage_graph is not None:
        if isinstance(st.session_state.lineage_graph, nx.DiGraph) and st.session_state.lineage_graph.number_of_nodes() == 0:
            st.warning("No lineage data found for the tables identified in the legacy scan. The diagrams below require tables from your Excel mapping to also appear in SQL lineage (INSERT/SELECT/FROM/JOIN statements).")
    if 'lineage_graph' in st.session_state and st.session_state.lineage_graph is not None and (not isinstance(st.session_state.lineage_graph, nx.DiGraph) or st.session_state.lineage_graph.number_of_nodes() > 0):
        G = st.session_state.lineage_graph
        scanned_files = st.session_state.scanned_lineage_files
        raw_sql_blocks = st.session_state.sql_blocks or []
        sql_blocks = []
        for blk in raw_sql_blocks:
            if not isinstance(blk, dict):
                continue
            normalized = dict(blk)
            for key in ('sources', 'targets'):
                raw_list = normalized.get(key, [])
                if not isinstance(raw_list, list):
                    raw_list = [raw_list] if raw_list else []
                normalized[key] = [
                    (item.get('table', str(item)) if isinstance(item, dict) else str(item))
                    for item in raw_list
                ]
            sql_blocks.append(normalized)
        
        # Create tabs for different views
        lin_tab1, lin_tab2, lin_tab3, lin_tab4 = st.tabs(["📊 Overview", "🔀 Lineage Diagram", "🔗 Workflow Diagram", "📝 SQL Diagrams"])
        
        with lin_tab1:
            st.markdown("### Lineage Overview")
            
            found_tables_set = st.session_state.get('found_tables_for_lineage', set())
            if found_tables_set:
                st.info(f"📌 Diagrams filtered to show only **{len(found_tables_set)} found table(s)** from the legacy scan and their connected scripts/queries. Tables and queries not identified in the scan are excluded.")
            
            col1, col2, col3, col4 = st.columns(4)
            
            tables = [n for n, d in G.nodes(data=True) if d.get('type') == 'hive_table']
            paths = [n for n, d in G.nodes(data=True) if d.get('type') == 'file_path']
            scripts = [n for n, d in G.nodes(data=True) if d.get('type') == 'script']
            
            with col1:
                st.metric("Scripts", len(scripts))
            with col2:
                st.metric("Tables", len(tables))
            with col3:
                st.metric("File Paths", len(paths))
            with col4:
                st.metric("SQL Blocks", len(sql_blocks))
            
            st.divider()
            
            # Top tables by connections
            st.markdown("### Top Tables by Connections")
            table_connections = []
            for table in tables:
                in_deg = G.in_degree(table)
                out_deg = G.out_degree(table)
                table_connections.append({
                    'Table': table,
                    'Read By': in_deg,
                    'Written By': out_deg,
                    'Total': in_deg + out_deg
                })
            
            if table_connections:
                conn_df = pd.DataFrame(table_connections).sort_values('Total', ascending=False).head(20)
                st.dataframe(conn_df, use_container_width=True, hide_index=True)
            
            st.divider()
            
            st.markdown("### Scripts with Lineage (Found Tables Only)")
            graph_scripts = set(n for n, d in G.nodes(data=True) if d.get('type') == 'script')
            script_summary = []
            for f in scanned_files:
                if found_tables_set and f['file_path'] not in graph_scripts:
                    continue
                script_summary.append({
                    'Script': f['file_path'],
                    'Reads': len(f.get('sources', [])),
                    'Writes': len(f.get('targets', [])),
                    'Imports': len(f.get('imports', [])),
                    'SQL Blocks': len(f.get('sql_blocks', []))
                })
            
            if script_summary:
                script_df = pd.DataFrame(script_summary).sort_values('Reads', ascending=False)
                st.dataframe(script_df, use_container_width=True, hide_index=True, height=300)
            
            # Export options
            st.divider()
            st.markdown("### Export")
            
            # Export as JSON
            export_data = {
                'nodes': [{'id': n, **d} for n, d in G.nodes(data=True)],
                'edges': [{'from': u, 'to': v, **d} for u, v, d in G.edges(data=True)]
            }
            
            import json
            json_str = json.dumps(export_data, indent=2)
            st.download_button(
                label="📥 Download Lineage as JSON",
                data=json_str,
                file_name="lineage_graph.json",
                mime="application/json"
            )
        
        with lin_tab2:
            st.markdown("### Data Lineage Diagram")
            st.markdown("*Tables and file paths read/written by scripts — filtered to found tables only*")

            node_count = G.number_of_nodes()
            if node_count > 200:
                st.warning(f"⚠️ Large graph ({node_count} nodes). Use filters below to focus on a subset for faster rendering.")

            col1, col2, col3 = st.columns(3)
            with col1:
                filter_keyword = st.text_input("Filter by keyword", key="lineage_filter", placeholder="e.g., staging, raw")
            with col2:
                center_node = st.selectbox("Center on node", options=[''] + list(G.nodes()), key="center_node")
            with col3:
                max_hops = st.slider("Max hops from center", 1, 5, 2, key="max_hops")

            try:
                lin_progress = st.progress(0, text="Generating lineage DOT...")
                dot_string = generate_lineage_dot(
                    G,
                    filter_keyword=filter_keyword if filter_keyword else None,
                    center_node=center_node if center_node else None,
                    max_hops=max_hops if center_node else None
                )
                lin_progress.progress(50, text="Rendering diagram...")

                st.graphviz_chart(dot_string, use_container_width=True)
                lin_progress.progress(100, text="✅ Lineage diagram ready")

                st.download_button(
                    label="📥 Download DOT file",
                    data=dot_string,
                    file_name="lineage.dot",
                    mime="text/plain"
                )
            except Exception as e:
                st.error(f"Error generating diagram: {str(e)}")
                if 'dot_string' in dir():
                    st.text("DOT string for manual rendering:")
                    st.code(dot_string, language="dot")
        
        with lin_tab3:
            st.markdown("### Workflow / Control Flow Diagram")
            st.markdown("*Script dependencies and orchestration — filtered to scripts impacting found tables*")
            
            include_tables = st.checkbox("Include tables in workflow", value=False, key="workflow_tables")

            try:
                import graphviz as gv

                wf_progress = st.progress(0, text="Building workflow graph...")

                dot = gv.Digraph('workflow', format='svg')
                dot.attr(rankdir='TB', bgcolor='white', label='Workflow Overview',
                         labelloc='t', fontsize='16', size='20,20', ratio='fill',
                         dpi='150')
                dot.attr('node', fontname='Arial', fontsize='12', style='filled')
                dot.attr('edge', fontname='Arial', fontsize='9')

                added_nodes = set()
                all_nodes = list(G.nodes(data=True))
                total_nodes = len(all_nodes) or 1

                for ni, (node, data) in enumerate(all_nodes):
                    ntype = data.get('type', '')
                    node_id = node.replace('.', '_').replace('/', '_').replace('-', '_').replace(' ', '_')

                    if ntype == 'script':
                        dot.node(node_id, label=node, shape='box', fillcolor='#AED6F1')
                        added_nodes.add(node)
                    elif ntype == 'hive_table' and include_tables:
                        dot.node(node_id, label=node, shape='cylinder', fillcolor='#ABEBC6')
                        added_nodes.add(node)
                    elif ntype == 'file_path' and include_tables:
                        dot.node(node_id, label=node, shape='folder', fillcolor='#F9E79F')
                        added_nodes.add(node)

                    if (ni + 1) % 50 == 0 or ni == total_nodes - 1:
                        wf_progress.progress(int(30 * (ni + 1) / total_nodes), text=f"Adding nodes {ni+1}/{total_nodes}...")

                wf_progress.progress(30, text="Adding edges...")
                for u, v, data in G.edges(data=True):
                    if u in added_nodes and v in added_nodes:
                        rel = data.get('relation', '')
                        u_id = u.replace('.', '_').replace('/', '_').replace('-', '_').replace(' ', '_')
                        v_id = v.replace('.', '_').replace('/', '_').replace('-', '_').replace(' ', '_')

                        edge_attrs = {}
                        if rel == 'imports':
                            edge_attrs = dict(label='imports', color='#3498DB', style='dashed')
                        elif rel == 'orchestrates':
                            edge_attrs = dict(label='calls', color='#E74C3C', penwidth='2')
                        elif rel == 'reads':
                            edge_attrs = dict(label='reads', color='#27AE60')
                        elif rel == 'writes':
                            edge_attrs = dict(label='writes', color='#E67E22')
                        else:
                            edge_attrs = dict(label=rel)
                        dot.edge(u_id, v_id, **edge_attrs)

                wf_progress.progress(50, text="Rendering SVG (this may take a moment for large graphs)...")
                svg_data = dot.pipe(format='svg').decode('utf-8')
                wf_progress.progress(90, text="Displaying diagram...")

                workflow_html = f'''
                <div style="width:100%; height:900px; overflow:auto; border:1px solid #ddd; border-radius:8px; background:#fff; padding:10px;">
                    {svg_data}
                </div>
                '''
                components.html(workflow_html, height=920, scrolling=False)
                wf_progress.progress(100, text="✅ Workflow diagram ready")
                
                workflow_dot = dot.source
                col_dl1, col_dl2 = st.columns(2)
                with col_dl1:
                    st.download_button(
                        label="Download Workflow DOT file",
                        data=workflow_dot,
                        file_name="workflow.dot",
                        mime="text/plain",
                        key="dl_workflow_dot"
                    )
                with col_dl2:
                    st.download_button(
                        label="Download Workflow SVG",
                        data=svg_data,
                        file_name="workflow.svg",
                        mime="image/svg+xml",
                        key="dl_workflow_svg"
                    )
                
            except Exception as e:
                st.error(f"Error generating workflow diagram: {str(e)}")
        
        with lin_tab4:
            st.markdown("### SQL / HQL Diagrams")
            
            if found_tables_set:
                st.info(f"📌 Showing only SQL blocks that reference the {len(found_tables_set)} found table(s) from the legacy scan.")
            
            if sql_blocks:
                def safe_id(s):
                    return ''.join(c if c.isalnum() else '_' for c in str(s))
                
                def get_fields_for_table(table_name):
                    fields = []
                    if st.session_state.get('scan_results'):
                        for res in st.session_state['scan_results']:
                            if isinstance(res, str):
                                tbl = res.lower()
                                field = ''
                            elif isinstance(res, dict):
                                tbl = res.get('Table', '').lower()
                                field = res.get('Field/Attribute', '')
                            else:
                                continue
                            if tbl == table_name.lower() or table_name.lower().endswith(f".{tbl}"):
                                if field and field not in fields:
                                    fields.append(field)
                    return fields
                
                def get_block_sources(block):
                    raw = block.get('sources', []) if isinstance(block, dict) else []
                    return [s if isinstance(s, str) else s.get('table', str(s)) for s in raw]
                
                def get_block_targets(block):
                    raw = block.get('targets', []) if isinstance(block, dict) else []
                    return [t if isinstance(t, str) else t.get('table', str(t)) for t in raw]
                
                def cytoscape_html(elements_json, layout='dagre', height=800, title='', directed=True):
                    import json
                    if not elements_json:
                        return '<html><body><p style="text-align:center;padding:40px;color:#666;">No data to display in this diagram.</p></body></html>'
                    el_str = json.dumps(elements_json)
                    safe_title = title.replace("'", "\\'").replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')
                    arrow_style = "'triangle'" if directed else "'none'"
                    return f'''
                    <!DOCTYPE html>
                    <html><head>
                    <script src="https://unpkg.com/cytoscape@3.28.1/dist/cytoscape.min.js"></script>
                    <script src="https://unpkg.com/dagre@0.8.5/dist/dagre.min.js"></script>
                    <script src="https://unpkg.com/cytoscape-dagre@2.5.0/cytoscape-dagre.js"></script>
                    <style>
                      body {{ margin:0; padding:0; font-family:Arial,sans-serif; }}
                      #cy {{ width:100%; height:{height-40}px; border:1px solid #ddd; border-radius:8px; background:#fafafa; }}
                      .title {{ text-align:center; font-size:15px; font-weight:bold; color:#333; padding:8px 0; }}
                      .legend {{ position:absolute; bottom:10px; right:10px; background:rgba(255,255,255,0.9); padding:8px 12px; border-radius:6px; border:1px solid #ddd; font-size:11px; z-index:10; }}
                    </style>
                    </head><body>
                    <div class="title">{safe_title}</div>
                    <div id="cy"></div>
                    <script>
                      var cy = cytoscape({{
                        container: document.getElementById('cy'),
                        elements: {el_str},
                        layout: {{ name: '{layout}', rankDir: 'LR', nodeSep: 50, rankSep: 80, edgeSep: 20, padding: 30 }},
                        style: [
                          {{ selector: 'node', style: {{
                            'label': 'data(label)',
                            'text-wrap': 'wrap',
                            'text-max-width': '180px',
                            'font-size': '10px',
                            'text-valign': 'center',
                            'text-halign': 'center',
                            'background-color': 'data(color)',
                            'border-width': 2,
                            'border-color': 'data(borderColor)',
                            'shape': 'data(shape)',
                            'width': 'label',
                            'height': 'label',
                            'padding': '12px'
                          }} }},
                          {{ selector: 'node[nodeType="table"]', style: {{
                            'shape': 'barrel',
                            'width': 'label',
                            'padding': '14px'
                          }} }},
                          {{ selector: 'node[nodeType="process"]', style: {{
                            'shape': 'round-rectangle',
                            'width': 'label',
                            'padding': '14px'
                          }} }},
                          {{ selector: 'node[nodeType="file"]', style: {{
                            'shape': 'rectangle',
                            'width': 'label',
                            'padding': '14px'
                          }} }},
                          {{ selector: 'node[nodeType="start"]', style: {{
                            'shape': 'ellipse',
                            'width': 60,
                            'height': 40
                          }} }},
                          {{ selector: 'node[nodeType="end"]', style: {{
                            'shape': 'ellipse',
                            'width': 60,
                            'height': 40
                          }} }},
                          {{ selector: 'node[nodeType="conditional"]', style: {{
                            'shape': 'diamond',
                            'width': 'label',
                            'padding': '16px'
                          }} }},
                          {{ selector: 'edge', style: {{
                            'label': 'data(label)',
                            'font-size': '9px',
                            'curve-style': 'bezier',
                            'target-arrow-shape': {arrow_style},
                            'target-arrow-color': 'data(color)',
                            'line-color': 'data(color)',
                            'width': 'data(width)',
                            'text-background-color': '#fff',
                            'text-background-opacity': 0.8,
                            'text-background-padding': '2px'
                          }} }}
                        ],
                        minZoom: 0.2,
                        maxZoom: 3,
                        wheelSensitivity: 0.3
                      }});
                      cy.on('tap', 'node', function(evt) {{
                        var node = evt.target;
                        var info = node.data('info') || '';
                        if (info) {{ alert(node.data('label') + '\\n\\n' + info); }}
                      }});
                    </script>
                    </body></html>
                    '''
                
                def elements_to_dot(elements, title='Diagram', directed=True):
                    arrow = '->' if directed else '--'
                    graph_type = 'digraph' if directed else 'graph'
                    safe = lambda s: s.replace('"', '\\"').replace('\n', '\\n')
                    dot = [f'{graph_type} "{safe(title)}" {{', '  rankdir=LR;', '  node [fontname="Arial", fontsize=10];', '  edge [fontname="Arial", fontsize=8];']
                    for el in elements:
                        d = el.get('data', {})
                        if 'source' in d and 'target' in d:
                            lbl = safe(d.get('label', ''))
                            color = d.get('color', '#333333')
                            dot.append(f'  "{safe(d["source"])}" {arrow} "{safe(d["target"])}" [label="{lbl}", color="{color}"];')
                        elif 'id' in d:
                            lbl = safe(d.get('label', d['id']))
                            color = d.get('color', '#FFFFFF')
                            border = d.get('borderColor', '#333333')
                            shape = {'barrel': 'cylinder', 'round-rectangle': 'box', 'diamond': 'diamond'}.get(d.get('shape', ''), 'box')
                            dot.append(f'  "{safe(d["id"])}" [label="{lbl}", shape={shape}, style="rounded,filled", fillcolor="{color}", color="{border}"];')
                    dot.append('}')
                    return '\n'.join(dot)
                
                found_tables_set = st.session_state.get('found_tables_for_lineage', set())
                
                files_with_blocks = {}
                all_sources_global = set()
                all_targets_global = set()
                for block in sql_blocks:
                    if not isinstance(block, dict):
                        continue
                    fname = block.get('file', 'Unknown')
                    if fname not in files_with_blocks:
                        files_with_blocks[fname] = []
                    files_with_blocks[fname].append(block)
                    all_sources_global.update(get_block_sources(block))
                    all_targets_global.update(get_block_targets(block))
                
                if found_tables_set:
                    all_sources_global = filter_table_names_to_found(all_sources_global, found_tables_set)
                    all_targets_global = filter_table_names_to_found(all_targets_global, found_tables_set)
                
                sql_sub1, sql_sub2, sql_sub3, sql_sub4, sql_sub5 = st.tabs([
                    "ETL Flow", "Data Flow (DFD)", "Query Dependency", "ERD", "Control Flow"
                ])
                
                # ── ETL Flow Diagram ──
                with sql_sub1:
                    st.markdown("#### ETL Flow Diagram")
                    st.markdown("*Extract → Transform → Load pipeline showing data movement through stages*")
                    
                    try:
                        elements = []
                        
                        for src in sorted(all_sources_global):
                            fields = get_fields_for_table(src)
                            fl = '\n'.join(fields[:8]) if fields else ''
                            lbl = f"{src}\n{'─'*10}\n{fl}" if fl else src
                            if len(fields) > 8:
                                lbl += f"\n+{len(fields)-8} more"
                            elements.append({'data': {'id': f'e_{safe_id(src)}', 'label': lbl, 'color': '#BBDEFB', 'borderColor': '#1976D2', 'shape': 'barrel', 'nodeType': 'table', 'info': f'Source table: {src}\nFields: {len(fields)}'}})
                        
                        for fname, blocks in files_with_blocks.items():
                            for bi, block in enumerate(blocks):
                                if not isinstance(block, dict):
                                    continue
                                qtype = block.get('type', 'SQL')
                                preview = block.get('sql', '')[:60].replace('\n', ' ')
                                nid = f't_{safe_id(fname)}_{bi}'
                                elements.append({'data': {'id': nid, 'label': f"{qtype}\n{fname}\n{preview}...", 'color': '#FFE0B2', 'borderColor': '#E65100', 'shape': 'round-rectangle', 'nodeType': 'process', 'info': f'File: {fname}\nType: {qtype}\nSQL: {block.get("sql", "")[:200]}'}})
                        
                        for tgt in sorted(all_targets_global):
                            fields = get_fields_for_table(tgt)
                            fl = '\n'.join(fields[:8]) if fields else ''
                            lbl = f"{tgt}\n{'─'*10}\n{fl}" if fl else tgt
                            if len(fields) > 8:
                                lbl += f"\n+{len(fields)-8} more"
                            elements.append({'data': {'id': f'l_{safe_id(tgt)}', 'label': lbl, 'color': '#C8E6C9', 'borderColor': '#388E3C', 'shape': 'barrel', 'nodeType': 'table', 'info': f'Target table: {tgt}\nFields: {len(fields)}'}})
                        
                        edge_idx = 0
                        for fname, blocks in files_with_blocks.items():
                            for bi, block in enumerate(blocks):
                                t_id = f't_{safe_id(fname)}_{bi}'
                                for src in get_block_sources(block):
                                    if src in all_sources_global:
                                        elements.append({'data': {'id': f'ee_{edge_idx}', 'source': f'e_{safe_id(src)}', 'target': t_id, 'label': 'extract', 'color': '#1976D2', 'width': 2}})
                                        edge_idx += 1
                                for tgt in get_block_targets(block):
                                    if tgt in all_targets_global:
                                        elements.append({'data': {'id': f'ee_{edge_idx}', 'source': t_id, 'target': f'l_{safe_id(tgt)}', 'label': 'load', 'color': '#388E3C', 'width': 2}})
                                        edge_idx += 1
                        
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Source Tables", len(all_sources_global))
                        with col2:
                            st.metric("Transform Blocks", sum(len(b) for b in files_with_blocks.values()))
                        with col3:
                            st.metric("Target Tables", len(all_targets_global))
                        
                        components.html(cytoscape_html(elements, 'dagre', 850, 'ETL Flow: Extract → Transform → Load'), height=870)
                        
                        dot_str = elements_to_dot(elements, 'ETL Flow')
                        st.download_button("📥 Download DOT file", dot_str, "etl_flow.dot", "text/plain", key="dl_etl_dot")
                        
                    except Exception as e:
                        import traceback
                        st.error(f"Error generating ETL Flow: {str(e)}")
                        st.code(traceback.format_exc())
                
                # ── Data Flow Diagram (DFD) ──
                with sql_sub2:
                    st.markdown("#### Data Flow Diagram (DFD)")
                    st.markdown("*How data moves between data stores and processes*")
                    
                    try:
                        elements = []
                        tables_as_both = all_sources_global & all_targets_global
                        only_sources = all_sources_global - all_targets_global
                        only_targets = all_targets_global - all_sources_global
                        
                        for src in sorted(only_sources):
                            fields = get_fields_for_table(src)
                            fl = '\n'.join(fields[:6]) if fields else ''
                            lbl = f"{src}\n{fl}" if fl else src
                            elements.append({'data': {'id': f'ds_{safe_id(src)}', 'label': lbl, 'color': '#BBDEFB', 'borderColor': '#1565C0', 'nodeType': 'table', 'info': f'Source only: {src}'}})
                        
                        for tbl in sorted(tables_as_both):
                            fields = get_fields_for_table(tbl)
                            fl = '\n'.join(fields[:6]) if fields else ''
                            lbl = f"{tbl}\n(read+write)\n{fl}" if fl else f"{tbl}\n(read+write)"
                            elements.append({'data': {'id': f'ds_{safe_id(tbl)}', 'label': lbl, 'color': '#FFF9C4', 'borderColor': '#F57F17', 'nodeType': 'table', 'info': f'Read and written: {tbl}'}})
                        
                        for tgt in sorted(only_targets):
                            fields = get_fields_for_table(tgt)
                            fl = '\n'.join(fields[:6]) if fields else ''
                            lbl = f"{tgt}\n{fl}" if fl else tgt
                            elements.append({'data': {'id': f'ds_{safe_id(tgt)}', 'label': lbl, 'color': '#C8E6C9', 'borderColor': '#2E7D32', 'nodeType': 'table', 'info': f'Target only: {tgt}'}})
                        
                        edge_idx = 0
                        for fname, blocks in files_with_blocks.items():
                            proc_id = f'proc_{safe_id(fname)}'
                            n_blocks = len(blocks)
                            types = set(b.get('type', '') if isinstance(b, dict) else str(b) for b in blocks)
                            elements.append({'data': {'id': proc_id, 'label': f"{fname}\n({', '.join(types)})\n[{n_blocks} queries]", 'color': '#FFE0B2', 'borderColor': '#E65100', 'nodeType': 'process', 'info': f'Process: {fname}\nQuery types: {", ".join(types)}\nBlocks: {n_blocks}'}})
                            
                            file_sources = set()
                            file_targets = set()
                            for block in blocks:
                                file_sources.update(get_block_sources(block))
                                file_targets.update(get_block_targets(block))
                            
                            all_found_tables = all_sources_global | all_targets_global
                            for src in file_sources:
                                if src in all_found_tables:
                                    elements.append({'data': {'id': f'de_{edge_idx}', 'source': f'ds_{safe_id(src)}', 'target': proc_id, 'label': 'data in', 'color': '#1565C0', 'width': 2}})
                                    edge_idx += 1
                            for tgt in file_targets:
                                if tgt in all_found_tables:
                                    elements.append({'data': {'id': f'de_{edge_idx}', 'source': proc_id, 'target': f'ds_{safe_id(tgt)}', 'label': 'data out', 'color': '#2E7D32', 'width': 2}})
                                    edge_idx += 1
                        
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Source-Only Tables", len(only_sources))
                        with col2:
                            st.metric("Read+Write Tables", len(tables_as_both))
                        with col3:
                            st.metric("Target-Only Tables", len(only_targets))
                        
                        components.html(cytoscape_html(elements, 'dagre', 850, 'Data Flow Diagram'), height=870)
                        
                        dot_str = elements_to_dot(elements, 'Data Flow Diagram')
                        st.download_button("📥 Download DOT file", dot_str, "dfd.dot", "text/plain", key="dl_dfd_dot")
                        
                    except Exception as e:
                        import traceback
                        st.error(f"Error generating DFD: {str(e)}")
                        st.code(traceback.format_exc())
                
                # ── Query Dependency Graph ──
                with sql_sub3:
                    st.markdown("#### Query Dependency Graph")
                    st.markdown("*Which queries depend on the output of other queries (shared tables)*")
                    
                    try:
                        elements = []
                        query_nodes = []
                        query_targets_map = {}
                        query_sources_map = {}
                        
                        for fname, blocks in files_with_blocks.items():
                            for bi, block in enumerate(blocks):
                                if not isinstance(block, dict):
                                    continue
                                qid = f'qd_{safe_id(fname)}_{bi}'
                                qtype = block.get('type', 'SQL')
                                preview = block.get('sql', '')[:50].replace('\n', ' ')
                                query_nodes.append(qid)
                                block_tgts = set(get_block_targets(block))
                                block_srcs = set(get_block_sources(block))
                                if found_tables_set:
                                    block_tgts = filter_table_names_to_found(block_tgts, found_tables_set)
                                    block_srcs = filter_table_names_to_found(block_srcs, found_tables_set)
                                query_targets_map[qid] = block_tgts
                                query_sources_map[qid] = block_srcs
                                elements.append({'data': {'id': qid, 'label': f"{qtype}\n{fname}\nBlock #{bi+1}\n{preview}...", 'color': '#E1BEE7', 'borderColor': '#6A1B9A', 'nodeType': 'process', 'info': f'File: {fname}\nType: {qtype}\nSources: {", ".join(get_block_sources(block))}\nTargets: {", ".join(get_block_targets(block))}'}})
                        
                        dep_edges = set()
                        edge_idx = 0
                        for qid_a in query_nodes:
                            for qid_b in query_nodes:
                                if qid_a != qid_b:
                                    shared = query_targets_map.get(qid_a, set()) & query_sources_map.get(qid_b, set())
                                    if shared:
                                        edge_key = (qid_a, qid_b)
                                        if edge_key not in dep_edges:
                                            dep_edges.add(edge_key)
                                            elements.append({'data': {'id': f'dep_{edge_idx}', 'source': qid_a, 'target': qid_b, 'label': f'via: {", ".join(list(shared)[:2])}', 'color': '#6A1B9A', 'width': 3}})
                                            edge_idx += 1
                        
                        shared_tables = set()
                        for targets in query_targets_map.values():
                            for sources in query_sources_map.values():
                                shared_tables.update(targets & sources)
                        if found_tables_set:
                            shared_tables = filter_table_names_to_found(shared_tables, found_tables_set)
                        
                        for tbl in sorted(shared_tables):
                            elements.append({'data': {'id': f'sh_{safe_id(tbl)}', 'label': f"{tbl}\n(shared)", 'color': '#FFF9C4', 'borderColor': '#F57F17', 'nodeType': 'table', 'info': f'Shared table: {tbl}'}})
                        
                        indep_queries = [q for q in query_nodes if not any(q == e[0] or q == e[1] for e in dep_edges)]
                        
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Total Queries", len(query_nodes))
                        with col2:
                            st.metric("Dependencies", len(dep_edges))
                        with col3:
                            st.metric("Independent", len(indep_queries))
                        
                        components.html(cytoscape_html(elements, 'dagre', 850, 'Query Dependency Graph'), height=870)
                        
                        dot_str = elements_to_dot(elements, 'Query Dependency Graph')
                        st.download_button("📥 Download DOT", dot_str, "query_dependency.dot", "text/plain", key="dl_qd_dot")
                        
                    except Exception as e:
                        import traceback
                        st.error(f"Error generating Query Dependency Graph: {str(e)}")
                        st.code(traceback.format_exc())
                
                # ── Entity Relationship Diagram (ERD) ──
                with sql_sub4:
                    st.markdown("#### Entity Relationship Diagram (ERD)")
                    st.markdown("*Tables and their fields with relationships inferred from SQL joins*")
                    
                    try:
                        elements = []
                        all_tables = sorted(all_sources_global | all_targets_global)
                        
                        for tbl in all_tables:
                            fields = get_fields_for_table(tbl)
                            tbl_name = tbl.split('.')[-1] if '.' in tbl else tbl
                            schema = tbl.rsplit('.', 1)[0] if '.' in tbl else ''
                            
                            field_lines = []
                            for f in fields[:15]:
                                is_key = any(k in f.lower() for k in ['_id', '_key', '_pk', '_fk', 'id'])
                                prefix = 'PK ' if is_key else '   '
                                field_lines.append(f"{prefix}{f}")
                            if len(fields) > 15:
                                field_lines.append(f"   +{len(fields)-15} more")
                            
                            lbl_parts = [tbl_name]
                            if schema:
                                lbl_parts.append(f"[{schema}]")
                            lbl_parts.append('─' * max(len(tbl_name), 10))
                            lbl_parts.extend(field_lines if field_lines else ['(no fields)'])
                            
                            is_src = tbl in all_sources_global
                            is_tgt = tbl in all_targets_global
                            if is_src and is_tgt:
                                color = '#FFF9C4'
                                border = '#F57F17'
                            elif is_tgt:
                                color = '#C8E6C9'
                                border = '#2E7D32'
                            else:
                                color = '#BBDEFB'
                                border = '#1565C0'
                            
                            elements.append({'data': {'id': f'erd_{safe_id(tbl)}', 'label': '\n'.join(lbl_parts), 'color': color, 'borderColor': border, 'nodeType': 'file', 'info': f'Table: {tbl}\nSchema: {schema or "N/A"}\nFields: {len(fields)}\n\nAll fields:\n' + chr(10).join(fields)}})
                        
                        erd_edges = set()
                        edge_idx = 0
                        erd_table_set = set(all_tables)
                        for block in sql_blocks:
                            if not isinstance(block, dict):
                                continue
                            srcs = [s for s in get_block_sources(block) if s in erd_table_set]
                            tgts = [t for t in get_block_targets(block) if t in erd_table_set]
                            sql_text = block.get('sql', '').upper()
                            
                            if 'JOIN' in sql_text:
                                for i, s1 in enumerate(srcs):
                                    for s2 in srcs[i+1:]:
                                        edge_key = tuple(sorted([s1, s2]))
                                        if edge_key not in erd_edges:
                                            erd_edges.add(edge_key)
                                            elements.append({'data': {'id': f'erde_{edge_idx}', 'source': f'erd_{safe_id(s1)}', 'target': f'erd_{safe_id(s2)}', 'label': 'JOIN', 'color': '#E65100', 'width': 3}})
                                            edge_idx += 1
                            
                            for src in srcs:
                                for tgt in tgts:
                                    edge_key = (src, tgt)
                                    if edge_key not in erd_edges:
                                        erd_edges.add(edge_key)
                                        elements.append({'data': {'id': f'erde_{edge_idx}', 'source': f'erd_{safe_id(src)}', 'target': f'erd_{safe_id(tgt)}', 'label': 'feeds', 'color': '#1565C0', 'width': 1.5}})
                                        edge_idx += 1
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            st.metric("Tables", len(all_tables))
                        with col2:
                            st.metric("Relationships", len(erd_edges))
                        
                        components.html(cytoscape_html(elements, 'dagre', 850, 'Entity Relationship Diagram'), height=870)
                        
                        dot_str = elements_to_dot(elements, 'Entity Relationship Diagram')
                        st.download_button("📥 Download DOT", dot_str, "erd.dot", "text/plain", key="dl_erd_dot")
                        
                    except Exception as e:
                        import traceback
                        st.error(f"Error generating ERD: {str(e)}")
                        st.code(traceback.format_exc())
                
                # ── Control Flow Diagram ──
                with sql_sub5:
                    st.markdown("#### Control Flow Diagram")
                    st.markdown("*Execution order of SQL blocks within each file*")
                    
                    try:
                        file_list = sorted(files_with_blocks.keys())
                        sel_file = st.selectbox("Select file for control flow", file_list, key="cf_file_sel")
                        
                        if sel_file:
                            blocks_in_file = files_with_blocks[sel_file]
                            elements = []
                            
                            elements.append({'data': {'id': 'start', 'label': 'START', 'color': '#C8E6C9', 'borderColor': '#2E7D32', 'nodeType': 'start'}})
                            
                            prev_id = 'start'
                            edge_idx = 0
                            for bi, block in enumerate(blocks_in_file):
                                if not isinstance(block, dict):
                                    continue
                                qtype = block.get('type', 'SQL')
                                sql_text = block.get('sql', '')
                                preview = sql_text[:80].replace('\n', ' ')
                                
                                srcs = get_block_sources(block)
                                tgts = get_block_targets(block)
                                if found_tables_set:
                                    srcs = [s for s in srcs if s in (all_sources_global | all_targets_global)]
                                    tgts = [t for t in tgts if t in (all_sources_global | all_targets_global)]
                                src_str = ', '.join(srcs[:3]) if srcs else 'N/A'
                                tgt_str = ', '.join(tgts[:3]) if tgts else 'N/A'
                                
                                block_id = f'cf_{bi}'
                                
                                is_conditional = any(kw in sql_text.upper() for kw in ['IF ', 'CASE ', 'WHEN ', 'EXISTS'])
                                is_loop = any(kw in sql_text.upper() for kw in ['LOOP', 'WHILE', 'CURSOR', 'FETCH'])
                                
                                if is_conditional:
                                    node_type = 'conditional'
                                    color = '#FFF3E0'
                                    border = '#E65100'
                                    prefix = 'COND'
                                elif is_loop:
                                    node_type = 'process'
                                    color = '#F3E5F5'
                                    border = '#6A1B9A'
                                    prefix = 'LOOP'
                                else:
                                    node_type = 'process'
                                    color = '#E3F2FD'
                                    border = '#1565C0'
                                    prefix = qtype
                                
                                lbl = f"{prefix} #{bi+1}\n{preview}...\n{'─'*15}\nReads: {src_str}\nWrites: {tgt_str}"
                                elements.append({'data': {'id': block_id, 'label': lbl, 'color': color, 'borderColor': border, 'nodeType': node_type, 'info': f'Block #{bi+1}\nType: {qtype}\nFull SQL:\n{sql_text[:500]}'}})
                                
                                elements.append({'data': {'id': f'cfe_{edge_idx}', 'source': prev_id, 'target': block_id, 'label': f'step {bi+1}', 'color': '#455A64', 'width': 2}})
                                edge_idx += 1
                                prev_id = block_id
                            
                            elements.append({'data': {'id': 'end', 'label': 'END', 'color': '#FFCDD2', 'borderColor': '#C62828', 'nodeType': 'end'}})
                            elements.append({'data': {'id': f'cfe_{edge_idx}', 'source': prev_id, 'target': 'end', 'label': 'done', 'color': '#455A64', 'width': 2}})
                            
                            st.metric("SQL Blocks in File", len(blocks_in_file))
                            
                            cf_layout = 'dagre'
                            components.html(cytoscape_html(elements, cf_layout, 850, f'Control Flow: {sel_file}'), height=870)
                            
                            dot_str = elements_to_dot(elements, f'Control Flow: {sel_file}')
                            st.download_button("📥 Download DOT", dot_str, f"control_flow_{sel_file.replace('/', '_')}.dot", "text/plain", key="dl_cf_dot")
                        
                    except Exception as e:
                        import traceback
                        st.error(f"Error generating Control Flow: {str(e)}")
                        st.code(traceback.format_exc())
                
            else:
                st.info("No SQL blocks found in the scanned files.")
