import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Database, Key, CheckCircle, XCircle, Loader2, ExternalLink, Shield, Server } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface ConfigStatus {
  database: {
    configured: boolean;
    connected: boolean;
    error?: string;
    host?: string;
  };
  openai: {
    configured: boolean;
    valid: boolean;
    error?: string;
  };
}

export default function SetupPage() {
  const { toast } = useToast();
  const [databaseUrl, setDatabaseUrl] = useState("");
  const [openaiKey, setOpenaiKey] = useState("");
  const [showDatabaseUrl, setShowDatabaseUrl] = useState(false);
  const [showOpenaiKey, setShowOpenaiKey] = useState(false);

  const { data: configStatus, isLoading: statusLoading } = useQuery<ConfigStatus>({
    queryKey: ["/api/config/status"],
  });

  const testDatabaseMutation = useMutation({
    mutationFn: async (url: string) => {
      return apiRequest("POST", "/api/config/test-database", { databaseUrl: url });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/config/status"] });
      toast({
        title: "Database Connected",
        description: "Successfully connected to the PostgreSQL database.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Connection Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const testOpenAIMutation = useMutation({
    mutationFn: async (key: string) => {
      return apiRequest("POST", "/api/config/test-openai", { apiKey: key });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/config/status"] });
      toast({
        title: "OpenAI API Valid",
        description: "Successfully validated OpenAI API key.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Validation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const saveDatabaseMutation = useMutation({
    mutationFn: async (url: string) => {
      return apiRequest("POST", "/api/config/save-database", { databaseUrl: url });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/config/status"] });
      setDatabaseUrl("");
      toast({
        title: "Database Saved",
        description: "Database configuration saved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Save Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const saveOpenAIMutation = useMutation({
    mutationFn: async (key: string) => {
      return apiRequest("POST", "/api/config/save-openai", { apiKey: key });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/config/status"] });
      setOpenaiKey("");
      toast({
        title: "OpenAI Key Saved",
        description: "OpenAI API key saved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Save Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleTestDatabase = () => {
    if (!databaseUrl.trim()) {
      toast({
        title: "Missing URL",
        description: "Please enter a database URL to test.",
        variant: "destructive",
      });
      return;
    }
    testDatabaseMutation.mutate(databaseUrl);
  };

  const handleSaveDatabase = () => {
    if (!databaseUrl.trim()) {
      toast({
        title: "Missing URL",
        description: "Please enter a database URL to save.",
        variant: "destructive",
      });
      return;
    }
    saveDatabaseMutation.mutate(databaseUrl);
  };

  const handleTestOpenAI = () => {
    if (!openaiKey.trim()) {
      toast({
        title: "Missing API Key",
        description: "Please enter an OpenAI API key to test.",
        variant: "destructive",
      });
      return;
    }
    testOpenAIMutation.mutate(openaiKey);
  };

  const handleSaveOpenAI = () => {
    if (!openaiKey.trim()) {
      toast({
        title: "Missing API Key",
        description: "Please enter an OpenAI API key to save.",
        variant: "destructive",
      });
      return;
    }
    saveOpenAIMutation.mutate(openaiKey);
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Setup</h1>
          <p className="text-muted-foreground mt-1">Configure your database and API connections</p>
        </div>
        <Shield className="w-10 h-10 text-primary" />
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-500/10">
                  <Database className="w-5 h-5 text-blue-500" />
                </div>
                <div>
                  <CardTitle>Neon PostgreSQL Database</CardTitle>
                  <CardDescription>Connect to your Neon database for data storage</CardDescription>
                </div>
              </div>
              {statusLoading ? (
                <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
              ) : configStatus?.database.connected ? (
                <Badge className="bg-green-500/10 text-green-500 border-green-500/20">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Connected
                </Badge>
              ) : configStatus?.database.configured ? (
                <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                  <XCircle className="w-3 h-3 mr-1" />
                  Connection Error
                </Badge>
              ) : (
                <Badge className="bg-gray-500/10 text-gray-500 border-gray-500/20">
                  Not Configured
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 rounded-lg bg-muted/50 border">
              <h4 className="font-medium mb-2">How to get a Neon Database URL:</h4>
              <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
                <li>Go to <a href="https://neon.tech" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline inline-flex items-center gap-1">neon.tech <ExternalLink className="w-3 h-3" /></a> and sign up (free)</li>
                <li>Create a new project</li>
                <li>Copy the connection string from the dashboard</li>
                <li>Paste it below and click "Test Connection"</li>
              </ol>
            </div>

            <div className="space-y-2">
              <Label htmlFor="database-url">Database URL</Label>
              <div className="flex gap-2">
                <Input
                  id="database-url"
                  type={showDatabaseUrl ? "text" : "password"}
                  placeholder="postgresql://user:password@host/database"
                  value={databaseUrl}
                  onChange={(e) => setDatabaseUrl(e.target.value)}
                  data-testid="input-database-url"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowDatabaseUrl(!showDatabaseUrl)}
                  data-testid="button-toggle-database-url"
                >
                  {showDatabaseUrl ? "Hide" : "Show"}
                </Button>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleTestDatabase}
                disabled={testDatabaseMutation.isPending || !databaseUrl.trim()}
                variant="outline"
                data-testid="button-test-database"
              >
                {testDatabaseMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Test Connection
              </Button>
              <Button
                onClick={handleSaveDatabase}
                disabled={saveDatabaseMutation.isPending || !databaseUrl.trim()}
                data-testid="button-save-database"
              >
                {saveDatabaseMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Save Configuration
              </Button>
            </div>

            {configStatus?.database.error && (
              <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-sm text-destructive">
                {configStatus.database.error}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-green-500/10">
                  <Key className="w-5 h-5 text-green-500" />
                </div>
                <div>
                  <CardTitle>OpenAI API Key</CardTitle>
                  <CardDescription>Required for OCR and AI document analysis</CardDescription>
                </div>
              </div>
              {statusLoading ? (
                <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
              ) : configStatus?.openai.valid ? (
                <Badge className="bg-green-500/10 text-green-500 border-green-500/20">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Valid
                </Badge>
              ) : configStatus?.openai.configured ? (
                <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                  <XCircle className="w-3 h-3 mr-1" />
                  Invalid Key
                </Badge>
              ) : (
                <Badge className="bg-gray-500/10 text-gray-500 border-gray-500/20">
                  Not Configured
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 rounded-lg bg-muted/50 border">
              <h4 className="font-medium mb-2">How to get an OpenAI API Key:</h4>
              <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
                <li>Go to <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline inline-flex items-center gap-1">platform.openai.com/api-keys <ExternalLink className="w-3 h-3" /></a></li>
                <li>Sign in or create an account</li>
                <li>Click "Create new secret key"</li>
                <li>Copy the key and paste it below</li>
              </ol>
            </div>

            <div className="space-y-2">
              <Label htmlFor="openai-key">API Key</Label>
              <div className="flex gap-2">
                <Input
                  id="openai-key"
                  type={showOpenaiKey ? "text" : "password"}
                  placeholder="sk-..."
                  value={openaiKey}
                  onChange={(e) => setOpenaiKey(e.target.value)}
                  data-testid="input-openai-key"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowOpenaiKey(!showOpenaiKey)}
                  data-testid="button-toggle-openai-key"
                >
                  {showOpenaiKey ? "Hide" : "Show"}
                </Button>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleTestOpenAI}
                disabled={testOpenAIMutation.isPending || !openaiKey.trim()}
                variant="outline"
                data-testid="button-test-openai"
              >
                {testOpenAIMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Test API Key
              </Button>
              <Button
                onClick={handleSaveOpenAI}
                disabled={saveOpenAIMutation.isPending || !openaiKey.trim()}
                data-testid="button-save-openai"
              >
                {saveOpenAIMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Save Configuration
              </Button>
            </div>

            {configStatus?.openai.error && (
              <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-sm text-destructive">
                {configStatus.openai.error}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <Server className="w-5 h-5 text-purple-500" />
              </div>
              <div>
                <CardTitle>System Status</CardTitle>
                <CardDescription>Current configuration status</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-lg border bg-card">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">Database</span>
                  </div>
                  {statusLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                  ) : configStatus?.database.connected ? (
                    <Badge className="bg-green-500/10 text-green-500 border-green-500/20">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Connected
                    </Badge>
                  ) : configStatus?.database.configured ? (
                    <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                      Error
                    </Badge>
                  ) : (
                    <Badge className="bg-gray-500/10 text-gray-500 border-gray-500/20">
                      Not configured
                    </Badge>
                  )}
                </div>
                {configStatus?.database.connected && configStatus?.database.host && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Host: {configStatus.database.host}
                  </p>
                )}
                {configStatus?.database.error && (
                  <p className="text-xs text-destructive mt-1">{configStatus.database.error}</p>
                )}
              </div>
              <div className="p-4 rounded-lg border bg-card">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Key className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">OpenAI API</span>
                  </div>
                  {statusLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                  ) : configStatus?.openai.valid ? (
                    <Badge className="bg-green-500/10 text-green-500 border-green-500/20">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Valid
                    </Badge>
                  ) : configStatus?.openai.configured ? (
                    <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                      Invalid
                    </Badge>
                  ) : (
                    <Badge className="bg-gray-500/10 text-gray-500 border-gray-500/20">
                      Not configured
                    </Badge>
                  )}
                </div>
                {configStatus?.openai.error && (
                  <p className="text-xs text-destructive mt-1">{configStatus.openai.error}</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
