import pandas as pd
from pyhive import hive
from thrift.transport.TTransport import TTransportException


def test_connection(host, port, database, username, password, auth_mechanism):
    try:
        kwargs = {
            "host": host,
            "port": int(port),
            "database": database,
        }
        if auth_mechanism == "NONE":
            kwargs["auth"] = "NONE"
        elif auth_mechanism == "CUSTOM":
            kwargs["auth"] = "CUSTOM"
            kwargs["username"] = username
            kwargs["password"] = password
        elif auth_mechanism == "LDAP":
            kwargs["auth"] = "LDAP"
            kwargs["username"] = username
            kwargs["password"] = password
        elif auth_mechanism == "KERBEROS":
            kwargs["auth"] = "KERBEROS"
            kwargs["kerberos_service_name"] = "hive"

        conn = hive.connect(**kwargs)
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()
        cursor.close()
        conn.close()
        return True, "Connection successful"
    except TTransportException as e:
        return False, f"Transport error: {str(e)}"
    except Exception as e:
        return False, f"Connection failed: {str(e)}"


def get_connection(config):
    kwargs = {
        "host": config["host"],
        "port": int(config["port"]),
        "database": config.get("database", "default"),
    }
    auth = config.get("auth_mechanism", "NONE")
    if auth == "NONE":
        kwargs["auth"] = "NONE"
    elif auth in ("CUSTOM", "LDAP"):
        kwargs["auth"] = auth
        kwargs["username"] = config.get("username", "")
        kwargs["password"] = config.get("password", "")
    elif auth == "KERBEROS":
        kwargs["auth"] = "KERBEROS"
        kwargs["kerberos_service_name"] = "hive"

    return hive.connect(**kwargs)


def execute_query(config, query):
    conn = None
    try:
        conn = get_connection(config)
        df = pd.read_sql(query, conn)
        return df, None
    except Exception as e:
        return None, str(e)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
