import streamlit as st
import pandas as pd


def render():
    st.header("Data Analysis")

    if st.session_state.asis_result is None and st.session_state.tobe_result is None:
        st.warning("No data available. Run AS-IS and/or TO-BE queries first.")
        return

    tab_asis, tab_tobe, tab_compare = st.tabs(["AS-IS Analysis", "TO-BE Analysis", "Comparison"])

    with tab_asis:
        if st.session_state.asis_result is not None:
            _analyze_dataframe(st.session_state.asis_result, "AS-IS")
        else:
            st.info("No AS-IS data loaded.")

    with tab_tobe:
        if st.session_state.tobe_result is not None:
            _analyze_dataframe(st.session_state.tobe_result, "TO-BE")
        else:
            st.info("No TO-BE data loaded.")

    with tab_compare:
        if st.session_state.asis_result is not None and st.session_state.tobe_result is not None:
            _compare_datasets(st.session_state.asis_result, st.session_state.tobe_result)
        else:
            st.info("Both AS-IS and TO-BE data are required for comparison.")


def _analyze_dataframe(df, label):
    st.subheader(f"{label} Data Overview")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Rows", f"{len(df):,}")
    col2.metric("Columns", len(df.columns))
    col3.metric("Null Cells", f"{df.isnull().sum().sum():,}")
    col4.metric("Duplicate Rows", f"{df.duplicated().sum():,}")

    st.subheader("Column Information")
    col_info = pd.DataFrame({
        "Column": df.columns,
        "Data Type": [str(dt) for dt in df.dtypes],
        "Non-Null Count": [df[col].notna().sum() for col in df.columns],
        "Null Count": [df[col].isnull().sum() for col in df.columns],
        "Null %": [round(df[col].isnull().sum() / len(df) * 100, 2) if len(df) > 0 else 0 for col in df.columns],
        "Unique Values": [df[col].nunique() for col in df.columns],
    })
    st.dataframe(col_info, use_container_width=True, hide_index=True)

    st.subheader("Statistical Summary")
    numeric_cols = df.select_dtypes(include=["number"])
    if not numeric_cols.empty:
        st.dataframe(numeric_cols.describe().round(2), use_container_width=True)
    else:
        st.info("No numeric columns found for statistical summary.")

    st.subheader("Sample Data")
    if len(df) == 0:
        st.info("Dataset is empty.")
    else:
        max_rows = min(100, len(df))
        default_rows = min(10, max_rows)
        n_rows = st.slider(f"Rows to display ({label})", 1, max_rows, default_rows, key=f"sample_{label}")
        st.dataframe(df.head(n_rows), use_container_width=True)


def _compare_datasets(asis_df, tobe_df):
    st.subheader("Dataset Comparison")

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("**AS-IS**")
        st.write(f"- Rows: {len(asis_df):,}")
        st.write(f"- Columns: {len(asis_df.columns)}")
        st.write(f"- Column Names: {', '.join(asis_df.columns.tolist())}")
    with col2:
        st.markdown("**TO-BE**")
        st.write(f"- Rows: {len(tobe_df):,}")
        st.write(f"- Columns: {len(tobe_df.columns)}")
        st.write(f"- Column Names: {', '.join(tobe_df.columns.tolist())}")

    asis_cols = set(asis_df.columns)
    tobe_cols = set(tobe_df.columns)
    common_cols = asis_cols & tobe_cols
    only_asis = asis_cols - tobe_cols
    only_tobe = tobe_cols - asis_cols

    st.subheader("Column Differences")
    col1, col2, col3 = st.columns(3)
    col1.metric("Common Columns", len(common_cols))
    col2.metric("Only in AS-IS", len(only_asis))
    col3.metric("Only in TO-BE", len(only_tobe))

    if only_asis:
        st.warning(f"Columns only in AS-IS: {', '.join(sorted(only_asis))}")
    if only_tobe:
        st.warning(f"Columns only in TO-BE: {', '.join(sorted(only_tobe))}")

    if common_cols:
        st.subheader("Data Type Comparison (Common Columns)")
        dtype_comparison = []
        for col in sorted(common_cols):
            asis_dtype = str(asis_df[col].dtype)
            tobe_dtype = str(tobe_df[col].dtype)
            match = "Yes" if asis_dtype == tobe_dtype else "No"
            dtype_comparison.append({
                "Column": col,
                "AS-IS Type": asis_dtype,
                "TO-BE Type": tobe_dtype,
                "Match": match,
            })
        st.dataframe(pd.DataFrame(dtype_comparison), use_container_width=True, hide_index=True)

    if common_cols:
        st.subheader("Row Count Comparison")
        st.write(f"- AS-IS rows: **{len(asis_df):,}**")
        st.write(f"- TO-BE rows: **{len(tobe_df):,}**")
        diff = len(tobe_df) - len(asis_df)
        if diff > 0:
            st.info(f"TO-BE has **{diff:,}** more rows than AS-IS")
        elif diff < 0:
            st.info(f"AS-IS has **{abs(diff):,}** more rows than TO-BE")
        else:
            st.success("Both datasets have the same number of rows")
