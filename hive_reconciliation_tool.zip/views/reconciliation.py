import streamlit as st
import pandas as pd
import io


def render():
    st.header("Reconciliation Report")

    if st.session_state.asis_result is None or st.session_state.tobe_result is None:
        st.warning("Both AS-IS and TO-BE data are required. Please run both queries or upload data first.")
        return

    asis_df = st.session_state.asis_result
    tobe_df = st.session_state.tobe_result

    common_cols = sorted(set(asis_df.columns) & set(tobe_df.columns))

    if not common_cols:
        st.error("No common columns found between AS-IS and TO-BE datasets. Cannot perform reconciliation.")
        return

    st.subheader("Reconciliation Settings")

    col1, col2 = st.columns(2)
    with col1:
        key_columns = st.multiselect(
            "Key Columns (for row matching)",
            options=common_cols,
            help="Select columns that uniquely identify a row across both datasets",
        )
    with col2:
        compare_columns = st.multiselect(
            "Columns to Compare",
            options=[c for c in common_cols if c not in key_columns],
            default=[c for c in common_cols if c not in key_columns],
            help="Select columns to compare between AS-IS and TO-BE",
        )

    tolerance = st.number_input(
        "Numeric Tolerance (for floating point comparison)",
        value=0.0001,
        min_value=0.0,
        format="%.6f",
        help="Values within this tolerance are considered matching",
    )

    if st.button("Run Reconciliation", type="primary", use_container_width=True):
        if not key_columns:
            st.error("Please select at least one key column for row matching.")
            return
        if not compare_columns:
            st.error("Please select at least one column to compare.")
            return

        with st.spinner("Running reconciliation..."):
            report = _run_reconciliation(asis_df, tobe_df, key_columns, compare_columns, tolerance)
            st.session_state.recon_report = report

    if "recon_report" in st.session_state and st.session_state.recon_report is not None:
        report = st.session_state.recon_report
        _display_report(report, key_columns, compare_columns)


def _run_reconciliation(asis_df, tobe_df, key_columns, compare_columns, tolerance):
    report = {}

    asis_dup_count = asis_df.duplicated(subset=key_columns, keep=False).sum()
    tobe_dup_count = tobe_df.duplicated(subset=key_columns, keep=False).sum()

    asis_dedup = asis_df.drop_duplicates(subset=key_columns, keep="first")
    tobe_dedup = tobe_df.drop_duplicates(subset=key_columns, keep="first")

    asis_key_tuples = set(asis_dedup[key_columns].apply(tuple, axis=1))
    tobe_key_tuples = set(tobe_dedup[key_columns].apply(tuple, axis=1))

    common_keys = asis_key_tuples & tobe_key_tuples
    only_asis_keys = asis_key_tuples - tobe_key_tuples
    only_tobe_keys = tobe_key_tuples - asis_key_tuples

    report["summary"] = {
        "total_asis_rows": len(asis_df),
        "total_tobe_rows": len(tobe_df),
        "unique_asis_keys": len(asis_key_tuples),
        "unique_tobe_keys": len(tobe_key_tuples),
        "matched_keys": len(common_keys),
        "only_in_asis": len(only_asis_keys),
        "only_in_tobe": len(only_tobe_keys),
        "asis_duplicate_rows": int(asis_dup_count),
        "tobe_duplicate_rows": int(tobe_dup_count),
    }

    if only_asis_keys:
        report["only_asis"] = pd.DataFrame(list(only_asis_keys), columns=key_columns)
    else:
        report["only_asis"] = pd.DataFrame(columns=key_columns)

    if only_tobe_keys:
        report["only_tobe"] = pd.DataFrame(list(only_tobe_keys), columns=key_columns)
    else:
        report["only_tobe"] = pd.DataFrame(columns=key_columns)

    if common_keys:
        merged = pd.merge(
            asis_dedup[key_columns + compare_columns],
            tobe_dedup[key_columns + compare_columns],
            on=key_columns,
            how="inner",
            suffixes=("_ASIS", "_TOBE"),
        )

        mismatches = []
        for col in compare_columns:
            asis_col = f"{col}_ASIS"
            tobe_col = f"{col}_TOBE"

            if asis_col not in merged.columns or tobe_col not in merged.columns:
                continue

            is_numeric = pd.api.types.is_numeric_dtype(merged[asis_col]) and pd.api.types.is_numeric_dtype(merged[tobe_col])

            for idx, row in merged.iterrows():
                asis_val = row[asis_col]
                tobe_val = row[tobe_col]

                both_null = pd.isna(asis_val) and pd.isna(tobe_val)
                if both_null:
                    continue

                one_null = pd.isna(asis_val) or pd.isna(tobe_val)
                if one_null:
                    key_info = {kc: row[kc] for kc in key_columns}
                    key_info["Column"] = col
                    key_info["AS-IS Value"] = str(asis_val)
                    key_info["TO-BE Value"] = str(tobe_val)
                    key_info["Difference"] = "NULL mismatch"
                    mismatches.append(key_info)
                    continue

                if is_numeric:
                    try:
                        diff = abs(float(asis_val) - float(tobe_val))
                        if diff > tolerance:
                            key_info = {kc: row[kc] for kc in key_columns}
                            key_info["Column"] = col
                            key_info["AS-IS Value"] = str(asis_val)
                            key_info["TO-BE Value"] = str(tobe_val)
                            key_info["Difference"] = str(round(diff, 6))
                            mismatches.append(key_info)
                    except (ValueError, TypeError):
                        if str(asis_val) != str(tobe_val):
                            key_info = {kc: row[kc] for kc in key_columns}
                            key_info["Column"] = col
                            key_info["AS-IS Value"] = str(asis_val)
                            key_info["TO-BE Value"] = str(tobe_val)
                            key_info["Difference"] = "Value mismatch"
                            mismatches.append(key_info)
                else:
                    if str(asis_val).strip() != str(tobe_val).strip():
                        key_info = {kc: row[kc] for kc in key_columns}
                        key_info["Column"] = col
                        key_info["AS-IS Value"] = str(asis_val)
                        key_info["TO-BE Value"] = str(tobe_val)
                        key_info["Difference"] = "Value mismatch"
                        mismatches.append(key_info)

        report["mismatches"] = pd.DataFrame(mismatches) if mismatches else pd.DataFrame()
        report["total_comparisons"] = len(merged) * len(compare_columns)
        report["total_mismatches"] = len(mismatches)
    else:
        report["mismatches"] = pd.DataFrame()
        report["total_comparisons"] = 0
        report["total_mismatches"] = 0

    return report


def _display_report(report, key_columns, compare_columns):
    st.markdown("---")
    st.subheader("Reconciliation Summary")

    summary = report["summary"]
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Matched Keys", f"{summary['matched_keys']:,}")
    col2.metric("Only in AS-IS", f"{summary['only_in_asis']:,}")
    col3.metric("Only in TO-BE", f"{summary['only_in_tobe']:,}")

    total_comp = report.get("total_comparisons", 0)
    total_mis = report.get("total_mismatches", 0)
    match_rate = ((total_comp - total_mis) / total_comp * 100) if total_comp > 0 else 0
    col4.metric("Match Rate", f"{match_rate:.1f}%")

    st.subheader("Detailed Metrics")
    metrics_data = {
        "Metric": [
            "Total AS-IS Rows",
            "Total TO-BE Rows",
            "Unique AS-IS Keys",
            "Unique TO-BE Keys",
            "Matched Keys",
            "Keys Only in AS-IS",
            "Keys Only in TO-BE",
            "AS-IS Duplicate Key Rows",
            "TO-BE Duplicate Key Rows",
            "Total Cell Comparisons",
            "Total Mismatches",
            "Match Rate",
        ],
        "Value": [
            f"{summary['total_asis_rows']:,}",
            f"{summary['total_tobe_rows']:,}",
            f"{summary['unique_asis_keys']:,}",
            f"{summary['unique_tobe_keys']:,}",
            f"{summary['matched_keys']:,}",
            f"{summary['only_in_asis']:,}",
            f"{summary['only_in_tobe']:,}",
            f"{summary.get('asis_duplicate_rows', 0):,}",
            f"{summary.get('tobe_duplicate_rows', 0):,}",
            f"{total_comp:,}",
            f"{total_mis:,}",
            f"{match_rate:.2f}%",
        ],
    }
    st.dataframe(pd.DataFrame(metrics_data), use_container_width=True, hide_index=True)

    if not report["only_asis"].empty:
        with st.expander(f"Keys Only in AS-IS ({len(report['only_asis'])} records)", expanded=False):
            st.dataframe(report["only_asis"], use_container_width=True, hide_index=True)

    if not report["only_tobe"].empty:
        with st.expander(f"Keys Only in TO-BE ({len(report['only_tobe'])} records)", expanded=False):
            st.dataframe(report["only_tobe"], use_container_width=True, hide_index=True)

    if not report["mismatches"].empty:
        with st.expander(f"Value Mismatches ({len(report['mismatches'])} differences)", expanded=True):
            st.dataframe(report["mismatches"], use_container_width=True, hide_index=True)

            st.subheader("Mismatches by Column")
            col_counts = report["mismatches"]["Column"].value_counts()
            chart_df = pd.DataFrame({"Column": col_counts.index, "Mismatches": col_counts.values})
            st.bar_chart(chart_df.set_index("Column"))
    else:
        if report.get("total_comparisons", 0) > 0:
            st.success("No value mismatches found! All matched records are identical.")

    st.markdown("---")
    st.subheader("Export Report")

    col1, col2 = st.columns(2)

    with col1:
        buffer = io.BytesIO()
        with pd.ExcelWriter(buffer, engine="xlsxwriter") as writer:
            pd.DataFrame(metrics_data).to_excel(writer, sheet_name="Summary", index=False)
            if not report["only_asis"].empty:
                report["only_asis"].to_excel(writer, sheet_name="Only in AS-IS", index=False)
            if not report["only_tobe"].empty:
                report["only_tobe"].to_excel(writer, sheet_name="Only in TO-BE", index=False)
            if not report["mismatches"].empty:
                report["mismatches"].to_excel(writer, sheet_name="Mismatches", index=False)
        buffer.seek(0)
        st.download_button(
            "Download Excel Report",
            data=buffer,
            file_name="reconciliation_report.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )

    with col2:
        csv_buffer = io.StringIO()
        if not report["mismatches"].empty:
            report["mismatches"].to_csv(csv_buffer, index=False)
        else:
            pd.DataFrame(metrics_data).to_csv(csv_buffer, index=False)
        st.download_button(
            "Download CSV Report",
            data=csv_buffer.getvalue(),
            file_name="reconciliation_report.csv",
            mime="text/csv",
            use_container_width=True,
        )
