import streamlit as st
import pandas as pd
import io
from hive_client import execute_query


def render():
    st.header("Query Runner — AS-IS & TO-BE")

    if not st.session_state.connected:
        st.warning("Please connect to a Hive server first.")
        return

    st.markdown("Run your **AS-IS** (current state) and **TO-BE** (expected state) queries side by side.")

    tab_asis, tab_tobe, tab_upload = st.tabs(["AS-IS Query", "TO-BE Query", "Upload CSV"])

    with tab_asis:
        _render_query_panel("asis")

    with tab_tobe:
        _render_query_panel("tobe")

    with tab_upload:
        _render_upload_panel()

    st.markdown("---")
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("AS-IS Result Preview")
        if st.session_state.asis_result is not None:
            st.dataframe(st.session_state.asis_result.head(100), use_container_width=True)
            st.caption(f"Total rows: {len(st.session_state.asis_result)} | Columns: {len(st.session_state.asis_result.columns)}")
        else:
            st.info("No AS-IS data loaded yet.")

    with col2:
        st.subheader("TO-BE Result Preview")
        if st.session_state.tobe_result is not None:
            st.dataframe(st.session_state.tobe_result.head(100), use_container_width=True)
            st.caption(f"Total rows: {len(st.session_state.tobe_result)} | Columns: {len(st.session_state.tobe_result.columns)}")
        else:
            st.info("No TO-BE data loaded yet.")


def _render_query_panel(query_type):
    label = "AS-IS" if query_type == "asis" else "TO-BE"
    key_query = f"{query_type}_query"
    key_result = f"{query_type}_result"

    query = st.text_area(
        f"{label} Query (HiveQL)",
        value=st.session_state.get(key_query, ""),
        height=200,
        placeholder=f"Enter your {label} HiveQL query here...\nExample: SELECT * FROM my_table LIMIT 100",
        key=f"{query_type}_query_input",
    )

    col1, col2 = st.columns([1, 4])
    with col1:
        run_btn = st.button(f"Run {label}", type="primary", key=f"run_{query_type}")
    with col2:
        if st.session_state.get(key_result) is not None:
            clear_btn = st.button(f"Clear {label} Results", key=f"clear_{query_type}")
            if clear_btn:
                st.session_state[key_result] = None
                st.rerun()

    if run_btn:
        if not query.strip():
            st.error("Please enter a query.")
            return

        st.session_state[key_query] = query
        with st.spinner(f"Executing {label} query..."):
            df, error = execute_query(st.session_state.hive_config, query)

        if error:
            st.error(f"Query failed: {error}")
        else:
            st.session_state[key_result] = df
            st.success(f"{label} query executed successfully. {len(df)} rows returned.")
            st.rerun()


def _render_upload_panel():
    st.markdown("Upload CSV files as an alternative to running queries.")

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Upload AS-IS Data")
        asis_file = st.file_uploader("Upload AS-IS CSV", type=["csv"], key="asis_upload")
        if asis_file is not None:
            try:
                df = pd.read_csv(asis_file)
                st.session_state.asis_result = df
                st.success(f"AS-IS data loaded: {len(df)} rows, {len(df.columns)} columns")
            except Exception as e:
                st.error(f"Error reading CSV: {e}")

    with col2:
        st.subheader("Upload TO-BE Data")
        tobe_file = st.file_uploader("Upload TO-BE CSV", type=["csv"], key="tobe_upload")
        if tobe_file is not None:
            try:
                df = pd.read_csv(tobe_file)
                st.session_state.tobe_result = df
                st.success(f"TO-BE data loaded: {len(df)} rows, {len(df.columns)} columns")
            except Exception as e:
                st.error(f"Error reading CSV: {e}")
