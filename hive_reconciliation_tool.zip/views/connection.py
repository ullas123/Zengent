import streamlit as st
from hive_client import test_connection


def render():
    st.header("Hive Server Connection")
    st.markdown("Connect to your Apache Hive server to run queries and perform data reconciliation.")

    with st.form("connection_form"):
        col1, col2 = st.columns(2)

        with col1:
            host = st.text_input("Host", value="localhost", help="Hive server hostname or IP")
            port = st.number_input("Port", value=10000, min_value=1, max_value=65535, help="HiveServer2 port")
            database = st.text_input("Database", value="default", help="Default database to connect to")

        with col2:
            auth_mechanism = st.selectbox(
                "Authentication",
                ["NONE", "CUSTOM", "LDAP", "KERBEROS"],
                help="Authentication mechanism for Hive connection",
            )
            username = st.text_input("Username", value="", help="Username (for CUSTOM/LDAP auth)")
            password = st.text_input("Password", value="", type="password", help="Password (for CUSTOM/LDAP auth)")

        submitted = st.form_submit_button("Connect", type="primary", use_container_width=True)

    if submitted:
        with st.spinner("Testing connection..."):
            success, message = test_connection(host, port, database, username, password, auth_mechanism)

        if success:
            st.success(message)
            st.session_state.connected = True
            st.session_state.hive_config = {
                "host": host,
                "port": port,
                "database": database,
                "username": username,
                "password": password,
                "auth_mechanism": auth_mechanism,
            }
        else:
            st.error(message)
            st.session_state.connected = False

    if st.session_state.connected:
        st.info("You are connected. Navigate to **Query Runner** to execute AS-IS and TO-BE queries.")

    with st.expander("Connection Help"):
        st.markdown(
            """
**Authentication Modes:**
- **NONE** — No authentication (common in development)
- **CUSTOM** — Username/password authentication
- **LDAP** — LDAP-based authentication
- **KERBEROS** — Kerberos ticket-based authentication

**Default Ports:**
- HiveServer2 (Thrift): `10000`
- HiveServer2 (HTTP): `10001`

**Troubleshooting:**
- Ensure the Hive server is running and accessible from this machine
- Check firewall rules if connection times out
- Verify credentials for CUSTOM/LDAP authentication
"""
        )
