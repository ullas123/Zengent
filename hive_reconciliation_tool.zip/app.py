import streamlit as st

st.set_page_config(
    page_title="Hive Data Reconciliation Tool",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

from views import connection, query_runner, analysis, reconciliation

if "connected" not in st.session_state:
    st.session_state.connected = False
if "hive_config" not in st.session_state:
    st.session_state.hive_config = {}
if "asis_result" not in st.session_state:
    st.session_state.asis_result = None
if "tobe_result" not in st.session_state:
    st.session_state.tobe_result = None
if "asis_query" not in st.session_state:
    st.session_state.asis_query = ""
if "tobe_query" not in st.session_state:
    st.session_state.tobe_query = ""

st.sidebar.title("Hive Reconciliation Tool")

page = st.sidebar.radio(
    "Navigation",
    ["Connection", "Query Runner", "Data Analysis", "Reconciliation Report"],
    index=0,
)

if st.session_state.connected:
    cfg = st.session_state.hive_config
    st.sidebar.success(f"Connected to {cfg.get('host', '')}:{cfg.get('port', '')}")
    st.sidebar.caption(f"Database: {cfg.get('database', 'default')}")
else:
    st.sidebar.warning("Not connected to Hive")

st.sidebar.markdown("---")
st.sidebar.caption("Hive Data Reconciliation Tool v1.0")

if page == "Connection":
    connection.render()
elif page == "Query Runner":
    query_runner.render()
elif page == "Data Analysis":
    analysis.render()
elif page == "Reconciliation Report":
    reconciliation.render()
