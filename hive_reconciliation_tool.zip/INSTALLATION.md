# Hive Data Reconciliation Tool — Installation Guide

## Prerequisites

- Python 3.11 or higher
- Access to an Apache Hive server (HiveServer2)
- Network connectivity to the Hive server from where this app is running

## Step 1: Clone or Download the Project

Download the project files to your local machine or server.

## Step 2: Install Python Dependencies

```bash
pip install streamlit pyhive thrift pandas openpyxl xlsxwriter
```

### Dependency Details

| Package     | Purpose                                      |
|-------------|----------------------------------------------|
| streamlit   | Web application framework                    |
| pyhive      | Apache Hive connectivity (HiveServer2)       |
| thrift      | Thrift transport protocol for HiveServer2    |
| pandas      | Data manipulation and analysis               |
| openpyxl    | Excel file reading support                   |
| xlsxwriter  | Excel file export for reconciliation reports |

### Optional Dependencies (for specific auth modes)

If you need **Kerberos** authentication:

```bash
pip install thrift-sasl sasl
```

If you need **LDAP** authentication, no additional packages are needed beyond the base install.

## Step 3: Run the Application

```bash
streamlit run app.py --server.port 5000
```

The app will start and be accessible at `http://localhost:5000`.

## Step 4: Connect to Hive

1. Open the app in your browser.
2. On the **Connection** page, enter your Hive server details:
   - **Host** — Hive server hostname or IP address
   - **Port** — HiveServer2 port (default: `10000`)
   - **Database** — Target database (default: `default`)
   - **Authentication** — Choose from NONE, CUSTOM, LDAP, or KERBEROS
   - **Username / Password** — Required for CUSTOM and LDAP auth
3. Click **Connect** to establish the connection.

## Step 5: Run Queries

1. Navigate to the **Query Runner** page.
2. Enter your **AS-IS** query (current state data) in the AS-IS tab.
3. Enter your **TO-BE** query (expected state data) in the TO-BE tab.
4. Alternatively, upload CSV files in the **Upload CSV** tab.
5. Click **Run** to execute each query.

## Step 6: Analyze and Reconcile

- **Data Analysis** — View data profiling, statistics, and structural comparison.
- **Reconciliation Report** — Select key columns and comparison columns, then run reconciliation to find mismatches. Export results as Excel or CSV.

## Project Structure

```
├── app.py                  # Main application entry point
├── hive_client.py          # Hive connection and query logic
├── views/
│   ├── __init__.py
│   ├── connection.py       # Connection page
│   ├── query_runner.py     # AS-IS / TO-BE query runner
│   ├── analysis.py         # Data analysis and profiling
│   └── reconciliation.py   # Reconciliation report generator
├── .streamlit/
│   └── config.toml         # Streamlit server configuration
└── pyproject.toml           # Python project dependencies
```

## Common Hive Connection Examples

### Local Development (No Auth)
- Host: `localhost`
- Port: `10000`
- Auth: `NONE`

### Corporate LDAP
- Host: `hive-server.company.com`
- Port: `10000`
- Auth: `LDAP`
- Username: your LDAP username
- Password: your LDAP password

### Kerberos Secured Cluster
- Host: `hive-server.company.com`
- Port: `10000`
- Auth: `KERBEROS`
- Ensure a valid Kerberos ticket is available (`kinit` before starting the app)

## Troubleshooting

| Issue                           | Solution                                                      |
|---------------------------------|---------------------------------------------------------------|
| Connection timeout              | Check if the Hive server is running and the port is open      |
| Authentication failed           | Verify credentials and authentication mode                    |
| "Transport error" message       | Ensure HiveServer2 is using Thrift (not HTTP) transport       |
| Missing module errors           | Run `pip install` for all required packages                   |
| Kerberos auth fails             | Run `kinit` to obtain a valid ticket before connecting        |
| Empty query results             | Verify the database and table names in your query             |
