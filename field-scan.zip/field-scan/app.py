import streamlit as st
import pandas as pd
import zipfile
import io
import re
from pathlib import Path
from typing import Optional
from rapidfuzz import fuzz

st.set_page_config(
    page_title="Field Scan",
    page_icon="🔍",
    layout="wide",
)

st.title("🔍 Field Scan")
st.markdown(
    "Upload your Excel field definitions and Java project (ZIP). "
    "JAR files inside the project — including `-sources.jar` — are discovered and indexed automatically."
)

# ── constants ─────────────────────────────────────────────────────────────────

EXPECTED_COLS = {
    "FieldName":   ["fieldname", "field_name", "field name", "field"],
    "COLTYPE":     ["coltype", "col_type", "col type", "type", "datatype"],
    "Description": ["description", "desc"],
    "C360":        ["c360", "c 360", "c-360"],
}

# Directories inside a project ZIP that typically contain JARs
JAR_SEARCH_DIRS = {"lib", "libs", "target", ".m2", "dependencies",
                   "build", "out", "dist", "vendor", "ext", "classpath"}


# ── helpers ───────────────────────────────────────────────────────────────────

def best_column_match(df_cols: list[str], candidates: list[str]) -> Optional[str]:
    lower_map = {c.lower().strip(): c for c in df_cols}
    for cand in candidates:
        if cand in lower_map:
            return lower_map[cand]
    for cand in candidates:
        for k, v in lower_map.items():
            if cand in k or k in cand:
                return v
    return None


def java_files_from_zip_bytes(data: bytes, archive_label: str) -> dict[str, str]:
    """Return {relative_path -> source} for every .java inside a ZIP/JAR."""
    out: dict[str, str] = {}
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            for name in zf.namelist():
                if name.endswith(".java") and not name.startswith("__MACOSX"):
                    try:
                        out[name] = zf.read(name).decode("utf-8", errors="replace")
                    except Exception:
                        pass
    except Exception as e:
        st.warning(f"Could not open {archive_label}: {e}")
    return out


def extract_project_zip(data: bytes) -> tuple[dict[str, str], dict[str, str], list[dict]]:
    """
    Extract a project ZIP and return:
      - java_files  : {path -> source} for all .java files found directly
      - jar_sources : {path -> source} for .java files found inside embedded JARs
      - jar_index   : list of dicts describing each JAR found
    """
    java_files: dict[str, str] = {}
    jar_sources: dict[str, str] = {}
    jar_index: list[dict] = []

    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            all_names = zf.namelist()

            for name in all_names:
                # ── collect .java source files ────────────────────────────
                if name.endswith(".java") and not name.startswith("__MACOSX"):
                    try:
                        java_files[name] = zf.read(name).decode("utf-8", errors="replace")
                    except Exception:
                        pass

                # ── collect JARs (anywhere in the ZIP) ───────────────────
                elif name.endswith(".jar") and not name.startswith("__MACOSX"):
                    # Check it's in a known library/build directory OR is a sources jar
                    parts = Path(name).parts
                    top_dirs = {p.lower() for p in parts[:-1]}
                    is_lib_dir = bool(top_dirs & JAR_SEARCH_DIRS)
                    is_source_jar = name.endswith("-sources.jar")

                    if not (is_lib_dir or is_source_jar):
                        continue  # skip JARs in arbitrary locations

                    try:
                        jar_bytes = zf.read(name)
                    except Exception:
                        continue

                    jar_name = Path(name).name
                    java_in_jar = java_files_from_zip_bytes(jar_bytes, jar_name)

                    jar_index.append({
                        "JAR Path":     name,
                        "JAR Name":     jar_name,
                        "Is Sources":   is_source_jar,
                        "Java Files":   len(java_in_jar),
                    })

                    for jpath, jsrc in java_in_jar.items():
                        jar_sources[f"{jar_name}::{jpath}"] = jsrc

    except Exception as e:
        st.error(f"Could not open project ZIP: {e}")

    return java_files, jar_sources, jar_index


def normalize(name: str) -> str:
    n = re.sub(r"([A-Z])", r"_\1", name).lower().strip("_")
    return re.sub(r"[\s\-_]+", "_", n)


# ── scanning ──────────────────────────────────────────────────────────────────

CHAINED_CALL_RE = re.compile(r"\b(\w+)\.((?:get|is)[A-Z]\w*)\(\)(?:\.\w+\(\))*")
TERNARY_GETTER_RE = re.compile(
    r"(\w+)\s*!=\s*null\s*\?\s*"
    r"(\w+)\.((?:get|is)[A-Z]\w*)\(\)(?:\.\w+\(\))*"
    r"\s*:\s*null"
)


def scan_for_field(filename: str, content: str, field_name: str) -> list[dict]:
    results = []
    lines = content.splitlines()
    norm_field = normalize(field_name)

    exact_enum_re = re.compile(
        r"(\w+)\." + re.escape(field_name) + r"\.name\(\)", re.IGNORECASE
    )

    for line_idx, line in enumerate(lines, start=1):
        ls = line.strip()
        if not ls or ls.startswith("//"):
            continue

        enum_class = None
        match_method = None
        confidence = 0

        # 1 — exact enum reference: SomeEnum.FIELD_NAME.name()
        m = exact_enum_re.search(line)
        if m:
            enum_class = m.group(1)
            match_method = "Enum.FIELD.name()"
            confidence = 100
        else:
            # 2 — normalised token
            for tok in re.findall(r"\b[A-Za-z_]\w*\b", line):
                if normalize(tok) == norm_field and len(tok) > 4:
                    match_method = "Normalised token"
                    confidence = 85
                    break
            # 3 — fuzzy
            if confidence == 0:
                best = max(
                    (fuzz.ratio(field_name.lower(), tok.lower())
                     for tok in re.findall(r"\b[A-Za-z_]\w*\b", line)
                     if len(tok) > 3),
                    default=0,
                )
                if best >= 75:
                    match_method = "Fuzzy"
                    confidence = int(best * 0.80)

        if confidence < 60:
            continue

        # extract getter from same line
        getter_object = getter_method = None
        tm = TERNARY_GETTER_RE.search(line)
        if tm:
            getter_object, getter_method = tm.group(2), tm.group(3)
        else:
            gm = CHAINED_CALL_RE.search(line)
            if gm:
                getter_object, getter_method = gm.group(1), gm.group(2)

        # annotations on nearby lines
        start = max(0, line_idx - 6)
        ann_lines = lines[start: line_idx + 1]
        annotations = [
            ann
            for al in ann_lines
            for ann in re.findall(r"@\w+(?:\([^)]*\))?", al.strip())
        ]

        results.append({
            "File":                   filename,
            "Line":                   line_idx,
            "Match Method":           match_method,
            "Confidence (%)":         confidence,
            "Enum Class":             enum_class or "—",
            "Getter Object":          getter_object or "—",
            "Getter Method":          getter_method or "—",
            "Annotations (in code)":  ", ".join(annotations) if annotations else "—",
            "Code Snippet":           ls[:140],
        })

    return results


# ── JAR source analysis ───────────────────────────────────────────────────────

def extract_getter_details(jar_sources: dict[str, str], getter_method: str) -> Optional[dict]:
    method_re = re.compile(
        r"(?:public|protected|private)\s+\S+\s+"
        + re.escape(getter_method)
        + r"\s*\(\s*\)\s*\{([^}]*)\}",
        re.DOTALL,
    )
    json_prop_re = re.compile(r'@JsonProperty\s*\(\s*(?:value\s*=\s*)?"([^"]+)"')
    return_re    = re.compile(r"\breturn\s+(?:this\.)?(\w+)\s*;")

    for path, src in jar_sources.items():
        m = method_re.search(src)
        if not m:
            continue

        method_body  = m.group(1)
        pre_src      = src[: m.start()]
        pre_lines    = "\n".join(pre_src.splitlines()[-6:])

        json_prop  = None
        jp_m = json_prop_re.search(pre_lines)
        if jp_m:
            json_prop = jp_m.group(1)

        java_field = None
        ret_m = return_re.search(method_body)
        if ret_m:
            java_field = ret_m.group(1)

        field_type = None
        if java_field:
            fd_re = re.compile(
                r"(?:private|protected)\s+(\S+)\s+" + re.escape(java_field) + r"\s*(?:=|;)"
            )
            fd_m = fd_re.search(src)
            if fd_m:
                field_type = fd_m.group(1)

        return {
            "JAR Source File": path,
            "Class Name":      Path(path.split("::")[-1]).stem,
            "Getter Method":   getter_method,
            "JSON Property":   json_prop  or "—",
            "Java Field Name": java_field or "—",
            "Java Field Type": field_type or "—",
        }
    return None


def confidence_label(score: int) -> str:
    if score >= 90: return "🟢 High"
    if score >= 75: return "🟡 Medium"
    if score >= 60: return "🟠 Low"
    return "🔴 Very Low"


# ── Sidebar ───────────────────────────────────────────────────────────────────

with st.sidebar:
    st.header("⚙️ Settings")
    min_conf = st.slider("Min confidence (%)", 50, 100, 60, 5)
    st.markdown("---")
    st.markdown("**How it works**")
    st.markdown(
        "1. Upload your project as a **ZIP**.\n"
        "2. The app automatically finds `.java` files **and** any `.jar` / `-sources.jar` "
        "files inside the project (in `lib/`, `target/`, `.m2/`, etc.).\n"
        "3. For every matched field, if a getter is found, the app searches the JAR sources "
        "for that method and extracts `@JsonProperty` value and Java field name.\n"
        "4. No separate JAR upload needed."
    )
    st.markdown("---")
    st.markdown("**Match types**")
    st.markdown("- `Enum.FIELD.name()` — exact enum reference (100%)")
    st.markdown("- `Normalised token` — camelCase/snake_case (85%)")
    st.markdown("- `Fuzzy` — approximate similarity (60–80%)")


# ── Step 1: Excel ─────────────────────────────────────────────────────────────

st.header("Step 1 — Upload Field Definition Excel")

# ── Format guide & sample download ────────────────────────────────────────────
SAMPLE_DATA = {
    "FieldName": [
        "GASP_ACCT_FIRST_NM_TX",
        "GASP_ACCT_LST_NM_TX",
        "GASP_ACCT_MID_NM_TX",
        "GASP_ACCT_PFX_NM_TX",
        "GASP_ACCT_SUFF_NM_TX",
        "GASP_ACCT_ADD_LAST_NM_TX",
        "GASP_ACCT_TTL_NM_TX",
        "GASP_ACCT_NM_SRC_CD",
    ],
    "COLTYPE": [
        "VARCHAR", "VARCHAR", "VARCHAR", "VARCHAR",
        "VARCHAR", "VARCHAR", "VARCHAR", "CHAR",
    ],
    "Description": [
        "Account first name text",
        "Account last name text",
        "Account middle name text",
        "Account prefix name text",
        "Account suffix name text",
        "Account additional last name text",
        "Account title name text",
        "Account name source code",
    ],
    "C360": [
        "first_nm", "last_nm", "mid_nm", "pfx_nm",
        "suff_nm", "add_last_nm", "ttl_nm", "nm_src_cd",
    ],
}
df_sample = pd.DataFrame(SAMPLE_DATA)

with st.expander("📋 Expected Excel Format", expanded=True):
    st.markdown(
        "Your Excel file must have **at least one column** containing field names "
        "(e.g. `GASP_ACCT_FIRST_NM_TX`). The four expected columns are:"
    )
    col_desc1, col_desc2 = st.columns(2)
    with col_desc1:
        st.markdown(
            "| Column | Required | Description |\n"
            "|---|---|---|\n"
            "| **FieldName** | ✅ Yes | Enum/GASP field identifier in UPPER_SNAKE_CASE |\n"
            "| **COLTYPE** | Optional | Data type, e.g. `VARCHAR`, `INT`, `CHAR` |\n"
            "| **Description** | Optional | Human-readable description of the field |\n"
            "| **C360** | Optional | C360 mapping value, e.g. `first_nm` |"
        )
    with col_desc2:
        st.markdown("**Column names are detected automatically** — exact capitalisation is not required. "
                    "For example `fieldname`, `Field Name`, and `FieldName` all map correctly.")
        st.markdown("**Blank rows** in the FieldName column are skipped automatically.")

    sample_buf = io.BytesIO()
    with pd.ExcelWriter(sample_buf, engine="openpyxl") as w:
        df_sample.to_excel(w, index=False, sheet_name="Fields")
    st.download_button(
        "⬇ Download Sample Template (.xlsx)",
        data=sample_buf.getvalue(),
        file_name="field_scan_template.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )

st.markdown("")

excel_file = st.file_uploader(
    "Upload your Excel file (.xlsx or .xls)",
    type=["xlsx", "xls"],
)

df_fields = None
col_map: dict = {}

if excel_file:
    try:
        raw_bytes = excel_file.read()
        # Detect actual format from binary magic bytes — ignores file extension
        # OLE2 / legacy .xls:  D0 CF 11 E0
        # ZIP-based .xlsx:      50 4B (PK)
        if raw_bytes[:4] == b"\xd0\xcf\x11\xe0":
            engine_order = ["xlrd"]          # definitely old .xls
        elif raw_bytes[:2] == b"PK":
            engine_order = ["openpyxl"]      # definitely .xlsx / zip-based
        else:
            engine_order = ["openpyxl", "xlrd"]  # unknown — try both

        df_raw = None
        last_err = None
        for engine in engine_order:
            try:
                df_raw = pd.read_excel(io.BytesIO(raw_bytes), engine=engine)
                break
            except Exception as err:
                last_err = err

        if df_raw is None:
            raise ValueError(
                f"Could not parse the Excel file (tried: {engine_order}).\n"
                f"Error: {last_err}\n\n"
                "Please open the file in Excel, choose File → Save As → "
                "Excel Workbook (.xlsx), and upload the saved file."
            )

        # ── Row / column summary ───────────────────────────────────────
        m1, m2, m3 = st.columns(3)
        m1.metric("📄 Total Rows in File", f"{len(df_raw):,}")
        m2.metric("📊 Columns Found", len(df_raw.columns))
        m3.metric("📁 File Name", excel_file.name)

        detected = {
            logical: best_column_match(df_raw.columns.tolist(), candidates)
            for logical, candidates in EXPECTED_COLS.items()
        }

        st.markdown("**Column mapping** — adjust if auto-detection is wrong:")
        c1, c2, c3, c4 = st.columns(4)
        opts = ["(none)"] + df_raw.columns.tolist()

        def sel(widget, label, detected_val):
            default = opts.index(detected_val) if detected_val in opts else 0
            return widget.selectbox(label, opts, index=default)

        col_map["FieldName"]   = sel(c1, "FieldName *",  detected.get("FieldName"))
        col_map["COLTYPE"]     = sel(c2, "COLTYPE",       detected.get("COLTYPE"))
        col_map["Description"] = sel(c3, "Description",  detected.get("Description"))
        col_map["C360"]        = sel(c4, "C360",         detected.get("C360"))

        for k in list(col_map):
            if col_map[k] == "(none)":
                col_map[k] = None

        if col_map["FieldName"] is None:
            st.error("Please select the FieldName column.")
        else:
            keep = [v for v in col_map.values() if v]
            df_fields = df_raw[keep].dropna(subset=[col_map["FieldName"]]).copy()
            df_fields.rename(columns={v: k for k, v in col_map.items() if v}, inplace=True)
            df_fields["FieldName"] = df_fields["FieldName"].astype(str).str.strip()
            for c in ["COLTYPE", "Description", "C360"]:
                if c not in df_fields.columns:
                    df_fields[c] = ""

            valid_rows = len(df_fields)
            skipped    = len(df_raw) - valid_rows
            st.success(
                f"✅ **{valid_rows:,} field rows** ready to scan"
                + (f" ({skipped:,} blank/skipped rows excluded)" if skipped else "")
            )

            st.markdown("**Data Preview** — all uploaded rows:")
            st.dataframe(
                df_fields,
                use_container_width=True,
                hide_index=True,
                height=min(400, 38 + valid_rows * 35),
            )

            st.caption(f"Showing all {valid_rows:,} rows · {len(df_fields.columns)} columns")

    except Exception as e:
        st.error(f"Could not read Excel file: {e}")


# ── Step 2: Java project upload ───────────────────────────────────────────────

st.header("Step 2 — Upload Java Project")
st.markdown(
    "Upload your project as a **ZIP archive** or individual **`.java`** files. "
    "Any `.jar` or `-sources.jar` files found inside the ZIP are indexed automatically."
)

upload_mode = st.radio(
    "Upload mode",
    ["ZIP archive (recommended — includes embedded JARs)", "Individual .java files"],
    horizontal=True,
)

java_files:  dict[str, str] = {}
jar_sources: dict[str, str] = {}
jar_index:   list[dict]     = []

if upload_mode == "ZIP archive (recommended — includes embedded JARs)":
    zip_up = st.file_uploader("Project ZIP", type=["zip"])
    if zip_up:
        with st.spinner("Extracting Java sources and scanning for embedded JARs…"):
            java_files, jar_sources, jar_index = extract_project_zip(zip_up.read())

        col_j, col_r = st.columns(2)
        col_j.success(f"Found **{len(java_files)}** Java source file(s).")
        if jar_sources:
            col_r.success(
                f"Found **{len(jar_index)}** JAR(s) → indexed "
                f"**{len(jar_sources)}** Java source file(s) from them."
            )
        else:
            col_r.info("No JARs found inside the ZIP (lib/, target/, .m2/, -sources.jar, etc.).")

        if java_files:
            with st.expander(f"Java files ({len(java_files)})", expanded=False):
                for n in sorted(java_files):
                    st.text(n)

        if jar_index:
            with st.expander(f"JARs discovered ({len(jar_index)})", expanded=False):
                df_jars = pd.DataFrame(jar_index)
                st.dataframe(df_jars, use_container_width=True, hide_index=True)
else:
    uploads = st.file_uploader("Java files", type=["java"], accept_multiple_files=True)
    for f in uploads:
        java_files[f.name] = f.read().decode("utf-8", errors="replace")
    if java_files:
        st.success(f"Loaded **{len(java_files)}** file(s).")
    st.info(
        "No JAR analysis is available in individual-file mode. "
        "Upload a full project ZIP to enable automatic JAR discovery."
    )


# ── Step 3: Scan ──────────────────────────────────────────────────────────────

st.header("Step 3 — Scan")

ready = df_fields is not None and bool(java_files)
if not ready:
    st.info(
        "Complete Step 1 (Excel) and Step 2 (Java project) to enable scanning."
        if df_fields is None or not java_files else
        "Upload Java source files in Step 2 to continue."
    )

if ready:
    if st.button("▶ Run Field Scan", type="primary", use_container_width=True):
        all_rows: list[dict] = []
        fields = df_fields.to_dict("records")
        prog = st.progress(0, text="Starting…")

        for i, row in enumerate(fields):
            fname = str(row.get("FieldName", "")).strip()
            ftype = str(row.get("COLTYPE",   "") or "").strip()
            fdesc = str(row.get("Description","") or "").strip()
            fc360 = str(row.get("C360",      "") or "").strip()

            if not fname or fname.lower() == "nan":
                prog.progress((i + 1) / len(fields))
                continue

            prog.progress((i + 1) / len(fields), text=f"[{i+1}/{len(fields)}] {fname}")

            for jname, jcontent in java_files.items():
                for h in scan_for_field(jname, jcontent, fname):
                    if h["Confidence (%)"] < min_conf:
                        continue

                    getter = h.get("Getter Method", "—")
                    jar_detail: dict = {}
                    if getter and getter != "—" and jar_sources:
                        result = extract_getter_details(jar_sources, getter)
                        if result:
                            jar_detail = result

                    all_rows.append({
                        "FieldName":              fname,
                        "COLTYPE":                ftype,
                        "Description":            fdesc,
                        "C360":                   fc360,
                        "File":                   h["File"],
                        "Line":                   h["Line"],
                        "Match Method":           h["Match Method"],
                        "Confidence (%)":         h["Confidence (%)"],
                        "Confidence":             confidence_label(h["Confidence (%)"]),
                        "Enum Class":             h["Enum Class"],
                        "Getter Object":          h["Getter Object"],
                        "Getter Method":          h["Getter Method"],
                        "Annotations (in code)":  h["Annotations (in code)"],
                        "JAR Source File":        jar_detail.get("JAR Source File", "—"),
                        "Class Name":             jar_detail.get("Class Name", "—"),
                        "JSON Property":          jar_detail.get("JSON Property", "—"),
                        "Java Field Name":        jar_detail.get("Java Field Name", "—"),
                        "Java Field Type":        jar_detail.get("Java Field Type", "—"),
                        "Code Snippet":           h["Code Snippet"],
                    })

        prog.empty()
        st.session_state["results"]      = all_rows
        st.session_state["fields_count"] = len(fields)
        st.session_state["jar_index"]    = jar_index


# ── Step 4: Results ───────────────────────────────────────────────────────────

if st.session_state.get("results") is not None:
    rows        = st.session_state["results"]
    total_flds  = st.session_state.get("fields_count", 0)

    st.header("Step 4 — Results")

    if not rows:
        st.warning("No matches found. Try lowering the minimum confidence or verify that field names match.")
    else:
        df = pd.DataFrame(rows)

        # KPIs
        k1, k2, k3, k4, k5 = st.columns(5)
        k1.metric("Total Matches",        len(df))
        k2.metric("Fields Matched",       f"{df['FieldName'].nunique()} / {total_flds}")
        k3.metric("Java Files Hit",       df["File"].nunique())
        k4.metric("Getter Methods Found", df[df["Getter Method"] != "—"]["Getter Method"].nunique())
        k5.metric("JAR Details Resolved", int((df["JSON Property"] != "—").sum()))

        # ── Quick export (top) ────────────────────────────────────────
        st.markdown("---")
        st.subheader("⬇ Download Results")

        detail_cols_all = [
            "FieldName", "COLTYPE", "C360", "File", "Line",
            "Match Method", "Confidence (%)", "Confidence",
            "Enum Class", "Getter Object", "Getter Method",
            "JSON Property", "Java Field Name", "Java Field Type",
            "Annotations (in code)", "Code Snippet",
        ]

        # Build summary for export
        summary_export = (
            df.groupby("FieldName")
            .agg(
                COLTYPE=("COLTYPE", "first"),
                C360=("C360", "first"),
                Description=("Description", "first"),
                Matches=("Confidence (%)", "count"),
                Max_Conf=("Confidence (%)", "max"),
                Files_Hit=("File", "nunique"),
                Enum_Class=("Enum Class", lambda x: ", ".join(sorted({v for v in x if v != "—"}))),
                Getter_Methods=("Getter Method", lambda x: ", ".join(sorted({v for v in x if v != "—"}))),
                JSON_Props=("JSON Property", lambda x: ", ".join(sorted({v for v in x if v != "—"}))),
                Java_Fields=("Java Field Name", lambda x: ", ".join(sorted({v for v in x if v != "—"}))),
            )
            .reset_index()
            .rename(columns={
                "Max_Conf": "Max Conf (%)",
                "Files_Hit": "Files Hit",
                "Enum_Class": "Enum Class(es)",
                "Getter_Methods": "Getter Method(s)",
                "JSON_Props": "JSON Property(ies)",
                "Java_Fields": "Java Field(s)",
            })
            .sort_values("Max Conf (%)", ascending=False)
        )
        summary_export["Confidence"] = summary_export["Max Conf (%)"].apply(confidence_label)

        exp_buf = io.BytesIO()
        with pd.ExcelWriter(exp_buf, engine="openpyxl") as writer:
            df[detail_cols_all].to_excel(writer, sheet_name="Detailed Results", index=False)
            summary_export.to_excel(writer, sheet_name="Summary", index=False)
            if st.session_state.get("jar_index"):
                pd.DataFrame(st.session_state["jar_index"]).to_excel(
                    writer, sheet_name="JARs Discovered", index=False
                )

        dl1, dl2 = st.columns(2)
        with dl1:
            st.download_button(
                "⬇ Download Results — Excel (.xlsx)",
                data=exp_buf.getvalue(),
                file_name="field_scan_results.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
                type="primary",
            )
            st.caption(
                f"3 sheets: **Detailed Results** ({len(df)} rows) · "
                f"**Summary** ({len(summary_export)} fields) · "
                + ("**JARs Discovered**" if st.session_state.get("jar_index") else "no JAR sheet")
            )
        with dl2:
            st.download_button(
                "⬇ Download Results — CSV",
                data=df[detail_cols_all].to_csv(index=False).encode("utf-8"),
                file_name="field_scan_results.csv",
                mime="text/csv",
                use_container_width=True,
            )
            st.caption(f"Flat file · {len(df)} rows · {len(detail_cols_all)} columns")

        # ── Excel output preview ──────────────────────────────────────
        st.markdown("**Preview — what the Excel file contains:**")
        prev_tab1, prev_tab2 = st.tabs(["📄 Detailed Results sheet", "📊 Summary sheet"])
        with prev_tab1:
            st.caption(f"{len(df)} rows × {len(detail_cols_all)} columns")
            st.dataframe(
                df[detail_cols_all],
                use_container_width=True,
                hide_index=True,
                height=350,
                column_config={
                    "Confidence (%)": st.column_config.ProgressColumn(
                        "Confidence (%)", min_value=0, max_value=100, format="%d%%"
                    ),
                },
            )
        with prev_tab2:
            st.caption(f"{len(summary_export)} fields")
            st.dataframe(summary_export, use_container_width=True, hide_index=True, height=350)

        st.markdown("---")

        # Filters
        with st.expander("🔽 Filters", expanded=True):
            fc1, fc2, fc3 = st.columns(3)
            sel_fields  = fc1.multiselect("FieldName",    sorted(df["FieldName"].unique()))
            sel_methods = fc2.multiselect("Match Method", sorted(df["Match Method"].unique()))
            sel_files   = fc3.multiselect("Java File",    sorted(df["File"].unique()))

        dv = df.copy()
        if sel_fields:  dv = dv[dv["FieldName"].isin(sel_fields)]
        if sel_methods: dv = dv[dv["Match Method"].isin(sel_methods)]
        if sel_files:   dv = dv[dv["File"].isin(sel_files)]

        # Summary
        st.subheader("Summary by Field")
        summary = (
            dv.groupby("FieldName")
            .agg(
                COLTYPE=("COLTYPE", "first"),
                C360=("C360", "first"),
                Description=("Description", "first"),
                Matches=("Confidence (%)", "count"),
                Max_Conf=("Confidence (%)", "max"),
                Files_Hit=("File", "nunique"),
                Enum_Class=("Enum Class",      lambda x: ", ".join(sorted({v for v in x if v != "—"}))),
                Getter_Methods=("Getter Method", lambda x: ", ".join(sorted({v for v in x if v != "—"}))),
                JSON_Props=("JSON Property",    lambda x: ", ".join(sorted({v for v in x if v != "—"}))),
                Java_Fields=("Java Field Name", lambda x: ", ".join(sorted({v for v in x if v != "—"}))),
            )
            .reset_index()
            .rename(columns={
                "Max_Conf":      "Max Conf (%)",
                "Files_Hit":     "Files Hit",
                "Enum_Class":    "Enum Class(es)",
                "Getter_Methods":"Getter Method(s)",
                "JSON_Props":    "JSON Property(ies)",
                "Java_Fields":   "Java Field(s)",
            })
            .sort_values("Max Conf (%)", ascending=False)
        )
        summary["Confidence"] = summary["Max Conf (%)"].apply(confidence_label)
        st.dataframe(summary, use_container_width=True, hide_index=True)

        # Drill-down
        st.subheader("Field Drill-Down")
        sel_drill = st.selectbox(
            "Select a field to inspect",
            ["(All)"] + sorted(dv["FieldName"].unique()),
        )
        drill_df = dv if sel_drill == "(All)" else dv[dv["FieldName"] == sel_drill]

        for _, r in drill_df.iterrows():
            label = (
                f"{r['Confidence']}  `{r['FieldName']}` — "
                f"**{Path(r['File']).name}** line {r['Line']}"
            )
            with st.expander(label, expanded=False):
                ca, cb, cc = st.columns(3)
                with ca:
                    st.markdown("**From Excel**")
                    st.markdown(f"- **FieldName:** `{r['FieldName']}`")
                    st.markdown(f"- **COLTYPE:** `{r['COLTYPE']}`")
                    st.markdown(f"- **C360:** `{r['C360']}`")
                    st.markdown(f"- **Description:** {r['Description']}")
                with cb:
                    st.markdown("**In Java code**")
                    st.markdown(f"- **File:** `{r['File']}`")
                    st.markdown(f"- **Line:** {r['Line']}")
                    st.markdown(f"- **Enum Class:** `{r['Enum Class']}`")
                    st.markdown(f"- **Getter:** `{r['Getter Object']}.{r['Getter Method']}()`")
                    st.markdown(f"- **Annotations:** {r['Annotations (in code)']}")
                with cc:
                    st.markdown("**From JAR source (auto-discovered)**")
                    st.markdown(f"- **Class:** `{r['Class Name']}`")
                    st.markdown(f"- **@JsonProperty:** `{r['JSON Property']}`")
                    st.markdown(f"- **Java field:** `{r['Java Field Name']}`")
                    st.markdown(f"- **Field type:** `{r['Java Field Type']}`")
                    st.markdown(f"- **JAR path:** `{r['JAR Source File']}`")
                st.code(r["Code Snippet"], language="java")
