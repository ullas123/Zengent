# Field Scan

A local desktop tool for scanning Java source code against an Excel field definition file.  
It identifies where each field is used, extracts getter method mappings, reads `@JsonProperty` values from embedded source JARs, and exports a full findings report.

---

## Requirements

- **Python 3.10 or newer** — [python.org/downloads](https://www.python.org/downloads/)
- **pip** (bundled with Python 3.10+)

---

## Installation

### 1. Download and unzip

Unzip the `field-scan.zip` file to any folder, for example `C:\Tools\field-scan` or `~/tools/field-scan`.

### 2. Create a virtual environment (recommended)

Open a terminal in the `field-scan` folder and run:

**Windows**
```cmd
python -m venv venv
venv\Scripts\activate
```

**macOS / Linux**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

This installs:

| Package | Purpose |
|---|---|
| `streamlit` | Web UI framework |
| `pandas` | Excel reading and data manipulation |
| `openpyxl` | `.xlsx` file support |
| `rapidfuzz` | Fuzzy string matching for field name similarity |
| `xlrd` | Legacy `.xls` file support |

---

## Running the app

```bash
streamlit run app.py
```

The app opens automatically in your default browser at `http://localhost:8501`.

To use a different port:
```bash
streamlit run app.py --server.port 8080
```

---

## How to use

### Step 1 — Upload your Excel file

The Excel file should have these columns (names are detected automatically):

| Column | Purpose |
|---|---|
| `FieldName` | The GASP/enum field identifier, e.g. `GASP_ACCT_FIRST_NM_TX` |
| `COLTYPE` | Data type of the field |
| `Description` | Human-readable description |
| `C360` | C360 mapping value |

### Step 2 — Upload your Java project ZIP

Zip your entire Java project folder and upload it.  
The tool automatically:
- Extracts all `.java` source files for scanning
- Finds any `.jar` files in `lib/`, `libs/`, `target/`, `.m2/`, `dependencies/`, `build/`, `vendor/`, `ext/`, or `classpath/`
- Extracts Java source files from `-sources.jar` files
- Indexes them all for getter method analysis

**No separate JAR upload is needed** — JARs inside the project are discovered automatically.

### Step 3 — Run the scan

Click **Run Field Scan**. For each field name the tool:

1. Searches every `.java` file for the enum reference pattern `EnumClass.FIELD_NAME.name()`
2. Reads the same line to find the associated getter call, e.g. `primary.getFirstNm().toUpperCase()`
3. Searches the JAR sources for that getter method
4. Extracts the `@JsonProperty` annotation value (e.g. `"first_nm"`)
5. Extracts the Java field name from the `return` statement (e.g. `firstNm`)
6. Calculates a confidence score (60–100%)

### Step 4 — Review and export

Results appear as:
- **Summary table** — one row per field with max confidence, getter methods, JSON properties, and C360
- **Detailed table** — every individual match with file, line, code snippet, and all extracted values
- **Field Drill-Down** — expand any match to see the full context

Export to **CSV** or **Excel** (with Detailed Results, Summary, and JARs Discovered sheets).

---

## Confidence scoring

| Score | Label | Meaning |
|---|---|---|
| 100% | 🟢 High | Exact enum reference `EnumClass.FIELD_NAME.name()` found |
| 85% | 🟡 Medium | Field name found after camelCase/snake_case normalisation |
| 60–80% | 🟠 Low | Approximate fuzzy match |

---

## Troubleshooting

**`streamlit: command not found`**  
Make sure the virtual environment is activated (step 2) before running the app.

**Excel file fails to load**  
Ensure the file is saved as `.xlsx` or `.xls`. Files exported from Google Sheets should be downloaded as Excel format first.

**No matches found**  
- Confirm that the FieldName column contains values like `GASP_ACCT_FIRST_NM_TX` (uppercase with underscores)
- Lower the minimum confidence slider in the sidebar
- Verify that your Java ZIP includes the source files (not just compiled `.class` files)

**JAR analysis returns "—" for JSON Property**  
The project ZIP must contain a `-sources.jar` or a JAR with `.java` files inside (not just compiled bytecode).
