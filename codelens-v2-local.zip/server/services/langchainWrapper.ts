import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

interface LangChainResult {
  status: 'success' | 'error';
  analysis?: string;
  explanation?: string;
  patterns?: string;
  migration_plan?: string;
  response?: string;
  message?: string;
  model?: string;
  framework?: string;
  timestamp?: string;
}

interface LangGraphResult {
  status: 'success' | 'error';
  project_name?: string;
  structure_analysis?: string;
  security_scan?: string;
  quality_metrics?: string;
  pattern_detection?: string;
  migration_plan?: string;
  executive_summary?: string;
  errors?: string[];
  metadata?: {
    start_time: string;
    end_time?: string;
    model: string;
    framework: string;
  };
  agents_used?: number;
  message?: string;
}

interface ServiceStatus {
  langchain_available: boolean;
  openai_available?: boolean;
  langgraph_available?: boolean;
  service_ready: boolean;
  features?: string[];
  workflow_phases?: string[];
  agents?: string[];
}

class LangChainService {
  private pythonPath: string = 'python3';
  private langchainScript: string;
  private langgraphScript: string;

  constructor() {
    this.langchainScript = path.join(__dirname, 'langchainService.py');
    this.langgraphScript = path.join(__dirname, 'langgraphOrchestrator.py');
  }

  private async runPythonScript(script: string, command: string, jsonInput?: object): Promise<any> {
    return new Promise((resolve) => {
      const args = [script, command];
      const proc = spawn(this.pythonPath, args, {
        env: { ...process.env },
        cwd: path.dirname(script)
      });

      let stdout = '';
      let stderr = '';

      if (jsonInput) {
        proc.stdin.write(JSON.stringify(jsonInput));
        proc.stdin.end();
      } else {
        proc.stdin.end();
      }

      proc.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      proc.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      proc.on('close', (code) => {
        if (code === 0 && stdout) {
          try {
            resolve(JSON.parse(stdout));
          } catch (e) {
            resolve({ status: 'success', output: stdout });
          }
        } else {
          resolve({
            status: 'error',
            message: stderr || `Process exited with code ${code}`,
            output: stdout
          });
        }
      });

      proc.on('error', (error) => {
        resolve({
          status: 'error',
          message: error.message
        });
      });

      setTimeout(() => {
        proc.kill();
        resolve({
          status: 'error',
          message: 'Process timeout after 120 seconds'
        });
      }, 120000);
    });
  }

  async getLangChainStatus(): Promise<ServiceStatus> {
    return this.runPythonScript(this.langchainScript, 'status');
  }

  async getLangGraphStatus(): Promise<ServiceStatus> {
    return this.runPythonScript(this.langgraphScript, 'status');
  }

  async analyzeArchitecture(code: string, question?: string): Promise<LangChainResult> {
    return this.runPythonScript(this.langchainScript, 'analyze', { code, question });
  }

  async explainCode(code: string, language: string = 'auto'): Promise<LangChainResult> {
    return this.runPythonScript(this.langchainScript, 'explain', { code, language });
  }

  async detectPatterns(code: string): Promise<LangChainResult> {
    return this.runPythonScript(this.langchainScript, 'patterns', { code });
  }

  async generateMigrationPlan(code: string, targetTech: string = 'Spring Boot 3'): Promise<LangChainResult> {
    return this.runPythonScript(this.langchainScript, 'migrate', { code, targetTech });
  }

  async runFullAnalysis(code: string, projectName: string = 'Unknown'): Promise<LangGraphResult> {
    return this.runPythonScript(this.langgraphScript, 'full', { code, projectName });
  }

  async runQuickAnalysis(code: string): Promise<LangGraphResult> {
    return this.runPythonScript(this.langgraphScript, 'quick', { code });
  }
}

export const langchainService = new LangChainService();
export type { LangChainResult, LangGraphResult, ServiceStatus };
