/**
 * Integration Pattern Detector
 * Detects various integration patterns in legacy (POD) systems
 * and suggests modern (POA) alternatives for migration.
 */

export interface IntegrationPattern {
  category: 'API' | 'DATABASE' | 'MESSAGING' | 'FILE_BATCH' | 'CROSS_CUTTING';
  podPattern: string;
  poaPattern: string;
  detected: boolean;
  confidence: 'LOW' | 'MEDIUM' | 'HIGH';
  evidence: string[];
  files: string[];
  recommendations: string[];
}

export interface IntegrationPatternAnalysis {
  apiPatterns: IntegrationPattern[];
  databasePatterns: IntegrationPattern[];
  messagingPatterns: IntegrationPattern[];
  fileBatchPatterns: IntegrationPattern[];
  crossCuttingPatterns: IntegrationPattern[];
  summary: {
    totalPatternsDetected: number;
    podPatternsFound: number;
    poaOpportunities: number;
    modernizationPriority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  };
}

interface SourceFile {
  relativePath: string;
  content: string;
}

export class IntegrationPatternDetector {
  
  analyze(sourceFiles: SourceFile[]): IntegrationPatternAnalysis {
    const apiPatterns = this.detectAPIPatterns(sourceFiles);
    const databasePatterns = this.detectDatabasePatterns(sourceFiles);
    const messagingPatterns = this.detectMessagingPatterns(sourceFiles);
    const fileBatchPatterns = this.detectFileBatchPatterns(sourceFiles);
    const crossCuttingPatterns = this.detectCrossCuttingPatterns(sourceFiles);

    const allPatterns = [
      ...apiPatterns,
      ...databasePatterns,
      ...messagingPatterns,
      ...fileBatchPatterns,
      ...crossCuttingPatterns
    ];

    const totalDetected = allPatterns.filter(p => p.detected).length;
    const podCount = allPatterns.filter(p => p.detected && !p.poaPattern.includes('Modern')).length;
    
    let priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'LOW';
    if (podCount >= 10) priority = 'CRITICAL';
    else if (podCount >= 7) priority = 'HIGH';
    else if (podCount >= 4) priority = 'MEDIUM';

    return {
      apiPatterns,
      databasePatterns,
      messagingPatterns,
      fileBatchPatterns,
      crossCuttingPatterns,
      summary: {
        totalPatternsDetected: totalDetected,
        podPatternsFound: podCount,
        poaOpportunities: podCount,
        modernizationPriority: priority
      }
    };
  }

  private detectAPIPatterns(sourceFiles: SourceFile[]): IntegrationPattern[] {
    const patterns: IntegrationPattern[] = [];

    // 1. Synchronous Request-Response (RPC style)
    const syncRpcPattern = this.createPattern(
      'API',
      'Synchronous Request-Response (RPC Style)',
      'API Gateway Pattern with Async Capabilities',
      sourceFiles,
      [
        /RestTemplate|HttpClient|WebClient/,
        /@RestController|@RequestMapping/,
        /synchronous|blocking|request.*response/i
      ],
      [
        'Implement API Gateway (Kong, Apigee, AWS API Gateway)',
        'Add circuit breaker patterns (Resilience4j)',
        'Consider async communication where appropriate'
      ]
    );
    patterns.push(syncRpcPattern);

    // 2. Monolithic REST/SOAP Endpoints
    const monolithicPattern = this.createPattern(
      'API',
      'Monolithic REST/SOAP Endpoints (Fat Controllers)',
      'Backend-for-Frontend (BFF) Pattern',
      sourceFiles,
      [
        /@RestController.*\{[\s\S]{200,}/,
        /class.*Controller[\s\S]{500,}/,
        /@Autowired.*@Autowired.*@Autowired/
      ],
      [
        'Split into focused microservices',
        'Implement BFF pattern for different client types (web, mobile)',
        'Use aggregator/composite API pattern'
      ]
    );
    patterns.push(monolithicPattern);

    // 3. Point-to-Point HTTP Calls
    const p2pPattern = this.createPattern(
      'API',
      'Point-to-Point HTTP Calls (Tight Coupling)',
      'Service Mesh with Load Balancing',
      sourceFiles,
      [
        /http:\/\/localhost:\d+/,
        /RestTemplate.*getForObject/,
        /hardcoded.*url|direct.*http.*call/i
      ],
      [
        'Implement service mesh (Istio, Linkerd)',
        'Use service discovery (Consul, Eureka)',
        'Add API Gateway for routing'
      ]
    );
    patterns.push(p2pPattern);

    // 4. No API Gateway (UI calling many backends)
    const noGatewayPattern = this.createPattern(
      'API',
      'No API Gateway (UI Directly Calling Multiple Services)',
      'API Gateway with Aggregation',
      sourceFiles,
      [
        /axios\.get.*axios\.get.*axios\.get/,
        /fetch\(.*\).*fetch\(.*\)/,
        /multiple.*backend.*calls/i
      ],
      [
        'Implement API Gateway (Kong, Tyk, AWS API Gateway)',
        'Add request aggregation and caching',
        'Implement rate limiting and throttling'
      ]
    );
    patterns.push(noGatewayPattern);

    // 5. Strangler Fig Opportunity
    const stranglerPattern = this.createPattern(
      'API',
      'Legacy System Integration',
      'Strangler Fig Pattern',
      sourceFiles,
      [
        /legacy|monolith|old.*system/i,
        /@Deprecated/,
        /todo.*refactor|fixme.*modernize/i
      ],
      [
        'Implement Strangler Fig pattern (gradual migration)',
        'Route traffic using API Gateway',
        'Version APIs (v1, v2) for controlled evolution'
      ]
    );
    patterns.push(stranglerPattern);

    return patterns;
  }

  private detectDatabasePatterns(sourceFiles: SourceFile[]): IntegrationPattern[] {
    const patterns: IntegrationPattern[] = [];

    // 1. Shared Database Pattern
    const sharedDbPattern = this.createPattern(
      'DATABASE',
      'Shared Database Pattern (Multiple Services Sharing Schema)',
      'Database per Service',
      sourceFiles,
      [
        /@Table\(name.*\)|@Entity/,
        /schema.*public|shared.*database/i,
        /multiple.*services.*same.*db/i
      ],
      [
        'Implement Database per Service pattern',
        'Use event-driven data synchronization (CDC, Outbox pattern)',
        'Create API layer for data access'
      ]
    );
    patterns.push(sharedDbPattern);

    // 2. Integration via DB Tables
    const dbIntegrationPattern = this.createPattern(
      'DATABASE',
      'Integration via Database Tables (Direct Table Access)',
      'API-Based Data Access',
      sourceFiles,
      [
        /SELECT.*FROM.*WHERE/,
        /INSERT.*INTO.*VALUES/,
        /integration.*table|shared.*table/i
      ],
      [
        'Replace with REST/GraphQL APIs',
        'Implement event-driven integration',
        'Use message queues for async data transfer'
      ]
    );
    patterns.push(dbIntegrationPattern);

    // 3. Stored Procedure Integration
    const storedProcPattern = this.createPattern(
      'DATABASE',
      'Stored Procedure Integration (Business Logic in DB)',
      'Application-Layer Business Logic',
      sourceFiles,
      [
        /CALL.*\(|EXECUTE.*PROCEDURE/,
        /CallableStatement|@Procedure/,
        /stored.*procedure|sp_.*\(/i
      ],
      [
        'Move business logic to application services',
        'Use ORM for data access (JPA, Hibernate)',
        'Implement CQRS if read/write separation needed'
      ]
    );
    patterns.push(storedProcPattern);

    // 4. Tight Coupling to DB Vendor
    const vendorLockPattern = this.createPattern(
      'DATABASE',
      'DB Vendor Lock-in (Oracle/DB2 Specific Features)',
      'Vendor-Agnostic Data Layer',
      sourceFiles,
      [
        /oracle|db2|mssql.*specific/i,
        /ROWNUM|TOP \d+|LIMIT \d+ OFFSET/,
        /vendor.*specific|proprietary.*feature/i
      ],
      [
        'Use JPA/Hibernate for vendor abstraction',
        'Migrate to PostgreSQL or cloud-native databases',
        'Implement repository pattern'
      ]
    );
    patterns.push(vendorLockPattern);

    // 5. Direct SQL from UI/Controllers
    const directSqlPattern = this.createPattern(
      'DATABASE',
      'Direct SQL from UI/Controllers (No Data Layer)',
      'Repository/DAO Pattern',
      sourceFiles,
      [
        /controller.*SELECT|controller.*INSERT/i,
        /Statement\.execute|createQuery.*SELECT/,
        /sql.*query.*controller/i
      ],
      [
        'Implement Repository pattern',
        'Use Spring Data JPA repositories',
        'Add service layer between controllers and data access'
      ]
    );
    patterns.push(directSqlPattern);

    return patterns;
  }

  private detectMessagingPatterns(sourceFiles: SourceFile[]): IntegrationPattern[] {
    const patterns: IntegrationPattern[] = [];

    // 1. Legacy Message Queue
    const legacyMqPattern = this.createPattern(
      'MESSAGING',
      'Legacy Message Queue (MQ/JMS/MSMQ)',
      'Modern Pub/Sub (Kafka/SNS/Event Hub)',
      sourceFiles,
      [
        /JMS|MSMQ|IBM.*MQ/,
        /MessageQueue|QueueConnection/,
        /legacy.*queue|old.*messaging/i
      ],
      [
        'Migrate to Apache Kafka or cloud pub/sub',
        'Implement event-driven architecture',
        'Use Kafka Connect for legacy integration'
      ]
    );
    patterns.push(legacyMqPattern);

    // 2. Point-to-Point Queue
    const p2pQueuePattern = this.createPattern(
      'MESSAGING',
      'Point-to-Point Queue Pattern (One Producer ↔ One Consumer)',
      'Publish-Subscribe Pattern',
      sourceFiles,
      [
        /Queue.*send.*receive/,
        /point.*to.*point|p2p.*queue/i,
        /MessageProducer.*MessageConsumer/
      ],
      [
        'Implement publish-subscribe pattern',
        'Use topics instead of queues where appropriate',
        'Add event sourcing capabilities'
      ]
    );
    patterns.push(p2pQueuePattern);

    // 3. Fire-and-Forget (No Tracking)
    const fireForgetPattern = this.createPattern(
      'MESSAGING',
      'Fire-and-Forget Messages (No Tracking/Retries)',
      'Reliable Messaging with DLQ & Retry',
      sourceFiles,
      [
        /send.*message.*forget|fire.*and.*forget/i,
        /no.*retry|no.*tracking/i,
        /async.*void.*send/
      ],
      [
        'Implement Dead Letter Queue (DLQ)',
        'Add retry policies with exponential backoff',
        'Use message tracking and correlation IDs'
      ]
    );
    patterns.push(fireForgetPattern);

    // 4. Synchronous "Fake Async"
    const fakeAsyncPattern = this.createPattern(
      'MESSAGING',
      'Synchronous "Fake Async" (Blocking on Async Calls)',
      'True Asynchronous Processing',
      sourceFiles,
      [
        /CompletableFuture\.get\(\)|Future\.get\(\)/,
        /async.*wait|await.*sync/i,
        /blocking.*async|synchronous.*async/i
      ],
      [
        'Use true async/await patterns',
        'Implement reactive programming (WebFlux, RxJava)',
        'Use callback-based or event-driven approach'
      ]
    );
    patterns.push(fakeAsyncPattern);

    // 5. Saga Pattern Opportunity
    const sagaPattern = this.createPattern(
      'MESSAGING',
      'Distributed Transaction Challenges',
      'Saga Pattern (Orchestrated/Choreographed)',
      sourceFiles,
      [
        /transaction.*distributed|@Transactional.*remote/i,
        /two.*phase.*commit|2pc/i,
        /cross.*service.*transaction/i
      ],
      [
        'Implement Saga pattern for distributed transactions',
        'Use orchestration (centralized) or choreography (event-driven)',
        'Add compensation logic for rollback scenarios'
      ]
    );
    patterns.push(sagaPattern);

    return patterns;
  }

  private detectFileBatchPatterns(sourceFiles: SourceFile[]): IntegrationPattern[] {
    const patterns: IntegrationPattern[] = [];

    // 1. File-Based Integration
    const fileIntegrationPattern = this.createPattern(
      'FILE_BATCH',
      'File-Based Integration (SFTP/FTP/Network Share)',
      'API + Event Hybrid (File Upload → Service → Events)',
      sourceFiles,
      [
        /SFTP|FTP|FileShare/,
        /file.*transfer|file.*upload|file.*download/i,
        /integration.*file|batch.*file/i
      ],
      [
        'Replace with REST APIs for file upload',
        'Emit events after file processing',
        'Use cloud storage (S3, Blob Storage) with notifications'
      ]
    );
    patterns.push(fileIntegrationPattern);

    // 2. Nightly Batch Jobs
    const batchJobPattern = this.createPattern(
      'FILE_BATCH',
      'Nightly Batch Jobs (JCL/Cron Moving Data)',
      'Incremental CDC-Based Data Flows',
      sourceFiles,
      [
        /cron|scheduler|@Scheduled/,
        /batch.*job|nightly.*job/i,
        /JCL|mainframe.*batch/i
      ],
      [
        'Implement Change Data Capture (CDC)',
        'Use streaming ETL (Spark, Flink, Data Factory)',
        'Move to event-driven real-time processing'
      ]
    );
    patterns.push(batchJobPattern);

    // 3. Excel/CSV Drop & Pickup
    const csvIntegrationPattern = this.createPattern(
      'FILE_BATCH',
      'Excel/CSV Drop & Pickup Integration',
      'Self-Service Data Products & APIs',
      sourceFiles,
      [
        /CSV|Excel|XLS|XLSX/,
        /file.*drop|file.*pickup/i,
        /import.*csv|parse.*excel/i
      ],
      [
        'Provide REST API for data submission',
        'Create data lake with curated datasets',
        'Implement web-based data upload forms'
      ]
    );
    patterns.push(csvIntegrationPattern);

    // 4. Report-Driven Integration
    const reportIntegrationPattern = this.createPattern(
      'FILE_BATCH',
      'Report-Driven Integration (Importing Generated Reports)',
      'Real-Time Data APIs',
      sourceFiles,
      [
        /report.*import|generate.*report/i,
        /pdf.*parse|report.*scraping/i,
        /integration.*via.*report/i
      ],
      [
        'Replace with direct API access to source data',
        'Implement GraphQL for flexible queries',
        'Use reporting APIs instead of file exports'
      ]
    );
    patterns.push(reportIntegrationPattern);

    return patterns;
  }

  private detectCrossCuttingPatterns(sourceFiles: SourceFile[]): IntegrationPattern[] {
    const patterns: IntegrationPattern[] = [];

    // 1. Circuit Breaker
    const circuitBreakerPattern = this.createPattern(
      'CROSS_CUTTING',
      'Missing Circuit Breaker Pattern',
      'Circuit Breaker with Fallback (Resilience4j)',
      sourceFiles,
      [
        /circuit.*breaker|@CircuitBreaker/i,
        /resilience4j|hystrix/i
      ],
      [
        'Implement Resilience4j circuit breaker',
        'Add fallback mechanisms',
        'Configure bulkhead isolation'
      ]
    );
    patterns.push(circuitBreakerPattern);

    // 2. API Security
    const apiSecurityPattern = this.createPattern(
      'CROSS_CUTTING',
      'API Security Patterns',
      'OAuth2/JWT/MTLS Authentication',
      sourceFiles,
      [
        /OAuth|JWT|MTLS/,
        /@PreAuthorize|@Secured/,
        /security.*filter|authentication/i
      ],
      [
        'Implement OAuth2/OIDC for API security',
        'Use JWT for stateless authentication',
        'Add MTLS for service-to-service communication'
      ]
    );
    patterns.push(apiSecurityPattern);

    // 3. Field-Level Encryption
    const encryptionPattern = this.createPattern(
      'CROSS_CUTTING',
      'Field-Level Encryption for PII/PCI',
      'Encryption & Tokenization (AWS KMS, PCI-DSS)',
      sourceFiles,
      [
        /encrypt|decrypt|AES|RSA/i,
        /tokenization|masking/i,
        /pii.*protection|sensitive.*data/i
      ],
      [
        'Implement field-level encryption (AES-256-GCM)',
        'Use cloud KMS for key management',
        'Add PCI-DSS compliant tokenization'
      ]
    );
    patterns.push(encryptionPattern);

    // 4. Request Caching
    const cachingPattern = this.createPattern(
      'CROSS_CUTTING',
      'Request Collapsing & Caching',
      'Distributed Caching (Redis/Memcached)',
      sourceFiles,
      [
        /@Cacheable|@CacheEvict/,
        /redis|memcached|cache/i,
        /caching.*strategy/i
      ],
      [
        'Implement distributed caching (Redis)',
        'Add cache invalidation strategies',
        'Use CDN for static content caching'
      ]
    );
    patterns.push(cachingPattern);

    // 5. Adapter/Wrapper Pattern
    const adapterPattern = this.createPattern(
      'CROSS_CUTTING',
      'Adapter/Wrapper for Legacy Systems',
      'Anti-Corruption Layer (ACL) Facade',
      sourceFiles,
      [
        /adapter|wrapper|facade/i,
        /anti.*corruption.*layer|acl/i,
        /legacy.*integration/i
      ],
      [
        'Implement Anti-Corruption Layer (ACL)',
        'Create facade pattern for legacy systems',
        'Use adapter pattern for protocol translation'
      ]
    );
    patterns.push(adapterPattern);

    return patterns;
  }

  private createPattern(
    category: IntegrationPattern['category'],
    podPattern: string,
    poaPattern: string,
    sourceFiles: SourceFile[],
    regexPatterns: RegExp[],
    recommendations: string[]
  ): IntegrationPattern {
    const evidence: string[] = [];
    const files: string[] = [];
    let matchCount = 0;

    for (const file of sourceFiles) {
      for (const pattern of regexPatterns) {
        const matches = file.content.match(pattern);
        if (matches) {
          matchCount++;
          if (!files.includes(file.relativePath)) {
            files.push(file.relativePath);
          }
          if (evidence.length < 5) {
            evidence.push(`${file.relativePath}: ${matches[0].substring(0, 100)}`);
          }
        }
      }
    }

    const detected = matchCount > 0;
    let confidence: 'LOW' | 'MEDIUM' | 'HIGH' = 'LOW';
    if (matchCount >= 5) confidence = 'HIGH';
    else if (matchCount >= 2) confidence = 'MEDIUM';

    return {
      category,
      podPattern,
      poaPattern,
      detected,
      confidence,
      evidence,
      files,
      recommendations
    };
  }
}
