#!/usr/bin/env python3
"""
LangChain RAG Service - Retrieval Augmented Generation for Code Analysis
Provides intelligent code documentation Q&A using LangChain chains and embeddings
"""

import json
import os
import sys
from typing import List, Dict, Any, Optional
from datetime import datetime

LANGCHAIN_AVAILABLE = False
OPENAI_AVAILABLE = False

Document = None
RecursiveCharacterTextSplitter = None
ChatPromptTemplate = None
StrOutputParser = None
ChatOpenAI = None

try:
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    from langchain.schema import Document
    from langchain.prompts import PromptTemplate, ChatPromptTemplate
    from langchain.chains import LLMChain
    from langchain_core.output_parsers import StrOutputParser
    LANGCHAIN_AVAILABLE = True
except ImportError:
    pass

try:
    from langchain_openai import ChatOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    pass


class LangChainCodeAnalyzer:
    """LangChain-powered code analysis with RAG capabilities"""
    
    def __init__(self, openai_api_key: Optional[str] = None):
        self.openai_api_key = openai_api_key or os.environ.get('OPENAI_API_KEY')
        self.llm = None
        self.text_splitter = None
        self._initialize()
    
    def _initialize(self):
        """Initialize LangChain components"""
        if LANGCHAIN_AVAILABLE:
            self.text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=2000,
                chunk_overlap=200,
                length_function=len,
                separators=["\n\n", "\n", " ", ""]
            )
        
        if OPENAI_AVAILABLE and self.openai_api_key:
            self.llm = ChatOpenAI(
                model="gpt-4o",
                temperature=0.3,
                openai_api_key=self.openai_api_key
            )
    
    def is_available(self) -> bool:
        """Check if LangChain is properly configured"""
        return LANGCHAIN_AVAILABLE and self.llm is not None
    
    def split_code_documents(self, files: List[Dict[str, str]]) -> List:
        """Split code files into chunks for analysis"""
        if not self.text_splitter:
            return []
        
        documents = []
        for file_info in files:
            filename = file_info.get('filename', 'unknown')
            content = file_info.get('content', '')
            
            chunks = self.text_splitter.split_text(content)
            for i, chunk in enumerate(chunks):
                doc = Document(
                    page_content=chunk,
                    metadata={
                        'source': filename,
                        'chunk': i,
                        'total_chunks': len(chunks)
                    }
                )
                documents.append(doc)
        
        return documents
    
    def analyze_architecture(self, code_context: str, question: str = None) -> Dict[str, Any]:
        """Analyze code architecture using LangChain chains"""
        if not self.is_available():
            return {
                'status': 'error',
                'message': 'LangChain not available. Please install langchain and langchain-openai packages.'
            }
        
        architecture_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert software architect analyzing codebase structure.
Analyze the provided code and identify:
1. Architectural patterns (MVC, microservices, layered, etc.)
2. Key components and their responsibilities
3. Dependencies and coupling between modules
4. Design patterns used (Factory, Singleton, Observer, etc.)
5. Potential improvements and refactoring opportunities

Provide structured, actionable insights."""),
            ("human", "Code Context:\n{code_context}\n\n{question}")
        ])
        
        chain = architecture_prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({
                'code_context': code_context[:15000],
                'question': question or 'Analyze this codebase architecture.'
            })
            
            return {
                'status': 'success',
                'analysis': result,
                'model': 'gpt-4o',
                'framework': 'langchain',
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def explain_code(self, code: str, language: str = 'auto') -> Dict[str, Any]:
        """Generate detailed code explanation using LangChain"""
        if not self.is_available():
            return {
                'status': 'error',
                'message': 'LangChain not available'
            }
        
        explain_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert code explainer. Analyze the provided code and explain:
1. What the code does (high-level overview)
2. How it works (step-by-step logic)
3. Key functions/methods and their purposes
4. Data flow and transformations
5. Dependencies and external integrations
6. Potential edge cases or issues

Use clear, concise language suitable for technical documentation."""),
            ("human", "Language: {language}\n\nCode:\n```\n{code}\n```")
        ])
        
        chain = explain_prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({
                'code': code[:10000],
                'language': language
            })
            
            return {
                'status': 'success',
                'explanation': result,
                'model': 'gpt-4o',
                'framework': 'langchain',
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def detect_patterns(self, code: str) -> Dict[str, Any]:
        """Detect integration and design patterns in code"""
        if not self.is_available():
            return {
                'status': 'error',
                'message': 'LangChain not available'
            }
        
        pattern_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert at identifying software patterns. Analyze the code for:

**Design Patterns:**
- Creational (Factory, Builder, Singleton, Prototype)
- Structural (Adapter, Bridge, Composite, Decorator, Facade)
- Behavioral (Observer, Strategy, Command, State, Template)

**Integration Patterns:**
- API Gateway, Message Queue, Event-Driven
- Database patterns (Repository, Unit of Work, CQRS)
- Microservice patterns (Circuit Breaker, Saga, API Composition)

**Anti-patterns:**
- God Class, Spaghetti Code, Copy-Paste Programming
- Magic Numbers, Deep Nesting, Feature Envy

Return a structured JSON response with detected patterns and their locations."""),
            ("human", "Analyze this code:\n```\n{code}\n```")
        ])
        
        chain = pattern_prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({'code': code[:12000]})
            
            return {
                'status': 'success',
                'patterns': result,
                'model': 'gpt-4o',
                'framework': 'langchain',
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def generate_migration_plan(self, source_code: str, target_tech: str) -> Dict[str, Any]:
        """Generate migration plan using LangChain chain"""
        if not self.is_available():
            return {
                'status': 'error',
                'message': 'LangChain not available'
            }
        
        migration_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert migration architect. Create a detailed migration plan for modernizing legacy code.

Include:
1. **Assessment**: Current state analysis, technical debt, dependencies
2. **Target Architecture**: Recommended modern architecture for {target_tech}
3. **Migration Strategy**: Strangler Fig, Big Bang, or Incremental approach
4. **Phase Breakdown**: Detailed phases with timelines
5. **Risk Analysis**: Potential risks and mitigation strategies
6. **Testing Strategy**: Unit, integration, and regression testing approach
7. **Rollback Plan**: Steps to revert if issues occur

Be specific and actionable."""),
            ("human", "Source Code to Migrate:\n{source_code}\n\nTarget Technology: {target_tech}")
        ])
        
        chain = migration_prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({
                'source_code': source_code[:10000],
                'target_tech': target_tech
            })
            
            return {
                'status': 'success',
                'migration_plan': result,
                'model': 'gpt-4o',
                'framework': 'langchain',
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def chat_about_code(self, code_context: str, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        """Interactive chat about code using LangChain with conversation history"""
        if not self.is_available():
            return {
                'status': 'error',
                'message': 'LangChain not available'
            }
        
        chat_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are Code Lens AI, an intelligent assistant for code analysis and understanding.
You have access to the following code context from the user's project:

{code_context}

Answer questions about this code accurately and helpfully. If you don't know something based on the provided context, say so."""),
            *[("human" if msg['role'] == 'user' else "assistant", msg['content']) for msg in messages[-10:]]
        ])
        
        chain = chat_prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({'code_context': code_context[:15000]})
            
            return {
                'status': 'success',
                'response': result,
                'model': 'gpt-4o',
                'framework': 'langchain',
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }


def parse_json_input() -> Dict[str, Any]:
    """Parse JSON input from stdin"""
    try:
        if not sys.stdin.isatty():
            stdin_data = sys.stdin.read().strip()
            if stdin_data:
                return json.loads(stdin_data)
    except json.JSONDecodeError:
        pass
    return {}


def main():
    """CLI interface for LangChain service"""
    if len(sys.argv) < 2:
        print(json.dumps({
            'status': 'error',
            'message': 'Usage: python langchainService.py <command>',
            'available_commands': ['analyze', 'explain', 'patterns', 'migrate', 'chat', 'status']
        }))
        return
    
    command = sys.argv[1]
    analyzer = LangChainCodeAnalyzer()
    
    if command == 'status':
        print(json.dumps({
            'langchain_available': LANGCHAIN_AVAILABLE,
            'openai_available': OPENAI_AVAILABLE,
            'service_ready': analyzer.is_available(),
            'features': [
                'Architecture Analysis',
                'Code Explanation',
                'Pattern Detection',
                'Migration Planning',
                'Interactive Chat'
            ]
        }))
        return
    
    input_data = parse_json_input()
    
    if command == 'analyze':
        code = input_data.get('code', '')
        question = input_data.get('question')
        result = analyzer.analyze_architecture(code, question)
        print(json.dumps(result))
    
    elif command == 'explain':
        code = input_data.get('code', '')
        language = input_data.get('language', 'auto')
        result = analyzer.explain_code(code, language)
        print(json.dumps(result))
    
    elif command == 'patterns':
        code = input_data.get('code', '')
        result = analyzer.detect_patterns(code)
        print(json.dumps(result))
    
    elif command == 'migrate':
        code = input_data.get('code', '')
        target = input_data.get('targetTech', 'Spring Boot 3')
        result = analyzer.generate_migration_plan(code, target)
        print(json.dumps(result))
    
    else:
        print(json.dumps({
            'status': 'error',
            'message': f'Unknown command: {command}'
        }))


if __name__ == '__main__':
    main()
