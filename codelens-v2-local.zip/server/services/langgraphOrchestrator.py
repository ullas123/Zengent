#!/usr/bin/env python3
"""
LangGraph Multi-Agent Orchestrator - Stateful Workflow for Code Analysis
Orchestrates multiple AI agents for comprehensive code analysis pipelines
"""

import json
import os
import sys
from typing import List, Dict, Any, Optional, TypedDict, Annotated
from datetime import datetime
from enum import Enum

LANGGRAPH_AVAILABLE = False
LANGCHAIN_AVAILABLE = False

StateGraph = None
START = None
END = None
ChatOpenAI = None
ChatPromptTemplate = None
StrOutputParser = None

try:
    from langgraph.graph import StateGraph, START, END
    from langgraph.graph.message import add_messages
    LANGGRAPH_AVAILABLE = True
except ImportError:
    pass

try:
    from langchain_openai import ChatOpenAI
    from langchain.prompts import ChatPromptTemplate
    from langchain_core.output_parsers import StrOutputParser
    LANGCHAIN_AVAILABLE = True
except ImportError:
    pass


class AnalysisPhase(str, Enum):
    STRUCTURE = "structure_analysis"
    SECURITY = "security_scan"
    QUALITY = "quality_metrics"
    PATTERNS = "pattern_detection"
    MIGRATION = "migration_planning"
    SUMMARY = "final_summary"


class WorkflowState(TypedDict):
    """State maintained across the analysis workflow"""
    code_context: str
    project_name: str
    analysis_type: str
    current_phase: str
    structure_analysis: Optional[str]
    security_scan: Optional[str]
    quality_metrics: Optional[str]
    pattern_detection: Optional[str]
    migration_plan: Optional[str]
    final_summary: Optional[str]
    errors: List[str]
    metadata: Dict[str, Any]


class LangGraphOrchestrator:
    """LangGraph-powered multi-agent orchestrator for code analysis workflows"""
    
    def __init__(self, openai_api_key: Optional[str] = None):
        self.openai_api_key = openai_api_key or os.environ.get('OPENAI_API_KEY')
        self.llm = None
        self.workflow = None
        self._initialize()
    
    def _initialize(self):
        """Initialize LangGraph workflow"""
        if LANGCHAIN_AVAILABLE and self.openai_api_key:
            self.llm = ChatOpenAI(
                model="gpt-4o",
                temperature=0.2,
                openai_api_key=self.openai_api_key
            )
        
        if LANGGRAPH_AVAILABLE and self.llm:
            self._build_workflow()
    
    def _build_workflow(self):
        """Build the LangGraph state machine for code analysis"""
        workflow = StateGraph(WorkflowState)
        
        workflow.add_node("structure_analysis", self._analyze_structure)
        workflow.add_node("security_scan", self._scan_security)
        workflow.add_node("quality_metrics", self._assess_quality)
        workflow.add_node("pattern_detection", self._detect_patterns)
        workflow.add_node("migration_planning", self._plan_migration)
        workflow.add_node("final_summary", self._generate_summary)
        
        workflow.add_edge(START, "structure_analysis")
        workflow.add_edge("structure_analysis", "security_scan")
        workflow.add_edge("security_scan", "quality_metrics")
        workflow.add_edge("quality_metrics", "pattern_detection")
        workflow.add_edge("pattern_detection", "migration_planning")
        workflow.add_edge("migration_planning", "final_summary")
        workflow.add_edge("final_summary", END)
        
        self.workflow = workflow.compile()
    
    def is_available(self) -> bool:
        """Check if LangGraph is properly configured"""
        return LANGGRAPH_AVAILABLE and LANGCHAIN_AVAILABLE and self.llm is not None and self.workflow is not None
    
    def _analyze_structure(self, state: WorkflowState) -> WorkflowState:
        """Agent 1: Analyze code structure and architecture"""
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert code structure analyst. Analyze the codebase and identify:
1. Overall architecture pattern (MVC, microservices, monolith, etc.)
2. Module/package organization
3. Key classes and their responsibilities
4. Dependency relationships
5. Entry points and main flows

Be concise but thorough."""),
            ("human", "Analyze this codebase:\n{code}")
        ])
        
        chain = prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({'code': state['code_context'][:12000]})
            state['structure_analysis'] = result
            state['current_phase'] = AnalysisPhase.SECURITY.value
        except Exception as e:
            state['errors'].append(f"Structure analysis error: {str(e)}")
            state['structure_analysis'] = "Analysis failed"
        
        return state
    
    def _scan_security(self, state: WorkflowState) -> WorkflowState:
        """Agent 2: Scan for security vulnerabilities"""
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a security expert. Analyze the code for vulnerabilities:
1. SQL Injection risks
2. XSS vulnerabilities
3. Authentication/Authorization issues
4. Sensitive data exposure
5. Input validation gaps
6. OWASP Top 10 concerns

Provide severity ratings and remediation suggestions."""),
            ("human", "Security scan this code:\n{code}")
        ])
        
        chain = prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({'code': state['code_context'][:12000]})
            state['security_scan'] = result
            state['current_phase'] = AnalysisPhase.QUALITY.value
        except Exception as e:
            state['errors'].append(f"Security scan error: {str(e)}")
            state['security_scan'] = "Scan failed"
        
        return state
    
    def _assess_quality(self, state: WorkflowState) -> WorkflowState:
        """Agent 3: Assess code quality metrics"""
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a code quality expert. Evaluate the code against ISO 5055 standards:
1. Reliability score (0-100)
2. Security rating
3. Performance efficiency
4. Maintainability index
5. Technical debt indicators
6. Code smell detection

Provide actionable improvement suggestions."""),
            ("human", "Quality assessment for:\n{code}")
        ])
        
        chain = prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({'code': state['code_context'][:12000]})
            state['quality_metrics'] = result
            state['current_phase'] = AnalysisPhase.PATTERNS.value
        except Exception as e:
            state['errors'].append(f"Quality assessment error: {str(e)}")
            state['quality_metrics'] = "Assessment failed"
        
        return state
    
    def _detect_patterns(self, state: WorkflowState) -> WorkflowState:
        """Agent 4: Detect integration and design patterns"""
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a pattern recognition expert. Identify patterns in the code:

**Integration Patterns (POD - Point of Departure):**
- Database access patterns
- API integration patterns
- Message queue patterns
- File I/O patterns
- External service calls

**Design Patterns:**
- Creational, Structural, Behavioral patterns
- Enterprise patterns

Classify each as POD (legacy) or POA (modern target)."""),
            ("human", "Pattern detection for:\n{code}")
        ])
        
        chain = prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({'code': state['code_context'][:12000]})
            state['pattern_detection'] = result
            state['current_phase'] = AnalysisPhase.MIGRATION.value
        except Exception as e:
            state['errors'].append(f"Pattern detection error: {str(e)}")
            state['pattern_detection'] = "Detection failed"
        
        return state
    
    def _plan_migration(self, state: WorkflowState) -> WorkflowState:
        """Agent 5: Create migration roadmap"""
        context = f"""
Previous Analysis:
- Structure: {state.get('structure_analysis', 'N/A')[:1000]}
- Security: {state.get('security_scan', 'N/A')[:1000]}
- Quality: {state.get('quality_metrics', 'N/A')[:1000]}
- Patterns: {state.get('pattern_detection', 'N/A')[:1000]}
"""
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a migration planning expert. Based on the analysis results, create a migration plan:

1. **Priority Matrix**: What to migrate first
2. **Phase Breakdown**: Sprint-level tasks
3. **Risk Assessment**: Migration risks and mitigation
4. **Resource Estimation**: Time and effort
5. **POD to POA Mapping**: Legacy to modern equivalents
6. **Testing Strategy**: Validation approach

Use the previous analysis to inform recommendations."""),
            ("human", "Create migration plan based on:\n{context}")
        ])
        
        chain = prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({'context': context})
            state['migration_plan'] = result
            state['current_phase'] = AnalysisPhase.SUMMARY.value
        except Exception as e:
            state['errors'].append(f"Migration planning error: {str(e)}")
            state['migration_plan'] = "Planning failed"
        
        return state
    
    def _generate_summary(self, state: WorkflowState) -> WorkflowState:
        """Agent 6: Generate executive summary"""
        all_results = f"""
## Structure Analysis
{state.get('structure_analysis', 'N/A')[:800]}

## Security Scan
{state.get('security_scan', 'N/A')[:800]}

## Quality Metrics
{state.get('quality_metrics', 'N/A')[:800]}

## Pattern Detection
{state.get('pattern_detection', 'N/A')[:800]}

## Migration Plan
{state.get('migration_plan', 'N/A')[:800]}
"""
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an executive report writer. Create a concise summary:

1. **Executive Overview**: 2-3 sentences on project state
2. **Key Findings**: Top 5 insights
3. **Risk Summary**: Critical issues needing attention
4. **Quick Wins**: Immediate improvements possible
5. **Recommendations**: Top 3 action items
6. **Next Steps**: Clear path forward

Be concise and actionable."""),
            ("human", "Summarize analysis:\n{results}")
        ])
        
        chain = prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({'results': all_results})
            state['final_summary'] = result
            state['current_phase'] = 'completed'
        except Exception as e:
            state['errors'].append(f"Summary generation error: {str(e)}")
            state['final_summary'] = "Summary failed"
        
        return state
    
    def run_full_analysis(self, code_context: str, project_name: str = "Unknown") -> Dict[str, Any]:
        """Execute the complete multi-agent analysis workflow"""
        if not self.is_available():
            return {
                'status': 'error',
                'message': 'LangGraph not available. Install langgraph and langchain-openai packages.',
                'langgraph_available': LANGGRAPH_AVAILABLE,
                'langchain_available': LANGCHAIN_AVAILABLE
            }
        
        initial_state: WorkflowState = {
            'code_context': code_context,
            'project_name': project_name,
            'analysis_type': 'full',
            'current_phase': AnalysisPhase.STRUCTURE.value,
            'structure_analysis': None,
            'security_scan': None,
            'quality_metrics': None,
            'pattern_detection': None,
            'migration_plan': None,
            'final_summary': None,
            'errors': [],
            'metadata': {
                'start_time': datetime.now().isoformat(),
                'model': 'gpt-4o',
                'framework': 'langgraph'
            }
        }
        
        try:
            final_state = self.workflow.invoke(initial_state)
            final_state['metadata']['end_time'] = datetime.now().isoformat()
            
            return {
                'status': 'success',
                'project_name': project_name,
                'structure_analysis': final_state.get('structure_analysis'),
                'security_scan': final_state.get('security_scan'),
                'quality_metrics': final_state.get('quality_metrics'),
                'pattern_detection': final_state.get('pattern_detection'),
                'migration_plan': final_state.get('migration_plan'),
                'executive_summary': final_state.get('final_summary'),
                'errors': final_state.get('errors', []),
                'metadata': final_state.get('metadata'),
                'framework': 'langgraph',
                'agents_used': 6
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e),
                'framework': 'langgraph'
            }
    
    def run_quick_analysis(self, code_context: str) -> Dict[str, Any]:
        """Run a quick single-agent analysis"""
        if not self.llm:
            return {
                'status': 'error',
                'message': 'LLM not available'
            }
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a code analysis expert. Provide a quick assessment covering:
1. Architecture overview
2. Main concerns (security, quality)
3. Key patterns detected
4. Top 3 recommendations

Be concise."""),
            ("human", "Quick analysis:\n{code}")
        ])
        
        chain = prompt | self.llm | StrOutputParser()
        
        try:
            result = chain.invoke({'code': code_context[:10000]})
            return {
                'status': 'success',
                'analysis': result,
                'framework': 'langchain',
                'type': 'quick'
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }


def parse_json_input() -> Dict[str, Any]:
    """Parse JSON input from stdin"""
    try:
        if not sys.stdin.isatty():
            stdin_data = sys.stdin.read().strip()
            if stdin_data:
                return json.loads(stdin_data)
    except json.JSONDecodeError:
        pass
    return {}


def main():
    """CLI interface for LangGraph orchestrator"""
    if len(sys.argv) < 2:
        print(json.dumps({
            'status': 'error',
            'message': 'Usage: python langgraphOrchestrator.py <command>',
            'commands': ['full', 'quick', 'status']
        }))
        return
    
    command = sys.argv[1]
    orchestrator = LangGraphOrchestrator()
    
    if command == 'status':
        print(json.dumps({
            'langgraph_available': LANGGRAPH_AVAILABLE,
            'langchain_available': LANGCHAIN_AVAILABLE,
            'service_ready': orchestrator.is_available(),
            'workflow_phases': [phase.value for phase in AnalysisPhase],
            'agents': [
                'Structure Analyzer',
                'Security Scanner',
                'Quality Assessor',
                'Pattern Detector',
                'Migration Planner',
                'Summary Generator'
            ]
        }))
        return
    
    input_data = parse_json_input()
    code = input_data.get('code', '')
    project_name = input_data.get('projectName', 'Unknown')
    
    if command == 'full':
        result = orchestrator.run_full_analysis(code, project_name)
        print(json.dumps(result, indent=2))
    
    elif command == 'quick':
        result = orchestrator.run_quick_analysis(code)
        print(json.dumps(result, indent=2))
    
    else:
        print(json.dumps({
            'status': 'error',
            'message': f'Unknown command: {command}'
        }))


if __name__ == '__main__':
    main()
