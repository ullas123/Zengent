# CODE LENS v2 - Enterprise Application Intelligence Platform

**Platform Tagline**: Code Analytics Agent

---

## Installation & Setup

### Prerequisites
- **Node.js 18+** - [Download](https://nodejs.org)
- **Python 3.10+** - [Download](https://python.org)

### Quick Start

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Run the application:**
   ```bash
   npm run dev
   ```

3. **Open in browser:**
   ```
   http://localhost:5000
   ```

### Alternative Installation (if cross-env error occurs)

```bash
npm install cross-env --save-dev
npm run dev
```

### Login Credentials

```
Username: amex
Password: zensar
```

---

## Key Features

### 1. Multi-Language Code Analysis
- **Supported Languages**: Java (Spring Boot), Python (Django/Flask), PySpark, Mainframe (COBOL/JCL), C#, Kotlin
- ZIP file upload (up to 50MB) or GitHub repository import
- Automatic code parsing and structure analysis
- Handles large enterprise applications (1000+ files)

### 2. Demographic Field Scanning & Compliance
- **39 pre-defined patterns** across 5 categories (Names, IDs, Contact, Financial, Health)
- Detects sensitive data: SSN, phone numbers, emails, addresses, credit cards, medical records
- Excel field mapping for custom field lists
- Compliance reporting for GDPR, HIPAA, PCI-DSS

### 3. AI-Powered Analysis
- **Online Mode**: OpenAI GPT-4o integration
- **Offline Mode**: Local LLMs via Ollama (Code Llama, Deepseek Coder, Llama 3, Mistral)
- Architecture insights and recommendations
- Code quality assessment

### 4. Integration Pattern Detection (30+ Patterns)
- **API Patterns**: REST/SOAP endpoints, HTTP calls, API Gateway detection
- **Database Patterns**: Shared database, stored procedures, vendor lock-in
- **Messaging Patterns**: MQ/JMS, event-driven, dead letter queues
- **File/Batch Patterns**: Scheduled jobs, SFTP, CSV processing
- **Cross-Cutting**: Logging, caching, security, monitoring

### 5. POD→POA Migration Planning
- Legacy system (POD) assessment with cost estimation
- Modern architecture (POA) recommendations
- Phased migration roadmap generation
- AI-powered strategy selection (Strangler Fig, Phased, Big Bang, Lift & Shift)
- Cost-benefit analysis and ROI calculation

### 6. Data Image & Quality Measures
- **ISO-5055 Quality Metrics**: Reliability, Security, Maintainability, Performance
- **CWE Vulnerability Detection**: 30+ security patterns
- **Data Lineage Tracking**: Field-to-function mapping
- Technical debt dashboard

### 7. Interactive Visualizations
- UML class diagrams
- Dependency graphs
- Component and sequence diagrams
- Data flow diagrams

### 8. Professional Reporting
- Export formats: PDF, DOC, HTML
- Comprehensive analysis with diagrams
- Corporate branding support

### 9. Swagger API Documentation
- Automatic extraction from REST controllers
- Interactive API documentation generation

### 10. GitHub Integration
- Direct repository import via URL
- Automatic cloning and analysis

---

## Technology Stack

| Layer | Technology |
|-------|------------|
| **Frontend** | React, TypeScript, Tailwind CSS, shadcn/ui |
| **Backend** | Express.js, TypeScript |
| **Database** | PostgreSQL with Drizzle ORM (optional - works with in-memory storage) |
| **AI Integration** | OpenAI GPT-4o, Ollama (local LLMs) |
| **Visualization** | React Flow, Cytoscape.js, Mermaid.js |
| **Python Services** | Code analysis, ML field matching |

---

## Database Options

### Option 1: In-Memory Storage (Default)
- No setup required
- Data resets on restart
- Good for testing and demos

### Option 2: PostgreSQL Database
- Set environment variable:
  ```bash
  DATABASE_URL=postgresql://user:password@host:5432/database
  ```
- Persistent data storage
- Recommended for production

---

## Environment Variables (Optional)

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | PostgreSQL connection string |
| `OPENAI_API_KEY` | OpenAI API key for cloud AI analysis |
| `OLLAMA_ENDPOINT` | Ollama server URL (default: http://localhost:11434) |
| `OLLAMA_MODEL` | Ollama model name (default: codellama) |

---

## Project Structure

```
├── client/              # React frontend
│   └── src/
│       ├── components/  # UI components
│       ├── pages/       # Application pages
│       └── lib/         # Utilities
├── server/              # Express backend
│   ├── routes.ts        # API routes
│   ├── services/        # Business logic
│   └── storage.ts       # Data storage
├── shared/              # Shared TypeScript types
├── python_services/     # Python analysis scripts
└── attached_assets/     # Images and logos
```

---

## Value Proposition

| Metric | Value |
|--------|-------|
| **Time Savings** | 70-80% reduction in manual analysis |
| **Compliance Detection** | 95%+ accuracy for PII/PHI fields |
| **Documentation Speed** | 90% faster |
| **Cost Reduction** | 40-60% on migration projects |

---

## License

Proprietary - All rights reserved.

**Developed by**: Ullas Krishnan, Sr Solution Architect  
**Copyright**: Project Diamond Zensar Team
