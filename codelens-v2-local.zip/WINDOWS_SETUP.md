# Windows Setup Guide for Code Lens

## Problem
When running `npm run dev` on Windows, you see this error:
```
'NODE_ENV' is not recognized as an internal or external command
```

This happens because Windows Command Prompt doesn't understand Unix-style environment variables.

## Solution: Fix package.json

The `cross-env` package is already installed in your project. You just need to update the npm scripts to use it.

### Step 1: Open package.json
Find and open the `package.json` file in your project folder.

### Step 2: Find the "scripts" section
Look for these lines (around line 6-11):
```json
"scripts": {
  "dev": "NODE_ENV=development tsx server/index.ts",
  "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
  "start": "NODE_ENV=production node dist/index.js",
  "check": "tsc",
  "db:push": "drizzle-kit push"
},
```

### Step 3: Replace with Windows-compatible scripts
Change the scripts to:
```json
"scripts": {
  "dev": "cross-env NODE_ENV=development tsx server/index.ts",
  "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
  "start": "cross-env NODE_ENV=production node dist/index.js",
  "check": "tsc",
  "db:push": "drizzle-kit push"
},
```

**Notice the changes:**
- Line "dev": Added `cross-env` before `NODE_ENV`
- Line "start": Added `cross-env` before `NODE_ENV`

### Step 4: Save the file

### Step 5: Run the app
```bash
npm run dev
```

## What You'll See

The app will start and show:
```
✅ Using MemStorage (in-memory)
🚀 Server running in development mode on port 5000
```

This means your app is running WITHOUT a database (data is stored in memory and resets when you restart).

## IMPORTANT: Windows ENOTSUP Error Fixed

The error you saw:
```
Error: listen ENOTSUP: operation not supported on socket 0.0.0.0:5000
```

**This has been FIXED automatically!** The app now:
- Uses `localhost` when running in development mode (your machine)
- Uses `0.0.0.0` when running in production mode (cloud hosting)

**No additional configuration needed!** Just run `npm run dev` after fixing package.json.

## Complete Local Setup Instructions

1. **Download project**: Download the project as ZIP
2. **Extract files**: Unzip to your desired folder
3. **Install Node.js**: Download from https://nodejs.org/ (version 18 or higher)
4. **Open Command Prompt** or PowerShell in the project folder
5. **Install dependencies**:
   ```bash
   npm install
   ```
6. **Create uploads folder**:
   ```bash
   mkdir uploads
   ```
7. **Fix package.json** (follow Step 1-4 above to add `cross-env`)
8. **Run the app**:
   ```bash
   npm run dev
   ```
9. **Open browser**: Go to `http://localhost:5000`
10. **Login**: 
    - Username: `amex`
    - Password: `zensar`

**That's it!** The ENOTSUP error is automatically fixed - the app detects Windows and uses `localhost` instead of `0.0.0.0`.

## Notes

- **No database required**: The app works perfectly without PostgreSQL
- **Data resets**: All uploaded projects reset when you restart the app (stored in memory only)
- **For permanent storage**: You would need to install and configure PostgreSQL separately

## Troubleshooting

### "Cannot find module 'tsx'"
Run: `npm install`

### Port 5000 already in use
Change PORT in the code or stop other apps using port 5000

### "Module not found" errors
Delete `node_modules` folder and run `npm install` again

---

**That's it!** Your Code Lens app should now run on Windows without any issues.
