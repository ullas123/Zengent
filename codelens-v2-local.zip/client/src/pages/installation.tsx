import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Play, 
  Download, 
  Terminal, 
  CheckCircle,
  Copy,
  Server,
  Database,
  Globe,
  Zap
} from "lucide-react";
import Layout from "@/components/layout";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function InstallationPage() {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const { toast } = useToast();

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedCode(label);
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard`,
      });
      setTimeout(() => setCopiedCode(null), 2000);
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const CodeBlock = ({ code, label }: { code: string; label: string }) => (
    <div className="relative">
      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
        {code}
      </pre>
      <Button
        size="sm"
        variant="outline"
        className="absolute top-2 right-2 h-8 w-8 p-0"
        onClick={() => copyToClipboard(code, label)}
      >
        {copiedCode === label ? (
          <CheckCircle className="h-4 w-4 text-green-600" />
        ) : (
          <Copy className="h-4 w-4" />
        )}
      </Button>
    </div>
  );

  const prerequisites = [
    { name: "Node.js 18+", icon: <Server className="w-4 h-4" /> },
    { name: "PostgreSQL database (optional)", icon: <Database className="w-4 h-4" /> },
    { name: "OpenAI API key (optional, for cloud AI)", icon: <Globe className="w-4 h-4" /> },
    { name: "Ollama (optional, for offline AI)", icon: <Zap className="w-4 h-4" /> }
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
            Installation Steps
          </h1>
          <p className="text-gray-600">Get Zengent AI Platform up and running in minutes</p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              Prerequisites
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-3">
              {prerequisites.map((prereq, index) => (
                <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                  <div className="text-blue-600">{prereq.icon}</div>
                  <span className="text-sm">{prereq.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="w-5 h-5 text-blue-600" />
              Step 1: Clone the Repository
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CodeBlock 
              code={`git clone <repository-url>
cd zengent-ai-platform`}
              label="Clone command"
            />
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-purple-600" />
              Step 2: Install Dependencies
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CodeBlock 
              code="npm install"
              label="Install command"
            />
            <p className="text-sm text-gray-500 mt-3">
              If you encounter issues, try: <code className="bg-gray-100 px-2 py-1 rounded">npm install cross-env --save-dev</code>
            </p>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5 text-green-600" />
              Step 3: Configure Environment (Optional)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              Create a <code className="bg-gray-100 px-2 py-1 rounded">.env</code> file for optional features:
            </p>
            <CodeBlock 
              code={`# Database (optional - uses in-memory if not set)
DATABASE_URL=postgresql://user:password@localhost:5432/codelens

# AI Integration (optional)
OPENAI_API_KEY=your_openai_api_key

# Ollama for offline AI (optional)
OLLAMA_ENDPOINT=http://localhost:11434
OLLAMA_MODEL=codellama`}
              label="Environment variables"
            />
            <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 p-3 rounded-lg">
              <Zap className="w-4 h-4" />
              <span>The app works without any environment variables using in-memory storage</span>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Play className="w-5 h-5 text-green-600" />
              Step 4: Start the Application
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CodeBlock 
              code="npm run dev"
              label="Start command"
            />
            <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-green-800">
                The application will be available at: <strong>http://localhost:5000</strong>
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-blue-600" />
              Step 5: Login
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 border rounded-lg">
                <p className="text-sm text-gray-600 mb-2">Username</p>
                <code className="text-lg font-mono bg-gray-100 px-3 py-1 rounded">amex</code>
              </div>
              <div className="p-4 border rounded-lg">
                <p className="text-sm text-gray-600 mb-2">Password</p>
                <code className="text-lg font-mono bg-gray-100 px-3 py-1 rounded">zensar</code>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Available Scripts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {[
                { cmd: "npm run dev", desc: "Start development server" },
                { cmd: "npm run build", desc: "Build for production" },
                { cmd: "npm run db:push", desc: "Push schema to database" },
                { cmd: "npm run db:studio", desc: "Open database GUI" }
              ].map((script, i) => (
                <div key={i} className="flex items-center justify-between p-3 border rounded-lg">
                  <code className="text-sm font-mono text-blue-600">{script.cmd}</code>
                  <Badge variant="secondary">{script.desc}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 text-center text-sm text-gray-500">
          <p>Built by Diamond Zensar Team</p>
        </div>
      </div>
    </Layout>
  );
}
