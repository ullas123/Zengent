import { 
  Code2, 
  Database, 
  Globe, 
  Zap, 
  Server, 
  Cpu, 
  FileCode, 
  GitBranch,
  Brain,
  Shield,
  ArrowRight,
  Upload,
  Search,
  BarChart,
  FileText,
  Sparkles,
  Layers,
  Network,
  Bot,
  Workflow,
  MessageSquare,
  Target
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function TechnologyFlow() {
  return (
    <div className="container mx-auto px-6 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Technology & Program Flow</h1>
        <p className="text-gray-600 dark:text-gray-300">Complete overview of our technology stack and how the system works</p>
      </div>

      <Tabs defaultValue="technology" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="technology" data-testid="tab-technology">
            <Code2 className="w-4 h-4 mr-2" />
            Technology Stack
          </TabsTrigger>
          <TabsTrigger value="ai-tech" data-testid="tab-ai-tech">
            <Brain className="w-4 h-4 mr-2" />
            AI Technologies
          </TabsTrigger>
          <TabsTrigger value="flow" data-testid="tab-flow">
            <GitBranch className="w-4 h-4 mr-2" />
            Program Flow
          </TabsTrigger>
        </TabsList>

        {/* Technology Stack Tab */}
        <TabsContent value="technology" className="space-y-6">
          {/* Frontend Technologies */}
          <Card data-testid="card-frontend">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-blue-600" />
                Frontend Technologies
              </CardTitle>
              <CardDescription>Modern React-based user interface</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-blue-500" />
                  Core Framework
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• React 18 with TypeScript</li>
                  <li>• Vite for fast builds</li>
                  <li>• Wouter for routing</li>
                  <li>• TanStack Query for state management</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Zap className="w-4 h-4 text-yellow-500" />
                  UI Components
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• shadcn/ui component library</li>
                  <li>• Radix UI primitives</li>
                  <li>• Tailwind CSS styling</li>
                  <li>• Lucide React icons</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <BarChart className="w-4 h-4 text-green-500" />
                  Visualization
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• Mermaid.js for diagrams</li>
                  <li>• AntV X6 for components</li>
                  <li>• React Flow for graphs</li>
                  <li>• Recharts for analytics</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <FileText className="w-4 h-4 text-purple-500" />
                  Document Export
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• jsPDF for PDF generation</li>
                  <li>• docx for Word documents</li>
                  <li>• HTML2Canvas for previews</li>
                  <li>• JSZip for file handling</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Backend Technologies */}
          <Card data-testid="card-backend">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Server className="w-5 h-5 text-green-600" />
                Backend Technologies
              </CardTitle>
              <CardDescription>Robust Node.js server architecture</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-green-500" />
                  Server Framework
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• Express.js with TypeScript</li>
                  <li>• RESTful API design</li>
                  <li>• Multer for file uploads (50MB limit)</li>
                  <li>• Express Session management</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Database className="w-4 h-4 text-blue-500" />
                  Database & ORM
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• PostgreSQL database</li>
                  <li>• Drizzle ORM for type-safe queries</li>
                  <li>• Neon serverless integration</li>
                  <li>• Zod schema validation</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Shield className="w-4 h-4 text-red-500" />
                  Authentication
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• Passport.js authentication</li>
                  <li>• bcrypt password encryption</li>
                  <li>• Session-based auth</li>
                  <li>• Multi-tenant support</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-orange-500" />
                  Code Analysis
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• Java (Spring Boot, JPA, MVC)</li>
                  <li>• Python (Django, Flask)</li>
                  <li>• PySpark (DataFrame, Job Flows)</li>
                  <li>• Mainframe (COBOL, JCL)</li>
                  <li>• C# (.NET, ASP.NET Core)</li>
                  <li>• Kotlin (Android, JVM)</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* AI & ML Stack */}
          <Card data-testid="card-ai">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-purple-600" />
                AI & Machine Learning
              </CardTitle>
              <CardDescription>Advanced AI-powered analysis and insights</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-purple-500" />
                  AI Models
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• OpenAI GPT-4o (cloud)</li>
                  <li>• Ollama local LLMs</li>
                  <li>• Code Llama, Deepseek Coder</li>
                  <li>• Llama 3, Mistral, StarCoder</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Database className="w-4 h-4 text-indigo-500" />
                  Vector & Knowledge
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• ChromaDB vector storage</li>
                  <li>• HuggingFace transformers</li>
                  <li>• CodeBERT for code quality</li>
                  <li>• Sentence transformers</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <GitBranch className="w-4 h-4 text-teal-500" />
                  AI Orchestration
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• LangChain for document processing</li>
                  <li>• LangGraph for workflows</li>
                  <li>• Langfuse for observability</li>
                  <li>• Redis for caching</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Shield className="w-4 h-4 text-cyan-500" />
                  Code Lens ML & Scanning
                </h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• Pure Python/NumPy ML (no TensorFlow)</li>
                  <li>• 39 regex patterns (5 categories)</li>
                  <li>• Excel field mapping (exact match)</li>
                  <li>• Levenshtein & token similarity</li>
                  <li>• Lookup table (95%+ confidence)</li>
                  <li>• Acronym detection (90%+ confidence)</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Additional Tools */}
          <Card data-testid="card-tools">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-orange-600" />
                Additional Tools & Libraries
              </CardTitle>
              <CardDescription>Supporting technologies and utilities</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Development</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• TypeScript</li>
                  <li>• ESBuild</li>
                  <li>• Vite</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Validation</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• Zod schemas</li>
                  <li>• date-fns</li>
                  <li>• clsx utilities</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Integration</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1 ml-6">
                  <li>• GitHub API</li>
                  <li>• WebSocket (ws)</li>
                  <li>• OpenID Client</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI Technologies Tab */}
        <TabsContent value="ai-tech" className="space-y-6">
          {/* LLM Models */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                Large Language Models (LLMs)
              </CardTitle>
              <CardDescription>Multi-model support for cloud-based and offline AI analysis</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <div className="border-2 border-green-300 rounded-lg p-4 hover:shadow-md transition-shadow bg-green-50/50 dark:bg-green-900/10">
                <h4 className="font-semibold text-gray-900 dark:text-white">OpenAI GPT-4o</h4>
                <div className="flex gap-1 mt-1">
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded">Primary</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">Advanced reasoning for architecture analysis, pattern detection, and migration recommendations</p>
              </div>
              <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <h4 className="font-semibold text-gray-900 dark:text-white">Claude 3.5 Sonnet</h4>
                <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded">Planned</span>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">Anthropic's model for nuanced code analysis with strong context understanding</p>
              </div>
              <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <h4 className="font-semibold text-gray-900 dark:text-white">Google Gemini Pro</h4>
                <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded">Planned</span>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">Google's multimodal AI for comprehensive code and diagram analysis</p>
              </div>
              <div className="border-2 border-green-300 rounded-lg p-4 hover:shadow-md transition-shadow bg-green-50/50 dark:bg-green-900/10">
                <h4 className="font-semibold text-gray-900 dark:text-white">Code Llama (Ollama)</h4>
                <div className="flex gap-1 mt-1">
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                  <span className="text-xs bg-orange-100 text-orange-800 px-2 py-0.5 rounded">Offline</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">Meta's code-specialized model for privacy-first offline analysis</p>
              </div>
              <div className="border-2 border-green-300 rounded-lg p-4 hover:shadow-md transition-shadow bg-green-50/50 dark:bg-green-900/10">
                <h4 className="font-semibold text-gray-900 dark:text-white">Deepseek Coder (Ollama)</h4>
                <div className="flex gap-1 mt-1">
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                  <span className="text-xs bg-orange-100 text-orange-800 px-2 py-0.5 rounded">Offline</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">Specialized coding model optimized for code understanding tasks</p>
              </div>
              <div className="border-2 border-green-300 rounded-lg p-4 hover:shadow-md transition-shadow bg-green-50/50 dark:bg-green-900/10">
                <h4 className="font-semibold text-gray-900 dark:text-white">Mistral 7B / StarCoder</h4>
                <div className="flex gap-1 mt-1">
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                  <span className="text-xs bg-orange-100 text-orange-800 px-2 py-0.5 rounded">Offline</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">Efficient open-source models for multi-language analysis</p>
              </div>
            </CardContent>
          </Card>

          {/* AI Frameworks */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-blue-600" />
                AI Frameworks & Libraries
              </CardTitle>
              <CardDescription>Core frameworks powering intelligent code analysis</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-6 md:grid-cols-2">
              <div className="border-2 border-green-300 rounded-lg p-4 bg-green-50/50 dark:bg-green-900/10">
                <div className="flex items-center gap-2 mb-2">
                  <GitBranch className="w-6 h-6 text-emerald-600" />
                  <h4 className="font-semibold">LangChain</h4>
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">Framework for developing applications powered by language models</p>
                <ul className="text-xs text-gray-500 space-y-1">
                  <li>• Architecture analysis chains</li>
                  <li>• Code explanation prompts</li>
                  <li>• Pattern detection pipelines</li>
                  <li>• Migration plan generation</li>
                </ul>
              </div>
              <div className="border-2 border-green-300 rounded-lg p-4 bg-green-50/50 dark:bg-green-900/10">
                <div className="flex items-center gap-2 mb-2">
                  <Workflow className="w-6 h-6 text-blue-600" />
                  <h4 className="font-semibold">LangGraph</h4>
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">Framework for stateful, multi-actor AI workflows</p>
                <ul className="text-xs text-gray-500 space-y-1">
                  <li>• 6-agent analysis orchestration</li>
                  <li>• Stateful workflow pipeline</li>
                  <li>• Structure → Security → Quality → Patterns → Migration → Summary</li>
                </ul>
              </div>
              <div className="border rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Layers className="w-6 h-6 text-yellow-600" />
                  <h4 className="font-semibold">Transformers (HuggingFace)</h4>
                  <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded">Planned</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">Pre-trained models for code understanding and embeddings</p>
                <ul className="text-xs text-gray-500 space-y-1">
                  <li>• CodeBERT for code embeddings</li>
                  <li>• Semantic code similarity</li>
                  <li>• Named entity recognition in code</li>
                </ul>
              </div>
              <div className="border-2 border-green-300 rounded-lg p-4 bg-green-50/50 dark:bg-green-900/10">
                <div className="flex items-center gap-2 mb-2">
                  <Network className="w-6 h-6 text-orange-600" />
                  <h4 className="font-semibold">NumPy Neural Networks</h4>
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">Custom neural networks for field matching and pattern recognition</p>
                <ul className="text-xs text-gray-500 space-y-1">
                  <li>• Multi-layer perceptron architecture</li>
                  <li>• Semantic similarity scoring</li>
                  <li>• Batch prediction optimization</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Vector Databases */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5 text-green-600" />
                Vector Databases
              </CardTitle>
              <CardDescription>Semantic search and embedding storage for intelligent code retrieval</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-3">
              <div className="border-2 border-green-300 rounded-lg p-4 bg-green-50/50 dark:bg-green-900/10">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold">ChromaDB</h4>
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300">Open-source embedding database for semantic code search</p>
              </div>
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold">Pinecone</h4>
                  <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded">Planned</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300">Cloud-native vector database for enterprise-scale search</p>
              </div>
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold">Weaviate</h4>
                  <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded">Planned</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300">AI-native database with built-in vectorization</p>
              </div>
            </CardContent>
          </Card>

          {/* AI Agents */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-indigo-600" />
                Intelligent AI Agents
              </CardTitle>
              <CardDescription>Specialized agents for different analysis and intelligence tasks</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <div className="border-2 border-green-300 rounded-lg p-4 bg-green-50/50 dark:bg-green-900/10">
                <div className="flex items-center gap-2 mb-2">
                  <Code2 className="w-5 h-5 text-blue-600" />
                  <h4 className="font-semibold">Code Lens Agent</h4>
                </div>
                <div className="flex gap-1">
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                  <span className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded">Python</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">Deep code analysis with AST parsing and pattern recognition</p>
              </div>
              <div className="border-2 border-green-300 rounded-lg p-4 bg-green-50/50 dark:bg-green-900/10">
                <div className="flex items-center gap-2 mb-2">
                  <Search className="w-5 h-5 text-purple-600" />
                  <h4 className="font-semibold">ZenVector Agent</h4>
                </div>
                <div className="flex gap-1">
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                  <span className="text-xs bg-purple-100 text-purple-800 px-2 py-0.5 rounded">TypeScript + Python</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">ChromaDB-powered semantic search and code similarity</p>
              </div>
              <div className="border rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <MessageSquare className="w-5 h-5 text-green-600" />
                  <h4 className="font-semibold">Knowledge Agent</h4>
                </div>
                <div className="flex gap-1">
                  <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded">Planned</span>
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded">TypeScript + Python</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">Document Q&A with Confluence integration</p>
              </div>
              <div className="border-2 border-green-300 rounded-lg p-4 bg-green-50/50 dark:bg-green-900/10">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-5 h-5 text-orange-600" />
                  <h4 className="font-semibold">Migration Planner</h4>
                </div>
                <div className="flex gap-1">
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                  <span className="text-xs bg-orange-100 text-orange-800 px-2 py-0.5 rounded">TypeScript</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">AI-powered POD→POA migration strategy</p>
              </div>
              <div className="border-2 border-green-300 rounded-lg p-4 bg-green-50/50 dark:bg-green-900/10">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-5 h-5 text-red-600" />
                  <h4 className="font-semibold">Demographic ML Agent</h4>
                </div>
                <div className="flex gap-1">
                  <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span>
                  <span className="text-xs bg-red-100 text-red-800 px-2 py-0.5 rounded">Python</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">Neural network-based PII/PHI field detection</p>
              </div>
            </CardContent>
          </Card>

          {/* Python Services */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Server className="w-5 h-5 text-orange-600" />
                Python AI Services
              </CardTitle>
              <CardDescription>Backend Python services powering AI analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-3 font-semibold">File</th>
                      <th className="text-left py-2 px-3 font-semibold">Purpose</th>
                      <th className="text-left py-2 px-3 font-semibold">Technologies</th>
                      <th className="text-left py-2 px-3 font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="text-gray-600 dark:text-gray-300">
                    <tr className="border-b bg-green-50/50 dark:bg-green-900/10"><td className="py-2 px-3 font-mono text-xs text-blue-600">codeLensAgent.py</td><td className="py-2 px-3">Core code analysis with AST parsing</td><td className="py-2 px-3">Python AST, Regex</td><td className="py-2 px-3"><span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span></td></tr>
                    <tr className="border-b bg-green-50/50 dark:bg-green-900/10"><td className="py-2 px-3 font-mono text-xs text-blue-600">zenVectorService.py</td><td className="py-2 px-3">Vector embeddings for semantic search</td><td className="py-2 px-3">ChromaDB</td><td className="py-2 px-3"><span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span></td></tr>
                    <tr className="border-b bg-green-50/50 dark:bg-green-900/10"><td className="py-2 px-3 font-mono text-xs text-blue-600">langchainService.py</td><td className="py-2 px-3">RAG chains for code Q&A</td><td className="py-2 px-3">LangChain, OpenAI</td><td className="py-2 px-3"><span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span></td></tr>
                    <tr className="border-b bg-green-50/50 dark:bg-green-900/10"><td className="py-2 px-3 font-mono text-xs text-blue-600">langgraphOrchestrator.py</td><td className="py-2 px-3">Multi-agent workflow orchestration</td><td className="py-2 px-3">LangGraph, LangChain</td><td className="py-2 px-3"><span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span></td></tr>
                    <tr className="border-b"><td className="py-2 px-3 font-mono text-xs text-blue-600">knowledgeAgent.py</td><td className="py-2 px-3">Document processing with LangChain</td><td className="py-2 px-3">LangChain, PyPDF</td><td className="py-2 px-3"><span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded">Planned</span></td></tr>
                    <tr className="border-b bg-green-50/50 dark:bg-green-900/10"><td className="py-2 px-3 font-mono text-xs text-blue-600">field_matcher_ml.py</td><td className="py-2 px-3">Neural network for field matching</td><td className="py-2 px-3">NumPy, Custom NN</td><td className="py-2 px-3"><span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span></td></tr>
                    <tr className="border-b bg-green-50/50 dark:bg-green-900/10"><td className="py-2 px-3 font-mono text-xs text-blue-600">tensorflow_field_model.py</td><td className="py-2 px-3">TensorFlow-style offline classification</td><td className="py-2 px-3">NumPy, Sigmoid/Softmax</td><td className="py-2 px-3"><span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span></td></tr>
                    <tr className="border-b bg-green-50/50 dark:bg-green-900/10"><td className="py-2 px-3 font-mono text-xs text-blue-600">excel_field_scanner.py</td><td className="py-2 px-3">Excel parsing for field mapping</td><td className="py-2 px-3">openpyxl</td><td className="py-2 px-3"><span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded font-medium">ACTIVE</span></td></tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* 14 Generative AI Functions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-cyan-600" />
                14 Generative AI Functions
              </CardTitle>
              <CardDescription>AI-powered capabilities for comprehensive code intelligence</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-3">
                {[
                  { name: "Code Explanation", desc: "Natural language explanation of code" },
                  { name: "Architecture Insights", desc: "Pattern analysis and recommendations" },
                  { name: "Security Analysis", desc: "CWE vulnerability detection" },
                  { name: "Migration Roadmap", desc: "Phased migration planning" },
                  { name: "Documentation Gen", desc: "Automated technical docs" },
                  { name: "Quality Scoring", desc: "ISO-5055 metrics" },
                  { name: "Pattern Detection", desc: "Design pattern identification" },
                  { name: "Dependency Analysis", desc: "Relationship mapping" },
                  { name: "Compliance Scanning", desc: "GDPR/HIPAA/PCI-DSS" },
                  { name: "Code Refactoring", desc: "AI-suggested improvements" },
                  { name: "Test Generation", desc: "Unit test suggestions" },
                  { name: "API Documentation", desc: "Swagger/OpenAPI generation" },
                  { name: "Data Lineage", desc: "Field-to-function tracking" },
                  { name: "Risk Assessment", desc: "Migration and security scoring" }
                ].map((func, i) => (
                  <div key={i} className="border rounded-lg p-3 hover:shadow-sm transition-shadow hover:border-cyan-300">
                    <div className="flex items-center gap-2 mb-1">
                      <Sparkles className="w-3 h-3 text-cyan-500" />
                      <h5 className="font-medium text-xs text-gray-900 dark:text-white">{func.name}</h5>
                    </div>
                    <p className="text-xs text-gray-500">{func.desc}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* MCP Orchestration */}
          <Card className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-purple-600" />
                MCP Agentic Orchestration (Planned)
              </CardTitle>
              <CardDescription>Model Context Protocol for multi-agent coordination</CardDescription>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-2">Core Capabilities</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1">
                  <li>• Multi-agent coordination with shared context</li>
                  <li>• Context sharing protocol between agents</li>
                  <li>• Workflow automation with conditional routing</li>
                  <li>• Smart task routing based on agent capabilities</li>
                  <li>• Tool chaining for complex analysis pipelines</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Integration Points</h4>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">Code Lens Agent</span>
                  <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">ZenVector Agent</span>
                  <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">Knowledge Agent</span>
                  <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">Migration Planner</span>
                  <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">Demographic Scanner</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Program Flow Tab */}
        <TabsContent value="flow" className="space-y-6">
          {/* Upload Phase */}
          <Card data-testid="card-upload-phase">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-blue-600" />
                Phase 1: Project Upload & Extraction
              </CardTitle>
              <CardDescription>Initial project ingestion and validation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-blue-100 p-2">
                  <ArrowRight className="w-4 h-4 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Upload Sources</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Users upload ZIP files (up to 50MB) or provide GitHub repository URLs. The system validates file formats and supports Java, Python, PySpark, Mainframe, C#, and Kotlin projects with automatic language detection.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-blue-100 p-2">
                  <ArrowRight className="w-4 h-4 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">File Extraction</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    ZIP files are extracted to temporary directories. Source files are identified by language-specific patterns (.java, .py, .scala, .cbl, .jcl). Files are stored in database before cleanup.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-blue-100 p-2">
                  <ArrowRight className="w-4 h-4 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Language Detection</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    System automatically detects project type based on file extensions and routes to appropriate analyzer: Java (.java), Python (.py), PySpark (.scala), Mainframe (.cbl, .jcl), C# (.cs), or Kotlin (.kt).
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Analysis Phase */}
          <Card data-testid="card-analysis-phase">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5 text-green-600" />
                Phase 2: Code Analysis & Parsing
              </CardTitle>
              <CardDescription>Deep source code analysis and pattern extraction</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-green-100 p-2">
                  <ArrowRight className="w-4 h-4 text-green-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Language-Specific Parsing</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Each analyzer extracts classes, methods, imports, annotations, and dependencies. Java analyzer identifies Spring Boot components, JPA entities, REST controllers. Python analyzer detects Django/Flask patterns.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-green-100 p-2">
                  <ArrowRight className="w-4 h-4 text-green-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Dependency Graph Building</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    System maps relationships between classes, services, repositories, and controllers. Creates architectural hierarchy with layers (controller → service → repository → entity).
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-green-100 p-2">
                  <ArrowRight className="w-4 h-4 text-green-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Metadata Extraction</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Extracts HTTP methods, API endpoints, database operations, and business logic flows. Results stored in PostgreSQL as JSON for quick retrieval.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* AI Analysis Phase */}
          <Card data-testid="card-ai-phase">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-purple-600" />
                Phase 3: AI-Powered Analysis
              </CardTitle>
              <CardDescription>Intelligent insights and recommendations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-purple-100 p-2">
                  <ArrowRight className="w-4 h-4 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">LLM Selection</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Users choose between cloud AI (OpenAI GPT-4o) or local models (Ollama with Code Llama, Deepseek, StarCoder, Llama 3, Mistral) for privacy-sensitive projects.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-purple-100 p-2">
                  <ArrowRight className="w-4 h-4 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Pattern Recognition</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    AI identifies architectural patterns (MVC, microservices, layered), design patterns (singleton, factory, repository), code smells, and technical debt areas.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-purple-100 p-2">
                  <ArrowRight className="w-4 h-4 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Code Lens - Demographic Scanning</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Two scanning modes: (1) Regex Scan - 39 pre-defined patterns across 5 categories (Names, Personal Info, Addresses, Phones, Emails), and (2) Excel Field Mapping - upload Excel with table_name + field_name columns for exact matching. Optional Code Lens ML provides suggestions for unmatched fields using Lookup Table (95%), Acronym Detection (90%), and Levenshtein similarity (60-95%).
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-purple-100 p-2">
                  <ArrowRight className="w-4 h-4 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Quality Assessment</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    AI-powered code quality analysis with HuggingFace CodeBERT for code assessment, security scanning, and technical debt identification.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Visualization Phase */}
          <Card data-testid="card-visualization-phase">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart className="w-5 h-5 text-orange-600" />
                Phase 4: Visualization & Export
              </CardTitle>
              <CardDescription>Interactive diagrams and professional reports</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-orange-100 p-2">
                  <ArrowRight className="w-4 h-4 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Diagram Generation</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Creates Flow Diagrams (Mermaid.js), Component Diagrams (AntV X6 with zoom controls), Sequence Diagrams (project-specific flows), and UML Class Diagrams (entity relationships).
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-orange-100 p-2">
                  <ArrowRight className="w-4 h-4 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">C360 Process Visualization</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Visual representation of integration processes, data flows, and system interactions with corporate branding.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-orange-100 p-2">
                  <ArrowRight className="w-4 h-4 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Export Options</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    PDF reports with professional formatting (jsPDF + autotable), Word documents (docx), HTML previews (HTML2Canvas), and downloadable diagram images.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-orange-100 p-2">
                  <ArrowRight className="w-4 h-4 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">AI Insights Display</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Formatted markdown output with component analysis, architectural patterns, detected issues, and actionable recommendations for improvement.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Advanced Features */}
          <Card data-testid="card-advanced-features">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-cyan-600" />
                Advanced Features & Agents
              </CardTitle>
              <CardDescription>Specialized AI agents and enterprise capabilities</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-cyan-100 p-2">
                  <ArrowRight className="w-4 h-4 text-cyan-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Knowledge Agent</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Document intelligence with Confluence scraping, IBM Doclinq PDF processing, intelligent Q&A interface, and persistent knowledge base using LangChain for document processing and LangGraph for workflow orchestration.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-cyan-100 p-2">
                  <ArrowRight className="w-4 h-4 text-cyan-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Code Conversion Agent</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Multi-language code transformation agent supporting conversion between Java, Python, PySpark, Mainframe, C#, and Kotlin. Uses AST-based syntax conversion and framework migration support while preserving code quality.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-cyan-100 p-2">
                  <ArrowRight className="w-4 h-4 text-cyan-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Validator & Responsible AI Agent</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Comprehensive validation covering security vulnerability detection, privacy compliance (GDPR, CCPA), AI ethics and bias detection, fairness assessment, code quality metrics, and responsible AI deployment validation.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-cyan-100 p-2">
                  <ArrowRight className="w-4 h-4 text-cyan-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Real-time Processing & Backend Visibility</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Interactive processing modals show backend operations step-by-step. Excel scanning displays: file upload → validation → parsing → codebase matching → report generation. ML suggestions show: engine initialization → dataset loading → lookup table → acronym detection → Levenshtein analysis → token similarity → report compilation.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
