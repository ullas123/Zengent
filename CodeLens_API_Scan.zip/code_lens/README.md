# Code Lens - API Scan

Scan Java & C# applications to discover REST, SOAP, and OneData API endpoints.

## Prerequisites

- **Python 3.9+** — [Download here](https://www.python.org/downloads/)
- **Graphviz** (system install) — Required for generating diagrams
  - **Windows:** Download from https://graphviz.org/download/ and add to PATH
  - **macOS:** `brew install graphviz`
  - **Linux (Ubuntu/Debian):** `sudo apt install graphviz`
  - **Linux (Fedora/RHEL):** `sudo dnf install graphviz`
- **Git** (optional) — Only needed if you want to scan repos via Git URL

## Installation

1. Unzip this folder to a location on your computer.

2. Open a terminal/command prompt and navigate to the folder:
   ```
   cd code_lens
   ```

3. (Recommended) Create a virtual environment:
   ```
   python -m venv venv
   ```
   Activate it:
   - **Windows:** `venv\Scripts\activate`
   - **macOS/Linux:** `source venv/bin/activate`

4. Install Python dependencies:
   ```
   pip install -r requirements.txt
   ```

## Running the Application

```
streamlit run app.py
```

The app will open in your browser at **http://localhost:8501**.

## How to Use

1. **Upload an Excel file** with columns `url_details` and `path_details` listing your known API URLs and file paths.

2. **Provide source code** — either upload a ZIP archive or paste a Git repository URL (GitHub, GitLab, Bitbucket, Azure DevOps).

3. Click **Scan Application** to discover all REST, SOAP, and OneData API endpoints.

4. Browse results across tabs:
   - **API Endpoints** — Full list with filters and search
   - **Excel Matches** — Which APIs matched your Excel entries
   - **Flow Diagrams** — Visual diagrams of API flows and dependencies
   - **Detailed View** — Per-file deep dive with code context
   - **Export** — Download results as CSV

## Supported Detection

| Type | Java | C# |
|------|------|----|
| REST APIs | Spring MVC, JAX-RS | ASP.NET Core, Web API |
| SOAP Services | JAX-WS, WSDL | WCF, ASMX |
| OneData | Function calls, annotations | Service/client calls |
| URL References | RestTemplate, HttpClient | HttpClient, WebClient |
