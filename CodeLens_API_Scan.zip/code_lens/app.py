import streamlit as st
import pandas as pd
import os
import re
import shutil
import tempfile
from scanner import (
    extract_source_files,
    clone_git_repo,
    scan_source_code,
    deduplicate_endpoints,
    detect_language,
    scan_for_outbound_sor_calls,
    scan_for_sql_table_usage,
    detect_integration_type,
    SOR_TABLES,
    SOR_SYSTEMS,
    SOR_APPROVED_TABLES,
)
from diagram import (
    create_api_flow_diagram,
    create_file_dependency_diagram,
    create_api_summary_diagram,
)
from report import (
    generate_html_report,
    generate_excel_report,
    generate_multi_repo_html_report,
    generate_sor_audit_report,
)


st.set_page_config(
    page_title="Code Lens - API Scan",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .main-header {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        padding: 2rem;
        border-radius: 12px;
        margin-bottom: 1.5rem;
        text-align: center;
    }
    .main-header h1 {
        color: #e94560;
        font-size: 2.2rem;
        margin-bottom: 0.3rem;
    }
    .main-header p {
        color: #a8b2d1;
        font-size: 1rem;
    }
    .stat-card {
        background: #ffffff;
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        padding: 1.2rem;
        text-align: center;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .stat-card h3 {
        color: #1a1a2e;
        font-size: 2rem;
        margin: 0;
    }
    .stat-card p {
        color: #6c757d;
        margin: 0;
        font-size: 0.85rem;
    }
    .api-rest { border-left: 4px solid #28a745; }
    .api-soap { border-left: 4px solid #17a2b8; }
    .api-onedata { border-left: 4px solid #ffc107; }
    .section-header {
        background: #f8f9fa;
        padding: 0.8rem 1.2rem;
        border-radius: 8px;
        border-left: 4px solid #e94560;
        margin: 1rem 0;
    }
    .source-badge {
        display: inline-block;
        background: #e8e8e8;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.8rem;
        font-weight: 600;
        margin-right: 6px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="main-header">
        <h1>Code Lens - API Scan</h1>
        <p>Scan Java & C# applications to discover REST, SOAP, and OneData API endpoints</p>
    </div>
    """,
    unsafe_allow_html=True,
)

if "multi_scan_results" not in st.session_state:
    st.session_state.multi_scan_results = None
if "sor_audit_data" not in st.session_state:
    st.session_state.sor_audit_data = None  # {"sor_calls": [...], "table_usages": [...], "integration_type": str}

with st.sidebar:
    st.markdown("### Upload Files")

    st.markdown("**1. Excel File** *(optional)* — provide `url_details` / `path_details` columns to match APIs against a known list")
    excel_file = st.file_uploader(
        "Upload Excel file",
        type=["xlsx", "xls"],
        help="Optional. Excel file with columns: url_details, path_details. Skip to scan all APIs without matching.",
        label_visibility="collapsed",
    )

    st.markdown("---")
    st.markdown("**2. Source Code**")
    source_option = st.radio(
        "Choose source input method",
        ["Upload ZIP files", "Git Repository URL"],
        horizontal=True,
        label_visibility="collapsed",
    )

    source_files = None
    git_url = ""
    git_branch = ""

    if source_option == "Upload ZIP files":
        source_files = st.file_uploader(
            "Upload source code ZIP(s)",
            type=["zip"],
            accept_multiple_files=True,
            help="Upload one or more ZIP files containing your Java or C# project source code",
            label_visibility="collapsed",
        )
    else:
        git_url = st.text_input(
            "Git Repository URL",
            placeholder="https://github.com/user/repo.git",
            help="Public repo URL, or use https://<token>@github.com/user/repo.git for private repos",
        )
        git_branch = st.text_input(
            "Branch (optional)",
            placeholder="main",
            help="Leave empty for default branch",
        )

    has_source = (source_option == "Upload ZIP files" and source_files and len(source_files) > 0) or (
        source_option == "Git Repository URL" and git_url.strip()
    )

    st.markdown("---")

    scan_button = st.button(
        "Scan Application",
        type="primary",
        use_container_width=True,
        disabled=not has_source,
    )

    if scan_button and has_source:
        with st.spinner("Scanning source code..."):
            try:
                excel_urls = []
                excel_paths = []
                df = None

                if excel_file:
                    df = pd.read_excel(excel_file)

                    clean_cols = {}
                    for col in df.columns:
                        cleaned = re.sub(r'[^\x20-\x7E]', '', str(col)).strip()
                        if cleaned != str(col):
                            df = df.rename(columns={col: cleaned})
                        clean_cols[cleaned] = cleaned

                    if len(df.columns) == 1 and "," in str(df.columns[0]):
                        single_col = str(df.columns[0])
                        new_cols = [c.strip() for c in single_col.split(",")]
                        if len(new_cols) >= 2:
                            df = pd.read_excel(excel_file, header=None, skiprows=1)
                            if len(df.columns) >= len(new_cols):
                                df.columns = new_cols + [f"col_{i}" for i in range(len(new_cols), len(df.columns))]

                    col_mapping = {}
                    normalized_cols = {}
                    for col in df.columns:
                        col_lower = str(col).strip().lower().replace(" ", "_").replace("-", "_")
                        normalized_cols[col_lower] = col

                    url_priorities = ["url_details", "urldetails", "url_detail", "urldetail"]
                    path_priorities = ["path_details", "pathdetails", "path_detail", "pathdetail"]

                    for key in url_priorities:
                        if key in normalized_cols:
                            col_mapping["url_details"] = normalized_cols[key]
                            break
                    if "url_details" not in col_mapping:
                        for col_lower, col_orig in normalized_cols.items():
                            if "url" in col_lower:
                                col_mapping["url_details"] = col_orig
                                break

                    for key in path_priorities:
                        if key in normalized_cols:
                            col_mapping["path_details"] = normalized_cols[key]
                            break
                    if "path_details" not in col_mapping:
                        for col_lower, col_orig in normalized_cols.items():
                            if "path" in col_lower:
                                col_mapping["path_details"] = col_orig
                                break

                    if "url_details" in col_mapping:
                        excel_urls = df[col_mapping["url_details"]].dropna().astype(str).tolist()
                    if "path_details" in col_mapping:
                        excel_paths = df[col_mapping["path_details"]].dropna().astype(str).tolist()

                    if not excel_urls and not excel_paths:
                        st.warning(
                            "Excel file uploaded but no URL/path columns found. "
                            "Scanning without Excel matching. "
                            f"Columns found: {', '.join(str(c) for c in df.columns)}"
                        )
                    else:
                        matched_cols = []
                        if "url_details" in col_mapping:
                            matched_cols.append(f"URL: **{col_mapping['url_details']}** ({len(excel_urls)} entries)")
                        if "path_details" in col_mapping:
                            matched_cols.append(f"Path: **{col_mapping['path_details']}** ({len(excel_paths)} entries)")
                        st.info(f"Excel columns detected: {' | '.join(matched_cols)}")
                else:
                    st.info("No Excel file uploaded — scanning all APIs without matching. SOR table detection is still active.")

                sources_to_scan = []

                if source_option == "Upload ZIP files":
                    for sf in source_files:
                        source_dir, error = extract_source_files(sf)
                        if error:
                            st.error(f"Error with {sf.name}: {error}")
                        else:
                            sources_to_scan.append((sf.name, source_dir))
                else:
                    with st.spinner("Cloning Git repository..."):
                        source_dir, error = clone_git_repo(
                            git_url.strip(),
                            branch=git_branch.strip() if git_branch.strip() else None,
                        )
                    if error:
                        st.error(error)
                    else:
                        sources_to_scan.append((git_url.strip(), source_dir))

                if sources_to_scan:
                    all_results = []
                    total_endpoints = 0
                    total_scanned = 0
                    total_total = 0

                    all_sor_calls = []
                    all_table_usages = []

                    for source_name, source_dir in sources_to_scan:
                        try:
                            endpoints, language, scanned, total = scan_source_code(
                                source_dir, excel_urls, excel_paths
                            )
                            endpoints = deduplicate_endpoints(endpoints)
                            all_results.append({
                                "source_name": source_name,
                                "endpoints": endpoints,
                                "language": language,
                                "scanned_files": scanned,
                                "total_files": total,
                            })
                            total_endpoints += len(endpoints)
                            total_scanned += scanned
                            total_total += total

                            # SOR Audit scans (run while source_dir still exists)
                            try:
                                sor_calls = scan_for_outbound_sor_calls(source_dir, language)
                                for c in sor_calls:
                                    c.source_name = source_name
                                all_sor_calls.extend(sor_calls)

                                table_usages = scan_for_sql_table_usage(source_dir, language)
                                for t in table_usages:
                                    t.source_name = source_name
                                all_table_usages.extend(table_usages)
                            except Exception as audit_err:
                                st.warning(f"SOR audit scan partial error for {source_name}: {audit_err}")

                        except Exception as e:
                            st.error(f"Error scanning {source_name}: {str(e)}")
                        finally:
                            if source_dir and os.path.exists(source_dir):
                                shutil.rmtree(os.path.dirname(source_dir), ignore_errors=True)

                    if all_results:
                        st.session_state.multi_scan_results = all_results
                        st.session_state.excel_urls = excel_urls
                        st.session_state.excel_paths = excel_paths
                        st.session_state.excel_df = df
                        # Store SOR audit data
                        int_type = detect_integration_type(all_sor_calls, all_table_usages)
                        st.session_state.sor_audit_data = {
                            "sor_calls": all_sor_calls,
                            "table_usages": all_table_usages,
                            "integration_type": int_type,
                        }

                        if len(all_results) == 1:
                            st.success(
                                f"Scan complete! Found {total_endpoints} API endpoints "
                                f"in {total_scanned} files."
                            )
                        else:
                            st.success(
                                f"Scan complete! Scanned {len(all_results)} sources. "
                                f"Found {total_endpoints} total API endpoints "
                                f"in {total_scanned} files."
                            )

            except Exception as e:
                st.error(f"Error during scan: {str(e)}")

    st.markdown("---")
    st.markdown("### About")
    st.markdown(
        """
        **Code Lens** scans your Java or C# source
        code and identifies:
        - REST API endpoints
        - SOAP Web Services
        - OneData function calls

        Upload an Excel file to match APIs against
        a known list, or scan without one to discover
        all APIs. SOR table detection is always active.
        """
    )

    st.markdown("---")
    st.markdown("### SOR Tables Monitored")
    sor_pills = " ".join(
        f'<span style="display:inline-block;background:#ede7f6;color:#4a235a;'
        f'padding:3px 10px;border-radius:12px;font-size:0.78rem;font-weight:600;'
        f'margin:2px;">{t}</span>'
        for t in SOR_TABLES
    )
    st.markdown(sor_pills, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### Download for Local Use")
    local_zip_path = os.path.join(os.path.dirname(__file__), "CodeLens_API_Scan.zip")
    if os.path.exists(local_zip_path):
        with open(local_zip_path, "rb") as zf:
            st.download_button(
                label="Download Local Installer",
                data=zf.read(),
                file_name="CodeLens_API_Scan.zip",
                mime="application/zip",
                use_container_width=True,
            )

if st.session_state.multi_scan_results is not None:
    all_results = st.session_state.multi_scan_results
    is_multi = len(all_results) > 1

    all_endpoints = []
    for r in all_results:
        for ep in r["endpoints"]:
            ep.source_name = r["source_name"]
        all_endpoints.extend(r["endpoints"])

    languages = list(set(r["language"] for r in all_results if r["language"]))
    language_display = ", ".join(languages) if languages else "Unknown"
    total_scanned = sum(r["scanned_files"] for r in all_results)
    total_total = sum(r["total_files"] for r in all_results)

    rest_count = sum(1 for e in all_endpoints if e.api_type == "REST")
    soap_count = sum(1 for e in all_endpoints if e.api_type == "SOAP")
    onedata_count = sum(1 for e in all_endpoints if e.api_type == "OneData")
    matched_count = sum(1 for e in all_endpoints if e.matched_excel_url or e.matched_excel_path)

    stat_cols = st.columns(7 if is_multi else 6)
    with stat_cols[0]:
        st.markdown(
            f'<div class="stat-card"><h3>{len(all_endpoints)}</h3><p>Total APIs</p></div>',
            unsafe_allow_html=True,
        )
    with stat_cols[1]:
        st.markdown(
            f'<div class="stat-card api-rest"><h3>{rest_count}</h3><p>REST APIs</p></div>',
            unsafe_allow_html=True,
        )
    with stat_cols[2]:
        st.markdown(
            f'<div class="stat-card api-soap"><h3>{soap_count}</h3><p>SOAP APIs</p></div>',
            unsafe_allow_html=True,
        )
    with stat_cols[3]:
        st.markdown(
            f'<div class="stat-card api-onedata"><h3>{onedata_count}</h3><p>OneData</p></div>',
            unsafe_allow_html=True,
        )
    with stat_cols[4]:
        st.markdown(
            f'<div class="stat-card"><h3>{matched_count}</h3><p>Excel Matched</p></div>',
            unsafe_allow_html=True,
        )
    with stat_cols[5]:
        st.markdown(
            f'<div class="stat-card"><h3>{language_display}</h3><p>Language</p></div>',
            unsafe_allow_html=True,
        )
    if is_multi:
        with stat_cols[6]:
            st.markdown(
                f'<div class="stat-card"><h3>{len(all_results)}</h3><p>Sources</p></div>',
                unsafe_allow_html=True,
            )

    st.markdown("")

    tab_names = [
        "API Endpoints",
        "Excel Matches",
        "Unmatched APIs",
        "Flow Diagrams",
        "Detailed View",
        "Request & Response",
        "SOR Tables",
        "SOR Audit",
        "Analysis",
        "Export",
    ]
    tab1, tab2, tab2b, tab3, tab4, tab5, tab_sor, tab_audit, tab7, tab6 = st.tabs(tab_names)

    with tab1:
        st.markdown(
            '<div class="section-header"><strong>Discovered API Endpoints</strong></div>',
            unsafe_allow_html=True,
        )

        filter_col1, filter_col2, filter_col3 = st.columns(3)
        with filter_col1:
            type_filter = st.multiselect(
                "Filter by API Type",
                ["REST", "SOAP", "OneData"],
                default=["REST", "SOAP", "OneData"],
            )
        with filter_col2:
            all_functions = sorted(set(e.function_name for e in all_endpoints))
            func_filter = st.multiselect(
                "Filter by Function",
                all_functions,
                default=[],
                placeholder="All Functions",
                key="ep_func_filter",
            )
        with filter_col3:
            search_query = st.text_input("Search endpoints", placeholder="Search by URL, file, or function...")

        all_source_names = sorted(set(e.source_name for e in all_endpoints if e.source_name))
        if len(all_source_names) > 1:
            source_filter = st.multiselect(
                "Filter by Repo / Source",
                all_source_names,
                default=[],
                placeholder="All Repos",
                key="ep_source_filter",
            )
        else:
            source_filter = []

        display_endpoints = all_endpoints
        if source_filter:
            display_endpoints = [e for e in display_endpoints if e.source_name in source_filter]

        filtered = [e for e in display_endpoints if e.api_type in type_filter]
        if func_filter:
            filtered = [e for e in filtered if e.function_name in func_filter]
        if search_query:
            q = search_query.lower()
            filtered = [
                e
                for e in filtered
                if q in e.url.lower()
                or q in e.file_path.lower()
                or q in e.function_name.lower()
            ]

        f_total = len(filtered)
        f_rest = sum(1 for e in filtered if e.api_type == "REST")
        f_soap = sum(1 for e in filtered if e.api_type == "SOAP")
        f_od = sum(1 for e in filtered if e.api_type == "OneData")
        f_matched = sum(1 for e in filtered if e.matched_excel_url or e.matched_excel_path)
        f_unmatched = f_total - f_matched
        f_sources = len(set(e.source_name for e in filtered if e.source_name))

        is_filtered = bool(func_filter or source_filter or search_query or set(type_filter) != {"REST", "SOAP", "OneData"})
        filter_label = " (Filtered)" if is_filtered else ""

        fc1, fc2, fc3, fc4, fc5, fc6 = st.columns(6)
        with fc1:
            st.markdown(
                f'<div class="stat-card"><h3>{f_total}</h3><p>Total{filter_label}</p></div>',
                unsafe_allow_html=True,
            )
        with fc2:
            st.markdown(
                f'<div class="stat-card api-rest"><h3>{f_rest}</h3><p>REST</p></div>',
                unsafe_allow_html=True,
            )
        with fc3:
            st.markdown(
                f'<div class="stat-card api-soap"><h3>{f_soap}</h3><p>SOAP</p></div>',
                unsafe_allow_html=True,
            )
        with fc4:
            st.markdown(
                f'<div class="stat-card api-onedata"><h3>{f_od}</h3><p>OneData</p></div>',
                unsafe_allow_html=True,
            )
        with fc5:
            st.markdown(
                f'<div class="stat-card"><h3>{f_matched}</h3><p>Matched</p></div>',
                unsafe_allow_html=True,
            )
        with fc6:
            st.markdown(
                f'<div class="stat-card"><h3>{f_unmatched}</h3><p>Unmatched</p></div>',
                unsafe_allow_html=True,
            )

        if filtered:
            table_data = []
            for ep in filtered:
                row = {
                    "Repo / Source": ep.source_name,
                    "API Type": ep.api_type,
                    "HTTP Method": ep.http_method,
                    "Operation": ep.operation,
                    "URL / Endpoint": ep.url,
                    "Function": ep.function_name,
                    "File": ep.file_path,
                    "Line": ep.line_number,
                    "Request": ep.request_details,
                    "Response": ep.response_details,
                }
                table_data.append(row)
            df_table = pd.DataFrame(table_data)
            st.dataframe(df_table, use_container_width=True, hide_index=True)
        else:
            st.info("No endpoints found matching the current filters.")

    with tab2:
        st.markdown(
            '<div class="section-header"><strong>Excel URL & Path Matches</strong></div>',
            unsafe_allow_html=True,
        )

        excel_filter_col1, excel_filter_col2 = st.columns(2)
        with excel_filter_col1:
            excel_func_options = sorted(set(e.function_name for e in all_endpoints))
            excel_func_filter = st.multiselect(
                "Filter by Function",
                excel_func_options,
                default=[],
                placeholder="All Functions",
                key="excel_func_filter",
            )
        with excel_filter_col2:
            excel_search = st.text_input(
                "Search",
                placeholder="Search by URL, function, or file...",
                key="excel_search",
            )

        excel_source_names = sorted(set(e.source_name for e in all_endpoints if e.source_name))
        if len(excel_source_names) > 1:
            excel_source_filter = st.multiselect(
                "Filter by Repo / Source",
                excel_source_names,
                default=[],
                placeholder="All Repos",
                key="excel_source_filter",
            )
        else:
            excel_source_filter = []

        excel_display_eps = all_endpoints
        if excel_source_filter:
            excel_display_eps = [e for e in excel_display_eps if e.source_name in excel_source_filter]
        if excel_func_filter:
            excel_display_eps = [e for e in excel_display_eps if e.function_name in excel_func_filter]
        if excel_search:
            q = excel_search.lower()
            excel_display_eps = [e for e in excel_display_eps if q in e.url.lower() or q in e.file_path.lower() or q in e.function_name.lower()]

        matched_eps = [e for e in excel_display_eps if e.matched_excel_url or e.matched_excel_path]
        unmatched_eps = [e for e in excel_display_eps if not e.matched_excel_url and not e.matched_excel_path]

        if matched_eps:
            st.markdown(f"**Matched APIs ({len(matched_eps)})**")
            match_data = []
            for ep in matched_eps:
                match_data.append(
                    {
                        "Repo / Source": ep.source_name,
                        "API Type": ep.api_type,
                        "Endpoint URL": ep.url,
                        "Function": ep.function_name,
                        "File": ep.file_path,
                        "Line": ep.line_number,
                        "Matched Excel URL": ep.matched_excel_url,
                        "Matched Excel Path": ep.matched_excel_path,
                    }
                )
            st.dataframe(pd.DataFrame(match_data), use_container_width=True, hide_index=True)
        else:
            st.warning("No direct matches found between Excel entries and source code endpoints.")

        if unmatched_eps:
            with st.expander(f"Unmatched APIs ({len(unmatched_eps)})"):
                unmatch_data = []
                for ep in unmatched_eps:
                    unmatch_data.append(
                        {
                            "Repo / Source": ep.source_name,
                            "API Type": ep.api_type,
                            "Endpoint URL": ep.url,
                            "Function": ep.function_name,
                            "File": ep.file_path,
                            "Line": ep.line_number,
                        }
                    )
                st.dataframe(
                    pd.DataFrame(unmatch_data), use_container_width=True, hide_index=True
                )

        if hasattr(st.session_state, "excel_urls") and st.session_state.excel_urls:
            matched_urls = set(e.matched_excel_url for e in all_endpoints if e.matched_excel_url)
            unmatched_excel = [u for u in st.session_state.excel_urls if u not in matched_urls]
            if unmatched_excel:
                with st.expander(f"Excel URLs not found in source code ({len(unmatched_excel)})"):
                    for url in unmatched_excel:
                        st.text(f"  - {url}")

    with tab2b:
        st.markdown(
            '<div class="section-header"><strong>APIs Found in Source Code but Not in Excel</strong></div>',
            unsafe_allow_html=True,
        )

        unmatched_source_eps = [
            e for e in all_endpoints
            if not e.matched_excel_url and not e.matched_excel_path
        ]

        if unmatched_source_eps:
            um_rest = sum(1 for e in unmatched_source_eps if e.api_type == "REST")
            um_soap = sum(1 for e in unmatched_source_eps if e.api_type == "SOAP")
            um_od = sum(1 for e in unmatched_source_eps if e.api_type == "OneData")

            um_stat1, um_stat2, um_stat3, um_stat4 = st.columns(4)
            with um_stat1:
                st.markdown(
                    f'<div class="stat-card"><h3>{len(unmatched_source_eps)}</h3><p>Total Unmatched</p></div>',
                    unsafe_allow_html=True,
                )
            with um_stat2:
                st.markdown(
                    f'<div class="stat-card api-rest"><h3>{um_rest}</h3><p>REST</p></div>',
                    unsafe_allow_html=True,
                )
            with um_stat3:
                st.markdown(
                    f'<div class="stat-card api-soap"><h3>{um_soap}</h3><p>SOAP</p></div>',
                    unsafe_allow_html=True,
                )
            with um_stat4:
                st.markdown(
                    f'<div class="stat-card api-onedata"><h3>{um_od}</h3><p>OneData</p></div>',
                    unsafe_allow_html=True,
                )

            st.markdown("")

            um_filter_col1, um_filter_col2, um_filter_col3 = st.columns(3)
            with um_filter_col1:
                um_type_filter = st.multiselect(
                    "Filter by API Type",
                    ["REST", "SOAP", "OneData"],
                    default=["REST", "SOAP", "OneData"],
                    key="um_type_filter",
                )
            with um_filter_col2:
                um_all_functions = sorted(set(e.function_name for e in unmatched_source_eps))
                um_func_filter = st.multiselect(
                    "Filter by Function",
                    um_all_functions,
                    default=[],
                    placeholder="All Functions",
                    key="um_func_filter",
                )
            with um_filter_col3:
                um_search = st.text_input(
                    "Search",
                    placeholder="Search by URL, function, or file...",
                    key="um_search",
                )

            um_source_names = sorted(set(e.source_name for e in unmatched_source_eps if e.source_name))
            if len(um_source_names) > 1:
                um_source_filter = st.multiselect(
                    "Filter by Repo / Source",
                    um_source_names,
                    default=[],
                    placeholder="All Repos",
                    key="um_source_filter",
                )
            else:
                um_source_filter = []

            um_display = unmatched_source_eps
            if um_source_filter:
                um_display = [e for e in um_display if e.source_name in um_source_filter]

            um_filtered = [e for e in um_display if e.api_type in um_type_filter]
            if um_func_filter:
                um_filtered = [e for e in um_filtered if e.function_name in um_func_filter]
            if um_search:
                q = um_search.lower()
                um_filtered = [
                    e for e in um_filtered
                    if q in e.url.lower()
                    or q in e.file_path.lower()
                    or q in e.function_name.lower()
                ]

            if um_filtered:
                um_table = []
                for ep in um_filtered:
                    um_table.append({
                        "Repo / Source": ep.source_name,
                        "API Type": ep.api_type,
                        "HTTP Method": ep.http_method,
                        "Operation": ep.operation,
                        "URL / Endpoint": ep.url,
                        "Function": ep.function_name,
                        "File": os.path.basename(ep.file_path),
                        "Line": ep.line_number,
                        "Parameters": ep.parameters.replace("\n", "; ") if ep.parameters else "",
                        "Request": ep.request_details,
                        "Response": ep.response_details,
                    })
                st.dataframe(pd.DataFrame(um_table), use_container_width=True, hide_index=True)

                st.markdown("---")
                st.markdown("**Detailed View**")
                for i, ep in enumerate(um_filtered):
                    type_emoji = {"REST": "🌐", "SOAP": "📨", "OneData": "📊"}.get(ep.api_type, "🔗")
                    op_icon = {"CREATE": "🟢", "READ": "🔵", "UPDATE": "🟠", "DELETE": "🔴"}.get(ep.operation, "⚪")
                    with st.expander(
                        f"{type_emoji} [{ep.api_type}] {ep.http_method} {op_icon} {ep.operation} | {ep.url} — {ep.function_name}",
                        expanded=False,
                    ):
                        d1, d2 = st.columns(2)
                        with d1:
                            st.markdown(f"**URL:** `{ep.url}`")
                            st.markdown(f"**HTTP Method:** `{ep.http_method}`")
                            st.markdown(f"**Operation:** {op_icon} `{ep.operation}`")
                            st.markdown(f"**Function:** `{ep.function_name}`")
                        with d2:
                            st.markdown(f"**File:** `{os.path.basename(ep.file_path)}`")
                            st.markdown(f"**Full Path:** `{ep.file_path}`")
                            st.markdown(f"**Line:** `{ep.line_number}`")
                            st.markdown(f"**Request:** {ep.request_details}")
                            st.markdown(f"**Response:** {ep.response_details}")

                        if ep.payload_fields:
                            st.markdown("**Payload Object Details**")
                            st.code(ep.payload_fields, language=None)

                        if ep.code_snippet:
                            primary_lang = all_results[0]["language"] if all_results else "Java"
                            st.markdown("**Code Context**")
                            st.code(ep.code_snippet, language="java" if primary_lang == "Java" else "csharp")
            else:
                st.info("No unmatched endpoints match the current filters.")
        else:
            st.success("All APIs found in the source code have a match in your Excel file.")

    with tab3:
        st.markdown(
            '<div class="section-header"><strong>API Flow Diagrams</strong></div>',
            unsafe_allow_html=True,
        )

        if all_endpoints:
            diagram_source_names = sorted(set(e.source_name for e in all_endpoints if e.source_name))
            if len(diagram_source_names) > 1:
                diagram_source_filter = st.multiselect(
                    "Filter by Repo / Source",
                    diagram_source_names,
                    default=[],
                    placeholder="All Repos",
                    key="diagram_source",
                )
            else:
                diagram_source_filter = []

            if diagram_source_filter:
                diagram_eps = [e for e in all_endpoints if e.source_name in diagram_source_filter]
                filtered_langs = list(set(
                    r["language"] for r in all_results
                    if r["source_name"] in diagram_source_filter and r["language"]
                ))
                diagram_lang = ", ".join(filtered_langs) if filtered_langs else language_display
            else:
                diagram_eps = all_endpoints
                diagram_lang = language_display

            diagram_type = st.selectbox(
                "Select Diagram",
                ["API Flow Diagram", "File Dependencies", "API Summary"],
            )

            try:
                if diagram_type == "API Flow Diagram":
                    img_path = create_api_flow_diagram(diagram_eps, diagram_lang)
                elif diagram_type == "File Dependencies":
                    img_path = create_file_dependency_diagram(diagram_eps)
                else:
                    img_path = create_api_summary_diagram(diagram_eps)

                st.image(img_path, use_container_width=True)

                with open(img_path, "rb") as f:
                    st.download_button(
                        label=f"Download {diagram_type}",
                        data=f.read(),
                        file_name=f"{diagram_type.lower().replace(' ', '_')}.png",
                        mime="image/png",
                    )
            except Exception as e:
                st.error(f"Error generating diagram: {str(e)}")
        else:
            st.info("No endpoints found to generate diagrams.")

    with tab4:
        st.markdown(
            '<div class="section-header"><strong>Detailed API View</strong></div>',
            unsafe_allow_html=True,
        )

        if all_endpoints:
            detail_source_names = sorted(set(e.source_name for e in all_endpoints if e.source_name))
            if len(detail_source_names) > 1:
                detail_source_filter = st.multiselect(
                    "Filter by Repo / Source",
                    detail_source_names,
                    default=[],
                    placeholder="All Repos",
                    key="detail_source",
                )
            else:
                detail_source_filter = []

            detail_eps = all_endpoints
            if detail_source_filter:
                detail_eps = [e for e in detail_eps if e.source_name in detail_source_filter]

            detail_filter_col1, detail_filter_col2 = st.columns(2)
            with detail_filter_col1:
                detail_func_options = sorted(set(e.function_name for e in detail_eps))
                detail_func_filter = st.multiselect(
                    "Filter by Function",
                    detail_func_options,
                    default=[],
                    placeholder="All Functions",
                    key="detail_func_filter",
                )
            with detail_filter_col2:
                detail_search = st.text_input(
                    "Search",
                    placeholder="Search by URL, function, or file...",
                    key="detail_search",
                )

            if detail_func_filter:
                detail_eps = [e for e in detail_eps if e.function_name in detail_func_filter]
            if detail_search:
                q = detail_search.lower()
                detail_eps = [e for e in detail_eps if q in e.url.lower() or q in e.file_path.lower() or q in e.function_name.lower()]

            primary_lang = all_results[0]["language"] if all_results else "Java"

            files_with_apis = sorted(set(e.file_path for e in detail_eps))
            if files_with_apis:
                selected_file = st.selectbox("Select File", files_with_apis)
            else:
                selected_file = None

            file_eps = [e for e in detail_eps if e.file_path == selected_file] if selected_file else []
            for i, ep in enumerate(file_eps):
                type_emoji = {"REST": "🌐", "SOAP": "📨", "OneData": "📊"}.get(
                    ep.api_type, "🔗"
                )
                with st.expander(
                    f"{type_emoji} {ep.api_type} | {ep.http_method} | {ep.function_name} (Line {ep.line_number})",
                    expanded=i == 0,
                ):
                    detail_col1, detail_col2 = st.columns(2)
                    with detail_col1:
                        st.markdown("**Endpoint URL:**")
                        st.code(ep.url, language=None)
                        st.markdown(f"**API Type:** `{ep.api_type}`")
                        st.markdown(f"**HTTP Method:** `{ep.http_method}`")
                        st.markdown(f"**Function:** `{ep.function_name}`")
                    with detail_col2:
                        st.markdown(f"**File:** `{ep.file_path}`")
                        st.markdown(f"**Line:** `{ep.line_number}`")
                        st.markdown(f"**Request:** {ep.request_details}")
                        st.markdown(f"**Response:** {ep.response_details}")

                    if ep.matched_excel_url:
                        st.success(f"Matched Excel URL: {ep.matched_excel_url}")
                    if ep.matched_excel_path:
                        st.success(f"Matched Excel Path: {ep.matched_excel_path}")

                    if ep.code_snippet:
                        st.markdown("**Code Context:**")
                        st.code(ep.code_snippet, language="java" if primary_lang == "Java" else "csharp")

    with tab5:
        st.markdown(
            '<div class="section-header"><strong>API Request & Response Details</strong></div>',
            unsafe_allow_html=True,
        )

        if all_endpoints:
            rr_filter_col1, rr_filter_col2, rr_filter_col3 = st.columns(3)
            with rr_filter_col1:
                rr_type_filter = st.multiselect(
                    "Filter by API Type",
                    ["REST", "SOAP", "OneData"],
                    default=["REST", "SOAP", "OneData"],
                    key="rr_type_filter",
                )
            with rr_filter_col2:
                rr_func_options = sorted(set(e.function_name for e in all_endpoints))
                rr_func_filter = st.multiselect(
                    "Filter by Function",
                    rr_func_options,
                    default=[],
                    placeholder="All Functions",
                    key="rr_func_filter",
                )
            with rr_filter_col3:
                rr_search = st.text_input(
                    "Search",
                    placeholder="Search by URL, function, or file...",
                    key="rr_search",
                )

            rr_source_names = sorted(set(e.source_name for e in all_endpoints if e.source_name))
            if len(rr_source_names) > 1:
                rr_source_filter = st.multiselect(
                    "Filter by Repo / Source",
                    rr_source_names,
                    default=[],
                    placeholder="All Repos",
                    key="rr_source_filter",
                )
            else:
                rr_source_filter = []

            rr_endpoints = all_endpoints
            if rr_source_filter:
                rr_endpoints = [e for e in rr_endpoints if e.source_name in rr_source_filter]

            rr_filtered = [e for e in rr_endpoints if e.api_type in rr_type_filter]
            if rr_func_filter:
                rr_filtered = [e for e in rr_filtered if e.function_name in rr_func_filter]
            if rr_search:
                q = rr_search.lower()
                rr_filtered = [
                    e for e in rr_filtered
                    if q in e.url.lower()
                    or q in e.file_path.lower()
                    or q in e.function_name.lower()
                ]

            if rr_filtered:
                for i, ep in enumerate(rr_filtered):
                    type_color = {"REST": "#28a745", "SOAP": "#17a2b8", "OneData": "#ffc107"}.get(ep.api_type, "#6c757d")
                    type_emoji = {"REST": "🌐", "SOAP": "📨", "OneData": "📊"}.get(ep.api_type, "🔗")
                    method_badge = f"`{ep.http_method}`" if ep.http_method != "N/A" else ""

                    op_icon = {"CREATE": "🟢", "READ": "🔵", "UPDATE": "🟠", "DELETE": "🔴"}.get(ep.operation, "⚪")
                    with st.expander(
                        f"{type_emoji} [{ep.api_type}] {method_badge} {op_icon} {ep.operation} | {ep.url}  —  {ep.function_name}",
                        expanded=False,
                    ):
                        info_col1, info_col2, info_col3 = st.columns(3)
                        with info_col1:
                            st.markdown(f"**API Type:** `{ep.api_type}`")
                            st.markdown(f"**HTTP Method:** `{ep.http_method}`")
                            st.markdown(f"**Function:** `{ep.function_name}`")
                        with info_col2:
                            op_color = {"CREATE": "🟢", "READ": "🔵", "UPDATE": "🟠", "DELETE": "🔴"}.get(ep.operation, "⚪")
                            st.markdown(f"**Operation:** {op_color} `{ep.operation}`")
                            st.markdown(f"**File:** `{os.path.basename(ep.file_path)}`")
                            st.markdown(f"**Line:** `{ep.line_number}`")
                        with info_col3:
                            st.markdown(f"**Full Path:** `{ep.file_path}`")

                        st.markdown("---")

                        if ep.parameters:
                            st.markdown("**Parameters**")
                            param_rows = []
                            for pline in ep.parameters.split("\n"):
                                parts = [p.strip() for p in pline.split("|")]
                                if len(parts) == 3:
                                    param_rows.append({
                                        "Source": parts[0],
                                        "Type": parts[1],
                                        "Name": parts[2],
                                    })
                            if param_rows:
                                st.dataframe(
                                    pd.DataFrame(param_rows),
                                    use_container_width=True,
                                    hide_index=True,
                                )

                        if ep.payload_fields:
                            st.markdown("**Payload Object Details**")
                            payload_sections = ep.payload_fields.split("\n")
                            current_section = ""
                            fields_for_section = []

                            def _render_payload_section(section_title, fields):
                                if section_title and fields:
                                    st.markdown(f"*{section_title}*")
                                    pf_rows = []
                                    for f in fields:
                                        raw = f.rstrip()
                                        indent_count = len(raw) - len(raw.lstrip())
                                        depth = indent_count // 4
                                        stripped = raw.strip()
                                        if "(circular reference)" in stripped or "(max depth reached)" in stripped or "(same as" in stripped:
                                            pf_rows.append({"Depth": depth, "Type": "", "Field Name": stripped})
                                            continue
                                        parts = stripped.split()
                                        if len(parts) >= 2:
                                            prefix = "  " * depth + ("└─ " if depth > 0 else "")
                                            pf_rows.append({
                                                "Depth": depth,
                                                "Type": " ".join(parts[:-1]),
                                                "Field Name": prefix + parts[-1],
                                            })
                                    if pf_rows:
                                        display_rows = [{"Type": r["Type"], "Field Name": r["Field Name"]} for r in pf_rows]
                                        st.dataframe(pd.DataFrame(display_rows), use_container_width=True, hide_index=True)

                            for pl in payload_sections:
                                if (pl.endswith("):") or "(same as" in pl) and not pl.startswith("  "):
                                    _render_payload_section(current_section, fields_for_section)
                                    current_section = pl
                                    fields_for_section = []
                                    if "(same as" in pl:
                                        st.markdown(f"*{pl}*")
                                        current_section = ""
                                elif pl.strip():
                                    fields_for_section.append(pl)
                            _render_payload_section(current_section, fields_for_section)

                        req_col, resp_col = st.columns(2)
                        with req_col:
                            st.markdown("**Request Details**")
                            if ep.request_details and ep.request_details != "Not detected":
                                st.code(ep.request_details, language=None)
                            else:
                                st.info("No request details detected in source code.")
                        with resp_col:
                            st.markdown("**Response Details**")
                            if ep.response_details and ep.response_details != "Not detected":
                                st.code(ep.response_details, language=None)
                            else:
                                st.info("No response details detected in source code.")

                        if ep.code_snippet:
                            primary_lang = all_results[0]["language"] if all_results else "Java"
                            st.markdown("**Source Code Context**")
                            st.code(ep.code_snippet, language="java" if primary_lang == "Java" else "csharp")

                st.markdown("---")
                st.markdown("**Summary Table**")
                rr_table = []
                for ep in rr_filtered:
                    params_display = ep.parameters.replace("\n", "; ") if ep.parameters else "None detected"
                    rr_table.append({
                        "Repo / Source": ep.source_name,
                        "API Type": ep.api_type,
                        "HTTP Method": ep.http_method,
                        "Operation": ep.operation,
                        "URL / Endpoint": ep.url,
                        "Function": ep.function_name,
                        "File": os.path.basename(ep.file_path),
                        "Parameters": params_display,
                        "Request Details": ep.request_details,
                        "Response Details": ep.response_details,
                    })
                st.dataframe(pd.DataFrame(rr_table), use_container_width=True, hide_index=True)
            else:
                st.info("No endpoints found matching the current filters.")
        else:
            st.info("No endpoints found. Run a scan first to see request and response details.")

    with tab_sor:
        st.markdown(
            '<div class="section-header"><strong>SOR / Source of Record Table Analysis</strong></div>',
            unsafe_allow_html=True,
        )

        # Show SOR table badges at top
        sor_pills_html = " ".join(
            f'<span style="display:inline-block;background:#ede7f6;color:#4a235a;'
            f'padding:4px 12px;border-radius:12px;font-size:0.82rem;font-weight:600;'
            f'margin:3px;">{t}</span>'
            for t in SOR_TABLES
        )
        st.markdown(
            f'<div style="margin-bottom:16px;"><strong>Monitored SOR Tables:</strong><br/>{sor_pills_html}</div>',
            unsafe_allow_html=True,
        )

        if all_endpoints:
            from collections import defaultdict

            # Build SOR → endpoints map
            sor_ep_map = defaultdict(list)
            for ep in all_endpoints:
                if ep.sor_tables:
                    for t in [s.strip() for s in ep.sor_tables.split(",") if s.strip()]:
                        sor_ep_map[t].append(ep)

            apis_with_sor = sum(1 for e in all_endpoints if e.sor_tables)
            sor_detected = len(sor_ep_map)

            sc1, sc2, sc3 = st.columns(3)
            with sc1:
                st.markdown(
                    f'<div class="stat-card" style="border-left:4px solid #9b59b6;">'
                    f'<h3>{apis_with_sor}</h3><p>APIs with SOR refs</p></div>',
                    unsafe_allow_html=True,
                )
            with sc2:
                st.markdown(
                    f'<div class="stat-card" style="border-left:4px solid #9b59b6;">'
                    f'<h3>{sor_detected}</h3><p>SOR Tables Detected</p></div>',
                    unsafe_allow_html=True,
                )
            with sc3:
                st.markdown(
                    f'<div class="stat-card" style="border-left:4px solid #9b59b6;">'
                    f'<h3>{len(SOR_TABLES) - sor_detected}</h3><p>SOR Tables Not Found</p></div>',
                    unsafe_allow_html=True,
                )

            st.markdown("")

            # Summary table: all SOR tables with counts
            st.markdown("#### SOR Table Summary")
            sor_summary = []
            for tname in SOR_TABLES:
                eps = sor_ep_map.get(tname, [])
                sor_summary.append({
                    "SOR Table": tname,
                    "API Count": len(eps),
                    "API Types": ", ".join(sorted(set(e.api_type for e in eps))) if eps else "—",
                    "Functions": ", ".join(sorted(set(e.function_name for e in eps))[:6]) if eps else "—",
                    "Repos": ", ".join(sorted(set(e.source_name for e in eps if e.source_name))) if eps else "—",
                    "Status": "✅ Detected" if eps else "⬜ Not Found",
                })
            st.dataframe(pd.DataFrame(sor_summary), use_container_width=True, hide_index=True)

            # Per-SOR-table detail
            if sor_ep_map:
                st.markdown("#### APIs Per SOR Table")
                for tname in SOR_TABLES:
                    eps = sor_ep_map.get(tname, [])
                    if not eps:
                        continue
                    with st.expander(f"📌 {tname} — {len(eps)} API(s)"):
                        rows = []
                        for ep in eps:
                            rows.append({
                                "Repo / Source": ep.source_name,
                                "API Type": ep.api_type,
                                "HTTP Method": ep.http_method,
                                "URL / Endpoint": ep.url,
                                "Function": ep.function_name,
                                "File": ep.file_path,
                                "Line": ep.line_number,
                                "All SOR Refs": ep.sor_tables,
                            })
                        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
            else:
                st.info(
                    "No SOR table references detected in the scanned code. "
                    "The scanner searches for table names in the code context surrounding each API endpoint."
                )
        else:
            st.info("No endpoints found. Run a scan first.")

    with tab_audit:
        st.markdown(
            '<div class="section-header"><strong>SOR Integration Audit</strong></div>',
            unsafe_allow_html=True,
        )
        audit_data = st.session_state.get("sor_audit_data")

        if audit_data:
            from collections import defaultdict
            sor_calls = audit_data["sor_calls"]
            table_usages = audit_data["table_usages"]
            integration_type = audit_data["integration_type"]

            # Integration type banner
            it_colors = {"API-Based": "#d4edda", "Query-Based": "#d1ecf1", "Both": "#fff3cd", "Not Detected": "#f8d7da"}
            it_text_colors = {"API-Based": "#155724", "Query-Based": "#0c5460", "Both": "#856404", "Not Detected": "#721c24"}
            it_icons = {"API-Based": "🔗", "Query-Based": "🗄️", "Both": "🔗🗄️", "Not Detected": "❓"}
            it_bg = it_colors.get(integration_type, "#f8d7da")
            it_tc = it_text_colors.get(integration_type, "#721c24")
            it_icon = it_icons.get(integration_type, "❓")
            st.markdown(
                f'<div style="background:{it_bg};color:{it_tc};border-left:6px solid {it_tc};'
                f'padding:14px 20px;border-radius:8px;margin-bottom:16px;font-size:1rem;font-weight:600;">'
                f'{it_icon} Integration Type: <strong>{integration_type}</strong></div>',
                unsafe_allow_html=True,
            )

            # Stat cards
            sor_sys_found = len(set(c.sor_system for c in sor_calls))
            tables_found = len(set(t.table_name for t in table_usages))
            demog_count = sum(1 for c in sor_calls if c.is_demographic) + sum(1 for t in table_usages if t.is_demographic)

            ac1, ac2, ac3, ac4, ac5 = st.columns(5)
            for col, val, label, color in [
                (ac1, len(sor_calls), "Outbound SOR Calls", "#28a745"),
                (ac2, sor_sys_found, "SOR Systems Detected", "#ffc107"),
                (ac3, len(table_usages), "Table References", "#17a2b8"),
                (ac4, tables_found, "Unique Tables Found", "#9b59b6"),
                (ac5, demog_count, "Demographic Refs", "#e94560"),
            ]:
                with col:
                    st.markdown(
                        f'<div class="stat-card" style="border-left:4px solid {color};">'
                        f'<h3>{val}</h3><p>{label}</p></div>',
                        unsafe_allow_html=True,
                    )

            st.markdown("")

            # ── Outbound SOR API Calls ──
            if integration_type in ("API-Based", "Both") or sor_calls:
                st.markdown("### 🔗 Outbound SOR API Calls")
                st.caption("HTTP calls the application makes to external SOR systems (outbound only, not internal endpoints)")

                calls_by_sys = defaultdict(list)
                for c in sor_calls:
                    calls_by_sys[c.sor_system].append(c)

                for sys_name in list(SOR_SYSTEMS.keys()):
                    calls = calls_by_sys.get(sys_name, [])
                    status = f"✅ {len(calls)} call(s)" if calls else "⬜ Not Found"
                    label_color = "#155724" if calls else "#999"
                    with st.expander(f"{sys_name}  —  {status}", expanded=bool(calls)):
                        if not calls:
                            st.info(f"No outbound API integration with **{sys_name}** found.")
                        else:
                            rows = []
                            for c in calls:
                                rows.append({
                                    "SOR System": c.sor_system,
                                    "Endpoint URL": c.url,
                                    "HTTP Method": c.http_method,
                                    "Operation": c.operation_desc,
                                    "Class": c.class_name,
                                    "File": c.file_path,
                                    "Line": c.line_number,
                                    "Config Location": c.config_location,
                                    "Demographic?": "Yes" if c.is_demographic else "",
                                    "Repo / Source": c.source_name,
                                })
                            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

                st.markdown("")

            # ── SQL Table Usage ──
            if integration_type in ("Query-Based", "Both") or table_usages:
                st.markdown("### 🗄️ SOR Table Usage (Query-Based)")
                st.caption("Approved SOR tables referenced in SQL files, DAO/repository classes, and ORM mappers")

                tbl_by_name = defaultdict(list)
                for t in table_usages:
                    tbl_by_name[t.table_name].append(t)

                # Summary table
                tbl_summary = []
                for tname in SOR_APPROVED_TABLES:
                    usages = tbl_by_name.get(tname, [])
                    tbl_summary.append({
                        "Table": tname,
                        "Count": len(usages),
                        "Query Types": ", ".join(sorted(set(u.query_type for u in usages))) if usages else "—",
                        "Classes": ", ".join(sorted(set(u.class_name for u in usages if u.class_name)))[:60] if usages else "—",
                        "Status": "✅ Found" if usages else "⬜ Not Found",
                    })
                st.dataframe(pd.DataFrame(tbl_summary), use_container_width=True, hide_index=True)

                # Per-table drilldown
                found_tables = [t for t in SOR_APPROVED_TABLES if tbl_by_name.get(t)]
                if found_tables:
                    st.markdown("#### Per-Table Detail")
                    for tname in found_tables:
                        usages = tbl_by_name[tname]
                        with st.expander(f"📋 {tname} — {len(usages)} reference(s)"):
                            rows = []
                            for u in usages:
                                rows.append({
                                    "Query Type": u.query_type,
                                    "Class": u.class_name,
                                    "File": u.file_path,
                                    "Line": u.line_number,
                                    "Demographic?": "Yes" if u.is_demographic else "",
                                    "Repo / Source": u.source_name,
                                    "Query Context": u.exact_query[:200] if u.exact_query else "",
                                })
                            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

                st.markdown("")

            # ── Demographic summary ──
            st.markdown("### 👥 Demographic Data — APIs & Tables")
            demog_apis = [c for c in sor_calls if c.is_demographic]
            demog_tbls = [t for t in table_usages if t.is_demographic]
            if demog_apis:
                st.markdown("**APIs fetching demographic data:**")
                st.dataframe(pd.DataFrame([{
                    "SOR Name": c.sor_system,
                    "API Endpoint URL": c.url,
                    "HTTP Method": c.http_method,
                    "Class": c.class_name,
                    "Source Location": f"{c.file_path}:{c.line_number}",
                    "Repo": c.source_name,
                } for c in demog_apis]), use_container_width=True, hide_index=True)
            else:
                st.info("No demographic API calls detected.")
            if demog_tbls:
                st.markdown("**Tables containing demographic data:**")
                st.dataframe(pd.DataFrame([{
                    "Table": t.table_name,
                    "Query Type": t.query_type,
                    "Class": t.class_name,
                    "Source Location": f"{t.file_path}:{t.line_number}",
                } for t in demog_tbls]), use_container_width=True, hide_index=True)

            st.markdown("---")
            st.markdown(
                "💡 **Download the full SOR Audit HTML report** from the **Export** tab for a "
                "structured audit report with WHY sections, Elapsed Time, and Impacted Components per SOR system."
            )
        else:
            st.info("Run a scan first to generate the SOR Integration Audit. Upload source code and click **Scan Application**.")

    with tab7:
        st.markdown(
            '<div class="section-header"><strong>Analysis Report</strong></div>',
            unsafe_allow_html=True,
        )

        if all_endpoints:
            from collections import Counter, defaultdict

            an_filter_col1, an_filter_col2 = st.columns(2)
            with an_filter_col1:
                an_funcs = sorted(set(e.function_name for e in all_endpoints))
                an_func_filter = st.multiselect(
                    "Filter by Function",
                    an_funcs,
                    default=[],
                    placeholder="All Functions",
                    key="an_func_filter",
                )
            with an_filter_col2:
                an_sources = sorted(set(e.source_name for e in all_endpoints if e.source_name))
                if len(an_sources) > 1:
                    an_source_filter = st.multiselect(
                        "Filter by Repo / Source",
                        an_sources,
                        default=[],
                        placeholder="All Repos",
                        key="an_source_filter",
                    )
                else:
                    an_source_filter = []

            an_eps = all_endpoints
            if an_func_filter:
                an_eps = [e for e in an_eps if e.function_name in an_func_filter]
            if an_source_filter:
                an_eps = [e for e in an_eps if e.source_name in an_source_filter]

            an_total = len(an_eps)
            an_matched = sum(1 for e in an_eps if e.matched_excel_url or e.matched_excel_path)
            an_unmatched = an_total - an_matched

            ac1, ac2, ac3 = st.columns(3)
            with ac1:
                st.markdown(
                    f'<div class="stat-card"><h3>{an_total}</h3><p>Total APIs</p></div>',
                    unsafe_allow_html=True,
                )
            with ac2:
                st.markdown(
                    f'<div class="stat-card api-rest"><h3>{an_matched}</h3><p>Matched</p></div>',
                    unsafe_allow_html=True,
                )
            with ac3:
                st.markdown(
                    f'<div class="stat-card api-soap"><h3>{an_unmatched}</h3><p>Unmatched</p></div>',
                    unsafe_allow_html=True,
                )

            st.markdown("### By Function")
            func_data = defaultdict(lambda: {"Total": 0, "Matched": 0, "Unmatched": 0, "REST": 0, "SOAP": 0, "OneData": 0})
            for e in an_eps:
                fd = func_data[e.function_name]
                fd["Total"] += 1
                is_m = bool(e.matched_excel_url or e.matched_excel_path)
                if is_m:
                    fd["Matched"] += 1
                else:
                    fd["Unmatched"] += 1
                if e.api_type == "REST":
                    fd["REST"] += 1
                elif e.api_type == "SOAP":
                    fd["SOAP"] += 1
                elif e.api_type == "OneData":
                    fd["OneData"] += 1
            func_rows = []
            for fn in sorted(func_data.keys()):
                d = func_data[fn]
                func_rows.append({"Function": fn, **d})
            df_func = pd.DataFrame(func_rows)
            st.dataframe(df_func, use_container_width=True, hide_index=True)

            if len(an_sources) > 0:
                st.markdown("### By Repo / Source")
                repo_data = defaultdict(lambda: {"Total": 0, "Matched": 0, "Unmatched": 0, "REST": 0, "SOAP": 0, "OneData": 0})
                for e in an_eps:
                    rd = repo_data[e.source_name]
                    rd["Total"] += 1
                    is_m = bool(e.matched_excel_url or e.matched_excel_path)
                    if is_m:
                        rd["Matched"] += 1
                    else:
                        rd["Unmatched"] += 1
                    if e.api_type == "REST":
                        rd["REST"] += 1
                    elif e.api_type == "SOAP":
                        rd["SOAP"] += 1
                    elif e.api_type == "OneData":
                        rd["OneData"] += 1
                repo_rows = []
                for rn in sorted(repo_data.keys()):
                    d = repo_data[rn]
                    repo_rows.append({"Repo / Source": rn, **d})
                df_repo = pd.DataFrame(repo_rows)
                st.dataframe(df_repo, use_container_width=True, hide_index=True)

            st.markdown("### By Function & Repo")
            cross_data = defaultdict(lambda: {"Total": 0, "Matched": 0, "Unmatched": 0})
            for e in an_eps:
                key = (e.function_name, e.source_name)
                cd = cross_data[key]
                cd["Total"] += 1
                is_m = bool(e.matched_excel_url or e.matched_excel_path)
                if is_m:
                    cd["Matched"] += 1
                else:
                    cd["Unmatched"] += 1
            cross_rows = []
            for (fn, rn) in sorted(cross_data.keys()):
                d = cross_data[(fn, rn)]
                cross_rows.append({"Function": fn, "Repo / Source": rn, **d})
            df_cross = pd.DataFrame(cross_rows)
            st.dataframe(df_cross, use_container_width=True, hide_index=True)

            st.markdown("### By API Type & HTTP Method")
            type_method_data = defaultdict(lambda: {"Total": 0, "Matched": 0, "Unmatched": 0})
            for e in an_eps:
                key = (e.api_type, e.http_method)
                td = type_method_data[key]
                td["Total"] += 1
                is_m = bool(e.matched_excel_url or e.matched_excel_path)
                if is_m:
                    td["Matched"] += 1
                else:
                    td["Unmatched"] += 1
            type_rows = []
            for (at, hm) in sorted(type_method_data.keys()):
                d = type_method_data[(at, hm)]
                type_rows.append({"API Type": at, "HTTP Method": hm, **d})
            df_type = pd.DataFrame(type_rows)
            st.dataframe(df_type, use_container_width=True, hide_index=True)
        else:
            st.info("No endpoints found. Run a scan first to see analysis.")

    with tab6:
        st.markdown(
            '<div class="section-header"><strong>Export & Download Reports</strong></div>',
            unsafe_allow_html=True,
        )

        if all_endpoints:
            combined_source_name = ", ".join(r["source_name"] for r in all_results)

            overview_diagrams = {}
            try:
                overview_diagrams["API Flow Diagram"] = create_api_flow_diagram(
                    all_endpoints, language_display
                )
                overview_diagrams["File Dependencies"] = create_file_dependency_diagram(all_endpoints)
                overview_diagrams["API Summary"] = create_api_summary_diagram(all_endpoints)
            except Exception:
                pass

            if is_multi:
                # ── Multi-repo: one comprehensive HTML + per-repo diagrams ──
                st.markdown("### Combined Multi-Repo HTML Report")
                st.markdown(
                    "One complete HTML file with an **overall analysis** (by repo, function, API type) "
                    "followed by a **dedicated section for every repo** — stats, endpoint table, "
                    "detail cards, and diagrams."
                )

                per_repo_diagrams = {}
                for idx, r in enumerate(all_results):
                    rdiags = {}
                    try:
                        rdiags["API Flow Diagram"] = create_api_flow_diagram(
                            r["endpoints"], r["language"] or "Application"
                        )
                        rdiags["File Dependencies"] = create_file_dependency_diagram(r["endpoints"])
                        rdiags["API Summary"] = create_api_summary_diagram(r["endpoints"])
                    except Exception:
                        pass
                    per_repo_diagrams[idx] = rdiags

                multi_html = generate_multi_repo_html_report(
                    all_results,
                    language_display,
                    total_scanned,
                    total_total,
                    overview_diagrams=overview_diagrams,
                    per_repo_diagrams=per_repo_diagrams,
                )
                st.download_button(
                    label="Download Combined Multi-Repo HTML Report",
                    data=multi_html,
                    file_name="code_lens_multi_repo_report.html",
                    mime="text/html",
                    use_container_width=True,
                )

                st.markdown("---")
                st.markdown("### Individual Per-Repo Downloads")
                st.markdown("Download a separate HTML or Excel report for each repo.")

                for idx, r in enumerate(all_results):
                    ep_count = len(r["endpoints"])
                    rest_c  = sum(1 for e in r["endpoints"] if e.api_type == "REST")
                    soap_c  = sum(1 for e in r["endpoints"] if e.api_type == "SOAP")
                    od_c    = sum(1 for e in r["endpoints"] if e.api_type == "OneData")
                    match_c = sum(1 for e in r["endpoints"] if e.matched_excel_url or e.matched_excel_path)
                    safe_name = re.sub(r'[^\w\-.]', '_', r["source_name"].replace(".zip", ""))

                    with st.expander(
                        f"{r['source_name']} — {ep_count} APIs  (REST: {rest_c}, SOAP: {soap_c}, OneData: {od_c}, Matched: {match_c})",
                        expanded=False,
                    ):
                        ind_col1, ind_col2 = st.columns(2)
                        with ind_col1:
                            ind_html = generate_html_report(
                                r["endpoints"],
                                r["language"] or "Unknown",
                                r["scanned_files"],
                                r["total_files"],
                                diagram_images=per_repo_diagrams.get(idx, {}),
                                source_name=r["source_name"],
                            )
                            st.download_button(
                                label="Download HTML",
                                data=ind_html,
                                file_name=f"code_lens_{safe_name}.html",
                                mime="text/html",
                                use_container_width=True,
                                key=f"html_{idx}",
                            )
                        with ind_col2:
                            ind_excel = generate_excel_report(
                                r["endpoints"],
                                r["language"] or "Unknown",
                                r["scanned_files"],
                                r["total_files"],
                                source_name=r["source_name"],
                            )
                            st.download_button(
                                label="Download Excel",
                                data=ind_excel,
                                file_name=f"code_lens_{safe_name}.xlsx",
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                use_container_width=True,
                                key=f"excel_{idx}",
                            )

                st.markdown("---")
                st.markdown("### Single-Source Overview Reports")

            # ── SOR Audit Report ──
            audit_data = st.session_state.get("sor_audit_data")
            if audit_data:
                st.markdown("### 🔍 SOR Integration Audit Report")
                st.markdown(
                    "Structured HTML audit report: Integration Type, outbound SOR API calls, "
                    "SQL table usage, demographic data APIs, WHY sections, Elapsed Time, "
                    "and Impacted Components per SOR system."
                )
                try:
                    sor_audit_html = generate_sor_audit_report(
                        audit_data["sor_calls"],
                        audit_data["table_usages"],
                        audit_data["integration_type"],
                        all_results,
                        language_display,
                        source_name=combined_source_name,
                    )
                    st.download_button(
                        label="⬇️ Download SOR Audit Report (HTML)",
                        data=sor_audit_html,
                        file_name="code_lens_sor_audit_report.html",
                        mime="text/html",
                        use_container_width=True,
                    )
                except Exception as e:
                    st.error(f"Could not generate SOR audit report: {e}")
                st.markdown("---")

            dl_col1, dl_col2, dl_col3 = st.columns(3)

            with dl_col1:
                st.markdown("#### HTML Report")
                if is_multi:
                    st.markdown("All endpoints combined in a single HTML (no per-repo breakdown).")
                else:
                    st.markdown("Full report with diagrams, tables, and code snippets.")
                html_data = generate_html_report(
                    all_endpoints,
                    language_display,
                    total_scanned,
                    total_total,
                    diagram_images=overview_diagrams,
                    source_name=combined_source_name,
                )
                st.download_button(
                    label="Download HTML Report" if not is_multi else "Download Overview HTML",
                    data=html_data,
                    file_name="code_lens_overview_report.html",
                    mime="text/html",
                    use_container_width=True,
                )

            with dl_col2:
                st.markdown("#### Excel Report")
                if is_multi:
                    st.markdown("Combined workbook with all sources, matches, and summary.")
                else:
                    st.markdown("Multi-sheet workbook with all endpoints, matches, and summary stats.")
                excel_data = generate_excel_report(
                    all_endpoints,
                    language_display,
                    total_scanned,
                    total_total,
                    source_name=combined_source_name,
                )
                st.download_button(
                    label="Download Excel Report" if not is_multi else "Download Overview Excel",
                    data=excel_data,
                    file_name="code_lens_overview_report.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                )

            with dl_col3:
                st.markdown("#### CSV Export")
                st.markdown("Simple flat file for quick data analysis or import.")
                export_data = []
                for r in all_results:
                    for ep in r["endpoints"]:
                        export_data.append({
                            "Source": r["source_name"],
                            "API Type": ep.api_type,
                            "HTTP Method": ep.http_method,
                            "Operation": ep.operation,
                            "URL / Endpoint": ep.url,
                            "Function Name": ep.function_name,
                            "File Path": ep.file_path,
                            "Line Number": ep.line_number,
                            "Parameters": ep.parameters.replace("\n", "; ") if ep.parameters else "",
                            "Request Details": ep.request_details,
                            "Response Details": ep.response_details,
                            "Matched Excel URL": ep.matched_excel_url,
                            "Matched Excel Path": ep.matched_excel_path,
                            "SOR Tables": ep.sor_tables or "",
                        })
                df_export = pd.DataFrame(export_data)
                csv_data = df_export.to_csv(index=False)
                st.download_button(
                    label="Download CSV",
                    data=csv_data,
                    file_name="code_lens_report.csv",
                    mime="text/csv",
                    use_container_width=True,
                )

            st.markdown("---")
            st.markdown("**Data Preview:**")
            preview_data = []
            for r in all_results:
                for ep in r["endpoints"]:
                    row = {
                        "API Type": ep.api_type,
                        "Method": ep.http_method,
                        "Operation": ep.operation,
                        "URL": ep.url,
                        "Function": ep.function_name,
                        "File": ep.file_path,
                        "Line": ep.line_number,
                        "Excel Match": "Yes" if (ep.matched_excel_url or ep.matched_excel_path) else "No",
                    }
                    if is_multi:
                        row["Source"] = r["source_name"]
                    preview_data.append(row)
            st.dataframe(pd.DataFrame(preview_data), use_container_width=True, hide_index=True)

else:
    st.markdown("---")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown(
            """
            ### Step 1: Excel File *(Optional)*
            Upload an Excel file with `url_details` / `path_details`
            columns to match APIs against a known list.
            **Skip this step** to discover all APIs without matching.
            """
        )
    with col2:
        st.markdown(
            """
            ### Step 2: Provide Source Code
            Upload one or more ZIP archives or paste a Git
            repository URL of your Java or C# project.
            The scanner will analyze all relevant files.
            """
        )
    with col3:
        st.markdown(
            """
            ### Step 3: Scan & Analyze
            Click **Scan Application** to discover REST, SOAP,
            and OneData APIs — including which SOR tables each
            API touches. Download HTML or Excel reports.
            """
        )

    st.markdown("---")

    # SOR Tables prominent display
    st.markdown("### 📌 SOR / Source of Record Tables")
    st.markdown(
        "The scanner automatically detects references to the following **17 approved SOR tables** "
        "in your code and reports which APIs interact with each one:"
    )
    sor_cols = st.columns(4)
    for i, tname in enumerate(SOR_TABLES):
        with sor_cols[i % 4]:
            st.markdown(
                f'<div style="background:#ffffff;border-left:4px solid #9b59b6;'
                f'border:1px solid #d8b4fe;padding:8px 12px;border-radius:8px;'
                f'margin-bottom:8px;font-size:0.84rem;color:#4a235a;font-weight:600;">'
                f'{tname}</div>',
                unsafe_allow_html=True,
            )

    st.markdown("---")
    st.markdown(
        """
        #### Supported Detection
        | Type | Java | C# |
        |------|------|----|
        | REST | Spring MVC, JAX-RS | ASP.NET Core |
        | SOAP | JAX-WS, WSDL | WCF, ASMX |
        | OneData | Function calls | Function calls |
        | SOR Tables | All languages — keyword scan in code context ||
        """
    )
