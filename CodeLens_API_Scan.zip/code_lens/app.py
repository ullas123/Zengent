import streamlit as st
import pandas as pd
import os
import shutil
import tempfile
from scanner import (
    extract_source_files,
    clone_git_repo,
    scan_source_code,
    deduplicate_endpoints,
    detect_language,
)
from diagram import (
    create_api_flow_diagram,
    create_file_dependency_diagram,
    create_api_summary_diagram,
)


st.set_page_config(
    page_title="Code Lens - API Scan",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .main-header {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        padding: 2rem;
        border-radius: 12px;
        margin-bottom: 1.5rem;
        text-align: center;
    }
    .main-header h1 {
        color: #e94560;
        font-size: 2.2rem;
        margin-bottom: 0.3rem;
    }
    .main-header p {
        color: #a8b2d1;
        font-size: 1rem;
    }
    .stat-card {
        background: #ffffff;
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        padding: 1.2rem;
        text-align: center;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .stat-card h3 {
        color: #1a1a2e;
        font-size: 2rem;
        margin: 0;
    }
    .stat-card p {
        color: #6c757d;
        margin: 0;
        font-size: 0.85rem;
    }
    .api-rest { border-left: 4px solid #28a745; }
    .api-soap { border-left: 4px solid #17a2b8; }
    .api-onedata { border-left: 4px solid #ffc107; }
    .section-header {
        background: #f8f9fa;
        padding: 0.8rem 1.2rem;
        border-radius: 8px;
        border-left: 4px solid #e94560;
        margin: 1rem 0;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="main-header">
        <h1>Code Lens - API Scan</h1>
        <p>Scan Java & C# applications to discover REST, SOAP, and OneData API endpoints</p>
    </div>
    """,
    unsafe_allow_html=True,
)

if "scan_results" not in st.session_state:
    st.session_state.scan_results = None
if "language" not in st.session_state:
    st.session_state.language = None
if "scanned_files" not in st.session_state:
    st.session_state.scanned_files = 0
if "total_files" not in st.session_state:
    st.session_state.total_files = 0

with st.sidebar:
    st.markdown("### Upload Files")

    st.markdown("**1. Excel File** (with `url_details` and `path_details` columns)")
    excel_file = st.file_uploader(
        "Upload Excel file",
        type=["xlsx", "xls"],
        help="Excel file with columns: url_details, path_details",
        label_visibility="collapsed",
    )

    st.markdown("---")
    st.markdown("**2. Source Code**")
    source_option = st.radio(
        "Choose source input method",
        ["Upload ZIP file", "Git Repository URL"],
        horizontal=True,
        label_visibility="collapsed",
    )

    source_file = None
    git_url = ""
    git_branch = ""

    if source_option == "Upload ZIP file":
        source_file = st.file_uploader(
            "Upload source code ZIP",
            type=["zip"],
            help="ZIP file containing your Java or C# project source code",
            label_visibility="collapsed",
        )
    else:
        git_url = st.text_input(
            "Git Repository URL",
            placeholder="https://github.com/user/repo.git",
            help="Public repo URL, or use https://<token>@github.com/user/repo.git for private repos",
        )
        git_branch = st.text_input(
            "Branch (optional)",
            placeholder="main",
            help="Leave empty for default branch",
        )

    has_source = (source_option == "Upload ZIP file" and source_file) or (
        source_option == "Git Repository URL" and git_url.strip()
    )

    st.markdown("---")

    scan_button = st.button(
        "Scan Application",
        type="primary",
        use_container_width=True,
        disabled=not (excel_file and has_source),
    )

    if scan_button and excel_file and has_source:
        with st.spinner("Scanning source code..."):
            try:
                df = pd.read_excel(excel_file)
                col_mapping = {}
                for col in df.columns:
                    col_lower = col.strip().lower().replace(" ", "_")
                    if "url" in col_lower:
                        col_mapping["url_details"] = col
                    elif "path" in col_lower:
                        col_mapping["path_details"] = col

                excel_urls = []
                excel_paths = []

                if "url_details" in col_mapping:
                    excel_urls = df[col_mapping["url_details"]].dropna().astype(str).tolist()
                if "path_details" in col_mapping:
                    excel_paths = df[col_mapping["path_details"]].dropna().astype(str).tolist()

                if not excel_urls and not excel_paths:
                    st.error(
                        "Could not find 'url_details' or 'path_details' columns in Excel file. "
                        f"Found columns: {list(df.columns)}"
                    )
                else:
                    source_dir = None
                    error = None

                    if source_option == "Upload ZIP file":
                        source_dir, error = extract_source_files(source_file)
                    else:
                        with st.spinner("Cloning Git repository..."):
                            source_dir, error = clone_git_repo(
                                git_url.strip(),
                                branch=git_branch.strip() if git_branch.strip() else None,
                            )

                    if error:
                        st.error(error)
                    else:
                        try:
                            endpoints, language, scanned, total = scan_source_code(
                                source_dir, excel_urls, excel_paths
                            )
                            endpoints = deduplicate_endpoints(endpoints)

                            st.session_state.scan_results = endpoints
                            st.session_state.language = language
                            st.session_state.scanned_files = scanned
                            st.session_state.total_files = total
                            st.session_state.excel_urls = excel_urls
                            st.session_state.excel_paths = excel_paths
                            st.session_state.excel_df = df

                            st.success(
                                f"Scan complete! Found {len(endpoints)} API endpoints "
                                f"in {scanned} files."
                            )
                        finally:
                            if source_dir and os.path.exists(source_dir):
                                shutil.rmtree(os.path.dirname(source_dir), ignore_errors=True)

            except Exception as e:
                st.error(f"Error during scan: {str(e)}")

    st.markdown("---")
    st.markdown("### About")
    st.markdown(
        """
        **Code Lens** scans your Java or C# source
        code and identifies:
        - REST API endpoints
        - SOAP Web Services
        - OneData function calls

        It matches discovered APIs against your
        Excel reference file and generates
        visual flow diagrams.
        """
    )

if st.session_state.scan_results is not None:
    endpoints = st.session_state.scan_results
    language = st.session_state.language

    rest_count = sum(1 for e in endpoints if e.api_type == "REST")
    soap_count = sum(1 for e in endpoints if e.api_type == "SOAP")
    onedata_count = sum(1 for e in endpoints if e.api_type == "OneData")
    matched_count = sum(1 for e in endpoints if e.matched_excel_url or e.matched_excel_path)

    col1, col2, col3, col4, col5, col6 = st.columns(6)
    with col1:
        st.markdown(
            f'<div class="stat-card"><h3>{len(endpoints)}</h3><p>Total APIs</p></div>',
            unsafe_allow_html=True,
        )
    with col2:
        st.markdown(
            f'<div class="stat-card api-rest"><h3>{rest_count}</h3><p>REST APIs</p></div>',
            unsafe_allow_html=True,
        )
    with col3:
        st.markdown(
            f'<div class="stat-card api-soap"><h3>{soap_count}</h3><p>SOAP APIs</p></div>',
            unsafe_allow_html=True,
        )
    with col4:
        st.markdown(
            f'<div class="stat-card api-onedata"><h3>{onedata_count}</h3><p>OneData</p></div>',
            unsafe_allow_html=True,
        )
    with col5:
        st.markdown(
            f'<div class="stat-card"><h3>{matched_count}</h3><p>Excel Matched</p></div>',
            unsafe_allow_html=True,
        )
    with col6:
        st.markdown(
            f'<div class="stat-card"><h3>{language}</h3><p>Language</p></div>',
            unsafe_allow_html=True,
        )

    st.markdown("")

    tab1, tab2, tab3, tab4, tab5 = st.tabs(
        [
            "API Endpoints",
            "Excel Matches",
            "Flow Diagrams",
            "Detailed View",
            "Export",
        ]
    )

    with tab1:
        st.markdown(
            '<div class="section-header"><strong>Discovered API Endpoints</strong></div>',
            unsafe_allow_html=True,
        )

        filter_col1, filter_col2 = st.columns(2)
        with filter_col1:
            type_filter = st.multiselect(
                "Filter by API Type",
                ["REST", "SOAP", "OneData"],
                default=["REST", "SOAP", "OneData"],
            )
        with filter_col2:
            search_query = st.text_input("Search endpoints", placeholder="Search by URL, file, or function...")

        filtered = [e for e in endpoints if e.api_type in type_filter]
        if search_query:
            q = search_query.lower()
            filtered = [
                e
                for e in filtered
                if q in e.url.lower()
                or q in e.file_path.lower()
                or q in e.function_name.lower()
            ]

        if filtered:
            table_data = []
            for ep in filtered:
                table_data.append(
                    {
                        "API Type": ep.api_type,
                        "HTTP Method": ep.http_method,
                        "URL / Endpoint": ep.url,
                        "Function": ep.function_name,
                        "File": ep.file_path,
                        "Line": ep.line_number,
                        "Request": ep.request_details,
                        "Response": ep.response_details,
                    }
                )
            df_table = pd.DataFrame(table_data)
            st.dataframe(df_table, use_container_width=True, hide_index=True)
        else:
            st.info("No endpoints found matching the current filters.")

    with tab2:
        st.markdown(
            '<div class="section-header"><strong>Excel URL & Path Matches</strong></div>',
            unsafe_allow_html=True,
        )

        matched_eps = [e for e in endpoints if e.matched_excel_url or e.matched_excel_path]
        unmatched_eps = [e for e in endpoints if not e.matched_excel_url and not e.matched_excel_path]

        if matched_eps:
            st.markdown(f"**Matched APIs ({len(matched_eps)})**")
            match_data = []
            for ep in matched_eps:
                match_data.append(
                    {
                        "API Type": ep.api_type,
                        "Endpoint URL": ep.url,
                        "Function": ep.function_name,
                        "File": ep.file_path,
                        "Line": ep.line_number,
                        "Matched Excel URL": ep.matched_excel_url,
                        "Matched Excel Path": ep.matched_excel_path,
                    }
                )
            st.dataframe(pd.DataFrame(match_data), use_container_width=True, hide_index=True)
        else:
            st.warning("No direct matches found between Excel entries and source code endpoints.")

        if unmatched_eps:
            with st.expander(f"Unmatched APIs ({len(unmatched_eps)})"):
                unmatch_data = []
                for ep in unmatched_eps:
                    unmatch_data.append(
                        {
                            "API Type": ep.api_type,
                            "Endpoint URL": ep.url,
                            "Function": ep.function_name,
                            "File": ep.file_path,
                            "Line": ep.line_number,
                        }
                    )
                st.dataframe(
                    pd.DataFrame(unmatch_data), use_container_width=True, hide_index=True
                )

        if hasattr(st.session_state, "excel_urls") and st.session_state.excel_urls:
            matched_urls = set(e.matched_excel_url for e in endpoints if e.matched_excel_url)
            unmatched_excel = [u for u in st.session_state.excel_urls if u not in matched_urls]
            if unmatched_excel:
                with st.expander(f"Excel URLs not found in source code ({len(unmatched_excel)})"):
                    for url in unmatched_excel:
                        st.text(f"  - {url}")

    with tab3:
        st.markdown(
            '<div class="section-header"><strong>API Flow Diagrams</strong></div>',
            unsafe_allow_html=True,
        )

        if endpoints:
            diagram_type = st.selectbox(
                "Select Diagram",
                ["API Flow Diagram", "File Dependencies", "API Summary"],
            )

            try:
                if diagram_type == "API Flow Diagram":
                    img_path = create_api_flow_diagram(endpoints, language or "Application")
                elif diagram_type == "File Dependencies":
                    img_path = create_file_dependency_diagram(endpoints)
                else:
                    img_path = create_api_summary_diagram(endpoints)

                st.image(img_path, use_container_width=True)

                with open(img_path, "rb") as f:
                    st.download_button(
                        label=f"Download {diagram_type}",
                        data=f.read(),
                        file_name=f"{diagram_type.lower().replace(' ', '_')}.png",
                        mime="image/png",
                    )
            except Exception as e:
                st.error(f"Error generating diagram: {str(e)}")
        else:
            st.info("No endpoints found to generate diagrams.")

    with tab4:
        st.markdown(
            '<div class="section-header"><strong>Detailed API View</strong></div>',
            unsafe_allow_html=True,
        )

        if endpoints:
            files_with_apis = sorted(set(e.file_path for e in endpoints))
            selected_file = st.selectbox("Select File", files_with_apis)

            file_eps = [e for e in endpoints if e.file_path == selected_file]
            for i, ep in enumerate(file_eps):
                type_emoji = {"REST": "🌐", "SOAP": "📨", "OneData": "📊"}.get(
                    ep.api_type, "🔗"
                )
                with st.expander(
                    f"{type_emoji} {ep.api_type} | {ep.http_method} | {ep.function_name} (Line {ep.line_number})",
                    expanded=i == 0,
                ):
                    detail_col1, detail_col2 = st.columns(2)
                    with detail_col1:
                        st.markdown("**Endpoint URL:**")
                        st.code(ep.url, language=None)
                        st.markdown(f"**API Type:** `{ep.api_type}`")
                        st.markdown(f"**HTTP Method:** `{ep.http_method}`")
                        st.markdown(f"**Function:** `{ep.function_name}`")
                    with detail_col2:
                        st.markdown(f"**File:** `{ep.file_path}`")
                        st.markdown(f"**Line:** `{ep.line_number}`")
                        st.markdown(f"**Request:** {ep.request_details}")
                        st.markdown(f"**Response:** {ep.response_details}")

                    if ep.matched_excel_url:
                        st.success(f"Matched Excel URL: {ep.matched_excel_url}")
                    if ep.matched_excel_path:
                        st.success(f"Matched Excel Path: {ep.matched_excel_path}")

                    if ep.code_snippet:
                        st.markdown("**Code Context:**")
                        st.code(ep.code_snippet, language="java" if language == "Java" else "csharp")

    with tab5:
        st.markdown(
            '<div class="section-header"><strong>Export Results</strong></div>',
            unsafe_allow_html=True,
        )

        if endpoints:
            export_data = []
            for ep in endpoints:
                export_data.append(
                    {
                        "API Type": ep.api_type,
                        "HTTP Method": ep.http_method,
                        "URL / Endpoint": ep.url,
                        "Function Name": ep.function_name,
                        "File Path": ep.file_path,
                        "Line Number": ep.line_number,
                        "Request Details": ep.request_details,
                        "Response Details": ep.response_details,
                        "Matched Excel URL": ep.matched_excel_url,
                        "Matched Excel Path": ep.matched_excel_path,
                    }
                )
            df_export = pd.DataFrame(export_data)

            csv_data = df_export.to_csv(index=False)
            st.download_button(
                label="Download as CSV",
                data=csv_data,
                file_name="code_lens_api_scan_results.csv",
                mime="text/csv",
                use_container_width=True,
            )

            st.markdown("**Preview:**")
            st.dataframe(df_export, use_container_width=True, hide_index=True)

else:
    st.markdown("---")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown(
            """
            ### Step 1: Upload Excel
            Upload your Excel file containing `url_details`
            and `path_details` columns that list the APIs
            used in your application.
            """
        )
    with col2:
        st.markdown(
            """
            ### Step 2: Provide Source Code
            Upload a ZIP archive or paste a Git repository
            URL of your Java or C# project. The scanner
            will analyze all relevant files.
            """
        )
    with col3:
        st.markdown(
            """
            ### Step 3: Scan & Analyze
            Click "Scan Application" to discover REST, SOAP,
            and OneData API endpoints. View results, matches,
            and flow diagrams.
            """
        )

    st.markdown("---")
    st.markdown(
        """
        #### Supported Detection
        | Type | Java | C# |
        |------|------|----|
        | **REST APIs** | Spring MVC (`@GetMapping`, `@PostMapping`, etc.), JAX-RS (`@Path`, `@GET`, etc.) | ASP.NET Core (`[HttpGet]`, `[Route]`, etc.), Web API |
        | **SOAP Services** | JAX-WS (`@WebService`, `@WebMethod`), WSDL files | WCF (`ServiceContract`, `OperationContract`), ASMX |
        | **OneData** | OneData function calls, annotations | OneData service/client calls |
        | **URL References** | `RestTemplate`, `HttpClient`, `URL` objects | `HttpClient`, `WebClient` |
        """
    )
