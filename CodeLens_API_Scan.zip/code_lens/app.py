import streamlit as st
import pandas as pd
import os
import re
import shutil
import tempfile
from scanner import (
    extract_source_files,
    clone_git_repo,
    scan_source_code,
    deduplicate_endpoints,
    detect_language,
)
from diagram import (
    create_api_flow_diagram,
    create_file_dependency_diagram,
    create_api_summary_diagram,
)
from report import generate_html_report, generate_excel_report


st.set_page_config(
    page_title="Code Lens - API Scan",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .main-header {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        padding: 2rem;
        border-radius: 12px;
        margin-bottom: 1.5rem;
        text-align: center;
    }
    .main-header h1 {
        color: #e94560;
        font-size: 2.2rem;
        margin-bottom: 0.3rem;
    }
    .main-header p {
        color: #a8b2d1;
        font-size: 1rem;
    }
    .stat-card {
        background: #ffffff;
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        padding: 1.2rem;
        text-align: center;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .stat-card h3 {
        color: #1a1a2e;
        font-size: 2rem;
        margin: 0;
    }
    .stat-card p {
        color: #6c757d;
        margin: 0;
        font-size: 0.85rem;
    }
    .api-rest { border-left: 4px solid #28a745; }
    .api-soap { border-left: 4px solid #17a2b8; }
    .api-onedata { border-left: 4px solid #ffc107; }
    .section-header {
        background: #f8f9fa;
        padding: 0.8rem 1.2rem;
        border-radius: 8px;
        border-left: 4px solid #e94560;
        margin: 1rem 0;
    }
    .source-badge {
        display: inline-block;
        background: #e8e8e8;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.8rem;
        font-weight: 600;
        margin-right: 6px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="main-header">
        <h1>Code Lens - API Scan</h1>
        <p>Scan Java & C# applications to discover REST, SOAP, and OneData API endpoints</p>
    </div>
    """,
    unsafe_allow_html=True,
)

if "multi_scan_results" not in st.session_state:
    st.session_state.multi_scan_results = None

with st.sidebar:
    st.markdown("### Upload Files")

    st.markdown("**1. Excel File** (with `url_details` and `path_details` columns)")
    excel_file = st.file_uploader(
        "Upload Excel file",
        type=["xlsx", "xls"],
        help="Excel file with columns: url_details, path_details",
        label_visibility="collapsed",
    )

    st.markdown("---")
    st.markdown("**2. Source Code**")
    source_option = st.radio(
        "Choose source input method",
        ["Upload ZIP files", "Git Repository URL"],
        horizontal=True,
        label_visibility="collapsed",
    )

    source_files = None
    git_url = ""
    git_branch = ""

    if source_option == "Upload ZIP files":
        source_files = st.file_uploader(
            "Upload source code ZIP(s)",
            type=["zip"],
            accept_multiple_files=True,
            help="Upload one or more ZIP files containing your Java or C# project source code",
            label_visibility="collapsed",
        )
    else:
        git_url = st.text_input(
            "Git Repository URL",
            placeholder="https://github.com/user/repo.git",
            help="Public repo URL, or use https://<token>@github.com/user/repo.git for private repos",
        )
        git_branch = st.text_input(
            "Branch (optional)",
            placeholder="main",
            help="Leave empty for default branch",
        )

    has_source = (source_option == "Upload ZIP files" and source_files and len(source_files) > 0) or (
        source_option == "Git Repository URL" and git_url.strip()
    )

    st.markdown("---")

    scan_button = st.button(
        "Scan Application",
        type="primary",
        use_container_width=True,
        disabled=not (excel_file and has_source),
    )

    if scan_button and excel_file and has_source:
        with st.spinner("Scanning source code..."):
            try:
                df = pd.read_excel(excel_file)

                clean_cols = {}
                for col in df.columns:
                    cleaned = re.sub(r'[^\x20-\x7E]', '', str(col)).strip()
                    if cleaned != str(col):
                        df = df.rename(columns={col: cleaned})
                    clean_cols[cleaned] = cleaned

                if len(df.columns) == 1 and "," in str(df.columns[0]):
                    single_col = str(df.columns[0])
                    new_cols = [c.strip() for c in single_col.split(",")]
                    if len(new_cols) >= 2:
                        df = pd.read_excel(excel_file, header=None, skiprows=1)
                        if len(df.columns) >= len(new_cols):
                            df.columns = new_cols + [f"col_{i}" for i in range(len(new_cols), len(df.columns))]

                col_mapping = {}
                normalized_cols = {}
                for col in df.columns:
                    col_lower = str(col).strip().lower().replace(" ", "_").replace("-", "_")
                    normalized_cols[col_lower] = col

                url_priorities = ["url_details", "urldetails", "url_detail", "urldetail"]
                path_priorities = ["path_details", "pathdetails", "path_detail", "pathdetail"]

                for key in url_priorities:
                    if key in normalized_cols:
                        col_mapping["url_details"] = normalized_cols[key]
                        break
                if "url_details" not in col_mapping:
                    for col_lower, col_orig in normalized_cols.items():
                        if "url" in col_lower:
                            col_mapping["url_details"] = col_orig
                            break

                for key in path_priorities:
                    if key in normalized_cols:
                        col_mapping["path_details"] = normalized_cols[key]
                        break
                if "path_details" not in col_mapping:
                    for col_lower, col_orig in normalized_cols.items():
                        if "path" in col_lower:
                            col_mapping["path_details"] = col_orig
                            break

                excel_urls = []
                excel_paths = []

                if "url_details" in col_mapping:
                    excel_urls = df[col_mapping["url_details"]].dropna().astype(str).tolist()
                if "path_details" in col_mapping:
                    excel_paths = df[col_mapping["path_details"]].dropna().astype(str).tolist()

                if not excel_urls and not excel_paths:
                    st.error(
                        "Could not find columns for URL or path details in your Excel file. "
                        "Please make sure your file has columns named **url_details** and/or **path_details** "
                        "(or similar names containing 'url' or 'path')."
                    )
                    st.info(
                        f"**Columns found in your file:** {', '.join(str(c) for c in df.columns)}"
                    )
                else:
                    matched_cols = []
                    if "url_details" in col_mapping:
                        matched_cols.append(f"URL column: **{col_mapping['url_details']}** ({len(excel_urls)} entries)")
                    if "path_details" in col_mapping:
                        matched_cols.append(f"Path column: **{col_mapping['path_details']}** ({len(excel_paths)} entries)")
                    st.info(f"Excel columns detected: {' | '.join(matched_cols)}")

                    sources_to_scan = []

                    if source_option == "Upload ZIP files":
                        for sf in source_files:
                            source_dir, error = extract_source_files(sf)
                            if error:
                                st.error(f"Error with {sf.name}: {error}")
                            else:
                                sources_to_scan.append((sf.name, source_dir))
                    else:
                        with st.spinner("Cloning Git repository..."):
                            source_dir, error = clone_git_repo(
                                git_url.strip(),
                                branch=git_branch.strip() if git_branch.strip() else None,
                            )
                        if error:
                            st.error(error)
                        else:
                            sources_to_scan.append((git_url.strip(), source_dir))

                    if sources_to_scan:
                        all_results = []
                        total_endpoints = 0
                        total_scanned = 0
                        total_total = 0

                        for source_name, source_dir in sources_to_scan:
                            try:
                                endpoints, language, scanned, total = scan_source_code(
                                    source_dir, excel_urls, excel_paths
                                )
                                endpoints = deduplicate_endpoints(endpoints)
                                all_results.append({
                                    "source_name": source_name,
                                    "endpoints": endpoints,
                                    "language": language,
                                    "scanned_files": scanned,
                                    "total_files": total,
                                })
                                total_endpoints += len(endpoints)
                                total_scanned += scanned
                                total_total += total
                            except Exception as e:
                                st.error(f"Error scanning {source_name}: {str(e)}")
                            finally:
                                if source_dir and os.path.exists(source_dir):
                                    shutil.rmtree(os.path.dirname(source_dir), ignore_errors=True)

                        if all_results:
                            st.session_state.multi_scan_results = all_results
                            st.session_state.excel_urls = excel_urls
                            st.session_state.excel_paths = excel_paths
                            st.session_state.excel_df = df

                            if len(all_results) == 1:
                                st.success(
                                    f"Scan complete! Found {total_endpoints} API endpoints "
                                    f"in {total_scanned} files."
                                )
                            else:
                                st.success(
                                    f"Scan complete! Scanned {len(all_results)} sources. "
                                    f"Found {total_endpoints} total API endpoints "
                                    f"in {total_scanned} files."
                                )

            except Exception as e:
                st.error(f"Error during scan: {str(e)}")

    st.markdown("---")
    st.markdown("### About")
    st.markdown(
        """
        **Code Lens** scans your Java or C# source
        code and identifies:
        - REST API endpoints
        - SOAP Web Services
        - OneData function calls

        It matches discovered APIs against your
        Excel reference file and generates
        visual flow diagrams.
        """
    )

    st.markdown("---")
    st.markdown("### Download for Local Use")
    local_zip_path = os.path.join(os.path.dirname(__file__), "CodeLens_API_Scan.zip")
    if os.path.exists(local_zip_path):
        with open(local_zip_path, "rb") as zf:
            st.download_button(
                label="Download Local Installer",
                data=zf.read(),
                file_name="CodeLens_API_Scan.zip",
                mime="application/zip",
                use_container_width=True,
            )

if st.session_state.multi_scan_results is not None:
    all_results = st.session_state.multi_scan_results
    is_multi = len(all_results) > 1

    all_endpoints = []
    for r in all_results:
        all_endpoints.extend(r["endpoints"])

    languages = list(set(r["language"] for r in all_results if r["language"]))
    language_display = ", ".join(languages) if languages else "Unknown"
    total_scanned = sum(r["scanned_files"] for r in all_results)
    total_total = sum(r["total_files"] for r in all_results)

    rest_count = sum(1 for e in all_endpoints if e.api_type == "REST")
    soap_count = sum(1 for e in all_endpoints if e.api_type == "SOAP")
    onedata_count = sum(1 for e in all_endpoints if e.api_type == "OneData")
    matched_count = sum(1 for e in all_endpoints if e.matched_excel_url or e.matched_excel_path)

    stat_cols = st.columns(7 if is_multi else 6)
    with stat_cols[0]:
        st.markdown(
            f'<div class="stat-card"><h3>{len(all_endpoints)}</h3><p>Total APIs</p></div>',
            unsafe_allow_html=True,
        )
    with stat_cols[1]:
        st.markdown(
            f'<div class="stat-card api-rest"><h3>{rest_count}</h3><p>REST APIs</p></div>',
            unsafe_allow_html=True,
        )
    with stat_cols[2]:
        st.markdown(
            f'<div class="stat-card api-soap"><h3>{soap_count}</h3><p>SOAP APIs</p></div>',
            unsafe_allow_html=True,
        )
    with stat_cols[3]:
        st.markdown(
            f'<div class="stat-card api-onedata"><h3>{onedata_count}</h3><p>OneData</p></div>',
            unsafe_allow_html=True,
        )
    with stat_cols[4]:
        st.markdown(
            f'<div class="stat-card"><h3>{matched_count}</h3><p>Excel Matched</p></div>',
            unsafe_allow_html=True,
        )
    with stat_cols[5]:
        st.markdown(
            f'<div class="stat-card"><h3>{language_display}</h3><p>Language</p></div>',
            unsafe_allow_html=True,
        )
    if is_multi:
        with stat_cols[6]:
            st.markdown(
                f'<div class="stat-card"><h3>{len(all_results)}</h3><p>Sources</p></div>',
                unsafe_allow_html=True,
            )

    st.markdown("")

    tab_names = [
        "API Endpoints",
        "Excel Matches",
        "Flow Diagrams",
        "Detailed View",
        "Request & Response",
        "Export",
    ]
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(tab_names)

    with tab1:
        st.markdown(
            '<div class="section-header"><strong>Discovered API Endpoints</strong></div>',
            unsafe_allow_html=True,
        )

        filter_col1, filter_col2 = st.columns(2)
        with filter_col1:
            type_filter = st.multiselect(
                "Filter by API Type",
                ["REST", "SOAP", "OneData"],
                default=["REST", "SOAP", "OneData"],
            )
        with filter_col2:
            search_query = st.text_input("Search endpoints", placeholder="Search by URL, file, or function...")

        if is_multi:
            source_names = ["All Sources"] + [r["source_name"] for r in all_results]
            selected_source = st.selectbox("Filter by Source", source_names, key="ep_source_filter")
        else:
            selected_source = "All Sources"

        if selected_source == "All Sources":
            display_endpoints = all_endpoints
        else:
            for r in all_results:
                if r["source_name"] == selected_source:
                    display_endpoints = r["endpoints"]
                    break

        filtered = [e for e in display_endpoints if e.api_type in type_filter]
        if search_query:
            q = search_query.lower()
            filtered = [
                e
                for e in filtered
                if q in e.url.lower()
                or q in e.file_path.lower()
                or q in e.function_name.lower()
            ]

        if filtered:
            table_data = []
            for ep in filtered:
                row = {
                    "API Type": ep.api_type,
                    "HTTP Method": ep.http_method,
                    "URL / Endpoint": ep.url,
                    "Function": ep.function_name,
                    "File": ep.file_path,
                    "Line": ep.line_number,
                    "Request": ep.request_details,
                    "Response": ep.response_details,
                }
                table_data.append(row)
            df_table = pd.DataFrame(table_data)
            st.dataframe(df_table, use_container_width=True, hide_index=True)
        else:
            st.info("No endpoints found matching the current filters.")

    with tab2:
        st.markdown(
            '<div class="section-header"><strong>Excel URL & Path Matches</strong></div>',
            unsafe_allow_html=True,
        )

        matched_eps = [e for e in all_endpoints if e.matched_excel_url or e.matched_excel_path]
        unmatched_eps = [e for e in all_endpoints if not e.matched_excel_url and not e.matched_excel_path]

        if matched_eps:
            st.markdown(f"**Matched APIs ({len(matched_eps)})**")
            match_data = []
            for ep in matched_eps:
                match_data.append(
                    {
                        "API Type": ep.api_type,
                        "Endpoint URL": ep.url,
                        "Function": ep.function_name,
                        "File": ep.file_path,
                        "Line": ep.line_number,
                        "Matched Excel URL": ep.matched_excel_url,
                        "Matched Excel Path": ep.matched_excel_path,
                    }
                )
            st.dataframe(pd.DataFrame(match_data), use_container_width=True, hide_index=True)
        else:
            st.warning("No direct matches found between Excel entries and source code endpoints.")

        if unmatched_eps:
            with st.expander(f"Unmatched APIs ({len(unmatched_eps)})"):
                unmatch_data = []
                for ep in unmatched_eps:
                    unmatch_data.append(
                        {
                            "API Type": ep.api_type,
                            "Endpoint URL": ep.url,
                            "Function": ep.function_name,
                            "File": ep.file_path,
                            "Line": ep.line_number,
                        }
                    )
                st.dataframe(
                    pd.DataFrame(unmatch_data), use_container_width=True, hide_index=True
                )

        if hasattr(st.session_state, "excel_urls") and st.session_state.excel_urls:
            matched_urls = set(e.matched_excel_url for e in all_endpoints if e.matched_excel_url)
            unmatched_excel = [u for u in st.session_state.excel_urls if u not in matched_urls]
            if unmatched_excel:
                with st.expander(f"Excel URLs not found in source code ({len(unmatched_excel)})"):
                    for url in unmatched_excel:
                        st.text(f"  - {url}")

    with tab3:
        st.markdown(
            '<div class="section-header"><strong>API Flow Diagrams</strong></div>',
            unsafe_allow_html=True,
        )

        if all_endpoints:
            if is_multi:
                diagram_source_opts = ["All Sources (Combined)"] + [r["source_name"] for r in all_results]
                diagram_source = st.selectbox("Select Source for Diagram", diagram_source_opts, key="diagram_source")
            else:
                diagram_source = "All Sources (Combined)"

            if diagram_source == "All Sources (Combined)":
                diagram_eps = all_endpoints
                diagram_lang = language_display
            else:
                for r in all_results:
                    if r["source_name"] == diagram_source:
                        diagram_eps = r["endpoints"]
                        diagram_lang = r["language"] or "Application"
                        break

            diagram_type = st.selectbox(
                "Select Diagram",
                ["API Flow Diagram", "File Dependencies", "API Summary"],
            )

            try:
                if diagram_type == "API Flow Diagram":
                    img_path = create_api_flow_diagram(diagram_eps, diagram_lang)
                elif diagram_type == "File Dependencies":
                    img_path = create_file_dependency_diagram(diagram_eps)
                else:
                    img_path = create_api_summary_diagram(diagram_eps)

                st.image(img_path, use_container_width=True)

                with open(img_path, "rb") as f:
                    st.download_button(
                        label=f"Download {diagram_type}",
                        data=f.read(),
                        file_name=f"{diagram_type.lower().replace(' ', '_')}.png",
                        mime="image/png",
                    )
            except Exception as e:
                st.error(f"Error generating diagram: {str(e)}")
        else:
            st.info("No endpoints found to generate diagrams.")

    with tab4:
        st.markdown(
            '<div class="section-header"><strong>Detailed API View</strong></div>',
            unsafe_allow_html=True,
        )

        if all_endpoints:
            if is_multi:
                detail_source_opts = ["All Sources"] + [r["source_name"] for r in all_results]
                detail_source = st.selectbox("Select Source", detail_source_opts, key="detail_source")
                if detail_source == "All Sources":
                    detail_eps = all_endpoints
                else:
                    for r in all_results:
                        if r["source_name"] == detail_source:
                            detail_eps = r["endpoints"]
                            break
            else:
                detail_eps = all_endpoints

            primary_lang = all_results[0]["language"] if all_results else "Java"

            files_with_apis = sorted(set(e.file_path for e in detail_eps))
            selected_file = st.selectbox("Select File", files_with_apis)

            file_eps = [e for e in detail_eps if e.file_path == selected_file]
            for i, ep in enumerate(file_eps):
                type_emoji = {"REST": "🌐", "SOAP": "📨", "OneData": "📊"}.get(
                    ep.api_type, "🔗"
                )
                with st.expander(
                    f"{type_emoji} {ep.api_type} | {ep.http_method} | {ep.function_name} (Line {ep.line_number})",
                    expanded=i == 0,
                ):
                    detail_col1, detail_col2 = st.columns(2)
                    with detail_col1:
                        st.markdown("**Endpoint URL:**")
                        st.code(ep.url, language=None)
                        st.markdown(f"**API Type:** `{ep.api_type}`")
                        st.markdown(f"**HTTP Method:** `{ep.http_method}`")
                        st.markdown(f"**Function:** `{ep.function_name}`")
                    with detail_col2:
                        st.markdown(f"**File:** `{ep.file_path}`")
                        st.markdown(f"**Line:** `{ep.line_number}`")
                        st.markdown(f"**Request:** {ep.request_details}")
                        st.markdown(f"**Response:** {ep.response_details}")

                    if ep.matched_excel_url:
                        st.success(f"Matched Excel URL: {ep.matched_excel_url}")
                    if ep.matched_excel_path:
                        st.success(f"Matched Excel Path: {ep.matched_excel_path}")

                    if ep.code_snippet:
                        st.markdown("**Code Context:**")
                        st.code(ep.code_snippet, language="java" if primary_lang == "Java" else "csharp")

    with tab5:
        st.markdown(
            '<div class="section-header"><strong>API Request & Response Details</strong></div>',
            unsafe_allow_html=True,
        )

        if all_endpoints:
            rr_filter_col1, rr_filter_col2 = st.columns(2)
            with rr_filter_col1:
                rr_type_filter = st.multiselect(
                    "Filter by API Type",
                    ["REST", "SOAP", "OneData"],
                    default=["REST", "SOAP", "OneData"],
                    key="rr_type_filter",
                )
            with rr_filter_col2:
                rr_search = st.text_input(
                    "Search",
                    placeholder="Search by URL, function, or file...",
                    key="rr_search",
                )

            if is_multi:
                rr_source_opts = ["All Sources"] + [r["source_name"] for r in all_results]
                rr_selected_source = st.selectbox("Filter by Source", rr_source_opts, key="rr_source_filter")
            else:
                rr_selected_source = "All Sources"

            if rr_selected_source == "All Sources":
                rr_endpoints = all_endpoints
            else:
                for r in all_results:
                    if r["source_name"] == rr_selected_source:
                        rr_endpoints = r["endpoints"]
                        break

            rr_filtered = [e for e in rr_endpoints if e.api_type in rr_type_filter]
            if rr_search:
                q = rr_search.lower()
                rr_filtered = [
                    e for e in rr_filtered
                    if q in e.url.lower()
                    or q in e.file_path.lower()
                    or q in e.function_name.lower()
                ]

            if rr_filtered:
                for i, ep in enumerate(rr_filtered):
                    type_color = {"REST": "#28a745", "SOAP": "#17a2b8", "OneData": "#ffc107"}.get(ep.api_type, "#6c757d")
                    type_emoji = {"REST": "🌐", "SOAP": "📨", "OneData": "📊"}.get(ep.api_type, "🔗")
                    method_badge = f"`{ep.http_method}`" if ep.http_method != "N/A" else ""

                    with st.expander(
                        f"{type_emoji} [{ep.api_type}] {method_badge} {ep.url}  —  {ep.function_name}",
                        expanded=False,
                    ):
                        info_col1, info_col2 = st.columns(2)
                        with info_col1:
                            st.markdown(f"**API Type:** `{ep.api_type}`")
                            st.markdown(f"**HTTP Method:** `{ep.http_method}`")
                            st.markdown(f"**Function:** `{ep.function_name}`")
                        with info_col2:
                            st.markdown(f"**File:** `{os.path.basename(ep.file_path)}`")
                            st.markdown(f"**Line:** `{ep.line_number}`")
                            st.markdown(f"**Full Path:** `{ep.file_path}`")

                        st.markdown("---")

                        if ep.parameters:
                            st.markdown("**Parameters**")
                            param_rows = []
                            for pline in ep.parameters.split("\n"):
                                parts = [p.strip() for p in pline.split("|")]
                                if len(parts) == 3:
                                    param_rows.append({
                                        "Source": parts[0],
                                        "Type": parts[1],
                                        "Name": parts[2],
                                    })
                            if param_rows:
                                st.dataframe(
                                    pd.DataFrame(param_rows),
                                    use_container_width=True,
                                    hide_index=True,
                                )

                        req_col, resp_col = st.columns(2)
                        with req_col:
                            st.markdown("**Request Details**")
                            if ep.request_details and ep.request_details != "Not detected":
                                st.code(ep.request_details, language=None)
                            else:
                                st.info("No request details detected in source code.")
                        with resp_col:
                            st.markdown("**Response Details**")
                            if ep.response_details and ep.response_details != "Not detected":
                                st.code(ep.response_details, language=None)
                            else:
                                st.info("No response details detected in source code.")

                        if ep.code_snippet:
                            primary_lang = all_results[0]["language"] if all_results else "Java"
                            st.markdown("**Source Code Context**")
                            st.code(ep.code_snippet, language="java" if primary_lang == "Java" else "csharp")

                st.markdown("---")
                st.markdown("**Summary Table**")
                rr_table = []
                for ep in rr_filtered:
                    params_display = ep.parameters.replace("\n", "; ") if ep.parameters else "None detected"
                    rr_table.append({
                        "API Type": ep.api_type,
                        "HTTP Method": ep.http_method,
                        "URL / Endpoint": ep.url,
                        "Function": ep.function_name,
                        "File": os.path.basename(ep.file_path),
                        "Parameters": params_display,
                        "Request Details": ep.request_details,
                        "Response Details": ep.response_details,
                    })
                st.dataframe(pd.DataFrame(rr_table), use_container_width=True, hide_index=True)
            else:
                st.info("No endpoints found matching the current filters.")
        else:
            st.info("No endpoints found. Run a scan first to see request and response details.")

    with tab6:
        st.markdown(
            '<div class="section-header"><strong>Export & Download Reports</strong></div>',
            unsafe_allow_html=True,
        )

        if all_endpoints:
            combined_source_name = ", ".join(r["source_name"] for r in all_results)

            overview_diagrams = {}
            try:
                overview_diagrams["API Flow Diagram"] = create_api_flow_diagram(
                    all_endpoints, language_display
                )
                overview_diagrams["File Dependencies"] = create_file_dependency_diagram(all_endpoints)
                overview_diagrams["API Summary"] = create_api_summary_diagram(all_endpoints)
            except Exception:
                pass

            if is_multi:
                st.markdown("### Overview Report (All Sources Combined)")

            dl_col1, dl_col2, dl_col3 = st.columns(3)

            with dl_col1:
                st.markdown("#### HTML Report")
                if is_multi:
                    st.markdown("Combined overview of all scanned sources with diagrams.")
                else:
                    st.markdown("Full report with diagrams, tables, and code snippets.")
                html_data = generate_html_report(
                    all_endpoints,
                    language_display,
                    total_scanned,
                    total_total,
                    diagram_images=overview_diagrams,
                    source_name=combined_source_name,
                )
                st.download_button(
                    label="Download HTML Report" if not is_multi else "Download Overview HTML",
                    data=html_data,
                    file_name="code_lens_overview_report.html",
                    mime="text/html",
                    use_container_width=True,
                )

            with dl_col2:
                st.markdown("#### Excel Report")
                if is_multi:
                    st.markdown("Combined workbook with all sources, matches, and summary.")
                else:
                    st.markdown("Multi-sheet workbook with all endpoints, matches, and summary stats.")
                excel_data = generate_excel_report(
                    all_endpoints,
                    language_display,
                    total_scanned,
                    total_total,
                    source_name=combined_source_name,
                )
                st.download_button(
                    label="Download Excel Report" if not is_multi else "Download Overview Excel",
                    data=excel_data,
                    file_name="code_lens_overview_report.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                )

            with dl_col3:
                st.markdown("#### CSV Export")
                st.markdown("Simple flat file for quick data analysis or import.")
                export_data = []
                for r in all_results:
                    for ep in r["endpoints"]:
                        export_data.append({
                            "Source": r["source_name"],
                            "API Type": ep.api_type,
                            "HTTP Method": ep.http_method,
                            "URL / Endpoint": ep.url,
                            "Function Name": ep.function_name,
                            "File Path": ep.file_path,
                            "Line Number": ep.line_number,
                            "Request Details": ep.request_details,
                            "Response Details": ep.response_details,
                            "Matched Excel URL": ep.matched_excel_url,
                            "Matched Excel Path": ep.matched_excel_path,
                        })
                df_export = pd.DataFrame(export_data)
                csv_data = df_export.to_csv(index=False)
                st.download_button(
                    label="Download CSV",
                    data=csv_data,
                    file_name="code_lens_report.csv",
                    mime="text/csv",
                    use_container_width=True,
                )

            if is_multi:
                st.markdown("---")
                st.markdown("### Individual Source Reports")
                st.markdown("Download a separate HTML report for each scanned source.")

                for idx, r in enumerate(all_results):
                    ind_diagrams = {}
                    try:
                        ind_diagrams["API Flow Diagram"] = create_api_flow_diagram(
                            r["endpoints"], r["language"] or "Application"
                        )
                        ind_diagrams["File Dependencies"] = create_file_dependency_diagram(r["endpoints"])
                        ind_diagrams["API Summary"] = create_api_summary_diagram(r["endpoints"])
                    except Exception:
                        pass

                    ep_count = len(r["endpoints"])
                    rest_c = sum(1 for e in r["endpoints"] if e.api_type == "REST")
                    soap_c = sum(1 for e in r["endpoints"] if e.api_type == "SOAP")
                    od_c = sum(1 for e in r["endpoints"] if e.api_type == "OneData")
                    match_c = sum(1 for e in r["endpoints"] if e.matched_excel_url or e.matched_excel_path)

                    with st.expander(
                        f"{r['source_name']} — {ep_count} APIs (REST: {rest_c}, SOAP: {soap_c}, OneData: {od_c}, Matched: {match_c})",
                        expanded=False,
                    ):
                        ind_col1, ind_col2 = st.columns(2)
                        with ind_col1:
                            ind_html = generate_html_report(
                                r["endpoints"],
                                r["language"] or "Unknown",
                                r["scanned_files"],
                                r["total_files"],
                                diagram_images=ind_diagrams,
                                source_name=r["source_name"],
                            )
                            safe_name = re.sub(r'[^\w\-.]', '_', r["source_name"].replace(".zip", ""))
                            st.download_button(
                                label=f"Download HTML",
                                data=ind_html,
                                file_name=f"code_lens_{safe_name}.html",
                                mime="text/html",
                                use_container_width=True,
                                key=f"html_{idx}",
                            )
                        with ind_col2:
                            ind_excel = generate_excel_report(
                                r["endpoints"],
                                r["language"] or "Unknown",
                                r["scanned_files"],
                                r["total_files"],
                                source_name=r["source_name"],
                            )
                            st.download_button(
                                label=f"Download Excel",
                                data=ind_excel,
                                file_name=f"code_lens_{safe_name}.xlsx",
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                use_container_width=True,
                                key=f"excel_{idx}",
                            )

            st.markdown("---")
            st.markdown("**Data Preview:**")
            preview_data = []
            for r in all_results:
                for ep in r["endpoints"]:
                    row = {
                        "API Type": ep.api_type,
                        "Method": ep.http_method,
                        "URL": ep.url,
                        "Function": ep.function_name,
                        "File": ep.file_path,
                        "Line": ep.line_number,
                        "Excel Match": "Yes" if (ep.matched_excel_url or ep.matched_excel_path) else "No",
                    }
                    if is_multi:
                        row["Source"] = r["source_name"]
                    preview_data.append(row)
            st.dataframe(pd.DataFrame(preview_data), use_container_width=True, hide_index=True)

else:
    st.markdown("---")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown(
            """
            ### Step 1: Upload Excel
            Upload your Excel file containing `url_details`
            and `path_details` columns that list the APIs
            used in your application.
            """
        )
    with col2:
        st.markdown(
            """
            ### Step 2: Provide Source Code
            Upload one or more ZIP archives or paste a Git
            repository URL of your Java or C# project.
            The scanner will analyze all relevant files.
            """
        )
    with col3:
        st.markdown(
            """
            ### Step 3: Scan & Analyze
            Click "Scan Application" to discover REST, SOAP,
            and OneData API endpoints. View results, matches,
            and flow diagrams.
            """
        )

    st.markdown("---")
    st.markdown(
        """
        #### Supported Detection
        | Type | Java | C# |
        |------|------|----|
        | REST | Spring MVC, JAX-RS | ASP.NET Core |
        | SOAP | JAX-WS, WSDL | WCF, ASMX |
        | OneData | Function calls | Function calls |
        """
    )
