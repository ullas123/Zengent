import base64
import html
import io
import os
import tempfile
from datetime import datetime

import pandas as pd


def _esc(text):
    return html.escape(str(text)) if text else ""


def _encode_image_base64(image_path):
    if image_path and os.path.exists(image_path):
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
    return None


def generate_html_report(endpoints, language, scanned_files, total_files, diagram_images=None, source_name=""):
    rest_count = sum(1 for e in endpoints if e.api_type == "REST")
    soap_count = sum(1 for e in endpoints if e.api_type == "SOAP")
    onedata_count = sum(1 for e in endpoints if e.api_type == "OneData")
    matched_count = sum(1 for e in endpoints if e.matched_excel_url or e.matched_excel_path)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    source_display = _esc(source_name) if source_name else "Unknown Source"

    diagram_html_sections = ""
    if diagram_images:
        for title, img_path in diagram_images.items():
            b64 = _encode_image_base64(img_path)
            if b64:
                diagram_html_sections += f"""
                <div class="diagram-section">
                    <h3>{title}</h3>
                    <img src="data:image/png;base64,{b64}" alt="{title}" />
                </div>
                """

    matched_eps = [e for e in endpoints if e.matched_excel_url or e.matched_excel_path]
    unmatched_eps = [e for e in endpoints if not e.matched_excel_url and not e.matched_excel_path]

    endpoint_rows = ""
    for ep in endpoints:
        match_class = "matched" if (ep.matched_excel_url or ep.matched_excel_path) else ""
        type_class = f"type-{_esc(ep.api_type).lower()}"

        endpoint_rows += f"""
        <tr class="{match_class}">
            <td><span class="badge {type_class}">{_esc(ep.api_type)}</span></td>
            <td><span class="method">{_esc(ep.http_method)}</span></td>
            <td class="url-cell">{_esc(ep.url)}</td>
            <td>{_esc(ep.function_name)}</td>
            <td>{_esc(os.path.basename(ep.file_path))}</td>
            <td>{ep.line_number}</td>
            <td>{_esc(ep.request_details)}</td>
            <td>{_esc(ep.response_details)}</td>
            <td>{_esc(ep.matched_excel_url)}</td>
            <td>{_esc(ep.matched_excel_path)}</td>
        </tr>
        """

    detail_cards = ""
    for ep in endpoints:
        match_badge = ""
        if ep.matched_excel_url:
            match_badge += f'<div class="match-info">Matched Excel URL: {_esc(ep.matched_excel_url)}</div>'
        if ep.matched_excel_path:
            match_badge += f'<div class="match-info">Matched Excel Path: {_esc(ep.matched_excel_path)}</div>'

        snippet_html = ""
        if ep.code_snippet:
            snippet_html = f"""
            <div class="detail-row">
                <strong>Code Context:</strong>
                <pre class="code-snippet">{_esc(ep.code_snippet)}</pre>
            </div>
            """

        type_class = f"type-{_esc(ep.api_type).lower()}"
        detail_cards += f"""
        <div class="detail-card">
            <div class="detail-header">
                <span class="badge {type_class}">{_esc(ep.api_type)}</span>
                <span class="method">{_esc(ep.http_method)}</span>
                <strong>{_esc(ep.function_name)}</strong>
                <span class="line-info">Line {ep.line_number}</span>
            </div>
            <div class="detail-body">
                <div class="detail-row"><strong>Endpoint URL:</strong> <code>{_esc(ep.url)}</code></div>
                <div class="detail-row"><strong>File:</strong> <code>{_esc(ep.file_path)}</code></div>
                <div class="detail-row"><strong>Request:</strong> {_esc(ep.request_details)}</div>
                <div class="detail-row"><strong>Response:</strong> {_esc(ep.response_details)}</div>
                {match_badge}
                {snippet_html}
            </div>
        </div>
        """

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Lens - API Scan Report</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f0f2f5; color: #333; line-height: 1.6; }}
        .container {{ max-width: 1400px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); padding: 30px; border-radius: 12px; text-align: center; margin-bottom: 24px; }}
        .header h1 {{ color: #e94560; font-size: 2rem; margin-bottom: 6px; }}
        .header p {{ color: #a8b2d1; font-size: 0.95rem; }}
        .header .timestamp {{ color: #6c7a9a; font-size: 0.8rem; margin-top: 8px; }}
        .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 16px; margin-bottom: 24px; }}
        .stat-card {{ background: #fff; border: 1px solid #e0e0e0; border-radius: 10px; padding: 18px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }}
        .stat-card h3 {{ font-size: 2rem; color: #1a1a2e; margin: 0; }}
        .stat-card p {{ color: #6c757d; margin: 0; font-size: 0.85rem; }}
        .stat-rest {{ border-left: 4px solid #28a745; }}
        .stat-soap {{ border-left: 4px solid #17a2b8; }}
        .stat-onedata {{ border-left: 4px solid #ffc107; }}
        .stat-matched {{ border-left: 4px solid #e94560; }}
        .section {{ background: #fff; border-radius: 10px; padding: 24px; margin-bottom: 24px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }}
        .section h2 {{ color: #1a1a2e; border-bottom: 3px solid #e94560; padding-bottom: 8px; margin-bottom: 16px; font-size: 1.3rem; }}
        table {{ width: 100%; border-collapse: collapse; font-size: 0.85rem; }}
        th {{ background: #1a1a2e; color: white; padding: 10px 8px; text-align: left; font-weight: 600; position: sticky; top: 0; }}
        td {{ padding: 8px; border-bottom: 1px solid #eee; vertical-align: top; }}
        tr:hover {{ background: #f8f9fa; }}
        tr.matched {{ background: #f0fff0; }}
        .badge {{ display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 0.75rem; font-weight: 600; }}
        .type-rest {{ background: #d4edda; color: #155724; }}
        .type-soap {{ background: #d1ecf1; color: #0c5460; }}
        .type-onedata {{ background: #fff3cd; color: #856404; }}
        .method {{ display: inline-block; background: #e8e8e8; padding: 2px 8px; border-radius: 4px; font-family: monospace; font-size: 0.8rem; font-weight: 600; }}
        .url-cell {{ font-family: monospace; font-size: 0.8rem; word-break: break-all; max-width: 250px; }}
        .file-cell {{ font-family: monospace; font-size: 0.78rem; word-break: break-all; max-width: 200px; }}
        .code-snippet {{ background: #282c34; color: #abb2bf; padding: 12px; border-radius: 6px; font-size: 0.8rem; overflow-x: auto; white-space: pre-wrap; word-wrap: break-word; margin-top: 6px; }}
        .detail-card {{ border: 1px solid #e0e0e0; border-radius: 8px; margin-bottom: 12px; overflow: hidden; }}
        .detail-header {{ background: #f8f9fa; padding: 10px 16px; border-bottom: 1px solid #e0e0e0; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }}
        .detail-body {{ padding: 16px; }}
        .detail-row {{ margin-bottom: 8px; }}
        .detail-row code {{ background: #f0f0f0; padding: 2px 6px; border-radius: 4px; font-size: 0.85rem; }}
        .line-info {{ color: #6c757d; font-size: 0.8rem; }}
        .match-info {{ background: #d4edda; color: #155724; padding: 6px 12px; border-radius: 6px; margin-top: 6px; font-size: 0.85rem; }}
        .diagram-section {{ margin-bottom: 24px; text-align: center; }}
        .diagram-section h3 {{ margin-bottom: 12px; color: #1a1a2e; }}
        .diagram-section img {{ max-width: 100%; height: auto; border: 1px solid #e0e0e0; border-radius: 8px; }}
        .footer {{ text-align: center; color: #999; font-size: 0.8rem; padding: 20px; }}
        @media print {{
            body {{ background: white; }}
            .container {{ max-width: 100%; padding: 10px; }}
            .section {{ box-shadow: none; border: 1px solid #ddd; page-break-inside: avoid; }}
            .diagram-section {{ page-break-before: always; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Code Lens - API Scan Report</h1>
            <p style="font-size:1.1rem; color:#e0e0e0; margin-bottom:4px;">{source_display}</p>
            <p>Automated API Endpoint Detection for {language} Application</p>
            <div class="timestamp">Generated: {timestamp} | Files Scanned: {scanned_files} / {total_files}</div>
        </div>

        <div class="stats">
            <div class="stat-card"><h3>{len(endpoints)}</h3><p>Total APIs</p></div>
            <div class="stat-card stat-rest"><h3>{rest_count}</h3><p>REST APIs</p></div>
            <div class="stat-card stat-soap"><h3>{soap_count}</h3><p>SOAP APIs</p></div>
            <div class="stat-card stat-onedata"><h3>{onedata_count}</h3><p>OneData</p></div>
            <div class="stat-card stat-matched"><h3>{matched_count}</h3><p>Excel Matched</p></div>
            <div class="stat-card"><h3>{language}</h3><p>Language</p></div>
        </div>

        <div class="section">
            <h2>All Discovered API Endpoints</h2>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>API Type</th>
                            <th>Method</th>
                            <th>URL / Endpoint</th>
                            <th>Function</th>
                            <th>File</th>
                            <th>Line</th>
                            <th>Request</th>
                            <th>Response</th>
                            <th>Matched URL</th>
                            <th>Matched Path</th>
                        </tr>
                    </thead>
                    <tbody>
                        {endpoint_rows}
                    </tbody>
                </table>
            </div>
        </div>

        <div class="section">
            <h2>Excel Match Summary</h2>
            <p><strong>Matched:</strong> {len(matched_eps)} endpoints &nbsp;|&nbsp; <strong>Unmatched:</strong> {len(unmatched_eps)} endpoints</p>
        </div>

        <div class="section">
            <h2>Detailed API View</h2>
            {detail_cards}
        </div>

        {"<div class='section'><h2>API Flow Diagrams</h2>" + diagram_html_sections + "</div>" if diagram_html_sections else "<div class='section'><h2>API Flow Diagrams</h2><p style='color:#999;'>Diagrams could not be generated. Ensure Graphviz is installed on the system.</p></div>"}

        <div class="footer">
            Code Lens - API Scan Report | Generated on {timestamp}
        </div>
    </div>
</body>
</html>"""
    return html


def generate_excel_report(endpoints, language, scanned_files, total_files, source_name=""):
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        all_data = []
        for ep in endpoints:
            all_data.append({
                "API Type": ep.api_type,
                "HTTP Method": ep.http_method,
                "URL / Endpoint": ep.url,
                "Function Name": ep.function_name,
                "File Path": ep.file_path,
                "Line Number": ep.line_number,
                "Request Details": ep.request_details,
                "Response Details": ep.response_details,
                "Matched Excel URL": ep.matched_excel_url,
                "Matched Excel Path": ep.matched_excel_path,
                "Code Snippet": ep.code_snippet,
            })
        df_all = pd.DataFrame(all_data)
        df_all.to_excel(writer, sheet_name="All Endpoints", index=False)

        matched_data = []
        for ep in endpoints:
            if ep.matched_excel_url or ep.matched_excel_path:
                matched_data.append({
                    "API Type": ep.api_type,
                    "HTTP Method": ep.http_method,
                    "URL / Endpoint": ep.url,
                    "Function Name": ep.function_name,
                    "File Path": ep.file_path,
                    "Line Number": ep.line_number,
                    "Matched Excel URL": ep.matched_excel_url,
                    "Matched Excel Path": ep.matched_excel_path,
                })
        if matched_data:
            pd.DataFrame(matched_data).to_excel(writer, sheet_name="Matched Endpoints", index=False)

        unmatched_data = []
        for ep in endpoints:
            if not ep.matched_excel_url and not ep.matched_excel_path:
                unmatched_data.append({
                    "API Type": ep.api_type,
                    "HTTP Method": ep.http_method,
                    "URL / Endpoint": ep.url,
                    "Function Name": ep.function_name,
                    "File Path": ep.file_path,
                    "Line Number": ep.line_number,
                })
        if unmatched_data:
            pd.DataFrame(unmatched_data).to_excel(writer, sheet_name="Unmatched Endpoints", index=False)

        rest_count = sum(1 for e in endpoints if e.api_type == "REST")
        soap_count = sum(1 for e in endpoints if e.api_type == "SOAP")
        onedata_count = sum(1 for e in endpoints if e.api_type == "OneData")
        matched_count = len(matched_data)

        summary = pd.DataFrame([
            {"Metric": "Source", "Value": source_name or "Unknown"},
            {"Metric": "Language", "Value": language},
            {"Metric": "Total Files", "Value": total_files},
            {"Metric": "Scanned Files", "Value": scanned_files},
            {"Metric": "Total API Endpoints", "Value": len(endpoints)},
            {"Metric": "REST APIs", "Value": rest_count},
            {"Metric": "SOAP APIs", "Value": soap_count},
            {"Metric": "OneData Functions", "Value": onedata_count},
            {"Metric": "Excel Matched", "Value": matched_count},
            {"Metric": "Unmatched", "Value": len(endpoints) - matched_count},
            {"Metric": "Report Generated", "Value": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
        ])
        summary.to_excel(writer, sheet_name="Summary", index=False)

    output.seek(0)
    return output.getvalue()
