import base64
import html
import io
import os
import tempfile
from datetime import datetime

import pandas as pd


def _esc(text):
    return html.escape(str(text)) if text else ""


def _encode_image_base64(image_path):
    if image_path and os.path.exists(image_path):
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
    return None


SOR_TABLES = [
    "Globestar", "Triumph", "CARS", "MNS", "CARE",
    "APAR", "Anagrafe", "Income SOR", "DIG/DCP",
]


def _sor_analysis_section_html(endpoints, title="SOR / Source of Record Table Analysis"):
    """Builds an HTML section showing which APIs reference each SOR table."""
    from collections import defaultdict

    # Map SOR table → list of endpoints referencing it
    sor_map = defaultdict(list)
    for e in endpoints:
        if e.sor_tables:
            for t in [s.strip() for s in e.sor_tables.split(",") if s.strip()]:
                sor_map[t].append(e)

    # Overall SOR hit stats
    apis_with_sor = sum(1 for e in endpoints if e.sor_tables)
    if not sor_map:
        summary_note = "<p style='color:#999'>No SOR table references detected in the scanned codebase.</p>"
        detail_rows = ""
    else:
        summary_note = f"""
        <p style="margin-bottom:14px;color:#555;">
            <strong>{apis_with_sor}</strong> API endpoint(s) reference at least one SOR table.
            <strong>{len(sor_map)}</strong> distinct SOR table(s) detected.
        </p>"""

        # Summary table: SOR table → count
        summary_rows = ""
        for tname in SOR_TABLES:
            eps = sor_map.get(tname, [])
            count = len(eps)
            api_types = ", ".join(sorted(set(e.api_type for e in eps))) if eps else "—"
            funcs = ", ".join(sorted(set(e.function_name for e in eps))[:5]) if eps else "—"
            badge_color = "#d4edda" if count > 0 else "#f8f9fa"
            txt_color = "#155724" if count > 0 else "#999"
            summary_rows += f"""<tr>
                <td><strong>{_esc(tname)}</strong></td>
                <td style="text-align:center"><span style="background:{badge_color};color:{txt_color};
                    padding:3px 10px;border-radius:10px;font-weight:700">{count}</span></td>
                <td style="font-size:0.8rem;color:#555">{_esc(api_types)}</td>
                <td style="font-size:0.78rem;color:#555">{_esc(funcs)}</td>
            </tr>"""

        detail_rows = f"""
        <h3 style="margin:20px 0 10px;color:#1a1a2e;">By SOR Table</h3>
        <div style="overflow-x:auto;">
        <table>
            <thead><tr>
                <th style="background:#4a235a;">SOR Table</th>
                <th style="background:#4a235a;">API Count</th>
                <th style="background:#4a235a;">API Types</th>
                <th style="background:#4a235a;">Functions (sample)</th>
            </tr></thead>
            <tbody>{summary_rows}</tbody>
        </table>
        </div>"""

    return f"""
    <div class="section" style="border-left:5px solid #9b59b6;">
        <h2 style="color:#4a235a;">&#128204; {title}</h2>
        {summary_note}
        {detail_rows}
    </div>"""


def _onedata_version_section_html(endpoints, title="OneData Version Function Occurrences"):
    """Builds an HTML section showing OneData .v1/.v2/.v3/.v4 function occurrences and counts."""
    from collections import defaultdict
    import re as _re

    version_eps = [
        e for e in endpoints
        if e.api_type == "OneData" and _re.search(r'v[1-4]', e.http_method or "")
    ]
    if not version_eps:
        return ""

    # Group: function_name × version_prefix × file → count + occurrences list
    func_agg = defaultdict(lambda: {"count": 0, "files": set(), "version": "", "occurrences": []})
    for e in version_eps:
        key = (e.function_name, e.http_method)
        d = func_agg[key]
        d["count"] += 1
        d["version"] = e.http_method
        d["files"].add(os.path.basename(e.file_path))
        d["occurrences"].append({"file": e.file_path, "line": e.line_number, "source": getattr(e, "source_name", "")})

    rows_html = ""
    for (fn, ver) in sorted(func_agg.keys()):
        d = func_agg[(fn, ver)]
        files_str = ", ".join(sorted(d["files"]))
        badge_color = "#e8f5e9" if "sor" in ver else "#e3f2fd"
        txt_color = "#1b5e20" if "sor" in ver else "#0d47a1"
        rows_html += f"""<tr>
            <td><span style="background:{badge_color};color:{txt_color};padding:2px 8px;border-radius:10px;font-size:0.78rem;font-weight:600">{_esc(ver)}</span></td>
            <td><strong>{_esc(fn)}</strong></td>
            <td style="text-align:center;font-size:1rem;font-weight:700;color:#0f3460">{d["count"]}</td>
            <td style="font-size:0.78rem;color:#555">{_esc(files_str)}</td>
        </tr>"""

    total_occurrences = sum(d["count"] for d in func_agg.values())
    unique_funcs = len(func_agg)

    return f"""
    <div class="section" style="border-left:5px solid #ffc107;">
        <h2 style="color:#856404;">&#9889; {title}</h2>
        <p style="margin-bottom:14px;color:#555;">
            Found <strong>{unique_funcs}</strong> unique OneData version function(s) with
            <strong>{total_occurrences}</strong> total occurrence(s) across the codebase.
        </p>
        <div style="overflow-x:auto;">
        <table>
            <thead><tr>
                <th style="background:#856404;">Version Prefix</th>
                <th style="background:#856404;">Function Name</th>
                <th style="background:#856404;">Occurrences</th>
                <th style="background:#856404;">File(s)</th>
            </tr></thead>
            <tbody>{rows_html}</tbody>
        </table>
        </div>
    </div>"""


def generate_html_report(endpoints, language, scanned_files, total_files, diagram_images=None, source_name=""):
    rest_count = sum(1 for e in endpoints if e.api_type == "REST")
    soap_count = sum(1 for e in endpoints if e.api_type == "SOAP")
    onedata_count = sum(1 for e in endpoints if e.api_type == "OneData")
    matched_count = sum(1 for e in endpoints if e.matched_excel_url or e.matched_excel_path)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    source_display = _esc(source_name) if source_name else "Unknown Source"

    diagram_html_sections = ""
    if diagram_images:
        for title, img_path in diagram_images.items():
            b64 = _encode_image_base64(img_path)
            if b64:
                diagram_html_sections += f"""
                <div class="diagram-section">
                    <h3>{title}</h3>
                    <img src="data:image/png;base64,{b64}" alt="{title}" />
                </div>
                """

    matched_eps = [e for e in endpoints if e.matched_excel_url or e.matched_excel_path]
    unmatched_eps = [e for e in endpoints if not e.matched_excel_url and not e.matched_excel_path]

    endpoint_rows = ""
    for ep in endpoints:
        match_class = "matched" if (ep.matched_excel_url or ep.matched_excel_path) else ""
        type_class = f"type-{_esc(ep.api_type).lower()}"
        sor_val = getattr(ep, "sor_tables", "") or ""
        sor_cell = ""
        for t in [s.strip() for s in sor_val.split(",") if s.strip()]:
            sor_cell += f'<span style="background:#ede7f6;color:#4a235a;padding:1px 6px;border-radius:8px;font-size:0.72rem;font-weight:600;margin:1px;display:inline-block">{_esc(t)}</span>'

        endpoint_rows += f"""
        <tr class="{match_class}">
            <td><span class="badge {type_class}">{_esc(ep.api_type)}</span></td>
            <td><span class="method">{_esc(ep.http_method)}</span></td>
            <td class="url-cell">{_esc(ep.url)}</td>
            <td>{_esc(ep.function_name)}</td>
            <td>{_esc(os.path.basename(ep.file_path))}</td>
            <td>{ep.line_number}</td>
            <td>{_esc(ep.request_details)}</td>
            <td>{_esc(ep.response_details)}</td>
            <td>{_esc(ep.matched_excel_url)}</td>
            <td>{_esc(ep.matched_excel_path)}</td>
            <td>{sor_cell if sor_cell else '<span style="color:#ccc">—</span>'}</td>
        </tr>
        """

    detail_cards = ""
    for ep in endpoints:
        match_badge = ""
        if ep.matched_excel_url:
            match_badge += f'<div class="match-info">Matched Excel URL: {_esc(ep.matched_excel_url)}</div>'
        if ep.matched_excel_path:
            match_badge += f'<div class="match-info">Matched Excel Path: {_esc(ep.matched_excel_path)}</div>'

        snippet_html = ""
        if ep.code_snippet:
            snippet_html = f"""
            <div class="detail-row">
                <strong>Code Context:</strong>
                <pre class="code-snippet">{_esc(ep.code_snippet)}</pre>
            </div>
            """

        sor_val = getattr(ep, "sor_tables", "") or ""
        sor_badge_html = ""
        if sor_val:
            pills = "".join(
                f'<span style="background:#ede7f6;color:#4a235a;padding:2px 8px;border-radius:10px;font-size:0.75rem;font-weight:600;margin:2px;display:inline-block">{_esc(t.strip())}</span>'
                for t in sor_val.split(",") if t.strip()
            )
            sor_badge_html = f'<div class="detail-row"><strong>&#128204; SOR Tables:</strong> {pills}</div>'

        type_class = f"type-{_esc(ep.api_type).lower()}"
        detail_cards += f"""
        <div class="detail-card">
            <div class="detail-header">
                <span class="badge {type_class}">{_esc(ep.api_type)}</span>
                <span class="method">{_esc(ep.http_method)}</span>
                <strong>{_esc(ep.function_name)}</strong>
                <span class="line-info">Line {ep.line_number}</span>
            </div>
            <div class="detail-body">
                <div class="detail-row"><strong>Endpoint URL:</strong> <code>{_esc(ep.url)}</code></div>
                <div class="detail-row"><strong>File:</strong> <code>{_esc(ep.file_path)}</code></div>
                <div class="detail-row"><strong>Request:</strong> {_esc(ep.request_details)}</div>
                <div class="detail-row"><strong>Response:</strong> {_esc(ep.response_details)}</div>
                {sor_badge_html}
                {match_badge}
                {snippet_html}
            </div>
        </div>
        """

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Lens - API Scan Report</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f0f2f5; color: #333; line-height: 1.6; }}
        .container {{ max-width: 1400px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); padding: 30px; border-radius: 12px; text-align: center; margin-bottom: 24px; }}
        .header h1 {{ color: #e94560; font-size: 2rem; margin-bottom: 6px; }}
        .header p {{ color: #a8b2d1; font-size: 0.95rem; }}
        .header .timestamp {{ color: #6c7a9a; font-size: 0.8rem; margin-top: 8px; }}
        .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 16px; margin-bottom: 24px; }}
        .stat-card {{ background: #fff; border: 1px solid #e0e0e0; border-radius: 10px; padding: 18px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }}
        .stat-card h3 {{ font-size: 2rem; color: #1a1a2e; margin: 0; }}
        .stat-card p {{ color: #6c757d; margin: 0; font-size: 0.85rem; }}
        .stat-rest {{ border-left: 4px solid #28a745; }}
        .stat-soap {{ border-left: 4px solid #17a2b8; }}
        .stat-onedata {{ border-left: 4px solid #ffc107; }}
        .stat-matched {{ border-left: 4px solid #e94560; }}
        .section {{ background: #fff; border-radius: 10px; padding: 24px; margin-bottom: 24px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }}
        .section h2 {{ color: #1a1a2e; border-bottom: 3px solid #e94560; padding-bottom: 8px; margin-bottom: 16px; font-size: 1.3rem; }}
        table {{ width: 100%; border-collapse: collapse; font-size: 0.85rem; }}
        th {{ background: #1a1a2e; color: white; padding: 10px 8px; text-align: left; font-weight: 600; position: sticky; top: 0; }}
        td {{ padding: 8px; border-bottom: 1px solid #eee; vertical-align: top; }}
        tr:hover {{ background: #f8f9fa; }}
        tr.matched {{ background: #f0fff0; }}
        .badge {{ display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 0.75rem; font-weight: 600; }}
        .type-rest {{ background: #d4edda; color: #155724; }}
        .type-soap {{ background: #d1ecf1; color: #0c5460; }}
        .type-onedata {{ background: #fff3cd; color: #856404; }}
        .method {{ display: inline-block; background: #e8e8e8; padding: 2px 8px; border-radius: 4px; font-family: monospace; font-size: 0.8rem; font-weight: 600; }}
        .url-cell {{ font-family: monospace; font-size: 0.8rem; word-break: break-all; max-width: 250px; }}
        .file-cell {{ font-family: monospace; font-size: 0.78rem; word-break: break-all; max-width: 200px; }}
        .code-snippet {{ background: #282c34; color: #abb2bf; padding: 12px; border-radius: 6px; font-size: 0.8rem; overflow-x: auto; white-space: pre-wrap; word-wrap: break-word; margin-top: 6px; }}
        .detail-card {{ border: 1px solid #e0e0e0; border-radius: 8px; margin-bottom: 12px; overflow: hidden; }}
        .detail-header {{ background: #f8f9fa; padding: 10px 16px; border-bottom: 1px solid #e0e0e0; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }}
        .detail-body {{ padding: 16px; }}
        .detail-row {{ margin-bottom: 8px; }}
        .detail-row code {{ background: #f0f0f0; padding: 2px 6px; border-radius: 4px; font-size: 0.85rem; }}
        .line-info {{ color: #6c757d; font-size: 0.8rem; }}
        .match-info {{ background: #d4edda; color: #155724; padding: 6px 12px; border-radius: 6px; margin-top: 6px; font-size: 0.85rem; }}
        .diagram-section {{ margin-bottom: 24px; text-align: center; }}
        .diagram-section h3 {{ margin-bottom: 12px; color: #1a1a2e; }}
        .diagram-section img {{ max-width: 100%; height: auto; border: 1px solid #e0e0e0; border-radius: 8px; }}
        .footer {{ text-align: center; color: #999; font-size: 0.8rem; padding: 20px; }}
        @media print {{
            body {{ background: white; }}
            .container {{ max-width: 100%; padding: 10px; }}
            .section {{ box-shadow: none; border: 1px solid #ddd; page-break-inside: avoid; }}
            .diagram-section {{ page-break-before: always; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Code Lens - API Scan Report</h1>
            <p style="font-size:1.1rem; color:#e0e0e0; margin-bottom:4px;">{source_display}</p>
            <p>Automated API Endpoint Detection for {language} Application</p>
            <div class="timestamp">Generated: {timestamp} | Files Scanned: {scanned_files} / {total_files}</div>
        </div>

        <div class="stats">
            <div class="stat-card"><h3>{len(endpoints)}</h3><p>Total APIs</p></div>
            <div class="stat-card stat-rest"><h3>{rest_count}</h3><p>REST APIs</p></div>
            <div class="stat-card stat-soap"><h3>{soap_count}</h3><p>SOAP APIs</p></div>
            <div class="stat-card stat-onedata"><h3>{onedata_count}</h3><p>OneData</p></div>
            <div class="stat-card stat-matched"><h3>{matched_count}</h3><p>Excel Matched</p></div>
            <div class="stat-card"><h3>{language}</h3><p>Language</p></div>
        </div>

        <div class="section">
            <h2>All Discovered API Endpoints</h2>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>API Type</th>
                            <th>Method</th>
                            <th>URL / Endpoint</th>
                            <th>Function</th>
                            <th>File</th>
                            <th>Line</th>
                            <th>Request</th>
                            <th>Response</th>
                            <th>Matched URL</th>
                            <th>Matched Path</th>
                            <th>SOR Tables</th>
                        </tr>
                    </thead>
                    <tbody>
                        {endpoint_rows}
                    </tbody>
                </table>
            </div>
        </div>

        <div class="section">
            <h2>Excel Match Summary</h2>
            <p><strong>Matched:</strong> {len(matched_eps)} endpoints &nbsp;|&nbsp; <strong>Unmatched:</strong> {len(unmatched_eps)} endpoints</p>
        </div>

        {_sor_analysis_section_html(endpoints)}
        {_onedata_version_section_html(endpoints)}

        <div class="section">
            <h2>Detailed API View</h2>
            {detail_cards}
        </div>

        {"<div class='section'><h2>API Flow Diagrams</h2>" + diagram_html_sections + "</div>" if diagram_html_sections else "<div class='section'><h2>API Flow Diagrams</h2><p style='color:#999;'>Diagrams could not be generated. Ensure Graphviz is installed on the system.</p></div>"}

        <div class="footer">
            Code Lens - API Scan Report | Generated on {timestamp}
        </div>
    </div>
</body>
</html>"""
    return html


def generate_multi_repo_html_report(all_results, language, total_scanned, total_total, overview_diagrams=None, per_repo_diagrams=None):
    """
    Generates one self-contained HTML report covering all repos:
    - Overall summary statistics & analysis (by repo, function, API type)
    - One dedicated section per repo with its own stats, endpoint table, and detail cards
    - Embedded diagrams (overall + per-repo)
    """
    from collections import defaultdict

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    all_endpoints = [ep for r in all_results for ep in r["endpoints"]]

    total_apis    = len(all_endpoints)
    rest_total    = sum(1 for e in all_endpoints if e.api_type == "REST")
    soap_total    = sum(1 for e in all_endpoints if e.api_type == "SOAP")
    od_total      = sum(1 for e in all_endpoints if e.api_type == "OneData")
    matched_total = sum(1 for e in all_endpoints if e.matched_excel_url or e.matched_excel_path)
    unmatched_total = total_apis - matched_total
    num_repos     = len(all_results)

    # ── shared CSS ──────────────────────────────────────────────────────────
    css = """
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; background:#f0f2f5; color:#333; line-height:1.6; }
        a { color:#e94560; text-decoration:none; }
        a:hover { text-decoration:underline; }
        .container { max-width:1400px; margin:0 auto; padding:20px; }
        /* header */
        .header { background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%); padding:30px; border-radius:12px; text-align:center; margin-bottom:24px; }
        .header h1 { color:#e94560; font-size:2rem; margin-bottom:6px; }
        .header p  { color:#a8b2d1; font-size:0.95rem; }
        .header .timestamp { color:#6c7a9a; font-size:0.8rem; margin-top:8px; }
        /* toc */
        .toc { background:#fff; border-radius:10px; padding:20px 28px; margin-bottom:24px; box-shadow:0 2px 4px rgba(0,0,0,.05); }
        .toc h2 { color:#1a1a2e; margin-bottom:12px; font-size:1.1rem; border-bottom:2px solid #e94560; padding-bottom:6px; }
        .toc ul { list-style:none; column-count:2; column-gap:24px; }
        .toc ul li { padding:3px 0; font-size:0.88rem; }
        .toc ul li::before { content:"▸ "; color:#e94560; }
        /* stat cards */
        .stats { display:grid; grid-template-columns:repeat(auto-fit,minmax(130px,1fr)); gap:14px; margin-bottom:24px; }
        .stat-card { background:#fff; border:1px solid #e0e0e0; border-radius:10px; padding:16px; text-align:center; box-shadow:0 2px 4px rgba(0,0,0,.05); }
        .stat-card h3 { font-size:1.8rem; color:#1a1a2e; margin:0; }
        .stat-card p  { color:#6c757d; margin:0; font-size:0.82rem; }
        .stat-rest     { border-left:4px solid #28a745; }
        .stat-soap     { border-left:4px solid #17a2b8; }
        .stat-onedata  { border-left:4px solid #ffc107; }
        .stat-matched  { border-left:4px solid #e94560; }
        .stat-unmatched{ border-left:4px solid #dc3545; }
        /* section */
        .section { background:#fff; border-radius:10px; padding:24px; margin-bottom:24px; box-shadow:0 2px 4px rgba(0,0,0,.05); }
        .section h2 { color:#1a1a2e; border-bottom:3px solid #e94560; padding-bottom:8px; margin-bottom:16px; font-size:1.25rem; }
        .section h3 { color:#1a1a2e; margin:16px 0 10px; font-size:1rem; }
        /* repo section */
        .repo-section { background:#fff; border-radius:10px; padding:24px; margin-bottom:32px; box-shadow:0 3px 8px rgba(0,0,0,.08); border-top:5px solid #e94560; }
        .repo-section h2 { color:#0f3460; border-bottom:2px solid #e0e0e0; padding-bottom:8px; margin-bottom:16px; font-size:1.2rem; }
        /* table */
        table { width:100%; border-collapse:collapse; font-size:0.83rem; }
        th { background:#1a1a2e; color:#fff; padding:9px 8px; text-align:left; font-weight:600; }
        td { padding:7px 8px; border-bottom:1px solid #eee; vertical-align:top; }
        tr:hover { background:#f8f9fa; }
        tr.matched { background:#f0fff0; }
        /* analysis table */
        .analysis-table th { background:#0f3460; }
        .analysis-table tr:nth-child(even) { background:#f8f9fa; }
        /* badges */
        .badge { display:inline-block; padding:2px 9px; border-radius:12px; font-size:0.73rem; font-weight:600; }
        .type-rest     { background:#d4edda; color:#155724; }
        .type-soap     { background:#d1ecf1; color:#0c5460; }
        .type-onedata  { background:#fff3cd; color:#856404; }
        .method { display:inline-block; background:#e8e8e8; padding:2px 7px; border-radius:4px; font-family:monospace; font-size:0.78rem; font-weight:600; }
        .url-cell { font-family:monospace; font-size:0.78rem; word-break:break-all; max-width:240px; }
        .match-yes { color:#155724; font-weight:600; }
        .match-no  { color:#721c24; }
        /* detail cards */
        .detail-card { border:1px solid #e0e0e0; border-radius:8px; margin-bottom:10px; overflow:hidden; }
        .detail-header { background:#f8f9fa; padding:9px 14px; border-bottom:1px solid #e0e0e0; display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
        .detail-body { padding:14px; }
        .detail-row { margin-bottom:7px; }
        .detail-row code { background:#f0f0f0; padding:2px 5px; border-radius:4px; font-size:0.82rem; }
        .line-info { color:#6c757d; font-size:0.78rem; }
        .match-info { background:#d4edda; color:#155724; padding:5px 10px; border-radius:5px; margin-top:5px; font-size:0.82rem; }
        .code-snippet { background:#282c34; color:#abb2bf; padding:10px; border-radius:6px; font-size:0.78rem; overflow-x:auto; white-space:pre-wrap; word-wrap:break-word; margin-top:5px; }
        /* diagrams */
        .diagram-section { margin-bottom:20px; text-align:center; }
        .diagram-section h3 { margin-bottom:10px; color:#1a1a2e; }
        .diagram-section img { max-width:100%; height:auto; border:1px solid #e0e0e0; border-radius:8px; }
        /* progress bar */
        .progress-wrap { background:#e9ecef; border-radius:6px; height:14px; overflow:hidden; margin:4px 0 10px; }
        .progress-bar  { height:14px; border-radius:6px; font-size:0.7rem; line-height:14px; color:#fff; padding:0 6px; white-space:nowrap; }
        .bar-matched   { background:#28a745; }
        .bar-unmatched { background:#dc3545; }
        /* footer */
        .footer { text-align:center; color:#999; font-size:0.78rem; padding:20px; }
        @media print {
            body { background:white; }
            .container { max-width:100%; padding:10px; }
            .section, .repo-section { box-shadow:none; border:1px solid #ddd; page-break-inside:avoid; }
            .diagram-section { page-break-before:always; }
        }
    """

    # ── Table of Contents ────────────────────────────────────────────────────
    toc_items = '<li><a href="#overall-analysis">Overall Analysis</a></li>\n'
    toc_items += '<li><a href="#overall-diagrams">Overall Diagrams</a></li>\n'
    for idx, r in enumerate(all_results):
        safe_id = f"repo-{idx}"
        toc_items += f'<li><a href="#{safe_id}">{_esc(r["source_name"])}</a></li>\n'

    # ── Overall stat cards ───────────────────────────────────────────────────
    overall_stats_html = f"""
    <div class="stats">
        <div class="stat-card"><h3>{num_repos}</h3><p>Repos Scanned</p></div>
        <div class="stat-card"><h3>{total_apis}</h3><p>Total APIs</p></div>
        <div class="stat-card stat-rest"><h3>{rest_total}</h3><p>REST APIs</p></div>
        <div class="stat-card stat-soap"><h3>{soap_total}</h3><p>SOAP APIs</p></div>
        <div class="stat-card stat-onedata"><h3>{od_total}</h3><p>OneData</p></div>
        <div class="stat-card stat-matched"><h3>{matched_total}</h3><p>Matched</p></div>
        <div class="stat-card stat-unmatched"><h3>{unmatched_total}</h3><p>Unmatched</p></div>
    </div>"""

    # ── Analysis: By Repo ────────────────────────────────────────────────────
    repo_analysis_rows = ""
    for r in all_results:
        eps   = r["endpoints"]
        tot   = len(eps)
        mat   = sum(1 for e in eps if e.matched_excel_url or e.matched_excel_path)
        unm   = tot - mat
        rst   = sum(1 for e in eps if e.api_type == "REST")
        sop   = sum(1 for e in eps if e.api_type == "SOAP")
        od    = sum(1 for e in eps if e.api_type == "OneData")
        pct   = int(mat / tot * 100) if tot else 0
        bar   = f"""<div class="progress-wrap">
            <div class="progress-bar bar-matched" style="width:{pct}%;display:inline-block;">{pct}%</div>
        </div>""" if tot else ""
        repo_analysis_rows += f"""
        <tr>
            <td><strong>{_esc(r["source_name"])}</strong></td>
            <td style="text-align:center">{tot}</td>
            <td style="text-align:center;color:#155724;font-weight:600">{mat}</td>
            <td style="text-align:center;color:#721c24">{unm}</td>
            <td style="text-align:center">{rst}</td>
            <td style="text-align:center">{sop}</td>
            <td style="text-align:center">{od}</td>
            <td style="min-width:120px">{bar}</td>
        </tr>"""

    repo_analysis_html = f"""
    <table class="analysis-table">
        <thead><tr>
            <th>Repo / Source</th><th>Total</th><th>Matched</th><th>Unmatched</th>
            <th>REST</th><th>SOAP</th><th>OneData</th><th>Match Rate</th>
        </tr></thead>
        <tbody>{repo_analysis_rows}</tbody>
    </table>"""

    # ── Analysis: By Function (across all repos) ────────────────────────────
    func_data = defaultdict(lambda: {"Total":0,"Matched":0,"Unmatched":0,"REST":0,"SOAP":0,"OneData":0})
    for e in all_endpoints:
        fd = func_data[e.function_name]
        fd["Total"] += 1
        is_m = bool(e.matched_excel_url or e.matched_excel_path)
        fd["Matched"]   += int(is_m)
        fd["Unmatched"] += int(not is_m)
        fd[e.api_type]  = fd.get(e.api_type, 0) + 1
    func_rows_html = ""
    for fn in sorted(func_data):
        fd = func_data[fn]
        func_rows_html += f"""<tr>
            <td>{_esc(fn)}</td>
            <td style="text-align:center">{fd["Total"]}</td>
            <td style="text-align:center;color:#155724;font-weight:600">{fd["Matched"]}</td>
            <td style="text-align:center;color:#721c24">{fd["Unmatched"]}</td>
            <td style="text-align:center">{fd.get("REST",0)}</td>
            <td style="text-align:center">{fd.get("SOAP",0)}</td>
            <td style="text-align:center">{fd.get("OneData",0)}</td>
        </tr>"""
    func_analysis_html = f"""
    <table class="analysis-table">
        <thead><tr>
            <th>Function</th><th>Total</th><th>Matched</th><th>Unmatched</th>
            <th>REST</th><th>SOAP</th><th>OneData</th>
        </tr></thead>
        <tbody>{func_rows_html}</tbody>
    </table>"""

    # ── Analysis: By API Type & HTTP Method ──────────────────────────────────
    type_data = defaultdict(lambda: {"Total":0,"Matched":0,"Unmatched":0})
    for e in all_endpoints:
        key = (e.api_type, e.http_method)
        td = type_data[key]
        td["Total"] += 1
        is_m = bool(e.matched_excel_url or e.matched_excel_path)
        td["Matched"]   += int(is_m)
        td["Unmatched"] += int(not is_m)
    type_rows_html = ""
    for (at, hm) in sorted(type_data):
        td = type_data[(at, hm)]
        type_class = f"type-{at.lower()}"
        type_rows_html += f"""<tr>
            <td><span class="badge {type_class}">{_esc(at)}</span></td>
            <td><span class="method">{_esc(hm)}</span></td>
            <td style="text-align:center">{td["Total"]}</td>
            <td style="text-align:center;color:#155724;font-weight:600">{td["Matched"]}</td>
            <td style="text-align:center;color:#721c24">{td["Unmatched"]}</td>
        </tr>"""
    type_analysis_html = f"""
    <table class="analysis-table">
        <thead><tr>
            <th>API Type</th><th>HTTP Method</th><th>Total</th><th>Matched</th><th>Unmatched</th>
        </tr></thead>
        <tbody>{type_rows_html}</tbody>
    </table>"""

    # ── Function × Repo cross-tab ────────────────────────────────────────────
    cross_data = defaultdict(lambda: {"Total":0,"Matched":0,"Unmatched":0})
    for e in all_endpoints:
        key = (e.function_name, e.source_name)
        cd = cross_data[key]
        cd["Total"] += 1
        is_m = bool(e.matched_excel_url or e.matched_excel_path)
        cd["Matched"]   += int(is_m)
        cd["Unmatched"] += int(not is_m)
    cross_rows_html = ""
    for (fn, rn) in sorted(cross_data):
        cd = cross_data[(fn, rn)]
        cross_rows_html += f"""<tr>
            <td>{_esc(fn)}</td><td>{_esc(rn)}</td>
            <td style="text-align:center">{cd["Total"]}</td>
            <td style="text-align:center;color:#155724;font-weight:600">{cd["Matched"]}</td>
            <td style="text-align:center;color:#721c24">{cd["Unmatched"]}</td>
        </tr>"""
    cross_analysis_html = f"""
    <table class="analysis-table">
        <thead><tr>
            <th>Function</th><th>Repo / Source</th><th>Total</th><th>Matched</th><th>Unmatched</th>
        </tr></thead>
        <tbody>{cross_rows_html}</tbody>
    </table>"""

    # ── Overall diagrams ─────────────────────────────────────────────────────
    overview_diag_html = ""
    if overview_diagrams:
        for title, img_path in overview_diagrams.items():
            b64 = _encode_image_base64(img_path)
            if b64:
                overview_diag_html += f"""
                <div class="diagram-section">
                    <h3>{_esc(title)}</h3>
                    <img src="data:image/png;base64,{b64}" alt="{_esc(title)}" />
                </div>"""

    # ── Per-repo sections ────────────────────────────────────────────────────
    per_repo_html = ""
    per_repo_diagrams = per_repo_diagrams or {}

    for idx, r in enumerate(all_results):
        safe_id  = f"repo-{idx}"
        eps      = r["endpoints"]
        tot      = len(eps)
        mat      = sum(1 for e in eps if e.matched_excel_url or e.matched_excel_path)
        unm      = tot - mat
        rst      = sum(1 for e in eps if e.api_type == "REST")
        sop      = sum(1 for e in eps if e.api_type == "SOAP")
        od       = sum(1 for e in eps if e.api_type == "OneData")
        pct      = int(mat / tot * 100) if tot else 0

        # repo stat cards
        repo_stats = f"""
        <div class="stats" style="grid-template-columns:repeat(auto-fit,minmax(110px,1fr));margin-bottom:16px;">
            <div class="stat-card"><h3>{tot}</h3><p>Total APIs</p></div>
            <div class="stat-card stat-rest"><h3>{rst}</h3><p>REST</p></div>
            <div class="stat-card stat-soap"><h3>{sop}</h3><p>SOAP</p></div>
            <div class="stat-card stat-onedata"><h3>{od}</h3><p>OneData</p></div>
            <div class="stat-card stat-matched"><h3>{mat}</h3><p>Matched</p></div>
            <div class="stat-card stat-unmatched"><h3>{unm}</h3><p>Unmatched</p></div>
            <div class="stat-card"><h3>{pct}%</h3><p>Match Rate</p></div>
        </div>
        <p style="color:#666;font-size:0.85rem;margin-bottom:14px;">
            Language: <strong>{_esc(r.get("language","Unknown"))}</strong> &nbsp;|&nbsp;
            Files scanned: <strong>{r.get("scanned_files",0)}</strong> / {r.get("total_files",0)}
        </p>"""

        # endpoint table
        ep_rows = ""
        for ep in eps:
            match_class  = "matched" if (ep.matched_excel_url or ep.matched_excel_path) else ""
            type_class   = f"type-{_esc(ep.api_type).lower()}"
            matched_cell = f'<span class="match-yes">✔ Yes</span>' if (ep.matched_excel_url or ep.matched_excel_path) else '<span class="match-no">✘ No</span>'
            sor_val = getattr(ep, "sor_tables", "") or ""
            sor_cell = ""
            for t in [s.strip() for s in sor_val.split(",") if s.strip()]:
                sor_cell += f'<span style="background:#ede7f6;color:#4a235a;padding:1px 5px;border-radius:7px;font-size:0.7rem;font-weight:600;margin:1px;display:inline-block">{_esc(t)}</span>'
            ep_rows += f"""
            <tr class="{match_class}">
                <td><span class="badge {type_class}">{_esc(ep.api_type)}</span></td>
                <td><span class="method">{_esc(ep.http_method)}</span></td>
                <td class="url-cell">{_esc(ep.url)}</td>
                <td>{_esc(ep.function_name)}</td>
                <td style="font-family:monospace;font-size:0.75rem;word-break:break-all">{_esc(os.path.basename(ep.file_path))}</td>
                <td style="text-align:center">{ep.line_number}</td>
                <td style="font-size:0.78rem">{_esc(ep.request_details)}</td>
                <td style="font-size:0.78rem">{_esc(ep.response_details)}</td>
                <td>{matched_cell}</td>
                <td style="font-size:0.75rem">{_esc(ep.matched_excel_url or ep.matched_excel_path)}</td>
                <td>{sor_cell if sor_cell else '<span style="color:#ccc">—</span>'}</td>
            </tr>"""

        ep_table = f"""
        <div style="overflow-x:auto;">
        <table>
            <thead><tr>
                <th>Type</th><th>Method</th><th>URL / Endpoint</th>
                <th>Function</th><th>File</th><th>Line</th>
                <th>Request</th><th>Response</th><th>Matched</th><th>Match Ref</th>
                <th style="background:#4a235a;">SOR Tables</th>
            </tr></thead>
            <tbody>{ep_rows}</tbody>
        </table></div>"""

        # detail cards
        detail_cards = ""
        for ep in eps:
            match_badge = ""
            if ep.matched_excel_url:
                match_badge += f'<div class="match-info">Matched Excel URL: {_esc(ep.matched_excel_url)}</div>'
            if ep.matched_excel_path:
                match_badge += f'<div class="match-info">Matched Excel Path: {_esc(ep.matched_excel_path)}</div>'
            snippet_html = ""
            if ep.code_snippet:
                snippet_html = f'<div class="detail-row"><strong>Code Context:</strong><pre class="code-snippet">{_esc(ep.code_snippet)}</pre></div>'
            payload_html = ""
            if ep.payload_fields:
                payload_html = f'<div class="detail-row"><strong>Payload Fields:</strong><pre class="code-snippet">{_esc(ep.payload_fields)}</pre></div>'
            sor_val = getattr(ep, "sor_tables", "") or ""
            sor_badge_html = ""
            if sor_val:
                pills = "".join(
                    f'<span style="background:#ede7f6;color:#4a235a;padding:2px 8px;border-radius:10px;font-size:0.75rem;font-weight:600;margin:2px;display:inline-block">{_esc(t.strip())}</span>'
                    for t in sor_val.split(",") if t.strip()
                )
                sor_badge_html = f'<div class="detail-row"><strong>&#128204; SOR Tables:</strong> {pills}</div>'
            type_class = f"type-{_esc(ep.api_type).lower()}"
            detail_cards += f"""
            <div class="detail-card">
                <div class="detail-header">
                    <span class="badge {type_class}">{_esc(ep.api_type)}</span>
                    <span class="method">{_esc(ep.http_method)}</span>
                    <strong>{_esc(ep.function_name)}</strong>
                    <span class="line-info">Line {ep.line_number}</span>
                </div>
                <div class="detail-body">
                    <div class="detail-row"><strong>URL:</strong> <code>{_esc(ep.url)}</code></div>
                    <div class="detail-row"><strong>File:</strong> <code>{_esc(ep.file_path)}</code></div>
                    <div class="detail-row"><strong>Request:</strong> {_esc(ep.request_details)}</div>
                    <div class="detail-row"><strong>Response:</strong> {_esc(ep.response_details)}</div>
                    {payload_html}
                    {sor_badge_html}
                    {match_badge}
                    {snippet_html}
                </div>
            </div>"""

        # per-repo diagrams
        repo_diag_html = ""
        repo_diags = per_repo_diagrams.get(idx, {})
        for title, img_path in repo_diags.items():
            b64 = _encode_image_base64(img_path)
            if b64:
                repo_diag_html += f"""
                <div class="diagram-section">
                    <h3>{_esc(title)}</h3>
                    <img src="data:image/png;base64,{b64}" alt="{_esc(title)}" />
                </div>"""

        per_repo_html += f"""
        <div class="repo-section" id="{safe_id}">
            <h2>📁 {_esc(r["source_name"])}</h2>
            {repo_stats}
            <h3>API Endpoints</h3>
            {ep_table}
            {"<h3>Diagrams</h3>" + repo_diag_html if repo_diag_html else ""}
            <h3>Detailed API Cards</h3>
            {detail_cards if detail_cards else "<p style='color:#999'>No endpoints found in this repo.</p>"}
            <p style="text-align:right;margin-top:12px;font-size:0.8rem;"><a href="#top">↑ Back to top</a></p>
        </div>"""

    # ── Assemble final HTML ──────────────────────────────────────────────────
    final_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Code Lens - Multi-Repo API Scan Report</title>
    <style>{css}</style>
</head>
<body>
<div class="container" id="top">

    <div class="header">
        <h1>Code Lens — Multi-Repo API Scan Report</h1>
        <p style="font-size:1rem;color:#e0e0e0;margin-bottom:4px;">
            {num_repos} repositories &nbsp;·&nbsp; {total_apis} APIs &nbsp;·&nbsp;
            {matched_total} matched &nbsp;·&nbsp; {unmatched_total} unmatched
        </p>
        <p>Language: {_esc(language)}</p>
        <div class="timestamp">Generated: {timestamp} | Total files scanned: {total_scanned} / {total_total}</div>
    </div>

    {overall_stats_html}

    <div class="toc">
        <h2>Table of Contents</h2>
        <ul>{toc_items}</ul>
    </div>

    <!-- OVERALL ANALYSIS -->
    <div class="section" id="overall-analysis">
        <h2>Overall Analysis</h2>

        <h3>By Repo / Source</h3>
        {repo_analysis_html}

        <h3>By Function (All Repos)</h3>
        {func_analysis_html}

        <h3>By Function &amp; Repo</h3>
        {cross_analysis_html}

        <h3>By API Type &amp; HTTP Method</h3>
        {type_analysis_html}
    </div>

    {_sor_analysis_section_html(all_endpoints, title="SOR / Source of Record Table Analysis — All Repos")}

    {_onedata_version_section_html(all_endpoints, title="OneData Version Functions — All Repos")}

    <!-- OVERALL DIAGRAMS -->
    <div class="section" id="overall-diagrams">
        <h2>Overall API Flow Diagrams</h2>
        {overview_diag_html if overview_diag_html else "<p style='color:#999'>Diagrams could not be generated.</p>"}
    </div>

    <!-- PER-REPO SECTIONS -->
    {per_repo_html}

    <div class="footer">
        Code Lens – Multi-Repo API Scan Report | Generated {timestamp}
    </div>

</div>
</body>
</html>"""
    return final_html


def generate_sor_audit_report(sor_calls, table_usages, integration_type, all_results, language, source_name=""):
    """
    Comprehensive SOR Integration Audit HTML report.
    Covers: Integration Type, Outbound SOR API calls, SQL table usage,
    Demographic data summary, WHY sections, Elapsed Time, Impacted Components.
    """
    import time as _time
    from collections import defaultdict

    t0 = _time.time()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    source_display = _esc(source_name) if source_name else "Scanned Workspace"

    SOR_SYSTEMS_LIST = [
        "CRPS", "Anagrafe", "Income SOR", "Triumph", "MNS",
        "GSTAR", "CM-CARS", "APAR", "CARE", "DIG", "GAR",
    ]
    SOR_APPROVED_TABLES = [
        "triumph_demographics", "triumph_card_account", "triumph_plastic_card",
        "gstar_card_details", "gstar_account_details", "gstar_customer_demographics",
        "gstar_corp_customer_demographics", "cars_cm_demographics", "mns_demographics_ar",
        "care_demographic", "apa_ar_demographic", "dcp_cm_mobile_dtl", "dcp_cm_email_dtl",
        "anagrafe_customer", "crps_customer_linkage", "gstar_corp_card_details",
        "gstar_corp_account_details",
    ]

    # Group by SOR system
    api_by_sor = defaultdict(list)
    for c in sor_calls:
        api_by_sor[c.sor_system].append(c)

    table_by_name = defaultdict(list)
    for t in table_usages:
        table_by_name[t.table_name].append(t)

    # Demographic APIs
    demog_api_calls = [c for c in sor_calls if c.is_demographic]
    demog_tables = [t for t in table_usages if t.is_demographic]

    # Compute total endpoints across all results
    total_endpoints = sum(len(r["endpoints"]) for r in all_results) if all_results else 0

    def _elapsed(t_start):
        return f"{(_time.time() - t_start) * 1000:.0f} ms"

    def _priority_badge(p):
        colors = {"High": "#dc3545", "Medium": "#fd7e14", "Low": "#28a745"}
        c = colors.get(p, "#666")
        return f'<span style="background:{c};color:#fff;padding:2px 10px;border-radius:10px;font-size:0.78rem;font-weight:700">{p}</span>'

    def _impacted_components(sor_name, calls_or_tables, kind="api"):
        """Generate Impacted Components section HTML."""
        if kind == "api":
            classes = sorted(set(c.class_name for c in calls_or_tables if c.class_name))
            files = sorted(set(c.file_path for c in calls_or_tables))
        else:
            classes = sorted(set(t.class_name for t in calls_or_tables if t.class_name))
            files = sorted(set(t.file_path for t in calls_or_tables))
        class_list = "".join(f"<li><code>{_esc(c)}</code></li>" for c in classes) if classes else "<li><em>Not detected</em></li>"
        file_list = "".join(f"<li><code>{_esc(f)}</code></li>" for f in files[:8]) if files else "<li><em>Not detected</em></li>"
        return f"""
        <div class="impacted-box">
            <strong>&#128268; Impacted Components (Java Full Stack Engineer View)</strong>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:10px;">
                <div>
                    <em>Backend Classes/DAOs</em>
                    <ul style="margin:4px 0 0 16px;font-size:0.8rem;">{class_list}</ul>
                </div>
                <div>
                    <em>Files</em>
                    <ul style="margin:4px 0 0 16px;font-size:0.8rem;">{file_list}</ul>
                </div>
            </div>
            <div style="margin-top:10px;font-size:0.82rem;">
                <strong>Required Code Changes:</strong>
                <ul style="margin:4px 0 0 16px;">
                    <li>Update endpoint URL if {_esc(sor_name)} base URL changes</li>
                    <li>Review DTO/POJO mapping for {_esc(sor_name)} response schema changes</li>
                    <li>Update integration test mocks and contract tests</li>
                </ul>
            </div>
            <div style="margin-top:8px;font-size:0.82rem;">
                <strong>Recommended Tests:</strong> Unit tests for service layer, Integration tests with WireMock/MockServer, Contract tests (Pact), End-to-end regression tests.
            </div>
        </div>"""

    def _why_section(text1, text2):
        return f"""
        <div class="why-box">
            <strong>&#10067; WHY</strong>
            <p>{_esc(text1)}</p>
            <p>{_esc(text2)}</p>
        </div>"""

    # ── CSS ────────────────────────────────────────────────────────────────
    css = """
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; background:#f0f2f5; color:#333; line-height:1.6; }
        a { color:#e94560; }
        .container { max-width:1400px; margin:0 auto; padding:20px; }
        .header { background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%); padding:30px; border-radius:12px; text-align:center; margin-bottom:24px; }
        .header h1 { color:#e94560; font-size:2rem; margin-bottom:6px; }
        .header p  { color:#a8b2d1; font-size:0.95rem; }
        .header .timestamp { color:#6c7a9a; font-size:0.8rem; margin-top:8px; }
        .toc { background:#fff; border-radius:10px; padding:20px 28px; margin-bottom:24px; box-shadow:0 2px 4px rgba(0,0,0,.05); }
        .toc h2 { color:#1a1a2e; margin-bottom:12px; font-size:1.1rem; border-bottom:2px solid #e94560; padding-bottom:6px; }
        .toc ul { list-style:none; }
        .toc ul li { padding:3px 0; font-size:0.88rem; }
        .toc ul li::before { content:"▸ "; color:#e94560; }
        .stats { display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); gap:14px; margin-bottom:24px; }
        .stat-card { background:#fff; border:1px solid #e0e0e0; border-radius:10px; padding:16px; text-align:center; box-shadow:0 2px 4px rgba(0,0,0,.05); }
        .stat-card h3 { font-size:1.8rem; color:#1a1a2e; margin:0; }
        .stat-card p  { color:#6c757d; margin:0; font-size:0.82rem; }
        .section { background:#fff; border-radius:10px; padding:24px; margin-bottom:24px; box-shadow:0 2px 4px rgba(0,0,0,.05); }
        .section h2 { color:#1a1a2e; border-bottom:3px solid #e94560; padding-bottom:8px; margin-bottom:16px; font-size:1.25rem; }
        .section h3 { color:#0f3460; margin:16px 0 10px; font-size:1rem; }
        .sor-block { border:1px solid #e0e0e0; border-radius:8px; margin-bottom:16px; overflow:hidden; }
        .sor-block-header { background:#1a1a2e; color:#fff; padding:10px 16px; display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
        .sor-block-body { padding:16px; }
        .badge { display:inline-block; padding:2px 10px; border-radius:12px; font-size:0.75rem; font-weight:600; }
        .badge-api  { background:#d4edda; color:#155724; }
        .badge-query{ background:#d1ecf1; color:#0c5460; }
        .badge-both { background:#fff3cd; color:#856404; }
        .badge-none { background:#f8d7da; color:#721c24; }
        .method { display:inline-block; background:#e8e8e8; padding:2px 8px; border-radius:4px; font-family:monospace; font-size:0.78rem; font-weight:600; }
        table { width:100%; border-collapse:collapse; font-size:0.83rem; }
        th { background:#1a1a2e; color:#fff; padding:9px 8px; text-align:left; font-weight:600; }
        td { padding:7px 8px; border-bottom:1px solid #eee; vertical-align:top; }
        tr:hover { background:#f8f9fa; }
        .code-snippet { background:#282c34; color:#abb2bf; padding:10px; border-radius:6px; font-size:0.78rem; overflow-x:auto; white-space:pre-wrap; word-wrap:break-word; margin-top:6px; }
        .detail-row { margin-bottom:8px; font-size:0.85rem; }
        .detail-row code { background:#f0f0f0; padding:2px 6px; border-radius:4px; }
        .why-box { background:#fff8e1; border-left:4px solid #ffc107; padding:12px 16px; border-radius:0 8px 8px 0; margin:12px 0; font-size:0.85rem; }
        .why-box p { margin:4px 0; }
        .impacted-box { background:#e8f4fd; border-left:4px solid #17a2b8; padding:12px 16px; border-radius:0 8px 8px 0; margin:12px 0; font-size:0.85rem; }
        .elapsed { display:inline-block; background:#e9ecef; color:#495057; padding:2px 10px; border-radius:10px; font-size:0.75rem; font-weight:600; margin-left:8px; }
        .not-found { background:#f8f9fa; border:1px dashed #ccc; border-radius:8px; padding:12px 16px; color:#6c757d; font-style:italic; margin-bottom:12px; }
        .integration-type-banner { padding:16px 20px; border-radius:10px; margin-bottom:20px; font-size:1rem; font-weight:600; }
        .it-api    { background:#d4edda; color:#155724; border-left:6px solid #28a745; }
        .it-query  { background:#d1ecf1; color:#0c5460; border-left:6px solid #17a2b8; }
        .it-both   { background:#fff3cd; color:#856404; border-left:6px solid #ffc107; }
        .it-none   { background:#f8d7da; color:#721c24; border-left:6px solid #dc3545; }
        .demog-table th { background:#4a235a; }
        .footer { text-align:center; color:#999; font-size:0.78rem; padding:20px; }
        @media print { body { background:white; } .section { box-shadow:none; border:1px solid #ddd; page-break-inside:avoid; } }
    """

    # ── Integration Type Banner ───────────────────────────────────────────
    it_class = {"API-Based": "it-api", "Query-Based": "it-query", "Both": "it-both"}.get(integration_type, "it-none")
    it_icon  = {"API-Based": "🔗", "Query-Based": "🗄️", "Both": "🔗🗄️"}.get(integration_type, "❓")
    it_banner = f"""
    <div class="integration-type-banner {it_class}">
        {it_icon} Integration Type: <strong>{_esc(integration_type)}</strong>
    </div>"""

    # ── TOC ───────────────────────────────────────────────────────────────
    toc_html = "<li><a href='#integration-type'>Integration Type</a></li>\n"
    if integration_type in ("API-Based", "Both"):
        toc_html += "<li><a href='#outbound-sor'>Outbound SOR API Calls</a></li>\n"
        for s in SOR_SYSTEMS_LIST:
            s_anchor = s.replace(" ", "-")
            toc_html += f"<li style='padding-left:16px'><a href='#sor-{s_anchor}'>&#8594; {_esc(s)}</a></li>\n"
    if integration_type in ("Query-Based", "Both"):
        toc_html += "<li><a href='#sql-tables'>SQL / Table Usage</a></li>\n"
    toc_html += "<li><a href='#demographic'>Demographic Data APIs</a></li>\n"
    toc_html += "<li><a href='#summary'>Executive Summary</a></li>\n"

    # ── Overall stats ─────────────────────────────────────────────────────
    sor_found = len(set(c.sor_system for c in sor_calls))
    tables_found = len(set(t.table_name for t in table_usages))

    stats_html = f"""
    <div class="stats">
        <div class="stat-card" style="border-left:4px solid #e94560"><h3>{total_endpoints}</h3><p>Total APIs Found</p></div>
        <div class="stat-card" style="border-left:4px solid #28a745"><h3>{len(sor_calls)}</h3><p>Outbound SOR Calls</p></div>
        <div class="stat-card" style="border-left:4px solid #17a2b8"><h3>{len(table_usages)}</h3><p>SOR Table References</p></div>
        <div class="stat-card" style="border-left:4px solid #ffc107"><h3>{sor_found}</h3><p>SOR Systems Detected</p></div>
        <div class="stat-card" style="border-left:4px solid #9b59b6"><h3>{tables_found}</h3><p>Unique Tables Found</p></div>
        <div class="stat-card" style="border-left:4px solid #e94560"><h3>{len(demog_api_calls) + len(demog_tables)}</h3><p>Demographic Refs</p></div>
    </div>"""

    # ── Outbound SOR API blocks ───────────────────────────────────────────
    t_api_start = _time.time()
    api_section_html = ""
    if integration_type in ("API-Based", "Both", "Not Detected"):
        for sys_name in SOR_SYSTEMS_LIST:
            anchor = f"sor-{sys_name.replace(' ', '-')}"
            calls = api_by_sor.get(sys_name, [])
            elapsed = _elapsed(t_api_start)

            if not calls:
                api_section_html += f"""
                <div class="sor-block" id="{anchor}">
                    <div class="sor-block-header">
                        <strong>{_esc(sys_name)}</strong>
                        <span class="badge badge-none">Not Found</span>
                        <span class="elapsed">Elapsed: {elapsed}</span>
                    </div>
                    <div class="sor-block-body">
                        <div class="not-found">No outbound API integration with <strong>{_esc(sys_name)}</strong> found.</div>
                        {_why_section(
                            f"The codebase was searched for HTTP client patterns, configuration properties, and URL strings referencing '{sys_name}' keywords.",
                            "No matching outbound calls were detected, indicating the application does not currently integrate with this SOR system via API."
                        )}
                    </div>
                </div>"""
                continue

            # Rows for each call
            call_rows = ""
            for c in calls:
                call_rows += f"""
                <tr>
                    <td><code style="font-size:0.78rem;word-break:break-all">{_esc(c.url)}</code></td>
                    <td><span class="method">{_esc(c.http_method)}</span></td>
                    <td style="font-size:0.78rem">{_esc(c.operation_desc)}</td>
                    <td style="font-family:monospace;font-size:0.73rem;word-break:break-all">{_esc(c.file_path)}</td>
                    <td style="font-size:0.75rem">{_esc(c.class_name)}</td>
                    <td style="text-align:center">{c.line_number}</td>
                    <td style="font-size:0.75rem">{_esc(c.config_location)}</td>
                    <td style="text-align:center">{'✅' if c.is_demographic else '—'}</td>
                </tr>"""

            snippets_html = ""
            for c in calls[:3]:
                if c.code_snippet:
                    snippets_html += f"""
                    <div style="margin-bottom:10px;">
                        <code style="font-size:0.75rem">{_esc(c.file_path)}:{c.line_number}</code>
                        <pre class="code-snippet">{_esc(c.code_snippet)}</pre>
                    </div>"""

            priority = "High" if calls else "Low"
            api_section_html += f"""
            <div class="sor-block" id="{anchor}">
                <div class="sor-block-header">
                    <strong>{_esc(sys_name)}</strong>
                    <span class="badge badge-api">API-Based</span>
                    <span style="font-size:0.82rem;color:#a8b2d1">{len(calls)} call(s) detected</span>
                    <span class="elapsed">Elapsed: {elapsed}</span>
                    {_priority_badge(priority)}
                </div>
                <div class="sor-block-body">
                    <div style="overflow-x:auto;">
                    <table>
                        <thead><tr>
                            <th>Endpoint URL</th><th>Method</th><th>Operation</th>
                            <th>File Path</th><th>Class</th><th>Line</th>
                            <th>Config Location</th><th>Demog?</th>
                        </tr></thead>
                        <tbody>{call_rows}</tbody>
                    </table>
                    </div>
                    {('<h3>Code Snippets</h3>' + snippets_html) if snippets_html else ''}
                    {_why_section(
                        f"The scanner identified {len(calls)} outbound HTTP call(s) in the codebase that reference '{sys_name}' keywords, indicating active integration with this SOR system.",
                        "These calls represent data flow dependency on the external SOR system and must be monitored for API contract changes, SLA compliance, and error handling."
                    )}
                    {_impacted_components(sys_name, calls, kind="api")}
                </div>
            </div>"""

    outbound_section = ""
    if integration_type in ("API-Based", "Both", "Not Detected"):
        outbound_section = f"""
        <div class="section" id="outbound-sor">
            <h2>&#128279; Outbound SOR API Calls</h2>
            <p style="color:#666;margin-bottom:16px;font-size:0.88rem;">
                Showing outbound HTTP integrations the application makes to external SOR systems.
                Internal controller endpoints are excluded.
            </p>
            {api_section_html}
        </div>"""

    # ── SQL Table Usage blocks ────────────────────────────────────────────
    t_sql_start = _time.time()
    sql_section_html = ""
    if integration_type in ("Query-Based", "Both", "Not Detected"):
        table_blocks = ""
        for tname in SOR_APPROVED_TABLES:
            usages = table_by_name.get(tname, [])
            elapsed = _elapsed(t_sql_start)
            anchor = f"table-{tname}"

            if not usages:
                table_blocks += f"""
                <div class="sor-block" id="{anchor}">
                    <div class="sor-block-header">
                        <strong><code style="color:#ffe">{_esc(tname)}</code></strong>
                        <span class="badge badge-none">Not Found</span>
                        <span class="elapsed">Elapsed: {elapsed}</span>
                    </div>
                    <div class="sor-block-body">
                        <div class="not-found">No usage of approved table <strong><code>{_esc(tname)}</code></strong> found.</div>
                    </div>
                </div>"""
                continue

            row_html = ""
            for u in usages:
                row_html += f"""
                <tr>
                    <td><span class="method">{_esc(u.query_type)}</span></td>
                    <td style="font-family:monospace;font-size:0.73rem;word-break:break-all">{_esc(u.file_path)}</td>
                    <td style="font-size:0.75rem">{_esc(u.class_name)}</td>
                    <td style="text-align:center">{u.line_number}</td>
                    <td style="text-align:center">{'✅' if u.is_demographic else '—'}</td>
                </tr>"""

            query_snippets = ""
            for u in usages[:2]:
                if u.exact_query:
                    query_snippets += f"""
                    <div style="margin-bottom:8px;">
                        <code style="font-size:0.75rem">{_esc(u.file_path)}:{u.line_number}</code>
                        <pre class="code-snippet">{_esc(u.exact_query)}</pre>
                    </div>"""

            priority = "High" if any(u.query_type in ("INSERT","UPDATE","DELETE") for u in usages) else "Medium"
            table_blocks += f"""
            <div class="sor-block" id="{anchor}">
                <div class="sor-block-header">
                    <strong><code style="color:#ffe">{_esc(tname)}</code></strong>
                    <span class="badge badge-query">Query-Based</span>
                    <span style="font-size:0.82rem;color:#a8b2d1">{len(usages)} reference(s)</span>
                    <span class="elapsed">Elapsed: {elapsed}</span>
                    {_priority_badge(priority)}
                </div>
                <div class="sor-block-body">
                    <div style="overflow-x:auto;">
                    <table>
                        <thead><tr>
                            <th>Query Type</th><th>File Path</th><th>Class</th>
                            <th>Line</th><th>Demog?</th>
                        </tr></thead>
                        <tbody>{row_html}</tbody>
                    </table>
                    </div>
                    {('<h3>Query Context</h3>' + query_snippets) if query_snippets else ''}
                    {_why_section(
                        f"The table '{tname}' is an approved SOR table found {len(usages)} time(s) in the codebase, representing a direct database-level coupling to the SOR system.",
                        "Direct table access creates tight coupling with the SOR schema; any structural change to this table requires coordinated code changes in all listed components."
                    )}
                    {_impacted_components(tname, usages, kind="sql")}
                </div>
            </div>"""

        sql_section_html = f"""
        <div class="section" id="sql-tables">
            <h2>&#128451; SQL / Table Usage (Query-Based Integration)</h2>
            <p style="color:#666;margin-bottom:16px;font-size:0.88rem;">
                Searching for approved SOR table references in SQL files, stored procedures, DAO/repository classes, and ORM mappers.
            </p>
            {table_blocks}
        </div>"""

    # ── Demographic Data API table ────────────────────────────────────────
    t_demog = _time.time()
    demog_rows_api = ""
    for c in demog_api_calls:
        demog_rows_api += f"""
        <tr>
            <td><strong>{_esc(c.sor_system)}</strong></td>
            <td><code style="font-size:0.78rem;word-break:break-all">{_esc(c.url)}</code></td>
            <td><span class="method">{_esc(c.http_method)}</span></td>
            <td style="font-size:0.75rem">{_esc(c.class_name)}</td>
            <td style="font-family:monospace;font-size:0.73rem;word-break:break-all">{_esc(c.file_path)}:{c.line_number}</td>
        </tr>"""

    demog_rows_sql = ""
    for u in demog_tables:
        demog_rows_sql += f"""
        <tr>
            <td style="font-size:0.8rem"><code>{_esc(u.table_name)}</code></td>
            <td><span class="method">{_esc(u.query_type)}</span></td>
            <td style="font-size:0.75rem">{_esc(u.class_name)}</td>
            <td style="font-family:monospace;font-size:0.73rem;word-break:break-all">{_esc(u.file_path)}:{u.line_number}</td>
        </tr>"""

    demog_api_table = f"""
        <h3>APIs Fetching Demographic Data</h3>
        <div style="overflow-x:auto;">
        <table class="demog-table">
            <thead><tr>
                <th>SOR Name</th><th>API Endpoint URL</th><th>Method</th><th>Class</th><th>Source Location</th>
            </tr></thead>
            <tbody>{demog_rows_api if demog_rows_api else '<tr><td colspan="5" style="color:#999;text-align:center">No demographic API calls detected</td></tr>'}</tbody>
        </table>
        </div>""" if integration_type in ("API-Based", "Both", "Not Detected") else ""

    demog_sql_table = f"""
        <h3>Tables Containing Demographic Data</h3>
        <div style="overflow-x:auto;">
        <table class="demog-table">
            <thead><tr>
                <th>Table Name</th><th>Query Type</th><th>Class</th><th>Source Location</th>
            </tr></thead>
            <tbody>{demog_rows_sql if demog_rows_sql else '<tr><td colspan="4" style="color:#999;text-align:center">No demographic table usages detected</td></tr>'}</tbody>
        </table>
        </div>""" if integration_type in ("Query-Based", "Both", "Not Detected") else ""

    demog_section = f"""
    <div class="section" id="demographic">
        <h2>&#128101; Demographic Data — API & SOR Reference</h2>
        <p style="color:#666;margin-bottom:16px;font-size:0.88rem;">
            APIs and tables where demographic data is fetched or accessed, identified by keyword analysis.
        </p>
        {demog_api_table}
        {demog_sql_table}
        <span class="elapsed">Elapsed: {_elapsed(t_demog)}</span>
        {_why_section(
            "Demographic data touchpoints are flagged separately because they represent the highest risk for PII exposure and regulatory compliance (GDPR, CCPA) across all SOR integrations.",
            "Centralising demographic data flows in a dedicated section enables data governance teams to quickly audit which APIs and tables handle personal information without scanning the full report."
        )}
    </div>"""

    # ── Executive Summary ─────────────────────────────────────────────────
    found_systems = sorted(set(c.sor_system for c in sor_calls))
    not_found_systems = [s for s in SOR_SYSTEMS_LIST if s not in found_systems]
    found_tables = sorted(set(t.table_name for t in table_usages))
    not_found_tables = [t for t in SOR_APPROVED_TABLES if t not in found_tables]

    summary_found = "".join(f"<li><strong>{_esc(s)}</strong> — {len(api_by_sor[s])} call(s)</li>" for s in found_systems)
    summary_not   = "".join(f"<li style='color:#999'>{_esc(s)}</li>" for s in not_found_systems)
    tables_found_list = "".join(f"<li><code>{_esc(t)}</code></li>" for t in found_tables)
    tables_not_list   = "".join(f"<li style='color:#999'><code>{_esc(t)}</code></li>" for t in not_found_tables[:8])

    summary_section = f"""
    <div class="section" id="summary">
        <h2>&#128203; Executive Summary</h2>
        <span class="elapsed">Total report generation: {_elapsed(t0)}</span>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:16px;">
            <div>
                <h3>SOR Systems — API Integrations Found ({len(found_systems)}/{len(SOR_SYSTEMS_LIST)})</h3>
                <ul style="margin:8px 0 0 16px;font-size:0.85rem;">{summary_found if summary_found else '<li style="color:#999">None detected</li>'}</ul>
                <h3 style="margin-top:14px">Not Found</h3>
                <ul style="margin:8px 0 0 16px;font-size:0.85rem;">{summary_not if summary_not else '<li style="color:#999">All systems found</li>'}</ul>
            </div>
            <div>
                <h3>SOR Tables Found ({len(found_tables)}/{len(SOR_APPROVED_TABLES)})</h3>
                <ul style="margin:8px 0 0 16px;font-size:0.85rem;">{tables_found_list if tables_found_list else '<li style="color:#999">None detected</li>'}</ul>
                <h3 style="margin-top:14px">Not Found (first 8)</h3>
                <ul style="margin:8px 0 0 16px;font-size:0.85rem;">{tables_not_list if tables_not_list else '<li style="color:#999">All tables found</li>'}</ul>
            </div>
        </div>
        {_why_section(
            "The executive summary consolidates all findings so that architects and product owners can assess the integration footprint without reading the full report.",
            "Systems and tables that are not found are explicitly listed per the audit specification to confirm thorough analysis rather than omission."
        )}
    </div>"""

    # ── Final assembly ────────────────────────────────────────────────────
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Code Lens — SOR Integration Audit Report</title>
    <style>{css}</style>
</head>
<body>
<div class="container" id="top">

    <div class="header">
        <h1>Code Lens — SOR Integration Audit Report</h1>
        <p style="font-size:1rem;color:#e0e0e0;margin-bottom:4px;">{source_display}</p>
        <p>Language: {_esc(language)} | Integration Type: <strong style="color:#ffc107">{_esc(integration_type)}</strong></p>
        <div class="timestamp">Generated: {timestamp}</div>
    </div>

    {stats_html}

    <div class="toc">
        <h2>Table of Contents</h2>
        <ul>{toc_html}</ul>
    </div>

    <div class="section" id="integration-type">
        <h2>&#128270; Integration Type Detection</h2>
        {it_banner}
        <div class="detail-row">
            <strong>Outbound SOR API calls detected:</strong> {len(sor_calls)} &nbsp;|&nbsp;
            <strong>SOR Table references detected:</strong> {len(table_usages)}
        </div>
        {_why_section(
            "Integration type is determined by scanning all HTTP client patterns (RestTemplate, WebClient, FeignClient, HttpClient, fetch, axios, etc.) for SOR system keywords and all SQL/DAO files for approved SOR table names.",
            "Classifying the integration type upfront is essential because it dictates the team responsible for testing, the appropriate change management process, and the risk level associated with SOR system modifications."
        )}
    </div>

    {outbound_section}
    {sql_section_html}
    {demog_section}
    {summary_section}

    <div class="footer">
        Code Lens – SOR Integration Audit Report | Generated {timestamp}
        <br/><a href="#top">↑ Back to top</a>
    </div>
</div>
</body>
</html>"""


def generate_excel_report(endpoints, language, scanned_files, total_files, source_name=""):
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        all_data = []
        for ep in endpoints:
            all_data.append({
                "API Type": ep.api_type,
                "HTTP Method": ep.http_method,
                "URL / Endpoint": ep.url,
                "Function Name": ep.function_name,
                "File Path": ep.file_path,
                "Line Number": ep.line_number,
                "Request Details": ep.request_details,
                "Response Details": ep.response_details,
                "Matched Excel URL": ep.matched_excel_url,
                "Matched Excel Path": ep.matched_excel_path,
                "SOR Tables": getattr(ep, "sor_tables", "") or "",
                "Code Snippet": ep.code_snippet,
            })
        df_all = pd.DataFrame(all_data)
        df_all.to_excel(writer, sheet_name="All Endpoints", index=False)

        matched_data = []
        for ep in endpoints:
            if ep.matched_excel_url or ep.matched_excel_path:
                matched_data.append({
                    "API Type": ep.api_type,
                    "HTTP Method": ep.http_method,
                    "URL / Endpoint": ep.url,
                    "Function Name": ep.function_name,
                    "File Path": ep.file_path,
                    "Line Number": ep.line_number,
                    "Matched Excel URL": ep.matched_excel_url,
                    "Matched Excel Path": ep.matched_excel_path,
                })
        if matched_data:
            pd.DataFrame(matched_data).to_excel(writer, sheet_name="Matched Endpoints", index=False)

        unmatched_data = []
        for ep in endpoints:
            if not ep.matched_excel_url and not ep.matched_excel_path:
                unmatched_data.append({
                    "API Type": ep.api_type,
                    "HTTP Method": ep.http_method,
                    "URL / Endpoint": ep.url,
                    "Function Name": ep.function_name,
                    "File Path": ep.file_path,
                    "Line Number": ep.line_number,
                })
        if unmatched_data:
            pd.DataFrame(unmatched_data).to_excel(writer, sheet_name="Unmatched Endpoints", index=False)

        rest_count = sum(1 for e in endpoints if e.api_type == "REST")
        soap_count = sum(1 for e in endpoints if e.api_type == "SOAP")
        onedata_count = sum(1 for e in endpoints if e.api_type == "OneData")
        matched_count = len(matched_data)

        summary = pd.DataFrame([
            {"Metric": "Source", "Value": source_name or "Unknown"},
            {"Metric": "Language", "Value": language},
            {"Metric": "Total Files", "Value": total_files},
            {"Metric": "Scanned Files", "Value": scanned_files},
            {"Metric": "Total API Endpoints", "Value": len(endpoints)},
            {"Metric": "REST APIs", "Value": rest_count},
            {"Metric": "SOAP APIs", "Value": soap_count},
            {"Metric": "OneData Functions", "Value": onedata_count},
            {"Metric": "Excel Matched", "Value": matched_count},
            {"Metric": "Unmatched", "Value": len(endpoints) - matched_count},
            {"Metric": "Report Generated", "Value": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
        ])
        summary.to_excel(writer, sheet_name="Summary", index=False)

        # SOR table analysis sheet
        from collections import defaultdict as _dd2
        sor_map = _dd2(list)
        for e in endpoints:
            sor_val = getattr(e, "sor_tables", "") or ""
            for t in [s.strip() for s in sor_val.split(",") if s.strip()]:
                sor_map[t].append(e)
        sor_rows = []
        for tname in SOR_TABLES:
            eps_for_t = sor_map.get(tname, [])
            sor_rows.append({
                "SOR Table": tname,
                "API Count": len(eps_for_t),
                "API Types": ", ".join(sorted(set(e.api_type for e in eps_for_t))) if eps_for_t else "",
                "Functions": ", ".join(sorted(set(e.function_name for e in eps_for_t))) if eps_for_t else "",
                "Files": ", ".join(sorted(set(os.path.basename(e.file_path) for e in eps_for_t))) if eps_for_t else "",
                "Repo / Source": ", ".join(sorted(set(getattr(e, "source_name", "") for e in eps_for_t if getattr(e, "source_name", "")))) if eps_for_t else "",
                "Status": "Detected" if eps_for_t else "Not Found",
            })
        pd.DataFrame(sor_rows).to_excel(writer, sheet_name="SOR Tables", index=False)

        # Per-API SOR detail
        sor_detail = []
        for e in endpoints:
            sor_val = getattr(e, "sor_tables", "") or ""
            if sor_val:
                sor_detail.append({
                    "API Type": e.api_type,
                    "HTTP Method": e.http_method,
                    "URL / Endpoint": e.url,
                    "Function Name": e.function_name,
                    "File Path": e.file_path,
                    "Line Number": e.line_number,
                    "SOR Tables": sor_val,
                    "Repo / Source": getattr(e, "source_name", ""),
                })
        if sor_detail:
            pd.DataFrame(sor_detail).to_excel(writer, sheet_name="SOR - API Detail", index=False)

        # OneData version functions sheet
        import re as _re
        from collections import defaultdict
        od_version_eps = [
            e for e in endpoints
            if e.api_type == "OneData" and _re.search(r'v[1-4]', e.http_method or "")
        ]
        if od_version_eps:
            func_agg = defaultdict(lambda: {"Occurrences": 0, "Files": set(), "Lines": [], "Repo": set()})
            for e in od_version_eps:
                key = (e.http_method, e.function_name)
                d = func_agg[key]
                d["Occurrences"] += 1
                d["Files"].add(os.path.basename(e.file_path))
                d["Lines"].append(str(e.line_number))
                if getattr(e, "source_name", ""):
                    d["Repo"].add(e.source_name)
            od_rows = []
            for (ver, fn) in sorted(func_agg.keys()):
                d = func_agg[(ver, fn)]
                od_rows.append({
                    "Version Prefix": ver,
                    "Function Name": fn,
                    "Occurrences": d["Occurrences"],
                    "Files": ", ".join(sorted(d["Files"])),
                    "Line Numbers": ", ".join(d["Lines"]),
                    "Repo / Source": ", ".join(sorted(d["Repo"])),
                })
            pd.DataFrame(od_rows).to_excel(writer, sheet_name="OneData Functions", index=False)

    output.seek(0)
    return output.getvalue()
