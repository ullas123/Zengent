import base64
import html
import io
import os
import tempfile
from datetime import datetime

import pandas as pd


def _esc(text):
    return html.escape(str(text)) if text else ""


def _encode_image_base64(image_path):
    if image_path and os.path.exists(image_path):
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
    return None


def _onedata_version_section_html(endpoints, title="OneData Version Function Occurrences"):
    """Builds an HTML section showing OneData .v1/.v2/.v3/.v4 function occurrences and counts."""
    from collections import defaultdict
    import re as _re

    version_eps = [
        e for e in endpoints
        if e.api_type == "OneData" and _re.search(r'v[1-4]', e.http_method or "")
    ]
    if not version_eps:
        return ""

    # Group: function_name × version_prefix × file → count + occurrences list
    func_agg = defaultdict(lambda: {"count": 0, "files": set(), "version": "", "occurrences": []})
    for e in version_eps:
        key = (e.function_name, e.http_method)
        d = func_agg[key]
        d["count"] += 1
        d["version"] = e.http_method
        d["files"].add(os.path.basename(e.file_path))
        d["occurrences"].append({"file": e.file_path, "line": e.line_number, "source": getattr(e, "source_name", "")})

    rows_html = ""
    for (fn, ver) in sorted(func_agg.keys()):
        d = func_agg[(fn, ver)]
        files_str = ", ".join(sorted(d["files"]))
        badge_color = "#e8f5e9" if "sor" in ver else "#e3f2fd"
        txt_color = "#1b5e20" if "sor" in ver else "#0d47a1"
        rows_html += f"""<tr>
            <td><span style="background:{badge_color};color:{txt_color};padding:2px 8px;border-radius:10px;font-size:0.78rem;font-weight:600">{_esc(ver)}</span></td>
            <td><strong>{_esc(fn)}</strong></td>
            <td style="text-align:center;font-size:1rem;font-weight:700;color:#0f3460">{d["count"]}</td>
            <td style="font-size:0.78rem;color:#555">{_esc(files_str)}</td>
        </tr>"""

    total_occurrences = sum(d["count"] for d in func_agg.values())
    unique_funcs = len(func_agg)

    return f"""
    <div class="section" style="border-left:5px solid #ffc107;">
        <h2 style="color:#856404;">&#9889; {title}</h2>
        <p style="margin-bottom:14px;color:#555;">
            Found <strong>{unique_funcs}</strong> unique OneData version function(s) with
            <strong>{total_occurrences}</strong> total occurrence(s) across the codebase.
        </p>
        <div style="overflow-x:auto;">
        <table>
            <thead><tr>
                <th style="background:#856404;">Version Prefix</th>
                <th style="background:#856404;">Function Name</th>
                <th style="background:#856404;">Occurrences</th>
                <th style="background:#856404;">File(s)</th>
            </tr></thead>
            <tbody>{rows_html}</tbody>
        </table>
        </div>
    </div>"""


def generate_html_report(endpoints, language, scanned_files, total_files, diagram_images=None, source_name=""):
    rest_count = sum(1 for e in endpoints if e.api_type == "REST")
    soap_count = sum(1 for e in endpoints if e.api_type == "SOAP")
    onedata_count = sum(1 for e in endpoints if e.api_type == "OneData")
    matched_count = sum(1 for e in endpoints if e.matched_excel_url or e.matched_excel_path)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    source_display = _esc(source_name) if source_name else "Unknown Source"

    diagram_html_sections = ""
    if diagram_images:
        for title, img_path in diagram_images.items():
            b64 = _encode_image_base64(img_path)
            if b64:
                diagram_html_sections += f"""
                <div class="diagram-section">
                    <h3>{title}</h3>
                    <img src="data:image/png;base64,{b64}" alt="{title}" />
                </div>
                """

    matched_eps = [e for e in endpoints if e.matched_excel_url or e.matched_excel_path]
    unmatched_eps = [e for e in endpoints if not e.matched_excel_url and not e.matched_excel_path]

    endpoint_rows = ""
    for ep in endpoints:
        match_class = "matched" if (ep.matched_excel_url or ep.matched_excel_path) else ""
        type_class = f"type-{_esc(ep.api_type).lower()}"

        endpoint_rows += f"""
        <tr class="{match_class}">
            <td><span class="badge {type_class}">{_esc(ep.api_type)}</span></td>
            <td><span class="method">{_esc(ep.http_method)}</span></td>
            <td class="url-cell">{_esc(ep.url)}</td>
            <td>{_esc(ep.function_name)}</td>
            <td>{_esc(os.path.basename(ep.file_path))}</td>
            <td>{ep.line_number}</td>
            <td>{_esc(ep.request_details)}</td>
            <td>{_esc(ep.response_details)}</td>
            <td>{_esc(ep.matched_excel_url)}</td>
            <td>{_esc(ep.matched_excel_path)}</td>
        </tr>
        """

    detail_cards = ""
    for ep in endpoints:
        match_badge = ""
        if ep.matched_excel_url:
            match_badge += f'<div class="match-info">Matched Excel URL: {_esc(ep.matched_excel_url)}</div>'
        if ep.matched_excel_path:
            match_badge += f'<div class="match-info">Matched Excel Path: {_esc(ep.matched_excel_path)}</div>'

        snippet_html = ""
        if ep.code_snippet:
            snippet_html = f"""
            <div class="detail-row">
                <strong>Code Context:</strong>
                <pre class="code-snippet">{_esc(ep.code_snippet)}</pre>
            </div>
            """

        type_class = f"type-{_esc(ep.api_type).lower()}"
        detail_cards += f"""
        <div class="detail-card">
            <div class="detail-header">
                <span class="badge {type_class}">{_esc(ep.api_type)}</span>
                <span class="method">{_esc(ep.http_method)}</span>
                <strong>{_esc(ep.function_name)}</strong>
                <span class="line-info">Line {ep.line_number}</span>
            </div>
            <div class="detail-body">
                <div class="detail-row"><strong>Endpoint URL:</strong> <code>{_esc(ep.url)}</code></div>
                <div class="detail-row"><strong>File:</strong> <code>{_esc(ep.file_path)}</code></div>
                <div class="detail-row"><strong>Request:</strong> {_esc(ep.request_details)}</div>
                <div class="detail-row"><strong>Response:</strong> {_esc(ep.response_details)}</div>
                {match_badge}
                {snippet_html}
            </div>
        </div>
        """

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Lens - API Scan Report</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f0f2f5; color: #333; line-height: 1.6; }}
        .container {{ max-width: 1400px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); padding: 30px; border-radius: 12px; text-align: center; margin-bottom: 24px; }}
        .header h1 {{ color: #e94560; font-size: 2rem; margin-bottom: 6px; }}
        .header p {{ color: #a8b2d1; font-size: 0.95rem; }}
        .header .timestamp {{ color: #6c7a9a; font-size: 0.8rem; margin-top: 8px; }}
        .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 16px; margin-bottom: 24px; }}
        .stat-card {{ background: #fff; border: 1px solid #e0e0e0; border-radius: 10px; padding: 18px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }}
        .stat-card h3 {{ font-size: 2rem; color: #1a1a2e; margin: 0; }}
        .stat-card p {{ color: #6c757d; margin: 0; font-size: 0.85rem; }}
        .stat-rest {{ border-left: 4px solid #28a745; }}
        .stat-soap {{ border-left: 4px solid #17a2b8; }}
        .stat-onedata {{ border-left: 4px solid #ffc107; }}
        .stat-matched {{ border-left: 4px solid #e94560; }}
        .section {{ background: #fff; border-radius: 10px; padding: 24px; margin-bottom: 24px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }}
        .section h2 {{ color: #1a1a2e; border-bottom: 3px solid #e94560; padding-bottom: 8px; margin-bottom: 16px; font-size: 1.3rem; }}
        table {{ width: 100%; border-collapse: collapse; font-size: 0.85rem; }}
        th {{ background: #1a1a2e; color: white; padding: 10px 8px; text-align: left; font-weight: 600; position: sticky; top: 0; }}
        td {{ padding: 8px; border-bottom: 1px solid #eee; vertical-align: top; }}
        tr:hover {{ background: #f8f9fa; }}
        tr.matched {{ background: #f0fff0; }}
        .badge {{ display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 0.75rem; font-weight: 600; }}
        .type-rest {{ background: #d4edda; color: #155724; }}
        .type-soap {{ background: #d1ecf1; color: #0c5460; }}
        .type-onedata {{ background: #fff3cd; color: #856404; }}
        .method {{ display: inline-block; background: #e8e8e8; padding: 2px 8px; border-radius: 4px; font-family: monospace; font-size: 0.8rem; font-weight: 600; }}
        .url-cell {{ font-family: monospace; font-size: 0.8rem; word-break: break-all; max-width: 250px; }}
        .file-cell {{ font-family: monospace; font-size: 0.78rem; word-break: break-all; max-width: 200px; }}
        .code-snippet {{ background: #282c34; color: #abb2bf; padding: 12px; border-radius: 6px; font-size: 0.8rem; overflow-x: auto; white-space: pre-wrap; word-wrap: break-word; margin-top: 6px; }}
        .detail-card {{ border: 1px solid #e0e0e0; border-radius: 8px; margin-bottom: 12px; overflow: hidden; }}
        .detail-header {{ background: #f8f9fa; padding: 10px 16px; border-bottom: 1px solid #e0e0e0; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }}
        .detail-body {{ padding: 16px; }}
        .detail-row {{ margin-bottom: 8px; }}
        .detail-row code {{ background: #f0f0f0; padding: 2px 6px; border-radius: 4px; font-size: 0.85rem; }}
        .line-info {{ color: #6c757d; font-size: 0.8rem; }}
        .match-info {{ background: #d4edda; color: #155724; padding: 6px 12px; border-radius: 6px; margin-top: 6px; font-size: 0.85rem; }}
        .diagram-section {{ margin-bottom: 24px; text-align: center; }}
        .diagram-section h3 {{ margin-bottom: 12px; color: #1a1a2e; }}
        .diagram-section img {{ max-width: 100%; height: auto; border: 1px solid #e0e0e0; border-radius: 8px; }}
        .footer {{ text-align: center; color: #999; font-size: 0.8rem; padding: 20px; }}
        @media print {{
            body {{ background: white; }}
            .container {{ max-width: 100%; padding: 10px; }}
            .section {{ box-shadow: none; border: 1px solid #ddd; page-break-inside: avoid; }}
            .diagram-section {{ page-break-before: always; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Code Lens - API Scan Report</h1>
            <p style="font-size:1.1rem; color:#e0e0e0; margin-bottom:4px;">{source_display}</p>
            <p>Automated API Endpoint Detection for {language} Application</p>
            <div class="timestamp">Generated: {timestamp} | Files Scanned: {scanned_files} / {total_files}</div>
        </div>

        <div class="stats">
            <div class="stat-card"><h3>{len(endpoints)}</h3><p>Total APIs</p></div>
            <div class="stat-card stat-rest"><h3>{rest_count}</h3><p>REST APIs</p></div>
            <div class="stat-card stat-soap"><h3>{soap_count}</h3><p>SOAP APIs</p></div>
            <div class="stat-card stat-onedata"><h3>{onedata_count}</h3><p>OneData</p></div>
            <div class="stat-card stat-matched"><h3>{matched_count}</h3><p>Excel Matched</p></div>
            <div class="stat-card"><h3>{language}</h3><p>Language</p></div>
        </div>

        <div class="section">
            <h2>All Discovered API Endpoints</h2>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>API Type</th>
                            <th>Method</th>
                            <th>URL / Endpoint</th>
                            <th>Function</th>
                            <th>File</th>
                            <th>Line</th>
                            <th>Request</th>
                            <th>Response</th>
                            <th>Matched URL</th>
                            <th>Matched Path</th>
                        </tr>
                    </thead>
                    <tbody>
                        {endpoint_rows}
                    </tbody>
                </table>
            </div>
        </div>

        <div class="section">
            <h2>Excel Match Summary</h2>
            <p><strong>Matched:</strong> {len(matched_eps)} endpoints &nbsp;|&nbsp; <strong>Unmatched:</strong> {len(unmatched_eps)} endpoints</p>
        </div>

        {_onedata_version_section_html(endpoints)}

        <div class="section">
            <h2>Detailed API View</h2>
            {detail_cards}
        </div>

        {"<div class='section'><h2>API Flow Diagrams</h2>" + diagram_html_sections + "</div>" if diagram_html_sections else "<div class='section'><h2>API Flow Diagrams</h2><p style='color:#999;'>Diagrams could not be generated. Ensure Graphviz is installed on the system.</p></div>"}

        <div class="footer">
            Code Lens - API Scan Report | Generated on {timestamp}
        </div>
    </div>
</body>
</html>"""
    return html


def generate_multi_repo_html_report(all_results, language, total_scanned, total_total, overview_diagrams=None, per_repo_diagrams=None):
    """
    Generates one self-contained HTML report covering all repos:
    - Overall summary statistics & analysis (by repo, function, API type)
    - One dedicated section per repo with its own stats, endpoint table, and detail cards
    - Embedded diagrams (overall + per-repo)
    """
    from collections import defaultdict

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    all_endpoints = [ep for r in all_results for ep in r["endpoints"]]

    total_apis    = len(all_endpoints)
    rest_total    = sum(1 for e in all_endpoints if e.api_type == "REST")
    soap_total    = sum(1 for e in all_endpoints if e.api_type == "SOAP")
    od_total      = sum(1 for e in all_endpoints if e.api_type == "OneData")
    matched_total = sum(1 for e in all_endpoints if e.matched_excel_url or e.matched_excel_path)
    unmatched_total = total_apis - matched_total
    num_repos     = len(all_results)

    # ── shared CSS ──────────────────────────────────────────────────────────
    css = """
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; background:#f0f2f5; color:#333; line-height:1.6; }
        a { color:#e94560; text-decoration:none; }
        a:hover { text-decoration:underline; }
        .container { max-width:1400px; margin:0 auto; padding:20px; }
        /* header */
        .header { background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%); padding:30px; border-radius:12px; text-align:center; margin-bottom:24px; }
        .header h1 { color:#e94560; font-size:2rem; margin-bottom:6px; }
        .header p  { color:#a8b2d1; font-size:0.95rem; }
        .header .timestamp { color:#6c7a9a; font-size:0.8rem; margin-top:8px; }
        /* toc */
        .toc { background:#fff; border-radius:10px; padding:20px 28px; margin-bottom:24px; box-shadow:0 2px 4px rgba(0,0,0,.05); }
        .toc h2 { color:#1a1a2e; margin-bottom:12px; font-size:1.1rem; border-bottom:2px solid #e94560; padding-bottom:6px; }
        .toc ul { list-style:none; column-count:2; column-gap:24px; }
        .toc ul li { padding:3px 0; font-size:0.88rem; }
        .toc ul li::before { content:"▸ "; color:#e94560; }
        /* stat cards */
        .stats { display:grid; grid-template-columns:repeat(auto-fit,minmax(130px,1fr)); gap:14px; margin-bottom:24px; }
        .stat-card { background:#fff; border:1px solid #e0e0e0; border-radius:10px; padding:16px; text-align:center; box-shadow:0 2px 4px rgba(0,0,0,.05); }
        .stat-card h3 { font-size:1.8rem; color:#1a1a2e; margin:0; }
        .stat-card p  { color:#6c757d; margin:0; font-size:0.82rem; }
        .stat-rest     { border-left:4px solid #28a745; }
        .stat-soap     { border-left:4px solid #17a2b8; }
        .stat-onedata  { border-left:4px solid #ffc107; }
        .stat-matched  { border-left:4px solid #e94560; }
        .stat-unmatched{ border-left:4px solid #dc3545; }
        /* section */
        .section { background:#fff; border-radius:10px; padding:24px; margin-bottom:24px; box-shadow:0 2px 4px rgba(0,0,0,.05); }
        .section h2 { color:#1a1a2e; border-bottom:3px solid #e94560; padding-bottom:8px; margin-bottom:16px; font-size:1.25rem; }
        .section h3 { color:#1a1a2e; margin:16px 0 10px; font-size:1rem; }
        /* repo section */
        .repo-section { background:#fff; border-radius:10px; padding:24px; margin-bottom:32px; box-shadow:0 3px 8px rgba(0,0,0,.08); border-top:5px solid #e94560; }
        .repo-section h2 { color:#0f3460; border-bottom:2px solid #e0e0e0; padding-bottom:8px; margin-bottom:16px; font-size:1.2rem; }
        /* table */
        table { width:100%; border-collapse:collapse; font-size:0.83rem; }
        th { background:#1a1a2e; color:#fff; padding:9px 8px; text-align:left; font-weight:600; }
        td { padding:7px 8px; border-bottom:1px solid #eee; vertical-align:top; }
        tr:hover { background:#f8f9fa; }
        tr.matched { background:#f0fff0; }
        /* analysis table */
        .analysis-table th { background:#0f3460; }
        .analysis-table tr:nth-child(even) { background:#f8f9fa; }
        /* badges */
        .badge { display:inline-block; padding:2px 9px; border-radius:12px; font-size:0.73rem; font-weight:600; }
        .type-rest     { background:#d4edda; color:#155724; }
        .type-soap     { background:#d1ecf1; color:#0c5460; }
        .type-onedata  { background:#fff3cd; color:#856404; }
        .method { display:inline-block; background:#e8e8e8; padding:2px 7px; border-radius:4px; font-family:monospace; font-size:0.78rem; font-weight:600; }
        .url-cell { font-family:monospace; font-size:0.78rem; word-break:break-all; max-width:240px; }
        .match-yes { color:#155724; font-weight:600; }
        .match-no  { color:#721c24; }
        /* detail cards */
        .detail-card { border:1px solid #e0e0e0; border-radius:8px; margin-bottom:10px; overflow:hidden; }
        .detail-header { background:#f8f9fa; padding:9px 14px; border-bottom:1px solid #e0e0e0; display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
        .detail-body { padding:14px; }
        .detail-row { margin-bottom:7px; }
        .detail-row code { background:#f0f0f0; padding:2px 5px; border-radius:4px; font-size:0.82rem; }
        .line-info { color:#6c757d; font-size:0.78rem; }
        .match-info { background:#d4edda; color:#155724; padding:5px 10px; border-radius:5px; margin-top:5px; font-size:0.82rem; }
        .code-snippet { background:#282c34; color:#abb2bf; padding:10px; border-radius:6px; font-size:0.78rem; overflow-x:auto; white-space:pre-wrap; word-wrap:break-word; margin-top:5px; }
        /* diagrams */
        .diagram-section { margin-bottom:20px; text-align:center; }
        .diagram-section h3 { margin-bottom:10px; color:#1a1a2e; }
        .diagram-section img { max-width:100%; height:auto; border:1px solid #e0e0e0; border-radius:8px; }
        /* progress bar */
        .progress-wrap { background:#e9ecef; border-radius:6px; height:14px; overflow:hidden; margin:4px 0 10px; }
        .progress-bar  { height:14px; border-radius:6px; font-size:0.7rem; line-height:14px; color:#fff; padding:0 6px; white-space:nowrap; }
        .bar-matched   { background:#28a745; }
        .bar-unmatched { background:#dc3545; }
        /* footer */
        .footer { text-align:center; color:#999; font-size:0.78rem; padding:20px; }
        @media print {
            body { background:white; }
            .container { max-width:100%; padding:10px; }
            .section, .repo-section { box-shadow:none; border:1px solid #ddd; page-break-inside:avoid; }
            .diagram-section { page-break-before:always; }
        }
    """

    # ── Table of Contents ────────────────────────────────────────────────────
    toc_items = '<li><a href="#overall-analysis">Overall Analysis</a></li>\n'
    toc_items += '<li><a href="#overall-diagrams">Overall Diagrams</a></li>\n'
    for idx, r in enumerate(all_results):
        safe_id = f"repo-{idx}"
        toc_items += f'<li><a href="#{safe_id}">{_esc(r["source_name"])}</a></li>\n'

    # ── Overall stat cards ───────────────────────────────────────────────────
    overall_stats_html = f"""
    <div class="stats">
        <div class="stat-card"><h3>{num_repos}</h3><p>Repos Scanned</p></div>
        <div class="stat-card"><h3>{total_apis}</h3><p>Total APIs</p></div>
        <div class="stat-card stat-rest"><h3>{rest_total}</h3><p>REST APIs</p></div>
        <div class="stat-card stat-soap"><h3>{soap_total}</h3><p>SOAP APIs</p></div>
        <div class="stat-card stat-onedata"><h3>{od_total}</h3><p>OneData</p></div>
        <div class="stat-card stat-matched"><h3>{matched_total}</h3><p>Matched</p></div>
        <div class="stat-card stat-unmatched"><h3>{unmatched_total}</h3><p>Unmatched</p></div>
    </div>"""

    # ── Analysis: By Repo ────────────────────────────────────────────────────
    repo_analysis_rows = ""
    for r in all_results:
        eps   = r["endpoints"]
        tot   = len(eps)
        mat   = sum(1 for e in eps if e.matched_excel_url or e.matched_excel_path)
        unm   = tot - mat
        rst   = sum(1 for e in eps if e.api_type == "REST")
        sop   = sum(1 for e in eps if e.api_type == "SOAP")
        od    = sum(1 for e in eps if e.api_type == "OneData")
        pct   = int(mat / tot * 100) if tot else 0
        bar   = f"""<div class="progress-wrap">
            <div class="progress-bar bar-matched" style="width:{pct}%;display:inline-block;">{pct}%</div>
        </div>""" if tot else ""
        repo_analysis_rows += f"""
        <tr>
            <td><strong>{_esc(r["source_name"])}</strong></td>
            <td style="text-align:center">{tot}</td>
            <td style="text-align:center;color:#155724;font-weight:600">{mat}</td>
            <td style="text-align:center;color:#721c24">{unm}</td>
            <td style="text-align:center">{rst}</td>
            <td style="text-align:center">{sop}</td>
            <td style="text-align:center">{od}</td>
            <td style="min-width:120px">{bar}</td>
        </tr>"""

    repo_analysis_html = f"""
    <table class="analysis-table">
        <thead><tr>
            <th>Repo / Source</th><th>Total</th><th>Matched</th><th>Unmatched</th>
            <th>REST</th><th>SOAP</th><th>OneData</th><th>Match Rate</th>
        </tr></thead>
        <tbody>{repo_analysis_rows}</tbody>
    </table>"""

    # ── Analysis: By Function (across all repos) ────────────────────────────
    func_data = defaultdict(lambda: {"Total":0,"Matched":0,"Unmatched":0,"REST":0,"SOAP":0,"OneData":0})
    for e in all_endpoints:
        fd = func_data[e.function_name]
        fd["Total"] += 1
        is_m = bool(e.matched_excel_url or e.matched_excel_path)
        fd["Matched"]   += int(is_m)
        fd["Unmatched"] += int(not is_m)
        fd[e.api_type]  = fd.get(e.api_type, 0) + 1
    func_rows_html = ""
    for fn in sorted(func_data):
        fd = func_data[fn]
        func_rows_html += f"""<tr>
            <td>{_esc(fn)}</td>
            <td style="text-align:center">{fd["Total"]}</td>
            <td style="text-align:center;color:#155724;font-weight:600">{fd["Matched"]}</td>
            <td style="text-align:center;color:#721c24">{fd["Unmatched"]}</td>
            <td style="text-align:center">{fd.get("REST",0)}</td>
            <td style="text-align:center">{fd.get("SOAP",0)}</td>
            <td style="text-align:center">{fd.get("OneData",0)}</td>
        </tr>"""
    func_analysis_html = f"""
    <table class="analysis-table">
        <thead><tr>
            <th>Function</th><th>Total</th><th>Matched</th><th>Unmatched</th>
            <th>REST</th><th>SOAP</th><th>OneData</th>
        </tr></thead>
        <tbody>{func_rows_html}</tbody>
    </table>"""

    # ── Analysis: By API Type & HTTP Method ──────────────────────────────────
    type_data = defaultdict(lambda: {"Total":0,"Matched":0,"Unmatched":0})
    for e in all_endpoints:
        key = (e.api_type, e.http_method)
        td = type_data[key]
        td["Total"] += 1
        is_m = bool(e.matched_excel_url or e.matched_excel_path)
        td["Matched"]   += int(is_m)
        td["Unmatched"] += int(not is_m)
    type_rows_html = ""
    for (at, hm) in sorted(type_data):
        td = type_data[(at, hm)]
        type_class = f"type-{at.lower()}"
        type_rows_html += f"""<tr>
            <td><span class="badge {type_class}">{_esc(at)}</span></td>
            <td><span class="method">{_esc(hm)}</span></td>
            <td style="text-align:center">{td["Total"]}</td>
            <td style="text-align:center;color:#155724;font-weight:600">{td["Matched"]}</td>
            <td style="text-align:center;color:#721c24">{td["Unmatched"]}</td>
        </tr>"""
    type_analysis_html = f"""
    <table class="analysis-table">
        <thead><tr>
            <th>API Type</th><th>HTTP Method</th><th>Total</th><th>Matched</th><th>Unmatched</th>
        </tr></thead>
        <tbody>{type_rows_html}</tbody>
    </table>"""

    # ── Function × Repo cross-tab ────────────────────────────────────────────
    cross_data = defaultdict(lambda: {"Total":0,"Matched":0,"Unmatched":0})
    for e in all_endpoints:
        key = (e.function_name, e.source_name)
        cd = cross_data[key]
        cd["Total"] += 1
        is_m = bool(e.matched_excel_url or e.matched_excel_path)
        cd["Matched"]   += int(is_m)
        cd["Unmatched"] += int(not is_m)
    cross_rows_html = ""
    for (fn, rn) in sorted(cross_data):
        cd = cross_data[(fn, rn)]
        cross_rows_html += f"""<tr>
            <td>{_esc(fn)}</td><td>{_esc(rn)}</td>
            <td style="text-align:center">{cd["Total"]}</td>
            <td style="text-align:center;color:#155724;font-weight:600">{cd["Matched"]}</td>
            <td style="text-align:center;color:#721c24">{cd["Unmatched"]}</td>
        </tr>"""
    cross_analysis_html = f"""
    <table class="analysis-table">
        <thead><tr>
            <th>Function</th><th>Repo / Source</th><th>Total</th><th>Matched</th><th>Unmatched</th>
        </tr></thead>
        <tbody>{cross_rows_html}</tbody>
    </table>"""

    # ── Overall diagrams ─────────────────────────────────────────────────────
    overview_diag_html = ""
    if overview_diagrams:
        for title, img_path in overview_diagrams.items():
            b64 = _encode_image_base64(img_path)
            if b64:
                overview_diag_html += f"""
                <div class="diagram-section">
                    <h3>{_esc(title)}</h3>
                    <img src="data:image/png;base64,{b64}" alt="{_esc(title)}" />
                </div>"""

    # ── Per-repo sections ────────────────────────────────────────────────────
    per_repo_html = ""
    per_repo_diagrams = per_repo_diagrams or {}

    for idx, r in enumerate(all_results):
        safe_id  = f"repo-{idx}"
        eps      = r["endpoints"]
        tot      = len(eps)
        mat      = sum(1 for e in eps if e.matched_excel_url or e.matched_excel_path)
        unm      = tot - mat
        rst      = sum(1 for e in eps if e.api_type == "REST")
        sop      = sum(1 for e in eps if e.api_type == "SOAP")
        od       = sum(1 for e in eps if e.api_type == "OneData")
        pct      = int(mat / tot * 100) if tot else 0

        # repo stat cards
        repo_stats = f"""
        <div class="stats" style="grid-template-columns:repeat(auto-fit,minmax(110px,1fr));margin-bottom:16px;">
            <div class="stat-card"><h3>{tot}</h3><p>Total APIs</p></div>
            <div class="stat-card stat-rest"><h3>{rst}</h3><p>REST</p></div>
            <div class="stat-card stat-soap"><h3>{sop}</h3><p>SOAP</p></div>
            <div class="stat-card stat-onedata"><h3>{od}</h3><p>OneData</p></div>
            <div class="stat-card stat-matched"><h3>{mat}</h3><p>Matched</p></div>
            <div class="stat-card stat-unmatched"><h3>{unm}</h3><p>Unmatched</p></div>
            <div class="stat-card"><h3>{pct}%</h3><p>Match Rate</p></div>
        </div>
        <p style="color:#666;font-size:0.85rem;margin-bottom:14px;">
            Language: <strong>{_esc(r.get("language","Unknown"))}</strong> &nbsp;|&nbsp;
            Files scanned: <strong>{r.get("scanned_files",0)}</strong> / {r.get("total_files",0)}
        </p>"""

        # endpoint table
        ep_rows = ""
        for ep in eps:
            match_class  = "matched" if (ep.matched_excel_url or ep.matched_excel_path) else ""
            type_class   = f"type-{_esc(ep.api_type).lower()}"
            matched_cell = f'<span class="match-yes">✔ Yes</span>' if (ep.matched_excel_url or ep.matched_excel_path) else '<span class="match-no">✘ No</span>'
            ep_rows += f"""
            <tr class="{match_class}">
                <td><span class="badge {type_class}">{_esc(ep.api_type)}</span></td>
                <td><span class="method">{_esc(ep.http_method)}</span></td>
                <td class="url-cell">{_esc(ep.url)}</td>
                <td>{_esc(ep.function_name)}</td>
                <td style="font-family:monospace;font-size:0.75rem;word-break:break-all">{_esc(os.path.basename(ep.file_path))}</td>
                <td style="text-align:center">{ep.line_number}</td>
                <td style="font-size:0.78rem">{_esc(ep.request_details)}</td>
                <td style="font-size:0.78rem">{_esc(ep.response_details)}</td>
                <td>{matched_cell}</td>
                <td style="font-size:0.75rem">{_esc(ep.matched_excel_url or ep.matched_excel_path)}</td>
            </tr>"""

        ep_table = f"""
        <div style="overflow-x:auto;">
        <table>
            <thead><tr>
                <th>Type</th><th>Method</th><th>URL / Endpoint</th>
                <th>Function</th><th>File</th><th>Line</th>
                <th>Request</th><th>Response</th><th>Matched</th><th>Match Ref</th>
            </tr></thead>
            <tbody>{ep_rows}</tbody>
        </table></div>"""

        # detail cards
        detail_cards = ""
        for ep in eps:
            match_badge = ""
            if ep.matched_excel_url:
                match_badge += f'<div class="match-info">Matched Excel URL: {_esc(ep.matched_excel_url)}</div>'
            if ep.matched_excel_path:
                match_badge += f'<div class="match-info">Matched Excel Path: {_esc(ep.matched_excel_path)}</div>'
            snippet_html = ""
            if ep.code_snippet:
                snippet_html = f'<div class="detail-row"><strong>Code Context:</strong><pre class="code-snippet">{_esc(ep.code_snippet)}</pre></div>'
            payload_html = ""
            if ep.payload_fields:
                payload_html = f'<div class="detail-row"><strong>Payload Fields:</strong><pre class="code-snippet">{_esc(ep.payload_fields)}</pre></div>'
            type_class = f"type-{_esc(ep.api_type).lower()}"
            detail_cards += f"""
            <div class="detail-card">
                <div class="detail-header">
                    <span class="badge {type_class}">{_esc(ep.api_type)}</span>
                    <span class="method">{_esc(ep.http_method)}</span>
                    <strong>{_esc(ep.function_name)}</strong>
                    <span class="line-info">Line {ep.line_number}</span>
                </div>
                <div class="detail-body">
                    <div class="detail-row"><strong>URL:</strong> <code>{_esc(ep.url)}</code></div>
                    <div class="detail-row"><strong>File:</strong> <code>{_esc(ep.file_path)}</code></div>
                    <div class="detail-row"><strong>Request:</strong> {_esc(ep.request_details)}</div>
                    <div class="detail-row"><strong>Response:</strong> {_esc(ep.response_details)}</div>
                    {payload_html}
                    {match_badge}
                    {snippet_html}
                </div>
            </div>"""

        # per-repo diagrams
        repo_diag_html = ""
        repo_diags = per_repo_diagrams.get(idx, {})
        for title, img_path in repo_diags.items():
            b64 = _encode_image_base64(img_path)
            if b64:
                repo_diag_html += f"""
                <div class="diagram-section">
                    <h3>{_esc(title)}</h3>
                    <img src="data:image/png;base64,{b64}" alt="{_esc(title)}" />
                </div>"""

        per_repo_html += f"""
        <div class="repo-section" id="{safe_id}">
            <h2>📁 {_esc(r["source_name"])}</h2>
            {repo_stats}
            <h3>API Endpoints</h3>
            {ep_table}
            {"<h3>Diagrams</h3>" + repo_diag_html if repo_diag_html else ""}
            <h3>Detailed API Cards</h3>
            {detail_cards if detail_cards else "<p style='color:#999'>No endpoints found in this repo.</p>"}
            <p style="text-align:right;margin-top:12px;font-size:0.8rem;"><a href="#top">↑ Back to top</a></p>
        </div>"""

    # ── Assemble final HTML ──────────────────────────────────────────────────
    final_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Code Lens - Multi-Repo API Scan Report</title>
    <style>{css}</style>
</head>
<body>
<div class="container" id="top">

    <div class="header">
        <h1>Code Lens — Multi-Repo API Scan Report</h1>
        <p style="font-size:1rem;color:#e0e0e0;margin-bottom:4px;">
            {num_repos} repositories &nbsp;·&nbsp; {total_apis} APIs &nbsp;·&nbsp;
            {matched_total} matched &nbsp;·&nbsp; {unmatched_total} unmatched
        </p>
        <p>Language: {_esc(language)}</p>
        <div class="timestamp">Generated: {timestamp} | Total files scanned: {total_scanned} / {total_total}</div>
    </div>

    {overall_stats_html}

    <div class="toc">
        <h2>Table of Contents</h2>
        <ul>{toc_items}</ul>
    </div>

    <!-- OVERALL ANALYSIS -->
    <div class="section" id="overall-analysis">
        <h2>Overall Analysis</h2>

        <h3>By Repo / Source</h3>
        {repo_analysis_html}

        <h3>By Function (All Repos)</h3>
        {func_analysis_html}

        <h3>By Function &amp; Repo</h3>
        {cross_analysis_html}

        <h3>By API Type &amp; HTTP Method</h3>
        {type_analysis_html}
    </div>

    {_onedata_version_section_html(all_endpoints, title="OneData Version Functions — All Repos")}

    <!-- OVERALL DIAGRAMS -->
    <div class="section" id="overall-diagrams">
        <h2>Overall API Flow Diagrams</h2>
        {overview_diag_html if overview_diag_html else "<p style='color:#999'>Diagrams could not be generated.</p>"}
    </div>

    <!-- PER-REPO SECTIONS -->
    {per_repo_html}

    <div class="footer">
        Code Lens – Multi-Repo API Scan Report | Generated {timestamp}
    </div>

</div>
</body>
</html>"""
    return final_html


def generate_excel_report(endpoints, language, scanned_files, total_files, source_name=""):
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        all_data = []
        for ep in endpoints:
            all_data.append({
                "API Type": ep.api_type,
                "HTTP Method": ep.http_method,
                "URL / Endpoint": ep.url,
                "Function Name": ep.function_name,
                "File Path": ep.file_path,
                "Line Number": ep.line_number,
                "Request Details": ep.request_details,
                "Response Details": ep.response_details,
                "Matched Excel URL": ep.matched_excel_url,
                "Matched Excel Path": ep.matched_excel_path,
                "Code Snippet": ep.code_snippet,
            })
        df_all = pd.DataFrame(all_data)
        df_all.to_excel(writer, sheet_name="All Endpoints", index=False)

        matched_data = []
        for ep in endpoints:
            if ep.matched_excel_url or ep.matched_excel_path:
                matched_data.append({
                    "API Type": ep.api_type,
                    "HTTP Method": ep.http_method,
                    "URL / Endpoint": ep.url,
                    "Function Name": ep.function_name,
                    "File Path": ep.file_path,
                    "Line Number": ep.line_number,
                    "Matched Excel URL": ep.matched_excel_url,
                    "Matched Excel Path": ep.matched_excel_path,
                })
        if matched_data:
            pd.DataFrame(matched_data).to_excel(writer, sheet_name="Matched Endpoints", index=False)

        unmatched_data = []
        for ep in endpoints:
            if not ep.matched_excel_url and not ep.matched_excel_path:
                unmatched_data.append({
                    "API Type": ep.api_type,
                    "HTTP Method": ep.http_method,
                    "URL / Endpoint": ep.url,
                    "Function Name": ep.function_name,
                    "File Path": ep.file_path,
                    "Line Number": ep.line_number,
                })
        if unmatched_data:
            pd.DataFrame(unmatched_data).to_excel(writer, sheet_name="Unmatched Endpoints", index=False)

        rest_count = sum(1 for e in endpoints if e.api_type == "REST")
        soap_count = sum(1 for e in endpoints if e.api_type == "SOAP")
        onedata_count = sum(1 for e in endpoints if e.api_type == "OneData")
        matched_count = len(matched_data)

        summary = pd.DataFrame([
            {"Metric": "Source", "Value": source_name or "Unknown"},
            {"Metric": "Language", "Value": language},
            {"Metric": "Total Files", "Value": total_files},
            {"Metric": "Scanned Files", "Value": scanned_files},
            {"Metric": "Total API Endpoints", "Value": len(endpoints)},
            {"Metric": "REST APIs", "Value": rest_count},
            {"Metric": "SOAP APIs", "Value": soap_count},
            {"Metric": "OneData Functions", "Value": onedata_count},
            {"Metric": "Excel Matched", "Value": matched_count},
            {"Metric": "Unmatched", "Value": len(endpoints) - matched_count},
            {"Metric": "Report Generated", "Value": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
        ])
        summary.to_excel(writer, sheet_name="Summary", index=False)

        # OneData version functions sheet
        import re as _re
        from collections import defaultdict
        od_version_eps = [
            e for e in endpoints
            if e.api_type == "OneData" and _re.search(r'v[1-4]', e.http_method or "")
        ]
        if od_version_eps:
            func_agg = defaultdict(lambda: {"Occurrences": 0, "Files": set(), "Lines": [], "Repo": set()})
            for e in od_version_eps:
                key = (e.http_method, e.function_name)
                d = func_agg[key]
                d["Occurrences"] += 1
                d["Files"].add(os.path.basename(e.file_path))
                d["Lines"].append(str(e.line_number))
                if getattr(e, "source_name", ""):
                    d["Repo"].add(e.source_name)
            od_rows = []
            for (ver, fn) in sorted(func_agg.keys()):
                d = func_agg[(ver, fn)]
                od_rows.append({
                    "Version Prefix": ver,
                    "Function Name": fn,
                    "Occurrences": d["Occurrences"],
                    "Files": ", ".join(sorted(d["Files"])),
                    "Line Numbers": ", ".join(d["Lines"]),
                    "Repo / Source": ", ".join(sorted(d["Repo"])),
                })
            pd.DataFrame(od_rows).to_excel(writer, sheet_name="OneData Functions", index=False)

    output.seek(0)
    return output.getvalue()
