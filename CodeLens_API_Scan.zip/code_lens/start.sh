#!/bin/bash
echo "============================================"
echo "  Code Lens - API Scan"
echo "============================================"
echo ""

if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed."
    echo "Please install Python 3.9+ first."
    exit 1
fi

if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

echo "Activating virtual environment..."
source venv/bin/activate

echo "Installing dependencies..."
pip install -r requirements.txt --quiet

echo ""
echo "Starting Code Lens..."
echo "App will open at http://localhost:8501"
echo ""
streamlit run app.py
