import re
import os
import zipfile
import tempfile
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class APIEndpoint:
    url: str
    api_type: str  # REST, SOAP, OneData
    http_method: str
    file_path: str
    line_number: int
    function_name: str
    request_details: str
    response_details: str
    matched_excel_url: str = ""
    matched_excel_path: str = ""
    code_snippet: str = ""
    parameters: str = ""
    operation: str = ""
    payload_fields: str = ""
    source_name: str = ""


JAVA_EXTENSIONS = {".java", ".xml", ".properties", ".yml", ".yaml", ".json", ".wsdl"}
CSHARP_EXTENSIONS = {".cs", ".cshtml", ".config", ".xml", ".json", ".wsdl", ".svc", ".asmx"}


REST_PATTERNS_JAVA = [
    (r'@RequestMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "RequestMapping"),
    (r'@GetMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "GET"),
    (r'@PostMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "POST"),
    (r'@PutMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "PUT"),
    (r'@DeleteMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "DELETE"),
    (r'@PatchMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "PATCH"),
    (r'@GetMapping\s*$', "GET"),
    (r'@PostMapping\s*$', "POST"),
    (r'@PutMapping\s*$', "PUT"),
    (r'@DeleteMapping\s*$', "DELETE"),
    (r'@PatchMapping\s*$', "PATCH"),
    (r'@Path\s*\(\s*["\']([^"\']+)["\']', "JAX-RS Path"),
    (r'@GET\b', "GET"),
    (r'@POST\b', "POST"),
    (r'@PUT\b', "PUT"),
    (r'@DELETE\b', "DELETE"),
]

REST_PATTERNS_CSHARP = [
    (r'\[HttpGet\s*\(\s*["\']([^"\']*)["\']', "GET"),
    (r'\[HttpPost\s*\(\s*["\']([^"\']*)["\']', "POST"),
    (r'\[HttpPut\s*\(\s*["\']([^"\']*)["\']', "PUT"),
    (r'\[HttpDelete\s*\(\s*["\']([^"\']*)["\']', "DELETE"),
    (r'\[HttpPatch\s*\(\s*["\']([^"\']*)["\']', "PATCH"),
    (r'\[HttpGet\]', "GET"),
    (r'\[HttpPost\]', "POST"),
    (r'\[HttpPut\]', "PUT"),
    (r'\[HttpDelete\]', "DELETE"),
    (r'\[HttpPatch\]', "PATCH"),
    (r'\[Route\s*\(\s*["\']([^"\']+)["\']', "Route"),
    (r'\[ApiController\]', "ApiController"),
]

SOAP_PATTERNS_JAVA = [
    (r'@WebService\b', "WebService"),
    (r'@WebMethod\b', "WebMethod"),
    (r'@SOAPBinding\b', "SOAPBinding"),
    (r'@WebResult\b', "WebResult"),
    (r'@WebParam\b', "WebParam"),
    (r'SOAPConnectionFactory', "SOAPConnectionFactory"),
    (r'SOAPConnection', "SOAPConnection"),
    (r'SOAPMessage', "SOAPMessage"),
    (r'MessageFactory\.newInstance', "SOAPMessageFactory"),
    (r'SOAPEnvelope', "SOAPEnvelope"),
    (r'SOAPBody', "SOAPBody"),
    (r'<wsdl:service\s', "WSDL Service"),
    (r'<wsdl:operation\s', "WSDL Operation"),
    (r'<soap:address\s+location\s*=\s*["\']([^"\']+)["\']', "SOAP Address"),
]

SOAP_PATTERNS_CSHARP = [
    (r'\[WebService\b', "WebService"),
    (r'\[WebMethod\b', "WebMethod"),
    (r'\[SoapHeader\b', "SoapHeader"),
    (r'\[SoapDocumentMethod\b', "SoapDocumentMethod"),
    (r'SoapHttpClientProtocol', "SoapClient"),
    (r'ServiceContract', "WCF ServiceContract"),
    (r'OperationContract', "WCF OperationContract"),
    (r'BasicHttpBinding', "WCF BasicHttpBinding"),
    (r'WSHttpBinding', "WCF WSHttpBinding"),
    (r'\.asmx', "ASMX WebService"),
    (r'<wsdl:service\s', "WSDL Service"),
    (r'<soap:address\s+location\s*=\s*["\']([^"\']+)["\']', "SOAP Address"),
]

ONEDATA_PATTERNS = [
    (r'OneData\.(?:get|fetch|query|read|load|retrieve)\s*\(', "OneData Read"),
    (r'OneData\.(?:post|create|insert|save|add|write)\s*\(', "OneData Write"),
    (r'OneData\.(?:update|modify|patch)\s*\(', "OneData Update"),
    (r'OneData\.(?:delete|remove)\s*\(', "OneData Delete"),
    (r'onedata\.(?:get|fetch|query|read|load|retrieve)\s*\(', "onedata Read"),
    (r'onedata\.(?:post|create|insert|save|add|write)\s*\(', "onedata Write"),
    (r'onedata\.(?:update|modify|patch)\s*\(', "onedata Update"),
    (r'onedata\.(?:delete|remove)\s*\(', "onedata Delete"),
    (r'OneDataService\s*\.', "OneDataService Call"),
    (r'OneDataClient\s*\.', "OneDataClient Call"),
    (r'IOneData\s*\.', "IOneData Interface Call"),
    (r'oneDataFunction\s*\(', "OneData Function"),
    (r'OneDataFunction\s*\(', "OneData Function"),
    (r'@OneData\b', "OneData Annotation"),
    (r'onedata[-_]api', "OneData API Reference"),
    (r'OneDataRequest', "OneData Request"),
    (r'OneDataResponse', "OneData Response"),
]

URL_CALL_PATTERNS = [
    (r'new\s+URL\s*\(\s*["\']([^"\']+)["\']', "Java URL"),
    (r'HttpClient\s*.*?\.(?:GetAsync|PostAsync|PutAsync|DeleteAsync|SendAsync)\s*\(\s*["\']([^"\']+)["\']', "C# HttpClient"),
    (r'WebClient\s*.*?\.(?:Download|Upload)\w+\s*\(\s*["\']([^"\']+)["\']', "C# WebClient"),
    (r'RestTemplate\s*.*?\.(?:getForObject|postForObject|exchange|getForEntity)\s*\(\s*["\']([^"\']+)["\']', "Java RestTemplate"),
    (r'WebTarget\s*.*?\.(?:path|request)\s*\(\s*["\']([^"\']+)["\']', "JAX-RS WebTarget"),
    (r'HttpURLConnection', "Java HttpURLConnection"),
    (r'HttpRequest\.newBuilder\(\)\s*\.uri\(URI\.create\(\s*["\']([^"\']+)["\']', "Java HttpClient"),
    (r'fetch\s*\(\s*["\']([^"\']+)["\']', "Fetch Call"),
    (r'axios\.\w+\s*\(\s*["\']([^"\']+)["\']', "Axios Call"),
    (r'["\']https?://[^"\']+["\']', "URL String"),
]


def extract_source_files(uploaded_file):
    temp_dir = tempfile.mkdtemp()
    zip_path = os.path.join(temp_dir, "source.zip")

    with open(zip_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    extract_dir = os.path.join(temp_dir, "source")
    os.makedirs(extract_dir, exist_ok=True)

    try:
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(extract_dir)
    except zipfile.BadZipFile:
        shutil.rmtree(temp_dir)
        return None, "Invalid ZIP file. Please upload a valid ZIP archive."

    return extract_dir, None


ALLOWED_GIT_HOSTS = [
    "github.com",
    "github.aexp.com",
    "gitlab.com",
    "bitbucket.org",
    "dev.azure.com",
    "ssh.dev.azure.com",
]

MAX_SCAN_FILES = 5000


def _validate_git_url(repo_url):
    if not repo_url.startswith("https://"):
        return False, "Only HTTPS Git URLs are supported. URLs starting with git://, ssh://, or file:// are not allowed."
    from urllib.parse import urlparse
    parsed = urlparse(repo_url)
    host = parsed.hostname
    if not host:
        return False, "Invalid Git URL format."
    host_lower = host.lower()
    if not any(host_lower == allowed or host_lower.endswith("." + allowed) for allowed in ALLOWED_GIT_HOSTS):
        return False, f"Git host '{host}' is not supported. Allowed hosts: {', '.join(ALLOWED_GIT_HOSTS)}"
    return True, ""


def clone_git_repo(repo_url, branch=None):
    valid, msg = _validate_git_url(repo_url)
    if not valid:
        return None, msg

    temp_dir = tempfile.mkdtemp()
    clone_dir = os.path.join(temp_dir, "source")

    cmd = ["git", "clone", "--depth", "1"]
    if branch:
        cmd.extend(["-b", branch])
    cmd.extend([repo_url, clone_dir])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            shutil.rmtree(temp_dir, ignore_errors=True)
            error_msg = result.stderr.strip()
            if "could not read Username" in error_msg or "Authentication failed" in error_msg:
                return None, (
                    "Authentication required. For private repos, use a URL with a token: "
                    "https://<token>@github.com/user/repo.git"
                )
            return None, f"Git clone failed: {error_msg}"
    except subprocess.TimeoutExpired:
        shutil.rmtree(temp_dir, ignore_errors=True)
        return None, "Git clone timed out after 120 seconds. The repository may be too large."
    except FileNotFoundError:
        shutil.rmtree(temp_dir, ignore_errors=True)
        return None, "Git is not installed on this system."

    return clone_dir, None


def detect_language(source_dir):
    java_count = 0
    csharp_count = 0

    for root, _, files in os.walk(source_dir):
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext == ".java":
                java_count += 1
            elif ext == ".cs":
                csharp_count += 1

    if java_count > csharp_count:
        return "Java"
    elif csharp_count > java_count:
        return "C#"
    elif java_count > 0:
        return "Java"
    elif csharp_count > 0:
        return "C#"
    return "Unknown"


def get_relevant_extensions(language):
    if language == "Java":
        return JAVA_EXTENSIONS
    elif language == "C#":
        return CSHARP_EXTENSIONS
    return JAVA_EXTENSIONS | CSHARP_EXTENSIONS


def read_file_safe(file_path):
    encodings = ["utf-8", "latin-1", "cp1252"]
    for enc in encodings:
        try:
            with open(file_path, "r", encoding=enc) as f:
                return f.read()
        except (UnicodeDecodeError, PermissionError):
            continue
    return None


def extract_function_name(lines, line_idx, language):
    if language == "Java":
        for i in range(line_idx, min(line_idx + 5, len(lines))):
            match = re.search(
                r'(?:public|private|protected)?\s*(?:static\s+)?(?:\w+(?:<[^>]+>)?)\s+(\w+)\s*\(',
                lines[i],
            )
            if match:
                return match.group(1)
    elif language == "C#":
        for i in range(line_idx, min(line_idx + 5, len(lines))):
            match = re.search(
                r'(?:public|private|protected|internal)?\s*(?:static\s+)?(?:async\s+)?(?:\w+(?:<[^>]+>)?)\s+(\w+)\s*\(',
                lines[i],
            )
            if match:
                return match.group(1)
    return "Unknown"


def extract_method_parameters(lines, line_idx, language):
    context_start = line_idx
    context_end = min(len(lines), line_idx + 15)
    context = "\n".join(lines[context_start:context_end])

    sig_match = re.search(r'\w+\s*\(([^)]*)\)', context, re.DOTALL)
    if not sig_match:
        return []

    param_str = sig_match.group(1).strip()
    if not param_str:
        return []

    params = []
    skip_types = {
        "HttpServletRequest", "HttpServletResponse", "HttpSession",
        "Model", "ModelMap", "ModelAndView", "BindingResult",
        "RedirectAttributes", "UriComponentsBuilder", "Errors",
        "HttpContext", "CancellationToken", "IFormFile",
    }

    raw_params = []
    depth = 0
    current = ""
    for ch in param_str:
        if ch in ("<", "["):
            depth += 1
            current += ch
        elif ch in (">", "]"):
            depth -= 1
            current += ch
        elif ch == "," and depth == 0:
            raw_params.append(current.strip())
            current = ""
        else:
            current += ch
    if current.strip():
        raw_params.append(current.strip())

    for raw in raw_params:
        raw = raw.strip()
        if not raw:
            continue

        raw = re.sub(r'@\w+(?:\([^)]*\))?\s*', '', raw).strip()
        raw = re.sub(r'\[[\w,\s]+\]\s*', '', raw).strip()

        if language == "Java":
            raw = re.sub(r'\b(final)\b\s*', '', raw).strip()

        parts = raw.split()
        if len(parts) >= 2:
            param_type = " ".join(parts[:-1])
            param_name = parts[-1]

            base_type = param_type.split("<")[0].split("[")[0].split(".")[-1]
            if base_type in skip_types:
                continue

            params.append({"type": param_type, "name": param_name})
        elif len(parts) == 1 and language == "C#":
            params.append({"type": "var", "name": parts[0]})

    return params


def extract_request_response(lines, line_idx, language):
    request_details = []
    response_details = []
    param_list = []

    context_start = max(0, line_idx - 3)
    context_end = min(len(lines), line_idx + 20)
    context = "\n".join(lines[context_start:context_end])

    annotated_param_patterns = [
        (r'@RequestBody\s+(\w+(?:<[^>]+>)?)\s+(\w+)', "Body", "{1}", "{0}"),
        (r'@PathVariable\s+(?:\(\s*["\']?\w+["\']?\s*\)\s*)?(\w+)\s+(\w+)', "Path", "{1}", "{0}"),
        (r'@RequestParam\s+(?:\(\s*["\']?\w+["\']?\s*\)\s*)?(\w+)\s+(\w+)', "Query", "{1}", "{0}"),
        (r'@RequestHeader\s+(?:\(\s*["\']?\w+["\']?\s*\)\s*)?(\w+)\s+(\w+)', "Header", "{1}", "{0}"),
        (r'\[FromBody\]\s*(\w+)\s+(\w+)', "Body", "{1}", "{0}"),
        (r'\[FromQuery\]\s*(\w+)\s+(\w+)', "Query", "{1}", "{0}"),
        (r'\[FromRoute\]\s*(\w+)\s+(\w+)', "Route", "{1}", "{0}"),
        (r'\[FromHeader\]\s*(\w+)\s+(\w+)', "Header", "{1}", "{0}"),
    ]

    annotated_names = set()
    for pattern, source, name_fmt, type_fmt in annotated_param_patterns:
        matches = re.findall(pattern, context)
        for m in matches:
            p_name = name_fmt.format(*m)
            p_type = type_fmt.format(*m)
            request_details.append(f"{source}: {p_name} ({p_type})")
            param_list.append(f"{source} | {p_type} | {p_name}")
            annotated_names.add(p_name)

    method_params = extract_method_parameters(lines, line_idx, language)
    for mp in method_params:
        if mp["name"] not in annotated_names:
            request_details.append(f"Param: {mp['name']} ({mp['type']})")
            param_list.append(f"Param | {mp['type']} | {mp['name']}")

    java_return_patterns = [
        r'(?:public|private|protected)\s+(?:static\s+)?(?:final\s+)?ResponseEntity<([^>]+)>\s+\w+\s*\(',
        r'(?:public|private|protected)\s+(?:static\s+)?(?:final\s+)?Mono<([^>]+)>\s+\w+\s*\(',
        r'(?:public|private|protected)\s+(?:static\s+)?(?:final\s+)?Flux<([^>]+)>\s+\w+\s*\(',
        r'(?:public|private|protected)\s+(?:static\s+)?(?:final\s+)?CompletableFuture<([^>]+)>\s+\w+\s*\(',
        r'(?:public|private|protected)\s+(?:static\s+)?(?:final\s+)?Optional<([^>]+)>\s+\w+\s*\(',
        r'(?:public|private|protected)\s+(?:static\s+)?(?:final\s+)?(\w+(?:<[^>]+>)?)\s+\w+\s*\(',
    ]

    csharp_return_patterns = [
        r'(?:public|private|protected|internal)\s+(?:static\s+)?(?:async\s+)?Task<ActionResult<([^>]+)>>\s+\w+\s*\(',
        r'(?:public|private|protected|internal)\s+(?:static\s+)?(?:async\s+)?ActionResult<([^>]+)>\s+\w+\s*\(',
        r'(?:public|private|protected|internal)\s+(?:static\s+)?(?:async\s+)?Task<([^>]+)>\s+\w+\s*\(',
        r'(?:public|private|protected|internal)\s+(?:static\s+)?(?:async\s+)?(\w+(?:<[^>]+>)?)\s+\w+\s*\(',
    ]

    skip_return_types = {"void", "Task", "IActionResult", "ActionResult", "override", "abstract", "class", "interface", "if", "for", "while", "switch", "try", "catch"}

    if language == "Java":
        for ret_pat in java_return_patterns:
            ret_match = re.search(ret_pat, context)
            if ret_match:
                ret_type = ret_match.group(1)
                if ret_type and ret_type not in skip_return_types:
                    response_details.append(f"Returns: {ret_type}")
                    break
    elif language == "C#":
        for ret_pat in csharp_return_patterns:
            ret_match = re.search(ret_pat, context)
            if ret_match:
                ret_type = ret_match.group(1)
                if ret_type and ret_type not in skip_return_types:
                    response_details.append(f"Returns: {ret_type}")
                    break

    return_patterns = [
        r'return\s+(?:new\s+)?ResponseEntity[^;]+',
        r'return\s+(?:new\s+)?(?:Ok|BadRequest|NotFound|Created|NoContent)\s*\([^)]*\)',
        r'return\s+Json\s*\([^)]*\)',
    ]
    for pat in return_patterns:
        match = re.search(pat, context)
        if match:
            response_details.append(f"Response: {match.group(0).strip()[:80]}")

    if not response_details:
        body_end = min(len(lines), line_idx + 40)
        body_context = "\n".join(lines[line_idx:body_end])

        body_ret_patterns = [
            (r'return\s+new\s+(\w+)\s*\(', "Returns: {0}"),
            (r'return\s+(\w+)Service\.\w+\(', "Returns: {0} service result"),
            (r'return\s+(\w+)Repository\.\w+\(', "Returns: {0} repository result"),
            (r'return\s+(\w+)Dao\.\w+\(', "Returns: {0} DAO result"),
            (r'\.body\(\s*(\w+)', "Returns: {0}"),
        ]
        for pat, fmt in body_ret_patterns:
            m = re.search(pat, body_context)
            if m:
                val = m.group(1)
                if val and val[0].isupper() and val not in skip_return_types:
                    response_details.append(fmt.format(val))
                    break

    req_str = "; ".join(request_details) if request_details else "Not detected"
    resp_str = "; ".join(response_details) if response_details else "Not detected"
    params_str = "\n".join(param_list) if param_list else ""
    return req_str, resp_str, params_str


def extract_code_snippet(lines, line_idx, context=3):
    start = max(0, line_idx - context)
    end = min(len(lines), line_idx + context + 1)
    snippet_lines = []
    for i in range(start, end):
        prefix = ">>> " if i == line_idx else "    "
        snippet_lines.append(f"{prefix}{i + 1}: {lines[i]}")
    return "\n".join(snippet_lines)


def extract_class_path(lines, language):
    if language == "Java":
        class_match = None
        for line in lines:
            m = re.search(r'@RequestMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', line)
            if m:
                class_match = m.group(1)
                break
        return class_match
    elif language == "C#":
        for line in lines:
            m = re.search(r'\[Route\s*\(\s*["\']([^"\']+)["\']', line)
            if m:
                return m.group(1)
    return None


def detect_operation(http_method, function_name, url, api_type):
    method_upper = http_method.upper()
    func_lower = function_name.lower()
    url_lower = url.lower()

    method_map = {
        "GET": "READ",
        "POST": "CREATE",
        "PUT": "UPDATE",
        "PATCH": "UPDATE",
        "DELETE": "DELETE",
        "HEAD": "READ",
        "OPTIONS": "READ",
    }

    if method_upper in method_map:
        op = method_map[method_upper]
        create_words = ("create", "add", "insert", "save", "register", "signup", "new", "post")
        read_words = ("get", "find", "fetch", "list", "search", "read", "load", "retrieve", "query", "show", "view", "select", "count")
        update_words = ("update", "edit", "modify", "patch", "change", "set", "replace", "put")
        delete_words = ("delete", "remove", "destroy", "drop", "purge", "cancel", "revoke")

        if any(w in func_lower for w in delete_words):
            return "DELETE"
        if any(w in func_lower for w in create_words):
            return "CREATE"
        if any(w in func_lower for w in update_words):
            return "UPDATE"
        if any(w in func_lower for w in read_words):
            return "READ"
        return op

    if api_type == "SOAP":
        if any(w in func_lower or w in url_lower for w in ("get", "find", "fetch", "list", "search", "read", "query", "retrieve", "select")):
            return "READ"
        if any(w in func_lower or w in url_lower for w in ("create", "add", "insert", "save", "register", "new")):
            return "CREATE"
        if any(w in func_lower or w in url_lower for w in ("update", "edit", "modify", "change", "set")):
            return "UPDATE"
        if any(w in func_lower or w in url_lower for w in ("delete", "remove", "destroy", "drop", "cancel")):
            return "DELETE"
        return "READ"

    if any(w in func_lower or w in url_lower for w in ("get", "find", "fetch", "list", "read", "query", "search", "retrieve", "select")):
        return "READ"
    if any(w in func_lower or w in url_lower for w in ("create", "add", "insert", "save", "new", "post")):
        return "CREATE"
    if any(w in func_lower or w in url_lower for w in ("update", "edit", "modify", "put", "patch", "set")):
        return "UPDATE"
    if any(w in func_lower or w in url_lower for w in ("delete", "remove", "destroy", "drop")):
        return "DELETE"

    return "READ"


def build_class_field_index(source_dir, language):
    extensions = {".java"} if language == "Java" else {".cs"}
    class_index = {}

    primitive_types = {
        "int", "long", "float", "double", "boolean", "char", "byte", "short",
        "Integer", "Long", "Float", "Double", "Boolean", "Character", "Byte", "Short",
        "String", "string", "BigDecimal", "BigInteger", "Date", "LocalDate",
        "LocalDateTime", "Instant", "UUID", "Object", "object",
        "DateTime", "DateTimeOffset", "Guid", "decimal", "bool",
    }

    for root, _, files in os.walk(source_dir):
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in extensions:
                continue
            full_path = os.path.join(root, fname)
            content = read_file_safe(full_path)
            if not content:
                continue

            lines = content.split("\n")

            if language == "Java":
                class_pattern = re.compile(
                    r'(?:public\s+)?(?:class|record|interface)\s+(\w+)'
                )
                field_patterns = [
                    re.compile(r'^\s*(?:private|protected|public)?\s*(?:static\s+)?(?:final\s+)?(\w+(?:<[^>]+>)?(?:\[\])?)\s+(\w+)\s*[;=]'),
                    re.compile(r'^\s*(?:private|protected|public)?\s*(?:static\s+)?(?:final\s+)?(\w+(?:<[^>]+>)?(?:\[\])?)\s+(\w+)\s*\('),
                ]
            else:
                class_pattern = re.compile(
                    r'(?:public\s+)?(?:class|record|struct|interface)\s+(\w+)'
                )
                field_patterns = [
                    re.compile(r'^\s*(?:public|private|protected|internal)?\s*(?:static\s+)?(?:virtual\s+)?(\w+(?:<[^>]+>)?(?:\[\])?(?:\?)?)\s+(\w+)\s*\{'),
                    re.compile(r'^\s*(?:public|private|protected|internal)?\s*(?:static\s+)?(\w+(?:<[^>]+>)?(?:\[\])?(?:\?)?)\s+(\w+)\s*[;=]'),
                ]

            current_class = None
            brace_depth = 0
            class_start_depth = 0

            for line in lines:
                open_braces = line.count("{")
                close_braces = line.count("}")

                if current_class is None:
                    cm = class_pattern.search(line)
                    if cm:
                        current_class = cm.group(1)
                        class_start_depth = brace_depth
                        if current_class not in class_index:
                            class_index[current_class] = []

                brace_depth += open_braces - close_braces

                if current_class and brace_depth > class_start_depth:
                    for fp in field_patterns:
                        fm = fp.search(line)
                        if fm:
                            f_type = fm.group(1)
                            f_name = fm.group(2)
                            base = f_type.split("<")[0].split("[")[0].replace("?", "")
                            skip_names = {"class", "return", "if", "else", "for", "while", "switch", "try", "catch", "new", "void", "throws", "override", "virtual", "abstract", "static"}
                            skip_types = {"void", "class", "return", "if", "else", "for", "while"}
                            if f_name.lower() not in skip_names and base.lower() not in skip_types:
                                getter_pattern = re.compile(rf'(?:get|set){re.escape(f_name)}\s*\(', re.IGNORECASE)
                                is_getter = bool(getter_pattern.search(line))
                                if not is_getter and f_name[0].islower() or (language == "C#" and f_name[0].isupper()):
                                    class_index.setdefault(current_class, [])
                                    entry = f"{f_type} {f_name}"
                                    if entry not in class_index[current_class]:
                                        class_index[current_class].append(entry)
                            break

                if current_class and brace_depth <= class_start_depth:
                    current_class = None

    return class_index


PRIMITIVE_TYPES = {
    "int", "long", "float", "double", "boolean", "char", "byte", "short",
    "Integer", "Long", "Float", "Double", "Boolean", "Character", "Byte", "Short",
    "String", "string", "BigDecimal", "BigInteger", "Date", "LocalDate",
    "LocalDateTime", "Instant", "UUID", "Object", "object",
    "DateTime", "DateTimeOffset", "Guid", "decimal", "bool",
    "void", "Void",
}

WRAPPER_TYPES = {
    "List", "ArrayList", "LinkedList", "Set", "HashSet", "TreeSet",
    "Map", "HashMap", "TreeMap", "LinkedHashMap",
    "Collection", "Iterable", "Optional", "ResponseEntity",
    "IActionResult", "ActionResult", "Task", "IEnumerable",
    "ICollection", "IList", "IReadOnlyList", "IReadOnlyCollection",
    "Page", "Slice", "Stream",
}


def _expand_class_fields(class_name, class_index, indent, visited, max_depth=4):
    if class_name in PRIMITIVE_TYPES or class_name in WRAPPER_TYPES:
        return []
    if class_name in visited:
        return [f"{indent}{class_name} (circular reference)"]
    if class_name not in class_index or not class_index[class_name]:
        return []
    if len(visited) >= max_depth:
        return [f"{indent}{class_name} (max depth reached)"]

    visited = visited | {class_name}
    lines = []
    for field_str in class_index[class_name]:
        parts = field_str.split()
        if len(parts) < 2:
            continue
        f_type = " ".join(parts[:-1])
        f_name = parts[-1]

        base_type = f_type.split("<")[0].split("[")[0].replace("?", "").split(".")[-1]

        inner_type = None
        generic_match = re.search(r'<(\w+)', f_type)
        if generic_match:
            inner_type = generic_match.group(1)

        if base_type in PRIMITIVE_TYPES:
            lines.append(f"{indent}{f_type} {f_name}")
        elif base_type in WRAPPER_TYPES:
            if inner_type and inner_type not in PRIMITIVE_TYPES and inner_type in class_index:
                lines.append(f"{indent}{f_type} {f_name}")
                nested = _expand_class_fields(inner_type, class_index, indent + "    ", visited, max_depth)
                lines.extend(nested)
            else:
                lines.append(f"{indent}{f_type} {f_name}")
        elif base_type in class_index:
            lines.append(f"{indent}{f_type} {f_name}")
            nested = _expand_class_fields(base_type, class_index, indent + "    ", visited, max_depth)
            lines.extend(nested)
        else:
            lines.append(f"{indent}{f_type} {f_name}")

    return lines


def resolve_payload_fields(endpoint, class_index, language):
    body_types = set()
    response_types = set()

    context = endpoint.request_details + " " + endpoint.parameters
    body_matches = re.findall(r'Body[^|]*\|\s*(\w+)', context)
    for bt in body_matches:
        base = bt.split("<")[0].split("[")[0]
        body_types.add(base)

    param_matches = re.findall(r'\((\w+(?:<[^>]+>)?)\)', endpoint.request_details)
    for pm in param_matches:
        base = pm.split("<")[0].split("[")[0]
        body_types.add(base)

    param_type_matches = re.findall(r'Param\s*\|\s*(\w+(?:<[^>]+>)?)\s*\|', endpoint.parameters)
    for pt in param_type_matches:
        base = pt.split("<")[0].split("[")[0]
        if base not in PRIMITIVE_TYPES and base not in WRAPPER_TYPES and base in class_index:
            body_types.add(base)

    resp_matches = re.findall(r'Returns:\s*(\w+)', endpoint.response_details)
    for rm in resp_matches:
        base = rm.split("<")[0].split("[")[0]
        response_types.add(base)
        generic_match = re.search(r'Returns:\s*\w+<(\w+)', endpoint.response_details)
        if generic_match:
            inner = generic_match.group(1)
            if inner not in PRIMITIVE_TYPES:
                response_types.add(inner)

    payload_lines = []

    for bt in sorted(body_types):
        if bt in PRIMITIVE_TYPES or bt in WRAPPER_TYPES:
            continue
        if bt in class_index and class_index[bt]:
            payload_lines.append(f"REQUEST BODY ({bt}):")
            nested = _expand_class_fields(bt, class_index, "  ", set(), max_depth=4)
            payload_lines.extend(nested)

    for rt in sorted(response_types):
        if rt in PRIMITIVE_TYPES or rt in WRAPPER_TYPES:
            continue
        if rt in class_index and class_index[rt]:
            already_shown = any(line == f"REQUEST BODY ({rt}):" for line in payload_lines)
            if already_shown:
                payload_lines.append(f"RESPONSE ({rt}): (same as request body above)")
            else:
                payload_lines.append(f"RESPONSE ({rt}):")
                nested = _expand_class_fields(rt, class_index, "  ", set(), max_depth=4)
                payload_lines.extend(nested)

    return "\n".join(payload_lines)


CONFIG_API_PATTERNS_YML = [
    re.compile(r'^\s*(?:[\w.-]+\s*:\s*)?(?:apiUrl|api-url|api\.url|api_url)\s*:\s*["\']?(/[^\s"\'#]+|https?://[^\s"\'#]+)', re.IGNORECASE),
    re.compile(r'^\s*(?:[\w.-]+\s*:\s*)?(?:endpoint|end-point|end_point)\s*:\s*["\']?(/[^\s"\'#]+|https?://[^\s"\'#]+)', re.IGNORECASE),
    re.compile(r'^\s*(?:[\w.-]+\s*:\s*)?(?:base-url|base\.url|base_url|baseUrl|baseURL)\s*:\s*["\']?(/[^\s"\'#]+|https?://[^\s"\'#]+)', re.IGNORECASE),
    re.compile(r'^\s*(?:[\w.-]+\s*:\s*)?(?:service-url|service\.url|service_url|serviceUrl)\s*:\s*["\']?(/[^\s"\'#]+|https?://[^\s"\'#]+)', re.IGNORECASE),
    re.compile(r'^\s*(?:[\w.-]+\s*:\s*)?(?:uri|URI)\s*:\s*["\']?(/[^\s"\'#]+|https?://[^\s"\'#]+)', re.IGNORECASE),
    re.compile(r'^\s*(?:[\w.-]+\s*:\s*)?(?:url|URL)\s*:\s*["\']?(/api[^\s"\'#]+|https?://[^\s"\'#]+)', re.IGNORECASE),
    re.compile(r'^\s*(?:[\w.-]+\s*:\s*)?(?:path)\s*:\s*["\']?(/api[^\s"\'#]+)', re.IGNORECASE),
]

CONFIG_API_PATTERNS_PROPS = [
    re.compile(r'^[\w.-]*(?:apiUrl|api\.url|api-url|api_url)\s*=\s*["\']?(/[^\s"\']+|https?://[^\s"\']+)', re.IGNORECASE),
    re.compile(r'^[\w.-]*(?:endpoint|end\.point)\s*=\s*["\']?(/[^\s"\']+|https?://[^\s"\']+)', re.IGNORECASE),
    re.compile(r'^[\w.-]*(?:base\.url|base-url|baseUrl)\s*=\s*["\']?(/[^\s"\']+|https?://[^\s"\']+)', re.IGNORECASE),
    re.compile(r'^[\w.-]*(?:service\.url|service-url|serviceUrl)\s*=\s*["\']?(/[^\s"\']+|https?://[^\s"\']+)', re.IGNORECASE),
    re.compile(r'^[\w.-]*(?:uri|URI)\s*=\s*["\']?(/[^\s"\']+|https?://[^\s"\']+)', re.IGNORECASE),
    re.compile(r'^[\w.-]*(?:url|URL)\s*=\s*["\']?(/api[^\s"\']+|https?://[^\s"\']+)', re.IGNORECASE),
]

CONFIG_API_PATTERNS_JSON = [
    re.compile(r'["\'](?:apiUrl|api-url|api_url|api\.url|endpoint|base-url|baseUrl|base_url|service-url|serviceUrl|service_url|uri|url|URL|path)["\']\s*:\s*["\'](/[^"\']+|https?://[^"\']+)["\']', re.IGNORECASE),
]

CONFIG_EXTENSIONS = {".yml", ".yaml", ".properties", ".json", ".xml", ".config"}


def _infer_service_name_from_context(lines, line_idx):
    skip_names = {
        "spring", "server", "app", "application", "config", "configuration",
        "true", "false", "timeout", "retry", "cache", "async",
        "apiurl", "api-url", "api.url", "api_url", "endpoint", "end-point",
        "base-url", "base.url", "baseurl", "base_url",
        "service-url", "service.url", "serviceurl", "service_url",
        "uri", "url", "path", "port", "host", "scheme", "protocol",
        "api", "base", "service", "services", "external", "internal",
        "http", "https", "rest", "soap", "ws", "web",
    }

    current_line = lines[line_idx].strip()
    key_part = current_line.split(":")[0].strip() if ":" in current_line else current_line.split("=")[0].strip()
    key_segments = re.split(r'[.\-_]', key_part)
    for seg in key_segments:
        if seg.lower() not in skip_names and len(seg) > 1:
            return seg[0].upper() + seg[1:]

    current_indent = len(lines[line_idx]) - len(lines[line_idx].lstrip())
    for i in range(line_idx - 1, max(line_idx - 20, -1), -1):
        ln = lines[i]
        if not ln.strip() or ln.strip().startswith("#"):
            continue
        ln_indent = len(ln) - len(ln.lstrip())
        if ln_indent < current_indent:
            parent_key = ln.strip().rstrip(":").split(":")[0].strip()
            parent_segments = re.split(r'[.\-_]', parent_key)
            for seg in parent_segments:
                if seg.lower() not in skip_names and len(seg) > 1:
                    return seg[0].upper() + seg[1:]
            current_indent = ln_indent

    for i in range(line_idx - 1, max(line_idx - 10, -1), -1):
        line = lines[i].strip().rstrip(":")
        if line and not line.startswith("#") and not line.startswith("//"):
            stripped = line.strip()
            stripped = stripped.split(":")[0].strip() if ":" in stripped else stripped.split("=")[0].strip()
            segments = re.split(r'[.\-_]', stripped)
            for seg in reversed(segments):
                if seg.lower() not in skip_names and len(seg) > 1:
                    return seg[0].upper() + seg[1:]
    return "ConfigEndpoint"


def _infer_http_method_from_url(url):
    url_lower = url.lower()
    if any(w in url_lower for w in ("/create", "/add", "/save", "/insert", "/register", "/send", "/post", "/submit", "/upload")):
        return "POST"
    if any(w in url_lower for w in ("/update", "/edit", "/modify", "/patch", "/change")):
        return "PUT"
    if any(w in url_lower for w in ("/delete", "/remove", "/destroy", "/purge", "/cancel")):
        return "DELETE"
    return "GET"


def _extract_yml_sibling_properties(lines, line_idx):
    current_indent = len(lines[line_idx]) - len(lines[line_idx].lstrip())
    props = {}

    for i in range(line_idx, -1, -1):
        ln = lines[i]
        if not ln.strip() or ln.strip().startswith("#"):
            if i < line_idx:
                continue
            else:
                break
        ln_indent = len(ln) - len(ln.lstrip())
        if ln_indent < current_indent and i < line_idx:
            break
        if ln_indent == current_indent:
            kv = ln.strip().split(":", 1)
            if len(kv) == 2:
                k = kv[0].strip()
                v = kv[1].strip().strip("'\"")
                if v:
                    props[k] = v

    for i in range(line_idx + 1, len(lines)):
        ln = lines[i]
        if not ln.strip() or ln.strip().startswith("#"):
            continue
        ln_indent = len(ln) - len(ln.lstrip())
        if ln_indent < current_indent:
            break
        if ln_indent == current_indent:
            kv = ln.strip().split(":", 1)
            if len(kv) == 2:
                k = kv[0].strip()
                v = kv[1].strip().strip("'\"")
                if v:
                    props[k] = v
        elif ln_indent > current_indent:
            continue

    return props


def _extract_props_sibling_properties(lines, line_idx):
    props = {}
    current_line = lines[line_idx].strip()
    if "=" not in current_line:
        return props

    full_key = current_line.split("=", 1)[0].strip()
    parts = full_key.rsplit(".", 1)
    if len(parts) < 2:
        return props

    prefix = parts[0] + "."
    for i, ln in enumerate(lines):
        stripped = ln.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if "=" in stripped and stripped.startswith(prefix):
            k = stripped.split("=", 1)[0].strip()
            v = stripped.split("=", 1)[1].strip().strip("'\"")
            short_key = k[len(prefix):]
            if v:
                props[short_key] = v

    return props


def _build_config_details(props, url, rel_path):
    api_url_keys = {
        "apiurl", "api-url", "api.url", "api_url", "endpoint", "end-point",
        "base-url", "base.url", "baseurl", "base_url",
        "service-url", "service.url", "serviceurl", "service_url",
        "uri", "url", "path",
    }

    api_name = ""
    http_method = ""
    client_id = ""
    request_body = ""
    response_body = ""
    content_type = ""
    description = ""
    extra_details = []

    known_keys = set()

    for k, v in props.items():
        kl = k.lower().replace("-", "").replace("_", "").replace(".", "")
        if kl in {"apiname", "name", "servicename"}:
            api_name = v
            known_keys.add(k)
        elif kl in {"httpmethod", "method"}:
            http_method = v.upper()
            known_keys.add(k)
        elif kl in {"clientid", "client"}:
            client_id = v
            known_keys.add(k)
        elif kl in {"requestbody", "request", "requesttype", "requestclass", "requestobject", "inputtype"}:
            request_body = v
            known_keys.add(k)
        elif kl in {"responsebody", "response", "responsetype", "responseclass", "responseobject", "outputtype", "returntype"}:
            response_body = v
            known_keys.add(k)
        elif kl in {"contenttype", "mediatype", "producetype", "consumetype"}:
            content_type = v
            known_keys.add(k)
        elif kl in {"description", "desc", "summary"}:
            description = v
            known_keys.add(k)

    if not http_method:
        http_method = _infer_http_method_from_url(url)

    request_parts = []
    if request_body:
        request_parts.append(f"Body: {request_body}")
    if content_type:
        request_parts.append(f"Content-Type: {content_type}")
    if client_id:
        request_parts.append(f"Client ID: {client_id}")
    req_str = "; ".join(request_parts) if request_parts else f"Configured in {os.path.basename(rel_path)}"

    response_parts = []
    if response_body:
        response_parts.append(f"Returns: {response_body}")
    resp_str = "; ".join(response_parts) if response_parts else f"Configured in {os.path.basename(rel_path)}"

    param_lines = []
    for k, v in props.items():
        if k in known_keys:
            continue
        if k.lower().replace("-", "").replace("_", "").replace(".", "") in api_url_keys:
            continue
        param_lines.append(f"Config | {k} | {v}")

    params_str = "\n".join(param_lines)

    func_label = api_name if api_name else _infer_service_name_from_context.__wrapped__(props, url) if hasattr(_infer_service_name_from_context, '__wrapped__') else ""

    return http_method, req_str, resp_str, params_str, api_name, client_id, description, request_body, response_body


def scan_config_file_for_apis(file_path, rel_path, language, excel_urls, excel_paths):
    content = read_file_safe(file_path)
    if not content:
        return []

    ext = os.path.splitext(file_path)[1].lower()
    lines = content.split("\n")
    endpoints = []
    seen_urls = set()

    if ext in (".yml", ".yaml"):
        patterns = CONFIG_API_PATTERNS_YML
    elif ext == ".properties":
        patterns = CONFIG_API_PATTERNS_PROPS
    elif ext in (".json",):
        patterns = CONFIG_API_PATTERNS_JSON
    elif ext in (".xml", ".config"):
        patterns = CONFIG_API_PATTERNS_JSON + CONFIG_API_PATTERNS_PROPS
    else:
        return []

    for line_idx, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith("//"):
            continue

        for pat in patterns:
            match = pat.search(line)
            if match:
                url = match.group(1).strip().rstrip("'\"")
                if not url or len(url) < 3:
                    continue
                if url in seen_urls:
                    continue
                seen_urls.add(url)

                if ext in (".yml", ".yaml"):
                    sibling_props = _extract_yml_sibling_properties(lines, line_idx)
                elif ext == ".properties":
                    sibling_props = _extract_props_sibling_properties(lines, line_idx)
                else:
                    sibling_props = {}

                http_method, req_str, resp_str, params_str, api_name, client_id, description, request_body, response_body = _build_config_details(sibling_props, url, rel_path)

                service_name = api_name if api_name else _infer_service_name_from_context(lines, line_idx)

                api_type = "REST"
                if "soap" in url.lower() or "wsdl" in url.lower():
                    api_type = "SOAP"
                elif "onedata" in url.lower():
                    api_type = "OneData"

                matched_url, matched_path = match_with_excel(
                    url, rel_path, excel_urls, excel_paths
                )

                crud_op = detect_operation(http_method, service_name, url, api_type)

                snippet_start = max(0, line_idx - 1)
                snippet_end = line_idx + 1
                current_indent = len(lines[line_idx]) - len(lines[line_idx].lstrip())
                for si in range(line_idx + 1, len(lines)):
                    if not lines[si].strip():
                        continue
                    si_indent = len(lines[si]) - len(lines[si].lstrip())
                    if si_indent < current_indent:
                        break
                    if si_indent == current_indent:
                        snippet_end = si + 1
                    elif si_indent > current_indent:
                        snippet_end = si + 1
                for si in range(line_idx - 1, max(line_idx - 15, -1), -1):
                    if not lines[si].strip():
                        continue
                    si_indent = len(lines[si]) - len(lines[si].lstrip())
                    if si_indent < current_indent:
                        snippet_start = si
                        break
                snippet_lines = []
                for si in range(snippet_start, min(snippet_end, len(lines))):
                    prefix = ">>> " if si == line_idx else "    "
                    snippet_lines.append(f"{prefix}{si + 1}: {lines[si]}")
                snippet = "\n".join(snippet_lines)

                config_key = stripped.split(":")[0].strip() if ":" in stripped else stripped.split("=")[0].strip()

                func_display = f"{service_name} (config: {config_key})"

                payload_parts = []
                if api_name:
                    payload_parts.append(f"API Name: {api_name}")
                if client_id:
                    payload_parts.append(f"Client ID: {client_id}")
                payload_parts.append(f"HTTP Method: {http_method}")
                if description:
                    payload_parts.append(f"Description: {description}")
                if request_body:
                    payload_parts.append(f"Request Body Type: {request_body}")
                if response_body:
                    payload_parts.append(f"Response Body Type: {response_body}")

                for k, v in sibling_props.items():
                    kl = k.lower().replace("-", "").replace("_", "").replace(".", "")
                    api_url_keys = {"apiurl", "apiurl", "apiurl", "endpoint", "baseurl", "serviceurl", "uri", "url", "path"}
                    detail_keys = {"apiname", "name", "servicename", "httpmethod", "method", "clientid", "client",
                                   "requestbody", "request", "requesttype", "responsebody", "response", "responsetype",
                                   "contenttype", "mediatype", "description", "desc", "summary",
                                   "requestclass", "responseclass", "requestobject", "responseobject",
                                   "inputtype", "outputtype", "returntype", "producetype", "consumetype"}
                    if kl not in api_url_keys and kl not in detail_keys:
                        payload_parts.append(f"{k}: {v}")

                payload_str = "\n".join(payload_parts)

                endpoints.append(
                    APIEndpoint(
                        url=url,
                        api_type=api_type,
                        http_method=http_method,
                        file_path=rel_path,
                        line_number=line_idx + 1,
                        function_name=func_display,
                        request_details=req_str,
                        response_details=resp_str,
                        matched_excel_url=matched_url,
                        matched_excel_path=matched_path,
                        code_snippet=snippet,
                        parameters=params_str,
                        operation=crud_op,
                        payload_fields=payload_str,
                    )
                )
                break

    return endpoints


def scan_file_for_apis(file_path, rel_path, language, excel_urls, excel_paths):
    content = read_file_safe(file_path)
    if not content:
        return []

    ext = os.path.splitext(file_path)[1].lower()
    if ext in CONFIG_EXTENSIONS:
        config_endpoints = scan_config_file_for_apis(
            file_path, rel_path, language, excel_urls, excel_paths
        )
        if ext not in (".xml",):
            return config_endpoints

    lines = content.split("\n")
    endpoints = []

    rest_patterns = REST_PATTERNS_JAVA if language == "Java" else REST_PATTERNS_CSHARP
    soap_patterns = SOAP_PATTERNS_JAVA if language == "Java" else SOAP_PATTERNS_CSHARP

    class_base_path = extract_class_path(lines, language)

    for line_idx, line in enumerate(lines):
        for pattern, method_type in rest_patterns:
            match = re.search(pattern, line)
            if match:
                url = match.group(1) if match.lastindex and match.lastindex >= 1 else ""
                if class_base_path and url and not url.startswith("/"):
                    url = f"{class_base_path}/{url}"
                elif class_base_path and not url:
                    url = class_base_path

                http_method = method_type
                if method_type in ("RequestMapping", "Route", "ApiController", "JAX-RS Path"):
                    method_match = re.search(r'method\s*=\s*RequestMethod\.(\w+)', line)
                    if method_match:
                        http_method = method_match.group(1)
                    elif method_type == "ApiController":
                        continue

                func_name = extract_function_name(lines, line_idx, language)
                req, resp, params = extract_request_response(lines, line_idx, language)
                snippet = extract_code_snippet(lines, line_idx)

                matched_url, matched_path = match_with_excel(
                    url, rel_path, excel_urls, excel_paths
                )

                crud_op = detect_operation(http_method, func_name, url, "REST")

                endpoints.append(
                    APIEndpoint(
                        url=url if url else f"[{method_type}]",
                        api_type="REST",
                        http_method=http_method,
                        file_path=rel_path,
                        line_number=line_idx + 1,
                        function_name=func_name,
                        request_details=req,
                        response_details=resp,
                        matched_excel_url=matched_url,
                        matched_excel_path=matched_path,
                        code_snippet=snippet,
                        parameters=params,
                        operation=crud_op,
                    )
                )
                break

        for pattern, soap_type in soap_patterns:
            match = re.search(pattern, line)
            if match:
                url = match.group(1) if match.lastindex and match.lastindex >= 1 else ""
                func_name = extract_function_name(lines, line_idx, language)
                req, resp, params = extract_request_response(lines, line_idx, language)
                snippet = extract_code_snippet(lines, line_idx)

                matched_url, matched_path = match_with_excel(
                    url, rel_path, excel_urls, excel_paths
                )

                crud_op = detect_operation(soap_type, func_name, url, "SOAP")

                endpoints.append(
                    APIEndpoint(
                        url=url if url else f"[{soap_type}]",
                        api_type="SOAP",
                        http_method=soap_type,
                        file_path=rel_path,
                        line_number=line_idx + 1,
                        function_name=func_name,
                        request_details=req,
                        response_details=resp,
                        matched_excel_url=matched_url,
                        matched_excel_path=matched_path,
                        code_snippet=snippet,
                        parameters=params,
                        operation=crud_op,
                    )
                )
                break

        for pattern, od_type in ONEDATA_PATTERNS:
            match = re.search(pattern, line)
            if match:
                url = match.group(1) if match.lastindex and match.lastindex >= 1 else ""
                func_name = extract_function_name(lines, line_idx, language)
                req, resp, params = extract_request_response(lines, line_idx, language)
                snippet = extract_code_snippet(lines, line_idx)

                matched_url, matched_path = match_with_excel(
                    url, rel_path, excel_urls, excel_paths
                )

                crud_op = detect_operation(od_type, func_name, url, "OneData")

                endpoints.append(
                    APIEndpoint(
                        url=url if url else f"[{od_type}]",
                        api_type="OneData",
                        http_method=od_type,
                        file_path=rel_path,
                        line_number=line_idx + 1,
                        function_name=func_name,
                        request_details=req,
                        response_details=resp,
                        matched_excel_url=matched_url,
                        matched_excel_path=matched_path,
                        code_snippet=snippet,
                        parameters=params,
                        operation=crud_op,
                    )
                )
                break

        for pattern, call_type in URL_CALL_PATTERNS:
            match = re.search(pattern, line)
            if match:
                url = match.group(1) if match.lastindex and match.lastindex >= 1 else line.strip()[:100]
                if url == line.strip()[:100] and not re.search(r'https?://', url):
                    continue

                func_name = extract_function_name(lines, max(0, line_idx - 5), language)
                snippet = extract_code_snippet(lines, line_idx)

                matched_url, matched_path = match_with_excel(
                    url, rel_path, excel_urls, excel_paths
                )

                if matched_url or matched_path:
                    api_type = "REST"
                    if "soap" in url.lower() or "wsdl" in url.lower():
                        api_type = "SOAP"
                    elif "onedata" in url.lower():
                        api_type = "OneData"

                    crud_op = detect_operation(call_type, func_name, url, api_type)

                    endpoints.append(
                        APIEndpoint(
                            url=url if len(url) < 200 else url[:200],
                            api_type=api_type,
                            http_method=call_type,
                            file_path=rel_path,
                            line_number=line_idx + 1,
                            function_name=func_name,
                            request_details="See code context",
                            response_details="See code context",
                            matched_excel_url=matched_url,
                            matched_excel_path=matched_path,
                            code_snippet=snippet,
                            operation=crud_op,
                        )
                    )

    return endpoints


def match_with_excel(url, file_path, excel_urls, excel_paths):
    matched_url = ""
    matched_path = ""

    if url:
        url_lower = url.lower().strip("/")
        for eu in excel_urls:
            eu_lower = str(eu).lower().strip("/")
            if not eu_lower:
                continue
            if url_lower in eu_lower or eu_lower in url_lower:
                matched_url = str(eu)
                break
            url_parts = [p for p in url_lower.split("/") if p and not p.startswith("{")]
            eu_parts = [p for p in eu_lower.split("/") if p]
            if url_parts and eu_parts:
                common = set(url_parts) & set(eu_parts)
                if len(common) >= max(1, min(len(url_parts), len(eu_parts)) // 2):
                    matched_url = str(eu)
                    break

    if file_path:
        fp_lower = file_path.lower().replace("\\", "/")
        for ep in excel_paths:
            ep_lower = str(ep).lower().replace("\\", "/")
            if not ep_lower:
                continue
            if ep_lower in fp_lower or fp_lower in ep_lower:
                matched_path = str(ep)
                break
            fp_parts = fp_lower.split("/")
            ep_parts = ep_lower.split("/")
            if fp_parts and ep_parts:
                fp_name = fp_parts[-1]
                ep_name = ep_parts[-1]
                if fp_name == ep_name:
                    matched_path = str(ep)
                    break

    return matched_url, matched_path


def scan_source_code(source_dir, excel_urls, excel_paths):
    language = detect_language(source_dir)
    extensions = get_relevant_extensions(language)
    all_endpoints = []
    scanned_files = 0
    file_list = []

    for root, _, files in os.walk(source_dir):
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext in extensions:
                full_path = os.path.join(root, fname)
                rel_path = os.path.relpath(full_path, source_dir)
                file_list.append((full_path, rel_path))

    if len(file_list) > MAX_SCAN_FILES:
        file_list = file_list[:MAX_SCAN_FILES]

    class_index = build_class_field_index(source_dir, language)

    for full_path, rel_path in file_list:
        scanned_files += 1
        endpoints = scan_file_for_apis(full_path, rel_path, language, excel_urls, excel_paths)
        all_endpoints.extend(endpoints)

    for ep in all_endpoints:
        ep.payload_fields = resolve_payload_fields(ep, class_index, language)

    return all_endpoints, language, scanned_files, len(file_list)


def deduplicate_endpoints(endpoints):
    seen = set()
    unique = []
    for ep in endpoints:
        key = (ep.url, ep.api_type, ep.file_path, ep.line_number)
        if key not in seen:
            seen.add(key)
            unique.append(ep)
    return unique
