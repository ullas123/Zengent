import re
import os
import zipfile
import tempfile
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class APIEndpoint:
    url: str
    api_type: str  # REST, SOAP, OneData
    http_method: str
    file_path: str
    line_number: int
    function_name: str
    request_details: str
    response_details: str
    matched_excel_url: str = ""
    matched_excel_path: str = ""
    code_snippet: str = ""


JAVA_EXTENSIONS = {".java", ".xml", ".properties", ".yml", ".yaml", ".json", ".wsdl"}
CSHARP_EXTENSIONS = {".cs", ".cshtml", ".config", ".xml", ".json", ".wsdl", ".svc", ".asmx"}


REST_PATTERNS_JAVA = [
    (r'@RequestMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "RequestMapping"),
    (r'@GetMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "GET"),
    (r'@PostMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "POST"),
    (r'@PutMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "PUT"),
    (r'@DeleteMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "DELETE"),
    (r'@PatchMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', "PATCH"),
    (r'@GetMapping\s*$', "GET"),
    (r'@PostMapping\s*$', "POST"),
    (r'@PutMapping\s*$', "PUT"),
    (r'@DeleteMapping\s*$', "DELETE"),
    (r'@PatchMapping\s*$', "PATCH"),
    (r'@Path\s*\(\s*["\']([^"\']+)["\']', "JAX-RS Path"),
    (r'@GET\b', "GET"),
    (r'@POST\b', "POST"),
    (r'@PUT\b', "PUT"),
    (r'@DELETE\b', "DELETE"),
]

REST_PATTERNS_CSHARP = [
    (r'\[HttpGet\s*\(\s*["\']([^"\']*)["\']', "GET"),
    (r'\[HttpPost\s*\(\s*["\']([^"\']*)["\']', "POST"),
    (r'\[HttpPut\s*\(\s*["\']([^"\']*)["\']', "PUT"),
    (r'\[HttpDelete\s*\(\s*["\']([^"\']*)["\']', "DELETE"),
    (r'\[HttpPatch\s*\(\s*["\']([^"\']*)["\']', "PATCH"),
    (r'\[HttpGet\]', "GET"),
    (r'\[HttpPost\]', "POST"),
    (r'\[HttpPut\]', "PUT"),
    (r'\[HttpDelete\]', "DELETE"),
    (r'\[HttpPatch\]', "PATCH"),
    (r'\[Route\s*\(\s*["\']([^"\']+)["\']', "Route"),
    (r'\[ApiController\]', "ApiController"),
]

SOAP_PATTERNS_JAVA = [
    (r'@WebService\b', "WebService"),
    (r'@WebMethod\b', "WebMethod"),
    (r'@SOAPBinding\b', "SOAPBinding"),
    (r'@WebResult\b', "WebResult"),
    (r'@WebParam\b', "WebParam"),
    (r'SOAPConnectionFactory', "SOAPConnectionFactory"),
    (r'SOAPConnection', "SOAPConnection"),
    (r'SOAPMessage', "SOAPMessage"),
    (r'MessageFactory\.newInstance', "SOAPMessageFactory"),
    (r'SOAPEnvelope', "SOAPEnvelope"),
    (r'SOAPBody', "SOAPBody"),
    (r'<wsdl:service\s', "WSDL Service"),
    (r'<wsdl:operation\s', "WSDL Operation"),
    (r'<soap:address\s+location\s*=\s*["\']([^"\']+)["\']', "SOAP Address"),
]

SOAP_PATTERNS_CSHARP = [
    (r'\[WebService\b', "WebService"),
    (r'\[WebMethod\b', "WebMethod"),
    (r'\[SoapHeader\b', "SoapHeader"),
    (r'\[SoapDocumentMethod\b', "SoapDocumentMethod"),
    (r'SoapHttpClientProtocol', "SoapClient"),
    (r'ServiceContract', "WCF ServiceContract"),
    (r'OperationContract', "WCF OperationContract"),
    (r'BasicHttpBinding', "WCF BasicHttpBinding"),
    (r'WSHttpBinding', "WCF WSHttpBinding"),
    (r'\.asmx', "ASMX WebService"),
    (r'<wsdl:service\s', "WSDL Service"),
    (r'<soap:address\s+location\s*=\s*["\']([^"\']+)["\']', "SOAP Address"),
]

ONEDATA_PATTERNS = [
    (r'OneData\.(?:get|fetch|query|read|load|retrieve)\s*\(', "OneData Read"),
    (r'OneData\.(?:post|create|insert|save|add|write)\s*\(', "OneData Write"),
    (r'OneData\.(?:update|modify|patch)\s*\(', "OneData Update"),
    (r'OneData\.(?:delete|remove)\s*\(', "OneData Delete"),
    (r'onedata\.(?:get|fetch|query|read|load|retrieve)\s*\(', "onedata Read"),
    (r'onedata\.(?:post|create|insert|save|add|write)\s*\(', "onedata Write"),
    (r'onedata\.(?:update|modify|patch)\s*\(', "onedata Update"),
    (r'onedata\.(?:delete|remove)\s*\(', "onedata Delete"),
    (r'OneDataService\s*\.', "OneDataService Call"),
    (r'OneDataClient\s*\.', "OneDataClient Call"),
    (r'IOneData\s*\.', "IOneData Interface Call"),
    (r'oneDataFunction\s*\(', "OneData Function"),
    (r'OneDataFunction\s*\(', "OneData Function"),
    (r'@OneData\b', "OneData Annotation"),
    (r'onedata[-_]api', "OneData API Reference"),
    (r'OneDataRequest', "OneData Request"),
    (r'OneDataResponse', "OneData Response"),
]

URL_CALL_PATTERNS = [
    (r'new\s+URL\s*\(\s*["\']([^"\']+)["\']', "Java URL"),
    (r'HttpClient\s*.*?\.(?:GetAsync|PostAsync|PutAsync|DeleteAsync|SendAsync)\s*\(\s*["\']([^"\']+)["\']', "C# HttpClient"),
    (r'WebClient\s*.*?\.(?:Download|Upload)\w+\s*\(\s*["\']([^"\']+)["\']', "C# WebClient"),
    (r'RestTemplate\s*.*?\.(?:getForObject|postForObject|exchange|getForEntity)\s*\(\s*["\']([^"\']+)["\']', "Java RestTemplate"),
    (r'WebTarget\s*.*?\.(?:path|request)\s*\(\s*["\']([^"\']+)["\']', "JAX-RS WebTarget"),
    (r'HttpURLConnection', "Java HttpURLConnection"),
    (r'HttpRequest\.newBuilder\(\)\s*\.uri\(URI\.create\(\s*["\']([^"\']+)["\']', "Java HttpClient"),
    (r'fetch\s*\(\s*["\']([^"\']+)["\']', "Fetch Call"),
    (r'axios\.\w+\s*\(\s*["\']([^"\']+)["\']', "Axios Call"),
    (r'["\']https?://[^"\']+["\']', "URL String"),
]


def extract_source_files(uploaded_file):
    temp_dir = tempfile.mkdtemp()
    zip_path = os.path.join(temp_dir, "source.zip")

    with open(zip_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    extract_dir = os.path.join(temp_dir, "source")
    os.makedirs(extract_dir, exist_ok=True)

    try:
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(extract_dir)
    except zipfile.BadZipFile:
        shutil.rmtree(temp_dir)
        return None, "Invalid ZIP file. Please upload a valid ZIP archive."

    return extract_dir, None


ALLOWED_GIT_HOSTS = [
    "github.com",
    "gitlab.com",
    "bitbucket.org",
    "dev.azure.com",
    "ssh.dev.azure.com",
]

MAX_SCAN_FILES = 5000


def _validate_git_url(repo_url):
    if not repo_url.startswith("https://"):
        return False, "Only HTTPS Git URLs are supported. URLs starting with git://, ssh://, or file:// are not allowed."
    from urllib.parse import urlparse
    parsed = urlparse(repo_url)
    host = parsed.hostname
    if not host:
        return False, "Invalid Git URL format."
    host_lower = host.lower()
    if not any(host_lower == allowed or host_lower.endswith("." + allowed) for allowed in ALLOWED_GIT_HOSTS):
        return False, f"Git host '{host}' is not supported. Allowed hosts: {', '.join(ALLOWED_GIT_HOSTS)}"
    return True, ""


def clone_git_repo(repo_url, branch=None):
    valid, msg = _validate_git_url(repo_url)
    if not valid:
        return None, msg

    temp_dir = tempfile.mkdtemp()
    clone_dir = os.path.join(temp_dir, "source")

    cmd = ["git", "clone", "--depth", "1"]
    if branch:
        cmd.extend(["-b", branch])
    cmd.extend([repo_url, clone_dir])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            shutil.rmtree(temp_dir, ignore_errors=True)
            error_msg = result.stderr.strip()
            if "could not read Username" in error_msg or "Authentication failed" in error_msg:
                return None, (
                    "Authentication required. For private repos, use a URL with a token: "
                    "https://<token>@github.com/user/repo.git"
                )
            return None, f"Git clone failed: {error_msg}"
    except subprocess.TimeoutExpired:
        shutil.rmtree(temp_dir, ignore_errors=True)
        return None, "Git clone timed out after 120 seconds. The repository may be too large."
    except FileNotFoundError:
        shutil.rmtree(temp_dir, ignore_errors=True)
        return None, "Git is not installed on this system."

    return clone_dir, None


def detect_language(source_dir):
    java_count = 0
    csharp_count = 0

    for root, _, files in os.walk(source_dir):
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext == ".java":
                java_count += 1
            elif ext == ".cs":
                csharp_count += 1

    if java_count > csharp_count:
        return "Java"
    elif csharp_count > java_count:
        return "C#"
    elif java_count > 0:
        return "Java"
    elif csharp_count > 0:
        return "C#"
    return "Unknown"


def get_relevant_extensions(language):
    if language == "Java":
        return JAVA_EXTENSIONS
    elif language == "C#":
        return CSHARP_EXTENSIONS
    return JAVA_EXTENSIONS | CSHARP_EXTENSIONS


def read_file_safe(file_path):
    encodings = ["utf-8", "latin-1", "cp1252"]
    for enc in encodings:
        try:
            with open(file_path, "r", encoding=enc) as f:
                return f.read()
        except (UnicodeDecodeError, PermissionError):
            continue
    return None


def extract_function_name(lines, line_idx, language):
    if language == "Java":
        for i in range(line_idx, min(line_idx + 5, len(lines))):
            match = re.search(
                r'(?:public|private|protected)?\s*(?:static\s+)?(?:\w+(?:<[^>]+>)?)\s+(\w+)\s*\(',
                lines[i],
            )
            if match:
                return match.group(1)
    elif language == "C#":
        for i in range(line_idx, min(line_idx + 5, len(lines))):
            match = re.search(
                r'(?:public|private|protected|internal)?\s*(?:static\s+)?(?:async\s+)?(?:\w+(?:<[^>]+>)?)\s+(\w+)\s*\(',
                lines[i],
            )
            if match:
                return match.group(1)
    return "Unknown"


def extract_request_response(lines, line_idx, language):
    request_details = []
    response_details = []

    context_start = max(0, line_idx - 3)
    context_end = min(len(lines), line_idx + 20)
    context = "\n".join(lines[context_start:context_end])

    param_patterns = [
        (r'@RequestBody\s+(\w+(?:<[^>]+>)?)\s+(\w+)', "Body: {1} ({0})"),
        (r'@PathVariable\s+(?:\(\s*["\']?\w+["\']?\s*\)\s*)?(\w+)\s+(\w+)', "Path: {1} ({0})"),
        (r'@RequestParam\s+(?:\(\s*["\']?\w+["\']?\s*\)\s*)?(\w+)\s+(\w+)', "Query: {1} ({0})"),
        (r'@RequestHeader\s+(?:\(\s*["\']?\w+["\']?\s*\)\s*)?(\w+)\s+(\w+)', "Header: {1} ({0})"),
        (r'\[FromBody\]\s*(\w+)\s+(\w+)', "Body: {1} ({0})"),
        (r'\[FromQuery\]\s*(\w+)\s+(\w+)', "Query: {1} ({0})"),
        (r'\[FromRoute\]\s*(\w+)\s+(\w+)', "Route: {1} ({0})"),
        (r'\[FromHeader\]\s*(\w+)\s+(\w+)', "Header: {1} ({0})"),
    ]

    for pattern, fmt in param_patterns:
        matches = re.findall(pattern, context)
        for m in matches:
            request_details.append(fmt.format(*m))

    if language == "Java":
        ret_match = re.search(
            r'(?:public|private|protected)?\s*(?:static\s+)?(?:ResponseEntity<([^>]+)>|(\w+(?:<[^>]+>)?))\s+\w+\s*\(',
            context,
        )
        if ret_match:
            ret_type = ret_match.group(1) or ret_match.group(2)
            if ret_type and ret_type not in ("void",):
                response_details.append(f"Returns: {ret_type}")
    elif language == "C#":
        ret_match = re.search(
            r'(?:public|private|protected|internal)?\s*(?:static\s+)?(?:async\s+)?(?:Task<)?(?:ActionResult<([^>]+)>|IActionResult|(\w+(?:<[^>]+>)?))\s+\w+\s*\(',
            context,
        )
        if ret_match:
            ret_type = ret_match.group(1) or ret_match.group(2)
            if ret_type and ret_type not in ("void", "Task"):
                response_details.append(f"Returns: {ret_type}")

    return_patterns = [
        r'return\s+(?:new\s+)?ResponseEntity[^;]+',
        r'return\s+(?:new\s+)?(?:Ok|BadRequest|NotFound|Created|NoContent)\s*\([^)]*\)',
        r'return\s+Json\s*\([^)]*\)',
    ]
    for pat in return_patterns:
        match = re.search(pat, context)
        if match:
            response_details.append(f"Response: {match.group(0).strip()[:80]}")

    req_str = "; ".join(request_details) if request_details else "Not detected"
    resp_str = "; ".join(response_details) if response_details else "Not detected"
    return req_str, resp_str


def extract_code_snippet(lines, line_idx, context=3):
    start = max(0, line_idx - context)
    end = min(len(lines), line_idx + context + 1)
    snippet_lines = []
    for i in range(start, end):
        prefix = ">>> " if i == line_idx else "    "
        snippet_lines.append(f"{prefix}{i + 1}: {lines[i]}")
    return "\n".join(snippet_lines)


def extract_class_path(lines, language):
    if language == "Java":
        class_match = None
        for line in lines:
            m = re.search(r'@RequestMapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', line)
            if m:
                class_match = m.group(1)
                break
        return class_match
    elif language == "C#":
        for line in lines:
            m = re.search(r'\[Route\s*\(\s*["\']([^"\']+)["\']', line)
            if m:
                return m.group(1)
    return None


def scan_file_for_apis(file_path, rel_path, language, excel_urls, excel_paths):
    content = read_file_safe(file_path)
    if not content:
        return []

    lines = content.split("\n")
    endpoints = []

    rest_patterns = REST_PATTERNS_JAVA if language == "Java" else REST_PATTERNS_CSHARP
    soap_patterns = SOAP_PATTERNS_JAVA if language == "Java" else SOAP_PATTERNS_CSHARP

    class_base_path = extract_class_path(lines, language)

    for line_idx, line in enumerate(lines):
        for pattern, method_type in rest_patterns:
            match = re.search(pattern, line)
            if match:
                url = match.group(1) if match.lastindex and match.lastindex >= 1 else ""
                if class_base_path and url and not url.startswith("/"):
                    url = f"{class_base_path}/{url}"
                elif class_base_path and not url:
                    url = class_base_path

                http_method = method_type
                if method_type in ("RequestMapping", "Route", "ApiController", "JAX-RS Path"):
                    method_match = re.search(r'method\s*=\s*RequestMethod\.(\w+)', line)
                    if method_match:
                        http_method = method_match.group(1)
                    elif method_type == "ApiController":
                        continue

                func_name = extract_function_name(lines, line_idx, language)
                req, resp = extract_request_response(lines, line_idx, language)
                snippet = extract_code_snippet(lines, line_idx)

                matched_url, matched_path = match_with_excel(
                    url, rel_path, excel_urls, excel_paths
                )

                endpoints.append(
                    APIEndpoint(
                        url=url if url else f"[{method_type}]",
                        api_type="REST",
                        http_method=http_method,
                        file_path=rel_path,
                        line_number=line_idx + 1,
                        function_name=func_name,
                        request_details=req,
                        response_details=resp,
                        matched_excel_url=matched_url,
                        matched_excel_path=matched_path,
                        code_snippet=snippet,
                    )
                )
                break

        for pattern, soap_type in soap_patterns:
            match = re.search(pattern, line)
            if match:
                url = match.group(1) if match.lastindex and match.lastindex >= 1 else ""
                func_name = extract_function_name(lines, line_idx, language)
                req, resp = extract_request_response(lines, line_idx, language)
                snippet = extract_code_snippet(lines, line_idx)

                matched_url, matched_path = match_with_excel(
                    url, rel_path, excel_urls, excel_paths
                )

                endpoints.append(
                    APIEndpoint(
                        url=url if url else f"[{soap_type}]",
                        api_type="SOAP",
                        http_method=soap_type,
                        file_path=rel_path,
                        line_number=line_idx + 1,
                        function_name=func_name,
                        request_details=req,
                        response_details=resp,
                        matched_excel_url=matched_url,
                        matched_excel_path=matched_path,
                        code_snippet=snippet,
                    )
                )
                break

        for pattern, od_type in ONEDATA_PATTERNS:
            match = re.search(pattern, line)
            if match:
                url = match.group(1) if match.lastindex and match.lastindex >= 1 else ""
                func_name = extract_function_name(lines, line_idx, language)
                req, resp = extract_request_response(lines, line_idx, language)
                snippet = extract_code_snippet(lines, line_idx)

                matched_url, matched_path = match_with_excel(
                    url, rel_path, excel_urls, excel_paths
                )

                endpoints.append(
                    APIEndpoint(
                        url=url if url else f"[{od_type}]",
                        api_type="OneData",
                        http_method=od_type,
                        file_path=rel_path,
                        line_number=line_idx + 1,
                        function_name=func_name,
                        request_details=req,
                        response_details=resp,
                        matched_excel_url=matched_url,
                        matched_excel_path=matched_path,
                        code_snippet=snippet,
                    )
                )
                break

        for pattern, call_type in URL_CALL_PATTERNS:
            match = re.search(pattern, line)
            if match:
                url = match.group(1) if match.lastindex and match.lastindex >= 1 else line.strip()[:100]
                if url == line.strip()[:100] and not re.search(r'https?://', url):
                    continue

                func_name = extract_function_name(lines, max(0, line_idx - 5), language)
                snippet = extract_code_snippet(lines, line_idx)

                matched_url, matched_path = match_with_excel(
                    url, rel_path, excel_urls, excel_paths
                )

                if matched_url or matched_path:
                    api_type = "REST"
                    if "soap" in url.lower() or "wsdl" in url.lower():
                        api_type = "SOAP"
                    elif "onedata" in url.lower():
                        api_type = "OneData"

                    endpoints.append(
                        APIEndpoint(
                            url=url if len(url) < 200 else url[:200],
                            api_type=api_type,
                            http_method=call_type,
                            file_path=rel_path,
                            line_number=line_idx + 1,
                            function_name=func_name,
                            request_details="See code context",
                            response_details="See code context",
                            matched_excel_url=matched_url,
                            matched_excel_path=matched_path,
                            code_snippet=snippet,
                        )
                    )

    return endpoints


def match_with_excel(url, file_path, excel_urls, excel_paths):
    matched_url = ""
    matched_path = ""

    if url:
        url_lower = url.lower().strip("/")
        for eu in excel_urls:
            eu_lower = str(eu).lower().strip("/")
            if not eu_lower:
                continue
            if url_lower in eu_lower or eu_lower in url_lower:
                matched_url = str(eu)
                break
            url_parts = [p for p in url_lower.split("/") if p and not p.startswith("{")]
            eu_parts = [p for p in eu_lower.split("/") if p]
            if url_parts and eu_parts:
                common = set(url_parts) & set(eu_parts)
                if len(common) >= max(1, min(len(url_parts), len(eu_parts)) // 2):
                    matched_url = str(eu)
                    break

    if file_path:
        fp_lower = file_path.lower().replace("\\", "/")
        for ep in excel_paths:
            ep_lower = str(ep).lower().replace("\\", "/")
            if not ep_lower:
                continue
            if ep_lower in fp_lower or fp_lower in ep_lower:
                matched_path = str(ep)
                break
            fp_parts = fp_lower.split("/")
            ep_parts = ep_lower.split("/")
            if fp_parts and ep_parts:
                fp_name = fp_parts[-1]
                ep_name = ep_parts[-1]
                if fp_name == ep_name:
                    matched_path = str(ep)
                    break

    return matched_url, matched_path


def scan_source_code(source_dir, excel_urls, excel_paths):
    language = detect_language(source_dir)
    extensions = get_relevant_extensions(language)
    all_endpoints = []
    scanned_files = 0
    file_list = []

    for root, _, files in os.walk(source_dir):
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext in extensions:
                full_path = os.path.join(root, fname)
                rel_path = os.path.relpath(full_path, source_dir)
                file_list.append((full_path, rel_path))

    if len(file_list) > MAX_SCAN_FILES:
        file_list = file_list[:MAX_SCAN_FILES]

    for full_path, rel_path in file_list:
        scanned_files += 1
        endpoints = scan_file_for_apis(full_path, rel_path, language, excel_urls, excel_paths)
        all_endpoints.extend(endpoints)

    return all_endpoints, language, scanned_files, len(file_list)


def deduplicate_endpoints(endpoints):
    seen = set()
    unique = []
    for ep in endpoints:
        key = (ep.url, ep.api_type, ep.file_path, ep.line_number)
        if key not in seen:
            seen.add(key)
            unique.append(ep)
    return unique
