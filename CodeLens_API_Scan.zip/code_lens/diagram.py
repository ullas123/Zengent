import graphviz
import tempfile
import os


def create_api_flow_diagram(endpoints, app_name="Application"):
    dot = graphviz.Digraph(
        name="API_Flow",
        format="png",
        engine="dot",
    )
    dot.attr(
        rankdir="LR",
        bgcolor="#f8f9fa",
        fontname="Arial",
        label=f"Code Lens - API Flow Diagram: {app_name}",
        labelloc="t",
        fontsize="18",
        fontcolor="#1a1a2e",
        pad="0.5",
        nodesep="0.8",
        ranksep="1.5",
    )

    dot.attr(
        "node",
        shape="box",
        style="rounded,filled",
        fontname="Arial",
        fontsize="10",
    )

    files = {}
    api_types = {"REST": [], "SOAP": [], "OneData": []}

    for ep in endpoints:
        if ep.file_path not in files:
            files[ep.file_path] = []
        files[ep.file_path].append(ep)
        if ep.api_type in api_types:
            api_types[ep.api_type].append(ep)

    type_colors = {
        "REST": {"fill": "#d4edda", "border": "#28a745", "font": "#155724"},
        "SOAP": {"fill": "#d1ecf1", "border": "#17a2b8", "font": "#0c5460"},
        "OneData": {"fill": "#fff3cd", "border": "#ffc107", "font": "#856404"},
    }

    dot.node(
        "client",
        "External Client\n/ Consumer",
        shape="ellipse",
        fillcolor="#e2e3e5",
        color="#6c757d",
        fontcolor="#383d41",
        fontsize="12",
        penwidth="2",
    )

    for api_type, eps in api_types.items():
        if not eps:
            continue
        colors = type_colors[api_type]
        type_node = f"type_{api_type}"
        dot.node(
            type_node,
            f"{api_type} API Layer",
            shape="box",
            fillcolor=colors["fill"],
            color=colors["border"],
            fontcolor=colors["font"],
            fontsize="12",
            penwidth="2",
            style="rounded,filled,bold",
        )
        dot.edge("client", type_node, label=api_type, color=colors["border"], penwidth="1.5")

    for file_path, file_eps in files.items():
        short_name = os.path.basename(file_path)
        file_node = f"file_{file_path}".replace("/", "_").replace(".", "_").replace(" ", "_")

        functions = []
        for ep in file_eps[:8]:
            method_label = ep.http_method if len(ep.http_method) < 20 else ep.api_type
            func_display = ep.function_name if ep.function_name != "Unknown" else "handler"
            url_display = ep.url if len(ep.url) < 40 else ep.url[:37] + "..."
            functions.append(f"{method_label}: {func_display}()\n  {url_display}")

        if len(file_eps) > 8:
            functions.append(f"... +{len(file_eps) - 8} more")

        label = f"{short_name}\n" + "-" * 20 + "\n" + "\n".join(functions)

        file_types = set(ep.api_type for ep in file_eps)
        primary_type = file_eps[0].api_type
        colors = type_colors.get(primary_type, type_colors["REST"])

        dot.node(
            file_node,
            label,
            shape="box",
            fillcolor="#ffffff",
            color=colors["border"],
            fontcolor="#333333",
            fontsize="9",
            penwidth="1.5",
            style="rounded,filled",
        )

        for api_type in file_types:
            type_node = f"type_{api_type}"
            colors = type_colors.get(api_type, type_colors["REST"])
            dot.edge(type_node, file_node, color=colors["border"], style="dashed")

    temp_dir = tempfile.mkdtemp()
    output_path = os.path.join(temp_dir, "api_flow")
    dot.render(output_path, cleanup=True)
    return output_path + ".png"


def create_file_dependency_diagram(endpoints):
    dot = graphviz.Digraph(
        name="File_Dependencies",
        format="png",
        engine="dot",
    )
    dot.attr(
        rankdir="TB",
        bgcolor="#f8f9fa",
        fontname="Arial",
        label="Code Lens - File & API Dependencies",
        labelloc="t",
        fontsize="18",
        fontcolor="#1a1a2e",
        pad="0.5",
    )

    file_apis = {}
    for ep in endpoints:
        if ep.file_path not in file_apis:
            file_apis[ep.file_path] = {"REST": 0, "SOAP": 0, "OneData": 0}
        if ep.api_type in file_apis[ep.file_path]:
            file_apis[ep.file_path][ep.api_type] += 1

    type_colors = {"REST": "#28a745", "SOAP": "#17a2b8", "OneData": "#ffc107"}

    for file_path, counts in file_apis.items():
        short_name = os.path.basename(file_path)
        file_node = f"f_{file_path}".replace("/", "_").replace(".", "_").replace(" ", "_")

        parts = []
        for t, c in counts.items():
            if c > 0:
                parts.append(f"{t}: {c}")
        label = f"{short_name}\n({', '.join(parts)})"

        max_type = max(counts, key=counts.get)
        color = type_colors.get(max_type, "#6c757d")

        dot.node(
            file_node,
            label,
            shape="box",
            style="rounded,filled",
            fillcolor="#ffffff",
            color=color,
            fontname="Arial",
            fontsize="10",
            penwidth="2",
        )

    file_list = list(file_apis.keys())
    for i, f1 in enumerate(file_list):
        for f2 in file_list[i + 1 :]:
            f1_types = set(t for t, c in file_apis[f1].items() if c > 0)
            f2_types = set(t for t, c in file_apis[f2].items() if c > 0)
            common = f1_types & f2_types
            if common:
                n1 = f"f_{f1}".replace("/", "_").replace(".", "_").replace(" ", "_")
                n2 = f"f_{f2}".replace("/", "_").replace(".", "_").replace(" ", "_")
                label = ", ".join(common)
                dot.edge(n1, n2, label=label, style="dotted", color="#6c757d")

    temp_dir = tempfile.mkdtemp()
    output_path = os.path.join(temp_dir, "file_deps")
    dot.render(output_path, cleanup=True)
    return output_path + ".png"


def create_api_summary_diagram(endpoints):
    dot = graphviz.Digraph(
        name="API_Summary",
        format="png",
        engine="dot",
    )
    dot.attr(
        rankdir="TB",
        bgcolor="#f8f9fa",
        fontname="Arial",
        label="Code Lens - API Type Summary",
        labelloc="t",
        fontsize="18",
        fontcolor="#1a1a2e",
        pad="0.5",
    )

    rest_count = sum(1 for e in endpoints if e.api_type == "REST")
    soap_count = sum(1 for e in endpoints if e.api_type == "SOAP")
    onedata_count = sum(1 for e in endpoints if e.api_type == "OneData")
    total = len(endpoints)

    dot.node(
        "total",
        f"Total APIs Found: {total}",
        shape="box",
        style="rounded,filled,bold",
        fillcolor="#1a1a2e",
        fontcolor="white",
        fontname="Arial",
        fontsize="14",
        penwidth="2",
    )

    if rest_count > 0:
        dot.node(
            "rest",
            f"REST APIs\n{rest_count} endpoints",
            shape="box",
            style="rounded,filled",
            fillcolor="#d4edda",
            color="#28a745",
            fontcolor="#155724",
            fontname="Arial",
            fontsize="12",
            penwidth="2",
        )
        dot.edge("total", "rest", color="#28a745", penwidth="2")

    if soap_count > 0:
        dot.node(
            "soap",
            f"SOAP APIs\n{soap_count} endpoints",
            shape="box",
            style="rounded,filled",
            fillcolor="#d1ecf1",
            color="#17a2b8",
            fontcolor="#0c5460",
            fontname="Arial",
            fontsize="12",
            penwidth="2",
        )
        dot.edge("total", "soap", color="#17a2b8", penwidth="2")

    if onedata_count > 0:
        dot.node(
            "onedata",
            f"OneData Functions\n{onedata_count} calls",
            shape="box",
            style="rounded,filled",
            fillcolor="#fff3cd",
            color="#ffc107",
            fontcolor="#856404",
            fontname="Arial",
            fontsize="12",
            penwidth="2",
        )
        dot.edge("total", "onedata", color="#ffc107", penwidth="2")

    matched = sum(1 for e in endpoints if e.matched_excel_url or e.matched_excel_path)
    unmatched = total - matched

    dot.node(
        "matched",
        f"Matched with Excel\n{matched} APIs",
        shape="ellipse",
        style="filled",
        fillcolor="#d4edda",
        color="#28a745",
        fontname="Arial",
        fontsize="10",
    )
    dot.node(
        "unmatched",
        f"Unmatched\n{unmatched} APIs",
        shape="ellipse",
        style="filled",
        fillcolor="#f8d7da",
        color="#dc3545",
        fontname="Arial",
        fontsize="10",
    )

    dot.edge("total", "matched", style="dashed", color="#28a745")
    dot.edge("total", "unmatched", style="dashed", color="#dc3545")

    temp_dir = tempfile.mkdtemp()
    output_path = os.path.join(temp_dir, "api_summary")
    dot.render(output_path, cleanup=True)
    return output_path + ".png"
