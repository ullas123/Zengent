# ZenForge Agent - Agentic AI Software Generation

Powered by Zensar AES

ZenForge Agent is an agentic AI software generation platform that transforms natural language project requirements into complete, production-ready codebases using a multi-agent pipeline (Planner, Coder, Reviewer) powered by OpenAI GPT-4o and GPT-4o-mini, orchestrated via LangGraph StateGraph.

---

## Prerequisites

- **Node.js** v20 or later
- **PostgreSQL** v14 or later
- **npm** v9 or later
- **OpenAI API Key** from [platform.openai.com](https://platform.openai.com)

---

## Installation

### Windows

1. **Install Node.js**
   - Download and install from [https://nodejs.org](https://nodejs.org) (LTS v20+)
   - Verify: open Command Prompt and run:
     ```cmd
     node --version
     npm --version
     ```

2. **Install PostgreSQL**
   - Download and install from [https://www.postgresql.org/download/windows/](https://www.postgresql.org/download/windows/)
   - During installation, note the username (default: `postgres`), password, and port (default: `5432`)
   - Open pgAdmin or psql and create a database:
     ```sql
     CREATE DATABASE zenforge;
     ```

3. **Clone / Extract the project**
   - Extract the ZIP to a folder, e.g. `C:\Projects\zenforge-agent`

4. **Configure environment variables**
   - Copy `.env.example` to `.env`:
     ```cmd
     copy .env.example .env
     ```
   - Open `.env` in a text editor and fill in your values:
     ```
     OPENAI_API_KEY=sk-your-key-here
     DATABASE_URL=postgresql://postgres:yourpassword@localhost:5432/zenforge
     SESSION_SECRET=any-random-string-here
     PORT=5000
     ```

5. **Install dependencies**
   ```cmd
   npm install
   ```

6. **Push database schema**
   ```cmd
   npm run db:push
   ```

7. **Start the application**
   ```cmd
   npm run dev
   ```

8. **Open in browser**
   - Navigate to [http://localhost:5000](http://localhost:5000)

---

### macOS / Linux

1. **Install Node.js**
   - Using Homebrew (macOS):
     ```bash
     brew install node@20
     ```
   - Using nvm (macOS/Linux):
     ```bash
     curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.0/install.sh | bash
     nvm install 20
     nvm use 20
     ```
   - Using apt (Ubuntu/Debian):
     ```bash
     curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
     sudo apt-get install -y nodejs
     ```
   - Verify:
     ```bash
     node --version
     npm --version
     ```

2. **Install PostgreSQL**
   - macOS (Homebrew):
     ```bash
     brew install postgresql@14
     brew services start postgresql@14
     ```
   - Ubuntu/Debian:
     ```bash
     sudo apt-get install -y postgresql postgresql-contrib
     sudo systemctl start postgresql
     sudo systemctl enable postgresql
     ```
   - Create a database:
     ```bash
     sudo -u postgres psql -c "CREATE DATABASE zenforge;"
     sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'yourpassword';"
     ```

3. **Clone / Extract the project**
   ```bash
   unzip zenforge-agent-local.zip -d ~/Projects/zenforge-agent
   cd ~/Projects/zenforge-agent
   ```

4. **Configure environment variables**
   ```bash
   cp .env.example .env
   ```
   Edit `.env` with your values:
   ```
   OPENAI_API_KEY=sk-your-key-here
   DATABASE_URL=postgresql://postgres:yourpassword@localhost:5432/zenforge
   SESSION_SECRET=any-random-string-here
   PORT=5000
   ```

5. **Install dependencies**
   ```bash
   npm install
   ```

6. **Push database schema**
   ```bash
   npm run db:push
   ```

7. **Start the application**
   ```bash
   npm run dev
   ```

8. **Open in browser**
   - Navigate to [http://localhost:5000](http://localhost:5000)

---

## Project Structure

```
zenforge-agent/
├── front_end/              # React frontend (TypeScript + Tailwind + shadcn/ui)
│   ├── src/
│   │   ├── components/     # UI components
│   │   ├── pages/          # Page routes
│   │   ├── hooks/          # Custom hooks
│   │   └── lib/            # Utilities and types
│   └── index.html
├── backend_code/           # Express backend (Node.js + TypeScript)
│   ├── index.ts            # Server entry point
│   ├── routes.ts           # API routes
│   ├── langgraph.ts        # LangGraph multi-agent pipeline
│   ├── llm.ts              # OpenAI integration
│   ├── storage.ts          # Database operations (Drizzle ORM)
│   └── db.ts               # PostgreSQL connection
├── shared/                 # Shared types and schemas
│   └── schema.ts           # Drizzle database schema
├── script_code/            # Build scripts
│   └── build.ts            # Production build script
├── attached_assets/        # Static assets
├── .env.example            # Environment variable template
├── package.json            # Dependencies and scripts
├── vite.config.ts          # Vite configuration
├── tsconfig.json           # TypeScript configuration
├── tailwind.config.ts      # Tailwind CSS configuration
└── drizzle.config.ts       # Drizzle ORM configuration
```

## AI/ML Tech Stack

- OpenAI GPT-4o
- OpenAI GPT-4o-mini
- LangGraph (StateGraph)
- LangChain
- Server-Sent Events (SSE)

## Available Scripts

| Command          | Description                        |
|------------------|------------------------------------|
| `npm run dev`    | Start development server           |
| `npm run build`  | Build for production               |
| `npm start`      | Run production build               |
| `npm run db:push`| Push database schema to PostgreSQL |

## Production Build

```bash
npm run build
npm start
```

---

Created by AI Agent | Powered by Zensar AES
