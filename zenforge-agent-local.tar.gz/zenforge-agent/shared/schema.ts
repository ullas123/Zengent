import { sql } from "drizzle-orm";
import { pgTable, text, varchar, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").notNull().default("draft"),
  spec: jsonb("spec"),
  fileTree: jsonb("file_tree"),
  generatedFiles: jsonb("generated_files"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export const generationLogs = pgTable("generation_logs", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  agent: text("agent").notNull(),
  message: text("message").notNull(),
  level: text("level").notNull().default("info"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertLogSchema = createInsertSchema(generationLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertLog = z.infer<typeof insertLogSchema>;
export type GenerationLog = typeof generationLogs.$inferSelect;

export const projectSpecSchema = z.object({
  requirements: z.string().optional(),
  features: z.string().optional(),
  frontend: z.string().optional(),
  backend: z.string().optional(),
  language: z.string().optional(),
  database: z.string().optional(),
  authEnabled: z.boolean().optional(),
  jwtEnabled: z.boolean().optional(),
  encryptionEnabled: z.boolean().optional(),
  deployment: z.string().optional(),
  cloud: z.string().optional(),
  compliance: z.string().optional(),
  logging: z.string().optional(),
  auditing: z.string().optional(),
});

export type ProjectSpec = z.infer<typeof projectSpecSchema>;

export interface FileNode {
  name: string;
  type: "file" | "folder";
  path: string;
  content?: string;
  children?: FileNode[];
  language?: string;
}
