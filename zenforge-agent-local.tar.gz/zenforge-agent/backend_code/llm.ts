import OpenAI from "openai";
import type { ProjectSpec, FileNode } from "@shared/schema";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function planProject(spec: ProjectSpec, requirements: string): Promise<FileNode[]> {
  const prompt = `You are a senior software architect. Based on the following project specification, create a complete project file/folder structure.

PROJECT REQUIREMENTS:
${requirements}

FEATURES:
${spec.features || "N/A"}

TECH STACK:
- Frontend: ${spec.frontend || "None"}
- Backend: ${spec.backend || "None"}
- Language: ${spec.language || "Python"}
- Database: ${spec.database || "None"}

SECURITY:
- Authentication: ${spec.authEnabled ? "Yes" : "No"}
- JWT: ${spec.jwtEnabled ? "Yes" : "No"}
- Encryption: ${spec.encryptionEnabled ? "Yes" : "No"}

DEPLOYMENT: ${spec.deployment || "None"}
CLOUD: ${spec.cloud || "None"}
COMPLIANCE: ${spec.compliance || "None"}
LOGGING: ${spec.logging || "None"}

Return a JSON object with a key "files" containing an array of file/folder nodes. Each node has:
- "name": string (file/folder name)
- "type": "file" or "folder"
- "path": string (full relative path like "src/app.py")
- "children": array of child nodes (only for folders)

Create a realistic, production-ready project structure with all necessary files including:
- Source code files
- Configuration files (package.json, requirements.txt, etc.)
- README.md
- .gitignore
- Test files
- Docker/deployment files if applicable

Keep it focused and practical (10-20 files maximum).

Example response format:
{"files": [{"name": "src", "type": "folder", "path": "src", "children": [{"name": "app.py", "type": "file", "path": "src/app.py"}]}, {"name": "README.md", "type": "file", "path": "README.md"}]}`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 4096,
    response_format: { type: "json_object" },
  });

  const content = response.choices[0]?.message?.content || "{}";
  console.log("[Planner] Raw LLM response length:", content.length);
  try {
    const parsed = JSON.parse(content);
    const tree = extractFileArray(parsed);
    console.log("[Planner] Extracted file count:", tree.length);
    return tree;
  } catch (err) {
    console.error("[Planner] JSON parse error:", err);
    return [];
  }
}

export async function generateFileCode(
  filePath: string,
  spec: ProjectSpec,
  requirements: string,
  projectTree: FileNode[]
): Promise<string> {
  const treeStr = formatTree(projectTree);
  const ext = filePath.split(".").pop()?.toLowerCase() || "";

  const prompt = `You are a senior software developer. Write complete, production-ready code for the file: "${filePath}"

PROJECT REQUIREMENTS:
${requirements}

FEATURES:
${spec.features || "N/A"}

TECH STACK: ${spec.frontend || "None"} frontend, ${spec.backend || "None"} backend, ${spec.language || "Python"} language, ${spec.database || "None"} database
SECURITY: Auth=${spec.authEnabled ? "Yes" : "No"}, JWT=${spec.jwtEnabled ? "Yes" : "No"}, Encryption=${spec.encryptionEnabled ? "Yes" : "No"}

PROJECT STRUCTURE:
${treeStr}

INSTRUCTIONS:
- Write COMPLETE, working code for "${filePath}"
- Use latest best practices and proper error handling
- Include all necessary imports
- Make it production-ready
- Follow the project's tech stack conventions
- For config files (package.json, requirements.txt, etc.), include all necessary dependencies
- For README.md files, include ALL of the following sections:
  1. Project title and description (include the project type and tech stack summary)
  2. Tech Stack (list all frameworks, libraries, languages, and databases used)
  3. Prerequisites (required software with exact version numbers, e.g. Node.js v18+, Python 3.10+)
  4. Installation steps — MUST include SEPARATE instructions for BOTH platforms:
     ## Installation (Windows)
     - Step-by-step commands using PowerShell or CMD
     - Use Windows-specific paths (backslash), tools (choco, winget, or manual download links)
     - Include how to install prerequisites on Windows (e.g. download Node.js from nodejs.org, install Python from python.org, install PostgreSQL from postgresql.org)
     - Use 'set' for environment variables (e.g. set DATABASE_URL=...)
     - Use 'npm install' / 'pip install -r requirements.txt' as appropriate
     ## Installation (macOS / Linux)
     - Step-by-step commands using Terminal
     - Use Homebrew where applicable (e.g. brew install node, brew install python, brew install postgresql)
     - Use 'export' for environment variables (e.g. export DATABASE_URL=...)
     - Use Unix paths (forward slash)
  5. Environment Setup (list ALL required environment variables with descriptions, e.g. DATABASE_URL, API keys, secret keys)
  6. How to Run (development mode and production mode commands)
  7. API Documentation or usage examples
  8. Project Structure overview (folder tree with descriptions)
  9. Testing instructions (how to run tests, what testing frameworks are used)
  10. Deployment instructions (Docker, cloud, or platform-specific)
  11. Troubleshooting (common issues and fixes for both Windows and Mac)
  12. License

Return ONLY the raw code content. No markdown fences, no explanation. Just the code.`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 4096,
  });

  let code = response.choices[0]?.message?.content || "";
  code = code.replace(/^```[\w]*\n?/, "").replace(/\n?```$/, "").trim();
  return code;
}

async function validatePackageJson(code: string): Promise<{ licenseIssues: string[]; versionIssues: string[] }> {
  const licenseIssues: string[] = [];
  const versionIssues: string[] = [];

  try {
    const pkg = JSON.parse(code);
    const allDeps: Record<string, string> = {
      ...(pkg.dependencies || {}),
      ...(pkg.devDependencies || {}),
    };

    const depNames = Object.keys(allDeps);
    if (depNames.length === 0) return { licenseIssues, versionIssues };

    const results = await Promise.allSettled(
      depNames.map(async (name) => {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8000);
        try {
          const resp = await fetch(`https://registry.npmjs.org/${encodeURIComponent(name)}`, {
            signal: controller.signal,
          });
          clearTimeout(timeout);
          if (!resp.ok) {
            versionIssues.push(`Package "${name}" not found on npm registry — may not exist or is private`);
            return;
          }
          const data = await resp.json() as any;

          const license = data.license || (data.versions && data["dist-tags"]?.latest && data.versions[data["dist-tags"].latest]?.license);
          const restrictedLicenses = ["GPL-3.0", "AGPL-3.0", "GPL-2.0", "AGPL-3.0-only", "GPL-3.0-only", "SSPL-1.0", "EUPL-1.1", "EUPL-1.2"];
          if (license && restrictedLicenses.some(r => typeof license === "string" && license.toUpperCase().includes(r.toUpperCase()))) {
            licenseIssues.push(`Package "${name}" uses restrictive license "${license}" — may have copyleft obligations`);
          } else if (!license) {
            licenseIssues.push(`Package "${name}" has no license specified — usage terms unclear`);
          }

          const specifiedVersion = allDeps[name].replace(/[\^~>=<]/g, "").trim();
          const availableVersions = Object.keys(data.versions || {});
          const latestVersion = data["dist-tags"]?.latest;
          if (specifiedVersion && availableVersions.length > 0) {
            const majorMatch = availableVersions.some(v => v.startsWith(specifiedVersion.split(".")[0] + "."));
            if (!majorMatch && specifiedVersion !== "*" && specifiedVersion !== "latest") {
              versionIssues.push(`Package "${name}@${allDeps[name]}" — major version may not exist. Latest: ${latestVersion}`);
            }
          }
        } catch (e: any) {
          clearTimeout(timeout);
          if (e.name === "AbortError") {
            versionIssues.push(`Package "${name}" — npm registry check timed out`);
          }
        }
      })
    );

  } catch {
    versionIssues.push("package.json is not valid JSON");
  }

  return { licenseIssues, versionIssues };
}

export async function reviewCode(
  filePath: string,
  code: string,
  spec: ProjectSpec
): Promise<{ issues: string[]; suggestions: string[] }> {
  const isPackageJson = filePath.endsWith("package.json");

  let packageValidation: { licenseIssues: string[]; versionIssues: string[] } | null = null;
  if (isPackageJson) {
    packageValidation = await validatePackageJson(code);
  }

  const packageJsonExtra = isPackageJson ? `

ADDITIONAL REVIEW REQUIREMENTS FOR package.json:
- Verify that all listed dependencies are real, commonly-used npm packages
- Check that version ranges use valid semver (e.g. ^1.0.0, ~2.3.0)
- Confirm the "license" field is set to a permissive open-source license (MIT, Apache-2.0, ISC, BSD-2-Clause, BSD-3-Clause preferred)
- Flag any packages with restrictive/copyleft licenses (GPL, AGPL, SSPL) as issues
- Ensure no deprecated or known-vulnerable packages are included
- Verify "scripts" section has appropriate dev/build/start commands` : "";

  const prompt = `You are a code reviewer. Briefly review the following code for the file "${filePath}".

TECH STACK: ${spec.language}, ${spec.frontend}, ${spec.backend}

CODE:
\`\`\`
${code.substring(0, 3000)}
\`\`\`
${packageJsonExtra}

Return a JSON object with:
- "issues": array of critical issues found (empty if none)
- "suggestions": array of improvement suggestions (1-3 max)

Keep it brief and actionable. Return only valid JSON.`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 1024,
    response_format: { type: "json_object" },
  });

  const content = response.choices[0]?.message?.content || "{}";
  try {
    const parsed = JSON.parse(content);
    let issues = parsed.issues || [];
    let suggestions = parsed.suggestions || [];

    if (packageValidation) {
      issues = [...packageValidation.licenseIssues, ...packageValidation.versionIssues, ...issues];
      if (packageValidation.licenseIssues.length > 0) {
        suggestions.push("Consider replacing packages with restrictive licenses with permissive alternatives (MIT, Apache-2.0, ISC)");
      }
    }

    return { issues, suggestions };
  } catch {
    return { issues: [], suggestions: [] };
  }
}

export async function updateFileWithPrompt(
  filePath: string,
  currentContent: string,
  userPrompt: string,
  spec: ProjectSpec,
  projectTree: FileNode[],
  allFiles: Record<string, string>
): Promise<string> {
  const treeStr = formatTree(projectTree);

  const contextFiles = Object.entries(allFiles)
    .filter(([p]) => p !== filePath)
    .slice(0, 5)
    .map(([p, c]) => `--- ${p} ---\n${c.substring(0, 1500)}`)
    .join("\n\n");

  const prompt = `You are a senior software developer. The user wants to update a file based on their instructions.

FILE PATH: "${filePath}"

CURRENT FILE CONTENT:
\`\`\`
${currentContent}
\`\`\`

USER'S UPDATE REQUEST:
${userPrompt}

TECH STACK: ${spec.frontend || "None"} frontend, ${spec.backend || "None"} backend, ${spec.language || "Python"} language, ${spec.database || "None"} database

PROJECT STRUCTURE:
${treeStr}

OTHER PROJECT FILES (for context):
${contextFiles}

INSTRUCTIONS:
- Apply the user's requested changes to the file
- Keep everything else in the file intact unless the change requires modifications
- Ensure the updated code is complete, working, and production-ready
- Maintain consistency with the rest of the project
- Include all necessary imports

Return ONLY the complete updated file content. No markdown fences, no explanation. Just the code.`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [{ role: "user", content: prompt }],
    max_tokens: 4096,
  });

  let code = response.choices[0]?.message?.content || "";
  code = code.replace(/^```[\w]*\n?/, "").replace(/\n?```$/, "").trim();
  return code;
}

export async function updateMultipleFiles(
  userPrompt: string,
  spec: ProjectSpec,
  projectTree: FileNode[],
  allFiles: Record<string, string>
): Promise<{ filePath: string; content: string }[]> {
  const treeStr = formatTree(projectTree);
  const fileList = Object.keys(allFiles).join("\n");

  const analysisPrompt = `You are a senior software architect. Based on the user's request, determine which files need to be modified or created.

USER'S REQUEST:
${userPrompt}

PROJECT FILES:
${fileList}

TECH STACK: ${spec.frontend || "None"} frontend, ${spec.backend || "None"} backend, ${spec.language || "Python"} language, ${spec.database || "None"} database

PROJECT STRUCTURE:
${treeStr}

Return a JSON object with:
- "files": array of file paths that need to be modified or created to fulfill this request
- "reason": brief explanation of what changes are needed

Keep the list focused - only include files that truly need changes. Return only valid JSON.`;

  const analysisResponse = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [{ role: "user", content: analysisPrompt }],
    max_tokens: 1024,
    response_format: { type: "json_object" },
  });

  const analysisContent = analysisResponse.choices[0]?.message?.content || "{}";
  let filesToUpdate: string[] = [];
  try {
    const parsed = JSON.parse(analysisContent);
    filesToUpdate = parsed.files || [];
  } catch {
    filesToUpdate = Object.keys(allFiles).slice(0, 3);
  }

  const results: { filePath: string; content: string }[] = [];

  for (const fp of filesToUpdate) {
    const currentContent = allFiles[fp] || "";
    try {
      const updatedContent = await updateFileWithPrompt(
        fp,
        currentContent,
        userPrompt,
        spec,
        projectTree,
        allFiles
      );
      results.push({ filePath: fp, content: updatedContent });
    } catch (error: any) {
      results.push({ filePath: fp, content: currentContent || `// Error updating: ${error.message}` });
    }
  }

  return results;
}

function formatTree(nodes: FileNode[], indent: string = ""): string {
  let result = "";
  for (const node of nodes) {
    result += `${indent}${node.type === "folder" ? "📁" : "📄"} ${node.name}\n`;
    if (node.children) {
      result += formatTree(node.children, indent + "  ");
    }
  }
  return result;
}

function collectFiles(nodes: FileNode[]): FileNode[] {
  const files: FileNode[] = [];
  for (const node of nodes) {
    if (node.type === "file") files.push(node);
    if (node.children) files.push(...collectFiles(node.children));
  }
  return files;
}

function extractFileArray(parsed: any): FileNode[] {
  if (Array.isArray(parsed)) return parsed;

  for (const key of ["files", "tree", "structure", "project", "fileTree", "file_tree", "root", "nodes"]) {
    if (parsed[key] && Array.isArray(parsed[key])) {
      return parsed[key];
    }
  }

  const values = Object.values(parsed);
  for (const val of values) {
    if (Array.isArray(val) && val.length > 0 && val[0] && typeof val[0] === "object" && ("name" in val[0] || "path" in val[0])) {
      return val as FileNode[];
    }
  }

  console.warn("[Planner] Could not extract file array from response keys:", Object.keys(parsed));
  return [];
}

export { collectFiles };
