import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { planProject, generateFileCode, reviewCode, collectFiles, updateMultipleFiles } from "./llm";
import { runForgeGraph, type AgentLog } from "./langgraph";
import type { ProjectSpec, FileNode } from "@shared/schema";
import archiver from "archiver";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getAllProjects();
      res.json(projects);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(parseInt(req.params.id));
      if (!project) return res.status(404).json({ error: "Project not found" });
      res.json(project);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/projects/generate", async (req, res) => {
    try {
      const { name, spec } = req.body as { name: string; spec: ProjectSpec };

      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      const send = (data: any) => {
        res.write(`data: ${JSON.stringify(data)}\n\n`);
      };

      const project = await storage.createProject({
        name,
        description: spec.requirements?.substring(0, 200) || "",
        status: "generating",
        spec: spec as any,
        fileTree: null,
        generatedFiles: null,
      });

      send({ type: "log", agent: "System", message: `Project "${name}" created (ID: ${project.id})` });
      send({ type: "log", agent: "System", message: `LangGraph StateGraph pipeline initialized — Planner → Coder → Reviewer` });
      send({ type: "progress", progress: 5 });

      await storage.createLog({ projectId: project.id, agent: "System", message: "LangGraph multi-agent pipeline started", level: "info" });

      try {
        const result = await runForgeGraph(
          spec,
          spec.requirements || spec.features || "",
          (log: AgentLog) => {
            send(log);
            if (log.agent && log.message) {
              storage.createLog({ projectId: project.id, agent: log.agent, message: log.message, level: log.level || "info" }).catch(() => {});
            }
          }
        );

        const updatedProject = await storage.updateProject(project.id, {
          status: result.status === "completed" ? "completed" : "failed",
          fileTree: result.fileTree as any,
          generatedFiles: result.generatedFiles as any,
        });

        send({ type: "complete", tree: result.fileTree, project: updatedProject });
        send({ type: "log", agent: "System", message: "LangGraph pipeline completed successfully", level: "success" });
      } catch (error: any) {
        send({ type: "error", message: `LangGraph pipeline failed: ${error.message}` });
        await storage.updateProject(project.id, { status: "failed" });
      }

      res.write("data: [DONE]\n\n");
      res.end();
    } catch (error: any) {
      console.error("Generation error:", error);
      if (!res.headersSent) {
        res.status(500).json({ error: error.message });
      } else {
        res.write(`data: ${JSON.stringify({ type: "error", message: error.message })}\n\n`);
        res.write("data: [DONE]\n\n");
        res.end();
      }
    }
  });

  app.post("/api/projects/:id/iterate", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const { prompt, fileTree, generatedFiles, spec } = req.body as {
        prompt: string;
        fileTree: FileNode[];
        generatedFiles: Record<string, string>;
        spec: ProjectSpec;
      };

      if (!prompt || !fileTree || !generatedFiles || !spec) {
        return res.status(400).json({ error: "Missing required fields: prompt, fileTree, generatedFiles, spec" });
      }

      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      const send = (data: any) => {
        res.write(`data: ${JSON.stringify(data)}\n\n`);
      };

      send({ type: "log", agent: "System", message: `Iterative update: "${prompt.substring(0, 100)}"` });
      send({ type: "agent", agent: "Planner", message: "Analyzing which files need updates..." });
      send({ type: "progress", progress: 10 });

      await storage.createLog({ projectId, agent: "Planner", message: `Iterative update requested: ${prompt.substring(0, 200)}`, level: "info" });

      const results = await updateMultipleFiles(prompt, spec, fileTree, generatedFiles);

      send({ type: "progress", progress: 50 });
      send({ type: "agent", agent: "Coder", message: `Updating ${results.length} file(s)...` });

      const updatedFiles = { ...generatedFiles };
      const updatedTree = JSON.parse(JSON.stringify(fileTree)) as FileNode[];

      for (let i = 0; i < results.length; i++) {
        const { filePath, content } = results[i];
        const oldContent = generatedFiles[filePath] || "";
        const changeInfo = computeChangedLines(oldContent, content);

        updatedFiles[filePath] = content;
        updateTreeContent(updatedTree, filePath, content);

        const progressPct = 50 + ((i + 1) / results.length) * 40;
        send({ type: "progress", progress: Math.round(progressPct) });
        send({ type: "log", agent: "Coder", message: `Updated: ${filePath}`, level: "success" });

        if (changeInfo) {
          send({ type: "log", agent: "Coder", message: `  ${changeInfo}`, level: "info" });
        }

        await storage.createLog({ projectId, agent: "Coder", message: `Iteratively updated: ${filePath} — ${changeInfo || "file rewritten"}`, level: "success" });
      }

      const updatedProject = await storage.updateProject(projectId, {
        fileTree: updatedTree as any,
        generatedFiles: updatedFiles as any,
      });

      send({ type: "progress", progress: 100 });
      send({ type: "complete", tree: updatedTree, project: updatedProject, updatedFiles });
      send({ type: "log", agent: "System", message: `Updated ${results.length} file(s) successfully`, level: "success" });

      res.write("data: [DONE]\n\n");
      res.end();
    } catch (error: any) {
      console.error("Iterate error:", error);
      if (!res.headersSent) {
        res.status(500).json({ error: error.message });
      } else {
        res.write(`data: ${JSON.stringify({ type: "error", message: error.message })}\n\n`);
        res.write("data: [DONE]\n\n");
        res.end();
      }
    }
  });

  app.get("/api/projects/:id/download", async (req, res) => {
    try {
      const project = await storage.getProject(parseInt(req.params.id));
      if (!project) return res.status(404).json({ error: "Project not found" });

      const files = project.generatedFiles as Record<string, string> | null;
      if (!files || Object.keys(files).length === 0) {
        return res.status(400).json({ error: "No generated files to download" });
      }

      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", `attachment; filename="${project.name.replace(/[^a-zA-Z0-9]/g, '_')}.zip"`);

      const archive = archiver("zip", { zlib: { level: 9 } });
      archive.pipe(res);

      for (const [filePath, content] of Object.entries(files)) {
        archive.append(content, { name: filePath });
      }

      await archive.finalize();
    } catch (error: any) {
      console.error("Download error:", error);
      if (!res.headersSent) {
        res.status(500).json({ error: error.message });
      }
    }
  });

  app.get("/api/projects/:id/logs", async (req, res) => {
    try {
      const logs = await storage.getLogsByProject(parseInt(req.params.id));
      res.json(logs);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      await storage.deleteProject(parseInt(req.params.id));
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  return httpServer;
}

function updateTreeContent(nodes: FileNode[], targetPath: string, content: string): void {
  for (const node of nodes) {
    if (node.path === targetPath) {
      node.content = content;
      return;
    }
    if (node.children) {
      updateTreeContent(node.children, targetPath, content);
    }
  }
}

function computeChangedLines(oldContent: string, newContent: string): string {
  if (!oldContent) return "New file created";

  const oldLines = oldContent.split("\n");
  const newLines = newContent.split("\n");
  const modified: number[] = [];
  const added: number[] = [];
  const removed: number[] = [];

  const maxLen = Math.max(oldLines.length, newLines.length);
  for (let i = 0; i < maxLen; i++) {
    if (i >= oldLines.length) {
      added.push(i + 1);
    } else if (i >= newLines.length) {
      removed.push(i + 1);
    } else if (oldLines[i] !== newLines[i]) {
      modified.push(i + 1);
    }
  }

  const parts: string[] = [];
  if (modified.length > 0) parts.push(`Modified lines: ${formatLineRanges(modified)}`);
  if (added.length > 0) parts.push(`Added lines: ${formatLineRanges(added)}`);
  if (removed.length > 0) parts.push(`Removed ${removed.length} line(s)`);

  if (parts.length === 0) return "No changes detected";
  return parts.join(" | ");
}

function formatLineRanges(lines: number[]): string {
  if (lines.length === 0) return "";
  const ranges: string[] = [];
  let start = lines[0];
  let end = lines[0];

  for (let i = 1; i < lines.length; i++) {
    if (lines[i] === end + 1) {
      end = lines[i];
    } else {
      ranges.push(start === end ? `${start}` : `${start}-${end}`);
      start = lines[i];
      end = lines[i];
    }
  }
  ranges.push(start === end ? `${start}` : `${start}-${end}`);

  if (ranges.length > 8) {
    return ranges.slice(0, 8).join(", ") + ` (+${ranges.length - 8} more)`;
  }
  return ranges.join(", ");
}

function countFilesInTree(nodes: FileNode[]): number {
  let count = 0;
  for (const node of nodes) {
    if (node.type === "file") count++;
    if (node.children) count += countFilesInTree(node.children);
  }
  return count;
}
