import { db } from "./db";
import { projects, generationLogs, type Project, type InsertProject, type GenerationLog, type InsertLog } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createProject(data: InsertProject): Promise<Project>;
  getProject(id: number): Promise<Project | undefined>;
  getAllProjects(): Promise<Project[]>;
  updateProject(id: number, data: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<void>;
  createLog(data: InsertLog): Promise<GenerationLog>;
  getLogsByProject(projectId: number): Promise<GenerationLog[]>;
}

class DatabaseStorage implements IStorage {
  async createProject(data: InsertProject): Promise<Project> {
    const [project] = await db.insert(projects).values(data).returning();
    return project;
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async getAllProjects(): Promise<Project[]> {
    return db.select().from(projects).orderBy(desc(projects.createdAt));
  }

  async updateProject(id: number, data: Partial<InsertProject>): Promise<Project | undefined> {
    const [project] = await db
      .update(projects)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return project;
  }

  async deleteProject(id: number): Promise<void> {
    await db.delete(generationLogs).where(eq(generationLogs.projectId, id));
    await db.delete(projects).where(eq(projects.id, id));
  }

  async createLog(data: InsertLog): Promise<GenerationLog> {
    const [log] = await db.insert(generationLogs).values(data).returning();
    return log;
  }

  async getLogsByProject(projectId: number): Promise<GenerationLog[]> {
    return db.select().from(generationLogs).where(eq(generationLogs.projectId, projectId)).orderBy(generationLogs.createdAt);
  }
}

export const storage = new DatabaseStorage();
