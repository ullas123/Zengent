import { StateGraph, Annotation, START, END } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";
import type { ProjectSpec, FileNode } from "@shared/schema";

const plannerModel = new ChatOpenAI({
  modelName: "gpt-4o",
  temperature: 0.3,
  maxTokens: 4096,
  openAIApiKey: process.env.OPENAI_API_KEY,
});

const coderModel = new ChatOpenAI({
  modelName: "gpt-4o",
  temperature: 0.2,
  maxTokens: 4096,
  openAIApiKey: process.env.OPENAI_API_KEY,
});

const reviewerModel = new ChatOpenAI({
  modelName: "gpt-4o-mini",
  temperature: 0.1,
  maxTokens: 1024,
  openAIApiKey: process.env.OPENAI_API_KEY,
});

export interface AgentLog {
  type: string;
  agent?: string;
  message?: string;
  level?: string;
  progress?: number;
  tree?: FileNode[];
  path?: string;
  project?: any;
  updatedFiles?: Record<string, string>;
}

const ForgeState = Annotation.Root({
  spec: Annotation<ProjectSpec>,
  requirements: Annotation<string>,
  fileTree: Annotation<FileNode[]>({
    reducer: (_prev: FileNode[], next: FileNode[]) => next,
    default: () => [],
  }),
  generatedFiles: Annotation<Record<string, string>>({
    reducer: (prev: Record<string, string>, next: Record<string, string>) => ({ ...prev, ...next }),
    default: () => ({}),
  }),
  reviews: Annotation<Record<string, { issues: string[]; suggestions: string[] }>>({
    reducer: (prev: Record<string, { issues: string[]; suggestions: string[] }>, next: Record<string, { issues: string[]; suggestions: string[] }>) => ({ ...prev, ...next }),
    default: () => ({}),
  }),
  logs: Annotation<AgentLog[]>({
    reducer: (prev: AgentLog[], next: AgentLog[]) => [...prev, ...next],
    default: () => [],
  }),
  currentFileIndex: Annotation<number>({
    reducer: (_prev: number, next: number) => next,
    default: () => 0,
  }),
  totalFiles: Annotation<number>({
    reducer: (_prev: number, next: number) => next,
    default: () => 0,
  }),
  status: Annotation<string>({
    reducer: (_prev: string, next: string) => next,
    default: () => "pending",
  }),
  error: Annotation<string | null>({
    reducer: (_prev: string | null, next: string | null) => next,
    default: () => null,
  }),
});

async function plannerNode(state: typeof ForgeState.State) {
  const spec = state.spec;
  const requirements = state.requirements;

  const logs: AgentLog[] = [
    { type: "agent", agent: "Planner", message: "Analyzing requirements and designing project structure..." },
    { type: "progress", progress: 10 },
  ];

  const prompt = `You are a senior software architect using TOGAF ADM methodology and Sitecore Helix architecture. Based on the following project specification, create a complete project file/folder structure.

PROJECT REQUIREMENTS:
${requirements}

FEATURES:
${spec.features || "N/A"}

TECH STACK:
- Frontend: ${spec.frontend || "None"}
- Backend: ${spec.backend || "None"}
- Language: ${spec.language || "Python"}
- Database: ${spec.database || "None"}

SECURITY:
- Authentication: ${spec.authEnabled ? "Yes" : "No"}
- JWT: ${spec.jwtEnabled ? "Yes" : "No"}
- Encryption: ${spec.encryptionEnabled ? "Yes" : "No"}

DEPLOYMENT: ${spec.deployment || "None"}
CLOUD: ${spec.cloud || "None"}
COMPLIANCE: ${spec.compliance || "None"}
LOGGING: ${spec.logging || "None"}

Return a JSON object with a key "files" containing an array of file/folder nodes. Each node has:
- "name": string (file/folder name)
- "type": "file" or "folder"
- "path": string (full relative path like "src/app.py")
- "children": array of child nodes (only for folders)

Create a realistic, production-ready project structure with all necessary files including:
- Source code files
- Configuration files (package.json, requirements.txt, etc.)
- README.md
- .gitignore
- Test files
- Docker/deployment files if applicable

Keep it focused and practical (10-20 files maximum).

Example response format:
{"files": [{"name": "src", "type": "folder", "path": "src", "children": [{"name": "app.py", "type": "file", "path": "src/app.py"}]}, {"name": "README.md", "type": "file", "path": "README.md"}]}`;

  try {
    const response = await plannerModel.invoke([{ role: "user", content: prompt }], {
      response_format: { type: "json_object" },
    });

    const content = typeof response.content === "string" ? response.content : JSON.stringify(response.content);
    const parsed = JSON.parse(content);
    const tree = extractFileArray(parsed);
    const allFiles = collectFiles(tree);

    logs.push(
      { type: "tree", tree },
      { type: "progress", progress: 25 },
      { type: "log", agent: "Planner", message: `Designed ${allFiles.length} files in project structure using TOGAF ADM & Sitecore Helix model`, level: "success" }
    );

    return {
      fileTree: tree,
      totalFiles: allFiles.length,
      logs,
      status: "planned",
    };
  } catch (error: any) {
    logs.push({ type: "error", message: `Planner failed: ${error.message}` });
    return { logs, status: "failed", error: error.message };
  }
}

async function coderNode(state: typeof ForgeState.State) {
  const spec = state.spec;
  const requirements = state.requirements;
  const fileTree = state.fileTree;
  const allFiles = collectFiles(fileTree);
  const totalFiles = allFiles.length;
  const treeStr = formatTree(fileTree);

  const logs: AgentLog[] = [
    { type: "agent", agent: "Coder", message: `Generating production-ready code for ${totalFiles} files...` },
  ];

  const generatedFiles: Record<string, string> = {};

  for (let i = 0; i < allFiles.length; i++) {
    const file = allFiles[i];
    const progressPct = 25 + ((i / totalFiles) * 50);
    logs.push(
      { type: "progress", progress: Math.round(progressPct) },
      { type: "log", agent: "Coder", message: `Generating: ${file.path} (${i + 1}/${totalFiles})` }
    );

    const prompt = `You are a senior software developer. Write complete, production-ready code for the file: "${file.path}"

PROJECT REQUIREMENTS:
${requirements}

FEATURES:
${spec.features || "N/A"}

TECH STACK: ${spec.frontend || "None"} frontend, ${spec.backend || "None"} backend, ${spec.language || "Python"} language, ${spec.database || "None"} database
SECURITY: Auth=${spec.authEnabled ? "Yes" : "No"}, JWT=${spec.jwtEnabled ? "Yes" : "No"}, Encryption=${spec.encryptionEnabled ? "Yes" : "No"}

PROJECT STRUCTURE:
${treeStr}

INSTRUCTIONS:
- Write COMPLETE, working code for "${file.path}"
- Use latest best practices and proper error handling
- Include all necessary imports
- Make it production-ready
- Follow the project's tech stack conventions
- For config files (package.json, requirements.txt, etc.), include all necessary dependencies
- For README.md files, include ALL of the following sections:
  1. Project title and description
  2. Tech Stack
  3. Prerequisites
  4. Installation steps — MUST include SEPARATE instructions for BOTH platforms:
     ## Installation (Windows)
     - Step-by-step commands using PowerShell or CMD
     - Use Windows-specific paths, tools (choco, winget, or manual download links)
     - Use 'set' for environment variables
     ## Installation (macOS / Linux)
     - Step-by-step commands using Terminal
     - Use Homebrew where applicable
     - Use 'export' for environment variables
  5. Environment Setup
  6. How to Run
  7. API Documentation or usage examples
  8. Project Structure overview
  9. Testing instructions
  10. Deployment instructions
  11. Troubleshooting
  12. License

Return ONLY the raw code content. No markdown fences, no explanation. Just the code.`;

    try {
      const response = await coderModel.invoke([{ role: "user", content: prompt }]);
      let code = typeof response.content === "string" ? response.content : JSON.stringify(response.content);
      code = code.replace(/^```[\w]*\n?/, "").replace(/\n?```$/, "").trim();
      generatedFiles[file.path] = code;
      logs.push(
        { type: "file", path: file.path },
        { type: "log", agent: "Coder", message: `Generated: ${file.path}`, level: "success" }
      );
    } catch (error: any) {
      const errorMsg = `Failed to generate ${file.path}: ${error.message}`;
      logs.push({ type: "log", agent: "Coder", message: errorMsg, level: "error" });
      generatedFiles[file.path] = `// Error generating this file: ${error.message}`;
    }
  }

  logs.push({ type: "progress", progress: 75 });

  return {
    generatedFiles,
    logs,
    status: "coded",
  };
}

async function validatePackageJson(code: string): Promise<{ licenseIssues: string[]; versionIssues: string[] }> {
  const licenseIssues: string[] = [];
  const versionIssues: string[] = [];

  try {
    const pkg = JSON.parse(code);
    const allDeps: Record<string, string> = {
      ...(pkg.dependencies || {}),
      ...(pkg.devDependencies || {}),
    };

    const depNames = Object.keys(allDeps);
    if (depNames.length === 0) return { licenseIssues, versionIssues };

    await Promise.allSettled(
      depNames.map(async (name) => {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8000);
        try {
          const resp = await fetch(`https://registry.npmjs.org/${encodeURIComponent(name)}`, {
            signal: controller.signal,
          });
          clearTimeout(timeout);
          if (!resp.ok) {
            versionIssues.push(`Package "${name}" not found on npm registry`);
            return;
          }
          const data = await resp.json() as any;

          const license = data.license || (data.versions && data["dist-tags"]?.latest && data.versions[data["dist-tags"].latest]?.license);
          const restrictedLicenses = ["GPL-3.0", "AGPL-3.0", "GPL-2.0", "AGPL-3.0-only", "GPL-3.0-only", "SSPL-1.0", "EUPL-1.1", "EUPL-1.2"];
          if (license && restrictedLicenses.some(r => typeof license === "string" && license.toUpperCase().includes(r.toUpperCase()))) {
            licenseIssues.push(`Package "${name}" uses restrictive license "${license}" — copyleft obligations`);
          } else if (!license) {
            licenseIssues.push(`Package "${name}" has no license specified`);
          }

          const specifiedVersion = allDeps[name].replace(/[\^~>=<]/g, "").trim();
          const availableVersions = Object.keys(data.versions || {});
          const latestVersion = data["dist-tags"]?.latest;
          if (specifiedVersion && availableVersions.length > 0) {
            const majorMatch = availableVersions.some(v => v.startsWith(specifiedVersion.split(".")[0] + "."));
            if (!majorMatch && specifiedVersion !== "*" && specifiedVersion !== "latest") {
              versionIssues.push(`Package "${name}@${allDeps[name]}" — major version may not exist. Latest: ${latestVersion}`);
            }
          }
        } catch (e: any) {
          clearTimeout(timeout);
          if (e.name === "AbortError") {
            versionIssues.push(`Package "${name}" — npm registry check timed out`);
          }
        }
      })
    );
  } catch {
    versionIssues.push("package.json is not valid JSON");
  }

  return { licenseIssues, versionIssues };
}

async function reviewerNode(state: typeof ForgeState.State) {
  const spec = state.spec;
  const generatedFiles = state.generatedFiles;
  const fileTree = state.fileTree;

  const logs: AgentLog[] = [
    { type: "agent", agent: "Reviewer", message: "Reviewing generated code for quality, security, and license compliance..." },
  ];

  const allFiles = collectFiles(fileTree);
  const filesToReview = allFiles.slice(0, 5);
  const reviews: Record<string, { issues: string[]; suggestions: string[] }> = {};

  for (let i = 0; i < filesToReview.length; i++) {
    const file = filesToReview[i];
    const code = generatedFiles[file.path];
    if (!code || code.startsWith("// Error")) continue;

    const progressPct = 75 + ((i / filesToReview.length) * 20);
    logs.push({ type: "progress", progress: Math.round(progressPct) });

    const isPackageJson = file.path.endsWith("package.json");
    let packageValidation: { licenseIssues: string[]; versionIssues: string[] } | null = null;
    if (isPackageJson) {
      packageValidation = await validatePackageJson(code);
    }

    const packageJsonExtra = isPackageJson ? `

ADDITIONAL REVIEW REQUIREMENTS FOR package.json:
- Verify that all listed dependencies are real, commonly-used npm packages
- Check that version ranges use valid semver
- Confirm the "license" field is set to a permissive license (MIT, Apache-2.0, ISC, BSD preferred)
- Flag any packages with restrictive/copyleft licenses (GPL, AGPL, SSPL)
- Ensure no deprecated or known-vulnerable packages are included` : "";

    const prompt = `You are a code reviewer performing OWASP-aligned security analysis. Review the following code for the file "${file.path}".

TECH STACK: ${spec.language}, ${spec.frontend}, ${spec.backend}

CODE:
\`\`\`
${code.substring(0, 3000)}
\`\`\`
${packageJsonExtra}

Return a JSON object with:
- "issues": array of critical issues found (empty if none)
- "suggestions": array of improvement suggestions (1-3 max)

Keep it brief and actionable. Return only valid JSON.`;

    try {
      const response = await reviewerModel.invoke([{ role: "user", content: prompt }], {
        response_format: { type: "json_object" },
      });

      const content = typeof response.content === "string" ? response.content : JSON.stringify(response.content);
      const parsed = JSON.parse(content);
      let issues = parsed.issues || [];
      let suggestions = parsed.suggestions || [];

      if (packageValidation) {
        issues = [...packageValidation.licenseIssues, ...packageValidation.versionIssues, ...issues];
        if (packageValidation.licenseIssues.length > 0) {
          suggestions.push("Consider replacing packages with restrictive licenses with permissive alternatives");
        }
      }

      reviews[file.path] = { issues, suggestions };

      if (issues.length > 0) {
        logs.push({ type: "log", agent: "Reviewer", message: `${file.path}: ${issues.join("; ")}`, level: "warning" });
      }
      if (suggestions.length > 0) {
        logs.push({ type: "log", agent: "Reviewer", message: `${file.path} suggestions: ${suggestions.join("; ")}`, level: "info" });
      }
      if (issues.length === 0) {
        logs.push({ type: "log", agent: "Reviewer", message: `${file.path}: Looks good!`, level: "success" });
      }
    } catch (error: any) {
      logs.push({ type: "log", agent: "Reviewer", message: `Could not review ${file.path}: ${error.message}`, level: "warning" });
    }
  }

  logs.push({ type: "progress", progress: 100 });

  return {
    reviews,
    logs,
    status: "completed",
  };
}

function shouldContinueAfterPlanner(state: typeof ForgeState.State): string {
  if (state.status === "failed" || state.error) {
    return END;
  }
  return "coder";
}

function shouldContinueAfterCoder(state: typeof ForgeState.State): string {
  const allFiles = collectFiles(state.fileTree);
  const successfulFiles = allFiles.filter(f => {
    const code = state.generatedFiles[f.path];
    return code && !code.startsWith("// Error");
  });

  if (successfulFiles.length === 0) {
    return END;
  }
  return "reviewer";
}

const forgeGraph = new StateGraph(ForgeState)
  .addNode("planner", plannerNode)
  .addNode("coder", coderNode)
  .addNode("reviewer", reviewerNode)
  .addEdge(START, "planner")
  .addConditionalEdges("planner", shouldContinueAfterPlanner, {
    coder: "coder",
    [END]: END,
  })
  .addConditionalEdges("coder", shouldContinueAfterCoder, {
    reviewer: "reviewer",
    [END]: END,
  })
  .addEdge("reviewer", END)
  .compile();

export async function runForgeGraph(
  spec: ProjectSpec,
  requirements: string,
  onLog: (log: AgentLog) => void
): Promise<{
  fileTree: FileNode[];
  generatedFiles: Record<string, string>;
  reviews: Record<string, { issues: string[]; suggestions: string[] }>;
  status: string;
}> {
  const initialState = {
    spec,
    requirements,
    fileTree: [] as FileNode[],
    generatedFiles: {} as Record<string, string>,
    reviews: {} as Record<string, { issues: string[]; suggestions: string[] }>,
    logs: [] as AgentLog[],
    currentFileIndex: 0,
    totalFiles: 0,
    status: "pending",
    error: null as string | null,
  };

  const stream = await forgeGraph.stream(initialState, {
    streamMode: "updates" as const,
  });

  let finalFileTree: FileNode[] = [];
  let finalGeneratedFiles: Record<string, string> = {};
  let finalReviews: Record<string, { issues: string[]; suggestions: string[] }> = {};
  let finalStatus = "pending";

  for await (const event of stream) {
    for (const [_nodeName, nodeOutput] of Object.entries(event)) {
      const output = nodeOutput as any;

      if (output.fileTree) finalFileTree = output.fileTree;
      if (output.generatedFiles) finalGeneratedFiles = { ...finalGeneratedFiles, ...output.generatedFiles };
      if (output.reviews) finalReviews = { ...finalReviews, ...output.reviews };
      if (output.status) finalStatus = output.status;

      if (output.logs && Array.isArray(output.logs)) {
        for (const log of output.logs) {
          onLog(log);
        }
      }
    }
  }

  const allFiles = collectFiles(finalFileTree);
  for (const file of allFiles) {
    if (finalGeneratedFiles[file.path]) {
      file.content = finalGeneratedFiles[file.path];
    }
  }

  return {
    fileTree: finalFileTree,
    generatedFiles: finalGeneratedFiles,
    reviews: finalReviews,
    status: finalStatus,
  };
}

function formatTree(nodes: FileNode[], indent: string = ""): string {
  let result = "";
  for (const node of nodes) {
    result += `${indent}${node.type === "folder" ? "📁" : "📄"} ${node.name}\n`;
    if (node.children) {
      result += formatTree(node.children, indent + "  ");
    }
  }
  return result;
}

export function collectFiles(nodes: FileNode[]): FileNode[] {
  const files: FileNode[] = [];
  for (const node of nodes) {
    if (node.type === "file") files.push(node);
    if (node.children) files.push(...collectFiles(node.children));
  }
  return files;
}

function extractFileArray(parsed: any): FileNode[] {
  if (Array.isArray(parsed)) return parsed;

  for (const key of ["files", "tree", "structure", "project", "fileTree", "file_tree", "root", "nodes"]) {
    if (parsed[key] && Array.isArray(parsed[key])) {
      return parsed[key];
    }
  }

  const values = Object.values(parsed);
  for (const val of values) {
    if (Array.isArray(val) && val.length > 0 && val[0] && typeof val[0] === "object" && ("name" in val[0] || "path" in val[0])) {
      return val as FileNode[];
    }
  }

  return [];
}
