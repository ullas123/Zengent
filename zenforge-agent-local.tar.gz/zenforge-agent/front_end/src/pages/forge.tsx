import { useState, useCallback, useRef } from "react";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { Header } from "@/components/header";
import { SetupWizard } from "@/components/setup-wizard";
import { FileExplorer } from "@/components/file-explorer";
import { CodeViewer } from "@/components/code-viewer";
import { ProgressPanel } from "@/components/progress-panel";
import { IterativePrompt } from "@/components/iterative-prompt";
import ProjectArchitectureDiagram from "@/components/project-architecture-diagram";
import { useToast } from "@/hooks/use-toast";
import type { ProjectSpec, FileNode, LogEntry, Project } from "@/lib/types";
import { DEFAULT_SPEC } from "@/lib/types";

export default function ForgePage() {
  const { toast } = useToast();
  const [spec, setSpec] = useState<ProjectSpec>({ ...DEFAULT_SPEC });
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [fileTree, setFileTree] = useState<FileNode[]>([]);
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isIterating, setIsIterating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [activeAgent, setActiveAgent] = useState("");
  const [projectName, setProjectName] = useState("");
  const [promptHistory, setPromptHistory] = useState<string[]>([]);
  const [archDiagramOpen, setArchDiagramOpen] = useState(false);
  const generatedFilesRef = useRef<Record<string, string>>({});

  const updateSpec = useCallback((partial: Partial<ProjectSpec>) => {
    setSpec(prev => ({ ...prev, ...partial }));
  }, []);

  const addLog = useCallback((agent: string, message: string, level: string = "info") => {
    setLogs(prev => [...prev, {
      id: Date.now() + Math.random(),
      agent,
      message,
      level,
      createdAt: new Date().toISOString(),
    }]);
  }, []);

  const handleFileUpload = useCallback((content: string) => {
    const lines = content.split("\n");
    const title = lines.find(l => l.startsWith("# "))?.replace("# ", "") || "Uploaded Project";
    setProjectName(title);
    updateSpec({
      requirements: content,
      features: "",
    });
    toast({
      title: "File uploaded",
      description: `Loaded "${title}" requirements`,
    });
  }, [updateSpec, toast]);

  const processSSEStream = useCallback(async (response: Response, onComplete?: (event: any) => void) => {
    const reader = response.body?.getReader();
    if (!reader) throw new Error("No response body");

    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const data = line.slice(6).trim();
        if (!data || data === "[DONE]") continue;

        try {
          const event = JSON.parse(data);

          switch (event.type) {
            case "agent":
              setActiveAgent(event.agent);
              addLog(event.agent, event.message, "info");
              break;
            case "progress":
              setProgress(event.progress);
              break;
            case "log":
              addLog(event.agent || "System", event.message, event.level || "info");
              break;
            case "file":
              addLog("Coder", `Generated: ${event.path}`, "success");
              break;
            case "tree":
              setFileTree(event.tree);
              addLog("Planner", "Project structure created", "success");
              break;
            case "files":
              setFileTree(event.tree);
              if (event.tree.length > 0) {
                const firstFile = findFirstFile(event.tree);
                if (firstFile) setSelectedFile(firstFile);
              }
              break;
            case "complete":
              if (onComplete) {
                onComplete(event);
              } else {
                setFileTree(event.tree || []);
                setCurrentProject(event.project);
                addLog("System", "Project generation complete!", "success");
                if (event.tree?.length > 0) {
                  const firstFile = findFirstFile(event.tree);
                  if (firstFile) setSelectedFile(firstFile);
                }
              }
              break;
            case "error":
              addLog("System", event.message, "error");
              break;
          }
        } catch (e) {
          // skip malformed JSON
        }
      }
    }
  }, [addLog]);

  const handleGenerate = useCallback(async () => {
    if (!spec.requirements && !spec.features) {
      toast({ title: "Missing requirements", description: "Please enter project requirements first.", variant: "destructive" });
      return;
    }

    setIsGenerating(true);
    setProgress(0);
    setLogs([]);
    setFileTree([]);
    setSelectedFile(null);
    setActiveAgent("System");
    setPromptHistory([]);
    generatedFilesRef.current = {};

    const name = projectName || spec.requirements.split("\n")[0]?.substring(0, 50) || "New Project";
    setProjectName(name);

    addLog("System", `Starting project generation: "${name}"`, "info");
    addLog("System", `Tech Stack: ${spec.frontend} + ${spec.backend} + ${spec.language} + ${spec.database}`, "info");

    try {
      const response = await fetch("/api/projects/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, spec }),
      });

      if (!response.ok) {
        throw new Error(`Generation failed: ${response.statusText}`);
      }

      await processSSEStream(response, (event) => {
        const tree = event.tree || [];
        setFileTree(tree);
        setCurrentProject(event.project);
        addLog("System", "Project generation complete!", "success");

        const files = collectGeneratedFiles(tree);
        generatedFilesRef.current = files;

        if (tree.length > 0) {
          const firstFile = findFirstFile(tree);
          if (firstFile) setSelectedFile(firstFile);
        }
      });
    } catch (error: any) {
      addLog("System", `Error: ${error.message}`, "error");
      toast({ title: "Generation failed", description: error.message, variant: "destructive" });
    } finally {
      setIsGenerating(false);
      setProgress(100);
      setActiveAgent("");
    }
  }, [spec, projectName, addLog, toast, processSSEStream]);

  const handleIterate = useCallback(async (prompt: string) => {
    if (!currentProject?.id || isIterating) return;

    setIsIterating(true);
    setProgress(0);
    setActiveAgent("System");

    setPromptHistory(prev => [...prev, prompt]);
    addLog("System", `Iterative update: "${prompt}"`, "info");

    try {
      const response = await fetch(`/api/projects/${currentProject.id}/iterate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          fileTree,
          generatedFiles: generatedFilesRef.current,
          spec,
        }),
      });

      if (!response.ok) {
        throw new Error(`Update failed: ${response.statusText}`);
      }

      await processSSEStream(response, (event) => {
        const tree = event.tree || [];
        setFileTree(tree);
        setCurrentProject(event.project);
        addLog("System", "Iterative update complete!", "success");

        if (event.updatedFiles) {
          generatedFilesRef.current = { ...generatedFilesRef.current, ...event.updatedFiles };
        }

        const files = collectGeneratedFiles(tree);
        generatedFilesRef.current = files;

        if (selectedFile) {
          const updated = findFileByPath(tree, selectedFile.path);
          if (updated) setSelectedFile(updated);
        }
      });
    } catch (error: any) {
      addLog("System", `Error: ${error.message}`, "error");
      toast({ title: "Update failed", description: error.message, variant: "destructive" });
    } finally {
      setIsIterating(false);
      setProgress(100);
      setActiveAgent("");
    }
  }, [currentProject, fileTree, spec, isIterating, selectedFile, addLog, toast, processSSEStream]);

  const handleNewProject = useCallback(() => {
    setSpec({ ...DEFAULT_SPEC });
    setCurrentProject(null);
    setFileTree([]);
    setSelectedFile(null);
    setLogs([]);
    setIsGenerating(false);
    setIsIterating(false);
    setProgress(0);
    setActiveAgent("");
    setProjectName("");
    setPromptHistory([]);
    generatedFilesRef.current = {};
  }, []);

  const handleDownload = useCallback(async () => {
    if (!currentProject?.id) {
      toast({ title: "No project to download", variant: "destructive" });
      return;
    }
    try {
      const response = await fetch(`/api/projects/${currentProject.id}/download`);
      if (!response.ok) throw new Error("Download failed");
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${projectName || "project"}.zip`;
      a.click();
      URL.revokeObjectURL(url);
      toast({ title: "Download started" });
    } catch (error: any) {
      toast({ title: "Download failed", description: error.message, variant: "destructive" });
    }
  }, [currentProject, projectName, toast]);

  const handleRegenerate = useCallback(() => {
    handleGenerate();
  }, [handleGenerate]);

  const handleUpdateContent = useCallback((path: string, content: string) => {
    setFileTree(prev => updateFileContent(prev, path, content));
    setSelectedFile(prev => prev && prev.path === path ? { ...prev, content } : prev);
    generatedFilesRef.current[path] = content;
  }, []);

  return (
    <div className="flex flex-col h-screen bg-background">
      <div className="flex items-center">
        <div className="flex-1">
          <Header
            projectName={projectName}
            isGenerating={isGenerating || isIterating}
            hasFiles={fileTree.length > 0}
            onNewProject={handleNewProject}
            onDownload={handleDownload}
            onRegenerate={handleRegenerate}
            onShowArchitecture={() => setArchDiagramOpen(true)}
          />
        </div>
        <div className="pr-2 border-b bg-card flex items-center" style={{ minHeight: "3rem" }}>
        </div>
      </div>

      <ResizablePanelGroup direction="horizontal" className="flex-1">
        <ResizablePanel defaultSize={22} minSize={15} maxSize={35}>
          <ResizablePanelGroup direction="vertical">
            <ResizablePanel defaultSize={65} minSize={30}>
              <SetupWizard
                spec={spec}
                onUpdate={updateSpec}
                onGenerate={handleGenerate}
                isGenerating={isGenerating}
                onFileUpload={handleFileUpload}
              />
            </ResizablePanel>
            <ResizableHandle withHandle />
            <ResizablePanel defaultSize={35} minSize={20}>
              <IterativePrompt
                onSubmit={handleIterate}
                isUpdating={isIterating}
                hasProject={currentProject !== null && fileTree.length > 0}
                promptHistory={promptHistory}
              />
            </ResizablePanel>
          </ResizablePanelGroup>
        </ResizablePanel>

        <ResizableHandle withHandle />

        <ResizablePanel defaultSize={35} minSize={20}>
          <ProgressPanel
            logs={logs}
            isGenerating={isGenerating || isIterating}
            progress={progress}
            activeAgent={activeAgent}
          />
        </ResizablePanel>

        <ResizableHandle withHandle />

        <ResizablePanel defaultSize={43} minSize={25}>
          <ResizablePanelGroup direction="vertical">
            <ResizablePanel defaultSize={30} minSize={15}>
              <FileExplorer
                files={fileTree}
                selectedFile={selectedFile}
                onSelectFile={setSelectedFile}
              />
            </ResizablePanel>
            <ResizableHandle withHandle />
            <ResizablePanel defaultSize={70} minSize={30}>
              <CodeViewer
                file={selectedFile}
                onUpdateContent={handleUpdateContent}
              />
            </ResizablePanel>
          </ResizablePanelGroup>
        </ResizablePanel>
      </ResizablePanelGroup>

      <div className="flex items-center justify-center py-1 border-t border-border bg-card/50 text-[10px] text-muted-foreground" data-testid="text-created-by">
        Created by AI Agent
      </div>

      <ProjectArchitectureDiagram
        open={archDiagramOpen}
        onOpenChange={setArchDiagramOpen}
        fileTree={fileTree}
        spec={spec}
        projectName={projectName}
      />
    </div>
  );
}

function findFirstFile(nodes: FileNode[]): FileNode | null {
  for (const node of nodes) {
    if (node.type === "file" && node.content) return node;
    if (node.children) {
      const found = findFirstFile(node.children);
      if (found) return found;
    }
  }
  return null;
}

function findFileByPath(nodes: FileNode[], path: string): FileNode | null {
  for (const node of nodes) {
    if (node.path === path) return node;
    if (node.children) {
      const found = findFileByPath(node.children, path);
      if (found) return found;
    }
  }
  return null;
}

function collectGeneratedFiles(nodes: FileNode[]): Record<string, string> {
  const files: Record<string, string> = {};
  for (const node of nodes) {
    if (node.type === "file" && node.content) {
      files[node.path] = node.content;
    }
    if (node.children) {
      Object.assign(files, collectGeneratedFiles(node.children));
    }
  }
  return files;
}

function updateFileContent(nodes: FileNode[], path: string, content: string): FileNode[] {
  return nodes.map(node => {
    if (node.path === path) {
      return { ...node, content };
    }
    if (node.children) {
      return { ...node, children: updateFileContent(node.children, path, content) };
    }
    return node;
  });
}
