import { useState, lazy, Suspense } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/theme-toggle";
import {
  Zap,
  FileText,
  Settings2,
  Bot,
  FolderOpen,
  Download,
  ArrowRight,
  ChevronRight,
  Layers,
  Shield,
  Cloud,
  Search,
  Cpu,
  Code2,
  Info,
  GitBranch,
} from "lucide-react";
import logoImg from "@assets/14657058_1771552453637.png";
import agentImg from "@assets/agent_1771552518611.png";
import zensarLogo from "@assets/zen_1771591674164.png";

const ArchitectureDiagram = lazy(() => import("@/components/architecture-diagram"));

const flowNodes = [
  {
    id: "input",
    icon: FileText,
    color: "border-blue-500/40",
    bg: "bg-blue-500/10",
    glow: "shadow-blue-500/20",
    title: "Requirements",
    subtitle: "Text or Markdown",
    isAgent: false,
  },
  {
    id: "config",
    icon: Settings2,
    color: "border-emerald-500/40",
    bg: "bg-emerald-500/10",
    glow: "shadow-emerald-500/20",
    title: "Tech Stack",
    subtitle: "TOGAF Wizard",
    isAgent: false,
  },
  {
    id: "planner",
    icon: Cpu,
    color: "border-purple-500/40",
    bg: "bg-purple-500/10",
    glow: "shadow-purple-500/20",
    title: "Agentic Planner",
    subtitle: "Architecture & Structure",
    isAgent: true,
  },
  {
    id: "coder",
    icon: Code2,
    color: "border-amber-500/40",
    bg: "bg-amber-500/10",
    glow: "shadow-amber-500/20",
    title: "Agentic Coder",
    subtitle: "Code Generation",
    isAgent: true,
  },
  {
    id: "reviewer",
    icon: Search,
    color: "border-cyan-500/40",
    bg: "bg-cyan-500/10",
    glow: "shadow-cyan-500/20",
    title: "Agentic Reviewer",
    subtitle: "Quality & Security",
    isAgent: true,
  },
  {
    id: "output",
    icon: Download,
    color: "border-green-500/40",
    bg: "bg-green-500/10",
    glow: "shadow-green-500/20",
    title: "Project Output",
    subtitle: "ZIP Download",
    isAgent: false,
  },
];

const agentSdlc = [
  {
    agent: "Agentic Planner",
    icon: Cpu,
    color: "text-purple-500",
    bg: "bg-purple-500/10",
    border: "border-purple-500/30",
    model: "GPT-4o",
    tech: ["LangGraph", "TOGAF ADM", "Sitecore Helix", "OpenAI Function Calling", "JSON Schema"],
    phases: [
      { name: "Requirements Analysis", desc: "NLP-driven extraction of functional & non-functional requirements via TOGAF-inspired wizard" },
      { name: "System Design", desc: "Generates Sitecore Helix-layered architecture (Foundation / Feature / Project) with full dependency graphs" },
      { name: "Planning", desc: "Produces structured JSON file trees, API contracts, and module boundaries using GPT-4o reasoning" },
    ],
  },
  {
    agent: "Agentic Coder",
    icon: Code2,
    color: "text-amber-500",
    bg: "bg-amber-500/10",
    border: "border-amber-500/30",
    model: "GPT-4o",
    tech: ["LangGraph", "LangChain", "React 18", "Next.js 14", "FastAPI", "Node.js 20", "TypeScript 5", "Docker"],
    phases: [
      { name: "Implementation", desc: "Generates production-grade code across React, Angular, Vue, Node.js, Django, Flask, FastAPI, and Spring Boot" },
      { name: "Configuration", desc: "Auto-generates package.json, tsconfig, Dockerfile, docker-compose, .env templates, and CI/CD configs" },
      { name: "Documentation", desc: "Creates comprehensive README with separate Windows & macOS/Linux install steps, API docs, and deployment guides" },
    ],
  },
  {
    agent: "Agentic Reviewer",
    icon: Search,
    color: "text-cyan-500",
    bg: "bg-cyan-500/10",
    border: "border-cyan-500/30",
    model: "GPT-4o-mini",
    tech: ["LangGraph", "npm Registry API", "SPDX License DB", "SemVer Validation", "OWASP Rules"],
    phases: [
      { name: "Code Review", desc: "AI-powered static analysis for code quality, design patterns, and best practices across all supported stacks" },
      { name: "Security Audit", desc: "OWASP-aligned scanning for XSS, injection, auth flaws, and encryption misconfigurations" },
      { name: "License & Version Validation", desc: "Live npm registry lookup — flags GPL/AGPL/SSPL copyleft licenses and verifies SemVer version availability" },
      { name: "Testing Guidance", desc: "Recommends unit/integration test strategies and identifies untested critical paths" },
    ],
  },
];

const features = [
  { icon: Layers, label: "Multi-Stack Generation", desc: "React 18, Next.js 14, Angular 17, Vue 3, Node.js 20, Django 5, FastAPI, Spring Boot" },
  { icon: Bot, label: "LangGraph Multi-Agent Pipeline", desc: "LangGraph StateGraph orchestrates three AI agents with state management, conditional routing, and streaming" },
  { icon: Shield, label: "Enterprise Security", desc: "OWASP-aligned audit, JWT/OAuth2, bcrypt encryption, CORS, CSRF protection" },
  { icon: Cloud, label: "Cloud-Native Deployment", desc: "Docker, docker-compose, Vercel, Railway, AWS ECS, Azure App Service" },
  { icon: FolderOpen, label: "In-Browser IDE", desc: "File explorer, syntax-highlighted editor, live iterative refinement via AI" },
  { icon: Zap, label: "Server-Sent Events Streaming", desc: "Real-time SSE pipeline — watch agents plan, code, and review live" },
];

export default function HomePage() {
  const [archDiagramOpen, setArchDiagramOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="flex items-center justify-between gap-4 px-6 py-3 border-b bg-card sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <img src={logoImg} alt="ZenForge Agent" className="w-8 h-8 rounded-md object-cover" />
          <div className="flex flex-col">
            <span className="text-sm font-semibold leading-tight">ZenForge Agent</span>
            <span className="text-[10px] text-muted-foreground leading-tight">Agentic Software Forge</span>
          </div>
        </div>
        <nav className="flex items-center gap-2">
          <Link href="/">
            <Button variant="ghost" size="sm" data-testid="link-home">Home</Button>
          </Link>
          <Link href="/forge">
            <Button variant="ghost" size="sm" data-testid="link-forge">Forge</Button>
          </Link>
          <Link href="/agentic">
            <Button variant="ghost" size="sm" data-testid="link-agentic">Agentic AI</Button>
          </Link>
          <Link href="/about">
            <Button variant="ghost" size="sm" data-testid="link-about">About</Button>
          </Link>
          <ThemeToggle />
        </nav>
      </header>

      <section className="relative py-24 px-6 text-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-primary/3 to-transparent" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent" />
        <div className="relative max-w-4xl mx-auto">
          <img src={logoImg} alt="ZenForge Agent" className="w-24 h-24 mx-auto mb-8 drop-shadow-xl animate-[bounce_3s_ease-in-out_infinite]" />
          <a href="https://www.zensar.com" target="_blank" rel="noopener noreferrer"><img src={zensarLogo} alt="Zensar" className="h-10 mx-auto mb-6 opacity-90 hover:opacity-100 transition-opacity" /></a>
          <Badge variant="secondary" className="mb-5 text-xs tracking-wide" data-testid="badge-tagline">Agentic AI Platform &mdash; Powered by Zensar AES</Badge>
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight mb-6 leading-[1.1]" data-testid="text-hero-title">
            <span className="bg-gradient-to-r from-foreground via-foreground to-foreground/70 bg-clip-text">ZenForge </span>
            <span className="text-primary"> Agent</span>
          </h1>
          <p className="text-lg sm:text-xl font-medium text-muted-foreground mb-1 tracking-wide">
            Agentic Software Forge
          </p>
          <p className="text-xl sm:text-2xl font-medium text-foreground/80 mb-3 tracking-wide">
            From Requirements to Production Code
          </p>
          <p className="text-sm sm:text-base text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
            Describe what you want to build. Our agentic AI pipeline plans, codes, and reviews your entire project &mdash; delivering production-ready software in minutes, not months.
          </p>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <Link href="/forge">
              <Button size="lg" className="text-base px-8" data-testid="button-start-forging">
                <Zap className="w-5 h-5 mr-2" />
                Start Forging
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Button variant="outline" size="lg" className="text-base px-8" data-testid="button-architecture" onClick={() => setArchDiagramOpen(true)}>
              <GitBranch className="w-5 h-5 mr-2" />
              Architecture Diagram
            </Button>
            <Link href="/about">
              <Button variant="outline" size="lg" className="text-base px-8" data-testid="button-learn-more">
                <Info className="w-5 h-5 mr-2" />
                Learn More
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="py-16 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold mb-3" data-testid="text-how-title">How It Works</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">
              Our agentic AI pipeline takes your ideas from concept to code in six steps.
            </p>
          </div>

          <div className="hidden lg:block relative" data-testid="flow-diagram-desktop">
            <div className="relative grid grid-cols-6 gap-3">
              {flowNodes.map((node, idx) => (
                <div key={node.id} className="flex flex-col items-center" data-testid={`flow-node-${node.id}`}>
                  <div className="flex items-center justify-center w-7 h-7 rounded-full bg-primary text-primary-foreground text-xs font-bold mb-2">
                    {idx + 1}
                  </div>
                  <div className="flex items-center w-full">
                    <Card className={`w-full p-4 flex flex-col items-center text-center border ${node.color} shadow-lg ${node.glow} hover-elevate transition-all`}>
                      {node.isAgent ? (
                        <img src={agentImg} alt={node.title} className="w-12 h-12 mb-2" />
                      ) : (
                        <div className={`flex items-center justify-center w-12 h-12 rounded-full ${node.bg} mb-2`}>
                          <node.icon className="w-6 h-6 text-foreground/70" />
                        </div>
                      )}
                      <h3 className="text-xs font-semibold mb-0.5 leading-tight">{node.title}</h3>
                      <p className="text-[10px] text-muted-foreground leading-tight">{node.subtitle}</p>
                      {node.isAgent && (
                        <Badge variant="outline" className="mt-2 text-[9px] px-1.5 py-0">Agentic AI</Badge>
                      )}
                    </Card>
                    {idx < flowNodes.length - 1 && (
                      <ArrowRight className="w-5 h-5 text-primary/50 shrink-0 -mr-4" style={{ marginLeft: "-2px" }} />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:hidden flex flex-col items-center gap-0" data-testid="flow-diagram-mobile">
            {flowNodes.map((node, idx) => (
              <div key={node.id} className="flex flex-col items-center w-full max-w-xs">
                {idx > 0 && (
                  <div className="flex flex-col items-center py-1">
                    <div className="w-px h-5 bg-primary/30" />
                    <ArrowRight className="w-4 h-4 text-primary/40 rotate-90" />
                  </div>
                )}
                <Card className={`w-full p-4 flex items-center gap-3 border ${node.color} shadow-md ${node.glow}`} data-testid={`flow-node-mobile-${node.id}`}>
                  <div className="flex items-center justify-center w-7 h-7 rounded-full bg-primary text-primary-foreground text-xs font-bold shrink-0">
                    {idx + 1}
                  </div>
                  {node.isAgent ? (
                    <img src={agentImg} alt={node.title} className="w-10 h-10 shrink-0" />
                  ) : (
                    <div className={`flex items-center justify-center w-10 h-10 rounded-full ${node.bg} shrink-0`}>
                      <node.icon className="w-5 h-5 text-foreground/70" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-semibold">{node.title}</h3>
                      {node.isAgent && <Badge variant="outline" className="text-[9px] px-1.5 py-0">AI</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground">{node.subtitle}</p>
                  </div>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-6 border-t" data-testid="section-sdlc">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold mb-3" data-testid="text-sdlc-title">SDLC Phases by Agent</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Each agent owns specific SDLC phases, working together to deliver production-ready software.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {agentSdlc.map((agent) => (
              <Card key={agent.agent} className={`p-5 border ${agent.border} hover-elevate transition-all relative overflow-hidden`} data-testid={`sdlc-agent-${agent.agent.replace(/\s/g, "-").toLowerCase()}`}>
                <div className="absolute top-3 right-3 opacity-[0.07]">
                  <img src={agentImg} alt="" className="w-24 h-24" />
                </div>
                <div className="relative">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="relative">
                      <img src={agentImg} alt={agent.agent} className="w-14 h-14 drop-shadow-md" />
                      <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full ${agent.bg} border-2 border-card flex items-center justify-center`}>
                        <agent.icon className={`w-3 h-3 ${agent.color}`} />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-base font-semibold">{agent.agent}</h3>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <Badge variant="outline" className={`text-[9px] px-1.5 py-0 ${agent.color} border-current/30`}>AI Agent</Badge>
                        <Badge variant="secondary" className="text-[9px] px-1.5 py-0">{agent.model}</Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1 mb-4">
                    {agent.tech.map((t) => (
                      <span key={t} className={`inline-block text-[9px] font-medium px-1.5 py-0.5 rounded ${agent.bg} ${agent.color}`}>{t}</span>
                    ))}
                  </div>
                  <div className="space-y-3">
                    {agent.phases.map((phase) => (
                      <div key={phase.name}>
                        <div className="flex items-center gap-1.5 mb-0.5">
                          <ChevronRight className={`w-3.5 h-3.5 ${agent.color} shrink-0`} />
                          <span className="text-sm font-medium">{phase.name}</span>
                        </div>
                        <p className="text-xs text-muted-foreground ml-5 leading-relaxed">{phase.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-6 border-t">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold mb-3">Key Features</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map((f) => (
              <Card key={f.label} className="p-4 flex items-start gap-3" data-testid={`card-feature-${f.label.replace(/\s/g, "-").toLowerCase()}`}>
                <f.icon className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium mb-0.5">{f.label}</h4>
                  <p className="text-xs text-muted-foreground">{f.desc}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 px-6 border-t">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-xl font-bold mb-3">Ready to Build?</h2>
          <p className="text-sm text-muted-foreground mb-6">
            Describe your project, pick your stack, and let ZenForge Agent do the heavy lifting.
          </p>
          <Link href="/forge">
            <Button size="lg" data-testid="button-cta-forge">
              <Zap className="w-4 h-4 mr-2" />
              Open the Forge
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </div>
      </section>

      <footer className="border-t py-6 px-6 text-center">
        <a href="https://www.zensar.com" target="_blank" rel="noopener noreferrer"><img src={zensarLogo} alt="Zensar" className="h-6 mx-auto mb-3 opacity-80 hover:opacity-100 transition-opacity" /></a>
        <p className="text-xs text-white dark:text-white">
          ZenForge Agent &mdash; Agentic AI Software Generation &mdash; Powered by Zensar AES
        </p>
        <p className="text-[10px] text-white/50 mt-1" data-testid="text-created-by-home">Created by AI Agent</p>
      </footer>

      {archDiagramOpen && (
        <Suspense fallback={null}>
          <ArchitectureDiagram open={archDiagramOpen} onOpenChange={setArchDiagramOpen} />
        </Suspense>
      )}
    </div>
  );
}
