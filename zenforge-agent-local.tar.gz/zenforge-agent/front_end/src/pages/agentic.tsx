import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/theme-toggle";
import { Separator } from "@/components/ui/separator";
import {
  Zap,
  ArrowLeft,
  ChevronRight,
  Bot,
  Cpu,
  Code2,
  Search,
  GitBranch,
  Layers,
  BrainCircuit,
  Workflow,
  RefreshCw,
  Target,
  MessageSquare,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";
import logoImg from "@assets/14657058_1771552453637.png";
import zensarLogo from "@assets/zen_1771591674164.png";

const agentStages = [
  {
    agent: "Agentic Planner",
    icon: Cpu,
    color: "text-purple-400",
    bg: "bg-purple-500/10",
    border: "border-purple-500/30",
    description: "Analyzes your requirements and autonomously designs the project architecture, file structure, and technology decisions.",
    capabilities: [
      "Decomposes complex requirements into actionable components",
      "Selects appropriate design patterns and architecture (e.g., Sitecore Helix layers)",
      "Generates a structured project plan with file-by-file specifications",
      "Makes autonomous decisions about module organization and dependencies",
    ],
  },
  {
    agent: "Agentic Coder",
    icon: Code2,
    color: "text-cyan-400",
    bg: "bg-cyan-500/10",
    border: "border-cyan-500/30",
    description: "Takes the plan and autonomously generates production-ready code for every file, making implementation decisions in real time.",
    capabilities: [
      "Generates complete, runnable code — not snippets or pseudocode",
      "Applies best practices for chosen frameworks and languages",
      "Handles cross-file dependencies and imports automatically",
      "Produces README, configuration, and deployment files",
    ],
  },
  {
    agent: "Agentic Reviewer",
    icon: Search,
    color: "text-amber-400",
    bg: "bg-amber-500/10",
    border: "border-amber-500/30",
    description: "Reviews all generated code for quality, security, and consistency — acting as an autonomous code reviewer before delivery.",
    capabilities: [
      "Validates code quality and adherence to best practices",
      "Checks for security vulnerabilities and anti-patterns",
      "Verifies consistency across the entire generated codebase",
      "Provides structured feedback and improvement suggestions",
    ],
  },
];

const agenticTraits = [
  {
    icon: BrainCircuit,
    title: "Autonomous Decision-Making",
    description: "Each agent independently makes technical decisions — from architecture choices to code patterns — without step-by-step human instruction.",
  },
  {
    icon: Workflow,
    title: "Multi-Agent Orchestration",
    description: "Three specialized agents work in a coordinated pipeline. Each agent's output feeds into the next, mimicking a real software development team.",
  },
  {
    icon: Target,
    title: "Goal-Oriented Execution",
    description: "You provide a high-level goal ('build a task manager'). The agents autonomously decompose it, plan the approach, generate code, and validate results.",
  },
  {
    icon: GitBranch,
    title: "LangGraph StateGraph Orchestration",
    description: "Agents are connected via LangGraph's StateGraph with typed state annotations, conditional edges, and streaming — replacing manual prompt chaining with a production-grade framework.",
  },
  {
    icon: RefreshCw,
    title: "Iterative Refinement",
    description: "After initial generation, you can send follow-up prompts. Agents re-evaluate and update specific files without restarting the entire pipeline.",
  },
  {
    icon: MessageSquare,
    title: "Structured Reasoning",
    description: "Each agent produces structured outputs — project plans, file trees, code reviews — not just raw text. This enables reliable, predictable automation.",
  },
];

const comparisons = [
  {
    label: "Simple AI Chatbot",
    traits: ["Single prompt, single response", "No planning or task decomposition", "No quality validation", "User must manually assemble output"],
    isAgentic: false,
  },
  {
    label: "ZenForge Agent",
    traits: ["Multi-agent pipeline with specialized roles", "Autonomous planning and architecture decisions", "Built-in code review and quality checks", "Complete, production-ready output"],
    isAgentic: true,
  },
];

export default function AgenticPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="flex items-center justify-between gap-4 px-6 py-3 border-b bg-card sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <img src={logoImg} alt="ZenForge Agent" className="w-8 h-8 rounded-md object-cover" />
          <div className="flex flex-col">
            <span className="text-sm font-semibold leading-tight">ZenForge Agent</span>
            <span className="text-[10px] text-muted-foreground leading-tight">Agentic Software Forge</span>
          </div>
        </div>
        <nav className="flex items-center gap-2">
          <Link href="/">
            <Button variant="ghost" size="sm" data-testid="link-home">Home</Button>
          </Link>
          <Link href="/forge">
            <Button variant="ghost" size="sm" data-testid="link-forge">Forge</Button>
          </Link>
          <Link href="/agentic">
            <Button variant="ghost" size="sm" data-testid="link-agentic" className="text-primary">Agentic AI</Button>
          </Link>
          <Link href="/about">
            <Button variant="ghost" size="sm" data-testid="link-about">About</Button>
          </Link>
          <ThemeToggle />
        </nav>
      </header>

      <section className="relative py-20 px-6 text-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/8 via-cyan-500/3 to-transparent" />
        <div className="relative max-w-3xl mx-auto">
          <Badge variant="secondary" className="mb-5 text-xs tracking-wide" data-testid="badge-agentic">
            <BrainCircuit className="w-3 h-3 mr-1" />
            Understanding Agentic AI
          </Badge>
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight mb-6" data-testid="text-agentic-title">
            What Makes This an{" "}
            <span className="text-primary">Agentic AI</span>{" "}
            Platform?
          </h1>
          <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Agentic AI goes beyond simple prompt-response. It uses multiple autonomous agents that <strong>plan, execute, and evaluate</strong> tasks in a coordinated pipeline — making decisions along the way, just like a real development team.
          </p>
        </div>
      </section>

      <section className="py-12 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold mb-2" data-testid="text-pipeline-title">The Multi-Agent Pipeline</h2>
            <p className="text-sm text-muted-foreground">Three specialized AI agents work autonomously in sequence</p>
          </div>

          <div className="space-y-6">
            {agentStages.map((stage, idx) => (
              <div key={stage.agent}>
                <Card className={`p-6 border ${stage.border}`} data-testid={`card-agent-${idx}`}>
                  <div className="flex items-start gap-4">
                    <div className={`w-14 h-14 rounded-xl ${stage.bg} flex items-center justify-center shrink-0`}>
                      <stage.icon className={`w-7 h-7 ${stage.color}`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Badge variant="outline" className="text-xs">{`Agent ${idx + 1}`}</Badge>
                        <h3 className="text-lg font-bold">{stage.agent}</h3>
                      </div>
                      <p className="text-sm text-muted-foreground mb-4">{stage.description}</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {stage.capabilities.map((cap) => (
                          <div key={cap} className="flex items-start gap-2">
                            <CheckCircle2 className={`w-4 h-4 ${stage.color} shrink-0 mt-0.5`} />
                            <span className="text-xs text-muted-foreground">{cap}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>
                {idx < agentStages.length - 1 && (
                  <div className="flex justify-center py-2">
                    <div className="flex flex-col items-center gap-1 text-muted-foreground">
                      <div className="w-px h-4 bg-border" />
                      <ArrowRight className="w-4 h-4 rotate-90" />
                      <span className="text-[10px]">output feeds next agent</span>
                      <div className="w-px h-4 bg-border" />
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <Separator className="max-w-4xl mx-auto" />

      <section className="py-12 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold mb-2" data-testid="text-traits-title">Core Agentic Traits</h2>
            <p className="text-sm text-muted-foreground">What separates agentic AI from a simple AI wrapper</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {agenticTraits.map((trait) => (
              <Card key={trait.title} className="p-5" data-testid={`card-trait-${trait.title.replace(/\s/g, "-").toLowerCase()}`}>
                <trait.icon className="w-8 h-8 text-primary mb-3" />
                <h3 className="text-sm font-bold mb-1.5">{trait.title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{trait.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Separator className="max-w-4xl mx-auto" />

      <section className="py-12 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold mb-2" data-testid="text-comparison-title">Simple AI vs. Agentic AI</h2>
            <p className="text-sm text-muted-foreground">The key difference is autonomy and orchestration</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {comparisons.map((comp) => (
              <Card key={comp.label} className={`p-6 ${comp.isAgentic ? "border-primary/40 bg-primary/5" : ""}`} data-testid={`card-comparison-${comp.isAgentic ? "agentic" : "simple"}`}>
                <div className="flex items-center gap-2 mb-4">
                  {comp.isAgentic ? (
                    <Sparkles className="w-5 h-5 text-primary" />
                  ) : (
                    <Bot className="w-5 h-5 text-muted-foreground" />
                  )}
                  <h3 className="text-base font-bold">{comp.label}</h3>
                  {comp.isAgentic && <Badge className="text-[10px]">Agentic</Badge>}
                </div>
                <div className="space-y-2.5">
                  {comp.traits.map((t) => (
                    <div key={t} className="flex items-start gap-2">
                      {comp.isAgentic ? (
                        <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                      ) : (
                        <div className="w-4 h-4 rounded-full border border-muted-foreground/30 shrink-0 mt-0.5" />
                      )}
                      <span className="text-sm text-muted-foreground">{t}</span>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Separator className="max-w-4xl mx-auto" />

      <section className="py-12 px-6">
        <div className="max-w-3xl mx-auto">
          <Card className="p-8 text-center border-primary/20 bg-primary/5" data-testid="card-summary">
            <Layers className="w-10 h-10 text-primary mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-3">The Bottom Line</h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-6 max-w-xl mx-auto">
              Built on <strong>LangGraph's StateGraph</strong> with OpenAI GPT-4o, the agentic behavior comes from the orchestration layer — multi-agent state management, conditional routing, typed annotations, and autonomous code generation. LangGraph enables real graph-based workflows with state persistence and streaming, making ZenForge Agent a true Agentic AI platform.
            </p>
            <Link href="/forge">
              <Button size="lg" data-testid="button-try-forge">
                <Zap className="w-4 h-4 mr-2" />
                Experience It — Open the Forge
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </Card>
        </div>
      </section>

      <footer className="border-t py-6 px-6 text-center mt-auto">
        <a href="https://www.zensar.com" target="_blank" rel="noopener noreferrer"><img src={zensarLogo} alt="Zensar" className="h-6 mx-auto mb-3 opacity-80 hover:opacity-100 transition-opacity" /></a>
        <p className="text-xs text-white dark:text-white">
          ZenForge Agent &mdash; Agentic AI Software Generation &mdash; Powered by Zensar AES
        </p>
      </footer>
    </div>
  );
}
