import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ThemeToggle } from "@/components/theme-toggle";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import {
  Zap,
  Lightbulb,
  Users,
  Target,
  Bot,
  Cpu,
  Search,
  Code2,
  ArrowLeft,
  Layers,
  FileText,
  ChevronDown,
  ChevronUp,
  Copy,
  Check,
  Clock,
  TrendingUp,
  ShieldCheck,
  Rocket,
} from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import logoImg from "@assets/14657058_1771552453637.png";
import agentImg from "@assets/agent_1771552651102.png";
import zensarLogo from "@assets/zen_1771591674164.png";
import teamImg from "@assets/image_1771590519956.png";
import rajeshImg from "@assets/image_1771590768677.png";
import kaushikImg from "@assets/image_1771590882609.png";
import sameerImg from "@assets/image_1771590899466.png";
import ullasImg from "@assets/image_1771590918550.png";
import hrishikeshImg from "@assets/image_1771590937365.png";

const teamMembers = [
  {
    name: "Rajesh Madhai",
    title: "Vice President - AES",
    role: "Creative Ideation",
    initials: "RM",
    image: rajeshImg,
    color: "bg-purple-500/20 text-purple-400",
    borderColor: "border-purple-400",
  },
  {
    name: "Kaushik Saha",
    title: "Distinguish Engineer - AES",
    role: "Diamond - Program Manager",
    initials: "KS",
    image: kaushikImg,
    color: "bg-amber-500/20 text-amber-400",
    borderColor: "border-amber-400",
  },
  {
    name: "Sameer Kumar Sharma",
    title: "Sr Engineering Manager, AES Delivery",
    role: "",
    initials: "SS",
    image: sameerImg,
    color: "bg-cyan-500/20 text-cyan-400",
    borderColor: "border-cyan-400",
  },
  {
    name: "Ullas Krishnan",
    title: "Sr Solution Architect, AES",
    role: "ZenForge - Solution Architect",
    initials: "UK",
    image: ullasImg,
    color: "bg-blue-500/20 text-blue-400",
    borderColor: "border-blue-400",
  },
  {
    name: "Hrishikesh Nalawade",
    title: "Sr Technical Specialist, AES",
    role: "ZenForge - Solution Architect",
    initials: "HN",
    image: hrishikeshImg,
    color: "bg-emerald-500/20 text-emerald-400",
    borderColor: "border-emerald-400",
  },
];

const sampleTemplates = [
  {
    id: "analytics-hub",
    title: "AnalyticsHub - C# Blazor Server Dashboard",
    tech: "C# .NET 8 / Blazor Server / SQL Server",
    color: "bg-purple-500/10 text-purple-400",
    content: `# AnalyticsHub - C# Blazor Server Dashboard

## Application Overview
Interactive business analytics dashboard with real-time data visualization.

## Core Features
- User authentication (Azure AD / Identity)
- KPI dashboards with charts
- Real-time data updates (SignalR)
- Data export (CSV/PDF)
- Role-based access control
- Responsive design

## Tech Stack
- **Language**: C# .NET 8
- **Frontend**: Blazor Server
- **Database**: SQL Server EF Core
- **Auth**: ASP.NET Identity
- **Charts**: Chart.js / MudBlazor
- **Real-time**: SignalR
- **API**: Minimal APIs

## Pages/Components
- Login/Register
- Dashboard (KPI cards, charts)
- Reports (filterable tables)
- Settings (user profile)
- Admin (user management)

## Data Models
\`\`\`csharp
public class Metric {
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Value { get; set; }
    public DateTime Timestamp { get; set; }
}
\`\`\`

## UI Requirements
- MudBlazor components
- Dark/Light theme toggle
- Responsive grid layout
- Loading spinners
- Toast notifications
- PWA support

## Security & Deployment
- HTTPS enforced
- CSRF protection
- SQL injection prevention
- Azure App Service ready
- Application Insights telemetry

## Deliverables
- Complete .NET 8 solution
- SQL scripts + EF migrations
- Docker container
- CI/CD pipeline (GitHub Actions)
- Unit/Integration tests (xUnit)
- Deployment manifests (ARM/Bicep)`,
  },
  {
    id: "shopfast-api",
    title: "ShopFast API - Java Spring Boot Microservice",
    tech: "Java 21 / Spring Boot 3.2+ / PostgreSQL",
    color: "bg-amber-500/10 text-amber-400",
    content: `# ShopFast API - Java Spring Boot Microservice

## Application Overview
Production-ready Spring Boot REST microservice for e-commerce product catalog.

## Core Features
- Product CRUD with categories
- Inventory management
- Search/filter (price, category, rating)
- Pagination & sorting
- File upload (product images)
- Email notifications

## Tech Stack
- **Language**: Java 21
- **Framework**: Spring Boot 3.2+
- **Database**: PostgreSQL (JPA/Hibernate)
- **Security**: Spring Security + JWT
- **Cache**: Redis
- **Validation**: Bean Validation 3.0
- **Testing**: JUnit 5, TestContainers

## Key Components
- @Controller @RestController endpoints
- @Service layer with business logic
- @Repository with JPA
- @Configuration for security/redis
- DTOs for request/response
- Exception handling (@ControllerAdvice)
- Swagger OpenAPI docs

## Database Schema
\`\`\`sql
products (id, name, price, stock, category_id, image_url)
categories (id, name, description)
\`\`\`

## Architecture Requirements
- Clean Architecture (3-layer)
- DTO pattern
- Global exception handler
- Swagger documentation
- Docker multi-stage build
- Health checks /actuator
- Logging (SLF4J)

## Integration Points
- Redis cache (30min TTL)
- PostgreSQL 15+
- MinIO S3-compatible storage
- Email service (Spring Mail)

## Deliverables
- Maven multi-module project
- Docker-compose (postgres/redis)
- Helm chart for K8s
- Integration tests
- Performance tests (JMeter)`,
  },
  {
    id: "todo-api",
    title: "Node.js Todo API - REST + MongoDB",
    tech: "Node.js / Express / MongoDB / REST API",
    color: "bg-green-500/10 text-green-400",
    content: `# Node.js Todo API - REST + MongoDB

## Application Overview
Production-ready RESTful API for task management with MongoDB persistence.

## Core Features
- Todo CRUD operations (Create, Read, Update, Delete)
- User authentication with JWT
- Task categories and labels
- Due date tracking and reminders
- Task priority levels
- Search and filter tasks
- Pagination support

## Tech Stack
- **Language**: Node.js 20+
- **Framework**: Express.js 4.x
- **Database**: MongoDB (Mongoose ODM)
- **Auth**: JWT + bcrypt
- **Validation**: Joi / express-validator
- **Testing**: Jest + Supertest
- **Docs**: Swagger / OpenAPI 3.0

## Key Components
- Routes (auth, todos, categories)
- Middleware (auth, error handler, rate limiter)
- Models (User, Todo, Category)
- Controllers (business logic)
- Services (email, notifications)
- Utils (helpers, validators)

## Database Schema
\`\`\`javascript
// Todo Model
{
  title: String,
  description: String,
  status: ['pending', 'in-progress', 'completed'],
  priority: ['low', 'medium', 'high'],
  dueDate: Date,
  category: ObjectId,
  user: ObjectId,
  labels: [String]
}

// User Model
{
  name: String,
  email: String,
  password: String (hashed),
  role: ['user', 'admin']
}
\`\`\`

## Architecture Requirements
- MVC pattern
- Environment-based configuration
- Centralized error handling
- Request validation middleware
- Rate limiting
- CORS configuration
- Logging (Winston)

## Integration Points
- MongoDB Atlas cloud database
- SendGrid for email notifications
- Redis for session caching
- AWS S3 for file attachments

## Deliverables
- Complete Express.js application
- Docker + docker-compose setup
- API documentation (Swagger)
- Unit and integration tests
- CI/CD pipeline (GitHub Actions)
- Postman collection`,
  },
];

const agentDetails = [
  {
    icon: Cpu,
    name: "Planner Agent",
    color: "text-blue-400",
    bg: "bg-blue-500/10",
    description: "Analyzes your requirements and designs a complete project structure. It determines the optimal file organization, dependencies, and architecture based on your chosen tech stack.",
  },
  {
    icon: Code2,
    name: "Coder Agent",
    color: "text-emerald-400",
    bg: "bg-emerald-500/10",
    description: "Generates production-ready code for each file in the project. Uses the latest language best practices, proper error handling, and follows your selected framework conventions.",
  },
  {
    icon: Search,
    name: "Reviewer Agent",
    color: "text-amber-400",
    bg: "bg-amber-500/10",
    description: "Reviews generated code for quality, security vulnerabilities, and adherence to best practices. Identifies potential issues and provides improvement suggestions.",
  },
];

function SampleTemplatesSection() {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (content: string, id: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="mb-12">
      <div className="flex items-center gap-2 mb-6">
        <FileText className="w-5 h-5 text-primary" />
        <h2 className="text-xl font-bold">Sample Requirement Templates</h2>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        Use these sample Markdown templates as a starting point. Upload them directly into ZenForge Agent or customize them for your project.
      </p>
      <div className="space-y-3">
        {sampleTemplates.map((tpl) => (
          <Card key={tpl.id} className="overflow-visible" data-testid={`card-template-${tpl.id}`}>
            <button
              className="w-full p-4 flex items-center justify-between gap-3 text-left"
              onClick={() => setExpandedId(expandedId === tpl.id ? null : tpl.id)}
              data-testid={`button-expand-${tpl.id}`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className={`flex items-center justify-center w-9 h-9 rounded-md ${tpl.color} shrink-0`}>
                  <FileText className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-semibold truncate">{tpl.title}</h3>
                  <p className="text-[10px] text-muted-foreground">{tpl.tech}</p>
                </div>
              </div>
              {expandedId === tpl.id ? (
                <ChevronUp className="w-4 h-4 text-muted-foreground shrink-0" />
              ) : (
                <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
              )}
            </button>
            {expandedId === tpl.id && (
              <div className="border-t px-4 pb-4">
                <div className="flex items-center justify-end gap-2 py-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleCopy(tpl.content, tpl.id)}
                    data-testid={`button-copy-${tpl.id}`}
                  >
                    {copiedId === tpl.id ? (
                      <><Check className="w-3.5 h-3.5 mr-1" /> Copied</>
                    ) : (
                      <><Copy className="w-3.5 h-3.5 mr-1" /> Copy Markdown</>
                    )}
                  </Button>
                </div>
                <ScrollArea className="h-[300px] rounded-md border bg-muted/30 p-3">
                  <pre className="text-xs font-mono whitespace-pre-wrap text-foreground/80">{tpl.content}</pre>
                </ScrollArea>
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="flex items-center justify-between gap-4 px-6 py-3 border-b bg-card sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <img src={logoImg} alt="ZenForge Agent" className="w-8 h-8 rounded-md object-cover" />
          <div className="flex flex-col">
            <span className="text-sm font-semibold leading-tight">ZenForge Agent</span>
            <span className="text-[10px] text-muted-foreground leading-tight">Agentic Software Forge</span>
          </div>
        </div>
        <nav className="flex items-center gap-2">
          <Link href="/">
            <Button variant="ghost" size="sm" data-testid="link-home">Home</Button>
          </Link>
          <Link href="/forge">
            <Button variant="ghost" size="sm" data-testid="link-forge">Forge</Button>
          </Link>
          <Link href="/agentic">
            <Button variant="ghost" size="sm" data-testid="link-agentic">Agentic AI</Button>
          </Link>
          <Link href="/about">
            <Button variant="ghost" size="sm" data-testid="link-about">About</Button>
          </Link>
          <ThemeToggle />
        </nav>
      </header>

      <section className="py-16 px-6">
        <div className="max-w-3xl mx-auto">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-6" data-testid="button-back-home">
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back to Home
            </Button>
          </Link>

          <div className="mb-12">
            <Badge variant="secondary" className="mb-3 text-xs">About ZenForge Agent</Badge>
            <h1 className="text-3xl sm:text-4xl font-bold mb-4" data-testid="text-about-title">
              Agentic AI Software Forge
            </h1>
            <p className="text-muted-foreground leading-relaxed mb-4">
              ZenForge Agent is an agentic software generation platform that transforms natural language project requirements into complete, production-ready codebases. By leveraging an agentic AI pipeline, ZenForge Agent handles the entire journey from requirements analysis to code generation and quality review.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Supporting multiple programming languages (Python, C#, Java, JavaScript, TypeScript), frameworks (React, Vue, Angular, Node.js, Django, Flask), and deployment targets (Docker, Vercel, Railway, AWS, Azure), ZenForge Agent adapts to your tech stack and generates code that follows industry best practices.
            </p>
          </div>

          <Separator className="my-10" />

          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">Efficiency &amp; Impact</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <Card className="p-5 text-center" data-testid="card-metric-time">
                <Clock className="w-8 h-8 text-primary mx-auto mb-2" />
                <p className="text-3xl font-extrabold text-primary mb-1">5&ndash;10 Days</p>
                <p className="text-xs text-muted-foreground">Saved per project vs. manual setup</p>
              </Card>
              <Card className="p-5 text-center" data-testid="card-metric-speed">
                <Rocket className="w-8 h-8 text-primary mx-auto mb-2" />
                <p className="text-3xl font-extrabold text-primary mb-1">85%</p>
                <p className="text-xs text-muted-foreground">Faster project scaffolding</p>
              </Card>
              <Card className="p-5 text-center" data-testid="card-metric-quality">
                <ShieldCheck className="w-8 h-8 text-primary mx-auto mb-2" />
                <p className="text-3xl font-extrabold text-primary mb-1">60%</p>
                <p className="text-xs text-muted-foreground">Fewer code review issues</p>
              </Card>
              <Card className="p-5 text-center" data-testid="card-metric-cost">
                <TrendingUp className="w-8 h-8 text-primary mx-auto mb-2" />
                <p className="text-3xl font-extrabold text-primary mb-1">70%</p>
                <p className="text-xs text-muted-foreground">Reduction in boilerplate effort</p>
              </Card>
            </div>

            <div className="space-y-3">
              <Card className="p-4" data-testid="card-efficiency-detail-1">
                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center w-9 h-9 rounded-full bg-blue-500/10 shrink-0 mt-0.5">
                    <Clock className="w-4 h-4 text-blue-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold mb-0.5">Project Setup: 5&ndash;10 Days to Minutes</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Traditional project scaffolding &mdash; configuring build tools, folder structure, boilerplate code, CI/CD, Docker, and README documentation &mdash; typically takes 5 to 10 developer days. ZenForge Agent completes this in under 5 minutes, saving teams an average of 7 working days per project.
                    </p>
                  </div>
                </div>
              </Card>
              <Card className="p-4" data-testid="card-efficiency-detail-2">
                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center w-9 h-9 rounded-full bg-emerald-500/10 shrink-0 mt-0.5">
                    <Rocket className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold mb-0.5">85% Faster Scaffolding &amp; Prototyping</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      By automating architecture design, file generation, and dependency setup, ZenForge Agent accelerates the scaffolding phase by 85%. Teams can jump straight into business logic instead of spending days on repetitive setup.
                    </p>
                  </div>
                </div>
              </Card>
              <Card className="p-4" data-testid="card-efficiency-detail-3">
                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center w-9 h-9 rounded-full bg-amber-500/10 shrink-0 mt-0.5">
                    <ShieldCheck className="w-4 h-4 text-amber-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold mb-0.5">60% Fewer Code Review Issues</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      The Agentic Reviewer catches security vulnerabilities, missing error handling, and best-practice violations before code reaches human reviewers &mdash; reducing review cycles by 60% and improving first-pass quality.
                    </p>
                  </div>
                </div>
              </Card>
              <Card className="p-4" data-testid="card-efficiency-detail-4">
                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center w-9 h-9 rounded-full bg-purple-500/10 shrink-0 mt-0.5">
                    <TrendingUp className="w-4 h-4 text-purple-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold mb-0.5">70% Reduction in Boilerplate Effort</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Config files, test stubs, Docker setup, authentication boilerplate, and database models &mdash; ZenForge Agent auto-generates all of it, eliminating 70% of repetitive coding work that adds no unique business value.
                    </p>
                  </div>
                </div>
              </Card>
            </div>
          </div>

          <Separator className="my-10" />

          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Target className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">AES &mdash; Advanced Engineering Services</h2>
            </div>
            <p className="text-muted-foreground leading-relaxed mb-4">
              ZenForge Agent is built by the Advanced Engineering Services (AES) team at Zensar Technologies. AES is dedicated to pushing the boundaries of software engineering through cutting-edge agentic AI, automation, and innovative tooling.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              The AES team focuses on developing next-generation engineering solutions that accelerate software development, improve code quality, and empower teams to deliver faster. ZenForge Agent represents our vision of agentic AI-augmented software creation.
            </p>
          </div>

          <Separator className="my-10" />

          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Bot className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">Multi-Agent AI Architecture</h2>
            </div>
            <div className="space-y-4">
              {agentDetails.map((agent) => (
                <Card key={agent.name} className="p-4" data-testid={`card-agent-${agent.name.replace(/\s/g, "-").toLowerCase()}`}>
                  <div className="flex items-start gap-3">
                    <img src={agentImg} alt={agent.name} className="w-12 h-12 shrink-0" />
                    <div>
                      <h3 className="text-sm font-semibold mb-1">{agent.name}</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">{agent.description}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <Separator className="my-10" />

          <div className="mb-12">
            <div className="flex items-center justify-center gap-2 mb-6">
              <Users className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">Zensar AES Team</h2>
            </div>

            <div className="flex justify-center">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {teamMembers.map((member) => (
                <Card key={member.name} className="p-5 text-center" data-testid={`card-member-${member.initials.toLowerCase()}`}>
                  <Avatar className="w-32 h-32 mx-auto mb-3">
                    {member.image && <AvatarImage src={member.image} alt={member.name} />}
                    <AvatarFallback className={member.color}>{member.initials}</AvatarFallback>
                  </Avatar>
                  <h3 className="text-sm font-bold mb-0.5">{member.name}</h3>
                  <p className="text-xs text-muted-foreground italic mb-1">{member.title}</p>
                  {member.role && <Badge variant="outline" className="text-[10px]">{member.role}</Badge>}
                </Card>
              ))}
            </div>
            </div>
          </div>

          <Separator className="my-10" />

          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Lightbulb className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">Key Capabilities</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Card className="p-4">
                <h4 className="text-sm font-medium mb-1">Multi-Language</h4>
                <p className="text-xs text-muted-foreground">Python, JavaScript, TypeScript, C#, Java</p>
              </Card>
              <Card className="p-4">
                <h4 className="text-sm font-medium mb-1">Framework Support</h4>
                <p className="text-xs text-muted-foreground">React, Vue, Angular, Node.js, Django, Flask</p>
              </Card>
              <Card className="p-4">
                <h4 className="text-sm font-medium mb-1">Security Options</h4>
                <p className="text-xs text-muted-foreground">Authentication, JWT tokens, Encryption</p>
              </Card>
              <Card className="p-4">
                <h4 className="text-sm font-medium mb-1">Cloud Deployment</h4>
                <p className="text-xs text-muted-foreground">Docker, Vercel, Railway, AWS, Azure</p>
              </Card>
              <Card className="p-4">
                <h4 className="text-sm font-medium mb-1">Code Quality</h4>
                <p className="text-xs text-muted-foreground">AI-powered review with security scanning</p>
              </Card>
              <Card className="p-4">
                <h4 className="text-sm font-medium mb-1">Governance</h4>
                <p className="text-xs text-muted-foreground">Compliance, logging, and audit trail support</p>
              </Card>
            </div>
          </div>

          <Separator className="my-10" />

          <SampleTemplatesSection />

          <div className="text-center pt-4">
            <Link href="/forge">
              <Button size="lg" data-testid="button-about-cta">
                <Zap className="w-4 h-4 mr-2" />
                Start Building with ZenForge Agent
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t py-6 px-6 text-center mt-auto">
        <a href="https://www.zensar.com" target="_blank" rel="noopener noreferrer"><img src={zensarLogo} alt="Zensar" className="h-6 mx-auto mb-3 opacity-80 hover:opacity-100 transition-opacity" /></a>
        <p className="text-xs text-white dark:text-white">
          ZenForge Agent &mdash; Agentic AI Software Generation &mdash; Powered by Zensar AES
        </p>
      </footer>
    </div>
  );
}
