export interface ProjectSpec {
  requirements: string;
  features: string;
  frontend: string;
  backend: string;
  language: string;
  database: string;
  authEnabled: boolean;
  jwtEnabled: boolean;
  encryptionEnabled: boolean;
  deployment: string;
  cloud: string;
  compliance: string;
  logging: string;
  auditing: string;
}

export interface FileNode {
  name: string;
  type: "file" | "folder";
  path: string;
  content?: string;
  children?: FileNode[];
  language?: string;
}

export interface LogEntry {
  id: number;
  agent: string;
  message: string;
  level: string;
  createdAt: string;
}

export interface Project {
  id: number;
  name: string;
  description: string | null;
  status: string;
  spec: ProjectSpec | null;
  fileTree: FileNode[] | null;
  generatedFiles: Record<string, string> | null;
  createdAt: string;
  updatedAt: string;
}

export const DEFAULT_SPEC: ProjectSpec = {
  requirements: "",
  features: "",
  frontend: "React",
  backend: "Node.js",
  language: "Python",
  database: "SQLite",
  authEnabled: false,
  jwtEnabled: false,
  encryptionEnabled: false,
  deployment: "Docker",
  cloud: "None",
  compliance: "",
  logging: "",
  auditing: "",
};
