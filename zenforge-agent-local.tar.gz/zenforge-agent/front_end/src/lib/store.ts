import { useState, useCallback } from "react";
import type { ProjectSpec, FileNode, LogEntry, Project } from "./types";
import { DEFAULT_SPEC } from "./types";

let globalSpec = { ...DEFAULT_SPEC };
let globalListeners: (() => void)[] = [];

export function useProjectStore() {
  const [spec, setSpecState] = useState<ProjectSpec>({ ...globalSpec });
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [fileTree, setFileTree] = useState<FileNode[]>([]);
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [activeAgent, setActiveAgent] = useState<string>("");

  const updateSpec = useCallback((partial: Partial<ProjectSpec>) => {
    setSpecState(prev => {
      const next = { ...prev, ...partial };
      globalSpec = next;
      return next;
    });
  }, []);

  const addLog = useCallback((log: Omit<LogEntry, "id" | "createdAt">) => {
    setLogs(prev => [...prev, {
      ...log,
      id: Date.now(),
      createdAt: new Date().toISOString(),
    }]);
  }, []);

  const clearLogs = useCallback(() => setLogs([]), []);

  return {
    spec,
    updateSpec,
    currentProject,
    setCurrentProject,
    fileTree,
    setFileTree,
    selectedFile,
    setSelectedFile,
    logs,
    addLog,
    clearLogs,
    isGenerating,
    setIsGenerating,
    progress,
    setProgress,
    activeAgent,
    setActiveAgent,
  };
}
