import { useEffect, useRef } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Bot, Cpu, Search, CheckCircle2, AlertCircle, Info, Loader2, Terminal } from "lucide-react";
import { cn } from "@/lib/utils";
import type { LogEntry } from "@/lib/types";

interface ProgressPanelProps {
  logs: LogEntry[];
  isGenerating: boolean;
  progress: number;
  activeAgent: string;
}

function getAgentIcon(agent: string) {
  switch (agent.toLowerCase()) {
    case "planner":
      return <Cpu className="w-3.5 h-3.5 text-blue-400" />;
    case "coder":
      return <Bot className="w-3.5 h-3.5 text-emerald-400" />;
    case "reviewer":
      return <Search className="w-3.5 h-3.5 text-amber-400" />;
    case "system":
      return <Terminal className="w-3.5 h-3.5 text-purple-400" />;
    default:
      return <Info className="w-3.5 h-3.5 text-muted-foreground" />;
  }
}

function getAgentColor(agent: string) {
  switch (agent.toLowerCase()) {
    case "planner": return "text-blue-400";
    case "coder": return "text-emerald-400";
    case "reviewer": return "text-amber-400";
    case "system": return "text-purple-400";
    default: return "text-muted-foreground";
  }
}

function getLevelIcon(level: string) {
  switch (level) {
    case "success":
      return <CheckCircle2 className="w-3 h-3 text-green-400 shrink-0" />;
    case "error":
      return <AlertCircle className="w-3 h-3 text-red-400 shrink-0" />;
    case "warning":
      return <AlertCircle className="w-3 h-3 text-amber-400 shrink-0" />;
    default:
      return null;
  }
}

export function ProgressPanel({ logs, isGenerating, progress, activeAgent }: ProgressPanelProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs.length]);

  return (
    <div className="flex flex-col h-full">
      <div className="px-3 py-2 border-b flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Build Log</span>
        </div>
        {isGenerating && activeAgent && (
          <Badge variant="outline" className="text-[10px] gap-1">
            <Loader2 className="w-3 h-3 animate-spin" />
            {activeAgent}
          </Badge>
        )}
      </div>

      {isGenerating && (
        <div className="px-3 py-2 border-b">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] text-muted-foreground">Generation Progress</span>
            <span className="text-[10px] font-mono text-muted-foreground">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-1.5" />
        </div>
      )}

      <ScrollArea className="flex-1">
        <div className="p-2 space-y-0.5">
          {logs.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Terminal className="w-10 h-10 text-muted-foreground/20 mb-3" />
              <p className="text-xs text-muted-foreground mb-1">Build log is empty</p>
              <p className="text-[10px] text-muted-foreground/60">
                Start a generation to see agent activity here
              </p>
            </div>
          ) : (
            logs.map((log) => (
              <div
                key={log.id}
                className={cn(
                  "flex items-start gap-2 py-1 px-2 rounded-sm text-xs",
                  log.level === "error" && "bg-red-500/5",
                  log.level === "success" && "bg-green-500/5",
                )}
              >
                {getAgentIcon(log.agent)}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className={cn("font-semibold text-[11px]", getAgentColor(log.agent))}>
                      {log.agent}
                    </span>
                    {getLevelIcon(log.level)}
                    <span className="text-[10px] text-muted-foreground/50 ml-auto font-mono">
                      {new Date(log.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                    </span>
                  </div>
                  <p className="text-foreground/70 text-[11px] leading-relaxed whitespace-pre-wrap break-words">
                    {log.message}
                  </p>
                </div>
              </div>
            ))
          )}
          <div ref={bottomRef} />
        </div>
      </ScrollArea>
    </div>
  );
}
