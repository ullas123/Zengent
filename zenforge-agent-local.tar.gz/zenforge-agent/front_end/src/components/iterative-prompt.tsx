import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageSquarePlus, Send, Loader2, History } from "lucide-react";
import { cn } from "@/lib/utils";

interface IterativePromptProps {
  onSubmit: (prompt: string) => void;
  isUpdating: boolean;
  hasProject: boolean;
  promptHistory: string[];
}

export function IterativePrompt({ onSubmit, isUpdating, hasProject, promptHistory }: IterativePromptProps) {
  const [prompt, setPrompt] = useState("");

  const handleSubmit = () => {
    if (!prompt.trim() || isUpdating || !hasProject) return;
    onSubmit(prompt.trim());
    setPrompt("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="px-3 py-2 border-b flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <MessageSquarePlus className="w-4 h-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Iterate</span>
        </div>
        <Badge variant="outline" className="text-[10px]">Refine</Badge>
      </div>

      {!hasProject ? (
        <div className="flex flex-col items-center justify-center flex-1 px-4 py-8 text-center">
          <MessageSquarePlus className="w-8 h-8 text-muted-foreground/30 mb-2" />
          <p className="text-xs text-muted-foreground mb-1">No project yet</p>
          <p className="text-[10px] text-muted-foreground/60">
            Generate a project first, then use this panel to refine files with follow-up prompts
          </p>
        </div>
      ) : (
        <>
          <ScrollArea className="flex-1">
            <div className="p-2 space-y-2">
              {promptHistory.length > 0 && (
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5 px-1">
                    <History className="w-3 h-3 text-muted-foreground" />
                    <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">History</span>
                  </div>
                  {promptHistory.map((h, i) => (
                    <div
                      key={i}
                      className="px-2 py-1.5 rounded-md bg-muted/50 text-[11px] text-foreground/70 leading-relaxed"
                      data-testid={`text-prompt-history-${i}`}
                    >
                      {h}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="p-2 border-t space-y-2">
            <Textarea
              placeholder="Describe changes to make... (Ctrl+Enter to send)"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isUpdating}
              className={cn(
                "text-xs min-h-[60px] resize-none font-mono",
                isUpdating && "opacity-50"
              )}
              data-testid="input-iterative-prompt"
            />
            <Button
              onClick={handleSubmit}
              disabled={!prompt.trim() || isUpdating}
              className="w-full"
              size="sm"
              data-testid="button-iterate"
            >
              {isUpdating ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                  Updating...
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5 mr-1.5" />
                  Update Project
                </>
              )}
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
