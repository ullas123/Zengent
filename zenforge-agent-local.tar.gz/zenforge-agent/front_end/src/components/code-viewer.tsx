import { useState, useCallback } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Copy, Check, Pencil, Save, X, FileCode } from "lucide-react";
import type { FileNode } from "@/lib/types";

interface CodeViewerProps {
  file: FileNode | null;
  onUpdateContent: (path: string, content: string) => void;
}

function getLanguageFromPath(path: string): string {
  const ext = path.split(".").pop()?.toLowerCase() || "";
  const map: Record<string, string> = {
    py: "Python",
    js: "JavaScript",
    jsx: "JavaScript",
    ts: "TypeScript",
    tsx: "TypeScript",
    json: "JSON",
    md: "Markdown",
    html: "HTML",
    css: "CSS",
    scss: "SCSS",
    java: "Java",
    cs: "C#",
    yml: "YAML",
    yaml: "YAML",
    sql: "SQL",
    sh: "Shell",
    bash: "Shell",
    toml: "TOML",
    xml: "XML",
    txt: "Text",
    cfg: "Config",
    ini: "Config",
    env: "Env",
    dockerfile: "Docker",
    gitignore: "Git",
  };
  return map[ext] || ext.toUpperCase();
}

export function CodeViewer({ file, onUpdateContent }: CodeViewerProps) {
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState("");

  const handleCopy = useCallback(() => {
    if (!file?.content) return;
    navigator.clipboard.writeText(file.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [file?.content]);

  const handleEdit = () => {
    if (!file) return;
    setEditContent(file.content || "");
    setIsEditing(true);
  };

  const handleSave = () => {
    if (!file) return;
    onUpdateContent(file.path, editContent);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setIsEditing(false);
  };

  if (!file) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center px-6">
        <FileCode className="w-12 h-12 text-muted-foreground/20 mb-4" />
        <p className="text-sm text-muted-foreground mb-1">No file selected</p>
        <p className="text-xs text-muted-foreground/60">
          Select a file from the explorer to view its contents
        </p>
      </div>
    );
  }

  const language = getLanguageFromPath(file.path);
  const lines = (file.content || "").split("\n");

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between gap-2 px-3 py-1.5 border-b bg-card">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-xs font-medium truncate" data-testid="text-filename">{file.name}</span>
          <Badge variant="secondary" className="text-[10px] shrink-0">{language}</Badge>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {isEditing ? (
            <>
              <Button variant="ghost" size="icon" onClick={handleSave} data-testid="button-save-file">
                <Save className="w-3.5 h-3.5" />
              </Button>
              <Button variant="ghost" size="icon" onClick={handleCancel} data-testid="button-cancel-edit">
                <X className="w-3.5 h-3.5" />
              </Button>
            </>
          ) : (
            <>
              <Button variant="ghost" size="icon" onClick={handleEdit} data-testid="button-edit-file">
                <Pencil className="w-3.5 h-3.5" />
              </Button>
              <Button variant="ghost" size="icon" onClick={handleCopy} data-testid="button-copy-code">
                {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
              </Button>
            </>
          )}
        </div>
      </div>

      {isEditing ? (
        <Textarea
          value={editContent}
          onChange={(e) => setEditContent(e.target.value)}
          className="flex-1 font-mono text-xs rounded-none border-0 resize-none focus-visible:ring-0"
          data-testid="textarea-edit-code"
        />
      ) : (
        <ScrollArea className="flex-1">
          <div className="p-0">
            <table className="w-full border-collapse">
              <tbody>
                {lines.map((line, i) => (
                  <tr key={i} className="hover:bg-muted/30">
                    <td className="text-right pr-3 pl-3 py-0 text-[11px] text-muted-foreground/40 select-none font-mono w-10 align-top whitespace-nowrap border-r border-border/30">
                      {i + 1}
                    </td>
                    <td className="pl-3 pr-4 py-0 font-mono text-[12px] leading-[1.6] whitespace-pre text-foreground/90">
                      {line || " "}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </ScrollArea>
      )}
    </div>
  );
}
