import { useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  FolderOpen,
  Folder,
  FileCode,
  FileText,
  FileJson,
  File,
  ChevronRight,
  ChevronDown,
  FileCog,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { FileNode } from "@/lib/types";

interface FileExplorerProps {
  files: FileNode[];
  selectedFile: FileNode | null;
  onSelectFile: (file: FileNode) => void;
}

function getFileIcon(name: string, type: "file" | "folder", isOpen?: boolean) {
  if (type === "folder") {
    return isOpen ? (
      <FolderOpen className="w-3.5 h-3.5 text-amber-400 shrink-0" />
    ) : (
      <Folder className="w-3.5 h-3.5 text-amber-400 shrink-0" />
    );
  }
  const ext = name.split(".").pop()?.toLowerCase() || "";
  switch (ext) {
    case "py":
      return <FileCode className="w-3.5 h-3.5 text-blue-400 shrink-0" />;
    case "js":
    case "jsx":
      return <FileCode className="w-3.5 h-3.5 text-yellow-400 shrink-0" />;
    case "ts":
    case "tsx":
      return <FileCode className="w-3.5 h-3.5 text-blue-300 shrink-0" />;
    case "json":
      return <FileJson className="w-3.5 h-3.5 text-green-400 shrink-0" />;
    case "md":
    case "txt":
      return <FileText className="w-3.5 h-3.5 text-gray-400 shrink-0" />;
    case "css":
    case "scss":
      return <FileCode className="w-3.5 h-3.5 text-pink-400 shrink-0" />;
    case "html":
      return <FileCode className="w-3.5 h-3.5 text-orange-400 shrink-0" />;
    case "yml":
    case "yaml":
    case "toml":
    case "cfg":
    case "ini":
      return <FileCog className="w-3.5 h-3.5 text-gray-400 shrink-0" />;
    case "java":
    case "cs":
      return <FileCode className="w-3.5 h-3.5 text-red-400 shrink-0" />;
    default:
      return <File className="w-3.5 h-3.5 text-muted-foreground shrink-0" />;
  }
}

function FileTreeItem({
  node,
  depth,
  selectedFile,
  onSelectFile,
}: {
  node: FileNode;
  depth: number;
  selectedFile: FileNode | null;
  onSelectFile: (file: FileNode) => void;
}) {
  const [isOpen, setIsOpen] = useState(depth < 2);
  const isFolder = node.type === "folder";
  const isSelected = selectedFile?.path === node.path;

  const handleClick = () => {
    if (isFolder) {
      setIsOpen(!isOpen);
    } else {
      onSelectFile(node);
    }
  };

  return (
    <div>
      <button
        onClick={handleClick}
        className={cn(
          "flex items-center gap-1 w-full text-left py-0.5 px-1 rounded-sm text-xs transition-colors",
          isSelected
            ? "bg-primary/15 text-primary"
            : "text-foreground/80 hover:bg-muted"
        )}
        style={{ paddingLeft: `${depth * 12 + 4}px` }}
        data-testid={`file-${node.path.replace(/[/.]/g, "-")}`}
      >
        {isFolder && (
          isOpen ? (
            <ChevronDown className="w-3 h-3 text-muted-foreground shrink-0" />
          ) : (
            <ChevronRight className="w-3 h-3 text-muted-foreground shrink-0" />
          )
        )}
        {!isFolder && <span className="w-3 shrink-0" />}
        {getFileIcon(node.name, node.type, isOpen)}
        <span className="truncate">{node.name}</span>
      </button>
      {isFolder && isOpen && node.children && (
        <div>
          {node.children.map((child) => (
            <FileTreeItem
              key={child.path}
              node={child}
              depth={depth + 1}
              selectedFile={selectedFile}
              onSelectFile={onSelectFile}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function FileExplorer({ files, selectedFile, onSelectFile }: FileExplorerProps) {
  const fileCount = countFiles(files);

  return (
    <div className="flex flex-col h-full">
      <div className="px-3 py-2 border-b flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <FolderOpen className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Explorer</span>
        </div>
        {fileCount > 0 && (
          <Badge variant="secondary" className="text-[10px]">{fileCount} files</Badge>
        )}
      </div>
      <ScrollArea className="flex-1">
        <div className="p-1">
          {files.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
              <Folder className="w-10 h-10 text-muted-foreground/30 mb-3" />
              <p className="text-xs text-muted-foreground mb-1">No files yet</p>
              <p className="text-[10px] text-muted-foreground/60">Configure your project and hit "Forge Software" to generate code</p>
            </div>
          ) : (
            files.map((node) => (
              <FileTreeItem
                key={node.path}
                node={node}
                depth={0}
                selectedFile={selectedFile}
                onSelectFile={onSelectFile}
              />
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

function countFiles(nodes: FileNode[]): number {
  let count = 0;
  for (const node of nodes) {
    if (node.type === "file") count++;
    if (node.children) count += countFiles(node.children);
  }
  return count;
}
