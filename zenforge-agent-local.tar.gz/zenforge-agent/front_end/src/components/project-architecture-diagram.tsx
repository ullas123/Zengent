import { useMemo } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  type Node,
  type Edge,
  Position,
  MarkerType,
  Handle,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  User,
  Bot,
  FolderOpen,
  Package,
  Puzzle,
  Zap,
  Database,
  FlaskConical,
  Settings,
  Palette,
  Wrench,
  Link2,
  Container,
  Folder,
} from "lucide-react";
import type { FileNode, ProjectSpec } from "@/lib/types";

function LayerNode({ data }: { data: any }) {
  const IconComp = data.icon || FolderOpen;
  return (
    <div className={`px-4 py-3 rounded-xl border-2 ${data.borderColor} ${data.bgColor} shadow-lg ${data.glowColor} min-w-[180px] max-w-[220px]`}>
      <Handle type="target" position={Position.Left} className={`!w-2.5 !h-2.5 ${data.handleColor}`} />
      <Handle type="source" position={Position.Right} className={`!w-2.5 !h-2.5 ${data.handleColor}`} />
      <Handle type="source" position={Position.Bottom} id="bottom" className={`!w-2.5 !h-2.5 ${data.handleColor}`} />
      <div className="text-center">
        <div className="flex justify-center mb-1">
          <IconComp className="w-4 h-4 text-white/80" />
        </div>
        <div className="text-[10px] font-bold text-white">{data.label}</div>
        {data.sub && <div className="text-[8px] text-white/50 mt-0.5">{data.sub}</div>}
      </div>
    </div>
  );
}

function FileGroupNode({ data }: { data: any }) {
  return (
    <div className={`px-3 py-2.5 rounded-lg border ${data.borderColor} ${data.bgColor} min-w-[160px] max-w-[200px]`}>
      <Handle type="target" position={Position.Top} className="!bg-gray-400 !w-2 !h-2" />
      <Handle type="source" position={Position.Bottom} className="!bg-gray-400 !w-2 !h-2" />
      <div className="text-center">
        <div className="text-[9px] font-semibold text-white/80 mb-1">{data.label}</div>
        <div className="flex flex-wrap justify-center gap-0.5">
          {data.files?.map((f: string) => (
            <span key={f} className="text-[7px] px-1 py-0.5 rounded bg-white/10 text-white/60 leading-tight">{f}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

function TechNode({ data }: { data: any }) {
  return (
    <div className={`px-4 py-3 rounded-xl border-2 border-dashed ${data.borderColor} ${data.bgColor} min-w-[200px]`}>
      <div className="text-center">
        <div className="text-[9px] font-bold text-white/70 mb-1.5">{data.label}</div>
        <div className="flex flex-wrap justify-center gap-1">
          {data.techs?.map((t: string) => (
            <span key={t} className="text-[8px] px-1.5 py-0.5 rounded bg-white/15 text-white/70 font-medium">{t}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

function EntryNode({ data }: { data: any }) {
  const IconComp = data.icon || User;
  return (
    <div className={`px-4 py-3 rounded-xl border-2 ${data.borderColor} ${data.bgColor} shadow-lg ${data.glowColor} min-w-[160px]`}>
      <Handle type="source" position={Position.Right} className={`!w-2.5 !h-2.5 ${data.handleColor}`} />
      <div className="text-center">
        <div className="flex justify-center mb-1">
          <IconComp className="w-4 h-4" style={{ color: data.textColor }} />
        </div>
        <div className="text-[10px] font-bold" style={{ color: data.textColor }}>{data.label}</div>
        {data.sub && <div className="text-[8px] text-white/50 mt-0.5">{data.sub}</div>}
      </div>
    </div>
  );
}

function OutputNodeComp({ data }: { data: any }) {
  const IconComp = data.icon || Package;
  return (
    <div className={`px-4 py-3 rounded-xl border-2 ${data.borderColor} ${data.bgColor} shadow-lg ${data.glowColor} min-w-[160px]`}>
      <Handle type="target" position={Position.Left} className={`!w-2.5 !h-2.5 ${data.handleColor}`} />
      <div className="text-center">
        <div className="flex justify-center mb-1">
          <IconComp className="w-4 h-4" style={{ color: data.textColor }} />
        </div>
        <div className="text-[10px] font-bold" style={{ color: data.textColor }}>{data.label}</div>
        {data.sub && <div className="text-[8px] text-white/50 mt-0.5">{data.sub}</div>}
      </div>
    </div>
  );
}

const nodeTypes = {
  layer: LayerNode,
  fileGroup: FileGroupNode,
  tech: TechNode,
  entry: EntryNode,
  outputNode: OutputNodeComp,
};

function categorizeFiles(fileTree: FileNode[]): {
  folders: Map<string, { displayName: string; files: string[] }>;
  rootFiles: string[];
} {
  const folders = new Map<string, { displayName: string; files: string[] }>();
  const rootFiles: string[] = [];

  function walk(nodes: FileNode[], parentPath: string = "", depth: number = 0) {
    for (const node of nodes) {
      const currentPath = parentPath ? `${parentPath}/${node.name}` : node.name;
      if (node.type === "folder" && node.children) {
        const folderFiles: string[] = [];
        collectDirectFileNames(node.children, folderFiles);
        if (folderFiles.length > 0) {
          folders.set(currentPath, {
            displayName: currentPath,
            files: folderFiles.slice(0, 8),
          });
        }
        walk(node.children, currentPath, depth + 1);
      } else if (node.type === "file" && depth === 0) {
        rootFiles.push(node.name);
      }
    }
  }

  walk(fileTree);
  return { folders, rootFiles };
}

function collectDirectFileNames(nodes: FileNode[], result: string[]) {
  for (const node of nodes) {
    if (node.type === "file") result.push(node.name);
  }
}

interface LayerStyle {
  borderColor: string;
  bgColor: string;
  glowColor: string;
  handleColor: string;
  icon: typeof FolderOpen;
}

function getLayerColor(folderPath: string): LayerStyle {
  const name = folderPath.split("/").pop()?.toLowerCase() || "";
  if (name === "src" || name === "app" || name === "lib") {
    return { borderColor: "border-blue-400", bgColor: "bg-blue-950/80", glowColor: "shadow-blue-500/20", handleColor: "!bg-blue-400", icon: FolderOpen };
  }
  if (name === "components" || name === "ui" || name === "views" || name === "pages") {
    return { borderColor: "border-purple-400", bgColor: "bg-purple-950/80", glowColor: "shadow-purple-500/20", handleColor: "!bg-purple-400", icon: Puzzle };
  }
  if (name === "api" || name === "routes" || name === "controllers" || name === "server") {
    return { borderColor: "border-amber-400", bgColor: "bg-amber-950/80", glowColor: "shadow-amber-500/20", handleColor: "!bg-amber-400", icon: Zap };
  }
  if (name === "models" || name === "schemas" || name === "db" || name === "database" || name === "migrations") {
    return { borderColor: "border-emerald-400", bgColor: "bg-emerald-950/80", glowColor: "shadow-emerald-500/20", handleColor: "!bg-emerald-400", icon: Database };
  }
  if (name === "tests" || name === "test" || name === "__tests__" || name === "spec") {
    return { borderColor: "border-cyan-400", bgColor: "bg-cyan-950/80", glowColor: "shadow-cyan-500/20", handleColor: "!bg-cyan-400", icon: FlaskConical };
  }
  if (name === "config" || name === "configs" || name === "settings") {
    return { borderColor: "border-orange-400", bgColor: "bg-orange-950/80", glowColor: "shadow-orange-500/20", handleColor: "!bg-orange-400", icon: Settings };
  }
  if (name === "public" || name === "static" || name === "assets" || name === "styles" || name === "css") {
    return { borderColor: "border-pink-400", bgColor: "bg-pink-950/80", glowColor: "shadow-pink-500/20", handleColor: "!bg-pink-400", icon: Palette };
  }
  if (name === "utils" || name === "helpers" || name === "shared" || name === "common") {
    return { borderColor: "border-indigo-400", bgColor: "bg-indigo-950/80", glowColor: "shadow-indigo-500/20", handleColor: "!bg-indigo-400", icon: Wrench };
  }
  if (name === "middleware" || name === "middlewares") {
    return { borderColor: "border-rose-400", bgColor: "bg-rose-950/80", glowColor: "shadow-rose-500/20", handleColor: "!bg-rose-400", icon: Link2 };
  }
  if (name === "docker" || name === "deploy" || name === "deployment" || name === "infra") {
    return { borderColor: "border-teal-400", bgColor: "bg-teal-950/80", glowColor: "shadow-teal-500/20", handleColor: "!bg-teal-400", icon: Container };
  }
  return { borderColor: "border-gray-400", bgColor: "bg-gray-950/80", glowColor: "shadow-gray-500/20", handleColor: "!bg-gray-400", icon: Folder };
}

function buildDiagram(fileTree: FileNode[], spec: ProjectSpec): { nodes: Node[]; edges: Edge[] } {
  const { folders, rootFiles } = categorizeFiles(fileTree);
  const nodes: Node[] = [];
  const edges: Edge[] = [];

  nodes.push({
    id: "entry-user",
    type: "entry",
    position: { x: 30, y: 180 },
    data: {
      icon: User, label: "User Request", sub: "Requirements Input",
      borderColor: "border-blue-400", bgColor: "bg-blue-950/80",
      glowColor: "shadow-blue-500/20", handleColor: "!bg-blue-400",
      textColor: "#93c5fd",
    },
  });

  nodes.push({
    id: "langgraph",
    type: "layer",
    position: { x: 250, y: 170 },
    data: {
      icon: Bot, label: "LangGraph Pipeline",
      sub: "Planner > Coder > Reviewer",
      borderColor: "border-purple-400", bgColor: "bg-purple-950/80",
      glowColor: "shadow-purple-500/20", handleColor: "!bg-purple-400",
    },
  });

  edges.push({
    id: "e-user-langgraph",
    source: "entry-user", target: "langgraph",
    animated: true,
    style: { stroke: "#818cf8", strokeWidth: 2 },
    markerEnd: { type: MarkerType.ArrowClosed, color: "#818cf8" },
  });

  const folderEntries = Array.from(folders.entries());
  const startX = 520;
  const startY = 40;
  const yGap = 90;

  folderEntries.forEach(([folderPath, folderData], idx) => {
    const colors = getLayerColor(folderPath);
    const y = startY + idx * yGap;
    const safeId = folderPath.replace(/[^a-zA-Z0-9]/g, "-");

    nodes.push({
      id: `folder-${safeId}`,
      type: "layer",
      position: { x: startX, y },
      data: {
        ...colors,
        label: `/${folderData.displayName}`,
        sub: `${folderData.files.length} file(s)`,
      },
    });

    edges.push({
      id: `e-lg-${safeId}`,
      source: "langgraph", target: `folder-${safeId}`,
      animated: true,
      style: { stroke: "#a78bfa", strokeWidth: 1.5 },
      markerEnd: { type: MarkerType.ArrowClosed, color: "#a78bfa" },
    });

    nodes.push({
      id: `files-${safeId}`,
      type: "fileGroup",
      position: { x: startX + 280, y: y + 5 },
      data: {
        label: `${folderPath} files`,
        files: folderData.files,
        borderColor: `${colors.borderColor}/40`,
        bgColor: colors.bgColor.replace("/80", "/40"),
      },
    });

    edges.push({
      id: `e-folder-files-${safeId}`,
      source: `folder-${safeId}`, target: `files-${safeId}`,
      style: { stroke: "#6b7280", strokeDasharray: "3 3" },
      markerEnd: { type: MarkerType.ArrowClosed, color: "#6b7280" },
    });
  });

  if (rootFiles.length > 0) {
    const rootY = startY + folderEntries.length * yGap;
    nodes.push({
      id: "root-files",
      type: "fileGroup",
      position: { x: startX + 50, y: rootY },
      data: {
        label: "Root Files",
        files: rootFiles.slice(0, 10),
        borderColor: "border-gray-500/40",
        bgColor: "bg-gray-950/50",
      },
    });

    edges.push({
      id: "e-lg-root",
      source: "langgraph", target: "root-files",
      style: { stroke: "#6b7280", strokeDasharray: "3 3" },
      markerEnd: { type: MarkerType.ArrowClosed, color: "#6b7280" },
    });
  }

  const outputY = 180;
  nodes.push({
    id: "output",
    type: "outputNode",
    position: { x: startX + 520, y: outputY },
    data: {
      icon: Package, label: "Generated Project", sub: "ZIP Download",
      borderColor: "border-green-400", bgColor: "bg-green-950/80",
      glowColor: "shadow-green-500/20", handleColor: "!bg-green-400",
      textColor: "#86efac",
    },
  });

  if (folderEntries.length > 0) {
    const midIdx = Math.floor(folderEntries.length / 2);
    const midSafeId = folderEntries[midIdx][0].replace(/[^a-zA-Z0-9]/g, "-");
    edges.push({
      id: "e-mid-output",
      source: `folder-${midSafeId}`, target: "output",
      animated: true,
      style: { stroke: "#4ade80", strokeWidth: 2 },
      markerEnd: { type: MarkerType.ArrowClosed, color: "#4ade80" },
      label: "Build",
      labelStyle: { fill: "#86efac", fontSize: 9, fontWeight: 600 },
      labelBgStyle: { fill: "rgba(0,0,0,0.6)" },
    });
  }

  const techStackItems: string[] = [];
  if (spec.frontend && spec.frontend !== "None") techStackItems.push(spec.frontend);
  if (spec.backend && spec.backend !== "None") techStackItems.push(spec.backend);
  if (spec.language) techStackItems.push(spec.language);
  if (spec.database && spec.database !== "None") techStackItems.push(spec.database);

  const securityItems: string[] = [];
  if (spec.authEnabled) securityItems.push("Auth");
  if (spec.jwtEnabled) securityItems.push("JWT");
  if (spec.encryptionEnabled) securityItems.push("Encryption");

  const deployItems: string[] = [];
  if (spec.deployment && spec.deployment !== "None") deployItems.push(spec.deployment);
  if (spec.cloud && spec.cloud !== "None") deployItems.push(spec.cloud);

  const bottomY = Math.max(startY + (folderEntries.length + 1) * yGap + 30, 500);

  if (techStackItems.length > 0) {
    nodes.push({
      id: "tech-stack",
      type: "tech",
      position: { x: 50, y: bottomY },
      data: { label: "Tech Stack", techs: techStackItems, borderColor: "border-blue-500/40", bgColor: "bg-blue-950/40" },
    });
  }

  nodes.push({
    id: "ai-framework",
    type: "tech",
    position: { x: 300, y: bottomY },
    data: { label: "AI Framework", techs: ["LangGraph", "LangChain", "OpenAI GPT-4o", "GPT-4o-mini"], borderColor: "border-purple-500/40", bgColor: "bg-purple-950/40" },
  });

  if (securityItems.length > 0) {
    nodes.push({
      id: "security",
      type: "tech",
      position: { x: 570, y: bottomY },
      data: { label: "Security", techs: [...securityItems, "OWASP"], borderColor: "border-red-500/40", bgColor: "bg-red-950/40" },
    });
  }

  if (deployItems.length > 0) {
    nodes.push({
      id: "deployment",
      type: "tech",
      position: { x: 800, y: bottomY },
      data: { label: "Deployment", techs: deployItems, borderColor: "border-teal-500/40", bgColor: "bg-teal-950/40" },
    });
  }

  return { nodes, edges };
}

interface ProjectArchitectureDiagramProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  fileTree: FileNode[];
  spec: ProjectSpec;
  projectName: string;
}

export default function ProjectArchitectureDiagram({ open, onOpenChange, fileTree, spec, projectName }: ProjectArchitectureDiagramProps) {
  const { nodes, edges } = useMemo(() => buildDiagram(fileTree, spec), [fileTree, spec]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[95vw] w-[95vw] h-[90vh] p-0 overflow-hidden bg-gray-950 border-gray-800" data-testid="dialog-project-architecture">
        <DialogHeader className="px-5 pt-4 pb-2 border-b border-gray-800 bg-gray-950/95 z-10">
          <DialogTitle className="text-base font-bold text-white flex items-center gap-2 flex-wrap">
            <span>{projectName || "Generated Project"} -- Architecture</span>
            {spec.frontend && spec.frontend !== "None" && <Badge variant="secondary" className="text-[9px]">{spec.frontend}</Badge>}
            {spec.backend && spec.backend !== "None" && <Badge variant="secondary" className="text-[9px]">{spec.backend}</Badge>}
            {spec.language && <Badge variant="secondary" className="text-[9px]">{spec.language}</Badge>}
            {spec.database && spec.database !== "None" && <Badge variant="outline" className="text-[9px] text-emerald-400 border-emerald-400/40">{spec.database}</Badge>}
            <Badge variant="outline" className="text-[9px] text-purple-400 border-purple-400/40">LangGraph Pipeline</Badge>
          </DialogTitle>
          <DialogDescription className="sr-only">Architecture diagram for the generated project</DialogDescription>
        </DialogHeader>
        <div className="w-full h-full" style={{ height: "calc(90vh - 60px)" }}>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            nodeTypes={nodeTypes}
            fitView
            fitViewOptions={{ padding: 0.2 }}
            minZoom={0.2}
            maxZoom={2.5}
            proOptions={{ hideAttribution: true }}
          >
            <Background color="#333" gap={20} size={1} />
            <Controls className="!bg-gray-900 !border-gray-700 !rounded-lg [&>button]:!bg-gray-800 [&>button]:!border-gray-700 [&>button]:!text-white [&>button:hover]:!bg-gray-700" />
            <MiniMap
              className="!bg-gray-900 !border-gray-700 !rounded-lg"
              nodeColor={(node) => {
                if (node.type === "layer") return "#7c3aed";
                if (node.type === "entry") return "#3b82f6";
                if (node.type === "outputNode") return "#22c55e";
                if (node.type === "fileGroup") return "#6b7280";
                return "#4b5563";
              }}
              maskColor="rgba(0,0,0,0.7)"
            />
          </ReactFlow>
        </div>
      </DialogContent>
    </Dialog>
  );
}
