import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileText, Layers, Shield, Cloud, ClipboardCheck, Zap, Upload } from "lucide-react";
import type { ProjectSpec } from "@/lib/types";
import { useRef } from "react";

interface SetupWizardProps {
  spec: ProjectSpec;
  onUpdate: (partial: Partial<ProjectSpec>) => void;
  onGenerate: () => void;
  isGenerating: boolean;
  onFileUpload: (content: string) => void;
}

export function SetupWizard({ spec, onUpdate, onGenerate, isGenerating, onFileUpload }: SetupWizardProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      onFileUpload(text);
    };
    reader.readAsText(file);
  };

  const canGenerate = spec.requirements.trim().length > 0 || spec.features.trim().length > 0;

  return (
    <div className="flex flex-col h-full">
      <div className="px-3 py-2 border-b flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Setup Wizard</span>
        </div>
        <Badge variant="outline" className="text-[10px]">TOGAF</Badge>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-2">
          <div className="mb-3 p-2 rounded-md border border-dashed border-muted-foreground/30 flex flex-col items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept=".md,.txt,.markdown"
              onChange={handleFileUpload}
              className="hidden"
              data-testid="input-file-upload"
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              className="w-full"
              data-testid="button-upload-file"
            >
              <Upload className="w-4 h-4 mr-2" />
              Upload MD / Text File
            </Button>
            <span className="text-[10px] text-muted-foreground">or fill out the wizard below</span>
          </div>

          <Accordion type="multiple" defaultValue={["requirements", "technologies"]} className="space-y-1">
            <AccordionItem value="requirements" className="border rounded-md px-2">
              <AccordionTrigger className="py-2 text-xs font-medium hover:no-underline">
                <div className="flex items-center gap-2">
                  <FileText className="w-3.5 h-3.5 text-blue-400" />
                  <span>Requirements & Features</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pb-3">
                <div className="space-y-2">
                  <div>
                    <Label className="text-[11px] text-muted-foreground mb-1 block">Project Requirements</Label>
                    <Textarea
                      placeholder="Describe your project requirements..."
                      value={spec.requirements}
                      onChange={(e) => onUpdate({ requirements: e.target.value })}
                      className="text-xs min-h-[80px] resize-none font-mono"
                      data-testid="input-requirements"
                    />
                  </div>
                  <div>
                    <Label className="text-[11px] text-muted-foreground mb-1 block">User Stories / Features</Label>
                    <Textarea
                      placeholder="As a user, I want to..."
                      value={spec.features}
                      onChange={(e) => onUpdate({ features: e.target.value })}
                      className="text-xs min-h-[60px] resize-none font-mono"
                      data-testid="input-features"
                    />
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="technologies" className="border rounded-md px-2">
              <AccordionTrigger className="py-2 text-xs font-medium hover:no-underline">
                <div className="flex items-center gap-2">
                  <Layers className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Technologies</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pb-3">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-[11px] text-muted-foreground mb-1 block">Frontend</Label>
                    <Select value={spec.frontend} onValueChange={(v) => onUpdate({ frontend: v })}>
                      <SelectTrigger className="text-xs" data-testid="select-frontend">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="React">React</SelectItem>
                        <SelectItem value="Vue">Vue</SelectItem>
                        <SelectItem value="Angular">Angular</SelectItem>
                        <SelectItem value="Streamlit">Streamlit</SelectItem>
                        <SelectItem value="None">None</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-[11px] text-muted-foreground mb-1 block">Backend</Label>
                    <Select value={spec.backend} onValueChange={(v) => onUpdate({ backend: v })}>
                      <SelectTrigger className="text-xs" data-testid="select-backend">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Node.js">Node.js</SelectItem>
                        <SelectItem value="Python">Python</SelectItem>
                        <SelectItem value="Django">Django</SelectItem>
                        <SelectItem value="Flask">Flask</SelectItem>
                        <SelectItem value="None">None</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-[11px] text-muted-foreground mb-1 block">Language</Label>
                    <Select value={spec.language} onValueChange={(v) => onUpdate({ language: v })}>
                      <SelectTrigger className="text-xs" data-testid="select-language">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Python">Python</SelectItem>
                        <SelectItem value="JavaScript">JavaScript</SelectItem>
                        <SelectItem value="TypeScript">TypeScript</SelectItem>
                        <SelectItem value="C#">C#</SelectItem>
                        <SelectItem value="Java">Java</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-[11px] text-muted-foreground mb-1 block">Database</Label>
                    <Select value={spec.database} onValueChange={(v) => onUpdate({ database: v })}>
                      <SelectTrigger className="text-xs" data-testid="select-database">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="SQLite">SQLite</SelectItem>
                        <SelectItem value="PostgreSQL">PostgreSQL</SelectItem>
                        <SelectItem value="MongoDB">MongoDB</SelectItem>
                        <SelectItem value="MySQL">MySQL</SelectItem>
                        <SelectItem value="InMemory">InMemory</SelectItem>
                        <SelectItem value="None">None</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="security" className="border rounded-md px-2">
              <AccordionTrigger className="py-2 text-xs font-medium hover:no-underline">
                <div className="flex items-center gap-2">
                  <Shield className="w-3.5 h-3.5 text-amber-400" />
                  <span>Security</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pb-3">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="auth"
                      checked={spec.authEnabled}
                      onCheckedChange={(c) => onUpdate({ authEnabled: !!c })}
                      data-testid="checkbox-auth"
                    />
                    <Label htmlFor="auth" className="text-xs cursor-pointer">Authentication</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="jwt"
                      checked={spec.jwtEnabled}
                      onCheckedChange={(c) => onUpdate({ jwtEnabled: !!c })}
                      data-testid="checkbox-jwt"
                    />
                    <Label htmlFor="jwt" className="text-xs cursor-pointer">JWT Tokens</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="encryption"
                      checked={spec.encryptionEnabled}
                      onCheckedChange={(c) => onUpdate({ encryptionEnabled: !!c })}
                      data-testid="checkbox-encryption"
                    />
                    <Label htmlFor="encryption" className="text-xs cursor-pointer">Encryption</Label>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="deployment" className="border rounded-md px-2">
              <AccordionTrigger className="py-2 text-xs font-medium hover:no-underline">
                <div className="flex items-center gap-2">
                  <Cloud className="w-3.5 h-3.5 text-purple-400" />
                  <span>Deployment</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pb-3">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-[11px] text-muted-foreground mb-1 block">Platform</Label>
                    <Select value={spec.deployment} onValueChange={(v) => onUpdate({ deployment: v })}>
                      <SelectTrigger className="text-xs" data-testid="select-deployment">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Docker">Docker</SelectItem>
                        <SelectItem value="Heroku">Heroku</SelectItem>
                        <SelectItem value="Vercel">Vercel</SelectItem>
                        <SelectItem value="Railway">Railway</SelectItem>
                        <SelectItem value="AWS">AWS</SelectItem>
                        <SelectItem value="Azure">Azure</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-[11px] text-muted-foreground mb-1 block">Cloud Provider</Label>
                    <Select value={spec.cloud} onValueChange={(v) => onUpdate({ cloud: v })}>
                      <SelectTrigger className="text-xs" data-testid="select-cloud">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="None">None</SelectItem>
                        <SelectItem value="AWS">AWS</SelectItem>
                        <SelectItem value="Azure">Azure</SelectItem>
                        <SelectItem value="GCP">GCP</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="governance" className="border rounded-md px-2">
              <AccordionTrigger className="py-2 text-xs font-medium hover:no-underline">
                <div className="flex items-center gap-2">
                  <ClipboardCheck className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Governance</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pb-3">
                <div className="space-y-2">
                  <div>
                    <Label className="text-[11px] text-muted-foreground mb-1 block">Compliance Requirements</Label>
                    <Input
                      placeholder="e.g., GDPR, HIPAA, SOX..."
                      value={spec.compliance}
                      onChange={(e) => onUpdate({ compliance: e.target.value })}
                      className="text-xs"
                      data-testid="input-compliance"
                    />
                  </div>
                  <div>
                    <Label className="text-[11px] text-muted-foreground mb-1 block">Logging Strategy</Label>
                    <Input
                      placeholder="e.g., structured logging, ELK..."
                      value={spec.logging}
                      onChange={(e) => onUpdate({ logging: e.target.value })}
                      className="text-xs"
                      data-testid="input-logging"
                    />
                  </div>
                  <div>
                    <Label className="text-[11px] text-muted-foreground mb-1 block">Audit Trail</Label>
                    <Input
                      placeholder="e.g., user actions, data changes..."
                      value={spec.auditing}
                      onChange={(e) => onUpdate({ auditing: e.target.value })}
                      className="text-xs"
                      data-testid="input-auditing"
                    />
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </ScrollArea>

      <div className="p-3 border-t">
        <Button
          onClick={onGenerate}
          disabled={!canGenerate || isGenerating}
          className="w-full"
          data-testid="button-forge"
        >
          <Zap className="w-4 h-4 mr-2" />
          {isGenerating ? "Forging..." : "Forge Software"}
        </Button>
      </div>
    </div>
  );
}
