import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/theme-toggle";
import { Plus, Download, RotateCcw, Home, Info, GitBranch } from "lucide-react";
import logoImg from "@assets/14657058_1771552453637.png";

interface HeaderProps {
  projectName: string;
  isGenerating: boolean;
  hasFiles: boolean;
  onNewProject: () => void;
  onDownload: () => void;
  onRegenerate: () => void;
  onShowArchitecture?: () => void;
}

export function Header({ projectName, isGenerating, hasFiles, onNewProject, onDownload, onRegenerate, onShowArchitecture }: HeaderProps) {
  return (
    <header className="flex items-center justify-between gap-4 px-4 py-2 border-b bg-card" style={{ minHeight: "3rem" }}>
      <div className="flex items-center gap-3 flex-wrap">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer">
            <img src={logoImg} alt="ZenForge Agent" className="w-8 h-8 rounded-md object-cover" />
            <div className="flex flex-col">
              <span className="text-sm font-semibold leading-tight" data-testid="text-app-title">ZenForge Agent</span>
              <span className="text-[10px] text-muted-foreground leading-tight">Agentic Software Forge</span>
            </div>
          </div>
        </Link>
        {projectName && (
          <Badge variant="secondary" className="text-xs" data-testid="badge-project-name">
            {projectName}
          </Badge>
        )}
        {isGenerating && (
          <Badge variant="outline" className="text-xs animate-pulse" data-testid="badge-generating">
            Generating...
          </Badge>
        )}
      </div>
      <div className="flex items-center gap-2 flex-wrap">
        <Link href="/">
          <Button variant="ghost" size="sm" data-testid="link-home-forge">
            <Home className="w-4 h-4 mr-1" />
            Home
          </Button>
        </Link>
        <Link href="/about">
          <Button variant="ghost" size="sm" data-testid="link-about-forge">
            <Info className="w-4 h-4 mr-1" />
            About
          </Button>
        </Link>
        <Button variant="ghost" size="sm" onClick={onNewProject} data-testid="button-new-project">
          <Plus className="w-4 h-4 mr-1" />
          New
        </Button>
        {hasFiles && (
          <>
            <Button variant="ghost" size="sm" onClick={onShowArchitecture} data-testid="button-show-architecture">
              <GitBranch className="w-4 h-4 mr-1" />
              Architecture
            </Button>
            <Button variant="ghost" size="sm" onClick={onRegenerate} disabled={isGenerating} data-testid="button-regenerate">
              <RotateCcw className="w-4 h-4 mr-1" />
              Iterate
            </Button>
            <Button variant="outline" size="sm" onClick={onDownload} data-testid="button-download">
              <Download className="w-4 h-4 mr-1" />
              Download ZIP
            </Button>
          </>
        )}
        <ThemeToggle />
      </div>
    </header>
  );
}
