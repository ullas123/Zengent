import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  type Node,
  type Edge,
  Position,
  MarkerType,
  Handle,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  FileText,
  Settings,
  Brain,
  Code2,
  Search,
  Package,
  Radio,
} from "lucide-react";

function UserInputNode({ data }: { data: any }) {
  const IconComp = data.icon || FileText;
  return (
    <div className="px-4 py-3 rounded-xl border-2 border-blue-400 bg-blue-950/80 shadow-lg shadow-blue-500/20 min-w-[180px]" data-testid={`node-${data.id}`}>
      <Handle type="source" position={Position.Right} className="!bg-blue-400 !w-2.5 !h-2.5" />
      <div className="text-center">
        <div className="flex justify-center mb-1"><IconComp className="w-4 h-4 text-blue-300" /></div>
        <div className="text-xs font-bold text-blue-300">{data.label}</div>
        <div className="text-[9px] text-blue-400/70 mt-0.5">{data.sub}</div>
      </div>
    </div>
  );
}

function AgentNode({ data }: { data: any }) {
  const IconComp = data.icon || Brain;
  return (
    <div className={`px-4 py-3 rounded-xl border-2 ${data.borderColor} ${data.bgColor} shadow-lg ${data.glowColor} min-w-[200px]`} data-testid={`node-${data.id}`}>
      <Handle type="target" position={Position.Left} className={`!w-2.5 !h-2.5 ${data.handleColor}`} />
      <Handle type="source" position={Position.Right} className={`!w-2.5 !h-2.5 ${data.handleColor}`} />
      <div className="text-center">
        <div className="flex justify-center mb-1"><IconComp className="w-4 h-4 text-white/80" /></div>
        <div className="text-xs font-bold text-white">{data.label}</div>
        <div className="flex items-center justify-center gap-1 mt-1">
          <span className="text-[8px] px-1.5 py-0.5 rounded bg-white/10 text-white/80 font-medium">{data.model}</span>
          <span className="text-[8px] px-1.5 py-0.5 rounded bg-white/10 text-white/80 font-medium">LangGraph</span>
        </div>
        <div className="text-[9px] text-white/50 mt-1">{data.sub}</div>
      </div>
    </div>
  );
}

function TechStackNode({ data }: { data: any }) {
  return (
    <div className={`px-3 py-2 rounded-lg border ${data.borderColor} ${data.bgColor} min-w-[140px]`} data-testid={`node-${data.id}`}>
      <Handle type="target" position={Position.Top} className="!bg-gray-400 !w-2 !h-2" />
      <Handle type="source" position={Position.Bottom} className="!bg-gray-400 !w-2 !h-2" />
      <div className="text-center">
        <div className="text-[10px] font-semibold text-white/90">{data.label}</div>
        <div className="flex flex-wrap justify-center gap-0.5 mt-1">
          {data.techs?.map((t: string) => (
            <span key={t} className="text-[7px] px-1 py-0.5 rounded bg-white/10 text-white/60">{t}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

function OutputNode({ data }: { data: any }) {
  const IconComp = data.icon || Package;
  return (
    <div className="px-4 py-3 rounded-xl border-2 border-green-400 bg-green-950/80 shadow-lg shadow-green-500/20 min-w-[180px]" data-testid={`node-${data.id}`}>
      <Handle type="target" position={Position.Left} className="!bg-green-400 !w-2.5 !h-2.5" />
      <div className="text-center">
        <div className="flex justify-center mb-1"><IconComp className="w-4 h-4 text-green-300" /></div>
        <div className="text-xs font-bold text-green-300">{data.label}</div>
        <div className="text-[9px] text-green-400/70 mt-0.5">{data.sub}</div>
      </div>
    </div>
  );
}

function FrameworkNode({ data }: { data: any }) {
  return (
    <div className={`px-4 py-3 rounded-xl border-2 border-dashed ${data.borderColor} ${data.bgColor} min-w-[220px]`} data-testid={`node-${data.id}`}>
      <div className="text-center">
        <div className="text-[10px] font-bold text-white/80 mb-1.5">{data.label}</div>
        <div className="flex flex-wrap justify-center gap-1">
          {data.techs?.map((t: string) => (
            <span key={t} className="text-[8px] px-1.5 py-0.5 rounded bg-white/15 text-white/70 font-medium">{t}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

function StateNode({ data }: { data: any }) {
  return (
    <div className="px-4 py-2 rounded-lg border-2 border-yellow-500/50 bg-yellow-950/60 shadow-md min-w-[200px]" data-testid={`node-${data.id}`}>
      <Handle type="target" position={Position.Top} className="!bg-yellow-400 !w-2 !h-2" />
      <Handle type="source" position={Position.Bottom} className="!bg-yellow-400 !w-2 !h-2" />
      <div className="text-center">
        <div className="text-[10px] font-bold text-yellow-300">{data.label}</div>
        <div className="text-[8px] text-yellow-400/60 mt-0.5">{data.sub}</div>
      </div>
    </div>
  );
}

const nodeTypes = {
  userInput: UserInputNode,
  agent: AgentNode,
  techStack: TechStackNode,
  output: OutputNode,
  framework: FrameworkNode,
  state: StateNode,
};

const initialNodes: Node[] = [
  {
    id: "user-input",
    type: "userInput",
    position: { x: 50, y: 220 },
    data: { id: "user-input", icon: FileText, label: "User Requirements", sub: "Text / Markdown Upload" },
  },
  {
    id: "togaf-wizard",
    type: "userInput",
    position: { x: 50, y: 350 },
    data: { id: "togaf-wizard", icon: Settings, label: "TOGAF Config Wizard", sub: "Tech Stack, Security, Deploy" },
  },
  {
    id: "langgraph-state",
    type: "state",
    position: { x: 320, y: 140 },
    data: { id: "langgraph-state", label: "LangGraph StateGraph", sub: "Typed State Annotations - Conditional Edges - Streaming" },
  },
  {
    id: "planner",
    type: "agent",
    position: { x: 340, y: 240 },
    data: {
      id: "planner", icon: Brain, label: "Agentic Planner",
      model: "GPT-4o", sub: "Architecture & File Structure",
      borderColor: "border-purple-400", bgColor: "bg-purple-950/80",
      glowColor: "shadow-purple-500/20", handleColor: "!bg-purple-400",
    },
  },
  {
    id: "coder",
    type: "agent",
    position: { x: 620, y: 240 },
    data: {
      id: "coder", icon: Code2, label: "Agentic Coder",
      model: "GPT-4o", sub: "Production Code Generation",
      borderColor: "border-amber-400", bgColor: "bg-amber-950/80",
      glowColor: "shadow-amber-500/20", handleColor: "!bg-amber-400",
    },
  },
  {
    id: "reviewer",
    type: "agent",
    position: { x: 900, y: 240 },
    data: {
      id: "reviewer", icon: Search, label: "Agentic Reviewer",
      model: "GPT-4o-mini", sub: "Quality, Security & License Audit",
      borderColor: "border-cyan-400", bgColor: "bg-cyan-950/80",
      glowColor: "shadow-cyan-500/20", handleColor: "!bg-cyan-400",
    },
  },
  {
    id: "output",
    type: "output",
    position: { x: 1180, y: 250 },
    data: { id: "output", icon: Package, label: "Project Output", sub: "ZIP Download - IDE View" },
  },
  {
    id: "sse",
    type: "techStack",
    position: { x: 600, y: 380 },
    data: { id: "sse", label: "Real-Time Streaming", borderColor: "border-orange-500/40", bgColor: "bg-orange-950/50", techs: ["SSE", "EventSource", "Live Build Logs"] },
  },
  {
    id: "frontend-stack",
    type: "framework",
    position: { x: 50, y: 500 },
    data: { id: "frontend-stack", label: "Frontend", borderColor: "border-blue-500/40", bgColor: "bg-blue-950/40", techs: ["React 18", "TypeScript 5", "Tailwind CSS", "shadcn/ui", "Framer Motion", "CodeMirror", "React Flow"] },
  },
  {
    id: "backend-stack",
    type: "framework",
    position: { x: 350, y: 500 },
    data: { id: "backend-stack", label: "Backend", borderColor: "border-green-500/40", bgColor: "bg-green-950/40", techs: ["Node.js 20", "Express 5", "Drizzle ORM", "PostgreSQL", "Archiver"] },
  },
  {
    id: "ai-stack",
    type: "framework",
    position: { x: 650, y: 500 },
    data: { id: "ai-stack", label: "AI / Agentic Framework", borderColor: "border-purple-500/40", bgColor: "bg-purple-950/40", techs: ["LangGraph", "LangChain", "OpenAI GPT-4o", "GPT-4o-mini", "ChatOpenAI"] },
  },
  {
    id: "security-stack",
    type: "framework",
    position: { x: 950, y: 500 },
    data: { id: "security-stack", label: "Security & Validation", borderColor: "border-red-500/40", bgColor: "bg-red-950/40", techs: ["OWASP Rules", "SPDX Licenses", "npm Registry", "SemVer", "JWT", "OAuth2"] },
  },
  {
    id: "db",
    type: "techStack",
    position: { x: 350, y: 620 },
    data: { id: "db", label: "Database Layer", borderColor: "border-emerald-500/40", bgColor: "bg-emerald-950/50", techs: ["PostgreSQL", "Drizzle ORM", "Projects", "Logs"] },
  },
  {
    id: "deploy-stack",
    type: "framework",
    position: { x: 650, y: 620 },
    data: { id: "deploy-stack", label: "Deployment Targets", borderColor: "border-cyan-500/40", bgColor: "bg-cyan-950/40", techs: ["Docker", "Vercel", "Railway", "AWS", "Azure"] },
  },
];

const initialEdges: Edge[] = [
  { id: "e-input-planner", source: "user-input", target: "planner", animated: true, style: { stroke: "#818cf8" }, markerEnd: { type: MarkerType.ArrowClosed, color: "#818cf8" } },
  { id: "e-togaf-planner", source: "togaf-wizard", target: "planner", animated: true, style: { stroke: "#818cf8" }, markerEnd: { type: MarkerType.ArrowClosed, color: "#818cf8" } },
  { id: "e-planner-coder", source: "planner", target: "coder", animated: true, style: { stroke: "#f59e0b", strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: "#f59e0b" }, label: "File Tree", labelStyle: { fill: "#fbbf24", fontSize: 9, fontWeight: 600 }, labelBgStyle: { fill: "rgba(0,0,0,0.6)" } },
  { id: "e-coder-reviewer", source: "coder", target: "reviewer", animated: true, style: { stroke: "#22d3ee", strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: "#22d3ee" }, label: "Generated Code", labelStyle: { fill: "#67e8f9", fontSize: 9, fontWeight: 600 }, labelBgStyle: { fill: "rgba(0,0,0,0.6)" } },
  { id: "e-reviewer-output", source: "reviewer", target: "output", animated: true, style: { stroke: "#4ade80", strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: "#4ade80" }, label: "Reviewed Output", labelStyle: { fill: "#86efac", fontSize: 9, fontWeight: 600 }, labelBgStyle: { fill: "rgba(0,0,0,0.6)" } },
  { id: "e-state-planner", source: "langgraph-state", target: "planner", style: { stroke: "#eab308", strokeDasharray: "4 4" }, markerEnd: { type: MarkerType.ArrowClosed, color: "#eab308" } },
  { id: "e-sse-coder", source: "coder", target: "sse", style: { stroke: "#f97316", strokeDasharray: "4 4" }, markerEnd: { type: MarkerType.ArrowClosed, color: "#f97316" } },
];

interface ArchitectureDiagramProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function ArchitectureDiagram({ open, onOpenChange }: ArchitectureDiagramProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[95vw] w-[95vw] h-[90vh] p-0 overflow-hidden bg-gray-950 border-gray-800" data-testid="dialog-architecture">
        <DialogHeader className="px-5 pt-4 pb-2 border-b border-gray-800 bg-gray-950/95 z-10">
          <DialogTitle className="text-base font-bold text-white flex items-center gap-2">
            <span>ZenForge Agent -- System Architecture</span>
            <Badge variant="secondary" className="text-[9px]">LangGraph + OpenAI</Badge>
            <Badge variant="outline" className="text-[9px] text-purple-400 border-purple-400/40">Multi-Agent Pipeline</Badge>
          </DialogTitle>
          <DialogDescription className="sr-only">Interactive architecture diagram showing the ZenForge Agent system</DialogDescription>
        </DialogHeader>
        <div className="w-full h-full" style={{ height: "calc(90vh - 60px)" }}>
          <ReactFlow
            nodes={initialNodes}
            edges={initialEdges}
            nodeTypes={nodeTypes}
            fitView
            fitViewOptions={{ padding: 0.15 }}
            minZoom={0.3}
            maxZoom={2}
            defaultViewport={{ x: 0, y: 0, zoom: 0.85 }}
            proOptions={{ hideAttribution: true }}
          >
            <Background color="#333" gap={20} size={1} />
            <Controls className="!bg-gray-900 !border-gray-700 !rounded-lg [&>button]:!bg-gray-800 [&>button]:!border-gray-700 [&>button]:!text-white [&>button:hover]:!bg-gray-700" />
            <MiniMap
              className="!bg-gray-900 !border-gray-700 !rounded-lg"
              nodeColor={(node) => {
                if (node.type === "agent") return "#7c3aed";
                if (node.type === "userInput") return "#3b82f6";
                if (node.type === "output") return "#22c55e";
                return "#6b7280";
              }}
              maskColor="rgba(0,0,0,0.7)"
            />
          </ReactFlow>
        </div>
      </DialogContent>
    </Dialog>
  );
}
