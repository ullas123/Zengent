# Nucleus 2.0 — Innersource Agentic SDLC Framework
### by Zensar Technologies · AMEX Diamond Project

Nucleus 2.0 is an enterprise application intelligence platform that automates code analysis, migration planning, compliance scanning, and documentation generation using a multi-agent AI pipeline. It supports Java (Spring Boot), Python (Django/Flask), PySpark, and Mainframe (COBOL/JCL) projects.

---

## Table of Contents
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Environment Variables](#environment-variables)
- [Running the App](#running-the-app)
- [Default Credentials](#default-credentials)
- [Project Structure](#project-structure)
- [Key Features](#key-features)
- [AI Configuration](#ai-configuration)
- [Database Setup](#database-setup)
- [Tech Stack](#tech-stack)

---

## Prerequisites

| Requirement | Version |
|---|---|
| Node.js | 18+ |
| npm | 9+ |
| Python | 3.9+ (for analysis scripts) |
| PostgreSQL | 14+ (optional — falls back to in-memory) |
| Git | Any recent version |

Optional for local AI:
- **Ollama** — for offline LLM support (no internet required)

---

## Installation

### 1. Clone the Repository

```bash
git clone https://github.com/your-org/nucleus-2.0.git
cd nucleus-2.0
```

### 2. Install Node.js Dependencies

```bash
npm install
```

### 3. Install Python Dependencies

```bash
pip install openpyxl numpy graphviz
```

> For advanced ML field matching (optional):
> ```bash
> pip install transformers torch
> ```

### 4. Set Up Environment Variables

Copy the example env file and fill in your values:

```bash
cp .env.example .env
```

See [Environment Variables](#environment-variables) for details.

### 5. Set Up the Database (Optional)

If you want PostgreSQL persistence:

```bash
npm run db:push
```

Without a database, the app runs entirely in memory — no data persists across restarts.

### 6. Start the Application

```bash
npm run dev
```

The app will be available at **http://localhost:5000**

---

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | Recommended | Claude AI for agent analysis (primary LLM) |
| `OPENAI_API_KEY` | Optional | GPT-4o fallback when no Anthropic key |
| `DATABASE_URL` | Optional | PostgreSQL connection string (Neon or local) |
| `OLLAMA_ENDPOINT` | Optional | Local Ollama server URL (e.g. `http://localhost:11434`) |
| `OLLAMA_MODEL` | Optional | Ollama model name (e.g. `codellama`, `deepseek-coder`) |
| `CONFLUENCE_EMAIL` | Optional | Atlassian account email for Confluence sync |
| `CONFLUENCE_API_TOKEN` | Optional | API token from Atlassian account settings |
| `SESSION_SECRET` | Optional | Express session secret (auto-generated if not set) |

> **Security note:** Never commit API keys to version control. Use environment secrets or a `.env` file that is `.gitignore`d.

---

## Running the App

| Command | Description |
|---|---|
| `npm run dev` | Start development server (frontend + backend) |
| `npm run build` | Build production bundle |
| `npm run start` | Start production server |
| `npm run db:push` | Apply database schema migrations |
| `npm run db:studio` | Open Drizzle Studio (database UI) |

---

## Default Credentials

| Field | Value |
|---|---|
| Username | `nucleus` |
| Password | `nucleus` |

> Change these in `server/auth.ts` before deploying to production.

---

## Project Structure

```
nucleus-2.0/
├── client/                        # React frontend (Vite + TypeScript)
│   └── src/
│       ├── pages/                 # All page components
│       ├── components/            # Shared UI components
│       ├── data/                  # Demo data and constants
│       └── hooks/                 # Custom React hooks
├── server/                        # Express backend (TypeScript)
│   ├── routes.ts                  # API route definitions
│   ├── storage.ts                 # Storage interface (DB or in-memory)
│   └── services/                  # AI, analysis, and scanning services
│       ├── codeLensAgent.py       # Python code analysis
│       ├── demographicScanner.ts  # PII/PHI field scanner
│       ├── cweScanner.ts          # CWE vulnerability scanner
│       ├── iso5055Analyzer.ts     # ISO quality metrics
│       ├── aiMigrationService.ts  # Migration planner
│       └── githubService.ts       # GitHub repo integration
├── shared/
│   └── schema.ts                  # Drizzle ORM schema + Zod types
├── README.md
└── package.json
```

---

## Key Features

- **Multi-Agent SDLC Canvas** — Drag-and-drop pipeline builder with specialized agents (Requirements → Code → QA → Migration → Docs)
- **Legacy Code Analysis** — Java, Python, PySpark, COBOL/JCL, Kotlin, C#
- **Demographic / PII Scanning** — 39 regex patterns, Excel field mapping, GDPR/HIPAA/PCI-DSS compliance reports
- **CWE Security Scanning** — 30+ vulnerability patterns, OWASP Top 10, severity classification
- **ISO/IEC 5055 Quality Metrics** — Reliability, Security, Performance, Maintainability scoring
- **Architecture Diagrams** — UML, Sequence, ER, Data Flow, Dependency Graphs
- **Confluence Sync** — Publish generated documentation directly to your Confluence space
- **GitHub Integration** — Analyze any public or private GitHub repository
- **PDF / HTML Export** — Professional reports with corporate branding
- **Offline AI Support** — Local LLM via Ollama, no cloud required

---

## AI Configuration

### Cloud AI (Default)
Nucleus uses **Anthropic Claude** (claude-3-7-sonnet) as the primary LLM with OpenAI GPT-4o as fallback.

```env
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
```

### Local / Offline AI (Ollama)
For air-gapped environments or privacy-sensitive projects:

1. Install Ollama: https://ollama.ai
2. Pull a model:
   ```bash
   ollama pull codellama
   # or
   ollama pull deepseek-coder
   ```
3. Set environment variables:
   ```env
   OLLAMA_ENDPOINT=http://localhost:11434
   OLLAMA_MODEL=codellama
   ```

---

## Database Setup

### With PostgreSQL (Recommended for Production)

```bash
# Set your connection string
DATABASE_URL=postgresql://user:password@host:5432/nucleus

# Apply schema
npm run db:push
```

### Without Database (Development / Demo)

Leave `DATABASE_URL` unset. The app runs in memory — all data is lost on restart but all features work.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript, Vite, Tailwind CSS, shadcn/ui |
| Routing | Wouter |
| State | TanStack Query v5 |
| Diagrams | React Flow, Mermaid.js, Cytoscape.js |
| Backend | Express.js, TypeScript, Node.js 18 |
| AI (Cloud) | Anthropic Claude, OpenAI GPT-4o |
| AI (Local) | Ollama (Code Llama, Deepseek Coder, Mistral) |
| Database | PostgreSQL + Drizzle ORM (Neon serverless) |
| Python | openpyxl, NumPy, Graphviz |
| Auth | express-session, bcrypt |
| Streaming | Server-Sent Events (SSE) |

---

## Contributing

This is an innersource project maintained by **Zensar Technologies** for the **AMEX Diamond Program**.

For internal contributions, follow the standard branching strategy and submit a pull request against `main`. All agents and analysis rules are in `server/services/` — new language support can be added by extending `codeAnalyzer.ts`.

---

## License

Internal use only — Zensar Technologies © 2025. Not for public distribution.
