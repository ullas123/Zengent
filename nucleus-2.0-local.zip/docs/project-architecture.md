# Code Lens - Enterprise Application Intelligence Platform

## Overview
Code Lens is an enterprise application intelligence platform designed to analyze multi-language project architectures from ZIP uploads and GitHub repositories. It supports Java, Python, PySpark, and Mainframe codebases, extracting and parsing source files to identify architectural patterns, dependencies, and relationships. The platform provides interactive visual diagrams and AI-powered analysis using various LLMs, delivering intelligent insights and recommendations. Key capabilities include Swagger API documentation generation, demographic field scanning with compliance reporting, integration pattern detection, POD→POA migration planning, Data Image and Quality Measures analysis, and professional PDF report generation. The ultimate vision is to provide comprehensive, AI-driven insights into complex enterprise applications to aid development, refactoring, and strategic planning, with upcoming advanced Agentic AI capabilities.

## User Preferences
Preferred communication style: Simple, everyday language.

### Critical Data Integrity Rules
**NEVER use mock values, dummy data, or placeholder content.** The system must ONLY display:
1. **Actual source code analysis results** from user-uploaded projects
2. **Real demographic scan data** from pattern matching or Excel field mapping
3. **Authentic AI-generated insights** from LLM analysis
4. **User-uploaded files and data** 

When no data is available, show appropriate empty state messages like "No analysis data available" or "No demographic fields found" instead of fake/sample data. This ensures users see only real, actionable information from their actual codebases.

## System Architecture

### UI/UX Decisions
The frontend is built with React and TypeScript, leveraging Tailwind CSS with shadcn/ui for a consistent, component-based design. The user experience is structured into three phases: upload, processing with real-time indicators, and results with interactive diagrams, powered by TanStack Query for state management and Wouter for routing.

### Technical Implementations
The backend uses Express.js and TypeScript, following a modular design, handling file processing (ZIP uploads with Multer) and GitHub integration. It features RESTful APIs for project management and intelligent code analysis. For development and testing, an in-memory storage (MemStorage) is used, requiring no database installation. The system supports database-based user authentication with bcrypt, session management, and multi-tenant support.

### Feature Specifications
The core analysis engine processes Java, Python, PySpark, and Mainframe projects, supporting automatic ZIP extraction and validation. It uses both OpenAI GPT-4o and local LLMs via Ollama (Code Llama, Deepseek Coder, StarCoder, Llama 3, Mistral) for privacy-first analysis. The platform generates dependency graphs, architectural relationships, interactive UML-style diagrams, and professional PDF reports. AI insights include project overviews, architecture analysis, actionable recommendations, quality assessment scores, and module-level improvement opportunities.

The **ZenVector Agent** utilizes ChromaDB for persistent vector storage, enabling code similarity detection, semantic search, and demographic data analysis. The **Knowledge Agent** provides document intelligence and Q&A using LangChain, LangGraph, and ChromaDB, supporting multi-model AI responses.

The **POD→POA Migration AI Suggester** analyzes legacy systems to generate comprehensive migration roadmaps, including automated POD assessment, AI-powered POA architecture recommendations, phased migration plans, demographic data migration strategies, and cost-benefit analysis. It integrates various AI models (OpenAI GPT-4o, Ollama, HuggingFace CodeBERT) for a multi-AI approach to risk management and strategic planning.

The **Data Image and Quality Measures** module provides code quality and data lineage analysis aligned with ISO/IEC 25010 standards, covering reliability, security (CWE), maintainability, performance efficiency, and testability. It offers data flow mapping, field-to-function mapping, quality visualization (heat maps, dependency graphs), and actionable insights.

The **Advanced Intelligence Features** (under development as premium enterprise add-on) will provide next-generation capabilities including:
- **Real-time collaboration** with multi-analyst workspaces and live code annotations
- **Predictive analytics** for technical debt forecasting and defect probability scoring
- **Automated code transformation** with one-click refactoring and design pattern application
- **CI/CD integration** for continuous code intelligence and automated quality gates
- **Multi-repository portfolio analysis** for enterprise-wide insights and compliance
- **Advanced security** with SAST/DAST integration and automated remediation
- **Vector database intelligence** using ChromaDB, Pinecone, Weaviate for semantic code search, clone detection, and architectural pattern discovery
- **Generative AI functions** leveraging GPT-4o, Claude Opus, Gemini Pro for code explanation, migration code generation, test scenario creation, security patch generation, and documentation synthesis
- **Agentic orchestrator with MCP (Model Context Protocol)** for multi-agent coordination, context sharing, workflow automation, smart task routing, tool chaining, and intelligent agent state management
- **Custom pattern builder** with no-code visual designer and industry templates
- **Executive dashboard** with KPI tracking, ROI metrics, and strategic recommendations
- **Enterprise integrations** with Jira, Slack, GitHub, Confluence, DataDog

## External Dependencies

### Database and ORM
- **PostgreSQL**: Primary database.
- **Drizzle ORM**: Type-safe database queries.
- **Neon Database**: Serverless PostgreSQL integration.

### Frontend Libraries
- **shadcn/ui**: React component library.
- **Radix UI**: Headless UI primitives.
- **Tailwind CSS**: Utility-first CSS framework.
- **React Flow**: Interactive diagram rendering.
- **Lucide React**: Icon library.

### File Processing
- **Multer**: Express middleware for file uploads.
- **JSZip**: JavaScript library for ZIP file extraction.

### AI & Analysis Integration
- **OpenAI API**: GPT-4o integration.
- **Ollama Integration**: Local LLM server support.
- **IBM Doclinq**: Enterprise-grade PDF processing.
- **LangChain**: AI application development framework.
- **LangGraph**: Orchestration for complex AI workflows.
- **Langfuse**: LLM observability platform.
- **HuggingFace Models**: Local AI processing models (CodeBERT, etc.).
- **ChromaDB**: Vector database for AI agents.
- **Redis**: Caching for performance optimization.

### Development Tools
- **Vite**: Frontend build tool.
- **TypeScript**: Static type checking.
- **ESBuild**: Fast JavaScript bundler.

### Validation and Utilities
- **Zod**: Schema validation.
- **date-fns**: Date utility library.
- **clsx**: Utility for className strings.
- **cross-env**: Cross-platform environment variable setting.