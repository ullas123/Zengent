# Code Lens - Demographic Data Scanning Process - Flow Diagram

## Process Overview

```
┌─────────────────────────────────────────────────────────────┐
│         DEMOGRAPHIC DATA SCANNING SYSTEM                     │
│         (Find Sensitive PII/PHI Fields in Code)             │
└─────────────────────────────────────────────────────────────┘
                            │
                            │
                ┌───────────┴───────────┐
                │                       │
                ▼                       ▼
    ┌──────────────────┐    ┌──────────────────────┐
    │   PATH 1:        │    │   PATH 2:            │
    │   REGEX SCAN     │    │   EXCEL FIELD SCAN   │
    │   (Automatic)    │    │   (User Upload)      │
    └──────────────────┘    └──────────────────────┘
```

---

## PATH 1: Regex Pattern Search (Automatic)

```
┌─────────────────────────────────────────────────────────────┐
│ START: User uploads ZIP/GitHub project                      │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Extract all source    │
        │  files from project    │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Load 39 Pre-defined   │
        │  Regex Patterns:       │
        │  • Name (8 patterns)   │
        │  • Personal (12)       │
        │  • Address (10)        │
        │  • Phone (5)           │
        │  • Email (4)           │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Scan each file for    │
        │  pattern matches       │
        │                        │
        │  Example patterns:     │
        │  /firstName/i          │
        │  /ssn/i                │
        │  /email.*address/i     │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Collect all matches:  │
        │  • File path           │
        │  • Line number         │
        │  • Field name          │
        │  • Category            │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Generate Report:      │
        │  ✓ 45 fields found     │
        │  ✓ 12 Name fields      │
        │  ✓ 8 Personal fields   │
        │  ✓ etc.                │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  END: Display results  │
        │  in UI with export     │
        └────────────────────────┘

NO CODE LENS ML USED IN THIS PATH ❌
```

---

## PATH 2: Excel Field Scan (100% Exact Match)

```
┌─────────────────────────────────────────────────────────────┐
│ START: User uploads Excel file                              │
│ Format: table_name | field_name                             │
│ Example: CUSTOMER  | SSN                                    │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Parse Excel File      │
        │  Extract mappings:     │
        │  • CUSTOMER.SSN        │
        │  • ACCOUNT.NUMBER      │
        │  • PERSON.FIRST_NAME   │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Get project source    │
        │  files from storage    │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  For each Excel field, │
        │  search with patterns: │
        │                        │
        │  1. table.field        │
        │  2. "table"."field"    │
        │  3. SELECT field       │
        │     FROM table         │
        │  4. @Column("field")   │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Find EXACT matches    │
        │  (case-insensitive)    │
        │                        │
        │  CUSTOMER.SSN found:   │
        │  • File: Customer.java │
        │  • Line: 45            │
        │  • Match: customer.SSN │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Compile Results:      │
        │  • Total: 50 fields    │
        │  • Matched: 42         │
        │  • Unmatched: 8        │
        │  • Match %: 84%        │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  END: Display exact    │
        │  match report with     │
        │  file locations        │
        └────────────────────────┘

NO CODE LENS ML USED IN THIS PATH ❌
```

---

## PATH 2 OPTIONAL: Code Lens ML Field Suggestions

```
┌─────────────────────────────────────────────────────────────┐
│ OPTIONAL: User clicks "Get ML Suggestions" button           │
│ (Only for UNMATCHED fields from Excel scan)                 │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Get unmatched Excel   │
        │  fields:               │
        │  • SSN                 │
        │  • firstName           │
        │  • dob                 │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Extract field names   │
        │  from codebase:        │
        │  • social_security_no  │
        │  • first_name          │
        │  • dateOfBirth         │
        │  • accountNumber       │
        └────────────┬───────────┘
                     │
                     ▼
    ┌───────────────────────────────────────┐
    │   🤖 CODE LENS ML ACTIVATED 🤖        │
    │   (field_matcher_ml.py)               │
    └───────────────┬───────────────────────┘
                    │
                    ▼
        ┌────────────────────────┐
        │  Step 1: Lookup Table  │
        │  Check knowledge base: │
        │                        │
        │  SSN → lookup →        │
        │  social_security_number│
        │  ✓ MATCH (95%)         │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Step 2: Acronym Check │
        │                        │
        │  dob → check →         │
        │  dateOfBirth           │
        │  d.o.b = DOB           │
        │  ✓ MATCH (90%)         │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Step 3: Similarity    │
        │  Calculate score:      │
        │                        │
        │  firstName vs          │
        │  first_name            │
        │  Levenshtein: 60%      │
        │  Token match: 40%      │
        │  ✓ MATCH (95%)         │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Filter suggestions:   │
        │  • Confidence > 60%    │
        │  • Top 3 matches       │
        │  • Sort by score       │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Return ML Suggestions:│
        │                        │
        │  SSN →                 │
        │   • social_security_no │
        │     (95% match)        │
        │                        │
        │  firstName →           │
        │   • first_name (95%)   │
        │   • fname (85%)        │
        │                        │
        │  dob →                 │
        │   • dateOfBirth (90%)  │
        │   • birthDate (75%)    │
        └────────────┬───────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  END: Display ML       │
        │  suggestions to user   │
        │  for review/approval   │
        └────────────────────────┘

✅ CODE LENS ML USED HERE (OPTIONAL)
```

---

## Summary Table

| Feature | Path 1: Regex | Path 2: Excel Exact | Path 2 Optional: ML |
|---------|--------------|-------------------|-------------------|
| **Trigger** | Automatic | User uploads Excel | User clicks "Get Suggestions" |
| **Input** | None | Excel file | Unmatched fields |
| **Method** | 39 regex patterns | Exact string match | Code Lens ML |
| **Speed** | Fast | Fast | Fast |
| **Accuracy** | Pattern-based | 100% exact | 60-95% similarity |
| **Use ML?** | ❌ NO | ❌ NO | ✅ YES |
| **Output** | Found fields | Exact matches | Suggested matches |

---

## When Code Lens ML is Used:

✅ **Used When:**
- User has Excel file with unmatched fields
- User clicks "Get ML Suggestions" button
- System compares Excel fields vs codebase fields
- Provides smart suggestions with confidence scores

❌ **NOT Used When:**
- Running regex pattern scan (Path 1)
- Running exact match scan (Path 2)
- Scanning with default settings

---

## Code Lens ML Process (Detailed)

```
Input: 
  Excel Fields: ["SSN", "firstName", "dob"]
  Codebase Fields: ["social_security_number", "first_name", "dateOfBirth", "accountNumber"]

Step 1: Lookup Table (Knowledge-Based)
  ┌─────────────────────────────────────┐
  │ Check built-in mappings:            │
  │ SSN → [social_security_number, ...]│
  │ firstName → [first_name, ...]       │
  │ dob → [dateOfBirth, birthDate, ...] │
  └─────────────────────────────────────┘
  Result: 95% confidence matches

Step 2: Acronym Detection
  ┌─────────────────────────────────────┐
  │ Build acronyms:                     │
  │ "dob" (3 letters)                   │
  │ "dateOfBirth" → D.O.B               │
  │ Match!                              │
  └─────────────────────────────────────┘
  Result: 90% confidence matches

Step 3: Algorithmic Similarity
  ┌─────────────────────────────────────┐
  │ Calculate scores:                   │
  │ • Levenshtein distance (60%)        │
  │ • Token overlap (40%)               │
  │ Combined weighted score             │
  └─────────────────────────────────────┘
  Result: Variable confidence (0-100%)

Output:
  {
    "SSN": [
      { "field": "social_security_number", "confidence": 0.95 }
    ],
    "firstName": [
      { "field": "first_name", "confidence": 0.95 },
      { "field": "fname", "confidence": 0.85 }
    ],
    "dob": [
      { "field": "dateOfBirth", "confidence": 0.90 },
      { "field": "birthDate", "confidence": 0.75 }
    ]
  }
```

---

**Developed by: Ullas Krishnan, Sr Solution Architect**  
**Copyright © Project Diamond Zensar team**
