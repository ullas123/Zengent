/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { Switch, Route } from "wouter";
import { ReactFlowProvider } from "reactflow";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";

import LoginForm from "@/components/LoginForm";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import TermsOfUse from "@/pages/terms-of-use";
import PrivacyPolicy from "@/pages/privacy-policy";
import TermsOfService from "@/pages/TermsOfService";
import PrivacyPolicyNew from "@/pages/PrivacyPolicy";
import Profile from "@/pages/profile";
import ReadmePage from "@/pages/readme";
import KnowledgeAgent from "@/pages/knowledge-agent";
import ZenVectorAgent from "@/pages/zenvector-agent";
import MigrationPlanner from "@/pages/migration-planner";
import QualityMeasure from "@/pages/quality-measure";
import DataFlow from "@/pages/data-flow";
import CWESecurityScan from "@/pages/cwe-security-scan";
import InnersourceDocsPage from "@/pages/innersource-docs";
import ConfluenceSync from "@/pages/confluence-sync";
import PlatformArchitecture from "@/pages/platform-architecture";
import TeamBehind from "@/pages/about";
import SDLCAgent from "@/pages/sdlc-agent";
import ZenseAIPlatform from "@/pages/zenseai-platform";
import GithubConfigPage from "@/pages/github-config";
import CodeExplorerPage from "@/pages/code-explorer";
import ArtifactsExplorer from "@/pages/artifacts-explorer";
import InstallationPage from "@/pages/installation";

import Layout from "@/components/layout";

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  // Public routes (accessible without authentication)
  return (
    <Switch>
      <Route path="/terms" component={TermsOfService} />
      <Route path="/privacy" component={PrivacyPolicyNew} />
      <Route>
        {() => {
          // Show login form if not authenticated
          if (!isAuthenticated || !user) {
            return <LoginForm />;
          }
          
          // Authenticated routes
          return (
            <Switch>
              <Route path="/" component={Home} />
              <Route path="/terms-of-use" component={TermsOfUse} />
              <Route path="/privacy-policy" component={PrivacyPolicy} />
              <Route path="/profile" component={Profile} />
              <Route path="/readme">
                {() => (
                  <Layout>
                    <ReadmePage />
                  </Layout>
                )}
              </Route>
              <Route path="/knowledge-agent">
                {() => (
                  <Layout>
                    <KnowledgeAgent />
                  </Layout>
                )}
              </Route>
              <Route path="/zenvector-agent">
                {() => (
                  <Layout>
                    <ZenVectorAgent />
                  </Layout>
                )}
              </Route>
              <Route path="/projects/:id/migration-planner">
                {(params) => (
                  <Layout>
                    <MigrationPlanner />
                  </Layout>
                )}
              </Route>
              <Route path="/quality-measure">
                {() => (
                  <Layout>
                    <QualityMeasure />
                  </Layout>
                )}
              </Route>
              <Route path="/data-flow">
                {() => (
                  <Layout>
                    <DataFlow />
                  </Layout>
                )}
              </Route>
              <Route path="/cwe-security-scan">
                {() => (
                  <Layout>
                    <CWESecurityScan />
                  </Layout>
                )}
              </Route>
              <Route path="/innersource-docs">
                {() => (
                  <Layout>
                    <InnersourceDocsPage />
                  </Layout>
                )}
              </Route>
              <Route path="/confluence-sync" component={ConfluenceSync} />
              <Route path="/platform-architecture">
                {() => (
                  <Layout>
                    <PlatformArchitecture />
                  </Layout>
                )}
              </Route>
              <Route path="/about">
                {() => (
                  <Layout>
                    <TeamBehind />
                  </Layout>
                )}
              </Route>
              <Route path="/sdlc-agent">
                {() => (
                  <Layout>
                    <SDLCAgent />
                  </Layout>
                )}
              </Route>
              <Route path="/zenseai-platform">
                {() => (
                  <Layout>
                    <ReactFlowProvider>
                      <ZenseAIPlatform />
                    </ReactFlowProvider>
                  </Layout>
                )}
              </Route>
              <Route path="/github-config">
                {() => (
                  <Layout>
                    <GithubConfigPage />
                  </Layout>
                )}
              </Route>
              <Route path="/code-explorer">
                {() => (
                  <Layout>
                    <CodeExplorerPage />
                  </Layout>
                )}
              </Route>
              <Route path="/artifacts-explorer">
                {() => (
                  <Layout>
                    <ArtifactsExplorer />
                  </Layout>
                )}
              </Route>
              <Route path="/installation">
                {() => (
                  <Layout>
                    <InstallationPage />
                  </Layout>
                )}
              </Route>
              <Route component={NotFound} />
            </Switch>
          );
        }}
      </Route>
    </Switch>
  );


}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
