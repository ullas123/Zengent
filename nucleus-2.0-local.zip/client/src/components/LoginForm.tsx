/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useLogin } from '@/hooks/useAuth';
import { loginSchema } from '@shared/schema';
import type { LoginInput } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { Eye, EyeOff } from 'lucide-react';
import nucleusImage from '@assets/nuc_1764055437845_1780916496294.png';

export default function LoginForm() {
  const [showPassword, setShowPassword] = useState(false);
  const { toast } = useToast();
  
  const loginMutation = useLogin();

  const loginForm = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });

  const onLogin = async (data: LoginInput) => {
    try {
      const result = await loginMutation.mutateAsync(data);
      console.log('Login result:', result);
      if (result.success) {
        toast({
          title: "Success",
          description: "Logged in successfully!",
        });
        window.location.href = '/';
      } else {
        toast({
          title: "Error",
          description: result.message || "Login failed",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Login error:', error);
      toast({
        title: "Error",
        description: "Login failed. Please check your credentials.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen flex bg-[#4285f4]">
      {/* Left Panel - Nucleus Image Centered */}
      <div className="hidden lg:flex lg:w-1/2 items-center justify-end pr-4">
        <img 
          src={nucleusImage} 
          alt="Nucleus - Innersource Agentic SDLC Framework" 
          className="w-[420px] h-auto object-contain rounded-lg shadow-2xl"
          data-testid="img-nucleus-banner"
        />
      </div>

      {/* Right Panel - Login Form with Blue Theme */}
      <div className="flex-1 flex items-center justify-start bg-[#4285f4] pl-4 pr-8">
        <div className="w-full max-w-md">
          {/* Login Form */}
          <div className="bg-white rounded-xl shadow-2xl p-8">
            {/* Header */}
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-[#1e3a8a] mb-2">
                NUCLEUS
              </h1>
              <p className="text-sm text-gray-600">
                Innersource Agentic SDLC Framework
              </p>
            </div>

            <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-6">
              <div>
                <Label htmlFor="username" className="text-sm font-medium text-gray-700 mb-2 block">
                  Username
                </Label>
                <Input
                  id="username"
                  {...loginForm.register('username')}
                  placeholder="Enter your username"
                  disabled={loginMutation.isPending}
                  className="h-11 px-4 text-sm border-gray-300 rounded-lg focus:border-[#2563eb] focus:ring-2 focus:ring-[#2563eb]/20"
                  data-testid="input-username"
                />
                {loginForm.formState.errors.username && (
                  <p className="text-sm text-red-600 mt-1">
                    {loginForm.formState.errors.username.message}
                  </p>
                )}
              </div>
              
              <div>
                <Label htmlFor="password" className="text-sm font-medium text-gray-700 mb-2 block">
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    {...loginForm.register('password')}
                    placeholder="Enter your password"
                    disabled={loginMutation.isPending}
                    className="h-11 px-4 text-sm border-gray-300 rounded-lg focus:border-[#2563eb] focus:ring-2 focus:ring-[#2563eb]/20 pr-12"
                    data-testid="input-password"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                    data-testid="button-toggle-password"
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-400" />
                    )}
                  </Button>
                </div>
                {loginForm.formState.errors.password && (
                  <p className="text-sm text-red-600 mt-1">
                    {loginForm.formState.errors.password.message}
                  </p>
                )}
              </div>

              {/* Remember me and Forgot password */}
              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center cursor-pointer">
                  <input type="checkbox" className="mr-2 h-4 w-4 text-[#2563eb] border-gray-300 rounded focus:ring-[#2563eb]" />
                  <span className="text-gray-700">Remember me</span>
                </label>
                <a href="#" className="text-[#2563eb] hover:text-[#1e3a8a] font-medium">
                  Forgot Password?
                </a>
              </div>
              
              <Button
                type="submit"
                disabled={loginMutation.isPending}
                className="w-full h-12 text-sm font-semibold bg-[#2563eb] hover:bg-[#1e3a8a] text-white rounded-lg transition-colors duration-200 shadow-lg"
                data-testid="button-login"
              >
                {loginMutation.isPending ? "SIGNING IN..." : "LOGIN"}
              </Button>
            </form>

            {/* Footer */}
            <div className="mt-8 text-center">
              <p className="text-xs text-gray-500 mb-3">
                Prepared by Diamond Zensar Team
              </p>
              <div className="flex justify-center space-x-1 text-xs text-gray-500">
                <span>© 2026 |</span>
                <a href="/terms" className="hover:text-[#2563eb]">Terms of use</a>
                <span>|</span>
                <a href="/privacy" className="hover:text-[#2563eb]">Privacy Policy</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
