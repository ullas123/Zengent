/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { type Project } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, Loader2, Circle } from "lucide-react";

interface ProcessingSectionProps {
  project: Project;
  projectType?: 'java' | 'mainframe' | 'python' | 'pyspark' | 'csharp' | 'kotlin' | string;
}

const getProcessingMessages = (projectType?: string) => {
  switch (projectType) {
    case 'mainframe':
      return {
        title: 'Analyzing COBOL/Mainframe Project',
        subtitle: 'Analyzing COBOL source files and extracting mainframe architectural information...',
        steps: [
          { label: 'Extracting project contents', status: 'complete' },
          { label: 'Parsing COBOL source files', status: 'complete' },
          { label: 'Analyzing JCL, COPYBOOK, and library structures', status: 'loading' },
          { label: 'Mapping IMS/DB2 relationships and data flows', status: 'pending' },
        ]
      };
    case 'python':
      return {
        title: 'Analyzing Python Project',
        subtitle: 'Analyzing Python source files and extracting framework patterns...',
        steps: [
          { label: 'Extracting project contents', status: 'complete' },
          { label: 'Parsing Python source files', status: 'complete' },
          { label: 'Analyzing Django/Flask patterns', status: 'loading' },
          { label: 'Generating dependency diagrams', status: 'pending' },
        ]
      };
    case 'pyspark':
      return {
        title: 'Analyzing PySpark Project',
        subtitle: 'Analyzing PySpark pipelines and Spark job configurations...',
        steps: [
          { label: 'Extracting project contents', status: 'complete' },
          { label: 'Parsing PySpark source files', status: 'complete' },
          { label: 'Analyzing DataFrame transformations', status: 'loading' },
          { label: 'Generating data pipeline diagrams', status: 'pending' },
        ]
      };
    case 'csharp':
      return {
        title: 'Analyzing C# Project',
        subtitle: 'Analyzing C# source files and .NET framework patterns...',
        steps: [
          { label: 'Extracting project contents', status: 'complete' },
          { label: 'Parsing C# source files', status: 'complete' },
          { label: 'Analyzing Entity Framework and MVC patterns', status: 'loading' },
          { label: 'Generating architecture diagrams', status: 'pending' },
        ]
      };
    case 'kotlin':
      return {
        title: 'Analyzing Kotlin Project',
        subtitle: 'Analyzing Kotlin source files and Android/JVM patterns...',
        steps: [
          { label: 'Extracting project contents', status: 'complete' },
          { label: 'Parsing Kotlin source files', status: 'complete' },
          { label: 'Analyzing coroutines and framework patterns', status: 'loading' },
          { label: 'Generating architecture diagrams', status: 'pending' },
        ]
      };
    case 'java':
    default:
      return {
        title: 'Analyzing Java Project',
        subtitle: 'Analyzing Java source files and extracting architectural information...',
        steps: [
          { label: 'Extracting ZIP contents', status: 'complete' },
          { label: 'Parsing Java source files', status: 'complete' },
          { label: 'Analyzing annotations and patterns', status: 'loading' },
          { label: 'Generating diagrams', status: 'pending' },
        ]
      };
  }
};

export default function ProcessingSection({ project, projectType }: ProcessingSectionProps) {
  const messages = getProcessingMessages(projectType);
  
  return (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardContent className="p-8">
          <div className="text-center">
            <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Loader2 className="text-2xl text-primary animate-spin-slow w-8 h-8" />
            </div>
            <h2 className="text-xl font-medium text-foreground mb-2">{messages.title}</h2>
            <p className="text-muted-foreground mb-6">
              {messages.subtitle}
            </p>
            
            <div className="w-full mb-6">
              <Progress value={65} className="h-2" />
            </div>
            
            <div className="text-left max-w-md mx-auto space-y-2">
              {messages.steps.map((step, index) => (
                <div key={index} className="flex items-center text-sm">
                  {step.status === 'complete' && (
                    <CheckCircle className="text-accent mr-3 w-4 h-4" />
                  )}
                  {step.status === 'loading' && (
                    <Loader2 className="text-primary mr-3 animate-spin w-4 h-4" />
                  )}
                  {step.status === 'pending' && (
                    <Circle className="mr-3 text-xs w-4 h-4 text-muted-foreground" />
                  )}
                  <span className={step.status === 'pending' ? 'text-muted-foreground' : 'text-muted-foreground'}>
                    {step.label}
                  </span>
                </div>
              ))}
            </div>
            
            <Button variant="ghost" className="mt-6 text-muted-foreground hover:text-foreground">
              Cancel Analysis
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
