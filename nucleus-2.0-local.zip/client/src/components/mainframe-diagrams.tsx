/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import cytoscape, { Core, ElementDefinition } from 'cytoscape';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Network, 
  GitBranch, 
  Database, 
  FileText, 
  Layers,
  ZoomIn,
  ZoomOut,
  Maximize,
  Download,
  AlertTriangle,
  Server,
  HardDrive,
  ArrowRight
} from 'lucide-react';
import type { AnalysisData } from '@shared/schema';

interface MainframeDiagramsProps {
  analysisData: AnalysisData;
}

interface DiagramNode {
  id: string;
  label: string;
  type: string;
  subtype?: string;
  fanIn?: number;
  fanOut?: number;
  crud?: string;
}

interface DiagramEdge {
  source: string;
  target: string;
  type: string;
  label?: string;
}

const nodeColors: Record<string, string> = {
  'batch': '#3B82F6',
  'online': '#10B981', 
  'program': '#6366F1',
  'copybook': '#8B5CF6',
  'jcl': '#F59E0B',
  'db2': '#EF4444',
  'vsam': '#EC4899',
  'qsam': '#14B8A6',
  'dataset': '#F97316',
  'transaction': '#06B6D4',
  'step': '#84CC16',
  'job': '#FBBF24',
  'table': '#DC2626',
  'impacted': '#EF4444',
  'source': '#3B82F6',
};

export default function MainframeDiagrams({ analysisData }: MainframeDiagramsProps) {
  const [activeTab, setActiveTab] = useState('inventory');
  const [selectedNode, setSelectedNode] = useState<DiagramNode | null>(null);
  const cyRef = useRef<Core | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const programs = analysisData.classes.filter(c => c.type === 'program');
  const copybooks = analysisData.classes.filter(c => c.type === 'copybook');
  const jclJobs = analysisData.classes.filter(c => c.type === 'jcl');

  const getInventoryMapData = useCallback(() => {
    const nodes: ElementDefinition[] = [];
    const edges: ElementDefinition[] = [];
    
    const batchPrograms = programs.filter(p => 
      p.programType === 'batch' || (!p.cicsCommands?.length && !p.imsCommands?.length)
    );
    const onlinePrograms = programs.filter(p => 
      p.programType === 'online-cics' || p.programType === 'online-ims' ||
      p.cicsCommands?.length || p.imsCommands?.length
    );
    
    nodes.push({
      data: { id: 'batch-region', label: `Batch Region\n(${batchPrograms.length} programs)`, type: 'batch' }
    });
    nodes.push({
      data: { id: 'online-region', label: `Online Region\n(${onlinePrograms.length} programs)`, type: 'online' }
    });
    
    const allDb2Tables = new Set<string>();
    const allVsamDatasets = new Set<string>();
    programs.forEach(p => {
      p.db2Tables?.forEach(t => allDb2Tables.add(t));
      p.vsamDatasets?.forEach(d => allVsamDatasets.add(d));
    });
    
    if (allDb2Tables.size > 0) {
      nodes.push({
        data: { id: 'db2-store', label: `DB2 Tables\n(${allDb2Tables.size})`, type: 'db2' }
      });
    }
    if (allVsamDatasets.size > 0) {
      nodes.push({
        data: { id: 'vsam-store', label: `VSAM Datasets\n(${allVsamDatasets.size})`, type: 'vsam' }
      });
    }
    
    batchPrograms.slice(0, 8).forEach((prog, idx) => {
      nodes.push({
        data: { id: `batch-${idx}`, label: prog.name, type: 'program', parent: 'batch-region' }
      });
      if (prog.db2Tables?.length) {
        edges.push({
          data: { id: `batch-${idx}-db2`, source: `batch-${idx}`, target: 'db2-store', type: 'access' }
        });
      }
      if (prog.vsamDatasets?.length) {
        edges.push({
          data: { id: `batch-${idx}-vsam`, source: `batch-${idx}`, target: 'vsam-store', type: 'access' }
        });
      }
    });
    
    onlinePrograms.slice(0, 8).forEach((prog, idx) => {
      nodes.push({
        data: { id: `online-${idx}`, label: prog.name, type: 'program', parent: 'online-region' }
      });
      if (prog.db2Tables?.length) {
        edges.push({
          data: { id: `online-${idx}-db2`, source: `online-${idx}`, target: 'db2-store', type: 'access' }
        });
      }
      if (prog.vsamDatasets?.length) {
        edges.push({
          data: { id: `online-${idx}-vsam`, source: `online-${idx}`, target: 'vsam-store', type: 'access' }
        });
      }
    });
    
    edges.push({
      data: { id: 'batch-online', source: 'batch-region', target: 'online-region', type: 'interface' }
    });
    
    return { nodes, edges };
  }, [programs]);

  const getCallGraphData = useCallback(() => {
    const nodes: ElementDefinition[] = [];
    const edges: ElementDefinition[] = [];
    const nodeMap = new Map<string, number>();
    
    programs.forEach(prog => {
      const fanIn = analysisData.relationships.filter(r => r.to === prog.name).length;
      const fanOut = analysisData.relationships.filter(r => r.from === prog.name).length;
      nodeMap.set(prog.name, fanIn);
      
      nodes.push({
        data: { 
          id: prog.name, 
          label: `${prog.name}\n(in:${fanIn} out:${fanOut})`,
          type: fanIn > 3 ? 'impacted' : 'program',
          fanIn,
          fanOut
        }
      });
    });
    
    analysisData.relationships
      .filter(r => r.type === 'CALL' || r.type === 'calls')
      .forEach((rel, idx) => {
        edges.push({
          data: { 
            id: `call-${idx}`, 
            source: rel.from, 
            target: rel.to, 
            type: 'call',
            label: 'CALL'
          }
        });
      });
    
    return { nodes, edges };
  }, [programs, analysisData.relationships]);

  const getJclFlowData = useCallback(() => {
    const nodes: ElementDefinition[] = [];
    const edges: ElementDefinition[] = [];
    
    jclJobs.slice(0, 5).forEach((job, jobIdx) => {
      nodes.push({
        data: { id: `job-${jobIdx}`, label: job.name, type: 'job' }
      });
      
      job.methods?.slice(0, 4).forEach((step, stepIdx) => {
        const stepId = `step-${jobIdx}-${stepIdx}`;
        nodes.push({
          data: { id: stepId, label: step.name, type: 'step' }
        });
        edges.push({
          data: { id: `job-step-${jobIdx}-${stepIdx}`, source: `job-${jobIdx}`, target: stepId, type: 'executes' }
        });
        
        const matchingProg = programs.find(p => 
          step.name.toUpperCase().includes(p.name.toUpperCase()) ||
          p.name.toUpperCase().includes(step.name.toUpperCase())
        );
        if (matchingProg) {
          const progId = `prog-${jobIdx}-${stepIdx}`;
          nodes.push({
            data: { id: progId, label: matchingProg.name, type: 'program' }
          });
          edges.push({
            data: { id: `step-prog-${jobIdx}-${stepIdx}`, source: stepId, target: progId, type: 'calls' }
          });
        }
      });
    });
    
    return { nodes, edges };
  }, [jclJobs, programs]);

  const getDb2TouchpointData = useCallback(() => {
    const nodes: ElementDefinition[] = [];
    const edges: ElementDefinition[] = [];
    const tableUsage = new Map<string, { programs: string[]; crud: Set<string> }>();
    
    programs.forEach(prog => {
      prog.db2Tables?.forEach(table => {
        if (!tableUsage.has(table)) {
          tableUsage.set(table, { programs: [], crud: new Set() });
        }
        tableUsage.get(table)!.programs.push(prog.name);
        tableUsage.get(table)!.crud.add('SELECT');
      });
    });
    
    Array.from(tableUsage.entries()).slice(0, 10).forEach(([table, usage], idx) => {
      const heat = usage.programs.length;
      nodes.push({
        data: { 
          id: `table-${idx}`, 
          label: `${table}\n(${heat} programs)`,
          type: heat > 3 ? 'impacted' : 'table',
          heat
        }
      });
      
      usage.programs.slice(0, 3).forEach((prog, pIdx) => {
        const progId = `prog-${idx}-${pIdx}`;
        if (!nodes.find(n => n.data.id === progId)) {
          nodes.push({
            data: { id: progId, label: prog, type: 'program' }
          });
        }
        edges.push({
          data: { 
            id: `access-${idx}-${pIdx}`, 
            source: progId, 
            target: `table-${idx}`, 
            type: 'crud',
            label: Array.from(usage.crud).join('/')
          }
        });
      });
    });
    
    return { nodes, edges };
  }, [programs]);

  const getImpactAnalysisData = useCallback(() => {
    const nodes: ElementDefinition[] = [];
    const edges: ElementDefinition[] = [];
    
    if (programs.length === 0) return { nodes, edges };
    
    const sourceProgram = programs[0];
    nodes.push({
      data: { id: 'source', label: `${sourceProgram.name}\n(SOURCE)`, type: 'source' }
    });
    
    const directlyImpacted = analysisData.relationships
      .filter(r => r.to === sourceProgram.name || r.from === sourceProgram.name)
      .slice(0, 8);
    
    directlyImpacted.forEach((rel, idx) => {
      const impactedName = rel.from === sourceProgram.name ? rel.to : rel.from;
      const impactedId = `impacted-${idx}`;
      nodes.push({
        data: { id: impactedId, label: `${impactedName}\n(IMPACTED)`, type: 'impacted' }
      });
      edges.push({
        data: { 
          id: `impact-${idx}`, 
          source: 'source', 
          target: impactedId, 
          type: rel.from === sourceProgram.name ? 'downstream' : 'upstream'
        }
      });
    });
    
    copybooks.slice(0, 4).forEach((cb, idx) => {
      if (sourceProgram.dependencies?.includes(cb.name)) {
        nodes.push({
          data: { id: `cb-${idx}`, label: `${cb.name}\n(COPYBOOK)`, type: 'copybook' }
        });
        edges.push({
          data: { id: `cb-impact-${idx}`, source: 'source', target: `cb-${idx}`, type: 'uses' }
        });
      }
    });
    
    return { nodes, edges };
  }, [programs, copybooks, analysisData.relationships]);

  const getDatasetLineageData = useCallback(() => {
    const nodes: ElementDefinition[] = [];
    const edges: ElementDefinition[] = [];
    
    const datasets = new Set<string>();
    programs.forEach(prog => {
      prog.vsamDatasets?.forEach(ds => datasets.add(ds));
    });
    
    Array.from(datasets).slice(0, 6).forEach((ds, idx) => {
      nodes.push({
        data: { id: `ds-${idx}`, label: ds, type: 'dataset' }
      });
    });
    
    jclJobs.slice(0, 4).forEach((job, jobIdx) => {
      nodes.push({
        data: { id: `job-${jobIdx}`, label: job.name, type: 'job' }
      });
      
      const dsIdx = jobIdx % Math.max(datasets.size, 1);
      if (datasets.size > 0) {
        edges.push({
          data: { 
            id: `produce-${jobIdx}`, 
            source: `job-${jobIdx}`, 
            target: `ds-${dsIdx}`, 
            type: 'produces',
            label: 'PRODUCES'
          }
        });
        if (dsIdx + 1 < datasets.size) {
          edges.push({
            data: { 
              id: `consume-${jobIdx}`, 
              source: `ds-${dsIdx + 1}`, 
              target: `job-${jobIdx}`, 
              type: 'consumes',
              label: 'CONSUMES'
            }
          });
        }
      }
    });
    
    return { nodes, edges };
  }, [programs, jclJobs]);

  const initCytoscape = useCallback((data: { nodes: ElementDefinition[]; edges: ElementDefinition[] }) => {
    if (!containerRef.current || data.nodes.length === 0) return;
    
    if (cyRef.current) {
      cyRef.current.destroy();
    }
    
    cyRef.current = cytoscape({
      container: containerRef.current,
      elements: [...data.nodes, ...data.edges],
      style: [
        {
          selector: 'node',
          style: {
            'label': 'data(label)',
            'text-valign': 'center',
            'text-halign': 'center',
            'background-color': (ele: any) => nodeColors[ele.data('type')] || '#6B7280',
            'color': '#fff',
            'text-outline-color': '#000',
            'text-outline-width': 1,
            'font-size': '10px',
            'width': 80,
            'height': 80,
            'text-wrap': 'wrap',
            'text-max-width': '70px',
            'border-width': 2,
            'border-color': '#fff'
          }
        },
        {
          selector: 'node[type="impacted"]',
          style: {
            'border-color': '#EF4444',
            'border-width': 4
          }
        },
        {
          selector: 'node[type="source"]',
          style: {
            'width': 100,
            'height': 100,
            'border-color': '#3B82F6',
            'border-width': 4
          }
        },
        {
          selector: 'edge',
          style: {
            'width': 2,
            'line-color': '#94A3B8',
            'target-arrow-color': '#94A3B8',
            'target-arrow-shape': 'triangle',
            'curve-style': 'bezier',
            'label': 'data(label)',
            'font-size': '8px',
            'text-rotation': 'autorotate',
            'text-background-color': '#fff',
            'text-background-opacity': 0.8,
            'text-background-padding': '2px'
          }
        },
        {
          selector: 'edge[type="call"]',
          style: { 'line-color': '#6366F1', 'target-arrow-color': '#6366F1' }
        },
        {
          selector: 'edge[type="crud"]',
          style: { 'line-color': '#EF4444', 'target-arrow-color': '#EF4444' }
        },
        {
          selector: 'edge[type="produces"]',
          style: { 'line-color': '#10B981', 'target-arrow-color': '#10B981' }
        },
        {
          selector: 'edge[type="consumes"]',
          style: { 'line-color': '#F59E0B', 'target-arrow-color': '#F59E0B' }
        }
      ],
      layout: {
        name: 'cose',
        animate: false,
        nodeDimensionsIncludeLabels: true,
        idealEdgeLength: () => 150,
        nodeRepulsion: () => 8000,
        padding: 50
      }
    });
    
    cyRef.current.on('tap', 'node', (evt: any) => {
      const node = evt.target;
      setSelectedNode({
        id: node.id(),
        label: node.data('label'),
        type: node.data('type'),
        fanIn: node.data('fanIn'),
        fanOut: node.data('fanOut')
      });
    });
    
    cyRef.current.on('tap', (evt: any) => {
      if (evt.target === cyRef.current) {
        setSelectedNode(null);
      }
    });
  }, []);

  useEffect(() => {
    let data;
    switch (activeTab) {
      case 'inventory':
        data = getInventoryMapData();
        break;
      case 'callgraph':
        data = getCallGraphData();
        break;
      case 'jclflow':
        data = getJclFlowData();
        break;
      case 'db2crud':
        data = getDb2TouchpointData();
        break;
      case 'impact':
        data = getImpactAnalysisData();
        break;
      case 'lineage':
        data = getDatasetLineageData();
        break;
      default:
        data = { nodes: [], edges: [] };
    }
    
    setTimeout(() => initCytoscape(data), 100);
  }, [activeTab, initCytoscape, getInventoryMapData, getCallGraphData, getJclFlowData, getDb2TouchpointData, getImpactAnalysisData, getDatasetLineageData]);

  const handleZoom = (direction: 'in' | 'out') => {
    if (cyRef.current) {
      const currentZoom = cyRef.current.zoom();
      cyRef.current.zoom(direction === 'in' ? currentZoom * 1.2 : currentZoom / 1.2);
    }
  };

  const handleFit = () => {
    if (cyRef.current) {
      cyRef.current.fit(undefined, 50);
    }
  };

  const handleExport = () => {
    if (cyRef.current) {
      const png = cyRef.current.png({ scale: 2, bg: '#fff' });
      const link = document.createElement('a');
      link.href = png;
      link.download = `${activeTab}-diagram.png`;
      link.click();
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Network className="w-5 h-5 text-blue-600" />
          Mainframe Application Diagrams
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-6 w-full">
            <TabsTrigger value="inventory" className="text-xs">
              <Layers className="w-3 h-3 mr-1" />
              Inventory
            </TabsTrigger>
            <TabsTrigger value="callgraph" className="text-xs">
              <GitBranch className="w-3 h-3 mr-1" />
              CALL Graph
            </TabsTrigger>
            <TabsTrigger value="jclflow" className="text-xs">
              <Server className="w-3 h-3 mr-1" />
              JCL Flow
            </TabsTrigger>
            <TabsTrigger value="db2crud" className="text-xs">
              <Database className="w-3 h-3 mr-1" />
              DB2 CRUD
            </TabsTrigger>
            <TabsTrigger value="impact" className="text-xs">
              <AlertTriangle className="w-3 h-3 mr-1" />
              Impact
            </TabsTrigger>
            <TabsTrigger value="lineage" className="text-xs">
              <HardDrive className="w-3 h-3 mr-1" />
              Lineage
            </TabsTrigger>
          </TabsList>

          <div className="flex items-center justify-between py-2">
            <div className="flex gap-1">
              <Button variant="outline" size="sm" onClick={() => handleZoom('in')}>
                <ZoomIn className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={() => handleZoom('out')}>
                <ZoomOut className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleFit}>
                <Maximize className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleExport}>
                <Download className="w-4 h-4" />
              </Button>
            </div>
            
            {selectedNode && (
              <div className="flex items-center gap-2 text-sm">
                <Badge variant="outline" style={{ backgroundColor: nodeColors[selectedNode.type] + '20' }}>
                  {selectedNode.type}
                </Badge>
                <span className="font-medium">{selectedNode.id}</span>
                {selectedNode.fanIn !== undefined && (
                  <span className="text-muted-foreground">
                    Fan-In: {selectedNode.fanIn} | Fan-Out: {selectedNode.fanOut}
                  </span>
                )}
              </div>
            )}
          </div>

          <div 
            ref={containerRef} 
            className="w-full h-[450px] border rounded-lg bg-gray-50"
          />

          <div className="flex flex-wrap gap-2 mt-3">
            <div className="flex items-center gap-1 text-xs">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.batch }} />
              <span>Batch</span>
            </div>
            <div className="flex items-center gap-1 text-xs">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.online }} />
              <span>Online</span>
            </div>
            <div className="flex items-center gap-1 text-xs">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.program }} />
              <span>Program</span>
            </div>
            <div className="flex items-center gap-1 text-xs">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.db2 }} />
              <span>DB2</span>
            </div>
            <div className="flex items-center gap-1 text-xs">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.vsam }} />
              <span>VSAM</span>
            </div>
            <div className="flex items-center gap-1 text-xs">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.job }} />
              <span>JCL Job</span>
            </div>
            <div className="flex items-center gap-1 text-xs">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.impacted }} />
              <span>High Impact</span>
            </div>
          </div>
        </Tabs>
      </CardContent>
    </Card>
  );
}
