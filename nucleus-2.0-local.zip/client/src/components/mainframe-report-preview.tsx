/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, X, Terminal, FileCode, Database, GitBranch, Layers, Network, Bot, CheckCircle2, AlertTriangle, Server, HardDrive, Boxes } from "lucide-react";
import type { Project, AnalysisData } from "@shared/schema";
import { htmlExportService } from "@/services/htmlExportService";
import FormattedAIContent from "./formatted-ai-content";
import mermaid from 'mermaid';

mermaid.initialize({
  startOnLoad: false,
  theme: 'default',
  securityLevel: 'loose',
  flowchart: {
    htmlLabels: true,
    curve: 'basis'
  }
});

interface MainframeReportPreviewProps {
  open: boolean;
  onClose: () => void;
  project: Project;
  enrichmentData?: {
    fileStatuses: Record<string, { status: string; description?: string }>;
    totalFiles: number;
    completedFiles: number;
  } | null;
}

export default function MainframeReportPreview({
  open,
  onClose,
  project,
  enrichmentData
}: MainframeReportPreviewProps) {
  const [isExportingPDF, setIsExportingPDF] = useState(false);
  const [isExportingDOC, setIsExportingDOC] = useState(false);
  const [callGraphSvg, setCallGraphSvg] = useState<string>('');
  const [copyGraphSvg, setCopyGraphSvg] = useState<string>('');

  const analysisData = project.analysisData as AnalysisData | null;
  const aiInsights = analysisData?.aiAnalysis;
  const projectDetails = aiInsights?.projectDetails;

  const programs = analysisData?.classes.filter(c => c.type === 'program') || [];
  const copybooks = analysisData?.classes.filter(c => c.type === 'copybook') || [];
  const jclJobs = analysisData?.classes.filter(c => c.type === 'jcl') || [];
  const procedures = analysisData?.classes.filter(c => c.type === 'procedure') || [];
  const datalibs = analysisData?.classes.filter(c => c.type === 'datalib') || [];

  const callRelationships = analysisData?.relationships.filter(r => r.type === 'CALL') || [];
  const copyRelationships = analysisData?.relationships.filter(r => r.type === 'COPY') || [];
  const execRelationships = analysisData?.relationships.filter(r => r.type === 'EXEC') || [];

  const completedAnalyses = enrichmentData?.fileStatuses 
    ? Object.entries(enrichmentData.fileStatuses).filter(([_, status]) => status.status === 'completed' && status.description)
    : [];

  useEffect(() => {
    if (open && callRelationships.length > 0) {
      generateCallGraph();
    }
    if (open && copyRelationships.length > 0) {
      generateCopyGraph();
    }
  }, [open, callRelationships.length, copyRelationships.length]);

  const generateCallGraph = async () => {
    try {
      const uniquePrograms = new Set<string>();
      callRelationships.slice(0, 20).forEach(rel => {
        uniquePrograms.add(rel.from);
        uniquePrograms.add(rel.to);
      });

      let mermaidCode = 'flowchart TD\n';
      callRelationships.slice(0, 20).forEach((rel, idx) => {
        const fromId = rel.from.replace(/[^a-zA-Z0-9]/g, '_');
        const toId = rel.to.replace(/[^a-zA-Z0-9]/g, '_');
        mermaidCode += `  ${fromId}[${rel.from}] -->|CALL| ${toId}[${rel.to}]\n`;
      });

      mermaidCode += '\n  classDef program fill:#e8d5e8,stroke:#9c27b0\n';
      mermaidCode += '  classDef default fill:#f3e5f5,stroke:#7b1fa2\n';

      const { svg } = await mermaid.render('callgraph-' + Date.now(), mermaidCode);
      setCallGraphSvg(svg);
    } catch (error) {
      console.error('Failed to generate call graph:', error);
    }
  };

  const generateCopyGraph = async () => {
    try {
      let mermaidCode = 'flowchart LR\n';
      copyRelationships.slice(0, 15).forEach((rel, idx) => {
        const fromId = rel.from.replace(/[^a-zA-Z0-9]/g, '_');
        const toId = rel.to.replace(/[^a-zA-Z0-9]/g, '_');
        mermaidCode += `  ${fromId}[${rel.from}] -->|COPY| ${toId}((${rel.to}))\n`;
      });

      mermaidCode += '\n  classDef copybook fill:#e3f2fd,stroke:#1976d2\n';

      const { svg } = await mermaid.render('copygraph-' + Date.now(), mermaidCode);
      setCopyGraphSvg(svg);
    } catch (error) {
      console.error('Failed to generate copy graph:', error);
    }
  };

  const handlePDFExport = async () => {
    setIsExportingPDF(true);
    try {
      const timestamp = new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
      const filename = `${project.name.replace(/\s+/g, '-')}-Mainframe-Report-${timestamp}.pdf`;
      await htmlExportService.exportToPDF('mainframe-report-content', filename);
    } catch (error) {
      console.error('PDF export failed:', error);
      alert('PDF export failed. Please try again.');
    } finally {
      setIsExportingPDF(false);
    }
  };

  const handleDOCExport = async () => {
    setIsExportingDOC(true);
    try {
      const timestamp = new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
      const filename = `${project.name.replace(/\s+/g, '-')}-Mainframe-Report-${timestamp}.docx`;
      await htmlExportService.exportToDOCX('mainframe-report-content', filename);
    } catch (error) {
      console.error('Word export failed:', error);
      alert('Word export failed. Please try again.');
    } finally {
      setIsExportingDOC(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] p-0">
        <DialogHeader className="px-6 pt-6 pb-4 border-b bg-gradient-to-r from-violet-50 to-purple-50">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl flex items-center gap-2">
              <Terminal className="w-6 h-6 text-violet-600" />
              Mainframe Analysis Report
            </DialogTitle>
            <div className="flex items-center gap-2">
              <Button
                onClick={handleDOCExport}
                disabled={isExportingDOC}
                className="bg-blue-600 hover:bg-blue-700"
                size="sm"
              >
                <FileText className="w-4 h-4 mr-2" />
                {isExportingDOC ? 'Exporting...' : 'Export to Word'}
              </Button>
              <Button
                onClick={handlePDFExport}
                disabled={isExportingPDF}
                className="bg-red-600 hover:bg-red-700"
                size="sm"
              >
                <Download className="w-4 h-4 mr-2" />
                {isExportingPDF ? 'Exporting...' : 'Export to PDF'}
              </Button>
              <Button onClick={onClose} variant="ghost" size="sm">
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>
        
        <ScrollArea className="flex-1 px-6 pb-6">
          <div id="mainframe-report-content" className="prose prose-sm dark:prose-invert max-w-none py-6">
            {/* Cover Section */}
            <div className="text-center mb-12 pb-8 border-b-2 border-violet-200">
              <div className="flex justify-center mb-4">
                <div className="p-4 bg-violet-600 rounded-2xl">
                  <Terminal className="w-12 h-12 text-white" />
                </div>
              </div>
              <h1 className="text-4xl font-bold text-violet-800 mb-2">{project.name}</h1>
              <p className="text-xl text-violet-600 mb-2">Mainframe COBOL Application Analysis Report</p>
              <p className="text-sm text-gray-500">
                Generated: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()}
              </p>
              <p className="text-sm text-violet-500 mt-2">
                Powered by Nucleus - Innersource Agentic SDLC Framework
              </p>
            </div>

            {/* Executive Summary */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4 text-violet-800 flex items-center gap-2">
                <CheckCircle2 className="w-6 h-6" />
                1. Executive Summary
              </h2>
              <div className="bg-gradient-to-r from-violet-50 to-purple-50 p-6 rounded-xl border border-violet-200">
                {projectDetails?.projectDescription ? (
                  <p className="text-gray-700 leading-relaxed">{projectDetails.projectDescription}</p>
                ) : (
                  <p className="text-gray-700 leading-relaxed">
                    This mainframe COBOL application consists of {programs.length} programs, {copybooks.length} copybooks, 
                    and {jclJobs.length} JCL jobs. The analysis provides comprehensive documentation of the application 
                    architecture, data flows, and business logic implementation.
                  </p>
                )}
              </div>
            </section>

            {/* Application Statistics */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4 text-violet-800 flex items-center gap-2">
                <Boxes className="w-6 h-6" />
                2. Application Statistics
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center p-4 bg-violet-50 rounded-lg border border-violet-200">
                  <div className="text-3xl font-bold text-violet-600">{programs.length}</div>
                  <div className="text-sm text-gray-600 font-medium">COBOL Programs</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="text-3xl font-bold text-blue-600">{copybooks.length}</div>
                  <div className="text-sm text-gray-600 font-medium">Copybooks</div>
                </div>
                <div className="text-center p-4 bg-amber-50 rounded-lg border border-amber-200">
                  <div className="text-3xl font-bold text-amber-600">{jclJobs.length}</div>
                  <div className="text-sm text-gray-600 font-medium">JCL Jobs</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="text-3xl font-bold text-green-600">{procedures.length}</div>
                  <div className="text-sm text-gray-600 font-medium">Procedures</div>
                </div>
              </div>

              {/* Dependency Statistics */}
              <h3 className="text-lg font-semibold mb-3 text-gray-700">Dependency Statistics</h3>
              <table className="w-full border-collapse border border-gray-300 mb-6">
                <thead>
                  <tr className="bg-violet-100">
                    <th className="border border-gray-300 px-4 py-2 text-left">Relationship Type</th>
                    <th className="border border-gray-300 px-4 py-2 text-center">Count</th>
                    <th className="border border-gray-300 px-4 py-2 text-left">Description</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-gray-300 px-4 py-2 font-medium">CALL Statements</td>
                    <td className="border border-gray-300 px-4 py-2 text-center font-bold text-violet-600">{callRelationships.length}</td>
                    <td className="border border-gray-300 px-4 py-2 text-sm text-gray-600">Program-to-program calls</td>
                  </tr>
                  <tr className="bg-gray-50">
                    <td className="border border-gray-300 px-4 py-2 font-medium">COPY Statements</td>
                    <td className="border border-gray-300 px-4 py-2 text-center font-bold text-blue-600">{copyRelationships.length}</td>
                    <td className="border border-gray-300 px-4 py-2 text-sm text-gray-600">Copybook inclusions</td>
                  </tr>
                  <tr>
                    <td className="border border-gray-300 px-4 py-2 font-medium">EXEC Statements</td>
                    <td className="border border-gray-300 px-4 py-2 text-center font-bold text-amber-600">{execRelationships.length}</td>
                    <td className="border border-gray-300 px-4 py-2 text-sm text-gray-600">JCL program executions</td>
                  </tr>
                </tbody>
              </table>

              {/* Technical Stack */}
              <h3 className="text-lg font-semibold mb-3 text-gray-700">Technical Stack</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-xs text-gray-500 uppercase font-semibold mb-1">Language</div>
                  <div className="text-sm font-medium text-gray-800">COBOL</div>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-xs text-gray-500 uppercase font-semibold mb-1">Platform</div>
                  <div className="text-sm font-medium text-gray-800">IBM Mainframe (z/OS)</div>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-xs text-gray-500 uppercase font-semibold mb-1">Job Control</div>
                  <div className="text-sm font-medium text-gray-800">JCL (Job Control Language)</div>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-xs text-gray-500 uppercase font-semibold mb-1">Data Access</div>
                  <div className="text-sm font-medium text-gray-800">VSAM, Sequential Files, DB2</div>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-xs text-gray-500 uppercase font-semibold mb-1">Transaction Processing</div>
                  <div className="text-sm font-medium text-gray-800">CICS / IMS</div>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-xs text-gray-500 uppercase font-semibold mb-1">Code Reuse</div>
                  <div className="text-sm font-medium text-gray-800">Copybooks ({copybooks.length})</div>
                </div>
              </div>
            </section>

            {/* Program Inventory */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4 text-violet-800 flex items-center gap-2">
                <FileCode className="w-6 h-6" />
                3. Program Inventory
              </h2>
              
              {programs.length > 0 && (
                <>
                  <h3 className="text-lg font-semibold mb-3 text-gray-700">COBOL Programs ({programs.length})</h3>
                  <table className="w-full border-collapse border border-gray-300 mb-6">
                    <thead>
                      <tr className="bg-violet-100">
                        <th className="border border-gray-300 px-4 py-2 text-left">Program Name</th>
                        <th className="border border-gray-300 px-4 py-2 text-center">Paragraphs</th>
                        <th className="border border-gray-300 px-4 py-2 text-center">Fields</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Location</th>
                      </tr>
                    </thead>
                    <tbody>
                      {programs.slice(0, 25).map((prog, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? '' : 'bg-gray-50'}>
                          <td className="border border-gray-300 px-4 py-2 font-medium">{prog.name}</td>
                          <td className="border border-gray-300 px-4 py-2 text-center">{prog.methods?.length || 0}</td>
                          <td className="border border-gray-300 px-4 py-2 text-center">{prog.fields?.length || 0}</td>
                          <td className="border border-gray-300 px-4 py-2 text-sm text-gray-600">{prog.package || '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {programs.length > 25 && (
                    <p className="text-sm text-gray-500 mb-4">... and {programs.length - 25} more programs</p>
                  )}
                </>
              )}

              {copybooks.length > 0 && (
                <>
                  <h3 className="text-lg font-semibold mb-3 text-gray-700">Copybooks ({copybooks.length})</h3>
                  <table className="w-full border-collapse border border-gray-300 mb-6">
                    <thead>
                      <tr className="bg-blue-100">
                        <th className="border border-gray-300 px-4 py-2 text-left">Copybook Name</th>
                        <th className="border border-gray-300 px-4 py-2 text-center">Fields Defined</th>
                        <th className="border border-gray-300 px-4 py-2 text-center">Used By</th>
                      </tr>
                    </thead>
                    <tbody>
                      {copybooks.slice(0, 20).map((cb, idx) => {
                        const usedByCount = copyRelationships.filter(r => r.to === cb.name).length;
                        return (
                          <tr key={idx} className={idx % 2 === 0 ? '' : 'bg-gray-50'}>
                            <td className="border border-gray-300 px-4 py-2 font-medium">{cb.name}</td>
                            <td className="border border-gray-300 px-4 py-2 text-center">{cb.fields?.length || 0}</td>
                            <td className="border border-gray-300 px-4 py-2 text-center">{usedByCount} programs</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  {copybooks.length > 20 && (
                    <p className="text-sm text-gray-500 mb-4">... and {copybooks.length - 20} more copybooks</p>
                  )}
                </>
              )}

              {jclJobs.length > 0 && (
                <>
                  <h3 className="text-lg font-semibold mb-3 text-gray-700">JCL Jobs ({jclJobs.length})</h3>
                  <table className="w-full border-collapse border border-gray-300 mb-6">
                    <thead>
                      <tr className="bg-amber-100">
                        <th className="border border-gray-300 px-4 py-2 text-left">Job Name</th>
                        <th className="border border-gray-300 px-4 py-2 text-center">Steps</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Programs Executed</th>
                      </tr>
                    </thead>
                    <tbody>
                      {jclJobs.slice(0, 15).map((job, idx) => {
                        const execsFrom = execRelationships.filter(r => r.from === job.name);
                        return (
                          <tr key={idx} className={idx % 2 === 0 ? '' : 'bg-gray-50'}>
                            <td className="border border-gray-300 px-4 py-2 font-medium">{job.name}</td>
                            <td className="border border-gray-300 px-4 py-2 text-center">{job.methods?.length || 0}</td>
                            <td className="border border-gray-300 px-4 py-2 text-sm">
                              {execsFrom.length > 0 ? execsFrom.map(e => e.to).join(', ') : '-'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  {jclJobs.length > 15 && (
                    <p className="text-sm text-gray-500 mb-4">... and {jclJobs.length - 15} more JCL jobs</p>
                  )}
                </>
              )}
            </section>

            {/* Call Graph / Dependencies */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4 text-violet-800 flex items-center gap-2">
                <Network className="w-6 h-6" />
                4. Program Dependencies &amp; Call Graph
              </h2>
              
              {callRelationships.length > 0 ? (
                <>
                  {/* Call Graph Visualization */}
                  {callGraphSvg && (
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-3 text-gray-700">Call Graph Diagram</h3>
                      <div 
                        className="bg-white p-4 rounded-lg border border-violet-200 overflow-auto"
                        dangerouslySetInnerHTML={{ __html: callGraphSvg }}
                      />
                    </div>
                  )}

                  {/* Copybook Dependency Diagram */}
                  {copyGraphSvg && (
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-3 text-gray-700">Copybook Dependencies</h3>
                      <div 
                        className="bg-white p-4 rounded-lg border border-blue-200 overflow-auto"
                        dangerouslySetInnerHTML={{ __html: copyGraphSvg }}
                      />
                    </div>
                  )}

                  <h3 className="text-lg font-semibold mb-3 text-gray-700">Call Relationship Table</h3>
                  <p className="text-gray-600 mb-4">
                    The following table shows program-to-program CALL relationships in the application.
                  </p>
                  <table className="w-full border-collapse border border-gray-300 mb-6">
                    <thead>
                      <tr className="bg-violet-100">
                        <th className="border border-gray-300 px-4 py-2 text-left">Calling Program</th>
                        <th className="border border-gray-300 px-4 py-2 text-center">&rarr;</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Called Program</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Call Type</th>
                      </tr>
                    </thead>
                    <tbody>
                      {callRelationships.slice(0, 30).map((rel, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? '' : 'bg-gray-50'}>
                          <td className="border border-gray-300 px-4 py-2 font-medium">{rel.from}</td>
                          <td className="border border-gray-300 px-4 py-2 text-center text-violet-600">CALL</td>
                          <td className="border border-gray-300 px-4 py-2 font-medium text-violet-700">{rel.to}</td>
                          <td className="border border-gray-300 px-4 py-2 text-sm text-gray-600">
                            Static
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {callRelationships.length > 30 && (
                    <p className="text-sm text-gray-500 mb-4">... and {callRelationships.length - 30} more call relationships</p>
                  )}
                </>
              ) : (
                <p className="text-gray-500 italic">No program-to-program call relationships detected.</p>
              )}
            </section>

            {/* AI Analysis Section */}
            {completedAnalyses.length > 0 && (
              <section className="mb-8">
                <h2 className="text-2xl font-bold mb-4 text-violet-800 flex items-center gap-2">
                  <Bot className="w-6 h-6" />
                  5. AI-Generated Documentation
                </h2>
                <p className="text-gray-600 mb-4">
                  The following AI-generated analyses provide detailed explanations of each program's purpose, 
                  business logic, data flows, and processing rules.
                </p>
                
                {completedAnalyses.map(([fileName, status], idx) => (
                  <div key={idx} className="mb-6 p-4 bg-gradient-to-r from-violet-50 to-purple-50 rounded-xl border border-violet-200">
                    <h3 className="text-lg font-semibold text-violet-700 mb-3 flex items-center gap-2">
                      <FileCode className="w-5 h-5" />
                      {fileName}
                    </h3>
                    <div className="bg-white p-4 rounded-lg border border-violet-100">
                      <FormattedAIContent content={status.description || ''} />
                    </div>
                  </div>
                ))}
              </section>
            )}

            {/* Architecture Insights */}
            {aiInsights?.architectureInsights && aiInsights.architectureInsights.length > 0 && (
              <section className="mb-8">
                <h2 className="text-2xl font-bold mb-4 text-violet-800 flex items-center gap-2">
                  <Layers className="w-6 h-6" />
                  6. Architecture Insights
                </h2>
                <div className="space-y-3">
                  {aiInsights.architectureInsights.map((insight: string, idx: number) => (
                    <div key={idx} className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border-l-4 border-blue-500">
                      <div className="flex items-start gap-3">
                        <div className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm font-bold">
                          {idx + 1}
                        </div>
                        <p className="text-gray-700">{insight}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Suggestions / Recommendations */}
            {aiInsights?.suggestions && aiInsights.suggestions.length > 0 && (
              <section className="mb-8">
                <h2 className="text-2xl font-bold mb-4 text-violet-800 flex items-center gap-2">
                  <AlertTriangle className="w-6 h-6" />
                  7. Recommendations
                </h2>
                <div className="space-y-3">
                  {aiInsights.suggestions.map((suggestion: string, idx: number) => (
                    <div key={idx} className="p-4 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-lg border-l-4 border-amber-400">
                      <div className="flex items-start gap-3">
                        <div className="bg-amber-500 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm font-bold">
                          {idx + 1}
                        </div>
                        <p className="text-gray-700">{suggestion}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Quality Score */}
            {aiInsights?.qualityScore !== undefined && (
              <section className="mb-8">
                <h2 className="text-2xl font-bold mb-4 text-violet-800 flex items-center gap-2">
                  <CheckCircle2 className="w-6 h-6" />
                  8. Quality Assessment
                </h2>
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-xl border border-green-200">
                  <div className="flex items-center gap-6">
                    <div className="text-center">
                      <div className="text-5xl font-bold text-green-600">{aiInsights.qualityScore}</div>
                      <div className="text-sm text-gray-600 font-medium">Quality Score</div>
                    </div>
                    <div className="flex-1">
                      <div className="w-full bg-gray-200 rounded-full h-4">
                        <div 
                          className="bg-gradient-to-r from-green-500 to-emerald-500 h-4 rounded-full transition-all"
                          style={{ width: `${Math.min(aiInsights.qualityScore, 100)}%` }}
                        />
                      </div>
                      <div className="flex justify-between mt-2 text-xs text-gray-500">
                        <span>0</span>
                        <span>25</span>
                        <span>50</span>
                        <span>75</span>
                        <span>100</span>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {/* Footer */}
            <div className="text-center text-sm text-gray-500 pt-8 border-t-2 border-gray-200 mt-12">
              <p className="font-medium">Nucleus - Innersource Agentic SDLC Framework</p>
              <p className="mt-1">Diamond Project - Zensar Technologies</p>
              <p className="mt-1">Report generated on {new Date().toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}</p>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
