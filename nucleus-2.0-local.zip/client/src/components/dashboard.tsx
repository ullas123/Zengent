/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Code, 
  Database, 
  Globe, 
  Settings,
  Users,
  Activity,
  AlertTriangle,
  CheckCircle,
  Brain,
  Lightbulb,
  Target,
  MessageSquareText,
  Info,
  FileCode,
  Folder,
  GitBranch,
  Link,
  Server,
  HardDrive,
  Zap,
  Shield,
  XCircle,
  Search,
  ArrowRight,
  ChevronDown,
  ChevronRight,
  Layers,
  Network,
  FileWarning,
  AlertOctagon,
  Clock,
  BarChart2
} from 'lucide-react';
import { type AnalysisData, type AIAnalysisResult } from '@shared/schema';
import AIProgressModal, { type AIProgressStep } from './ai-progress-modal';
import FormattedAIContent from './formatted-ai-content';
import MainframeDiagrams from './mainframe-diagrams';
import ApplicationFlowDiagram from './application-flow-diagram';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  LineChart,
  Line,
  AreaChart,
  Area,
  Treemap,
} from 'recharts';

interface DashboardProps {
  analysisData: AnalysisData;
  onAIAnalysisComplete?: (analysis: AIAnalysisResult) => void;
}

interface KPITileProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  color: 'blue' | 'green' | 'orange' | 'purple' | 'red' | 'cyan' | 'amber' | 'pink';
  trend?: { value: number; direction: 'up' | 'down' };
  onClick?: () => void;
}

function KPITile({ title, value, subtitle, icon, color, trend, onClick }: KPITileProps) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100',
    green: 'bg-green-50 text-green-700 border-green-200 hover:bg-green-100',
    orange: 'bg-orange-50 text-orange-700 border-orange-200 hover:bg-orange-100',
    purple: 'bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100',
    red: 'bg-red-50 text-red-700 border-red-200 hover:bg-red-100',
    cyan: 'bg-cyan-50 text-cyan-700 border-cyan-200 hover:bg-cyan-100',
    amber: 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100',
    pink: 'bg-pink-50 text-pink-700 border-pink-200 hover:bg-pink-100',
  };

  return (
    <Card 
      className={`${colorClasses[color]} border cursor-pointer transition-all duration-200`}
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <p className="text-xs font-medium opacity-70 uppercase tracking-wide">{title}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
            {subtitle && <p className="text-xs opacity-60 mt-0.5">{subtitle}</p>}
            {trend && (
              <div className="flex items-center mt-1">
                {trend.direction === 'up' ? (
                  <TrendingUp className="w-3 h-3 text-green-600 mr-1" />
                ) : (
                  <TrendingDown className="w-3 h-3 text-red-600 mr-1" />
                )}
                <span className={`text-xs ${trend.direction === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                  {trend.value}%
                </span>
              </div>
            )}
          </div>
          <div className="opacity-60">{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}

interface DependencyItemProps {
  name: string;
  fanIn: number;
  fanOut: number;
  type: 'batch' | 'online' | 'subroutine';
  dynamicCalls: number;
  db2Tables?: number;
  vsamDatasets?: number;
}

function DependencyItem({ name, fanIn, fanOut, type, dynamicCalls, db2Tables, vsamDatasets }: DependencyItemProps) {
  const typeColors = {
    batch: 'bg-blue-100 text-blue-700',
    online: 'bg-green-100 text-green-700',
    subroutine: 'bg-purple-100 text-purple-700',
  };

  return (
    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border">
      <div className="flex items-center gap-3">
        <FileCode className="w-4 h-4 text-gray-500" />
        <div>
          <p className="font-medium text-sm">{name}</p>
          <Badge className={`${typeColors[type]} text-xs mt-1`}>{type}</Badge>
        </div>
      </div>
      <div className="flex items-center gap-3 text-xs">
        <div className="text-center" title="Programs that CALL this program">
          <p className="font-bold text-blue-600">{fanIn}</p>
          <p className="text-gray-500">Called By</p>
        </div>
        <div className="text-center" title="Programs this program CALLs">
          <p className="font-bold text-orange-600">{fanOut}</p>
          <p className="text-gray-500">Calls To</p>
        </div>
        {db2Tables !== undefined && db2Tables > 0 && (
          <div className="text-center" title="DB2 tables accessed">
            <p className="font-bold text-amber-600">{db2Tables}</p>
            <p className="text-gray-500">DB2</p>
          </div>
        )}
        {vsamDatasets !== undefined && vsamDatasets > 0 && (
          <div className="text-center" title="VSAM datasets accessed">
            <p className="font-bold text-pink-600">{vsamDatasets}</p>
            <p className="text-gray-500">VSAM</p>
          </div>
        )}
        {dynamicCalls > 0 && (
          <div className="text-center" title="Dynamic CALL statements">
            <p className="font-bold text-purple-600">{dynamicCalls}</p>
            <p className="text-gray-500">Dynamic</p>
          </div>
        )}
      </div>
    </div>
  );
}

type ImpactType = 'program' | 'copybook' | 'db2' | 'dataset' | null;

interface ImpactResult {
  programs: string[];
  jobs: string[];
  transactions: string[];
  tables: string[];
  selectedItem: string;
}

export default function Dashboard({ analysisData, onAIAnalysisComplete }: DashboardProps) {
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');
  const [selectedKPI, setSelectedKPI] = useState<string | null>(null);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['inventory']));
  
  const [showProgressModal, setShowProgressModal] = useState(false);
  const [progressSteps, setProgressSteps] = useState<AIProgressStep[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [aiModel, setAiModel] = useState('OpenAI GPT-4o');
  
  const [impactType, setImpactType] = useState<ImpactType>(null);
  const [impactResult, setImpactResult] = useState<ImpactResult | null>(null);
  const [selectedImpactItem, setSelectedImpactItem] = useState<string>('');

  const initializeProgressSteps = (model: string) => {
    const steps: AIProgressStep[] = [
      { id: 'init', label: 'Initializing AI Analysis', description: 'Setting up analysis parameters', status: 'pending' },
      { id: 'parsing', label: 'Parsing COBOL Structure', description: 'Analyzing programs, copybooks, JCL', status: 'pending' },
      { id: 'context', label: 'Building Context', description: 'Preparing mainframe context for AI', status: 'pending' },
      { id: 'overview', label: 'Generating Overview', description: 'Creating program descriptions', status: 'pending' },
      { id: 'architecture', label: 'Analyzing Architecture', description: 'Identifying batch/online patterns', status: 'pending' },
      { id: 'modules', label: 'Extracting Business Rules', description: 'Analyzing decision logic and calculations', status: 'pending' },
      { id: 'suggestions', label: 'Generating Recommendations', description: 'Creating actionable improvements', status: 'pending' }
    ];
    setProgressSteps(steps);
    setCurrentStep(0);
  };

  const programs = analysisData.classes.filter(c => c.type === 'program');
  const cicsPrograms = programs.filter(c => c.programType === 'online-cics' || (c.cicsCommands && c.cicsCommands.length > 0));
  const imsPrograms = programs.filter(c => c.programType === 'online-ims' || (c.imsCommands && c.imsCommands.length > 0));
  const batchPrograms = programs.filter(c => c.programType === 'batch' || (!c.cicsCommands?.length && !c.imsCommands?.length));
  
  const allDb2Tables = new Set<string>();
  const allVsamDatasets = new Set<string>();
  programs.forEach(p => {
    p.db2Tables?.forEach(t => allDb2Tables.add(t));
    p.vsamDatasets?.forEach(d => allVsamDatasets.add(d));
  });

  const stats = {
    totalPrograms: programs.length,
    batchPrograms: batchPrograms.length,
    onlinePrograms: cicsPrograms.length + imsPrograms.length,
    copybooks: analysisData.classes.filter(c => c.type === 'copybook').length,
    jclJobs: analysisData.classes.filter(c => c.type === 'jcl').length,
    procedures: analysisData.classes.filter(c => c.type === 'jcl').reduce((sum, c) => sum + (c.dependencies?.length || 0), 0),
    relationships: analysisData.relationships.length,
    totalParagraphs: analysisData.classes.reduce((sum, c) => sum + (c.methods?.length || 0), 0),
    modules: analysisData.structure.packages.length,
    cicsTransactions: cicsPrograms.length,
    imsPrograms: imsPrograms.length,
    db2Tables: allDb2Tables.size,
    vsamDatasets: allVsamDatasets.size,
    qsamDatasets: 0,
    deadPrograms: Math.max(0, programs.length - 
      new Set(analysisData.relationships.map(r => r.to)).size),
    unusedCopybooks: Math.max(0, analysisData.classes.filter(c => c.type === 'copybook').length -
      analysisData.relationships.filter(r => r.type === 'COPY').length),
    callRelationships: analysisData.relationships.filter(r => r.type === 'CALL' || r.type === 'calls').length,
    copyRelationships: analysisData.relationships.filter(r => r.type === 'COPY').length,
    totalClasses: analysisData.classes.length,
  };

  const programDependencies = analysisData.classes
    .filter(c => c.type === 'program')
    .map(prog => {
      const fanIn = analysisData.relationships.filter(r => r.to === prog.name).length;
      const fanOut = analysisData.relationships.filter(r => r.from === prog.name).length;
      const progType = prog.programType === 'online-cics' || prog.programType === 'online-ims' 
        ? 'online' as const 
        : prog.programType === 'subroutine' 
          ? 'subroutine' as const 
          : 'batch' as const;
      return {
        name: prog.name,
        fanIn,
        fanOut,
        type: progType,
        dynamicCalls: 0,
        complexity: fanIn + fanOut + (prog.methods?.length || 0),
        db2Tables: prog.db2Tables?.length || 0,
        vsamDatasets: prog.vsamDatasets?.length || 0,
      };
    })
    .sort((a, b) => b.complexity - a.complexity);

  const highRiskPrograms = programDependencies.filter(p => p.fanIn > 3 || p.fanOut > 5 || p.complexity > 15);

  const generateAIAnalysis = async () => {
    setIsLoadingAI(true);
    
    try {
      const configResponse = await fetch('/api/ai-config');
      const configData = await configResponse.json();
      const modelName = configData.type === 'local' ? `Local LLM (${configData.model || 'Ollama'})` : 
                       configData.type === 'claude' ? 'AWS Claude 3.5 Sonnet' :
                       configData.type === 'gemini' ? 'Google Gemini Pro' :
                       'OpenAI GPT-4o';
      setAiModel(modelName);
    } catch (error) {
      setAiModel('OpenAI GPT-4o');
    }

    initializeProgressSteps(aiModel);
    setShowProgressModal(true);
    
    const progressDelays = [
      { step: 0, delay: 500 },
      { step: 1, delay: 1000 },
      { step: 2, delay: 1500 },
      { step: 3, delay: 3000 },
      { step: 4, delay: 4000 },
      { step: 5, delay: 5000 },
      { step: 6, delay: 6000 }
    ];

    progressDelays.forEach(({ step, delay }) => {
      setTimeout(() => {
        setProgressSteps(prev => prev.map((s, index) => {
          if (index < step) return { ...s, status: 'completed' as const, timestamp: new Date() };
          if (index === step) return { ...s, status: 'running' as const };
          return s;
        }));
        setCurrentStep(step);
      }, delay);
    });

    try {
      const response = await fetch('/api/projects/ai-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...analysisData, customPrompt: customPrompt.trim() || undefined }),
      });
      
      if (!response.ok) throw new Error(`Server error: ${response.status}`);
      
      const result = await response.json();
      
      setTimeout(() => {
        setProgressSteps(prev => prev.map(s => ({ ...s, status: 'completed' as const, timestamp: new Date() })));
        setCurrentStep(6);
        setTimeout(() => {
          setShowProgressModal(false);
          setAiAnalysis(result);
          if (onAIAnalysisComplete) onAIAnalysisComplete(result);
        }, 1500);
      }, 7500);
      
    } catch (error) {
      console.error('Failed to generate AI analysis:', error);
      setProgressSteps(prev => prev.map((s, index) => 
        index === currentStep ? { ...s, status: 'error' as const } : s
      ));
      setTimeout(() => {
        setShowProgressModal(false);
        setAiAnalysis({
          projectOverview: "Unable to generate AI analysis. Please check your AI configuration.",
          projectDetails: { projectDescription: "Error", projectType: "unknown", implementedFeatures: [], modulesServices: [] },
          architectureInsights: [],
          moduleInsights: {},
          suggestions: [],
          qualityScore: 0
        });
      }, 2000);
    } finally {
      setIsLoadingAI(false);
    }
  };

  useEffect(() => {
    if (analysisData.aiAnalysis) setAiAnalysis(analysisData.aiAnalysis);
  }, [analysisData]);

  const toggleSection = (section: string) => {
    setExpandedSections(prev => {
      const newSet = new Set(prev);
      if (newSet.has(section)) newSet.delete(section);
      else newSet.add(section);
      return newSet;
    });
  };

  const selectImpactType = (type: ImpactType) => {
    setImpactType(type);
    setSelectedImpactItem('');
    setImpactResult(null);
  };

  const calculateImpact = (itemName: string) => {
    if (!impactType || !itemName) {
      setImpactResult(null);
      return;
    }

    setSelectedImpactItem(itemName);
    const impactedPrograms = new Set<string>();
    const impactedJobs = new Set<string>();
    const impactedTransactions = new Set<string>();
    const impactedTables = new Set<string>();

    if (impactType === 'program') {
      const sourceProgram = programs.find(p => p.name === itemName);
      if (sourceProgram) {
        analysisData.relationships.forEach(rel => {
          if (rel.from === itemName) impactedPrograms.add(rel.to);
          if (rel.to === itemName) impactedPrograms.add(rel.from);
        });
        
        sourceProgram.db2Tables?.forEach(t => impactedTables.add(t));
        
        analysisData.classes.filter(c => c.type === 'jcl').forEach(job => {
          const hasRef = job.methods?.some(m => m.name.includes(itemName)) || 
                        job.dependencies?.includes(itemName);
          if (hasRef) impactedJobs.add(job.name);
        });
        
        if (sourceProgram.cicsCommands?.length) {
          impactedTransactions.add(`${itemName} (CICS)`);
        }
        if (sourceProgram.imsCommands?.length) {
          impactedTransactions.add(`${itemName} (IMS)`);
        }
      }
    } else if (impactType === 'copybook') {
      analysisData.relationships
        .filter(r => r.type === 'COPY' && r.to === itemName)
        .forEach(rel => impactedPrograms.add(rel.from));
      
      impactedPrograms.forEach(prog => {
        const progData = programs.find(p => p.name === prog);
        progData?.db2Tables?.forEach(t => impactedTables.add(t));
        
        analysisData.classes.filter(c => c.type === 'jcl').forEach(job => {
          const hasRef = job.methods?.some(m => m.name.includes(prog)) ||
                        job.dependencies?.includes(prog);
          if (hasRef) impactedJobs.add(job.name);
        });
        
        if (progData?.cicsCommands?.length) {
          impactedTransactions.add(`${prog} (CICS)`);
        }
      });
    } else if (impactType === 'db2') {
      programs.forEach(prog => {
        if (prog.db2Tables?.includes(itemName)) {
          impactedPrograms.add(prog.name);
          if (prog.cicsCommands?.length) impactedTransactions.add(`${prog.name} (CICS)`);
          if (prog.imsCommands?.length) impactedTransactions.add(`${prog.name} (IMS)`);
        }
      });
      
      impactedPrograms.forEach(prog => {
        analysisData.classes.filter(c => c.type === 'jcl').forEach(job => {
          const hasRef = job.methods?.some(m => m.name.includes(prog)) ||
                        job.dependencies?.includes(prog);
          if (hasRef) impactedJobs.add(job.name);
        });
      });
      
      impactedTables.add(itemName);
    } else if (impactType === 'dataset') {
      programs.forEach(prog => {
        if (prog.vsamDatasets?.includes(itemName)) {
          impactedPrograms.add(prog.name);
        }
      });
      
      impactedPrograms.forEach(prog => {
        analysisData.classes.filter(c => c.type === 'jcl').forEach(job => {
          const hasRef = job.methods?.some(m => m.name.includes(prog)) ||
                        job.dependencies?.includes(prog);
          if (hasRef) impactedJobs.add(job.name);
        });
      });
    }

    setImpactResult({
      programs: Array.from(impactedPrograms),
      jobs: Array.from(impactedJobs),
      transactions: Array.from(impactedTransactions),
      tables: Array.from(impactedTables),
      selectedItem: itemName
    });
  };

  const getImpactItemOptions = (): string[] => {
    switch (impactType) {
      case 'program':
        return programs.map(p => p.name);
      case 'copybook':
        return analysisData.classes.filter(c => c.type === 'copybook').map(c => c.name);
      case 'db2':
        return Array.from(allDb2Tables);
      case 'dataset':
        return Array.from(allVsamDatasets);
      default:
        return [];
    }
  };

  return (
    <div className="p-6 space-y-6">
      <AIProgressModal
        isOpen={showProgressModal}
        onClose={() => setShowProgressModal(false)}
        steps={progressSteps}
        currentStep={currentStep}
        aiModel={aiModel}
      />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Mainframe Analysis Dashboard</h1>
          <p className="text-gray-600">COBOL/JCL Portfolio Inventory & Dependency Analysis</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            onClick={generateAIAnalysis} 
            disabled={isLoadingAI}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
          >
            <Brain className="w-4 h-4 mr-2" />
            {isLoadingAI ? 'Analyzing...' : 'Generate AI Documentation'}
          </Button>
        </div>
      </div>

      {/* Portfolio Inventory KPI Tiles */}
      <Collapsible open={expandedSections.has('inventory')} onOpenChange={() => toggleSection('inventory')}>
        <CollapsibleTrigger className="flex items-center gap-2 w-full text-left mb-4">
          {expandedSections.has('inventory') ? <ChevronDown className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
          <h2 className="text-xl font-semibold">Portfolio Inventory</h2>
          <Badge variant="secondary" className="ml-2">{stats.totalClasses} Total Artifacts</Badge>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
            <KPITile
              title="COBOL Programs"
              value={stats.totalPrograms}
              subtitle={`${stats.batchPrograms} Batch / ${stats.onlinePrograms} Online`}
              icon={<FileCode className="w-5 h-5" />}
              color="blue"
              onClick={() => setSelectedKPI('programs')}
            />
            <KPITile
              title="Copybooks"
              value={stats.copybooks}
              subtitle="FILE/WS/LINKAGE"
              icon={<Folder className="w-5 h-5" />}
              color="green"
              onClick={() => setSelectedKPI('copybooks')}
            />
            <KPITile
              title="JCL Jobs"
              value={stats.jclJobs}
              subtitle="JOB/EXEC/DD"
              icon={<Settings className="w-5 h-5" />}
              color="orange"
              onClick={() => setSelectedKPI('jcl')}
            />
            <KPITile
              title="CICS Trans"
              value={stats.cicsTransactions}
              subtitle="TRANID mapped"
              icon={<Globe className="w-5 h-5" />}
              color="cyan"
              onClick={() => setSelectedKPI('cics')}
            />
            <KPITile
              title="IMS Programs"
              value={stats.imsPrograms}
              subtitle="MPP/BMP"
              icon={<Server className="w-5 h-5" />}
              color="purple"
              onClick={() => setSelectedKPI('ims')}
            />
            <KPITile
              title="DB2 Tables"
              value={stats.db2Tables}
              subtitle="SQL refs"
              icon={<Database className="w-5 h-5" />}
              color="amber"
              onClick={() => setSelectedKPI('db2')}
            />
            <KPITile
              title="VSAM/QSAM"
              value={stats.vsamDatasets + stats.qsamDatasets}
              subtitle="Dataset refs"
              icon={<HardDrive className="w-5 h-5" />}
              color="pink"
              onClick={() => setSelectedKPI('vsam')}
            />
            <KPITile
              title="Dead Programs"
              value={stats.deadPrograms}
              subtitle="No JCL/TRANID ref"
              icon={<XCircle className="w-5 h-5" />}
              color="red"
              onClick={() => setSelectedKPI('dead')}
            />
          </div>
        </CollapsibleContent>
      </Collapsible>

      {/* Main Dashboard Tabs */}
      <Tabs defaultValue="dependencies" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="dependencies">Dependencies</TabsTrigger>
          <TabsTrigger value="risk">Risk & Complexity</TabsTrigger>
          <TabsTrigger value="deadcode">Dead Code</TabsTrigger>
          <TabsTrigger value="impact">Impact Analysis</TabsTrigger>
          <TabsTrigger value="architecture">Architecture</TabsTrigger>
          <TabsTrigger value="ai-insights">AI Insights</TabsTrigger>
        </TabsList>

        {/* Dependencies Tab */}
        <TabsContent value="dependencies" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Program CALL Graph Summary */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <GitBranch className="w-5 h-5" />
                  Program Dependencies
                </CardTitle>
                <p className="text-xs text-gray-500 mt-1">
                  Shows each program and how it connects to others. "Called By" = other programs that call this one. "Calls To" = programs this one calls.
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {programDependencies.slice(0, 10).map((prog, index) => (
                    <DependencyItem
                      key={index}
                      name={prog.name}
                      fanIn={prog.fanIn}
                      fanOut={prog.fanOut}
                      type={prog.type}
                      dynamicCalls={prog.dynamicCalls}
                      db2Tables={prog.db2Tables}
                      vsamDatasets={prog.vsamDatasets}
                    />
                  ))}
                  {programDependencies.length === 0 && (
                    <p className="text-gray-500 text-center py-4">No program dependencies found in the uploaded code</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Call Graph Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="w-5 h-5" />
                  Relationship Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-xs text-gray-500 mb-2">Shows how programs connect to each other and shared resources</p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-blue-50 rounded-lg" title="Number of CALL statements linking programs together">
                    <p className="text-2xl font-bold text-blue-700">{stats.callRelationships}</p>
                    <p className="text-xs text-blue-600">Program CALLs</p>
                    <p className="text-[10px] text-gray-400">Links between programs</p>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg" title="Number of COPY statements including shared copybooks">
                    <p className="text-2xl font-bold text-green-700">{stats.copyRelationships}</p>
                    <p className="text-xs text-green-600">Copybook Includes</p>
                    <p className="text-[10px] text-gray-400">Shared code references</p>
                  </div>
                  <div className="text-center p-3 bg-orange-50 rounded-lg" title="Internal sections within programs (PERFORM targets)">
                    <p className="text-2xl font-bold text-orange-700">{stats.totalParagraphs}</p>
                    <p className="text-xs text-orange-600">Paragraphs</p>
                    <p className="text-[10px] text-gray-400">Internal code sections</p>
                  </div>
                  <div className="text-center p-3 bg-purple-50 rounded-lg" title="JCL cataloged procedures referenced">
                    <p className="text-2xl font-bold text-purple-700">{stats.procedures}</p>
                    <p className="text-xs text-purple-600">JCL Procedures</p>
                    <p className="text-[10px] text-gray-400">Cataloged PROCs</p>
                  </div>
                </div>
                <Separator />
                <div>
                  <p className="text-sm font-medium mb-2">Entry Points Classification</p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Batch Entry (JCL PGM=)</span>
                      <Badge variant="secondary">{stats.jclJobs}</Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Online Entry (TRANID)</span>
                      <Badge variant="secondary">{stats.cicsTransactions}</Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>IMS Entry (MPP/BMP)</span>
                      <Badge variant="secondary">{stats.imsPrograms}</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* JCL Job Flow & Data Touchpoints */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="w-5 h-5" />
                  JCL Job Flow Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analysisData.classes.filter(c => c.type === 'jcl').slice(0, 5).map((job, index) => (
                    <div key={index} className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Settings className="w-4 h-4 text-orange-600" />
                          <span className="font-medium">{job.name}</span>
                        </div>
                        <Badge className="bg-orange-100 text-orange-700">
                          {job.methods?.length || 0} Steps
                        </Badge>
                      </div>
                      {job.methods && job.methods.length > 0 && (
                        <div className="mt-2 pl-6 text-xs text-gray-600">
                          {job.methods.slice(0, 3).map((step, i) => (
                            <div key={i} className="flex items-center gap-1">
                              <ArrowRight className="w-3 h-3" />
                              <span>{step.name}</span>
                            </div>
                          ))}
                          {job.methods.length > 3 && (
                            <span className="text-gray-400">+{job.methods.length - 3} more steps</span>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                  {stats.jclJobs === 0 && (
                    <p className="text-gray-500 text-center py-4">No JCL jobs found</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="w-5 h-5" />
                  Data Touchpoint Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-amber-800">DB2 Tables</span>
                      <Badge className="bg-amber-100 text-amber-700">{stats.db2Tables} refs</Badge>
                    </div>
                    <p className="text-xs text-amber-600">CRUD operations detected via EXEC SQL blocks</p>
                  </div>
                  <div className="p-3 bg-pink-50 rounded-lg border border-pink-200">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-pink-800">VSAM Datasets</span>
                      <Badge className="bg-pink-100 text-pink-700">{stats.vsamDatasets} refs</Badge>
                    </div>
                    <p className="text-xs text-pink-600">READ/WRITE/REWRITE/DELETE operations</p>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-gray-800">QSAM Datasets</span>
                      <Badge className="bg-gray-100 text-gray-700">{stats.qsamDatasets} refs</Badge>
                    </div>
                    <p className="text-xs text-gray-600">Sequential file operations</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Risk & Complexity Tab */}
        <TabsContent value="risk" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-orange-500" />
                  High-Risk Programs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {highRiskPrograms.slice(0, 8).map((prog, index) => (
                    <div key={index} className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{prog.name}</p>
                          <div className="flex gap-2 mt-1">
                            {prog.fanIn > 3 && <Badge variant="destructive" className="text-xs">High Fan-In: {prog.fanIn}</Badge>}
                            {prog.fanOut > 5 && <Badge variant="destructive" className="text-xs">High Fan-Out: {prog.fanOut}</Badge>}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-orange-600">{prog.complexity}</p>
                          <p className="text-xs text-gray-500">Complexity</p>
                        </div>
                      </div>
                    </div>
                  ))}
                  {highRiskPrograms.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <CheckCircle className="w-12 h-12 mx-auto mb-2 text-green-500" />
                      <p>No high-risk programs detected</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart2 className="w-5 h-5" />
                  Complexity Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={[
                    { tier: 'Low', count: programDependencies.filter(p => p.complexity <= 5).length },
                    { tier: 'Medium', count: programDependencies.filter(p => p.complexity > 5 && p.complexity <= 10).length },
                    { tier: 'High', count: programDependencies.filter(p => p.complexity > 10 && p.complexity <= 15).length },
                    { tier: 'Critical', count: programDependencies.filter(p => p.complexity > 15).length },
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="tier" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" name="Programs">
                      <Cell fill="#22c55e" />
                      <Cell fill="#f59e0b" />
                      <Cell fill="#f97316" />
                      <Cell fill="#ef4444" />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Standards Flags */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Standards & Risk Flags
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 bg-red-50 rounded-lg border border-red-200 text-center">
                  <AlertOctagon className="w-8 h-8 mx-auto text-red-500 mb-2" />
                  <p className="text-2xl font-bold text-red-700">0</p>
                  <p className="text-xs text-red-600">Heavy GO TO Usage</p>
                </div>
                <div className="p-4 bg-orange-50 rounded-lg border border-orange-200 text-center">
                  <Layers className="w-8 h-8 mx-auto text-orange-500 mb-2" />
                  <p className="text-2xl font-bold text-orange-700">0</p>
                  <p className="text-xs text-orange-600">Excessive Nesting</p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200 text-center">
                  <Zap className="w-8 h-8 mx-auto text-purple-500 mb-2" />
                  <p className="text-2xl font-bold text-purple-700">0</p>
                  <p className="text-xs text-purple-600">Dynamic CALLs</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200 text-center">
                  <FileWarning className="w-8 h-8 mx-auto text-blue-500 mb-2" />
                  <p className="text-2xl font-bold text-blue-700">0</p>
                  <p className="text-xs text-blue-600">Duplicate Logic</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Dead Code Tab */}
        <TabsContent value="deadcode" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600">
                  <XCircle className="w-5 h-5" />
                  Dead Programs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-4">
                  <p className="text-4xl font-bold text-red-600">{stats.deadPrograms}</p>
                  <p className="text-sm text-gray-500">No JCL/TRANID/IMS reference</p>
                </div>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {analysisData.classes
                    .filter(c => c.type === 'program')
                    .filter(prog => !analysisData.relationships.some(r => r.to === prog.name))
                    .slice(0, 10)
                    .map((prog, index) => (
                      <div key={index} className="p-2 bg-red-50 rounded border border-red-200 text-sm">
                        {prog.name}
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-600">
                  <Folder className="w-5 h-5" />
                  Unused Copybooks
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-4">
                  <p className="text-4xl font-bold text-orange-600">{stats.unusedCopybooks}</p>
                  <p className="text-sm text-gray-500">Never included in programs</p>
                </div>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {analysisData.classes
                    .filter(c => c.type === 'copybook')
                    .filter(copy => !analysisData.relationships.some(r => r.to === copy.name && r.type === 'COPY'))
                    .slice(0, 10)
                    .map((copy, index) => (
                      <div key={index} className="p-2 bg-orange-50 rounded border border-orange-200 text-sm">
                        {copy.name}
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-gray-600">
                  <Code className="w-5 h-5" />
                  Unreferenced Paragraphs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-4">
                  <p className="text-4xl font-bold text-gray-600">-</p>
                  <p className="text-sm text-gray-500">Best effort analysis</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg text-center">
                  <p className="text-sm text-gray-500">
                    Run AI analysis to detect unreferenced paragraphs
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Impact Analysis Tab */}
        <TabsContent value="impact" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5" />
                Change Impact Analyzer
              </CardTitle>
              <p className="text-xs text-gray-500 mt-1">
                Step 1: Select a category, Step 2: Choose a specific item to analyze its impact
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Button 
                    variant={impactType === 'program' ? 'default' : 'outline'} 
                    className="h-20 flex flex-col items-center justify-center"
                    onClick={() => selectImpactType('program')}
                  >
                    <FileCode className="w-6 h-6 mb-1" />
                    <span className="text-sm">Program Impact</span>
                    <span className="text-xs text-muted-foreground">{programs.length} available</span>
                  </Button>
                  <Button 
                    variant={impactType === 'copybook' ? 'default' : 'outline'} 
                    className="h-20 flex flex-col items-center justify-center"
                    onClick={() => selectImpactType('copybook')}
                  >
                    <Folder className="w-6 h-6 mb-1" />
                    <span className="text-sm">Copybook Impact</span>
                    <span className="text-xs text-muted-foreground">{stats.copybooks} available</span>
                  </Button>
                  <Button 
                    variant={impactType === 'db2' ? 'default' : 'outline'} 
                    className="h-20 flex flex-col items-center justify-center"
                    onClick={() => selectImpactType('db2')}
                  >
                    <Database className="w-6 h-6 mb-1" />
                    <span className="text-sm">DB2 Table Impact</span>
                    <span className="text-xs text-muted-foreground">{stats.db2Tables} available</span>
                  </Button>
                  <Button 
                    variant={impactType === 'dataset' ? 'default' : 'outline'} 
                    className="h-20 flex flex-col items-center justify-center"
                    onClick={() => selectImpactType('dataset')}
                  >
                    <HardDrive className="w-6 h-6 mb-1" />
                    <span className="text-sm">Dataset Impact</span>
                    <span className="text-xs text-muted-foreground">{stats.vsamDatasets} available</span>
                  </Button>
                </div>
                
                {impactType && (
                  <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg border">
                    <Label className="text-sm font-medium whitespace-nowrap">
                      Select {impactType === 'db2' ? 'DB2 Table' : impactType === 'dataset' ? 'VSAM Dataset' : impactType}:
                    </Label>
                    <Select value={selectedImpactItem} onValueChange={calculateImpact}>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder={`Choose a ${impactType} to analyze...`} />
                      </SelectTrigger>
                      <SelectContent>
                        {getImpactItemOptions().map((item) => (
                          <SelectItem key={item} value={item}>{item}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                <Separator />
                {impactResult ? (
                  <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
                    <p className="text-sm font-medium text-amber-800 mb-2">
                      <AlertTriangle className="w-4 h-4 inline mr-2" />
                      Impact Analysis for: <span className="font-bold">{impactResult.selectedItem}</span>
                    </p>
                    <p className="text-xs text-amber-700">
                      If this {impactType} is modified, the components below may be affected.
                    </p>
                  </div>
                ) : impactType ? (
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <p className="text-sm text-green-700">
                      <Info className="w-4 h-4 inline mr-2" />
                      Now select a specific {impactType} from the dropdown above to see its impact.
                    </p>
                  </div>
                ) : (
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <p className="text-sm text-blue-700">
                      <Info className="w-4 h-4 inline mr-2" />
                      Select a category above to start analyzing change impacts.
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Impact Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className={impactResult && impactResult.programs.length > 0 ? 'ring-2 ring-blue-400' : ''}>
              <CardContent className="p-4 text-center">
                <FileCode className="w-8 h-8 mx-auto text-blue-500 mb-2" />
                <p className="text-2xl font-bold">{impactResult?.programs.length ?? '-'}</p>
                <p className="text-xs text-gray-500">Impacted Programs</p>
                {impactResult && impactResult.programs.length > 0 && (
                  <div className="mt-2 text-left max-h-20 overflow-y-auto">
                    {impactResult.programs.slice(0, 3).map((p, i) => (
                      <Badge key={i} variant="secondary" className="text-[10px] mr-1 mb-1">{p}</Badge>
                    ))}
                    {impactResult.programs.length > 3 && (
                      <span className="text-[10px] text-gray-400">+{impactResult.programs.length - 3} more</span>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
            <Card className={impactResult && impactResult.jobs.length > 0 ? 'ring-2 ring-orange-400' : ''}>
              <CardContent className="p-4 text-center">
                <Settings className="w-8 h-8 mx-auto text-orange-500 mb-2" />
                <p className="text-2xl font-bold">{impactResult?.jobs.length ?? '-'}</p>
                <p className="text-xs text-gray-500">Impacted Jobs</p>
                {impactResult && impactResult.jobs.length > 0 && (
                  <div className="mt-2 text-left max-h-20 overflow-y-auto">
                    {impactResult.jobs.slice(0, 3).map((j, i) => (
                      <Badge key={i} variant="secondary" className="text-[10px] mr-1 mb-1">{j}</Badge>
                    ))}
                    {impactResult.jobs.length > 3 && (
                      <span className="text-[10px] text-gray-400">+{impactResult.jobs.length - 3} more</span>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
            <Card className={impactResult && impactResult.transactions.length > 0 ? 'ring-2 ring-cyan-400' : ''}>
              <CardContent className="p-4 text-center">
                <Globe className="w-8 h-8 mx-auto text-cyan-500 mb-2" />
                <p className="text-2xl font-bold">{impactResult?.transactions.length ?? '-'}</p>
                <p className="text-xs text-gray-500">Impacted Trans</p>
                {impactResult && impactResult.transactions.length > 0 && (
                  <div className="mt-2 text-left max-h-20 overflow-y-auto">
                    {impactResult.transactions.slice(0, 3).map((t, i) => (
                      <Badge key={i} variant="secondary" className="text-[10px] mr-1 mb-1">{t}</Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            <Card className={impactResult && impactResult.tables.length > 0 ? 'ring-2 ring-purple-400' : ''}>
              <CardContent className="p-4 text-center">
                <Database className="w-8 h-8 mx-auto text-purple-500 mb-2" />
                <p className="text-2xl font-bold">{impactResult?.tables.length ?? '-'}</p>
                <p className="text-xs text-gray-500">Impacted Tables</p>
                {impactResult && impactResult.tables.length > 0 && (
                  <div className="mt-2 text-left max-h-20 overflow-y-auto">
                    {impactResult.tables.slice(0, 3).map((t, i) => (
                      <Badge key={i} variant="secondary" className="text-[10px] mr-1 mb-1">{t}</Badge>
                    ))}
                    {impactResult.tables.length > 3 && (
                      <span className="text-[10px] text-gray-400">+{impactResult.tables.length - 3} more</span>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Architecture Tab */}
        <TabsContent value="architecture" className="space-y-6">
          {/* Interactive Mainframe Diagrams */}
          <MainframeDiagrams analysisData={analysisData} />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Application Component View */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="w-5 h-5" />
                  Application Component View
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Settings className="w-5 h-5 text-blue-600" />
                      <span className="font-semibold text-blue-800">Batch Subsystem</span>
                    </div>
                    <p className="text-sm text-blue-600">{stats.jclJobs} JCL Jobs, {stats.batchPrograms} Programs</p>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Globe className="w-5 h-5 text-green-600" />
                      <span className="font-semibold text-green-800">Online Subsystem</span>
                    </div>
                    <p className="text-sm text-green-600">{stats.cicsTransactions} CICS, {stats.imsPrograms} IMS</p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Link className="w-5 h-5 text-purple-600" />
                      <span className="font-semibold text-purple-800">Shared Services</span>
                    </div>
                    <p className="text-sm text-purple-600">{stats.copybooks} Copybooks, Common Programs</p>
                  </div>
                  <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Database className="w-5 h-5 text-amber-600" />
                      <span className="font-semibold text-amber-800">Data Stores</span>
                    </div>
                    <p className="text-sm text-amber-600">{stats.db2Tables} DB2, {stats.vsamDatasets} VSAM, {stats.qsamDatasets} QSAM</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Component Distribution Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Component Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'COBOL Programs', value: stats.totalPrograms, color: '#3b82f6' },
                        { name: 'Copybooks', value: stats.copybooks, color: '#22c55e' },
                        { name: 'JCL Jobs', value: stats.jclJobs, color: '#f59e0b' },
                        { name: 'Procedures', value: stats.procedures, color: '#8b5cf6' },
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => value > 0 ? `${name}: ${value}` : ''}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {[
                        { color: '#3b82f6' },
                        { color: '#22c55e' },
                        { color: '#f59e0b' },
                        { color: '#8b5cf6' },
                      ].map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Architecture Insights from AI */}
          <Card>
            <CardHeader>
              <CardTitle>Architecture Patterns</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {aiAnalysis?.architectureInsights && aiAnalysis.architectureInsights.length > 0 ? (
                  aiAnalysis.architectureInsights.map((insight, index) => (
                    <div key={index} className="flex items-start space-x-3 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100">
                      <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <FormattedAIContent content={insight} />
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Brain className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Generate AI analysis to see architecture insights</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI Insights Tab */}
        <TabsContent value="ai-insights" className="space-y-6">
          {/* Custom Prompt Section */}
          <Card className="border-dashed border-2 border-blue-200 bg-blue-50/30">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <MessageSquareText className="w-5 h-5 text-blue-600" />
                  <Label htmlFor="custom-prompt" className="text-sm font-medium text-gray-700">
                    Custom AI Analysis Prompt
                  </Label>
                </div>
                <Textarea
                  id="custom-prompt"
                  placeholder="Add specific instructions for AI analysis...&#10;Example: 'Focus on business rules in CALC-PREMIUM paragraph' or 'Explain the payment processing flow'"
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  className="min-h-[100px] resize-vertical"
                  disabled={isLoadingAI}
                />
              </div>
            </CardContent>
          </Card>

          {/* AI Analysis Results */}
          {aiAnalysis ? (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5 text-purple-600" />
                    Project Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <FormattedAIContent content={aiAnalysis.projectOverview} />
                </CardContent>
              </Card>

              {aiAnalysis.suggestions && aiAnalysis.suggestions.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Lightbulb className="w-5 h-5 text-amber-500" />
                      Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {aiAnalysis.suggestions.map((suggestion, index) => (
                        <div key={index} className="flex items-start gap-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
                          <CheckCircle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                          <div className="flex-1">
                            <FormattedAIContent content={suggestion} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Application Flow Diagram */}
              <ApplicationFlowDiagram analysisData={analysisData} />

              {/* Module Insights */}
              {aiAnalysis.moduleInsights && Object.keys(aiAnalysis.moduleInsights).length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Program Analysis Details</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {Object.entries(aiAnalysis.moduleInsights).map(([moduleName, insight]) => (
                        <Card key={moduleName} className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200">
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm flex items-center gap-2">
                              <Code className="w-4 h-4 text-green-600" />
                              {moduleName}
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="pt-0">
                            {insight.description && (
                              <FormattedAIContent content={insight.description} />
                            )}
                            {insight.patterns && insight.patterns.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {insight.patterns.map((pattern, i) => (
                                  <Badge key={i} variant="outline" className="text-xs">
                                    {pattern}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <Card>
              <CardContent className="py-16 text-center">
                <Brain className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No AI Analysis Yet</h3>
                <p className="text-gray-500 mb-6">
                  Generate AI documentation to see business rules, architectural overview, and natural language naming
                </p>
                <Button onClick={generateAIAnalysis} disabled={isLoadingAI}>
                  <Brain className="w-4 h-4 mr-2" />
                  Generate AI Documentation
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
