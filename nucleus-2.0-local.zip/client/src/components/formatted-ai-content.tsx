/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

interface FormattedAIContentProps {
  content: string;
  variant?: 'default' | 'architecture';
}

export default function FormattedAIContent({ content, variant = 'default' }: FormattedAIContentProps) {
  if (!content) return null;
  
  // Clean any remaining markdown symbols from the content
  const cleanMarkdown = (text: string): string => {
    return text
      .replace(/^#{1,6}\s*/gm, '') // Remove heading markers
      .replace(/\*\*\*/g, '')      // Remove bold+italic
      .replace(/\*\*/g, '')        // Remove bold
      .replace(/\*/g, '')          // Remove italic
      .replace(/`{3}[\s\S]*?`{3}/g, (match) => match.replace(/`{3}/g, '')) // Remove code block markers
      .replace(/`([^`]+)`/g, '$1') // Remove inline code markers
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1'); // Remove link formatting, keep text
  };

  // Special handling for architecture overview - convert to table
  if (variant === 'architecture') {
    const cleanedContent = cleanMarkdown(content);
    const lines = cleanedContent.split('\n').filter(line => line.trim());
    const architectureItems: { label: string; value: string }[] = [];
    let generalDescriptions: string[] = [];

    lines.forEach(line => {
      const trimmed = line.trim();
      const withoutNumber = trimmed.replace(/^\d+\.\s*/, '');
      
      if (withoutNumber.includes(':')) {
        const [label, ...valueParts] = withoutNumber.split(':');
        const value = valueParts.join(':').trim();
        if (label && value) {
          architectureItems.push({ label: label.trim(), value });
        }
      } else if (withoutNumber) {
        generalDescriptions.push(withoutNumber);
      }
    });

    if (architectureItems.length === 0 && generalDescriptions.length === 0) {
      return (
        <div className="text-gray-700 leading-relaxed">
          {cleanedContent}
        </div>
      );
    }

    return (
      <div className="space-y-3">
        {generalDescriptions.length > 0 && (
          <div className="text-sm text-gray-700 leading-relaxed space-y-2 mb-4">
            {generalDescriptions.map((desc, idx) => (
              <p key={`desc-${idx}`}>{desc}</p>
            ))}
          </div>
        )}
        {architectureItems.map((item, index) => (
          <div key={index} className="border-l-4 border-blue-400 pl-4 py-2 bg-blue-50/50">
            <div className="text-sm font-semibold text-gray-800 mb-1">{item.label}</div>
            <div className="text-sm text-gray-700 leading-relaxed">{item.value}</div>
          </div>
        ))}
      </div>
    );
  }

  const formatContent = (text: string) => {
    const cleanedText = cleanMarkdown(text);
    const lines = cleanedText.split('\n');
    const elements: JSX.Element[] = [];
    let listItems: string[] = [];

    const flushList = () => {
      if (listItems.length > 0) {
        elements.push(
          <ul key={`list-${elements.length}`} className="list-disc list-inside space-y-1 mb-3 ml-2">
            {listItems.map((item, idx) => (
              <li key={idx} className="text-gray-700 leading-relaxed text-sm">{item}</li>
            ))}
          </ul>
        );
        listItems = [];
      }
    };

    lines.forEach((line, index) => {
      const trimmed = line.trim();
      
      if (!trimmed) {
        flushList();
        return;
      }

      // Section headers ending with colon (e.g., "PROGRAM SUMMARY:")
      if (/^[A-Z][A-Z\s&]+:$/.test(trimmed)) {
        flushList();
        elements.push(
          <h3 key={`section-${index}`} className="text-sm font-semibold text-gray-900 mt-4 mb-2 border-b border-gray-200 pb-1">
            {trimmed.replace(/:$/, '')}
          </h3>
        );
      }
      // Numbered lists
      else if (/^\d+\.\s/.test(trimmed)) {
        const text = trimmed.replace(/^\d+\.\s*/, '');
        listItems.push(text);
      }
      // Bullet lists (-, •)
      else if (/^[-•]\s/.test(trimmed)) {
        const text = trimmed.replace(/^[-•]\s*/, '');
        listItems.push(text);
      }
      // Lines with label: value format (short labels only)
      else if (trimmed.includes(':') && trimmed.indexOf(':') < 25 && trimmed.indexOf(':') > 0) {
        flushList();
        const colonIndex = trimmed.indexOf(':');
        const label = trimmed.substring(0, colonIndex).trim();
        const value = trimmed.substring(colonIndex + 1).trim();
        if (value && label.length > 0) {
          elements.push(
            <div key={`kv-${index}`} className="mb-2 text-sm">
              <span className="font-medium text-gray-800">{label}:</span>{' '}
              <span className="text-gray-700">{value}</span>
            </div>
          );
        } else {
          elements.push(
            <p key={`p-${index}`} className="text-gray-700 leading-relaxed mb-2 text-sm">{trimmed}</p>
          );
        }
      }
      // Regular paragraphs
      else {
        flushList();
        elements.push(
          <p key={`p-${index}`} className="text-gray-700 leading-relaxed mb-2 text-sm">
            {trimmed}
          </p>
        );
      }
    });

    flushList();
    return elements;
  };

  return (
    <div className="prose prose-sm max-w-none">
      {formatContent(content)}
    </div>
  );
}
