/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useState, useEffect, useRef, useCallback } from "react";
import { type Project, type AnalysisData } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { 
  FolderOpen, 
  Download, 
  Share2, 
  Settings,
  FileCode,
  FileText,
  Database,
  GitBranch,
  Boxes,
  Network,
  Server,
  HardDrive,
  Layers,
  ArrowRight,
  Terminal,
  Copy,
  Play,
  Link2,
  Bot,
  Loader2,
  CheckCircle2,
  XCircle,
  FileDown,
  Eye
} from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import FormattedAIContent from "@/components/formatted-ai-content";
import MainframeReportPreview from "@/components/mainframe-report-preview";

interface EnrichmentProgress {
  totalFiles: number;
  completedFiles: number;
  currentFile: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'paused';
  fileStatuses: Record<string, { status: string; description?: string }>;
}

interface CobolAnalysisResultsProps {
  project: Project;
  onNewAnalysis: () => void;
}

export default function CobolAnalysisResults({ project, onNewAnalysis }: CobolAnalysisResultsProps) {
  const [enrichmentProgress, setEnrichmentProgress] = useState<EnrichmentProgress | null>(null);
  const [showEnrichmentDetails, setShowEnrichmentDetails] = useState(false);
  const [selectedAnalysis, setSelectedAnalysis] = useState<{ name: string; description: string } | null>(null);
  const [showReportPreview, setShowReportPreview] = useState(false);
  const eventSourceRef = useRef<EventSource | null>(null);
  const analysisData = project.analysisData as AnalysisData | null;

  // Export AI analysis report as text file
  const exportAnalysisReport = useCallback(() => {
    if (!enrichmentProgress?.fileStatuses) return;
    
    const completedAnalyses = Object.entries(enrichmentProgress.fileStatuses)
      .filter(([_, status]) => status.status === 'completed' && status.description);
    
    if (completedAnalyses.length === 0) {
      alert('No completed analyses to export');
      return;
    }

    let reportContent = `NUCLEUS - AI ANALYSIS REPORT\n`;
    reportContent += `Project: ${project.name}\n`;
    reportContent += `Generated: ${new Date().toLocaleString()}\n`;
    reportContent += `Files Analyzed: ${completedAnalyses.length}\n`;
    reportContent += `${'='.repeat(60)}\n\n`;

    completedAnalyses.forEach(([fileName, status]) => {
      reportContent += `\n${'─'.repeat(50)}\n`;
      reportContent += `FILE: ${fileName}\n`;
      reportContent += `${'─'.repeat(50)}\n\n`;
      reportContent += status.description || 'No analysis available';
      reportContent += '\n\n';
    });

    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.name}-ai-analysis-report.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [enrichmentProgress, project.name]);

  useEffect(() => {
    if (eventSourceRef.current) {
      return;
    }

    const eventSource = new EventSource(`/api/projects/${project.id}/ai-enrichment-progress`);
    eventSourceRef.current = eventSource;
    
    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        setEnrichmentProgress(data);
        
        if (data.status === 'completed' || data.status === 'failed') {
          queryClient.invalidateQueries({ queryKey: ['/api/projects', project.id] });
          setTimeout(() => {
            eventSource.close();
            eventSourceRef.current = null;
          }, 2000);
        }
      } catch (e) {
        console.error('Error parsing SSE data:', e);
      }
    };

    eventSource.onerror = () => {
      eventSource.close();
      eventSourceRef.current = null;
    };

    return () => {
      eventSource.close();
      eventSourceRef.current = null;
    };
  }, [project.id]);

  if (!analysisData) {
    return (
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">No analysis data available</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const programs = analysisData.classes.filter(c => c.type === 'program');
  const copybooks = analysisData.classes.filter(c => c.type === 'copybook');
  const jclJobs = analysisData.classes.filter(c => c.type === 'jcl');
  const procedures = analysisData.classes.filter(c => c.type === 'procedure');
  
  const callRelationships = analysisData.relationships.filter(r => r.type === 'CALL');
  const copyRelationships = analysisData.relationships.filter(r => r.type === 'COPY');
  const execRelationships = analysisData.relationships.filter(r => r.type === 'EXEC');

  const totalFiles = analysisData.structure?.sourceFiles?.length || 0;
  const packages = analysisData.structure?.packages || [];

  return (
    <div>
      <Card className="mb-6 bg-gradient-to-r from-violet-50 to-purple-50 dark:from-violet-950/20 dark:to-purple-950/20 border-violet-200 dark:border-violet-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-violet-600 rounded-lg">
                <Terminal className="text-white w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-medium">{project.name}</h2>
                <p className="text-muted-foreground text-sm">
                  Mainframe COBOL Project • Analyzed {totalFiles} files • 
                  Found {programs.length} programs, {copybooks.length} copybooks, {jclJobs.length} JCL jobs
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button 
                variant="default" 
                size="sm"
                className="bg-violet-600 hover:bg-violet-700 text-white"
                data-testid="button-export-cobol-report"
                onClick={() => setShowReportPreview(true)}
              >
                <Download className="w-4 h-4 mr-2" />
                Export Report
              </Button>
              <Button variant="ghost" size="sm">
                <Share2 className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-violet-100 dark:border-violet-800">
              <div className="text-2xl font-bold text-violet-600">{programs.length}</div>
              <div className="text-sm text-muted-foreground">COBOL Programs</div>
            </div>
            <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-blue-100 dark:border-blue-800">
              <div className="text-2xl font-bold text-blue-600">{copybooks.length}</div>
              <div className="text-sm text-muted-foreground">Copybooks</div>
            </div>
            <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-amber-100 dark:border-amber-800">
              <div className="text-2xl font-bold text-amber-600">{jclJobs.length}</div>
              <div className="text-sm text-muted-foreground">JCL Jobs</div>
            </div>
            <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-green-100 dark:border-green-800">
              <div className="text-2xl font-bold text-green-600">{procedures.length}</div>
              <div className="text-sm text-muted-foreground">Procedures</div>
            </div>
          </div>

          {enrichmentProgress && enrichmentProgress.status === 'completed' && (
            <div className="mt-4 p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-800">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                  <span className="font-medium text-green-700 dark:text-green-300">
                    AI Analysis Complete - All {enrichmentProgress.totalFiles} files analyzed!
                  </span>
                </div>
              </div>
              
              {/* Action Buttons for completed state */}
              <div className="flex flex-wrap items-center gap-2 mb-3 p-3 bg-white dark:bg-gray-800 rounded-lg border border-green-100 dark:border-green-700">
                <Button 
                  variant="default"
                  size="sm"
                  className="bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => setShowEnrichmentDetails(!showEnrichmentDetails)}
                >
                  <Eye className="w-4 h-4 mr-2" />
                  {showEnrichmentDetails ? 'Hide Analysis' : 'View All AI Analysis'}
                </Button>
                <Button 
                  variant="default"
                  size="sm"
                  className="bg-violet-600 hover:bg-violet-700 text-white"
                  onClick={() => setShowReportPreview(true)}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export Full Report
                </Button>
                <Button 
                  variant="outline"
                  size="sm"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50"
                  onClick={exportAnalysisReport}
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Export as Text
                </Button>
              </div>

              <p className="text-sm text-green-600 dark:text-green-400">
                Each program, copybook, and JCL job now has detailed AI-generated explanations. 
                Click "View All AI Analysis" above or select any item in the tabs below to view its documentation.
              </p>

              {showEnrichmentDetails && (
                <div className="mt-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      All Analyzed Files ({enrichmentProgress.totalFiles})
                    </span>
                  </div>
                  <div className="max-h-60 overflow-y-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {Object.entries(enrichmentProgress.fileStatuses)
                        .filter(([_, status]) => status.status === 'completed')
                        .map(([fileName, status]) => (
                        <div key={fileName} className="flex items-center justify-between gap-2 text-sm p-2 bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700">
                          <div className="flex items-center gap-2 flex-1 min-w-0">
                            <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                            <span className="truncate font-medium">{fileName}</span>
                          </div>
                          {status.description && (
                            <Button
                              variant="default"
                              size="sm"
                              className="h-7 px-3 text-xs bg-violet-600 hover:bg-violet-700 text-white"
                              onClick={() => setSelectedAnalysis({ name: fileName, description: status.description! })}
                            >
                              <Bot className="w-3 h-3 mr-1" />
                              View
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {selectedAnalysis && (
                <div className="mt-4 p-4 bg-white dark:bg-gray-800 rounded-lg border-2 border-violet-300 dark:border-violet-600 shadow-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Bot className="w-5 h-5 text-violet-600" />
                      <span className="font-semibold text-violet-700 dark:text-violet-300">
                        AI Analysis: {selectedAnalysis.name}
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedAnalysis(null)}
                      className="h-7 px-2 hover:bg-red-100"
                    >
                      <XCircle className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                  <div className="text-sm text-gray-700 dark:text-gray-300 max-h-80 overflow-y-auto bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
                    <FormattedAIContent content={selectedAnalysis.description} />
                  </div>
                </div>
              )}
            </div>
          )}

          {enrichmentProgress && enrichmentProgress.status === 'paused' && (
            <div className="mt-4 p-4 bg-amber-50 dark:bg-amber-950/30 rounded-lg border border-amber-200 dark:border-amber-800">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-amber-600" />
                  <span className="font-medium text-amber-700 dark:text-amber-300">
                    First Batch Complete - {enrichmentProgress.completedFiles}/{enrichmentProgress.totalFiles} files analyzed
                  </span>
                </div>
              </div>
              
              {/* Action Buttons Row */}
              <div className="flex flex-wrap items-center gap-2 mb-3 p-3 bg-white dark:bg-gray-800 rounded-lg border border-amber-100 dark:border-amber-700">
                <Button 
                  variant="default"
                  size="sm"
                  className="bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => setShowEnrichmentDetails(!showEnrichmentDetails)}
                >
                  <Eye className="w-4 h-4 mr-2" />
                  {showEnrichmentDetails ? 'Hide Analysis' : 'View AI Analysis'}
                </Button>
                <Button 
                  variant="default"
                  size="sm"
                  className="bg-violet-600 hover:bg-violet-700 text-white"
                  onClick={() => setShowReportPreview(true)}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export Report
                </Button>
                <Button 
                  variant="default"
                  size="sm"
                  className="bg-amber-600 hover:bg-amber-700 text-white"
                  onClick={async () => {
                    try {
                      await fetch(`/api/projects/${project.id}/continue-ai-enrichment`, {
                        method: 'POST',
                        credentials: 'include'
                      });
                    } catch (error) {
                      console.error('Failed to continue enrichment:', error);
                    }
                  }}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Continue Analysis ({enrichmentProgress.totalFiles - enrichmentProgress.completedFiles} remaining)
                </Button>
              </div>

              <div className="flex items-center gap-3 mb-2">
                <Progress 
                  value={(enrichmentProgress.completedFiles / enrichmentProgress.totalFiles) * 100} 
                  className="flex-1"
                />
                <span className="text-sm text-amber-600 font-medium">
                  {Math.round((enrichmentProgress.completedFiles / enrichmentProgress.totalFiles) * 100)}% complete
                </span>
              </div>

              {showEnrichmentDetails && (
                <div className="mt-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Completed Files ({enrichmentProgress.completedFiles})
                    </span>
                  </div>
                  <div className="max-h-60 overflow-y-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {Object.entries(enrichmentProgress.fileStatuses)
                        .filter(([_, status]) => status.status === 'completed')
                        .map(([fileName, status]) => (
                        <div key={fileName} className="flex items-center justify-between gap-2 text-sm p-2 bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700">
                          <div className="flex items-center gap-2 flex-1 min-w-0">
                            <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                            <span className="truncate font-medium">{fileName}</span>
                          </div>
                          {status.description && (
                            <Button
                              variant="default"
                              size="sm"
                              className="h-7 px-3 text-xs bg-violet-600 hover:bg-violet-700 text-white"
                              onClick={() => setSelectedAnalysis({ name: fileName, description: status.description! })}
                            >
                              <Bot className="w-3 h-3 mr-1" />
                              View Analysis
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {selectedAnalysis && (
                <div className="mt-4 p-4 bg-white dark:bg-gray-800 rounded-lg border-2 border-violet-300 dark:border-violet-600 shadow-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Bot className="w-5 h-5 text-violet-600" />
                      <span className="font-semibold text-violet-700 dark:text-violet-300">
                        AI Analysis: {selectedAnalysis.name}
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedAnalysis(null)}
                      className="h-7 px-2 hover:bg-red-100"
                    >
                      <XCircle className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                  <div className="text-sm text-gray-700 dark:text-gray-300 max-h-80 overflow-y-auto bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
                    <FormattedAIContent content={selectedAnalysis.description} />
                  </div>
                </div>
              )}
            </div>
          )}

          {enrichmentProgress && enrichmentProgress.status === 'processing' && (
            <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Bot className="w-5 h-5 text-blue-600 animate-pulse" />
                  <span className="font-medium text-blue-700 dark:text-blue-300">AI Analysis in Progress</span>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setShowEnrichmentDetails(!showEnrichmentDetails)}
                  className="text-blue-600"
                >
                  {showEnrichmentDetails ? 'Hide Details' : 'Show Details'}
                </Button>
              </div>
              <div className="flex items-center gap-3 mb-2">
                <Progress 
                  value={(enrichmentProgress.completedFiles / enrichmentProgress.totalFiles) * 100} 
                  className="flex-1"
                />
                <span className="text-sm text-blue-600 font-medium">
                  {enrichmentProgress.completedFiles}/{enrichmentProgress.totalFiles}
                </span>
              </div>
              <p className="text-sm text-blue-600 dark:text-blue-400">
                <Loader2 className="w-3 h-3 inline mr-1 animate-spin" />
                Generating AI explanation for: <strong>{enrichmentProgress.currentFile}</strong>
              </p>
              
              {showEnrichmentDetails && (
                <div className="mt-3 max-h-60 overflow-y-auto">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {Object.entries(enrichmentProgress.fileStatuses).map(([fileName, status]) => (
                      <div key={fileName} className="flex items-center justify-between gap-2 text-sm p-2 bg-white dark:bg-gray-800 rounded">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          {status.status === 'completed' ? (
                            <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                          ) : status.status === 'processing' ? (
                            <Loader2 className="w-4 h-4 text-blue-500 animate-spin flex-shrink-0" />
                          ) : status.status === 'failed' ? (
                            <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                          ) : (
                            <div className="w-4 h-4 rounded-full border-2 border-gray-300 flex-shrink-0" />
                          )}
                          <span className="truncate">{fileName}</span>
                        </div>
                        {status.status === 'completed' && status.description && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-6 px-2 text-xs bg-green-50 hover:bg-green-100 border-green-200 text-green-700"
                            onClick={() => setSelectedAnalysis({ name: fileName, description: status.description! })}
                          >
                            <Bot className="w-3 h-3 mr-1" />
                            View
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {selectedAnalysis && (
                <div className="mt-4 p-4 bg-white dark:bg-gray-800 rounded-lg border border-green-200 dark:border-green-700">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Bot className="w-5 h-5 text-green-600" />
                      <span className="font-medium text-green-700 dark:text-green-300">
                        AI Analysis: {selectedAnalysis.name}
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedAnalysis(null)}
                      className="h-6 px-2"
                    >
                      <XCircle className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="text-sm text-gray-700 dark:text-gray-300 max-h-64 overflow-y-auto">
                    <FormattedAIContent content={selectedAnalysis.description} />
                  </div>
                </div>
              )}
            </div>
          )}

          {enrichmentProgress && enrichmentProgress.status === 'completed' && (
            <div className="mt-4 p-3 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-800 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
              <span className="text-green-700 dark:text-green-300">
                AI analysis complete for all {enrichmentProgress.totalFiles} files
              </span>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="border-violet-200 dark:border-violet-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Link2 className="w-4 h-4 mr-2 text-violet-600" />
              CALL Relationships
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-violet-600">{callRelationships.length}</div>
            <p className="text-xs text-muted-foreground">Inter-program calls</p>
          </CardContent>
        </Card>

        <Card className="border-blue-200 dark:border-blue-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Copy className="w-4 h-4 mr-2 text-blue-600" />
              COPY Statements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{copyRelationships.length}</div>
            <p className="text-xs text-muted-foreground">Copybook inclusions</p>
          </CardContent>
        </Card>

        <Card className="border-amber-200 dark:border-amber-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Play className="w-4 h-4 mr-2 text-amber-600" />
              EXEC References
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-600">{execRelationships.length}</div>
            <p className="text-xs text-muted-foreground">Program executions</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="programs" className="w-full">
        <TabsList className="grid w-full grid-cols-6 mb-4">
          <TabsTrigger value="programs" className="flex items-center gap-1">
            <FileCode className="w-4 h-4" />
            Programs
          </TabsTrigger>
          <TabsTrigger value="copybooks" className="flex items-center gap-1">
            <Layers className="w-4 h-4" />
            Copybooks
          </TabsTrigger>
          <TabsTrigger value="jcl" className="flex items-center gap-1">
            <Terminal className="w-4 h-4" />
            JCL Jobs
          </TabsTrigger>
          <TabsTrigger value="procedures" className="flex items-center gap-1">
            <Server className="w-4 h-4" />
            Procedures
          </TabsTrigger>
          <TabsTrigger value="relationships" className="flex items-center gap-1">
            <Network className="w-4 h-4" />
            Dependencies
          </TabsTrigger>
          <TabsTrigger value="patterns" className="flex items-center gap-1">
            <Boxes className="w-4 h-4" />
            Patterns
          </TabsTrigger>
        </TabsList>

        <TabsContent value="programs">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileCode className="w-5 h-5 mr-2 text-violet-600" />
                COBOL Programs ({programs.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {programs.map((program, index) => (
                    <div key={index} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <FileCode className="w-5 h-5 text-violet-600" />
                          <span className="font-medium">{program.name}</span>
                        </div>
                        <Badge variant="outline" className="text-violet-600 border-violet-600">
                          {program.package || 'SOURCE'}
                        </Badge>
                      </div>
                      {program.methods && program.methods.length > 0 && (
                        <div className="mt-2">
                          <p className="text-xs text-muted-foreground mb-1">Paragraphs/Sections:</p>
                          <div className="flex flex-wrap gap-1">
                            {program.methods.slice(0, 5).map((method, i) => (
                              <Badge key={i} variant="secondary" className="text-xs">
                                {method.name}
                              </Badge>
                            ))}
                            {program.methods.length > 5 && (
                              <Badge variant="secondary" className="text-xs">
                                +{program.methods.length - 5} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}
                      {program.dependencies && program.dependencies.length > 0 && (
                        <div className="mt-2">
                          <p className="text-xs text-muted-foreground mb-1">Calls:</p>
                          <div className="flex flex-wrap gap-1">
                            {program.dependencies.map((dep, i) => (
                              <Badge key={i} variant="outline" className="text-xs text-blue-600 border-blue-300">
                                {dep}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  {programs.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">No COBOL programs found</p>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="copybooks">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Layers className="w-5 h-5 mr-2 text-blue-600" />
                Copybooks ({copybooks.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {copybooks.map((copybook, index) => (
                    <div key={index} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <Layers className="w-5 h-5 text-blue-600" />
                          <span className="font-medium">{copybook.name}</span>
                        </div>
                        <Badge variant="outline" className="text-blue-600 border-blue-600">
                          COPYBOOK
                        </Badge>
                      </div>
                      {copybook.fields && copybook.fields.length > 0 && (
                        <div className="mt-2">
                          <p className="text-xs text-muted-foreground mb-1">Data Items ({copybook.fields.length}):</p>
                          <div className="flex flex-wrap gap-1">
                            {copybook.fields.slice(0, 8).map((field, i) => (
                              <Badge key={i} variant="secondary" className="text-xs">
                                {field.name}
                              </Badge>
                            ))}
                            {copybook.fields.length > 8 && (
                              <Badge variant="secondary" className="text-xs">
                                +{copybook.fields.length - 8} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  {copybooks.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">No copybooks found</p>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="jcl">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Terminal className="w-5 h-5 mr-2 text-amber-600" />
                JCL Jobs ({jclJobs.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {jclJobs.map((job, index) => (
                    <div key={index} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <Terminal className="w-5 h-5 text-amber-600" />
                          <span className="font-medium">{job.name}</span>
                        </div>
                        <Badge variant="outline" className="text-amber-600 border-amber-600">
                          JCL
                        </Badge>
                      </div>
                      {job.methods && job.methods.length > 0 && (
                        <div className="mt-2">
                          <p className="text-xs text-muted-foreground mb-1">Job Steps:</p>
                          <div className="flex flex-wrap gap-1">
                            {job.methods.map((step, i) => (
                              <Badge key={i} variant="secondary" className="text-xs">
                                {step.name}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      {job.dependencies && job.dependencies.length > 0 && (
                        <div className="mt-2">
                          <p className="text-xs text-muted-foreground mb-1">Executes:</p>
                          <div className="flex flex-wrap gap-1">
                            {job.dependencies.map((dep, i) => (
                              <Badge key={i} variant="outline" className="text-xs text-green-600 border-green-300">
                                {dep}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  {jclJobs.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">No JCL jobs found</p>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="procedures">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Server className="w-5 h-5 mr-2 text-green-600" />
                Procedures ({procedures.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {procedures.map((proc, index) => (
                    <div key={index} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Server className="w-5 h-5 text-green-600" />
                          <span className="font-medium">{proc.name}</span>
                        </div>
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          PROC
                        </Badge>
                      </div>
                    </div>
                  ))}
                  {procedures.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">No procedures found</p>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="relationships">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Network className="w-5 h-5 mr-2 text-purple-600" />
                Program Dependencies
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2 flex items-center">
                      <Link2 className="w-4 h-4 mr-2 text-violet-600" />
                      CALL Relationships ({callRelationships.length})
                    </h4>
                    <div className="space-y-2">
                      {callRelationships.map((rel, index) => (
                        <div key={index} className="flex items-center space-x-2 p-2 bg-violet-50 dark:bg-violet-950/20 rounded border border-violet-200 dark:border-violet-800">
                          <Badge className="bg-violet-600">{rel.from}</Badge>
                          <ArrowRight className="w-4 h-4 text-violet-600" />
                          <span className="text-sm">CALL</span>
                          <ArrowRight className="w-4 h-4 text-violet-600" />
                          <Badge variant="outline" className="border-violet-600 text-violet-600">{rel.to}</Badge>
                        </div>
                      ))}
                      {callRelationships.length === 0 && (
                        <p className="text-sm text-muted-foreground">No CALL relationships found</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2 flex items-center">
                      <Copy className="w-4 h-4 mr-2 text-blue-600" />
                      COPY Relationships ({copyRelationships.length})
                    </h4>
                    <div className="space-y-2">
                      {copyRelationships.map((rel, index) => (
                        <div key={index} className="flex items-center space-x-2 p-2 bg-blue-50 dark:bg-blue-950/20 rounded border border-blue-200 dark:border-blue-800">
                          <Badge className="bg-blue-600">{rel.from}</Badge>
                          <ArrowRight className="w-4 h-4 text-blue-600" />
                          <span className="text-sm">COPY</span>
                          <ArrowRight className="w-4 h-4 text-blue-600" />
                          <Badge variant="outline" className="border-blue-600 text-blue-600">{rel.to}</Badge>
                        </div>
                      ))}
                      {copyRelationships.length === 0 && (
                        <p className="text-sm text-muted-foreground">No COPY relationships found</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2 flex items-center">
                      <Play className="w-4 h-4 mr-2 text-amber-600" />
                      EXEC Relationships ({execRelationships.length})
                    </h4>
                    <div className="space-y-2">
                      {execRelationships.map((rel, index) => (
                        <div key={index} className="flex items-center space-x-2 p-2 bg-amber-50 dark:bg-amber-950/20 rounded border border-amber-200 dark:border-amber-800">
                          <Badge className="bg-amber-600">{rel.from}</Badge>
                          <ArrowRight className="w-4 h-4 text-amber-600" />
                          <span className="text-sm">EXEC</span>
                          <ArrowRight className="w-4 h-4 text-amber-600" />
                          <Badge variant="outline" className="border-amber-600 text-amber-600">{rel.to}</Badge>
                        </div>
                      ))}
                      {execRelationships.length === 0 && (
                        <p className="text-sm text-muted-foreground">No EXEC relationships found</p>
                      )}
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patterns">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Boxes className="w-5 h-5 mr-2 text-indigo-600" />
                Detected Patterns
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {analysisData.patterns.map((pattern, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{pattern.name}</span>
                        <Badge variant="outline">{pattern.type}</Badge>
                      </div>
                      {pattern.description && (
                        <p className="text-sm text-muted-foreground mb-2">{pattern.description}</p>
                      )}
                      {pattern.classes && pattern.classes.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {pattern.classes.map((cls, i) => (
                            <Badge key={i} variant="secondary" className="text-xs">
                              {cls}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                  {analysisData.patterns.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">No patterns detected</p>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="flex items-center">
            <HardDrive className="w-5 h-5 mr-2 text-gray-600" />
            Library Structure
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {packages.map((pkg, index) => (
              <div key={index} className="p-3 border rounded-lg text-center">
                <Database className="w-6 h-6 mx-auto mb-2 text-gray-600" />
                <span className="text-sm font-medium">{pkg}</span>
              </div>
            ))}
            {packages.length === 0 && (
              <p className="col-span-5 text-center text-muted-foreground py-4">No library structure detected</p>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="mt-6 flex justify-center">
        <Button onClick={onNewAnalysis} variant="outline" size="lg">
          Analyze Another Project
        </Button>
      </div>

      <MainframeReportPreview
        open={showReportPreview}
        onClose={() => setShowReportPreview(false)}
        project={project}
        enrichmentData={enrichmentProgress}
      />
    </div>
  );
}
