/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useEffect, useRef, useCallback } from 'react';
import cytoscape, { Core, ElementDefinition } from 'cytoscape';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Workflow, 
  ZoomIn,
  ZoomOut,
  Maximize,
  Download
} from 'lucide-react';
import type { AnalysisData } from '@shared/schema';

interface ApplicationFlowDiagramProps {
  analysisData: AnalysisData;
}

const nodeColors: Record<string, string> = {
  'entry': '#3B82F6',
  'batch': '#F59E0B',
  'online': '#10B981',
  'program': '#6366F1',
  'data': '#EF4444',
  'output': '#8B5CF6',
};

export default function ApplicationFlowDiagram({ analysisData }: ApplicationFlowDiagramProps) {
  const cyRef = useRef<Core | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const programs = analysisData.classes.filter(c => c.type === 'program');
  const jclJobs = analysisData.classes.filter(c => c.type === 'jcl');
  const cicsPrograms = programs.filter(p => p.cicsCommands?.length || p.programType === 'online-cics');
  const batchPrograms = programs.filter(p => !p.cicsCommands?.length && !p.imsCommands?.length);

  const getFlowData = useCallback(() => {
    const nodes: ElementDefinition[] = [];
    const edges: ElementDefinition[] = [];

    nodes.push({
      data: { id: 'user-entry', label: 'User/System\nRequest', type: 'entry' }
    });

    if (cicsPrograms.length > 0) {
      nodes.push({
        data: { id: 'online-layer', label: `Online Processing\n(${cicsPrograms.length} CICS Programs)`, type: 'online' }
      });
      edges.push({
        data: { id: 'entry-online', source: 'user-entry', target: 'online-layer', label: 'CICS Transaction' }
      });
    }

    if (jclJobs.length > 0) {
      nodes.push({
        data: { id: 'batch-layer', label: `Batch Processing\n(${jclJobs.length} JCL Jobs)`, type: 'batch' }
      });
      edges.push({
        data: { id: 'entry-batch', source: 'user-entry', target: 'batch-layer', label: 'Scheduled Job' }
      });
    }

    const allDb2Tables = new Set<string>();
    const allVsamDatasets = new Set<string>();
    programs.forEach(p => {
      p.db2Tables?.forEach(t => allDb2Tables.add(t));
      p.vsamDatasets?.forEach(d => allVsamDatasets.add(d));
    });

    if (allDb2Tables.size > 0 || allVsamDatasets.size > 0) {
      nodes.push({
        data: { 
          id: 'data-layer', 
          label: `Data Layer\n(${allDb2Tables.size} DB2, ${allVsamDatasets.size} VSAM)`, 
          type: 'data' 
        }
      });

      if (cicsPrograms.length > 0) {
        edges.push({
          data: { id: 'online-data', source: 'online-layer', target: 'data-layer', label: 'Read/Write' }
        });
      }
      if (jclJobs.length > 0) {
        edges.push({
          data: { id: 'batch-data', source: 'batch-layer', target: 'data-layer', label: 'Process' }
        });
      }
    }

    nodes.push({
      data: { id: 'output', label: 'Reports/\nResponses', type: 'output' }
    });

    if (cicsPrograms.length > 0) {
      edges.push({
        data: { id: 'online-output', source: 'online-layer', target: 'output', label: 'Screen Response' }
      });
    }
    if (jclJobs.length > 0) {
      edges.push({
        data: { id: 'batch-output', source: 'batch-layer', target: 'output', label: 'Reports/Files' }
      });
    }

    batchPrograms.slice(0, 3).forEach((prog, idx) => {
      nodes.push({
        data: { id: `prog-${idx}`, label: prog.name, type: 'program' }
      });
      if (jclJobs.length > 0) {
        edges.push({
          data: { id: `batch-prog-${idx}`, source: 'batch-layer', target: `prog-${idx}`, label: '' }
        });
      }
    });

    cicsPrograms.slice(0, 3).forEach((prog, idx) => {
      nodes.push({
        data: { id: `cics-${idx}`, label: prog.name, type: 'program' }
      });
      edges.push({
        data: { id: `online-cics-${idx}`, source: 'online-layer', target: `cics-${idx}`, label: '' }
      });
    });

    return { nodes, edges };
  }, [programs, jclJobs, cicsPrograms, batchPrograms]);

  const initCytoscape = useCallback(() => {
    if (!containerRef.current) return;
    
    const data = getFlowData();
    if (data.nodes.length === 0) return;

    if (cyRef.current) {
      cyRef.current.destroy();
    }

    cyRef.current = cytoscape({
      container: containerRef.current,
      elements: [...data.nodes, ...data.edges],
      style: [
        {
          selector: 'node',
          style: {
            'label': 'data(label)',
            'text-valign': 'center',
            'text-halign': 'center',
            'background-color': (ele: any) => nodeColors[ele.data('type')] || '#6B7280',
            'color': '#fff',
            'text-outline-color': '#000',
            'text-outline-width': 1,
            'font-size': '11px',
            'width': 100,
            'height': 60,
            'shape': 'round-rectangle',
            'text-wrap': 'wrap',
            'text-max-width': '90px',
            'border-width': 2,
            'border-color': '#fff'
          }
        },
        {
          selector: 'node[type="entry"]',
          style: {
            'shape': 'ellipse',
            'width': 90,
            'height': 90
          }
        },
        {
          selector: 'node[type="output"]',
          style: {
            'shape': 'ellipse',
            'width': 90,
            'height': 90
          }
        },
        {
          selector: 'node[type="program"]',
          style: {
            'width': 80,
            'height': 40,
            'font-size': '9px'
          }
        },
        {
          selector: 'edge',
          style: {
            'width': 2,
            'line-color': '#94A3B8',
            'target-arrow-color': '#94A3B8',
            'target-arrow-shape': 'triangle',
            'curve-style': 'bezier',
            'label': 'data(label)',
            'font-size': '9px',
            'text-rotation': 'autorotate',
            'text-background-color': '#fff',
            'text-background-opacity': 0.9,
            'text-background-padding': '3px'
          }
        }
      ],
      layout: {
        name: 'breadthfirst',
        directed: true,
        padding: 40,
        spacingFactor: 1.5
      }
    });
  }, [getFlowData]);

  useEffect(() => {
    setTimeout(() => initCytoscape(), 100);
  }, [initCytoscape]);

  const handleZoom = (direction: 'in' | 'out') => {
    if (cyRef.current) {
      const currentZoom = cyRef.current.zoom();
      cyRef.current.zoom(direction === 'in' ? currentZoom * 1.2 : currentZoom / 1.2);
    }
  };

  const handleFit = () => {
    if (cyRef.current) {
      cyRef.current.fit(undefined, 50);
    }
  };

  const handleExport = () => {
    if (cyRef.current) {
      const png = cyRef.current.png({ scale: 2, bg: '#fff' });
      const link = document.createElement('a');
      link.href = png;
      link.download = 'application-flow-diagram.png';
      link.click();
    }
  };

  if (programs.length === 0 && jclJobs.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Workflow className="w-5 h-5 text-indigo-600" />
            Application Flow Diagram
          </div>
          <div className="flex gap-1">
            <Button variant="outline" size="sm" onClick={() => handleZoom('in')}>
              <ZoomIn className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleZoom('out')}>
              <ZoomOut className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={handleFit}>
              <Maximize className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={handleExport}>
              <Download className="w-4 h-4" />
            </Button>
          </div>
        </CardTitle>
        <p className="text-xs text-gray-500">
          Shows how requests flow through your application from entry points to data and outputs
        </p>
      </CardHeader>
      <CardContent>
        <div 
          ref={containerRef} 
          className="w-full h-[350px] border rounded-lg bg-gray-50"
        />
        <div className="flex flex-wrap gap-3 mt-3">
          <div className="flex items-center gap-1 text-xs">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.entry }} />
            <span>Entry Point</span>
          </div>
          <div className="flex items-center gap-1 text-xs">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.online }} />
            <span>Online (CICS)</span>
          </div>
          <div className="flex items-center gap-1 text-xs">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.batch }} />
            <span>Batch (JCL)</span>
          </div>
          <div className="flex items-center gap-1 text-xs">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.program }} />
            <span>Program</span>
          </div>
          <div className="flex items-center gap-1 text-xs">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.data }} />
            <span>Data Layer</span>
          </div>
          <div className="flex items-center gap-1 text-xs">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: nodeColors.output }} />
            <span>Output</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
