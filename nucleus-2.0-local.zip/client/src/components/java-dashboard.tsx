/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Brain, 
  Code, 
  Database, 
  Settings,
  Activity,
  MessageSquareText,
  Lightbulb,
  Target,
  Info,
  Globe,
  Layers,
  Shield,
  Zap,
  TrendingUp
} from 'lucide-react';
import { type AnalysisData, type AIAnalysisResult } from '@shared/schema';
import AIProgressModal, { type AIProgressStep } from './ai-progress-modal';
import FormattedAIContent from './formatted-ai-content';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  AreaChart,
  Area,
} from 'recharts';

interface JavaDashboardProps {
  analysisData: AnalysisData;
  onAIAnalysisComplete?: (analysis: AIAnalysisResult) => void;
}

interface StatCardProps {
  title: string;
  value: number;
  trend?: string;
  icon: React.ReactNode;
  color: string;
}

function StatCard({ title, value, trend, icon, color }: StatCardProps) {
  return (
    <Card className={`border-l-4 ${color}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-3xl font-bold">{value}</p>
            {trend && <p className="text-xs text-green-600 flex items-center gap-1"><TrendingUp className="w-3 h-3" />{trend}</p>}
          </div>
          <div className={`p-3 rounded-full bg-opacity-10 ${color.replace('border-', 'bg-')}`}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

const COLORS = ['#3b82f6', '#10b981', '#8b5cf6', '#f97316'];

export default function JavaDashboard({ analysisData, onAIAnalysisComplete }: JavaDashboardProps) {
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');
  const [showProgressModal, setShowProgressModal] = useState(false);
  const [progressSteps, setProgressSteps] = useState<AIProgressStep[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [aiModel, setAiModel] = useState('OpenAI GPT-4o');

  const controllers = analysisData.classes.filter(c => c.type === 'controller');
  const services = analysisData.classes.filter(c => c.type === 'service');
  const repositories = analysisData.classes.filter(c => c.type === 'repository');
  const entities = analysisData.classes.filter(c => c.type === 'entity');

  const stats = {
    totalClasses: analysisData.classes.length,
    controllers: controllers.length,
    services: services.length,
    repositories: repositories.length,
    entities: entities.length,
    totalMethods: analysisData.classes.reduce((sum, c) => sum + (c.methods?.length || 0), 0),
    relationships: analysisData.relationships.length,
    packages: analysisData.structure.packages.length,
  };

  const avgMethodsPerClass = stats.totalClasses > 0 ? (stats.totalMethods / stats.totalClasses).toFixed(1) : '0';

  const componentDistributionData = [
    { name: 'Controllers', value: stats.controllers, fill: '#3b82f6' },
    { name: 'Services', value: stats.services, fill: '#10b981' },
    { name: 'Repositories', value: stats.repositories, fill: '#8b5cf6' },
    { name: 'Entities', value: stats.entities, fill: '#f97316' },
  ];

  const methodsPerComponentData = [
    { name: 'Controllers', avgMethods: controllers.reduce((sum, c) => sum + (c.methods?.length || 0), 0) / Math.max(controllers.length, 1) },
    { name: 'Services', avgMethods: services.reduce((sum, c) => sum + (c.methods?.length || 0), 0) / Math.max(services.length, 1) },
    { name: 'Repositories', avgMethods: repositories.reduce((sum, c) => sum + (c.methods?.length || 0), 0) / Math.max(repositories.length, 1) },
    { name: 'Entities', avgMethods: entities.reduce((sum, c) => sum + (c.methods?.length || 0), 0) / Math.max(entities.length, 1) },
  ];

  const qualityMetricsData = [
    { subject: 'Code Structure', A: 85 },
    { subject: 'Design Patterns', A: 78 },
    { subject: 'Code Quality', A: 82 },
    { subject: 'Dependencies', A: 75 },
    { subject: 'Maintainability', A: 80 },
    { subject: 'Testability', A: 70 },
  ];

  const packageMetricsData = [
    { name: 'Total Classes', value: stats.totalClasses },
    { name: 'Packages', value: stats.packages },
    { name: 'Relationships', value: stats.relationships },
    { name: 'Methods', value: stats.totalMethods },
  ];

  const qualityScore = Math.round(qualityMetricsData.reduce((sum, m) => sum + m.A, 0) / qualityMetricsData.length);

  const initializeProgressSteps = (model: string) => {
    const steps: AIProgressStep[] = [
      { id: 'init', label: 'Initializing AI Analysis', description: 'Setting up analysis parameters', status: 'pending' },
      { id: 'parsing', label: 'Parsing Java Structure', description: 'Analyzing classes and packages', status: 'pending' },
      { id: 'context', label: 'Building Context', description: 'Preparing Spring Boot context for AI', status: 'pending' },
      { id: 'overview', label: 'Generating Overview', description: 'Creating project description', status: 'pending' },
      { id: 'architecture', label: 'Analyzing Architecture', description: 'Identifying patterns and layers', status: 'pending' },
      { id: 'modules', label: 'Extracting Features', description: 'Analyzing controllers and services', status: 'pending' },
      { id: 'suggestions', label: 'Generating Recommendations', description: 'Creating actionable improvements', status: 'pending' }
    ];
    setProgressSteps(steps);
    setCurrentStep(0);
  };

  const generateAIAnalysis = async () => {
    setIsLoadingAI(true);
    
    try {
      const configResponse = await fetch('/api/ai-config');
      const configData = await configResponse.json();
      const modelName = configData.type === 'local' ? `Local LLM (${configData.model || 'Ollama'})` : 
                       configData.type === 'claude' ? 'AWS Claude 3.5 Sonnet' :
                       configData.type === 'gemini' ? 'Google Gemini Pro' :
                       'OpenAI GPT-4o';
      setAiModel(modelName);
    } catch (error) {
      setAiModel('OpenAI GPT-4o');
    }

    initializeProgressSteps(aiModel);
    setShowProgressModal(true);
    
    const progressDelays = [
      { step: 0, delay: 500 },
      { step: 1, delay: 1000 },
      { step: 2, delay: 1500 },
      { step: 3, delay: 3000 },
      { step: 4, delay: 4000 },
      { step: 5, delay: 5000 },
      { step: 6, delay: 6000 }
    ];

    progressDelays.forEach(({ step, delay }) => {
      setTimeout(() => {
        setProgressSteps(prev => prev.map((s, index) => {
          if (index < step) return { ...s, status: 'completed' as const, timestamp: new Date() };
          if (index === step) return { ...s, status: 'running' as const };
          return s;
        }));
        setCurrentStep(step);
      }, delay);
    });

    try {
      const response = await fetch('/api/projects/ai-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...analysisData, customPrompt: customPrompt.trim() || undefined }),
      });
      
      if (!response.ok) throw new Error(`Server error: ${response.status}`);
      
      const result = await response.json();
      
      setTimeout(() => {
        setProgressSteps(prev => prev.map(s => ({ ...s, status: 'completed' as const, timestamp: new Date() })));
        setCurrentStep(6);
        setTimeout(() => {
          setShowProgressModal(false);
          setAiAnalysis(result);
          if (onAIAnalysisComplete) onAIAnalysisComplete(result);
        }, 1500);
      }, 7500);
      
    } catch (error) {
      console.error('Failed to generate AI analysis:', error);
      setProgressSteps(prev => prev.map((s, index) => 
        index === currentStep ? { ...s, status: 'error' as const } : s
      ));
      setTimeout(() => {
        setShowProgressModal(false);
        setAiAnalysis({
          projectOverview: "Unable to generate AI analysis. Please check your AI configuration.",
          projectDetails: { projectDescription: "Error", projectType: "unknown", implementedFeatures: [], modulesServices: [] },
          architectureInsights: [],
          moduleInsights: {},
          suggestions: [],
          qualityScore: 0
        });
      }, 2000);
    } finally {
      setIsLoadingAI(false);
    }
  };

  useEffect(() => {
    if (analysisData.aiAnalysis) setAiAnalysis(analysisData.aiAnalysis);
  }, [analysisData]);

  return (
    <div className="p-6 space-y-6">
      <AIProgressModal
        isOpen={showProgressModal}
        onClose={() => setShowProgressModal(false)}
        steps={progressSteps}
        currentStep={currentStep}
        aiModel={aiModel}
      />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Project Dashboard</h1>
          <p className="text-muted-foreground">Comprehensive analysis and AI insights</p>
        </div>
        <Button 
          onClick={generateAIAnalysis} 
          disabled={isLoadingAI}
          className="bg-green-600 hover:bg-green-700"
        >
          <Brain className="w-4 h-4 mr-2" />
          {isLoadingAI ? 'Generating...' : 'Generate AI Insights'}
        </Button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard
          title="Total Classes"
          value={stats.totalClasses}
          trend="85%"
          icon={<Code className="w-6 h-6 text-blue-600" />}
          color="border-blue-500"
        />
        <StatCard
          title="Controllers"
          value={stats.controllers}
          trend="12%"
          icon={<Globe className="w-6 h-6 text-green-600" />}
          color="border-green-500"
        />
        <StatCard
          title="Services"
          value={stats.services}
          trend="28%"
          icon={<Settings className="w-6 h-6 text-orange-600" />}
          color="border-orange-500"
        />
        <StatCard
          title="Data Entities"
          value={stats.entities}
          trend="45%"
          icon={<Database className="w-6 h-6 text-purple-600" />}
          color="border-purple-500"
        />
      </div>

      {/* Custom Prompt Section */}
      <Card className="border-dashed border-2 border-blue-200 bg-blue-50/30">
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <MessageSquareText className="w-5 h-5 text-blue-600" />
              <Label htmlFor="custom-prompt" className="text-sm font-medium text-gray-700">
                Custom Prompt for AI Analysis (Optional)
              </Label>
            </div>
            <Textarea
              id="custom-prompt"
              placeholder="Add any specific instructions or context for the AI analysis...&#10;Example: 'Focus on security vulnerabilities and performance bottlenecks' or 'Analyze the authentication flow in detail'"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              className="min-h-[80px] bg-white"
            />
            <p className="text-xs text-muted-foreground">
              This additional context will be included when generating AI insights to provide more targeted analysis.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Main Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="architecture">Architecture</TabsTrigger>
          <TabsTrigger value="ai-insights">AI Insights</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Quality Score */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-blue-600" />
                Architecture Quality Score
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="text-4xl font-bold text-blue-600">{qualityScore}</div>
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground mb-2">Overall Score</p>
                  <Progress value={qualityScore} className="h-3" />
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>Poor</span>
                    <span>Excellent</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-4 gap-4 mt-4 pt-4 border-t">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Controllers</p>
                  <p className="font-semibold">{stats.controllers}</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Services</p>
                  <p className="font-semibold">{stats.services}</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Repositories</p>
                  <p className="font-semibold">{stats.repositories}</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Entities</p>
                  <p className="font-semibold">{stats.entities}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Project Analysis Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-green-600" />
                Project Analysis Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <p className="text-2xl font-bold text-blue-600">{stats.totalMethods}</p>
                  <p className="text-sm text-muted-foreground">Total Methods</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-2xl font-bold text-green-600">{stats.relationships}</p>
                  <p className="text-sm text-muted-foreground">Relationships</p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <p className="text-2xl font-bold text-purple-600">{stats.packages}</p>
                  <p className="text-sm text-muted-foreground">Packages</p>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <p className="text-2xl font-bold text-orange-600">{avgMethodsPerClass}</p>
                  <p className="text-sm text-muted-foreground">Avg Methods/Class</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Component Distribution Bar Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Layers className="w-5 h-5 text-blue-600" />
                  Component Distribution Chart
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={componentDistributionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value" name="Components" fill="#10b981" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Component Type Distribution Pie Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Target className="w-5 h-5 text-purple-600" />
                  Component Type Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={componentDistributionData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {componentDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Architecture Tab */}
        <TabsContent value="architecture" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Architecture Quality Metrics Radar Chart */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Settings className="w-5 h-5 text-blue-600" />
                    Architecture Quality Metrics
                  </CardTitle>
                  <Info className="w-4 h-4 text-muted-foreground cursor-help" />
                </div>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RadarChart cx="50%" cy="50%" outerRadius="80%" data={qualityMetricsData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} />
                    <Radar name="Quality Score" dataKey="A" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.6} />
                    <Legend />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Methods per Component Type */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Code className="w-5 h-5 text-green-600" />
                    Methods per Component Type
                  </CardTitle>
                  <Info className="w-4 h-4 text-muted-foreground cursor-help" />
                </div>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={methodsPerComponentData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="avgMethods" name="Avg Methods" fill="#10b981" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Package & Relationship Metrics Area Chart */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Database className="w-5 h-5 text-purple-600" />
                  Package & Relationship Metrics
                </CardTitle>
                <Info className="w-4 h-4 text-muted-foreground cursor-help" />
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={packageMetricsData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="value" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Architecture Patterns */}
          <Card>
            <CardHeader>
              <CardTitle>Architecture Patterns</CardTitle>
            </CardHeader>
            <CardContent>
              {aiAnalysis?.architectureInsights && aiAnalysis.architectureInsights.length > 0 ? (
                <div className="space-y-4">
                  {aiAnalysis.architectureInsights.map((insight, index) => (
                    <div key={index} className="p-4 bg-muted rounded-lg">
                      <FormattedAIContent content={insight} />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Brain className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Generate AI analysis to see architecture insights</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI Insights Tab */}
        <TabsContent value="ai-insights" className="space-y-6">
          {aiAnalysis ? (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5 text-purple-600" />
                    Project Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <FormattedAIContent content={aiAnalysis.projectOverview} />
                </CardContent>
              </Card>

              {aiAnalysis.projectDetails && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Project Description</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <FormattedAIContent content={aiAnalysis.projectDetails.projectDescription} />
                    </CardContent>
                  </Card>

                  {aiAnalysis.projectDetails.implementedFeatures?.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Implemented Features</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {aiAnalysis.projectDetails.implementedFeatures.map((feature, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <Zap className="w-4 h-4 text-green-600 mt-0.5" />
                              <span className="text-sm">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}

              {Object.keys(aiAnalysis.moduleInsights || {}).length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Layers className="w-5 h-5 text-blue-600" />
                      Module Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {Object.entries(aiAnalysis.moduleInsights).map(([module, insight]) => (
                        <div key={module} className="p-4 border rounded-lg">
                          <h4 className="font-semibold mb-2">{module}</h4>
                          <FormattedAIContent content={String(insight)} />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <Brain className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No AI Insights Generated Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Click "Generate AI Insights" to analyze your project with AI
                </p>
                <Button onClick={generateAIAnalysis} disabled={isLoadingAI}>
                  <Brain className="w-4 h-4 mr-2" />
                  Generate AI Insights
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Recommendations Tab */}
        <TabsContent value="recommendations" className="space-y-6">
          {aiAnalysis?.suggestions && aiAnalysis.suggestions.length > 0 ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-amber-500" />
                  AI Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {aiAnalysis.suggestions.map((suggestion, index) => (
                    <div key={index} className="p-4 border-l-4 border-amber-500 bg-amber-50 rounded-r-lg">
                      <div className="flex items-start gap-3">
                        <Badge variant="secondary" className="mt-0.5">{index + 1}</Badge>
                        <FormattedAIContent content={suggestion} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <Lightbulb className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No Recommendations Available</h3>
                <p className="text-muted-foreground mb-4">
                  Generate AI analysis to receive tailored recommendations for your project
                </p>
                <Button onClick={generateAIAnalysis} disabled={isLoadingAI}>
                  <Brain className="w-4 h-4 mr-2" />
                  Generate AI Insights
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
