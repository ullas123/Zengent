/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useState, useRef, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Loader2, Upload, FileArchive, Search, CheckCircle2,
  XCircle, Download, Globe, Database, AlertCircle,
  FileText, Trash2, Info,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// ─── Types ────────────────────────────────────────────────────────────────────

interface EndpointFinding {
  url: string;
  method: string;
  description: string;
  sourceFile: string;
}

interface SorFinding {
  sorName: string;
  endpoints: EndpointFinding[];
  files: string[];
}

interface TableFinding {
  tableName: string;
  queryType: string;
  sourceFile: string;
  exactQuery?: string;
}

interface ScanResult {
  success: boolean;
  integrationType: "API-Based" | "Query-Based" | "Both" | "None";
  zipFiles: string[];
  totalFilesScanned: number;
  scanDuration: number;
  elapsedTime: string;
  sorFindings: SorFinding[];
  tableFindings: TableFinding[];
  notFoundSors: string[];
  notFoundTables: string[];
  htmlReport: string; // base64
}

const SOR_SYSTEMS = [
  "CRPS", "Anagrafe", "Income SOR", "Triumph", "MNS",
  "GSTAR", "CM-CARS", "APA AR", "CARE", "DIG", "GAR",
];

const METHOD_COLORS: Record<string, string> = {
  GET:     "bg-blue-100 text-blue-700",
  POST:    "bg-green-100 text-green-700",
  PUT:     "bg-yellow-100 text-yellow-700",
  PATCH:   "bg-purple-100 text-purple-700",
  DELETE:  "bg-red-100 text-red-700",
  SELECT:  "bg-blue-100 text-blue-700",
  INSERT:  "bg-green-100 text-green-700",
  UPDATE:  "bg-yellow-100 text-yellow-700",
  Unknown: "bg-gray-100 text-gray-600",
};

function MethodBadge({ method }: { method: string }) {
  const cls = METHOD_COLORS[method.toUpperCase()] ?? METHOD_COLORS.Unknown;
  return <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold ${cls}`}>{method}</span>;
}

function IntTypeBadge({ type }: { type: string }) {
  const map: Record<string, string> = {
    "API-Based":   "bg-green-100 text-green-800 border-green-300",
    "Query-Based": "bg-yellow-100 text-yellow-800 border-yellow-300",
    "Both":        "bg-purple-100 text-purple-800 border-purple-300",
    "None":        "bg-gray-100 text-gray-600 border-gray-300",
  };
  return (
    <span className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg border font-bold text-sm ${map[type] ?? map.None}`}>
      {type === "API-Based" ? <Globe className="w-4 h-4" /> : <Database className="w-4 h-4" />}
      Integration Type: {type}
    </span>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function ApiScanPage() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [dragging, setDragging] = useState(false);

  // ── File management ──────────────────────────────────────────────────────

  const addFiles = useCallback((incoming: FileList | null) => {
    if (!incoming) return;
    const zips = Array.from(incoming).filter((f) => f.name.endsWith(".zip"));
    if (zips.length !== incoming.length) {
      toast({ title: "Only ZIP files accepted", description: "Non-ZIP files were skipped.", variant: "destructive" });
    }
    setFiles((prev) => {
      const existing = new Set(prev.map((f) => f.name));
      return [...prev, ...zips.filter((f) => !existing.has(f.name))];
    });
  }, [toast]);

  const removeFile = (name: string) => setFiles((prev) => prev.filter((f) => f.name !== name));
  const clearAll = () => { setFiles([]); setResult(null); };

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    addFiles(e.dataTransfer.files);
  }, [addFiles]);

  // ── Scan mutation ────────────────────────────────────────────────────────

  const scanMutation = useMutation({
    mutationFn: async () => {
      const formData = new FormData();
      files.forEach((f) => formData.append("files", f));
      const res = await fetch("/api/api-scan/scan", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Scan failed" }));
        throw new Error(err.error || "Scan failed");
      }
      return res.json() as Promise<ScanResult>;
    },
    onSuccess: (data) => {
      setResult(data);
      toast({ title: "Scan complete", description: `${data.totalFilesScanned} files scanned in ${data.elapsedTime}` });
    },
    onError: (err: Error) => {
      toast({ title: "Scan failed", description: err.message, variant: "destructive" });
    },
  });

  // ── HTML report download ─────────────────────────────────────────────────

  const downloadReport = () => {
    if (!result) return;
    const html = atob(result.htmlReport);
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `api-scan-report-${Date.now()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // ─── Render ───────────────────────────────────────────────────────────────

  const foundSors = result?.sorFindings.filter((s) => s.endpoints.length > 0 || s.files.length > 0) ?? [];
  const isApiBased  = result && (result.integrationType === "API-Based"  || result.integrationType === "Both");
  const isQueryBased = result && (result.integrationType === "Query-Based" || result.integrationType === "Both");

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">

      {/* Page header */}
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-1">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Search className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">API Scan</h1>
            <p className="text-sm text-gray-500">
              Upload ZIP repositories · Detect SOR integrations · Generate audit report
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">

        {/* ── Left panel: upload + SOR reference ── */}
        <div className="xl:col-span-1 space-y-4">

          {/* Upload area */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <FileArchive className="w-4 h-4 text-blue-500" />
                Upload ZIP Repositories
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">

              {/* Drop zone */}
              <div
                className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                  dragging ? "border-blue-500 bg-blue-50" : "border-gray-300 hover:border-blue-400 hover:bg-gray-50"
                }`}
                onDrop={onDrop}
                onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
                onDragLeave={() => setDragging(false)}
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm font-medium text-gray-600">
                  Drop ZIP files here or click to browse
                </p>
                <p className="text-xs text-gray-400 mt-1">Multiple ZIP files supported · Max 100 MB each</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".zip"
                  multiple
                  className="hidden"
                  onChange={(e) => addFiles(e.target.files)}
                />
              </div>

              {/* File list */}
              {files.length > 0 && (
                <div className="space-y-2">
                  {files.map((f) => (
                    <div key={f.name} className="flex items-center justify-between bg-gray-50 border rounded-lg px-3 py-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <FileArchive className="w-4 h-4 text-blue-500 flex-shrink-0" />
                        <span className="text-xs font-medium truncate">{f.name}</span>
                        <span className="text-xs text-gray-400 flex-shrink-0">
                          {(f.size / 1024).toFixed(0)} KB
                        </span>
                      </div>
                      <button onClick={() => removeFile(f.name)} className="ml-2 text-red-400 hover:text-red-600">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2">
                <Button
                  className="flex-1"
                  onClick={() => scanMutation.mutate()}
                  disabled={files.length === 0 || scanMutation.isPending}
                >
                  {scanMutation.isPending ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Scanning…</>
                  ) : (
                    <><Search className="w-4 h-4 mr-2" />Run Scan</>
                  )}
                </Button>
                {files.length > 0 && (
                  <Button variant="outline" onClick={clearAll} disabled={scanMutation.isPending}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* SOR reference list */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-xs font-semibold text-gray-500 uppercase tracking-wide flex items-center gap-2">
                <Info className="w-3.5 h-3.5" /> SOR Systems Scanned
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-1.5">
                {SOR_SYSTEMS.map((s) => (
                  <span key={s} className="px-2.5 py-0.5 text-xs font-medium rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                    {s}
                  </span>
                ))}
              </div>
            </CardContent>
          </Card>

        </div>

        {/* ── Right panel: results ── */}
        <div className="xl:col-span-2 space-y-4">

          {!result && !scanMutation.isPending && (
            <div className="flex flex-col items-center justify-center h-64 text-gray-400">
              <Search className="w-12 h-12 mb-3 opacity-30" />
              <p className="text-sm font-medium">Upload ZIP files and run the scan</p>
              <p className="text-xs mt-1">Results will appear here</p>
            </div>
          )}

          {scanMutation.isPending && (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <Loader2 className="w-10 h-10 animate-spin text-blue-500 mb-4" />
                <p className="font-semibold text-gray-700">Scanning repositories…</p>
                <p className="text-sm text-gray-400 mt-1">Extracting ZIPs · Detecting SOR patterns</p>
              </CardContent>
            </Card>
          )}

          {result && (
            <>
              {/* Summary bar */}
              <Card className="border-blue-200 bg-blue-50/40">
                <CardContent className="pt-4 pb-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex flex-wrap gap-3 items-center">
                      <IntTypeBadge type={result.integrationType} />
                      <Badge variant="outline">{result.totalFilesScanned} files scanned</Badge>
                      <Badge variant="outline">{result.zipFiles.length} ZIP(s)</Badge>
                      <Badge variant="outline">{result.elapsedTime}</Badge>
                    </div>
                    <Button size="sm" onClick={downloadReport}>
                      <Download className="w-4 h-4 mr-1" /> Download Report
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Tabs */}
              <Tabs defaultValue="sor">
                <TabsList className="mb-4">
                  <TabsTrigger value="sor">
                    <Globe className="w-3.5 h-3.5 mr-1.5" />
                    SOR APIs ({foundSors.length})
                  </TabsTrigger>
                  <TabsTrigger value="tables">
                    <Database className="w-3.5 h-3.5 mr-1.5" />
                    Tables ({result.tableFindings.length})
                  </TabsTrigger>
                  <TabsTrigger value="not-found">
                    <XCircle className="w-3.5 h-3.5 mr-1.5" />
                    Not Found ({result.notFoundSors.length})
                  </TabsTrigger>
                </TabsList>

                {/* SOR API tab */}
                <TabsContent value="sor">
                  {!isApiBased && (
                    <Alert>
                      <AlertCircle className="w-4 h-4" />
                      <AlertDescription>
                        Integration type is <strong>{result.integrationType}</strong> — no outbound API calls detected.
                      </AlertDescription>
                    </Alert>
                  )}
                  <div className="space-y-3">
                    {result.sorFindings
                      .filter((s) => s.endpoints.length > 0 || s.files.length > 0)
                      .map((sor) => (
                        <Card key={sor.sorName} className="border-green-200">
                          <CardHeader className="py-3 px-4 bg-green-50/60">
                            <div className="flex items-center gap-2">
                              <CheckCircle2 className="w-4 h-4 text-green-600" />
                              <span className="font-semibold text-green-800">{sor.sorName}</span>
                              <Badge className="bg-green-100 text-green-700 text-xs">
                                {sor.endpoints.length} endpoint{sor.endpoints.length !== 1 ? "s" : ""}
                              </Badge>
                            </div>
                          </CardHeader>
                          <CardContent className="px-4 py-3">
                            {sor.endpoints.length > 0 ? (
                              <div className="overflow-x-auto">
                                <table className="w-full text-xs">
                                  <thead>
                                    <tr className="border-b">
                                      <th className="text-left py-1.5 pr-3 font-semibold text-gray-500">Method</th>
                                      <th className="text-left py-1.5 pr-3 font-semibold text-gray-500">Endpoint</th>
                                      <th className="text-left py-1.5 pr-3 font-semibold text-gray-500">Description</th>
                                      <th className="text-left py-1.5 font-semibold text-gray-500">Source</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {sor.endpoints.map((e, i) => (
                                      <tr key={i} className="border-b last:border-0">
                                        <td className="py-1.5 pr-3"><MethodBadge method={e.method} /></td>
                                        <td className="py-1.5 pr-3 font-mono text-blue-700 break-all">{e.url}</td>
                                        <td className="py-1.5 pr-3 text-gray-600">{e.description}</td>
                                        <td className="py-1.5 text-gray-400 font-mono break-all">
                                          {e.sourceFile.split("/").slice(-2).join("/")}
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            ) : (
                              <p className="text-xs text-gray-500">Referenced in: {sor.files.join(", ")}</p>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    {foundSors.length === 0 && isApiBased && (
                      <p className="text-sm text-gray-500 text-center py-8">
                        API signals detected but no specific SOR endpoint URLs found in code literals.
                      </p>
                    )}
                  </div>
                </TabsContent>

                {/* Tables tab */}
                <TabsContent value="tables">
                  {!isQueryBased && (
                    <Alert>
                      <AlertCircle className="w-4 h-4" />
                      <AlertDescription>
                        Integration type is <strong>{result.integrationType}</strong> — no approved SOR table access detected.
                      </AlertDescription>
                    </Alert>
                  )}
                  {result.tableFindings.length > 0 && (
                    <Card>
                      <CardContent className="p-0">
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="bg-gray-50 border-b">
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Table</th>
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Query</th>
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Source</th>
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Excerpt</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.tableFindings.map((t, i) => (
                                <tr key={i} className="border-b last:border-0 hover:bg-gray-50">
                                  <td className="px-4 py-2 font-mono font-medium text-indigo-700">{t.tableName}</td>
                                  <td className="px-4 py-2"><MethodBadge method={t.queryType} /></td>
                                  <td className="px-4 py-2 text-gray-500 font-mono">
                                    {t.sourceFile.split("/").slice(-2).join("/")}
                                  </td>
                                  <td className="px-4 py-2 text-gray-400 font-mono max-w-xs truncate">
                                    {t.exactQuery}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                  {result.tableFindings.length === 0 && (
                    <div className="text-center py-10 text-gray-400">
                      <Database className="w-8 h-8 mx-auto mb-2 opacity-40" />
                      <p className="text-sm">No approved SOR tables found in the workspace</p>
                    </div>
                  )}
                </TabsContent>

                {/* Not found tab */}
                <TabsContent value="not-found">
                  <Card>
                    <CardContent className="pt-4 space-y-2">
                      {result.notFoundSors.map((s) => (
                        <div key={s} className="flex items-center gap-2 text-sm text-gray-500 py-1.5 border-b last:border-0">
                          <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                          No outbound API integration with <strong>{s}</strong> found
                        </div>
                      ))}
                      {result.notFoundSors.length === 0 && (
                        <p className="text-sm text-green-600 flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4" /> All SOR systems were detected
                        </p>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

              </Tabs>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
