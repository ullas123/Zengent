/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 *
 * API Scan — Two-Stage SOR Discovery (BRD Spec)
 * Features:
 *  • Upload multiple ZIPs or scan multiple GitHub repos
 *  • Application Context form (BRD spec requirement)
 *  • Stage 1 ExtractionJson download
 *  • Flow diagram (pipeline + SOR dependency)
 *  • Demographic / PII field results tab
 *  • Multi-language detection badges
 */

import { useState, useRef, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Loader2, Upload, FileArchive, Search, CheckCircle2,
  XCircle, Download, Globe, Database, AlertCircle,
  Trash2, Info, Github, GitBranch, Lock, ExternalLink,
  Plus, ShieldAlert, ChevronDown, ChevronRight,
  Workflow, FileJson, Eye, EyeOff, Building2, BrainCircuit,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// ─── Types ────────────────────────────────────────────────────────────────────

interface ApplicationContext {
  applicationName: string;
  businessFunction: string;
  domain: string;
  techStack: string;
  repositoryPath: string;
  knownSystems: string;
  complianceScope: string;
}

interface EndpointFinding {
  url: string;
  method: string;
  description: string;
  sourceFile: string;
  language?: string;
}

interface SorFinding {
  sorName: string;
  endpoints: EndpointFinding[];
  files: string[];
}

interface TableFinding {
  tableName: string;
  queryType: string;
  sourceFile: string;
  exactQuery?: string;
  language?: string;
}

interface DemographicFinding {
  fieldName: string;
  dataType: string;
  language: string;
  sourceFile: string;
  lineNumber: number;
  matchedBy: string;
}

type PipelineMode = "s12" | "s123" | "s3direct" | "compare";

interface ScanResult {
  success: boolean;
  mode?: string;
  source?: "github" | "zip" | "multi-github";
  githubUrl?: string;
  repoLabel?: string;
  repoLabels?: string[];
  branch?: string;
  downloadErrors?: string[];
  integrationType: "API-Based" | "Query-Based" | "Both" | "None";
  zipFiles: string[];
  totalFilesScanned: number;
  scanDuration: number;
  elapsedTime: string;
  languagesDetected: string[];
  sorFindings: SorFinding[];
  tableFindings: TableFinding[];
  demographicFindings: DemographicFinding[];
  unlisted_sources_found: string[];
  notFoundSors: string[];
  notFoundTables: string[];
  htmlReport: string; // base64 — S1+2 or S3 Direct report
  extractionJson: object;
  // compare mode extras
  s3HtmlReport?: string;    // base64 S3 Direct BRD
  s3ExtractionJson?: object;
  comparisonHtml?: string;  // base64 comparison report
}

interface GithubRepoEntry {
  id: string;
  url: string;
  branch: string;
  token: string;
  showToken: boolean;
}

const SOR_SYSTEMS = [
  "CRPS", "Anagrafe", "Income SOR", "Triumph", "MNS",
  "GSTAR", "CM-CARS", "APA AR", "CARE", "DIG", "GAR",
];

const LANG_COLORS: Record<string, string> = {
  "Java":      "bg-orange-100 text-orange-700 border-orange-300",
  "C#":        "bg-purple-100 text-purple-700 border-purple-300",
  "Python":    "bg-blue-100 text-blue-700 border-blue-300",
  "React-JS":  "bg-cyan-100 text-cyan-700 border-cyan-300",
  "SQL":       "bg-green-100 text-green-700 border-green-300",
  "Go":        "bg-sky-100 text-sky-700 border-sky-300",
  "Ruby":      "bg-red-100 text-red-700 border-red-300",
};

const METHOD_COLORS: Record<string, string> = {
  GET:     "bg-blue-100 text-blue-700",
  POST:    "bg-green-100 text-green-700",
  PUT:     "bg-yellow-100 text-yellow-700",
  PATCH:   "bg-purple-100 text-purple-700",
  DELETE:  "bg-red-100 text-red-700",
  SELECT:  "bg-blue-100 text-blue-700",
  INSERT:  "bg-green-100 text-green-700",
  UPDATE:  "bg-yellow-100 text-yellow-700",
  Unknown: "bg-gray-100 text-gray-600",
};

function MethodBadge({ method }: { method: string }) {
  const cls = METHOD_COLORS[method.toUpperCase()] ?? METHOD_COLORS.Unknown;
  return <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold ${cls}`}>{method}</span>;
}

function LangBadge({ lang }: { lang: string }) {
  const cls = LANG_COLORS[lang] ?? "bg-gray-100 text-gray-600 border-gray-300";
  return <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${cls}`}>{lang}</span>;
}

function IntTypeBadge({ type }: { type: string }) {
  const map: Record<string, string> = {
    "API-Based":   "bg-green-100 text-green-800 border-green-300",
    "Query-Based": "bg-yellow-100 text-yellow-800 border-yellow-300",
    "Both":        "bg-purple-100 text-purple-800 border-purple-300",
    "None":        "bg-gray-100 text-gray-600 border-gray-300",
  };
  return (
    <span className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg border font-bold text-sm ${map[type] ?? map.None}`}>
      {type === "API-Based" ? <Globe className="w-4 h-4" /> : <Database className="w-4 h-4" />}
      Integration Type: {type}
    </span>
  );
}

// ─── Pipeline Flow Diagram (React SVG) ───────────────────────────────────────

function PipelineFlowDiagram({ repos, foundSors, langs }: {
  repos: string[];
  foundSors: string[];
  langs: string[];
}) {
  const repoCount = Math.max(repos.length, 1);
  const baseHeight = 280;
  const extraHeight = Math.max(0, (foundSors.length - 5) * 30);
  const height = baseHeight + extraHeight;

  const repoY = (i: number) => 60 + i * Math.min(50, (height - 140) / repoCount);
  const midY = 60 + (repoCount - 1) * Math.min(50, (height - 140) / repoCount) / 2 + 18;

  // Clamp to not go off the SVG
  const clampedMidY = Math.max(80, Math.min(midY, height - 80));

  return (
    <svg viewBox={`0 0 860 ${height}`} className="w-full" style={{ maxHeight: height + "px" }} xmlns="http://www.w3.org/2000/svg">
      {/* Background */}
      <rect width="860" height={height} fill="#f8fafc" rx="12" />

      {/* Title */}
      <text x="430" y="22" textAnchor="middle" fontSize="12" fontWeight="700" fill="#1e3a5f">Two-Stage SOR Discovery Pipeline</text>
      <text x="430" y="38" textAnchor="middle" fontSize="9" fill="#64748b">Stage 1: Deterministic multi-language extraction  →  Stage 2: BRD narrative (rule-based, JSON-constrained)</text>

      {/* Repo boxes */}
      {repos.slice(0, 8).map((name, i) => {
        const y = repoY(i);
        const label = name.length > 18 ? name.substring(0, 16) + "…" : name;
        return (
          <g key={i}>
            <rect x="8" y={y} width="148" height="34" rx="6" fill="#dbeafe" stroke="#3b82f6" strokeWidth="1.5" />
            <text x="82" y={y + 13} textAnchor="middle" fontSize="9" fontWeight="600" fill="#1d4ed8">📦 {label}</text>
            <text x="82" y={y + 26} textAnchor="middle" fontSize="8" fill="#3b82f6">Repo / ZIP</text>
            <line x1="156" y1={y + 17} x2="188" y2={clampedMidY} stroke="#3b82f6" strokeWidth="1.5" strokeDasharray="4,2" markerEnd="url(#arr)" />
          </g>
        );
      })}

      {/* Stage 1 box */}
      <rect x="192" y={clampedMidY - 44} width="152" height="88" rx="8" fill="#dcfce7" stroke="#16a34a" strokeWidth="2" />
      <text x="268" y={clampedMidY - 22} textAnchor="middle" fontSize="11" fontWeight="700" fill="#15803d">⚙️ STAGE 1</text>
      <text x="268" y={clampedMidY - 6} textAnchor="middle" fontSize="8.5" fill="#166534">Deterministic Parser</text>
      <text x="268" y={clampedMidY + 8} textAnchor="middle" fontSize="8" fill="#166534">{langs.slice(0, 3).join(" · ") || "Multi-Language"}</text>
      <text x="268" y={clampedMidY + 22} textAnchor="middle" fontSize="8" fill="#166534">No LLM · 100% Reproducible</text>
      <text x="268" y={clampedMidY + 36} textAnchor="middle" fontSize="7.5" fill="#166534">Java · C# · Python · JS/TS · SQL</text>
      <line x1="344" y1={clampedMidY} x2="378" y2={clampedMidY} stroke="#16a34a" strokeWidth="2" markerEnd="url(#arr-g)" />

      {/* extraction.json */}
      <rect x="382" y={clampedMidY - 36} width="112" height="72" rx="8" fill="#fef9c3" stroke="#d97706" strokeWidth="1.5" />
      <text x="438" y={clampedMidY - 14} textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#854d0e">📄 extraction</text>
      <text x="438" y={clampedMidY + 2} textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#854d0e">.json</text>
      <text x="438" y={clampedMidY + 18} textAnchor="middle" fontSize="8" fill="#92400e">Stage 1 output</text>
      <text x="438" y={clampedMidY + 30} textAnchor="middle" fontSize="7.5" fill="#92400e">Git-diffable · Cached</text>
      <line x1="494" y1={clampedMidY} x2="526" y2={clampedMidY} stroke="#d97706" strokeWidth="2" markerEnd="url(#arr-a)" />

      {/* Stage 2 box */}
      <rect x="530" y={clampedMidY - 44} width="138" height="88" rx="8" fill="#ede9fe" stroke="#7c3aed" strokeWidth="2" />
      <text x="599" y={clampedMidY - 22} textAnchor="middle" fontSize="11" fontWeight="700" fill="#6d28d9">📊 STAGE 2</text>
      <text x="599" y={clampedMidY - 6} textAnchor="middle" fontSize="8.5" fill="#5b21b6">BRD Narrative</text>
      <text x="599" y={clampedMidY + 8} textAnchor="middle" fontSize="8" fill="#5b21b6">JSON-only input</text>
      <text x="599" y={clampedMidY + 22} textAnchor="middle" fontSize="8" fill="#5b21b6">No hallucination</text>
      <text x="599" y={clampedMidY + 36} textAnchor="middle" fontSize="7.5" fill="#5b21b6">Rule-based · Temp = 0</text>
      <line x1="668" y1={clampedMidY} x2="700" y2={clampedMidY} stroke="#7c3aed" strokeWidth="2" markerEnd="url(#arr-p)" />

      {/* BRD Report box */}
      <rect x="704" y={clampedMidY - 36} width="112" height="72" rx="8" fill="#fce7f3" stroke="#db2777" strokeWidth="1.5" />
      <text x="760" y={clampedMidY - 14} textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#9d174d">📑 BRD</text>
      <text x="760" y={clampedMidY + 2} textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#9d174d">HTML Report</text>
      <text x="760" y={clampedMidY + 18} textAnchor="middle" fontSize="8" fill="#be185d">SOR · Demo · Impact</text>
      <text x="760" y={clampedMidY + 30} textAnchor="middle" fontSize="7.5" fill="#be185d">Download ready</text>

      {/* SOR found badges at bottom */}
      {foundSors.length > 0 && (
        <>
          <text x="430" y={height - 70} textAnchor="middle" fontSize="9" fill="#64748b" fontWeight="600">SOR Systems Detected</text>
          {foundSors.slice(0, 8).map((sor, i) => {
            const cols = Math.min(foundSors.length, 8);
            const boxW = 74;
            const gap = 8;
            const totalW = cols * boxW + (cols - 1) * gap;
            const startX = (860 - totalW) / 2;
            const x = startX + i * (boxW + gap);
            const y = height - 54;
            return (
              <g key={sor}>
                <rect x={x} y={y} width={boxW} height="24" rx="5" fill="#dcfce7" stroke="#16a34a" strokeWidth="1.2" />
                <text x={x + boxW / 2} y={y + 16} textAnchor="middle" fontSize="9" fontWeight="600" fill="#15803d">{sor}</text>
                <line x1={x + boxW / 2} y1={y} x2="268" y2={clampedMidY + 44} stroke="#16a34a" strokeWidth="1" strokeDasharray="3,2" opacity="0.4" />
              </g>
            );
          })}
        </>
      )}

      {/* Arrow markers */}
      <defs>
        <marker id="arr"   markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L8,3 z" fill="#3b82f6"/></marker>
        <marker id="arr-g" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L8,3 z" fill="#16a34a"/></marker>
        <marker id="arr-a" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L8,3 z" fill="#d97706"/></marker>
        <marker id="arr-p" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L8,3 z" fill="#7c3aed"/></marker>
      </defs>
    </svg>
  );
}

// ─── SOR Dependency Graph ──────────────────────────────────────────────────────

function SorDependencyGraph({ sorFindings, repoNames }: {
  sorFindings: SorFinding[];
  repoNames: string[];
}) {
  const found = sorFindings.filter(s => s.endpoints.length > 0 || s.files.length > 0);
  if (found.length === 0) {
    return (
      <div className="flex items-center justify-center h-28 text-gray-400 text-sm">
        <XCircle className="w-5 h-5 mr-2 opacity-50" />
        No SOR systems detected — no dependency graph to show
      </div>
    );
  }

  const repoCount = Math.min(repoNames.length, 6);
  const sorCount  = Math.min(found.length, 11);
  const svgH = Math.max(180, Math.max(repoCount, sorCount) * 42 + 60);
  const midX = 360;

  const repoBoxes = repoNames.slice(0, 6).map((name, i) => {
    const y = 40 + i * (svgH - 80) / Math.max(repoCount - 1, 1);
    const label = name.length > 16 ? name.substring(0, 14) + "…" : name;
    return (
      <g key={i}>
        <rect x="8" y={y - 14} width="130" height="28" rx="5" fill="#dbeafe" stroke="#3b82f6" strokeWidth="1.5" />
        <text x="73" y={y + 5} textAnchor="middle" fontSize="9" fontWeight="600" fill="#1d4ed8">📦 {label}</text>
        {found.map((_, si) => {
          const sy = 40 + si * (svgH - 80) / Math.max(sorCount - 1, 1);
          return <line key={si} x1="138" y1={y} x2={midX - 70} y2={sy} stroke="#3b82f6" strokeWidth="1" strokeDasharray="4,2" opacity="0.35" />;
        })}
      </g>
    );
  });

  const sorBoxes = found.slice(0, 11).map((sor, i) => {
    const y = 40 + i * (svgH - 80) / Math.max(sorCount - 1, 1);
    const epCount = sor.endpoints.length;
    return (
      <g key={sor.sorName}>
        <rect x={midX - 60} y={y - 14} width="120" height="28" rx="5" fill="#dcfce7" stroke="#16a34a" strokeWidth="1.5" />
        <text x={midX} y={y + 5} textAnchor="middle" fontSize="9" fontWeight="700" fill="#15803d">{sor.sorName}</text>
        {epCount > 0 && (
          <>
            <rect x={midX + 62} y={y - 10} width="130" height="20" rx="4" fill="#f0fdf4" stroke="#86efac" strokeWidth="1" />
            <text x={midX + 127} y={y + 5} textAnchor="middle" fontSize="8" fill="#166534">{epCount} endpoint{epCount !== 1 ? "s" : ""}</text>
            <line x1={midX + 60} y1={y} x2={midX + 62} y2={y} stroke="#16a34a" strokeWidth="1" />
          </>
        )}
        {sor.files.length > 0 && epCount === 0 && (
          <>
            <rect x={midX + 62} y={y - 10} width="130" height="20" rx="4" fill="#eff6ff" stroke="#93c5fd" strokeWidth="1" />
            <text x={midX + 127} y={y + 5} textAnchor="middle" fontSize="8" fill="#1d4ed8">{sor.files.length} file ref{sor.files.length !== 1 ? "s" : ""}</text>
          </>
        )}
      </g>
    );
  });

  return (
    <svg viewBox={`0 0 600 ${svgH}`} className="w-full" style={{ maxHeight: svgH + "px" }}>
      <rect width="600" height={svgH} fill="#f8fafc" rx="10" />
      <text x="300" y="18" textAnchor="middle" fontSize="11" fontWeight="700" fill="#1e3a5f">SOR API Dependency Graph</text>
      <text x="73" y="32" textAnchor="middle" fontSize="8.5" fill="#64748b">Repositories</text>
      <text x={midX} y="32" textAnchor="middle" fontSize="8.5" fill="#64748b">SOR Systems Found</text>
      {repoBoxes}
      {sorBoxes}
    </svg>
  );
}

// ─── Application Context form ─────────────────────────────────────────────────

function AppContextForm({ context, onChange }: {
  context: ApplicationContext;
  onChange: (c: ApplicationContext) => void;
}) {
  const [open, setOpen] = useState(false);
  const set = (key: keyof ApplicationContext) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    onChange({ ...context, [key]: e.target.value });

  const filled = Object.values(context).some(v => v.trim() !== "");

  return (
    <Card className={filled ? "border-blue-300 bg-blue-50/30" : ""}>
      <CardContent className="pt-3 pb-3">
        <button
          className="flex w-full items-center gap-2 text-left"
          onClick={() => setOpen(o => !o)}
        >
          <Building2 className="w-4 h-4 text-blue-600 flex-shrink-0" />
          <span className="flex-1 text-sm font-semibold text-gray-700">Application Context</span>
          {filled && <Badge variant="outline" className="text-blue-600 border-blue-300 text-xs">Filled</Badge>}
          <span className="text-xs text-gray-400">(BRD requirement)</span>
          {open ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronRight className="w-4 h-4 text-gray-400" />}
        </button>

        {open && (
          <div className="mt-4 space-y-3">
            <p className="text-xs text-gray-500 bg-blue-50 border border-blue-200 rounded p-2">
              This context frames the BRD narrative (executive summary, priority calls) — it does not affect what Stage 1 extracts. Leaving blank still produces a valid technical report.
            </p>
            <div className="grid grid-cols-1 gap-3">
              <div>
                <Label className="text-xs font-medium text-gray-600">Application Name</Label>
                <Input className="mt-1 text-sm" placeholder="e.g. Card Servicing Portal" value={context.applicationName} onChange={set("applicationName")} />
              </div>
              <div>
                <Label className="text-xs font-medium text-gray-600">Business Function / Purpose</Label>
                <Input className="mt-1 text-sm" placeholder="e.g. Customer KYC verification" value={context.businessFunction} onChange={set("businessFunction")} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs font-medium text-gray-600">Domain</Label>
                  <Input className="mt-1 text-sm" placeholder="e.g. KYC, Collections" value={context.domain} onChange={set("domain")} />
                </div>
                <div>
                  <Label className="text-xs font-medium text-gray-600">Primary Tech Stack</Label>
                  <Input className="mt-1 text-sm" placeholder="e.g. Java / React-JS" value={context.techStack} onChange={set("techStack")} />
                </div>
              </div>
              <div>
                <Label className="text-xs font-medium text-gray-600">Known Upstream/Downstream Systems</Label>
                <Input className="mt-1 text-sm" placeholder="e.g. GSTAR, Triumph, MNS" value={context.knownSystems} onChange={set("knownSystems")} />
              </div>
              <div>
                <Label className="text-xs font-medium text-gray-600">Compliance / Regulatory Scope</Label>
                <Input className="mt-1 text-sm" placeholder="e.g. PCI, GDPR, KYC/AML" value={context.complianceScope} onChange={set("complianceScope")} />
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── GitHub repo entry row ────────────────────────────────────────────────────

function GithubRepoRow({
  entry,
  index,
  onChange,
  onRemove,
  canRemove,
}: {
  entry: GithubRepoEntry;
  index: number;
  onChange: (e: GithubRepoEntry) => void;
  onRemove: () => void;
  canRemove: boolean;
}) {
  const set = (key: keyof GithubRepoEntry) => (v: string) =>
    onChange({ ...entry, [key]: v });

  return (
    <div className="border rounded-lg p-3 space-y-2 bg-gray-50/50">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-gray-500">Repo {index + 1}</span>
        {canRemove && (
          <button onClick={onRemove} className="text-red-400 hover:text-red-600">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
      <div className="relative">
        <Github className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
        <Input
          className="pl-8 text-xs font-mono"
          placeholder="https://github.com/org/repo"
          value={entry.url}
          onChange={e => set("url")(e.target.value)}
        />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div className="relative">
          <GitBranch className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-gray-400" />
          <Input
            className="pl-7 text-xs"
            placeholder="Branch (auto)"
            value={entry.branch}
            onChange={e => set("branch")(e.target.value)}
          />
        </div>
        <div className="relative">
          <Lock className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-gray-400" />
          <Input
            className="pl-7 pr-12 text-xs font-mono"
            type={entry.showToken ? "text" : "password"}
            placeholder="Token (optional)"
            value={entry.token}
            onChange={e => set("token")(e.target.value)}
          />
          <button
            type="button"
            onClick={() => onChange({ ...entry, showToken: !entry.showToken })}
            className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            {entry.showToken ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function isValidGithubUrl(url: string): boolean {
  try {
    const u = new URL(url.trim());
    return u.hostname.toLowerCase().startsWith("github") && u.pathname.split("/").filter(Boolean).length >= 2;
  } catch { return false; }
}

let uidCounter = 0;
function uid() { return `repo-${++uidCounter}`; }
function emptyRepo(): GithubRepoEntry {
  return { id: uid(), url: "", branch: "", token: "", showToken: false };
}

function emptyContext(): ApplicationContext {
  return { applicationName: "", businessFunction: "", domain: "", techStack: "", repositoryPath: "", knownSystems: "", complianceScope: "" };
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function ApiScanPage() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Shared application context
  const [context, setContext] = useState<ApplicationContext>(emptyContext());

  // Pipeline mode
  const [pipelineMode, setPipelineMode] = useState<PipelineMode>("s123");

  // Custom LLM instructions (only used by s123 mode)
  const [customInstructions, setCustomInstructions] = useState("");
  const [showCustomInstructions, setShowCustomInstructions] = useState(false);

  // ZIP state
  const [files, setFiles] = useState<File[]>([]);
  const [dragging, setDragging] = useState(false);

  // GitHub multi-repo state
  const [githubRepos, setGithubRepos] = useState<GithubRepoEntry[]>([emptyRepo()]);

  // Shared result
  const [result, setResult] = useState<ScanResult | null>(null);

  // ── File management ──────────────────────────────────────────────────────

  const addFiles = useCallback((incoming: FileList | null) => {
    if (!incoming) return;
    const zips = Array.from(incoming).filter(f => f.name.endsWith(".zip"));
    if (zips.length !== incoming.length) {
      toast({ title: "Only ZIP files accepted", description: "Non-ZIP files were skipped.", variant: "destructive" });
    }
    setFiles(prev => {
      const existing = new Set(prev.map(f => f.name));
      return [...prev, ...zips.filter(f => !existing.has(f.name))];
    });
  }, [toast]);

  const removeFile = (name: string) => setFiles(prev => prev.filter(f => f.name !== name));
  const clearAll = () => { setFiles([]); setResult(null); };

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    addFiles(e.dataTransfer.files);
  }, [addFiles]);

  // ── GitHub repo management ───────────────────────────────────────────────

  const updateRepo = (id: string, updated: GithubRepoEntry) =>
    setGithubRepos(prev => prev.map(r => r.id === id ? updated : r));

  const removeRepo = (id: string) =>
    setGithubRepos(prev => prev.length > 1 ? prev.filter(r => r.id !== id) : prev);

  const addRepo = () => {
    if (githubRepos.length < 10) setGithubRepos(prev => [...prev, emptyRepo()]);
  };

  const validRepos = githubRepos.filter(r => isValidGithubUrl(r.url));

  // ── ZIP Scan mutation ────────────────────────────────────────────────────

  const zipScanMutation = useMutation({
    mutationFn: async () => {
      const formData = new FormData();
      files.forEach(f => formData.append("files", f));
      formData.append("context", JSON.stringify(context));
      formData.append("pipelineMode", pipelineMode);
      if (pipelineMode === "s123" && customInstructions.trim())
        formData.append("customInstructions", customInstructions.trim());
      const res = await fetch("/api/api-scan/scan", { method: "POST", body: formData, credentials: "include" });
      if (!res.ok) { const e = await res.json().catch(() => ({ error: "Scan failed" })); throw new Error(e.error || "Scan failed"); }
      return res.json() as Promise<ScanResult>;
    },
    onSuccess: data => {
      setResult({ ...data, source: "zip" });
      toast({ title: "✅ Scan complete", description: `${data.totalFilesScanned} files · ${data.elapsedTime} · mode: ${data.mode ?? pipelineMode}` });
    },
    onError: (err: Error) => toast({ title: "Scan failed", description: err.message, variant: "destructive" }),
  });

  // ── Multi-GitHub Scan mutation ───────────────────────────────────────────

  const githubScanMutation = useMutation({
    mutationFn: async () => {
      const repos = validRepos.map(r => ({
        githubUrl: r.url.trim(),
        branch:    r.branch.trim() || undefined,
        token:     r.token.trim()  || undefined,
      }));

      const endpoint = repos.length === 1 ? "/api/api-scan/scan-github" : "/api/api-scan/scan-multi-github";
      const extra: Record<string, string> = { pipelineMode };
      if (pipelineMode === "s123" && customInstructions.trim())
        extra.customInstructions = customInstructions.trim();

      const body = repos.length === 1
        ? { githubUrl: repos[0].githubUrl, branch: repos[0].branch, token: repos[0].token, context, ...extra }
        : { repos, context, ...extra };

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(body),
      });
      if (!res.ok) { const e = await res.json().catch(() => ({ error: "GitHub scan failed" })); throw new Error(e.error || "GitHub scan failed"); }
      return res.json() as Promise<ScanResult>;
    },
    onSuccess: data => {
      setResult({ ...data, source: validRepos.length > 1 ? "multi-github" : "github" });
      toast({
        title: "✅ GitHub scan complete",
        description: `${data.totalFilesScanned} files · ${data.elapsedTime} · mode: ${data.mode ?? pipelineMode}`,
      });
    },
    onError: (err: Error) => toast({ title: "GitHub scan failed", description: err.message, variant: "destructive" }),
  });

  const isScanning = zipScanMutation.isPending || githubScanMutation.isPending;

  // ── Downloads ────────────────────────────────────────────────────────────

  const downloadReport = () => {
    if (!result) return;
    const html = atob(result.htmlReport);
    const blob = new Blob([html], { type: "text/html" });
    const url  = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sor-brd-report-${Date.now()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadExtractionJson = () => {
    if (!result?.extractionJson) return;
    const json = JSON.stringify(result.extractionJson, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url  = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `extraction-stage1-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadS3Report = () => {
    if (!result?.s3HtmlReport) return;
    const html = atob(result.s3HtmlReport);
    const blob = new Blob([html], { type: "text/html" });
    const url  = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sor-brd-s3direct-${Date.now()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadComparisonReport = () => {
    if (!result?.comparisonHtml) return;
    const html = atob(result.comparisonHtml);
    const blob = new Blob([html], { type: "text/html" });
    const url  = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `s1-vs-s3-comparison-${Date.now()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadS3ExtractionJson = () => {
    if (!result?.s3ExtractionJson) return;
    const json = JSON.stringify(result.s3ExtractionJson, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url  = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `extraction-s3direct-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // ── Derived display values ────────────────────────────────────────────────

  const foundSors   = result?.sorFindings.filter(s => s.endpoints.length > 0 || s.files.length > 0) ?? [];
  const isApiBased  = result && (result.integrationType === "API-Based"  || result.integrationType === "Both");
  const isQueryBased = result && (result.integrationType === "Query-Based" || result.integrationType === "Both");

  // ─── Render ───────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">

      {/* Page header */}
      <div className="mb-5">
        <div className="flex items-center gap-3 mb-1">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Search className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">API Scan</h1>
            <p className="text-sm text-gray-500">
              Two-Stage SOR &amp; Demographic Discovery · Multi-Repo · Multi-Language · BRD Spec
            </p>
          </div>
        </div>

        {/* Pipeline mini-legend */}
        <div className="flex flex-wrap gap-2 mt-3 text-xs">
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-green-100 text-green-700 border border-green-300 font-medium">⚙️ Stage 1 — Deterministic Parser</span>
          <span className="text-gray-400">→</span>
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-yellow-100 text-yellow-700 border border-yellow-300 font-medium">📄 extraction.json</span>
          <span className="text-gray-400">→</span>
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-purple-100 text-purple-700 border border-purple-300 font-medium">📊 Stage 2 — BRD Narrative</span>
          <span className="text-gray-400">→</span>
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-pink-100 text-pink-700 border border-pink-300 font-medium">📑 HTML Report</span>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">

        {/* ── Left panel ── */}
        <div className="xl:col-span-1 space-y-4">

          {/* Application Context (shared across all scan modes) */}
          <AppContextForm context={context} onChange={setContext} />

          {/* Pipeline Mode Selector */}
          <Card>
            <CardContent className="pt-3 pb-3">
              <p className="text-xs font-semibold text-gray-600 mb-2.5 flex items-center gap-1.5">
                <Workflow className="w-3.5 h-3.5 text-blue-600" />
                Pipeline Mode
              </p>
              <div className="grid grid-cols-2 gap-2">
                {([
                  { mode: "s12",      icon: "⚙️",  label: "S1+2 Standard",     desc: "Deterministic parser only" },
                  { mode: "s123",     icon: "✨",  label: "S1+2+3 Enhanced",   desc: "S1+2 + AI appendix" },
                  { mode: "s3direct", icon: "🤖",  label: "S3 Direct LLM",     desc: "Code → AI → BRD report" },
                  { mode: "compare",  icon: "🔬",  label: "Compare S1 vs S3",  desc: "Side-by-side accuracy" },
                ] as { mode: PipelineMode; icon: string; label: string; desc: string }[]).map(({ mode, icon, label, desc }) => (
                  <button
                    key={mode}
                    onClick={() => setPipelineMode(mode)}
                    className={`text-left p-2.5 rounded-lg border text-xs transition-all ${
                      pipelineMode === mode
                        ? "border-blue-500 bg-blue-50 text-blue-800 shadow-sm"
                        : "border-gray-200 hover:border-blue-300 text-gray-600 hover:bg-gray-50"
                    }`}
                  >
                    <div className="font-semibold mb-0.5">{icon} {label}</div>
                    <div className={`leading-tight ${pipelineMode === mode ? "text-blue-500" : "text-gray-400"}`}>{desc}</div>
                  </button>
                ))}
              </div>
              {(pipelineMode === "s3direct" || pipelineMode === "compare") && (
                <p className="text-xs text-amber-600 mt-2 flex items-center gap-1 bg-amber-50 border border-amber-200 rounded p-1.5">
                  <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                  Requires an AI key in AI Settings. Code is sent to the LLM (up to 80 KB sampled).
                </p>
              )}
            </CardContent>
          </Card>

          {/* Source tabs */}
          <Card>
            <CardContent className="pt-4 pb-4">
              <Tabs defaultValue="zip">
                <TabsList className="w-full mb-4">
                  <TabsTrigger value="zip" className="flex-1">
                    <FileArchive className="w-3.5 h-3.5 mr-1.5" />
                    Upload ZIP{files.length > 0 && ` (${files.length})`}
                  </TabsTrigger>
                  <TabsTrigger value="github" className="flex-1">
                    <Github className="w-3.5 h-3.5 mr-1.5" />
                    GitHub{githubRepos.length > 1 && ` (${githubRepos.length})`}
                  </TabsTrigger>
                </TabsList>

                {/* ── ZIP tab ── */}
                <TabsContent value="zip" className="space-y-4 mt-0">
                  <div
                    className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                      dragging ? "border-blue-500 bg-blue-50" : "border-gray-300 hover:border-blue-400 hover:bg-gray-50"
                    }`}
                    onDrop={onDrop}
                    onDragOver={e => { e.preventDefault(); setDragging(true); }}
                    onDragLeave={() => setDragging(false)}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm font-medium text-gray-600">Drop ZIP files here or click to browse</p>
                    <p className="text-xs text-gray-400 mt-1">Multiple repos · Max 100 MB each · Up to 20 ZIPs</p>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".zip"
                      multiple
                      className="hidden"
                      onChange={e => addFiles(e.target.files)}
                    />
                  </div>

                  {files.length > 0 && (
                    <div className="space-y-1.5 max-h-48 overflow-y-auto">
                      {files.map(f => (
                        <div key={f.name} className="flex items-center justify-between bg-gray-50 border rounded-lg px-3 py-2">
                          <div className="flex items-center gap-2 min-w-0">
                            <FileArchive className="w-4 h-4 text-blue-500 flex-shrink-0" />
                            <span className="text-xs font-medium truncate">{f.name}</span>
                            <span className="text-xs text-gray-400 flex-shrink-0">{(f.size / 1024).toFixed(0)} KB</span>
                          </div>
                          <button onClick={() => removeFile(f.name)} className="ml-2 text-red-400 hover:text-red-600">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Button className="flex-1" onClick={() => zipScanMutation.mutate()} disabled={files.length === 0 || isScanning}>
                      {zipScanMutation.isPending
                        ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Scanning…</>
                        : <><Search className="w-4 h-4 mr-2" />Run Scan ({files.length} ZIP{files.length !== 1 ? "s" : ""})</>}
                    </Button>
                    {files.length > 0 && (
                      <Button variant="outline" onClick={clearAll} disabled={isScanning}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </TabsContent>

                {/* ── GitHub multi-repo tab ── */}
                <TabsContent value="github" className="space-y-3 mt-0">
                  <p className="text-xs text-gray-500 bg-blue-50 border border-blue-200 rounded p-2">
                    Add up to 10 repositories. All repos are scanned together — their files are merged for a unified SOR dependency report.
                  </p>

                  <div className="space-y-2 max-h-96 overflow-y-auto pr-0.5">
                    {githubRepos.map((repo, i) => (
                      <GithubRepoRow
                        key={repo.id}
                        entry={repo}
                        index={i}
                        onChange={updated => updateRepo(repo.id, updated)}
                        onRemove={() => removeRepo(repo.id)}
                        canRemove={githubRepos.length > 1}
                      />
                    ))}
                  </div>

                  {githubRepos.length < 10 && (
                    <Button variant="outline" className="w-full text-xs" onClick={addRepo}>
                      <Plus className="w-3.5 h-3.5 mr-1.5" />
                      Add Another Repository
                    </Button>
                  )}

                  {githubRepos.some(r => r.url && !isValidGithubUrl(r.url)) && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      One or more URLs are invalid. Format: https://github[.domain]/owner/repo
                    </p>
                  )}

                  <Button
                    className="w-full"
                    onClick={() => githubScanMutation.mutate()}
                    disabled={validRepos.length === 0 || isScanning}
                  >
                    {githubScanMutation.isPending
                      ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Cloning &amp; Scanning…</>
                      : <><Github className="w-4 h-4 mr-2" />Scan {validRepos.length} Repo{validRepos.length !== 1 ? "s" : ""} from GitHub</>}
                  </Button>
                </TabsContent>

                {/* Comparison tab — compare mode only */}
                {result.mode === "compare" && (
                  <TabsContent value="comparison">
                    <div className="space-y-4">

                      {/* Metric overview */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        {[
                          { label: "S1 APIs",       val: (result.extractionJson as any)?.api_integrations?.length ?? 0,            color: "text-blue-700",   bg: "bg-blue-50 border-blue-200" },
                          { label: "S3 APIs",        val: (result.s3ExtractionJson as any)?.api_integrations?.length ?? 0,         color: "text-purple-700", bg: "bg-purple-50 border-purple-200" },
                          { label: "S1 Tables",      val: (result.extractionJson as any)?.table_usages?.length ?? 0,               color: "text-blue-700",   bg: "bg-blue-50 border-blue-200" },
                          { label: "S3 Tables",      val: (result.s3ExtractionJson as any)?.table_usages?.length ?? 0,             color: "text-purple-700", bg: "bg-purple-50 border-purple-200" },
                          { label: "S1 PII Fields",  val: (result.extractionJson as any)?.demographic_fields_found?.length ?? 0,   color: "text-blue-700",   bg: "bg-blue-50 border-blue-200" },
                          { label: "S3 PII Fields",  val: (result.s3ExtractionJson as any)?.demographic_fields_found?.length ?? 0, color: "text-purple-700", bg: "bg-purple-50 border-purple-200" },
                        ].map(({ label, val, color, bg }) => (
                          <div key={label} className={`border rounded-lg p-3 text-center ${bg}`}>
                            <div className={`text-2xl font-bold ${color}`}>{val}</div>
                            <div className="text-xs text-gray-500 mt-0.5">{label}</div>
                          </div>
                        ))}
                      </div>

                      {/* Legend */}
                      <Card className="border-teal-200 bg-teal-50/40">
                        <CardContent className="pt-3 pb-3 space-y-1.5">
                          <p className="text-xs font-semibold text-teal-800">Reading the comparison:</p>
                          <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-gray-600">
                            <span className="flex items-center gap-1.5"><span className="px-2 py-0.5 rounded-full bg-green-100 text-green-700 font-semibold text-xs">Both</span>Agreed by S1 and S3 — highest confidence</span>
                            <span className="flex items-center gap-1.5"><span className="px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-700 font-semibold text-xs">S1 only</span>Deterministic found it; LLM missed</span>
                            <span className="flex items-center gap-1.5"><span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 font-semibold text-xs">S3 only</span>LLM found it; parser patterns may not cover it yet</span>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Download all reports */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-gray-600">Download reports:</p>
                        <div className="flex flex-wrap gap-2">
                          <Button onClick={downloadReport} className="gap-2 bg-blue-600 hover:bg-blue-700">
                            <Download className="w-4 h-4" /> S1+2 BRD Report
                          </Button>
                          <Button variant="outline" onClick={downloadS3Report} className="gap-2 border-purple-400 text-purple-700 hover:bg-purple-50">
                            <Download className="w-4 h-4" /> S3 Direct BRD Report
                          </Button>
                          <Button variant="outline" onClick={downloadComparisonReport} className="gap-2 border-teal-400 text-teal-700 hover:bg-teal-50">
                            <Download className="w-4 h-4" /> Full Comparison Report
                          </Button>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <Button variant="outline" size="sm" onClick={downloadExtractionJson} className="gap-1.5 text-blue-600 border-blue-200 hover:bg-blue-50">
                            <FileJson className="w-3.5 h-3.5" /> S1 extraction.json
                          </Button>
                          <Button variant="outline" size="sm" onClick={downloadS3ExtractionJson} className="gap-1.5 border-purple-200 text-purple-600 hover:bg-purple-50">
                            <FileJson className="w-3.5 h-3.5" /> S3 extraction.json
                          </Button>
                        </div>
                        <p className="text-xs text-gray-400 mt-1">
                          The Full Comparison Report is a standalone HTML file with side-by-side diff tables for all APIs, tables, and PII fields, plus an accuracy verdict.
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                )}
              </Tabs>
            </CardContent>
          </Card>

          {/* Custom LLM Instructions — only for s123 mode */}
          {pipelineMode === "s123" && <Card className={customInstructions.trim() ? "border-purple-300 bg-purple-50/20" : ""}>
            <CardContent className="pt-3 pb-3">
              <button
                className="flex w-full items-center gap-2 text-left"
                onClick={() => setShowCustomInstructions(o => !o)}
              >
                <BrainCircuit className="w-4 h-4 text-purple-600 flex-shrink-0" />
                <span className="flex-1 text-sm font-semibold text-gray-700">Additional LLM Instructions</span>
                {customInstructions.trim() && (
                  <Badge variant="outline" className="text-purple-600 border-purple-300 text-xs">Active</Badge>
                )}
                <span className="text-xs text-gray-400">(optional)</span>
                {showCustomInstructions
                  ? <ChevronDown className="w-4 h-4 text-gray-400" />
                  : <ChevronRight className="w-4 h-4 text-gray-400" />}
              </button>

              {showCustomInstructions && (
                <div className="mt-3 space-y-2">
                  <p className="text-xs text-gray-500 bg-purple-50 border border-purple-200 rounded p-2">
                    These instructions are passed to the LLM after Stage 1 &amp; 2 complete. Only used when an AI key is configured. The LLM will only reference facts from the extraction.json — it cannot invent findings.
                  </p>
                  <Textarea
                    className="text-sm resize-none min-h-[110px]"
                    placeholder={`e.g. "Focus on GDPR compliance gaps. Highlight any PII fields not covered by the approved SOR tables. Suggest remediation steps for each unlisted source."`}
                    value={customInstructions}
                    onChange={e => setCustomInstructions(e.target.value)}
                  />
                  {customInstructions.trim() && (
                    <button
                      className="text-xs text-red-400 hover:text-red-600 flex items-center gap-1"
                      onClick={() => setCustomInstructions("")}
                    >
                      <Trash2 className="w-3 h-3" /> Clear instructions
                    </button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>}

        </div>

        {/* ── Right panel: results ── */}
        <div className="xl:col-span-2 space-y-4">

          {!result && !isScanning && (
            <div className="flex flex-col items-center justify-center h-72 text-gray-400 bg-white rounded-xl border border-dashed border-gray-200">
              <Workflow className="w-12 h-12 mb-3 opacity-20" />
              <p className="text-sm font-medium">Upload ZIP(s) or add GitHub URL(s), then run the scan</p>
              <p className="text-xs mt-1 text-gray-300">Stage 1 → extraction.json → Stage 2 → BRD Report</p>
            </div>
          )}

          {isScanning && (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <Loader2 className="w-10 h-10 animate-spin text-blue-500 mb-4" />
                <p className="font-semibold text-gray-700">
                  {pipelineMode === "s3direct"
                    ? "Sending code to AI model (Stage 3 Direct)…"
                    : pipelineMode === "compare"
                    ? "Running S1 parser + S3 Direct LLM in parallel…"
                    : githubScanMutation.isPending
                    ? "Downloading repositories & running Stage 1 parser…"
                    : "Running Stage 1 multi-language parser…"}
                </p>
                <p className="text-sm text-gray-400 mt-1">
                  {pipelineMode === "s3direct"
                    ? "Collecting code files · Sending to AI · Generating BRD"
                    : pipelineMode === "compare"
                    ? "Deterministic extraction + LLM analysis → comparison report"
                    : "Detecting languages · Extracting SOR patterns · Scanning for PII fields"}
                </p>
                {(pipelineMode === "s12" || pipelineMode === "s123") && (
                  <div className="flex gap-2 mt-4 flex-wrap justify-center">
                    {["Java", "C#", "Python", "React-JS", "SQL", "Config"].map(l => (
                      <span key={l} className="px-2 py-0.5 bg-gray-100 rounded text-xs text-gray-500 animate-pulse">{l}</span>
                    ))}
                  </div>
                )}
                {(pipelineMode === "s3direct" || pipelineMode === "compare") && (
                  <div className="mt-4 flex gap-2">
                    <span className="px-2.5 py-1 bg-purple-100 text-purple-600 rounded text-xs animate-pulse">🤖 LLM Active</span>
                    {pipelineMode === "compare" && <span className="px-2.5 py-1 bg-green-100 text-green-600 rounded text-xs animate-pulse">⚙️ Parser Active</span>}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {result && (
            <>
              {/* Summary bar */}
              <Card className="border-blue-200 bg-blue-50/40">
                <CardContent className="pt-4 pb-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="space-y-2">
                      <div className="flex flex-wrap gap-2 items-center">
                        <IntTypeBadge type={result.integrationType} />
                        <Badge variant="outline">{result.totalFilesScanned} files</Badge>
                        <Badge variant="outline">⚡ {result.elapsedTime}</Badge>
                        {result.source === "github" && result.repoLabel && (
                          <a href={result.zipFiles[0]} target="_blank" rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-900 text-white hover:bg-gray-700 transition-colors">
                            <Github className="w-3 h-3" />{result.repoLabel}<ExternalLink className="w-3 h-3 opacity-60" />
                          </a>
                        )}
                        {result.source === "multi-github" && (
                          <Badge variant="outline"><Github className="w-3 h-3 mr-1" />{result.zipFiles.length} repos</Badge>
                        )}
                        {result.source === "zip" && (
                          <Badge variant="outline"><FileArchive className="w-3 h-3 mr-1" />{result.zipFiles.length} ZIP{result.zipFiles.length !== 1 ? "s" : ""}</Badge>
                        )}
                      </div>
                      {/* Language badges */}
                      {result.languagesDetected.length > 0 && (
                        <div className="flex flex-wrap gap-1.5">
                          <span className="text-xs text-gray-400">Languages:</span>
                          {result.languagesDetected.map(l => <LangBadge key={l} lang={l} />)}
                        </div>
                      )}
                      {/* Download errors */}
                      {result.downloadErrors && result.downloadErrors.length > 0 && (
                        <p className="text-xs text-amber-600 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {result.downloadErrors.length} repo(s) failed to download
                        </p>
                      )}
                    </div>
                    <div className="flex flex-col gap-2">
                      <Button size="sm" onClick={downloadReport}>
                        <Download className="w-4 h-4 mr-1" />
                        {result.mode === "compare" ? "S1+2 BRD" : result.mode === "s3direct" ? "S3 Direct BRD" : "BRD Report"}
                      </Button>
                      {result.mode === "compare" && (
                        <Button size="sm" variant="outline" onClick={downloadS3Report} className="border-purple-300 text-purple-700 hover:bg-purple-50">
                          <Download className="w-4 h-4 mr-1" /> S3 Direct BRD
                        </Button>
                      )}
                      {result.mode === "compare" && (
                        <Button size="sm" variant="outline" onClick={downloadComparisonReport} className="border-teal-300 text-teal-700 hover:bg-teal-50">
                          <Download className="w-4 h-4 mr-1" /> Comparison
                        </Button>
                      )}
                      <Button size="sm" variant="outline" onClick={downloadExtractionJson}>
                        <FileJson className="w-4 h-4 mr-1" />
                        {result.mode === "compare" ? "S1 JSON" : "extraction.json"}
                      </Button>
                      {result.mode === "compare" && (
                        <Button size="sm" variant="outline" onClick={downloadS3ExtractionJson} className="border-purple-200 text-purple-600 hover:bg-purple-50">
                          <FileJson className="w-4 h-4 mr-1" /> S3 JSON
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Mode badge */}
              {result.mode && (
                <div className="flex gap-2 flex-wrap">
                  {result.mode === "s12"      && <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700 border border-green-300">⚙️ S1+2 Standard</span>}
                  {result.mode === "s123"     && <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-700 border border-purple-300">✨ S1+2+3 Enhanced</span>}
                  {result.mode === "s3direct" && <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-700 border border-indigo-300">🤖 S3 Direct LLM</span>}
                  {result.mode === "compare"  && <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-teal-100 text-teal-700 border border-teal-300">🔬 Compare S1 vs S3</span>}
                </div>
              )}

              {/* Results tabs */}
              <Tabs defaultValue="sor">
                <TabsList className="mb-4 flex-wrap h-auto">
                  <TabsTrigger value="sor">
                    <Globe className="w-3.5 h-3.5 mr-1.5" />SOR APIs ({foundSors.length})
                  </TabsTrigger>
                  <TabsTrigger value="tables">
                    <Database className="w-3.5 h-3.5 mr-1.5" />Tables ({result.tableFindings.length})
                  </TabsTrigger>
                  <TabsTrigger value="demographics">
                    <ShieldAlert className="w-3.5 h-3.5 mr-1.5" />PII Fields ({result.demographicFindings?.length ?? 0})
                  </TabsTrigger>
                  <TabsTrigger value="flow">
                    <Workflow className="w-3.5 h-3.5 mr-1.5" />Flow Diagrams
                  </TabsTrigger>
                  <TabsTrigger value="not-found">
                    <XCircle className="w-3.5 h-3.5 mr-1.5" />Not Found ({result.notFoundSors.length})
                  </TabsTrigger>
                  {result.mode === "compare" && (
                    <TabsTrigger value="comparison">
                      <BrainCircuit className="w-3.5 h-3.5 mr-1.5" />S1 vs S3 Comparison
                    </TabsTrigger>
                  )}
                </TabsList>

                {/* SOR API tab */}
                <TabsContent value="sor">
                  {!isApiBased && (
                    <Alert className="mb-3">
                      <AlertCircle className="w-4 h-4" />
                      <AlertDescription>Integration type is <strong>{result.integrationType}</strong> — no outbound API calls detected.</AlertDescription>
                    </Alert>
                  )}
                  <div className="space-y-3">
                    {foundSors.map(sor => (
                      <Card key={sor.sorName} className="border-green-200">
                        <CardHeader className="py-3 px-4 bg-green-50/60">
                          <div className="flex items-center gap-2 flex-wrap">
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                            <span className="font-semibold text-green-800">{sor.sorName}</span>
                            <Badge className="bg-green-100 text-green-700 text-xs">
                              {sor.endpoints.length} endpoint{sor.endpoints.length !== 1 ? "s" : ""}
                            </Badge>
                            {sor.files.length > 0 && (
                              <Badge variant="outline" className="text-xs">{sor.files.length} file ref{sor.files.length !== 1 ? "s" : ""}</Badge>
                            )}
                            {/* Language badges from endpoints */}
                            {[...new Set(sor.endpoints.map(e => e.language).filter(Boolean))].map(l =>
                              <LangBadge key={l} lang={l!} />
                            )}
                          </div>
                        </CardHeader>
                        <CardContent className="px-4 py-3">
                          {sor.endpoints.length > 0 ? (
                            <div className="overflow-x-auto">
                              <table className="w-full text-xs">
                                <thead>
                                  <tr className="border-b">
                                    <th className="text-left py-1.5 pr-3 font-semibold text-gray-500">Method</th>
                                    <th className="text-left py-1.5 pr-3 font-semibold text-gray-500">Endpoint</th>
                                    <th className="text-left py-1.5 pr-3 font-semibold text-gray-500">Lang</th>
                                    <th className="text-left py-1.5 font-semibold text-gray-500">Source</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {sor.endpoints.map((e, i) => (
                                    <tr key={i} className="border-b last:border-0">
                                      <td className="py-1.5 pr-3"><MethodBadge method={e.method} /></td>
                                      <td className="py-1.5 pr-3 font-mono text-blue-700 break-all">{e.url}</td>
                                      <td className="py-1.5 pr-3">{e.language && <LangBadge lang={e.language} />}</td>
                                      <td className="py-1.5 text-gray-400 font-mono break-all">{e.sourceFile.split("/").slice(-2).join("/")}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          ) : (
                            <p className="text-xs text-gray-500">
                              Referenced in: {sor.files.slice(0, 3).map(f => f.split("/").slice(-2).join("/")).join(", ")}
                            </p>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                    {foundSors.length === 0 && isApiBased && (
                      <p className="text-sm text-gray-500 text-center py-8">API signals detected but no specific SOR endpoint URLs found in code literals.</p>
                    )}
                    {foundSors.length === 0 && !isApiBased && (
                      <p className="text-sm text-gray-500 text-center py-8">No SOR API integrations found.</p>
                    )}
                  </div>
                </TabsContent>

                {/* Tables tab */}
                <TabsContent value="tables">
                  {!isQueryBased && (
                    <Alert className="mb-3">
                      <AlertCircle className="w-4 h-4" />
                      <AlertDescription>Integration type is <strong>{result.integrationType}</strong> — no approved SOR table access detected.</AlertDescription>
                    </Alert>
                  )}
                  {result.tableFindings.length > 0 && (
                    <Card>
                      <CardContent className="p-0">
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="bg-gray-50 border-b">
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Table</th>
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Query</th>
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Lang</th>
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Source</th>
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Excerpt</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.tableFindings.map((t, i) => (
                                <tr key={i} className="border-b last:border-0 hover:bg-gray-50">
                                  <td className="px-4 py-2 font-mono font-medium text-indigo-700">{t.tableName}</td>
                                  <td className="px-4 py-2"><MethodBadge method={t.queryType} /></td>
                                  <td className="px-4 py-2">{t.language && <LangBadge lang={t.language} />}</td>
                                  <td className="px-4 py-2 text-gray-500 font-mono">{t.sourceFile.split("/").slice(-2).join("/")}</td>
                                  <td className="px-4 py-2 text-gray-400 font-mono max-w-xs truncate">{t.exactQuery}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                  {result.tableFindings.length === 0 && (
                    <div className="text-center py-10 text-gray-400">
                      <Database className="w-8 h-8 mx-auto mb-2 opacity-40" />
                      <p className="text-sm">No approved SOR tables found in the workspace</p>
                    </div>
                  )}
                </TabsContent>

                {/* PII / Demographic tab */}
                <TabsContent value="demographics">
                  {(result.demographicFindings?.length ?? 0) > 0 ? (
                    <Card>
                      <CardContent className="p-0">
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="bg-gray-50 border-b">
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Field / PII Category</th>
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Data Type</th>
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Language</th>
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Source File</th>
                                <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Line #</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.demographicFindings.map((d, i) => (
                                <tr key={i} className="border-b last:border-0 hover:bg-red-50/20">
                                  <td className="px-4 py-2 font-medium text-red-700 flex items-center gap-1.5">
                                    <ShieldAlert className="w-3 h-3 text-red-400 flex-shrink-0" />
                                    {d.fieldName}
                                  </td>
                                  <td className="px-4 py-2 font-mono text-gray-600">{d.dataType}</td>
                                  <td className="px-4 py-2"><LangBadge lang={d.language} /></td>
                                  <td className="px-4 py-2 text-gray-500 font-mono">{d.sourceFile.split("/").slice(-2).join("/")}</td>
                                  <td className="px-4 py-2 text-gray-400">{d.lineNumber}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CardContent>
                    </Card>
                  ) : (
                    <div className="text-center py-10 text-gray-400">
                      <ShieldAlert className="w-8 h-8 mx-auto mb-2 opacity-40" />
                      <p className="text-sm">No PII / demographic fields detected in the scanned files</p>
                    </div>
                  )}

                  {/* Unlisted sources */}
                  {(result.unlisted_sources_found?.length ?? 0) > 0 && (
                    <Card className="mt-3 border-amber-200">
                      <CardHeader className="py-3 px-4 bg-amber-50/60">
                        <CardTitle className="text-xs font-semibold text-amber-700 flex items-center gap-1.5">
                          <AlertCircle className="w-3.5 h-3.5" />
                          Unlisted External Sources ({result.unlisted_sources_found.length})
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="px-4 py-3">
                        <p className="text-xs text-gray-500 mb-2">HTTP calls found that don't match any known SOR pattern:</p>
                        <div className="space-y-1 max-h-40 overflow-y-auto">
                          {result.unlisted_sources_found.slice(0, 20).map((s, i) => (
                            <p key={i} className="text-xs font-mono text-amber-700 truncate">{s}</p>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>

                {/* Flow Diagrams tab */}
                <TabsContent value="flow">
                  <div className="space-y-4">
                    {/* Pipeline */}
                    <Card>
                      <CardHeader className="py-3 px-4 bg-gray-50 border-b">
                        <CardTitle className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                          <Workflow className="w-4 h-4 text-blue-600" />
                          Two-Stage Discovery Pipeline
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-4">
                        <PipelineFlowDiagram
                          repos={result.zipFiles}
                          foundSors={foundSors.map(s => s.sorName)}
                          langs={result.languagesDetected}
                        />
                        <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                          <div className="bg-green-50 border border-green-200 rounded p-2">
                            <div className="font-semibold text-green-700 mb-1">⚙️ Stage 1</div>
                            <div className="text-green-600">Deterministic · No LLM · Same code = same JSON every run</div>
                          </div>
                          <div className="bg-yellow-50 border border-yellow-200 rounded p-2">
                            <div className="font-semibold text-yellow-700 mb-1">📄 extraction.json</div>
                            <div className="text-yellow-600">Git-diffable · Cacheable · Download button above</div>
                          </div>
                          <div className="bg-purple-50 border border-purple-200 rounded p-2">
                            <div className="font-semibold text-purple-700 mb-1">📊 Stage 2</div>
                            <div className="text-purple-600">JSON-only input · No hallucination · No model drift</div>
                          </div>
                          <div className="bg-pink-50 border border-pink-200 rounded p-2">
                            <div className="font-semibold text-pink-700 mb-1">📑 BRD Report</div>
                            <div className="text-pink-600">HTML · All 11 BRD sections · Provenance footer</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* SOR Dependency graph */}
                    <Card>
                      <CardHeader className="py-3 px-4 bg-gray-50 border-b">
                        <CardTitle className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                          <Globe className="w-4 h-4 text-green-600" />
                          SOR API Dependency Graph
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-4">
                        <SorDependencyGraph sorFindings={result.sorFindings} repoNames={result.zipFiles} />
                      </CardContent>
                    </Card>

                    {/* API function call dependency table */}
                    {foundSors.length > 0 && (
                      <Card>
                        <CardHeader className="py-3 px-4 bg-gray-50 border-b">
                          <CardTitle className="text-sm font-semibold text-gray-700">
                            API Function Call Dependency Map
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                          <div className="overflow-x-auto">
                            <table className="w-full text-xs">
                              <thead>
                                <tr className="bg-gray-50 border-b">
                                  <th className="text-left px-4 py-2.5 font-semibold text-gray-500">SOR System</th>
                                  <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Endpoints Found</th>
                                  <th className="text-left px-4 py-2.5 font-semibold text-gray-500">File References</th>
                                  <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Languages</th>
                                  <th className="text-left px-4 py-2.5 font-semibold text-gray-500">Call Type</th>
                                </tr>
                              </thead>
                              <tbody>
                                {result.sorFindings.map(sor => (
                                  <tr key={sor.sorName} className={`border-b last:border-0 ${sor.endpoints.length > 0 || sor.files.length > 0 ? "hover:bg-green-50/20" : "opacity-40"}`}>
                                    <td className="px-4 py-2 font-semibold">
                                      {sor.endpoints.length > 0 || sor.files.length > 0
                                        ? <span className="text-green-700 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" />{sor.sorName}</span>
                                        : <span className="text-gray-400 flex items-center gap-1"><XCircle className="w-3 h-3" />{sor.sorName}</span>}
                                    </td>
                                    <td className="px-4 py-2 text-gray-600">{sor.endpoints.length}</td>
                                    <td className="px-4 py-2 text-gray-600">{sor.files.length}</td>
                                    <td className="px-4 py-2">
                                      <div className="flex flex-wrap gap-1">
                                        {[...new Set(sor.endpoints.map(e => e.language).filter(Boolean))].map(l => <LangBadge key={l} lang={l!} />)}
                                      </div>
                                    </td>
                                    <td className="px-4 py-2">
                                      {sor.endpoints.length > 0
                                        ? <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded text-xs font-medium">Outbound HTTP</span>
                                        : sor.files.length > 0
                                        ? <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs font-medium">File Reference</span>
                                        : <span className="px-2 py-0.5 bg-gray-100 text-gray-500 rounded text-xs">Not Found</span>}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                </TabsContent>

                {/* Not found tab */}
                <TabsContent value="not-found">
                  <Card>
                    <CardContent className="pt-4 space-y-2">
                      {result.notFoundSors.map(s => (
                        <div key={s} className="flex items-center gap-2 text-sm text-gray-500 py-1.5 border-b last:border-0">
                          <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                          No outbound API integration with <strong>{s}</strong> found
                        </div>
                      ))}
                      {result.notFoundSors.length === 0 && (
                        <p className="text-sm text-green-600 flex items-center gap-2 py-2">
                          <CheckCircle2 className="w-4 h-4" /> All SOR systems were detected
                        </p>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

              </Tabs>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
