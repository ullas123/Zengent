/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useState } from "react";
import { Link } from "wouter";
import sdlcMapImage from "@assets/sdlc_full_map_v2.png";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import {
  Play, Download, ZoomIn, X, ChevronRight, CheckCircle,
  Terminal, BookOpen, Key, Sparkles, ArrowRight, Code,
  Bot, Layers, TrendingUp, Clock, Zap, FileText, BrainCircuit,
  Users, Star, Radio
} from "lucide-react";

// ── Agent data ────────────────────────────────────────────────────────────────
const AGENTS = [
  { id:"A01", emoji:"🎯", name:"SDLC Orchestrator",        domain:"Control",      accent:"#EC4899",
    story: "The conductor. Before any code is written, A01 maps your entire delivery — stage gates, dependencies, risks. It hands every downstream agent exactly what it needs." },
  { id:"A02", emoji:"⚖️", name:"Policy & Compliance",     domain:"Control",      accent:"#EF4444",
    story: "The guardian. Checks every artefact against GDPR, PCI-DSS, SOX and HIPAA before anything moves forward. Compliance is baked in, not bolted on." },
  { id:"A03", emoji:"📚", name:"Knowledge / RAG",          domain:"Control",      accent:"#06B6D4",
    story: "The librarian. Pulls patterns, decisions and context from Confluence, SharePoint and past projects — so your agents never start from zero." },
  { id:"A04", emoji:"👤", name:"Human Approval",           domain:"Control",      accent:"#F59E0B",
    story: "The checkpoint. Formats architecture sign-offs, CAB requests and PO acceptance for the right people at the right moment. Humans stay in control." },
  { id:"A05", emoji:"📊", name:"Eval & Telemetry",         domain:"Control",      accent:"#A855F7",
    story: "The scorekeeper. Measures quality across the pipeline in real time. Catches drift before it becomes debt." },
  { id:"A06", emoji:"📋", name:"Req Intelligence",         domain:"Requirements", accent:"#3B82F6",
    story: "The translator. Turns stakeholder conversations into INVEST-format epics, user stories, NFRs and a full traceability matrix — in minutes." },
  { id:"A07", emoji:"🎨", name:"Experience Design",        domain:"Requirements", accent:"#3B82F6",
    story: "The designer. Produces wireframe specs, WCAG accessibility requirements and Gherkin BDD scenarios straight from requirements — no separate design sprint needed." },
  { id:"A08", emoji:"🏗️", name:"Solution Architecture",  domain:"Architecture", accent:"#10B981",
    story: "The architect. Generates HLDs, LLDs, OpenAPI contracts and Architecture Decision Records with Extended Thinking — it reasons through trade-offs before it writes a word." },
  { id:"A09", emoji:"💻", name:"Eng Delivery",             domain:"Development",  accent:"#A855F7",
    story: "The builder. Writes production-grade backend and frontend code, DB schemas and READMEs — wired to your chosen tech stack, not a generic template." },
  { id:"A10", emoji:"🔄", name:"Code Modernisation",       domain:"Development",  accent:"#A855F7",
    story: "The renovator. Takes COBOL, Java 8 or legacy Python and produces a full modernisation plan plus migrated code. Your technical debt has a resolution date." },
  { id:"A11", emoji:"🔍", name:"Code Quality",             domain:"Development",  accent:"#A855F7",
    story: "The reviewer. Scans every line for CWE/OWASP vulnerabilities, complexity violations and merge-readiness — before a human reviewer ever opens the PR." },
  { id:"A12", emoji:"🧪", name:"Test Engineering",         domain:"Testing",      accent:"#F59E0B",
    story: "The tester. Generates unit tests, integration tests and full BDD suites from the code A09 wrote. Coverage isn't an afterthought — it's part of the pipeline." },
  { id:"A13", emoji:"🛡️", name:"Quality & Security",      domain:"Testing",      accent:"#F59E0B",
    story: "The auditor. Runs DAST/SAST simulation, builds a performance test plan and produces a CVE vulnerability report — all before a single line hits production." },
  { id:"A14", emoji:"🚀", name:"Release Engineering",      domain:"Release",      accent:"#EF4444",
    story: "The launcher. Produces GitHub Actions / Jenkins pipelines, Terraform IaC, canary configs and your CAB pack. From code to cloud with zero manual scripting." },
  { id:"A15", emoji:"⚙️", name:"RunOps & Enhancement",    domain:"RunOps",       accent:"#06B6D4",
    story: "The operator. When incidents happen A15 produces the RCA document, updates the runbook and adds an item to the enhancement backlog — all from a single alert." },
];

const DOMAIN_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  Control:      { bg: "bg-pink-50",   text: "text-pink-700",   border: "border-pink-200" },
  Requirements: { bg: "bg-blue-50",   text: "text-blue-700",   border: "border-blue-200" },
  Architecture: { bg: "bg-green-50",  text: "text-green-700",  border: "border-green-200" },
  Development:  { bg: "bg-purple-50", text: "text-purple-700", border: "border-purple-200" },
  Testing:      { bg: "bg-amber-50",  text: "text-amber-700",  border: "border-amber-200" },
  Release:      { bg: "bg-red-50",    text: "text-red-700",    border: "border-red-200" },
  RunOps:       { bg: "bg-cyan-50",   text: "text-cyan-700",   border: "border-cyan-200" },
};

// ── Banking Demo — Customer Demographic Migration ─────────────────────────────

const BEFORE_CODE = {
  identity: `// ─── BEFORE: Two separate legacy tables ─────────────────────────────
// File: src/main/java/com/bank/model/CustomerIdentity.java

package com.bank.customer.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "CUST_IDENTITY")
public class CustomerIdentity {

    @Id
    @Column(name = "CUST_ID", length = 20, updatable = false)
    private String customerId;

    @Column(name = "FIRST_NM", nullable = false, length = 50)
    private String firstName;

    @Column(name = "LAST_NM", nullable = false, length = 50)
    private String lastName;

    @Column(name = "DT_OF_BIRTH", nullable = false)
    private LocalDate dateOfBirth;

    // getters / setters omitted
}`,
  tax: `// File: src/main/java/com/bank/model/CustomerTaxInfo.java

package com.bank.customer.model;

import javax.persistence.*;

@Entity
@Table(name = "CUST_TAX_INFO")
public class CustomerTaxInfo {

    @Id
    @Column(name = "CUST_ID", length = 20)
    private String customerId;

    // SSN or EIN — stored in a SEPARATE table
    @Column(name = "TAX_ID_NUM", length = 11)
    private String taxId;

    @Column(name = "TAX_TYPE_CD", length = 3)
    private String taxType;   // "SSN" | "EIN"

    // getters / setters omitted
}`,
  service: `// File: src/main/java/com/bank/service/CustomerService.java
// ⚠️  Problem: Two repository calls + manual JOIN for every profile fetch

@Service
public class CustomerService {

    @Autowired private CustomerIdentityRepository identityRepo;
    @Autowired private CustomerTaxInfoRepository  taxInfoRepo;

    public CustomerProfileDto getProfile(String customerId) {

        // Call 1 — fetch identity row
        CustomerIdentity identity = identityRepo.findById(customerId)
            .orElseThrow(() -> new CustomerNotFoundException(customerId));

        // Call 2 — fetch tax row (may not exist for legacy records)
        CustomerTaxInfo taxInfo = taxInfoRepo.findById(customerId)
            .orElse(null);

        // Manual assembly — error-prone, no single source of truth
        return CustomerProfileDto.builder()
            .customerId(identity.getCustomerId())
            .firstName(identity.getFirstName())
            .lastName(identity.getLastName())
            .dateOfBirth(identity.getDateOfBirth())
            .taxId(taxInfo != null ? taxInfo.getTaxId() : null)
            .taxType(taxInfo != null ? taxInfo.getTaxType() : null)
            .build();
    }
}`
};

const AFTER_CODE = {
  entity: `// ─── AFTER: Single unified table — generated by A10 ─────────────────
// File: src/main/java/com/bank/model/CustomerDemographics.java

package com.bank.customer.model;

import javax.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "CUSTOMER_DEMOGRAPHICS",
    indexes = {
        @Index(name = "idx_cust_tax_id",  columnList = "TAX_ID_NUM"),
        @Index(name = "idx_cust_dob",     columnList = "DT_OF_BIRTH")
    })
public class CustomerDemographics {

    @Id
    @Column(name = "CUST_ID", length = 20, updatable = false, nullable = false)
    private String customerId;

    @Column(name = "FIRST_NM", nullable = false, length = 50)
    private String firstName;

    @Column(name = "LAST_NM", nullable = false, length = 50)
    private String lastName;

    @Column(name = "DT_OF_BIRTH", nullable = false)
    private LocalDate dateOfBirth;

    @Column(name = "TAX_ID_NUM", unique = true, length = 11)
    private String taxId;            // SSN or EIN

    @Column(name = "TAX_TYPE_CD", length = 3)
    private String taxType;          // "SSN" | "EIN"

    @CreationTimestamp
    @Column(name = "MIGRATED_AT", updatable = false)
    private LocalDateTime migratedAt;

    @Version
    @Column(name = "VERSION")
    private Long version;            // Optimistic locking

    // getters / setters omitted
}`,
  service: `// File: src/main/java/com/bank/service/CustomerService.java
// ✅  After: Single repository call, no manual JOIN

@Service
public class CustomerService {

    @Autowired
    private CustomerDemographicsRepository demographicsRepo;

    public CustomerDemographics getProfile(String customerId) {
        return demographicsRepo.findById(customerId)
            .orElseThrow(() -> new CustomerNotFoundException(customerId));
        // Name, DOB, Tax ID all returned in one row — no assembly needed
    }

    public Optional<CustomerDemographics> findByTaxId(String taxId) {
        return demographicsRepo.findByTaxId(taxId);
    }
}`,
  migration: `-- File: src/main/resources/db/migration/V3__consolidate_customer_demographics.sql
-- Flyway migration — generated by A10 Code Modernisation

-- Step 1: Create the unified table
CREATE TABLE CUSTOMER_DEMOGRAPHICS (
    CUST_ID      VARCHAR(20)  NOT NULL PRIMARY KEY,
    FIRST_NM     VARCHAR(50)  NOT NULL,
    LAST_NM      VARCHAR(50)  NOT NULL,
    DT_OF_BIRTH  DATE         NOT NULL,
    TAX_ID_NUM   VARCHAR(11)  UNIQUE,
    TAX_TYPE_CD  VARCHAR(3),
    MIGRATED_AT  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    VERSION      BIGINT       DEFAULT 0,
    CONSTRAINT chk_tax_type CHECK (TAX_TYPE_CD IN ('SSN','EIN'))
);

-- Step 2: Migrate data — LEFT JOIN preserves records without tax info
INSERT INTO CUSTOMER_DEMOGRAPHICS
    (CUST_ID, FIRST_NM, LAST_NM, DT_OF_BIRTH, TAX_ID_NUM, TAX_TYPE_CD)
SELECT
    ci.CUST_ID,
    ci.FIRST_NM,
    ci.LAST_NM,
    ci.DT_OF_BIRTH,
    ct.TAX_ID_NUM,
    ct.TAX_TYPE_CD
FROM      CUST_IDENTITY ci
LEFT JOIN CUST_TAX_INFO ct ON ci.CUST_ID = ct.CUST_ID;

-- Step 3: Validate row counts before dropping old tables
DO $$
BEGIN
    IF (SELECT COUNT(*) FROM CUSTOMER_DEMOGRAPHICS) <
       (SELECT COUNT(*) FROM CUST_IDENTITY) THEN
        RAISE EXCEPTION 'Migration row count mismatch — aborting';
    END IF;
END $$;

-- Step 4: Archive (not drop) old tables for 90-day rollback window
ALTER TABLE CUST_IDENTITY  RENAME TO CUST_IDENTITY_ARCHIVED_2025;
ALTER TABLE CUST_TAX_INFO  RENAME TO CUST_TAX_INFO_ARCHIVED_2025;`
};

const DEMO_AGENT_OUTPUTS = [
  {
    agent: "A06 — Req Intelligence",
    color: "#3B82F6",
    label: "Migration User Story",
    output: `EPIC-042: Customer Demographic Data Consolidation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
US-042-01: As a retail banking backend service,
I need all customer demographic data (Name, DOB, ID, Tax ID)
in a single CUSTOMER_DEMOGRAPHICS table,
So that profile lookups require one database call
and PII audit surface is minimised.

Acceptance Criteria:
  ✓ CUSTOMER_DEMOGRAPHICS table contains CUST_ID, FIRST_NM,
    LAST_NM, DT_OF_BIRTH, TAX_ID_NUM, TAX_TYPE_CD
  ✓ All rows from CUST_IDENTITY migrated with zero data loss
  ✓ TAX_ID_NUM from CUST_TAX_INFO merged via LEFT JOIN
  ✓ MIGRATED_AT timestamp recorded per row for audit trail
  ✓ Legacy tables archived (not dropped) for 90-day rollback
  ✓ All existing CustomerService API contracts unchanged
  ✓ PII fields encrypted at rest — AES-256 on TAX_ID_NUM
  ✓ GDPR right-to-erasure handled via single-row delete

NFR-001: Profile fetch p99 latency < 50ms (was 120ms with JOIN)
NFR-002: Zero downtime migration — blue/green deployment
NFR-003: Full audit log of migration in MIGRATION_AUDIT table`
  },
  {
    agent: "A08 — Solution Architecture",
    color: "#10B981",
    label: "ADR-007",
    output: `ADR-007: Consolidate Customer Demographics into Single Table
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Status: Accepted | Author: A08 Solution Architecture Agent

Context:
  CUST_IDENTITY and CUST_TAX_INFO were created in 2007 under
  different ownership (Identity team vs. Tax Compliance team).
  Today every customer profile query performs an implicit JOIN,
  adding ~70ms latency and creating two separate PII audit surfaces
  for GDPR / CCPA / DPDPA compliance scans.

Decision:
  Merge both tables into CUSTOMER_DEMOGRAPHICS.
  Use Flyway V3 migration script with LEFT JOIN to preserve
  records that have identity but no tax info (legacy accounts).

Alternatives Considered:
  Option A — JPA @OneToOne: Keeps two tables, hides JOIN in ORM.
             Rejected: JOIN cost remains, two PII surfaces remain.
  Option B — View/Materialized View: Read-only, cannot write.
             Rejected: Adds complexity without solving root cause.
  Option C — Consolidate (CHOSEN): Single table, single read,
             single PII surface. Flyway migration is reversible
             via archived tables for 90 days.

Consequences:
  + Profile fetch: 2 DB calls → 1 DB call (~50ms p99)
  + PII audit surface: 2 tables → 1 table
  + GDPR erasure: 2 DELETEs → 1 DELETE
  - 90-day dependency on archived tables before hard drop`
  },
  {
    agent: "A10 — Code Modernisation",
    color: "#8B5CF6",
    label: "Migration Plan",
    output: `Customer Demographics Consolidation — Migration Plan
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Generated by: A10 Code Gen & Modernisation Agent

PHASE 1 — Preparation (Sprint 1)
  [x] Create CUSTOMER_DEMOGRAPHICS entity (CustomerDemographics.java)
  [x] Create CustomerDemographicsRepository (JPA)
  [x] Write Flyway V3 migration script with row-count validation
  [x] Add @Version field for optimistic locking
  [x] Add AES-256 column encryption for TAX_ID_NUM

PHASE 2 — Migration (Sprint 2, Blue/Green)
  [x] Deploy new code alongside legacy code (feature flag OFF)
  [x] Run Flyway V3 on production — LEFT JOIN insert
  [x] Validate: COUNT(*) CUSTOMER_DEMOGRAPHICS >= COUNT(*) CUST_IDENTITY
  [x] Enable feature flag — route reads to new table
  [x] Monitor for 48 hours — compare query latency

PHASE 3 — Cutover (Sprint 3)
  [x] Rename old tables with _ARCHIVED_2025 suffix
  [x] Remove CustomerIdentityRepository + CustomerTaxInfoRepository
  [x] Remove two-call pattern from CustomerService
  [x] Update all SQL queries referencing CUST_IDENTITY / CUST_TAX_INFO

PHASE 4 — Cleanup (90 days post-migration)
  [ ] Drop CUST_IDENTITY_ARCHIVED_2025
  [ ] Drop CUST_TAX_INFO_ARCHIVED_2025
  [ ] Remove feature flag infrastructure

Estimated Effort: 3 sprints | Risk: Low (archived tables = rollback path)`
  },
  {
    agent: "A11 — Code Quality",
    color: "#EF4444",
    label: "Security & PII Report",
    output: `Code Quality & Security Review — CustomerDemographics Migration
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Scanned by: A11 Code Quality Agent | Standard: OWASP + GDPR

PII FIELDS DETECTED:
  ⚠  FIRST_NM    — Category: Name       — Risk: Medium
  ⚠  LAST_NM     — Category: Name       — Risk: Medium
  ⚠  DT_OF_BIRTH — Category: Personal   — Risk: High
  🔴 TAX_ID_NUM  — Category: Tax/Gov ID — Risk: Critical

FINDINGS:
  [CRITICAL] CWE-312 — TAX_ID_NUM stored as plaintext VARCHAR
             Recommendation: Apply AES-256 encryption via JPA
             @Convert(converter = TaxIdEncryptor.class)

  [HIGH]     CWE-89  — findByTaxId() — verify parameter binding
             in CustomerDemographicsRepository to prevent SQLi
             Use: @Query("SELECT c FROM CustomerDemographics c
                         WHERE c.taxId = :taxId")

  [MEDIUM]   Missing @Audit annotation — MIGRATED_AT tracks
             creation but changes to TAX_ID_NUM are not logged.
             Recommendation: Add Hibernate Envers @Audited

  [INFO]     @Version field present — optimistic locking
             correctly prevents concurrent demographic updates ✓

MERGE READINESS: BLOCKED — Fix CRITICAL finding before merge`
  },
  {
    agent: "A12 — Test Engineering",
    color: "#F59E0B",
    label: "JUnit 5 Migration Tests",
    output: `// File: src/test/java/com/bank/service/CustomerMigrationTest.java

@SpringBootTest
@Sql("/test-data/seed-cust-identity.sql")
@Sql("/test-data/seed-cust-tax-info.sql")
class CustomerMigrationTest {

  @Autowired CustomerDemographicsRepository repo;
  @Autowired CustomerService service;

  @Test
  @DisplayName("All CUST_IDENTITY rows present in CUSTOMER_DEMOGRAPHICS")
  void migration_allIdentityRowsMigrated() {
    long identityCount = jdbcTemplate
        .queryForObject("SELECT COUNT(*) FROM CUST_IDENTITY", Long.class);
    long consolidatedCount = repo.count();

    assertThat(consolidatedCount).isGreaterThanOrEqualTo(identityCount);
  }

  @Test
  @DisplayName("Tax ID merged correctly for customers with tax records")
  void migration_taxIdMergedForKnownCustomer() {
    CustomerDemographics cust = repo.findById("CUST-10042").orElseThrow();

    assertThat(cust.getFirstName()).isEqualTo("James");
    assertThat(cust.getLastName()).isEqualTo("Hartley");
    assertThat(cust.getTaxId()).isEqualTo("***-**-6789"); // masked
    assertThat(cust.getTaxType()).isEqualTo("SSN");
  }

  @Test
  @DisplayName("Legacy customers without tax info have null taxId — not missing row")
  void migration_legacyCustomerWithoutTaxInfo_hasNullTaxId() {
    CustomerDemographics cust = repo.findById("CUST-00001").orElseThrow();

    assertThat(cust.getCustomerId()).isEqualTo("CUST-00001");
    assertThat(cust.getTaxId()).isNull(); // LEFT JOIN — no orphan row
  }

  @Test
  @DisplayName("getProfile() returns full demographics in single call")
  void service_getProfile_singleDbCall() {
    CustomerDemographics profile = service.getProfile("CUST-10042");

    assertThat(profile.getFirstName()).isNotBlank();
    assertThat(profile.getDateOfBirth()).isNotNull();
    assertThat(profile.getMigratedAt()).isNotNull();
    // Verify: no secondary query to CUST_TAX_INFO
    verify(legacyTaxInfoRepo, never()).findById(any());
  }
}`
  },
  {
    agent: "A14 — Release Engineering",
    color: "#EC4899",
    label: "GitHub Actions Pipeline",
    output: `# File: .github/workflows/demographic-migration.yml
# Generated by A14 Release Engineering Agent

name: Customer Demographics — Build, Migrate, Deploy
on:
  push:
    branches: [release/demographic-consolidation]

jobs:
  validate-migration:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:15
        env: { POSTGRES_DB: bankdb }
    steps:
      - uses: actions/checkout@v4
      - name: Run Flyway migration (dry run)
        run: flyway -url=jdbc:postgresql://localhost/bankdb migrate -dryRunOutput=migration-plan.sql
      - name: Upload migration plan for CAB review
        uses: actions/upload-artifact@v3
        with: { name: migration-plan, path: migration-plan.sql }

  test:
    needs: validate-migration
    steps:
      - name: Run migration tests
        run: mvn test -Dtest=CustomerMigrationTest -Dspring.profiles.active=test
      - name: Assert row count parity
        run: mvn test -Dtest=MigrationRowCountValidationTest

  deploy-blue-green:
    needs: test
    steps:
      - name: Deploy v2 (new schema) alongside v1 (feature flag OFF)
        run: kubectl apply -f k8s/demographic-v2-blue.yaml
      - name: Run Flyway V3 on production
        run: flyway -url=\${{ secrets.PROD_DB_URL }} migrate
      - name: Enable feature flag — route to CUSTOMER_DEMOGRAPHICS
        run: curl -X POST \${{ secrets.FF_API }}/demographics-consolidation/enable
      - name: Monitor 48h — compare p99 latency
        run: ./scripts/monitor-latency.sh --baseline=120ms --target=50ms --duration=48h`
  },
];

export default function SDLCAgent() {
  const [mapOpen, setMapOpen] = useState(false);
  const [activeAgent, setActiveAgent] = useState<string | null>(null);
  const [activeDemoTab, setActiveDemoTab] = useState(0);
  const [activeBeforeTab, setActiveBeforeTab] = useState(0);

  const handleDownload = () => {
    const original = document.title;
    document.title = "Nucleus 2.0 — Agent Factory Guide";
    window.print();
    document.title = original;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-10">

      {/* ══════════════════════════════════════════════════════════
          ACT 2 — THE ANSWER
      ══════════════════════════════════════════════════════════ */}
      <div className="mb-16">

        {/* Hero answer block */}
        <div className="relative rounded-3xl overflow-hidden mb-10"
          style={{ background: "linear-gradient(135deg, #0F172A 0%, #1E1B4B 50%, #0F172A 100%)" }}>
          {/* Glow orbs */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-20 -left-20 w-80 h-80 bg-blue-600/20 rounded-full blur-3xl" />
            <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-purple-600/20 rounded-full blur-3xl" />
          </div>

          <div className="relative z-10 px-8 py-12 text-center">
            <div className="text-6xl mb-4">🚀</div>
            <h2 className="text-4xl font-extrabold text-white mb-4">
              Nucleus 2.0 — Agent Factory
            </h2>
            <p className="text-blue-200 text-lg max-w-2xl mx-auto mb-8 leading-relaxed">
              15 specialist AI agents that cover every step of your software delivery lifecycle — wired together on a drag-and-drop canvas, powered by Anthropic Claude.
            </p>

            {/* Stat pills */}
            <div className="flex flex-wrap justify-center gap-3 mb-8">
              {[
                { v: "15", l: "Specialist Agents" },
                { v: "62", l: "SDLC Activities" },
                { v: "6", l: "Delivery Phases" },
                { v: "70%", l: "Effort Reduction" },
                { v: "200K", l: "Token Context" },
              ].map(s => (
                <div key={s.l} className="bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-center">
                  <div className="text-xl font-extrabold text-white">{s.v}</div>
                  <div className="text-xs text-blue-300">{s.l}</div>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap justify-center gap-3">
              <Link href="/zenseai-platform">
                <button className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-3.5 rounded-xl font-bold text-base shadow-lg hover:shadow-xl transition-all hover:scale-105">
                  <Play className="w-5 h-5" /> Launch Nucleus 2.0
                </button>
              </Link>
              <button onClick={handleDownload}
                className="inline-flex items-center gap-2 bg-white/10 border border-white/30 text-white px-8 py-3.5 rounded-xl font-bold text-base hover:bg-white/20 transition-all print:hidden">
                <Download className="w-5 h-5" /> Download Guide
              </button>
            </div>
          </div>
        </div>

        {/* Anthropic engine status */}
        <div className="rounded-2xl overflow-hidden border border-violet-200 shadow-md">
          <div className="bg-gradient-to-r from-[#1a1035] to-[#2d1b69] px-6 py-4 flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-violet-500/30 border border-violet-400/40 flex items-center justify-center text-lg">🤖</div>
              <div>
                <div className="text-white font-extrabold text-sm leading-tight">Anthropic Claude — Live AI Engine</div>
                <div className="text-violet-300 text-xs">All 15 Agents · Prompt Caching · Extended Thinking · SSE Streaming</div>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 ml-auto">
              {[
                { label: "claude-sonnet-4-5", sub: "A01 + A08 (Extended Thinking)", c: "bg-indigo-500/25 border-indigo-400/30 text-indigo-200" },
                { label: "claude-opus-4-5", sub: "All other agents", c: "bg-violet-500/25 border-violet-400/30 text-violet-200" },
                { label: "GPT-4o fallback", sub: "Auto when no Anthropic key", c: "bg-gray-500/25 border-gray-400/30 text-gray-300" },
              ].map(b => (
                <div key={b.label} className={`border rounded-xl px-3 py-1.5 ${b.c}`}>
                  <div className="text-xs font-bold font-mono">{b.label}</div>
                  <div className="text-xs opacity-70">{b.sub}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-gray-900 px-6 py-3 flex flex-wrap items-center gap-6 text-xs">
            {[
              { icon: "✅", label: "Prompt Caching", detail: "80–90% cost reduction" },
              { icon: "🧠", label: "Extended Thinking", detail: "Architect-grade reasoning" },
              { icon: "📡", label: "SSE Streaming", detail: "Live word-by-word output" },
              { icon: "🔒", label: "Prompt-caching-2024-07-31", detail: "Beta header enabled" },
            ].map(f => (
              <div key={f.label} className="flex items-center gap-2">
                <span>{f.icon}</span>
                <span className="font-semibold text-white">{f.label}</span>
                <span className="text-gray-500">— {f.detail}</span>
              </div>
            ))}
            <div className="ml-auto flex gap-3">
              <a href="https://docs.anthropic.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-violet-400 hover:text-violet-300 transition font-medium">
                <BookOpen className="w-3 h-3" /> Docs
              </a>
              <a href="https://console.anthropic.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-violet-400 hover:text-violet-300 transition font-medium">
                <Key className="w-3 h-3" /> Console
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════════
          ACT 3 — MEET THE TEAM
      ══════════════════════════════════════════════════════════ */}
      <div className="mb-16">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-purple-50 border border-purple-200 text-purple-700 rounded-full px-4 py-1.5 text-sm font-semibold mb-4">
            <Users className="w-4 h-4" /> The Cast
          </div>
          <h2 className="text-4xl font-extrabold text-gray-900 mb-3">
            ADLC - 15 experts. Every phase. One pipeline.
          </h2>
          <p className="text-gray-500 max-w-2xl mx-auto">
            Each agent has a specific job, a pre-loaded system prompt and domain-specific acceptance criteria. Click any agent to read its story.
          </p>
        </div>

        {/* Agent grid — interactive cards */}
        <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
          {AGENTS.map(a => {
            const dc = DOMAIN_COLORS[a.domain];
            const isActive = activeAgent === a.id;
            return (
              <button key={a.id}
                onClick={() => setActiveAgent(isActive ? null : a.id)}
                className={`text-left rounded-xl border p-3 transition-all hover:shadow-md ${
                  isActive ? `${dc.bg} ${dc.border} shadow-md` : "bg-white border-gray-200 hover:border-gray-300"
                }`}>
                <div className="text-2xl mb-2">{a.emoji}</div>
                <div className="font-bold text-gray-900 text-xs leading-tight mb-1">{a.name}</div>
                <div className="font-mono text-xs font-semibold" style={{ color: a.accent }}>{a.id}</div>
                <div className={`text-xs mt-1.5 px-1.5 py-0.5 rounded-full inline-block border font-medium ${dc.bg} ${dc.border} ${dc.text}`}>
                  {a.domain}
                </div>
              </button>
            );
          })}
        </div>

        {/* Expanded agent story */}
        {activeAgent && (() => {
          const a = AGENTS.find(x => x.id === activeAgent)!;
          const dc = DOMAIN_COLORS[a.domain];
          return (
            <div className={`rounded-2xl border p-6 ${dc.bg} ${dc.border} animate-in fade-in slide-in-from-top-2 duration-200`}>
              <div className="flex items-start gap-4">
                <div className="text-4xl">{a.emoji}</div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2 flex-wrap">
                    <span className="font-extrabold text-gray-900 text-lg">{a.name}</span>
                    <span className="font-mono text-sm font-bold" style={{ color: a.accent }}>{a.id}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${dc.border} ${dc.text}`}>{a.domain}</span>
                  </div>
                  <p className="text-gray-700 text-base leading-relaxed">{a.story}</p>
                </div>
                <button onClick={() => setActiveAgent(null)} className="text-gray-400 hover:text-gray-600">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          );
        })()}

        {/* Activity map */}
        <div className="mt-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold text-gray-900">62 SDLC Activities → 15 Agents</h3>
              <p className="text-sm text-gray-500">Every activity across the lifecycle is owned by a specialist agent</p>
            </div>
            <button onClick={() => setMapOpen(true)}
              className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700 font-semibold border border-blue-200 rounded-lg px-3 py-1.5 hover:bg-blue-50 transition">
              <ZoomIn className="w-4 h-4" /> Full Map
            </button>
          </div>
          <button type="button" onClick={() => setMapOpen(true)}
            className="group relative w-full rounded-2xl border border-gray-200 shadow-sm overflow-hidden bg-white cursor-zoom-in block">
            <img src={sdlcMapImage} alt="AI-Infused SDLC full map" className="w-full h-auto" />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors flex items-center justify-center">
              <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-white/95 rounded-full p-3 shadow-lg">
                <ZoomIn className="w-6 h-6 text-gray-700" />
              </div>
            </div>
          </button>
          <Dialog open={mapOpen} onOpenChange={setMapOpen}>
            <DialogContent className="max-w-[98vw] w-full p-2 sm:p-4 bg-white">
              <DialogTitle className="sr-only">AI-Infused SDLC — the full map</DialogTitle>
              <button onClick={() => setMapOpen(false)} className="absolute top-3 right-3 z-10 bg-white border border-gray-200 rounded-full p-1.5 shadow hover:bg-gray-50">
                <X className="w-5 h-5 text-gray-600" />
              </button>
              <img src={sdlcMapImage} alt="AI-Infused SDLC full map" className="w-full h-auto rounded-lg" />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════════
          ACT 4 — THE NUMBERS
      ══════════════════════════════════════════════════════════ */}
      <div className="mb-16 bg-gradient-to-br from-gray-950 to-gray-900 rounded-3xl p-10 text-white">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 rounded-full px-4 py-1.5 text-sm font-semibold mb-4">
            <TrendingUp className="w-4 h-4" /> Business Impact
          </div>
          <h2 className="text-4xl font-extrabold mb-3">The numbers don't lie.</h2>
          <p className="text-gray-400 max-w-xl mx-auto">Replacing manual SDLC handoffs with 15 specialist agents changes the economics of software delivery.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { v: "70%", l: "Less manual effort per sprint", sub: "Agents handle documentation, review and boilerplate" },
            { v: "10×", l: "Faster artefact generation", sub: "Minutes instead of days, every phase" },
            { v: "62", l: "Activities automated", sub: "6 phases from requirements to RunOps" },
            { v: "24/7", l: "Always on", sub: "No stand-up required, no context re-loading" },
          ].map(m => (
            <div key={m.l} className="bg-white/5 border border-white/10 rounded-2xl p-5 text-center">
              <div className="text-4xl font-extrabold text-emerald-400 mb-1">{m.v}</div>
              <div className="text-sm font-bold text-white mb-1">{m.l}</div>
              <div className="text-xs text-gray-500 leading-snug">{m.sub}</div>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          {[
            { icon: "💰", title: "Cost", points: [
              "80–90% fewer LLM tokens via Claude prompt caching",
              "No separate doc tooling, review tooling or test tooling",
              "One pipeline replaces multiple bespoke automations",
            ]},
            { icon: "⚡", title: "Speed", points: [
              "Requirements-to-code artefacts: days → minutes",
              "Each agent passes context forward — no re-briefing",
              "Parallel agents run concurrently on the same flow",
            ]},
            { icon: "🏆", title: "Quality", points: [
              "Every agent enforces domain acceptance criteria",
              "Security scanning (OWASP/CWE) is in the pipeline, not optional",
              "Standardised outputs → instant cross-project reuse",
            ]},
          ].map(col => (
            <div key={col.title} className="bg-white/5 border border-white/10 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xl">{col.icon}</span>
                <span className="font-bold text-white">{col.title}</span>
              </div>
              <ul className="space-y-2">
                {col.points.map(p => (
                  <li key={p} className="flex items-start gap-2 text-sm text-gray-300">
                    <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0 text-emerald-400" />
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>


      {/* ══════════════════════════════════════════════════════════
          ACT 6 — LOAD DEMO: BANKING DEMOGRAPHIC MIGRATION
      ══════════════════════════════════════════════════════════ */}
      <div className="mb-16">

        {/* Section header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-200 text-blue-700 rounded-full px-4 py-1.5 text-sm font-semibold mb-4">
            <Sparkles className="w-4 h-4" /> Live Demo · Banking Java Project
          </div>
          <h2 className="text-4xl font-extrabold text-gray-900 mb-3">
            A real migration, not a toy example.
          </h2>
          <p className="text-gray-500 max-w-2xl mx-auto leading-relaxed">
            A retail banking Java project stores customer demographic data — Name, Date of Birth, Customer ID and Tax ID — across <strong>two separate legacy tables</strong>.
            Watch Nucleus 2.0 analyse the existing code, plan the consolidation and generate everything needed to migrate to a single unified table.
          </p>
        </div>

        {/* ── USE CASE STORY ─────────────────────────────────── */}
        <div className="rounded-3xl overflow-hidden border border-gray-200 shadow-sm mb-8 bg-white">

          {/* Story header */}
          <div className="bg-gradient-to-r from-slate-800 to-slate-900 px-8 py-6">
            <div className="flex items-center gap-3 mb-2">
              <span className="text-2xl">🏦</span>
              <div>
                <div className="text-white font-extrabold text-lg">Customer Demographics Consolidation</div>
                <div className="text-slate-400 text-sm">Retail Banking · Spring Boot / JPA · PostgreSQL 15</div>
              </div>
              <div className="ml-auto flex gap-2">
                <span className="bg-red-500/20 text-red-300 border border-red-500/30 text-xs px-3 py-1 rounded-full font-semibold">Legacy: 2 Tables</span>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs px-3 py-1 rounded-full font-semibold">After: 1 Table</span>
              </div>
            </div>
          </div>

          {/* The problem — table diagram */}
          <div className="p-8">
            <div className="grid md:grid-cols-2 gap-6 mb-8">

              {/* BEFORE — two tables */}
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
                  <span className="font-bold text-gray-900 text-sm uppercase tracking-wide">Before — Two Separate Tables</span>
                </div>
                <div className="space-y-3">
                  {[
                    { table: "CUST_IDENTITY", cols: ["CUST_ID (PK)", "FIRST_NM", "LAST_NM", "DT_OF_BIRTH"], owner: "Identity Team · 2007", color: "border-red-200 bg-red-50" },
                    { table: "CUST_TAX_INFO", cols: ["CUST_ID (PK → FK)", "TAX_ID_NUM", "TAX_TYPE_CD"], owner: "Tax Compliance Team · 2009", color: "border-orange-200 bg-orange-50" },
                  ].map(t => (
                    <div key={t.table} className={`rounded-xl border p-4 ${t.color}`}>
                      <div className="font-mono font-bold text-gray-800 text-sm mb-2">{t.table}</div>
                      <div className="space-y-1">
                        {t.cols.map(c => (
                          <div key={c} className="flex items-center gap-2 text-xs font-mono text-gray-600">
                            <div className="w-1.5 h-1.5 rounded-sm bg-gray-400 flex-shrink-0" />
                            {c}
                          </div>
                        ))}
                      </div>
                      <div className="mt-2 text-xs text-gray-400 italic">{t.owner}</div>
                    </div>
                  ))}
                  {/* Pain points */}
                  <div className="bg-red-50 border border-red-200 rounded-xl p-3">
                    <div className="text-xs font-bold text-red-700 mb-2">⚠ Problems with this design</div>
                    <ul className="space-y-1">
                      {[
                        "Every profile fetch = 2 DB calls + manual JOIN",
                        "Orphan risk: tax info without identity record",
                        "Two separate PII audit surfaces (GDPR, CCPA)",
                        "p99 latency: ~120ms per profile lookup",
                      ].map(p => <li key={p} className="text-xs text-red-600 flex items-start gap-1.5"><span className="mt-0.5 flex-shrink-0">✗</span>{p}</li>)}
                    </ul>
                  </div>
                </div>
              </div>

              {/* AFTER — one table */}
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="font-bold text-gray-900 text-sm uppercase tracking-wide">After — Single Unified Table</span>
                </div>
                <div className="space-y-3">
                  <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4">
                    <div className="font-mono font-bold text-gray-800 text-sm mb-2">CUSTOMER_DEMOGRAPHICS</div>
                    <div className="space-y-1">
                      {[
                        "CUST_ID (PK)",
                        "FIRST_NM · LAST_NM",
                        "DT_OF_BIRTH",
                        "TAX_ID_NUM (AES-256 encrypted)",
                        "TAX_TYPE_CD   — SSN | EIN",
                        "MIGRATED_AT   — audit timestamp",
                        "VERSION       — optimistic lock",
                      ].map(c => (
                        <div key={c} className="flex items-center gap-2 text-xs font-mono text-gray-600">
                          <div className="w-1.5 h-1.5 rounded-sm bg-emerald-500 flex-shrink-0" />
                          {c}
                        </div>
                      ))}
                    </div>
                    <div className="mt-2 text-xs text-gray-400 italic">Nucleus A10 · Flyway V3 migration</div>
                  </div>
                  {/* Gains */}
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3">
                    <div className="text-xs font-bold text-emerald-700 mb-2">✅ What this gives you</div>
                    <ul className="space-y-1">
                      {[
                        "Single DB call per profile — p99 → ~50ms",
                        "LEFT JOIN migration — zero data loss",
                        "One PII surface for GDPR erasure: 1 DELETE",
                        "90-day rollback via archived legacy tables",
                      ].map(p => <li key={p} className="text-xs text-emerald-700 flex items-start gap-1.5"><span className="mt-0.5 flex-shrink-0">✓</span>{p}</li>)}
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Arrow between */}
            <div className="flex justify-center mb-2">
              <div className="flex items-center gap-3 bg-blue-50 border border-blue-200 rounded-full px-5 py-2">
                <span className="text-sm font-bold text-blue-700">Nucleus 2.0 runs 6 agents</span>
                <ArrowRight className="w-4 h-4 text-blue-500" />
                <span className="text-sm text-blue-600">analyses → plans → migrates → tests → deploys</span>
              </div>
            </div>
          </div>
        </div>

        {/* ── BEFORE CODE VIEWER ─────────────────────────────── */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <span className="font-bold text-gray-900">Existing Code — Loaded into Nucleus 2.0</span>
            <span className="text-xs text-gray-400 border border-gray-200 rounded-full px-2 py-0.5">Java / Spring Boot · 3 files</span>
          </div>
          <div className="bg-gray-950 rounded-2xl overflow-hidden border border-gray-800">
            <div className="flex border-b border-gray-800">
              {[
                { label: "CustomerIdentity.java", sub: "CUST_IDENTITY entity" },
                { label: "CustomerTaxInfo.java", sub: "CUST_TAX_INFO entity" },
                { label: "CustomerService.java", sub: "⚠ Two-call pattern" },
              ].map((t, i) => (
                <button key={i} onClick={() => setActiveBeforeTab(i)}
                  className={`flex-shrink-0 px-4 py-2.5 text-xs font-mono font-semibold border-b-2 transition-all ${
                    activeBeforeTab === i
                      ? "border-red-500 text-red-400 bg-red-950/20"
                      : "border-transparent text-gray-500 hover:text-gray-300 hover:bg-gray-900"
                  }`}>
                  <div>{t.label}</div>
                  <div className="text-xs opacity-60 font-sans">{t.sub}</div>
                </button>
              ))}
            </div>
            <div className="p-0">
              {[BEFORE_CODE.identity, BEFORE_CODE.tax, BEFORE_CODE.service].map((code, i) => (
                <div key={i} className={activeBeforeTab === i ? "block" : "hidden"}>
                  <div className="flex items-center gap-2 px-4 py-2 border-b border-gray-800 bg-gray-900">
                    <div className="flex gap-1.5"><div className="w-2.5 h-2.5 rounded-full bg-red-500/70" /><div className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" /><div className="w-2.5 h-2.5 rounded-full bg-green-500/70" /></div>
                    <span className="text-gray-500 text-xs font-mono ml-2">com.bank.customer</span>
                    <span className="ml-auto text-xs text-red-400 font-semibold">BEFORE</span>
                  </div>
                  <div className="p-5 overflow-x-auto max-h-80 overflow-y-auto">
                    <pre className="text-xs text-gray-300 font-mono leading-relaxed whitespace-pre">{code}</pre>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── AGENT PIPELINE OUTPUTS ─────────────────────────── */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-3 h-3 rounded-full bg-blue-500 animate-pulse" />
            <span className="font-bold text-gray-900">6 Agents Execute — Each Output Streams Live</span>
            <span className="text-xs text-gray-400 border border-gray-200 rounded-full px-2 py-0.5">Claude claude-opus-4-5 · SSE streaming</span>
          </div>
          <div className="bg-gray-950 rounded-2xl overflow-hidden border border-gray-800 shadow-2xl">
            <div className="flex overflow-x-auto border-b border-gray-800">
              {DEMO_AGENT_OUTPUTS.map((d, i) => (
                <button key={i} onClick={() => setActiveDemoTab(i)}
                  className={`flex-shrink-0 flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all ${
                    activeDemoTab === i
                      ? "border-blue-500 text-blue-400 bg-blue-950/30"
                      : "border-transparent text-gray-500 hover:text-gray-300 hover:bg-gray-900"
                  }`}>
                  <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: d.color }} />
                  {d.agent}
                </button>
              ))}
            </div>
            <div className="p-0">
              {DEMO_AGENT_OUTPUTS.map((d, i) => (
                <div key={i} className={activeDemoTab === i ? "block" : "hidden"}>
                  <div className="flex items-center gap-3 px-5 py-2.5 border-b border-gray-800 bg-gray-900">
                    <div className="flex gap-1.5"><div className="w-2.5 h-2.5 rounded-full bg-red-500/70" /><div className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" /><div className="w-2.5 h-2.5 rounded-full bg-green-500/70" /></div>
                    <span className="text-gray-400 text-xs font-mono">{d.agent}</span>
                    <span className="ml-auto text-xs font-semibold px-2 py-0.5 rounded-full border"
                      style={{ color: d.color, borderColor: `${d.color}40`, background: `${d.color}15` }}>
                      {d.label}
                    </span>
                    <span className="text-xs text-gray-600 font-mono">claude-opus-4-5</span>
                  </div>
                  <div className="p-5 overflow-x-auto max-h-80 overflow-y-auto">
                    <pre className="text-xs text-green-300 font-mono leading-relaxed whitespace-pre">{d.output}</pre>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>


        {/* Artefacts summary row */}
        <div className="grid grid-cols-3 md:grid-cols-6 gap-3 mb-10">
          {[
            { icon: "📋", label: "User Story", sub: "EPIC-042" },
            { icon: "🏗️", label: "ADR-007", sub: "Architecture decision" },
            { icon: "🗺️", label: "Migration Plan", sub: "3-sprint rollout" },
            { icon: "💻", label: "Java Entity", sub: "Unified model" },
            { icon: "🗃️", label: "Flyway SQL", sub: "V3 migration" },
            { icon: "🧪", label: "JUnit 5 Tests", sub: "4 test cases" },
          ].map(a => (
            <div key={a.label} className="bg-white border border-gray-100 rounded-xl p-3 text-center hover:shadow-sm transition-shadow">
              <div className="text-2xl mb-1">{a.icon}</div>
              <div className="text-xs font-bold text-gray-900">{a.label}</div>
              <div className="text-xs text-gray-400">{a.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════════
          THE CALL TO ACTION — LOAD DEMO
      ══════════════════════════════════════════════════════════ */}
      <div className="mb-16">
        <div className="relative rounded-3xl overflow-hidden"
          style={{ background: "linear-gradient(135deg, #0F2027 0%, #203A43 50%, #1a1a2e 100%)" }}>
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className="absolute -top-32 -left-32 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl" />
            <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-emerald-600/15 rounded-full blur-3xl" />
          </div>
          <div className="relative z-10 px-8 py-14">
            <div className="max-w-4xl mx-auto">

              {/* Header */}
              <div className="text-center mb-10">
                <div className="inline-flex items-center gap-2 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 rounded-full px-4 py-1.5 text-sm font-semibold mb-4">
                  🚀 Load Demo — Banking Java Project
                </div>
                <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-4 leading-tight">
                  Try this exact migration yourself.
                </h2>
                <p className="text-slate-400 text-lg max-w-2xl mx-auto leading-relaxed">
                  The banking project — two legacy tables, demographic data, the whole migration challenge — is pre-loaded in Nucleus 2.0.
                  Click <strong className="text-white">Load Demo</strong> and watch 6 agents analyse it, plan it, and generate the consolidated code in real time.
                </p>
              </div>

              {/* What's pre-loaded */}
              <div className="grid md:grid-cols-2 gap-4 mb-10">
                <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
                  <div className="text-white font-bold mb-3 flex items-center gap-2">
                    <span>📂</span> Pre-loaded project
                  </div>
                  <ul className="space-y-2">
                    {[
                      "Spring Boot 3.2 / JPA / PostgreSQL 15",
                      "CUST_IDENTITY table — Name, DOB, Customer ID",
                      "CUST_TAX_INFO table — Tax ID (SSN/EIN)",
                      "CustomerService.java — the two-call anti-pattern",
                      "10,000 seed rows — real migration scenario",
                    ].map(item => (
                      <li key={item} className="flex items-start gap-2 text-sm text-slate-300">
                        <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0 text-emerald-400" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
                  <div className="text-white font-bold mb-3 flex items-center gap-2">
                    <span>🤖</span> Pre-wired agents
                  </div>
                  <div className="space-y-2">
                    {[
                      { id: "A06", name: "Req Intelligence", out: "Migration user story + NFRs", color: "#3B82F6" },
                      { id: "A08", name: "Solution Architecture", out: "ADR-007 — consolidation decision", color: "#10B981" },
                      { id: "A10", name: "Code Modernisation", out: "3-sprint migration plan", color: "#8B5CF6" },
                      { id: "A09", name: "Eng Delivery", out: "Unified entity + updated service", color: "#A855F7" },
                      { id: "A11", name: "Code Quality", out: "PII security findings", color: "#EF4444" },
                      { id: "A12", name: "Test Engineering", out: "4 migration validation tests", color: "#F59E0B" },
                    ].map(a => (
                      <div key={a.id} className="flex items-center gap-2 text-xs">
                        <span className="font-mono font-bold w-8 flex-shrink-0" style={{ color: a.color }}>{a.id}</span>
                        <span className="text-slate-300 font-semibold flex-shrink-0 w-32">{a.name}</span>
                        <span className="text-slate-500 hidden md:block">→ {a.out}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Steps */}
              <div className="flex flex-wrap justify-center gap-2 mb-10">
                {[
                  { n: "1", icon: "🚀", text: "Open Nucleus 2.0" },
                  { n: "2", icon: "📂", text: "Click 'Load Demo'" },
                  { n: "3", icon: "▶", text: "Click 'Run Flow'" },
                  { n: "4", icon: "📡", text: "Watch 6 agents stream live" },
                  { n: "5", icon: "📦", text: "Open Full Explorer" },
                ].map((s, i, arr) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-center">
                      <div className="text-base mb-0.5">{s.icon}</div>
                      <div className="text-xs font-semibold text-white">{s.text}</div>
                    </div>
                    {i < arr.length - 1 && <ArrowRight className="w-4 h-4 text-white/30 flex-shrink-0" />}
                  </div>
                ))}
              </div>

              {/* CTA button */}
              <div className="text-center">
                <Link href="/zenseai-platform">
                  <button className="inline-flex items-center gap-3 bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-12 py-5 rounded-2xl font-extrabold text-xl shadow-2xl hover:shadow-emerald-500/30 hover:scale-105 transition-all">
                    <Sparkles className="w-6 h-6" />
                    Load Demo in Nucleus 2.0
                    <ArrowRight className="w-6 h-6" />
                  </button>
                </Link>
                <p className="text-slate-500 text-sm mt-4">
                  Banking project pre-loaded · 6 agents pre-wired · Real Claude AI · No setup
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════════
          CLAUDE AI DEEP DIVE (for technical readers)
      ══════════════════════════════════════════════════════════ */}
      <div className="mb-16">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-violet-50 border border-violet-200 text-violet-700 rounded-full px-4 py-1.5 text-sm font-semibold mb-4">
            <BrainCircuit className="w-4 h-4" /> For the technically curious
          </div>
          <h2 className="text-4xl font-extrabold text-gray-900 mb-3">The Claude AI upgrade path</h2>
          <p className="text-gray-500 max-w-2xl mx-auto">
            Nucleus 2.0 runs on Anthropic Claude today. Here are the six capabilities that make it measurably better than a GPT-4o implementation — with the exact code.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-5">
          {[
            {
              rank: "P1", icon: "💾", color: "violet",
              title: "Prompt Caching",
              impact: "80–90% token cost reduction",
              agents: "All 15 Agents",
              why: "Every agent re-sends the full system prompt + project context on each call. In a 7-agent flow that's 7× the same 20K tokens. Claude caches them after the first call.",
              code: `cache_control: { type: "ephemeral" }  // ← mark as cacheable
// Every subsequent call in the flow reuses it`
            },
            {
              rank: "P1", icon: "📖", color: "blue",
              title: "200K Extended Context",
              impact: "Entire codebase in one call",
              agents: "A09, A10, A11",
              why: "The repo loader summarises code to ~3K chars. A11 only sees fragments. Claude's 200K window fits entire codebases — A10 can plan a full COBOL→Java migration in one shot.",
              code: `// Pass ALL files directly — no RAG, no chunking
const allFiles = repoFiles.map(f => \`// \${f.path}\\n\${f.content}\`).join("\\n")
// Claude handles 150K+ lines of code`
            },
            {
              rank: "P1", icon: "🧠", color: "indigo",
              title: "Extended Thinking",
              impact: "Architect-grade reasoning",
              agents: "A01, A08",
              why: "A08 generates HLDs and ADRs in one pass with no internal reasoning. Claude's Extended Thinking lets it reason through trade-offs before it writes — like a senior architect thinking out loud first.",
              code: `thinking: { type: "enabled", budget_tokens: 8000 }
// response[0].type === "thinking" ← internal reasoning
// response[1].type === "text"     ← final output`
            },
            {
              rank: "P2", icon: "📡", color: "green",
              title: "SSE Streaming",
              impact: "Live word-by-word output",
              agents: "All 15 Agents",
              why: "Without streaming, the Activity tab shows nothing for 30–60 seconds. With Claude's streaming API, users watch output appear token-by-token — transforming perceived wait time completely.",
              code: `for await (const chunk of anthropic.messages.stream({...})) {
  res.write(\`data: \${JSON.stringify({ text: chunk.delta.text })}\\n\\n\`);
}`
            },
            {
              rank: "P3", icon: "👁️", color: "amber",
              title: "Vision (Multimodal)",
              impact: "Screenshot → wireframe specs",
              agents: "A07, A11",
              why: "A07 currently generates wireframes from text requirements only. With Claude Vision, you can attach an existing app screenshot and get WCAG critique, component breakdown and redesign suggestions.",
              code: `{ type: "image", source: { type: "base64", data: imageBase64 } }
// A07 analyses the actual UI, not just your description of it`
            },
            {
              rank: "P3", icon: "🔧", color: "rose",
              title: "Tool Use (Auto-Flow)",
              impact: "A01 wires the pipeline itself",
              agents: "A01",
              why: "Currently A01 produces a delivery plan as text and you manually build the canvas. With Claude Tool Use, A01 receives all 15 agents as callable tools and invokes them dynamically — no wiring needed.",
              code: `tools: AGENT_DEFINITIONS.map(a => ({
  name: a.id, description: a.description,
  input_schema: { type: "object", properties: { projectContext: {...} } }
}))`
            },
          ].map((f, i) => (
            <div key={i} className={`rounded-2xl border bg-white overflow-hidden hover:shadow-md transition-shadow ${
              f.color === "violet" ? "border-violet-200" : f.color === "blue" ? "border-blue-200" :
              f.color === "indigo" ? "border-indigo-200" : f.color === "green" ? "border-green-200" :
              f.color === "amber" ? "border-amber-200" : "border-rose-200"
            }`}>
              <div className={`px-5 py-3 flex items-center gap-3 border-b ${
                f.color === "violet" ? "bg-violet-50 border-violet-100" : f.color === "blue" ? "bg-blue-50 border-blue-100" :
                f.color === "indigo" ? "bg-indigo-50 border-indigo-100" : f.color === "green" ? "bg-green-50 border-green-100" :
                f.color === "amber" ? "bg-amber-50 border-amber-100" : "bg-rose-50 border-rose-100"
              }`}>
                <span className="text-xl">{f.icon}</span>
                <div className="flex-1">
                  <div className="font-extrabold text-gray-900">{f.title}</div>
                  <div className={`text-xs font-semibold ${
                    f.color === "violet" ? "text-violet-600" : f.color === "blue" ? "text-blue-600" :
                    f.color === "indigo" ? "text-indigo-600" : f.color === "green" ? "text-green-600" :
                    f.color === "amber" ? "text-amber-600" : "text-rose-600"
                  }`}>{f.impact}</div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-semibold border ${
                  f.color === "violet" ? "bg-violet-100 text-violet-700 border-violet-200" :
                  f.color === "blue" ? "bg-blue-100 text-blue-700 border-blue-200" :
                  f.color === "indigo" ? "bg-indigo-100 text-indigo-700 border-indigo-200" :
                  f.color === "green" ? "bg-green-100 text-green-700 border-green-200" :
                  f.color === "amber" ? "bg-amber-100 text-amber-700 border-amber-200" :
                  "bg-rose-100 text-rose-700 border-rose-200"
                }`}>{f.agents}</span>
              </div>
              <div className="p-5">
                <p className="text-sm text-gray-600 mb-3 leading-relaxed">{f.why}</p>
                <pre className="text-xs bg-gray-950 text-green-300 rounded-xl p-3 overflow-x-auto leading-relaxed whitespace-pre-wrap">{f.code}</pre>
              </div>
            </div>
          ))}
        </div>

        {/* SDK install block */}
        <div className="mt-6 bg-gray-900 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-5">
            <Terminal className="w-5 h-5 text-green-400" />
            <h3 className="text-white font-bold">Install in 4 steps</h3>
            <span className="ml-auto text-xs text-gray-500 font-mono">All features above become available</span>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {[
              { step: "01", title: "Install SDK", code: "npm install @anthropic-ai/sdk" },
              { step: "02", title: "Add secret", code: "ANTHROPIC_API_KEY=sk-ant-..." },
              { step: "03", title: "Init client", code: `import Anthropic from "@anthropic-ai/sdk";\nconst anthropic = new Anthropic();` },
              { step: "04", title: "Route agents", code: `const model = THINKING_AGENTS.has(id)\n  ? "claude-sonnet-4-5" : "claude-opus-4-5";` },
            ].map(s => (
              <div key={s.step} className="bg-gray-800 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-bold text-green-400 font-mono bg-green-400/10 px-2 py-0.5 rounded">Step {s.step}</span>
                  <span className="text-white text-sm font-semibold">{s.title}</span>
                </div>
                <pre className="text-green-300 text-xs font-mono bg-gray-900 rounded-lg p-3 overflow-x-auto whitespace-pre-wrap">{s.code}</pre>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════════
          TEAM
      ══════════════════════════════════════════════════════════ */}
      <div className="mb-10 bg-white border border-gray-200 rounded-2xl p-8 shadow-sm">
        <div className="flex items-center gap-2 mb-6">
          <Users className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-bold text-gray-900">Team Diamond — Zensar Technologies</h2>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { name: "Rajesh Madhai", role: "VP — Products & Platforms", highlight: true },
            { name: "Kaushik Saha", role: "Project Manager — AES" },
            { name: "Piyush Gupta", role: "Project Manager (Onshore)" },
            { name: "Sameer Kumar Sharma", role: "Project Manager (Offshore)" },
            { name: "Ullas Krishnan", role: "AI Solution Architect" },
            { name: "Hrushikesh Nalawade", role: "Solution Architect" },
          ].map(m => (
            <div key={m.name} className={`p-4 rounded-xl border ${m.highlight ? "bg-blue-50 border-blue-300" : "bg-gray-50 border-gray-200"}`}>
              <div className="font-bold text-gray-900 mb-0.5">{m.name}</div>
              <div className={`text-sm font-medium ${m.highlight ? "text-blue-600" : "text-gray-500"}`}>{m.role}</div>
              <div className="text-xs text-gray-400 mt-1">AMEX Diamond Project</div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
