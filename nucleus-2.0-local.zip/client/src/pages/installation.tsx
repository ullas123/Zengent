/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useState } from "react";
import { CheckCircle2, Copy, Terminal, Database, Bot, Key, FolderOpen, Layers, BookOpen, Cpu, Globe, Lock } from "lucide-react";
import { Badge } from "@/components/ui/badge";

function CodeBlock({ code, language = "bash" }: { code: string; language?: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="relative group rounded-lg overflow-hidden border border-slate-700 bg-slate-950 my-3">
      <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700">
        <span className="text-xs text-slate-400 font-mono">{language}</span>
        <button onClick={copy} className="flex items-center gap-1 text-xs text-slate-400 hover:text-white transition-colors">
          {copied ? <CheckCircle2 size={13} className="text-green-400" /> : <Copy size={13} />}
          {copied ? "Copied!" : "Copy"}
        </button>
      </div>
      <pre className="p-4 text-sm text-slate-100 font-mono overflow-x-auto leading-relaxed whitespace-pre">{code}</pre>
    </div>
  );
}

function Section({ icon: Icon, title, children, id }: { icon: any; title: string; children: React.ReactNode; id: string }) {
  return (
    <section id={id} className="mb-10">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-9 h-9 rounded-lg bg-blue-900/50 border border-blue-700/40 flex items-center justify-center">
          <Icon size={18} className="text-blue-400" />
        </div>
        <h2 className="text-lg font-semibold text-white">{title}</h2>
      </div>
      <div className="pl-12">{children}</div>
    </section>
  );
}

function Table({ headers, rows }: { headers: string[]; rows: string[][] }) {
  return (
    <div className="overflow-x-auto rounded-lg border border-slate-700 mb-4">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-slate-800 border-b border-slate-700">
            {headers.map(h => (
              <th key={h} className="px-4 py-2.5 text-left text-slate-300 font-medium">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} className={i % 2 === 0 ? "bg-slate-900" : "bg-slate-900/60"}>
              {row.map((cell, j) => (
                <td key={j} className="px-4 py-2.5 text-slate-300 font-mono text-xs">{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const TOC = [
  { id: "prerequisites", label: "Prerequisites" },
  { id: "installation", label: "Installation" },
  { id: "env-vars", label: "Environment Variables" },
  { id: "running", label: "Running the App" },
  { id: "credentials", label: "Default Credentials" },
  { id: "ai-config", label: "AI Configuration" },
  { id: "database", label: "Database Setup" },
  { id: "tech-stack", label: "Tech Stack" },
];

export default function InstallationPage() {
  const [activeSection, setActiveSection] = useState("prerequisites");

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="max-w-7xl mx-auto px-6 py-8 flex gap-8">

        {/* Sidebar TOC */}
        <aside className="hidden lg:block w-56 shrink-0">
          <div className="sticky top-8">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">On This Page</p>
            <nav className="space-y-1">
              {TOC.map(item => (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  onClick={() => setActiveSection(item.id)}
                  className={`block text-sm px-3 py-1.5 rounded-md transition-colors ${
                    activeSection === item.id
                      ? "bg-blue-900/40 text-blue-300 border-l-2 border-blue-500"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
                  }`}
                >
                  {item.label}
                </a>
              ))}
            </nav>

            <div className="mt-8 p-4 rounded-lg bg-blue-950/40 border border-blue-800/30">
              <p className="text-xs text-blue-300 font-medium mb-1">Quick Start</p>
              <p className="text-xs text-slate-400">Default login after install:</p>
              <div className="mt-2 space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-500">User</span>
                  <code className="text-blue-300">nucleus</code>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-500">Pass</span>
                  <code className="text-blue-300">nucleus</code>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 min-w-0">

          {/* Hero */}
          <div className="mb-10 pb-8 border-b border-slate-800">
            <div className="flex items-center gap-3 mb-3">
              <Badge className="bg-blue-900/50 text-blue-300 border-blue-700/40 text-xs">v2.0</Badge>
              <Badge className="bg-emerald-900/50 text-emerald-300 border-emerald-700/40 text-xs">Zensar Technologies</Badge>
              <Badge className="bg-purple-900/50 text-purple-300 border-purple-700/40 text-xs">AMEX Diamond</Badge>
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Nucleus 2.0 — Installation Guide</h1>
            <p className="text-slate-400 text-base">
              Enterprise Agentic SDLC Framework · Multi-language code analysis · AI-powered migration planning
            </p>
          </div>

          {/* Prerequisites */}
          <Section icon={CheckCircle2} title="Prerequisites" id="prerequisites">
            <Table
              headers={["Requirement", "Version", "Notes"]}
              rows={[
                ["Node.js", "18+", "Required"],
                ["npm", "9+", "Required"],
                ["Python", "3.9+", "For analysis scripts"],
                ["PostgreSQL", "14+", "Optional — falls back to in-memory"],
                ["Git", "Any", "For GitHub integration"],
                ["Ollama", "Latest", "Optional — for offline/local AI"],
              ]}
            />
          </Section>

          {/* Installation */}
          <Section icon={Terminal} title="Installation" id="installation">
            <p className="text-slate-400 text-sm mb-4">Follow these steps in order to get Nucleus 2.0 running locally.</p>

            <p className="text-slate-300 text-sm font-medium mb-1">1 · Clone the repository</p>
            <CodeBlock code={`git clone https://github.com/your-org/nucleus-2.0.git\ncd nucleus-2.0`} />

            <p className="text-slate-300 text-sm font-medium mb-1">2 · Install Node.js dependencies</p>
            <CodeBlock code={`npm install`} />

            <p className="text-slate-300 text-sm font-medium mb-1">3 · Install Python dependencies</p>
            <CodeBlock code={`pip install openpyxl numpy graphviz\n\n# Optional — for advanced ML field matching\npip install transformers torch`} />

            <p className="text-slate-300 text-sm font-medium mb-1">4 · Set up environment variables</p>
            <CodeBlock code={`cp .env.example .env\n# Then edit .env with your API keys`} />

            <p className="text-slate-300 text-sm font-medium mb-1">5 · Apply the database schema (optional)</p>
            <CodeBlock code={`npm run db:push`} />
            <p className="text-xs text-slate-500 mb-4">Skip this step to run fully in-memory (no data persists on restart).</p>

            <p className="text-slate-300 text-sm font-medium mb-1">6 · Start the application</p>
            <CodeBlock code={`npm run dev`} />
            <p className="text-xs text-slate-500">App runs at <code className="text-blue-400">http://localhost:5000</code></p>
          </Section>

          {/* Environment Variables */}
          <Section icon={Key} title="Environment Variables" id="env-vars">
            <Table
              headers={["Variable", "Required", "Description"]}
              rows={[
                ["ANTHROPIC_API_KEY", "Recommended", "Claude AI — primary LLM for agents"],
                ["OPENAI_API_KEY", "Optional", "GPT-4o — fallback when no Anthropic key"],
                ["DATABASE_URL", "Optional", "PostgreSQL connection string (Neon or local)"],
                ["OLLAMA_ENDPOINT", "Optional", "Local Ollama server (e.g. http://localhost:11434)"],
                ["OLLAMA_MODEL", "Optional", "Ollama model name (e.g. codellama, deepseek-coder)"],
                ["CONFLUENCE_EMAIL", "Optional", "Atlassian account email for Confluence sync"],
                ["CONFLUENCE_API_TOKEN", "Optional", "API token from Atlassian account settings"],
                ["SESSION_SECRET", "Optional", "Express session secret (auto-generated if unset)"],
              ]}
            />
            <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-950/30 border border-amber-700/30 text-xs text-amber-300">
              <Lock size={14} className="mt-0.5 shrink-0" />
              Never commit API keys to version control. Use a <code className="mx-1 text-amber-200">.env</code> file (gitignored) or your platform's secret manager.
            </div>
          </Section>

          {/* Running the App */}
          <Section icon={Globe} title="Running the App" id="running">
            <Table
              headers={["Command", "Description"]}
              rows={[
                ["npm run dev", "Start development server (frontend + backend on port 5000)"],
                ["npm run build", "Build production bundle"],
                ["npm run start", "Start production server"],
                ["npm run db:push", "Apply database schema migrations"],
                ["npm run db:studio", "Open Drizzle Studio (visual database UI)"],
              ]}
            />
          </Section>

          {/* Credentials */}
          <Section icon={Lock} title="Default Credentials" id="credentials">
            <Table
              headers={["Field", "Value"]}
              rows={[
                ["Username", "nucleus"],
                ["Password", "nucleus"],
              ]}
            />
            <p className="text-xs text-slate-500 mt-2">Change these in <code className="text-blue-400">server/auth.ts</code> before deploying to production.</p>
          </Section>

          {/* AI Configuration */}
          <Section icon={Bot} title="AI Configuration" id="ai-config">
            <p className="text-slate-300 text-sm font-medium mb-2">Cloud AI (Default)</p>
            <p className="text-slate-400 text-sm mb-2">Nucleus uses <strong className="text-white">Anthropic Claude</strong> (claude-3-7-sonnet) as the primary LLM with OpenAI GPT-4o as fallback.</p>
            <CodeBlock language=".env" code={`ANTHROPIC_API_KEY=sk-ant-...\nOPENAI_API_KEY=sk-...`} />

            <p className="text-slate-300 text-sm font-medium mt-5 mb-2">Local / Offline AI (Ollama)</p>
            <p className="text-slate-400 text-sm mb-3">For air-gapped environments or privacy-sensitive projects — no data leaves your network.</p>
            <CodeBlock code={`# 1. Install Ollama from https://ollama.ai\n\n# 2. Pull a model\nollama pull codellama\n# or\nollama pull deepseek-coder\nollama pull mistral`} />
            <CodeBlock language=".env" code={`OLLAMA_ENDPOINT=http://localhost:11434\nOLLAMA_MODEL=codellama`} />

            <div className="mt-3 grid grid-cols-3 gap-3">
              {[
                { model: "codellama", tag: "Best for code", color: "blue" },
                { model: "deepseek-coder", tag: "Fast + accurate", color: "purple" },
                { model: "mistral", tag: "General purpose", color: "emerald" },
              ].map(m => (
                <div key={m.model} className="p-3 rounded-lg bg-slate-800/60 border border-slate-700 text-center">
                  <Cpu size={16} className="mx-auto mb-1 text-slate-400" />
                  <p className="text-xs font-mono text-white">{m.model}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{m.tag}</p>
                </div>
              ))}
            </div>
          </Section>

          {/* Database Setup */}
          <Section icon={Database} title="Database Setup" id="database">
            <p className="text-slate-300 text-sm font-medium mb-2">With PostgreSQL (Recommended for Production)</p>
            <CodeBlock language=".env" code={`DATABASE_URL=postgresql://user:password@host:5432/nucleus`} />
            <CodeBlock code={`npm run db:push`} />

            <p className="text-slate-300 text-sm font-medium mt-5 mb-2">Without Database (Development / Demo)</p>
            <p className="text-slate-400 text-sm">Leave <code className="text-blue-400">DATABASE_URL</code> unset. The app runs in memory — all features work but data is lost on restart.</p>
          </Section>

          {/* Tech Stack */}
          <Section icon={Layers} title="Tech Stack" id="tech-stack">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                {
                  category: "Frontend",
                  items: ["React 18 + TypeScript", "Vite", "Tailwind CSS + shadcn/ui", "TanStack Query v5", "Wouter (routing)", "React Flow, Mermaid.js, Cytoscape.js"],
                },
                {
                  category: "Backend",
                  items: ["Express.js + TypeScript", "Node.js 18+", "Server-Sent Events (SSE)", "Multer (file uploads)", "bcrypt + express-session", "Zod + drizzle-zod (validation)"],
                },
                {
                  category: "AI / LLM",
                  items: ["Anthropic Claude (primary)", "OpenAI GPT-4o (fallback)", "Ollama — local/offline LLMs", "Code Llama, Deepseek, Mistral", "Prompt caching + Extended Thinking", "ChromaDB (ZenVector — planned)"],
                },
                {
                  category: "Data & Analysis",
                  items: ["PostgreSQL + Drizzle ORM", "Neon serverless DB", "Python: openpyxl, NumPy, Graphviz", "CWE rule engine (30+ patterns)", "ISO/IEC 5055 quality scoring", "OWASP Top 10 mapping"],
                },
              ].map(group => (
                <div key={group.category} className="rounded-lg border border-slate-700 bg-slate-900/50 p-4">
                  <p className="text-xs font-semibold text-blue-400 uppercase tracking-wider mb-3">{group.category}</p>
                  <ul className="space-y-1.5">
                    {group.items.map(item => (
                      <li key={item} className="flex items-center gap-2 text-xs text-slate-300">
                        <div className="w-1 h-1 rounded-full bg-blue-500 shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </Section>

          {/* Footer */}
          <div className="mt-10 pt-6 border-t border-slate-800 flex items-center justify-between text-xs text-slate-600">
            <span>Nucleus 2.0 · Zensar Technologies · AMEX Diamond Project</span>
            <span>Internal use only — not for public distribution</span>
          </div>
        </main>
      </div>
    </div>
  );
}
