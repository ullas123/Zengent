/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, FileCode, Folder, Copy, Download, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import JSZip from "jszip";

interface GeneratedFile {
  id?: string;
  agentId?: string;
  agentName?: string;
  filename?: string;
  lang?: string;
  code?: string;
  path?: string;
  content?: string;
}

interface NormalizedFile {
  id: string;
  group: string;
  filename: string;
  code: string;
  lang: string;
}

function normalize(raw: GeneratedFile[], source: "generated" | "pulled"): NormalizedFile[] {
  if (source === "pulled") {
    return raw.map((f, i) => ({
      id: `pulled_${i}`,
      group: (f.path || "").split("/").slice(0, -1).join("/") || "root",
      filename: (f.path || `file_${i}`).split("/").pop() || `file_${i}`,
      code: f.content || "",
      lang: (f.path || "").split(".").pop() || "text",
    }));
  }
  return raw.map((f, i) => ({
    id: f.id || `gen_${i}`,
    group: f.agentName || f.agentId || "Unassigned",
    filename: f.filename || `file_${i}`,
    code: f.code || "",
    lang: f.lang || "text",
  }));
}

export default function CodeExplorerPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [source, setSource] = useState<"generated" | "pulled">("generated");
  const [files, setFiles] = useState<NormalizedFile[]>([]);
  const [selected, setSelected] = useState<NormalizedFile | null>(null);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const initialSource = params.get("source") === "pulled" ? "pulled" : "generated";
    setSource(initialSource);
    loadFiles(initialSource);
  }, []);

  const loadFiles = (src: "generated" | "pulled") => {
    const key = src === "pulled" ? "nucleus_pulled_files" : "nucleus_generated_files";
    const stored = sessionStorage.getItem(key);
    if (stored) {
      try {
        const raw = JSON.parse(stored);
        const normalized = normalize(raw, src);
        setFiles(normalized);
        setSelected(normalized[0] || null);
      } catch {
        setFiles([]);
      }
    } else {
      setFiles([]);
      setSelected(null);
    }
  };

  const switchSource = (src: "generated" | "pulled") => {
    setSource(src);
    loadFiles(src);
  };

  const grouped = useMemo(() => {
    const filtered = files.filter(f =>
      !search || f.filename.toLowerCase().includes(search.toLowerCase()) || f.group.toLowerCase().includes(search.toLowerCase())
    );
    return filtered.reduce((acc, f) => {
      if (!acc[f.group]) acc[f.group] = [];
      acc[f.group].push(f);
      return acc;
    }, {} as Record<string, NormalizedFile[]>);
  }, [files, search]);

  const copyCode = () => {
    if (!selected) return;
    navigator.clipboard.writeText(selected.code);
    toast({ title: "Copied to clipboard", description: selected.filename });
  };

  const downloadAll = async () => {
    if (files.length === 0) return;
    const zip = new JSZip();
    files.forEach(f => zip.file(`${f.group}/${f.filename}`, f.code));
    const blob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = source === "pulled" ? "nucleus-pulled-code.zip" : "nucleus-generated-code.zip";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 60px)", background: "#F8FAFC" }}>
      <div style={{ height: 52, background: "#FFFFFF", borderBottom: "1px solid #E2E8F0", display: "flex", alignItems: "center", gap: 12, padding: "0 16px", flexShrink: 0 }}>
        <button onClick={() => navigate("/zenseai-platform")} style={{ display: "flex", alignItems: "center", gap: 6, background: "none", border: "none", color: "#64748B", fontSize: 13, cursor: "pointer" }}>
          <ArrowLeft size={14} /> Back
        </button>
        <div style={{ width: 1, height: 20, background: "#E2E8F0" }} />
        <span style={{ fontWeight: 800, fontSize: 14 }}>Code Explorer</span>

        <div style={{ display: "flex", gap: 4, marginLeft: 12 }}>
          <button onClick={() => switchSource("generated")} style={{
            padding: "4px 10px", borderRadius: 6, fontSize: 11, cursor: "pointer",
            background: source === "generated" ? "#ECFDF5" : "#F1F5F9",
            border: `1px solid ${source === "generated" ? "#10B981" : "#E2E8F0"}`,
            color: source === "generated" ? "#10B981" : "#64748B",
          }}>Generated</button>
          <button onClick={() => switchSource("pulled")} style={{
            padding: "4px 10px", borderRadius: 6, fontSize: 11, cursor: "pointer",
            background: source === "pulled" ? "#ECFDF5" : "#F1F5F9",
            border: `1px solid ${source === "pulled" ? "#10B981" : "#E2E8F0"}`,
            color: source === "pulled" ? "#10B981" : "#64748B",
          }}>Pulled from GitHub</button>
        </div>

        <div style={{ flex: 1 }} />

        <div style={{ position: "relative" }}>
          <Search size={13} style={{ position: "absolute", left: 8, top: 8, color: "#94A3B8" }} />
          <input
            placeholder="Search files..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ paddingLeft: 26, paddingRight: 8, height: 28, fontSize: 12, border: "1px solid #E2E8F0", borderRadius: 6, width: 200 }}
          />
        </div>
        <button onClick={downloadAll} disabled={files.length === 0} style={{
          display: "flex", alignItems: "center", gap: 4, padding: "5px 10px",
          background: "#F1F5F9", border: "1px solid #E2E8F0", borderRadius: 6, cursor: files.length ? "pointer" : "not-allowed",
          fontSize: 11, color: "#64748B",
        }}>
          <Download size={13} /> Download All
        </button>
      </div>

      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
        <div style={{ width: 280, borderRight: "1px solid #E2E8F0", background: "#FFFFFF", overflowY: "auto", flexShrink: 0 }}>
          {Object.keys(grouped).length === 0 ? (
            <div style={{ padding: 24, textAlign: "center", color: "#94A3B8", fontSize: 12 }}>
              No {source === "pulled" ? "pulled" : "generated"} files found.<br />
              {source === "generated" ? "Run the flow in Agent Factory first." : "Use the GitHub configuration page to pull a repository."}
            </div>
          ) : (
            Object.entries(grouped).map(([group, groupFiles]) => (
              <div key={group}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "8px 12px", fontSize: 11, fontWeight: 700, color: "#475569", background: "#F8FAFC", borderBottom: "1px solid #F1F5F9" }}>
                  <Folder size={12} /> {group} <span style={{ color: "#94A3B8", fontWeight: 400 }}>({groupFiles.length})</span>
                </div>
                {groupFiles.map(f => (
                  <div
                    key={f.id}
                    onClick={() => setSelected(f)}
                    style={{
                      display: "flex", alignItems: "center", gap: 6, padding: "6px 20px", fontSize: 12, cursor: "pointer",
                      background: selected?.id === f.id ? "#ECFDF5" : "transparent",
                      color: selected?.id === f.id ? "#059669" : "#334155",
                      borderLeft: selected?.id === f.id ? "2px solid #10B981" : "2px solid transparent",
                    }}
                  >
                    <FileCode size={12} /> {f.filename}
                  </div>
                ))}
              </div>
            ))
          )}
        </div>

        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
          {selected ? (
            <>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 16px", borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <FileCode size={14} />
                  <span style={{ fontWeight: 700, fontSize: 13 }}>{selected.filename}</span>
                  <span style={{ fontSize: 10, color: "#94A3B8" }}>{selected.group}</span>
                </div>
                <button onClick={copyCode} style={{ display: "flex", alignItems: "center", gap: 4, padding: "4px 8px", background: "#F1F5F9", border: "1px solid #E2E8F0", borderRadius: 6, cursor: "pointer", fontSize: 11, color: "#64748B" }}>
                  <Copy size={12} /> Copy
                </button>
              </div>
              <pre style={{ flex: 1, overflow: "auto", margin: 0, padding: 16, fontSize: 12, lineHeight: 1.6, fontFamily: "monospace", background: "#0F172A", color: "#E2E8F0" }}>
                {selected.code}
              </pre>
            </>
          ) : (
            <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: "#94A3B8", fontSize: 13 }}>
              Select a file to view its contents
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
