/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { Link } from "wouter";
import {
  Bot, Code, Shield, Zap, Globe, FileText, Users, CheckCircle,
  Sparkles, Database, Lock, Layers, BrainCircuit, Workflow,
  GitBranch, TestTube, Rocket, Settings, BarChart3, FlaskConical,
  Terminal, Package, MonitorCheck, RefreshCw, BookMarked, Play,
  Search, FileArchive, Github, Table2, Download, ScanLine,
  ShieldAlert, FileJson, Plus, Eye, Building2, ArrowRight,
  Cpu, FileCode2, ServerCrash, SquareCode,
} from "lucide-react";

// ─── Team ─────────────────────────────────────────────────────────────────────

const TEAM = [
  { name: "Rajesh Madhai",        role: "Vice President — Products & Platforms", org: "AES, Zensar Technologies", highlight: true },
  { name: "Kaushik Saha",         role: "Project Manager — AES",                 org: "AMEX Diamond Project" },
  { name: "Piyush Gupta",         role: "Project Manager (Onshore)",              org: "AMEX Diamond Project" },
  { name: "Sameer Kumar Sharma",  role: "Project Manager (Offshore)",             org: "AMEX Diamond Project" },
  { name: "Ullas Krishnan",       role: "AI Solution Architect",                 org: "Nucleus Platform · Diamond Project" },
  { name: "Hrushikesh Nalawade",  role: "Solution Architect",                    org: "Nucleus Platform · Diamond Project" },
  { name: "Vinoj Kannan",         role: "Architect",                             org: "Nucleus Diamond Platform" },
];

// ─── Agents ───────────────────────────────────────────────────────────────────

const ZENSEAI_AGENTS = [
  { id:"A01", emoji:"🎯", name:"SDLC Orchestrator",        domain:"Control",      desc:"Plans delivery, sets stage gates, builds agent chains and manages risk across the pipeline." },
  { id:"A02", emoji:"⚖️", name:"Policy & Compliance",     domain:"Control",      desc:"Enforces PCI-DSS, GDPR, SOX, HIPAA requirements and produces audit trails." },
  { id:"A03", emoji:"📚", name:"Knowledge / RAG",          domain:"Control",      desc:"Retrieves context from Confluence, SharePoint, PDFs to augment downstream agents." },
  { id:"A04", emoji:"👤", name:"Human Approval Gate",      domain:"Control",      desc:"Inserts human-in-the-loop checkpoints — architecture sign-off, CAB, PO acceptance." },
  { id:"A05", emoji:"📊", name:"Eval & Telemetry",         domain:"Control",      desc:"Produces quality scorecards, pipeline metrics and improvement recommendations." },
  { id:"A06", emoji:"📋", name:"Requirements Intelligence",domain:"Requirements", desc:"Converts business needs into epics, user stories (INVEST), NFRs and acceptance criteria." },
  { id:"A07", emoji:"🎨", name:"Experience Design",        domain:"Requirements", desc:"Wireframe specs, BDD Gherkin, customer journey maps and accessibility requirements." },
  { id:"A08", emoji:"🏗️", name:"Solution Architecture",  domain:"Architecture", desc:"Generates HLD, LLD, OpenAPI 3.0 contracts, ADRs and security architecture patterns." },
  { id:"A09", emoji:"💻", name:"Engineering Delivery",     domain:"Development",  desc:"Produces production-ready backend/frontend code, DB schemas, READMEs and inline docs." },
  { id:"A10", emoji:"🔄", name:"Code Modernisation",       domain:"Development",  desc:"Migrates legacy code, upgrades frameworks, rewrites COBOL to Java/Python." },
  { id:"A11", emoji:"🔍", name:"Code Quality Review",      domain:"Development",  desc:"Reviews for CWE/OWASP vulnerabilities, cyclomatic complexity and merge readiness." },
  { id:"A12", emoji:"🧪", name:"Test Engineering",         domain:"Testing",      desc:"Creates unit, integration, BDD tests, test data sets and coverage reports." },
  { id:"A13", emoji:"🛡️", name:"Quality & Security",      domain:"Testing",      desc:"DAST/SAST scanning, performance test plans, CVE reports and OWASP Top 10 mapping." },
  { id:"A14", emoji:"🚀", name:"Release Engineering",      domain:"Release",      desc:"CI/CD pipelines (GitHub Actions/Jenkins), Terraform IaC, canary configs, CAB packs." },
  { id:"A15", emoji:"⚙️", name:"RunOps & Enhancement",    domain:"RunOps",       desc:"Incident RCA, runbooks, SLA monitoring, SLO configs and enhancement backlog." },
];

const DOMAIN_COLOR: Record<string, string> = {
  Control: "bg-pink-50 border-pink-200 text-pink-700",
  Requirements: "bg-blue-50 border-blue-200 text-blue-700",
  Architecture: "bg-green-50 border-green-200 text-green-700",
  Development: "bg-purple-50 border-purple-200 text-purple-700",
  Testing: "bg-amber-50 border-amber-200 text-amber-700",
  Release: "bg-red-50 border-red-200 text-red-700",
  RunOps: "bg-cyan-50 border-cyan-200 text-cyan-700",
};

// ─── Platform capabilities ────────────────────────────────────────────────────

const NUCLEUS_CAPABILITIES = [
  { icon: <Code className="w-5 h-5 text-blue-500" />,       title: "Multi-Language Code Analysis",    desc: "Analyse Java, Python, PySpark, COBOL/JCL, TypeScript and C# codebases with specialised parsers for each language and framework." },
  { icon: <BrainCircuit className="w-5 h-5 text-purple-500" />, title: "Nucleus 2.0 Agent Factory",       desc: "15 specialist AI agents covering every SDLC phase — drag-and-drop canvas, 6-tab inspector, GPT-4o execution with context chaining." },
  { icon: <Shield className="w-5 h-5 text-red-500" />,      title: "Security & Compliance Scanning",  desc: "CWE/OWASP vulnerability detection, demographic PII/PHI field scanning, PCI-DSS, GDPR, SOX and HIPAA compliance reporting." },
  { icon: <BarChart3 className="w-5 h-5 text-green-500" />, title: "ISO/IEC 5055 Quality Metrics",    desc: "Reliability, security, performance and maintainability scoring aligned to ISO 5055 standards with actionable improvement recommendations." },
  { icon: <FileText className="w-5 h-5 text-orange-500" />, title: "Automated Documentation",         desc: "AI-generated architecture docs, UML/sequence diagrams, ER diagrams, dependency graphs and Confluence-ready professional reports." },
  { icon: <Database className="w-5 h-5 text-cyan-500" />,   title: "Data Flow & Impact Analysis",      desc: "Function call graphs, field-level data tracking, cross-module dependency visualisation and blast-radius assessment for code changes." },
  { icon: <Globe className="w-5 h-5 text-indigo-500" />,    title: "GitHub & Confluence Integration",  desc: "Clone and analyse public/private GitHub repos. Publish reports directly to Confluence spaces with structured hierarchy." },
  { icon: <Rocket className="w-5 h-5 text-pink-500" />,     title: "Migration Planning",               desc: "POD→POA migration analysis, modernisation roadmaps, COBOL-to-Java transformation, migration priority scoring and effort estimation." },
  {
    icon: <ScanLine className="w-5 h-5 text-teal-500" />,
    title: "API Scan — Two-Stage BRD Pipeline",
    desc: "Deterministic multi-language Stage 1 extraction (Java, C#, Python, JS/TS, SQL) → ExtractionJson → Stage 2 BRD narrative. Detects 11 SORs, 17 approved tables, 12 PII categories. Supports up to 20 ZIPs or 10 GitHub repos in one scan.",
  },
];

// ─── API Scan feature cards (updated for BRD spec) ──────────────────────────

const API_SCAN_FEATURES = [
  {
    icon: <Workflow className="w-5 h-5 text-green-600" />,
    title: "Two-Stage Pipeline (BRD Spec)",
    desc: "Stage 1 is a deterministic parser — no LLM, 100% reproducible. Stage 2 generates the BRD narrative from Stage 1 JSON only (never raw source). Same code always produces identical findings — no hallucination, no model drift.",
  },
  {
    icon: <FileJson className="w-5 h-5 text-yellow-600" />,
    title: "ExtractionJson — Stage 1 Output",
    desc: "Every scan produces a downloadable extraction.json with scan_metadata, api_integrations, table_usages, demographic_fields_found and unlisted_sources_found. Git-diffable and cacheable — regenerate Stage 2 without re-running Stage 1.",
  },
  {
    icon: <FileArchive className="w-5 h-5 text-blue-500" />,
    title: "Multi-Repo ZIP Upload",
    desc: "Upload up to 20 ZIP archives (100 MB each) via drag-and-drop or file browser. All repos are scanned together producing a single consolidated BRD with per-repo file attribution.",
  },
  {
    icon: <Github className="w-5 h-5 text-gray-800" />,
    title: "Multi-Repo GitHub Scanning",
    desc: "Add up to 10 GitHub repositories in one scan — each with its own URL, branch and access token. Downloads are parallelised; any failed repo is flagged and skipped without stopping the rest.",
  },
  {
    icon: <GitBranch className="w-5 h-5 text-purple-500" />,
    title: "Branch & Enterprise Token",
    desc: "Specify any branch or leave blank to auto-detect (tries main → master → HEAD). Personal Access Tokens supported for private repos and enterprise GitHub subdomains (e.g. github.aexp.com).",
  },
  {
    icon: <Building2 className="w-5 h-5 text-blue-600" />,
    title: "Application Context Form",
    desc: "A BRD spec requirement: fill in App Name, Business Function, Domain, Tech Stack, Known Systems and Compliance Scope before scanning. This frames the executive summary and priority calls — leaving it blank still produces a valid technical report.",
  },
  {
    icon: <Code className="w-5 h-5 text-orange-500" />,
    title: "6-Language Detection",
    desc: "Auto-detects Java, C#, Python, React-JS/TS, SQL and Config files from extensions and build files (pom.xml, .csproj, requirements.txt, package.json). Each language has its own extraction pattern set — FeignClient for Java, HttpClient for C#, requests.* for Python, fetch/axios for JS/TS.",
  },
  {
    icon: <Search className="w-5 h-5 text-indigo-500" />,
    title: "Integration Type Classification",
    desc: "Classifies the workspace as API-Based (outbound REST/HTTP clients), Query-Based (direct SQL/ORM table access), Both (mixed), or None — based purely on static pattern evidence in source files.",
  },
  {
    icon: <Globe className="w-5 h-5 text-teal-500" />,
    title: "11 SOR System Detection",
    desc: "Scans for outbound integrations to CRPS, Anagrafe, Income SOR, Triumph, MNS, GSTAR, CM-CARS, APA AR, CARE, DIG and GAR. Extracts endpoint URLs, HTTP methods, source class/function names and config locations — all verbatim from code.",
  },
  {
    icon: <Table2 className="w-5 h-5 text-cyan-600" />,
    title: "17 Approved SOR Tables",
    desc: "Identifies SQL and ORM references to 17 pre-approved SOR tables. Reports table name, query type (SELECT/INSERT/UPDATE/DELETE), source file, class/proc name and raw query excerpt. Covers JPA entities, SQLAlchemy __tablename__ and EF DbSet<>.",
  },
  {
    icon: <ShieldAlert className="w-5 h-5 text-red-500" />,
    title: "PII / Demographic Discovery",
    desc: "Detects 12 PII categories: SSN, Date of Birth, Name, Address, Phone, Email, Account/Card numbers, Gender/Nationality, Income, IP/MAC Address, Passport/License, Marital Status. Reports field name, data type, source file and line number.",
  },
  {
    icon: <Workflow className="w-5 h-5 text-purple-600" />,
    title: "Flow Diagrams — 3 Views",
    desc: "Results include an interactive SVG Pipeline Diagram (repos → Stage 1 → extraction.json → Stage 2 → BRD), a SOR Dependency Graph (repos ↔ SOR systems found), and an API Function Call Dependency Map table.",
  },
  {
    icon: <CheckCircle className="w-5 h-5 text-green-500" />,
    title: "Complete Gap Analysis",
    desc: "Explicitly states every SOR not found ('No outbound API integration with X found'), every approved table not found, and all unlisted external HTTP sources discovered outside the known SOR list.",
  },
  {
    icon: <Download className="w-5 h-5 text-orange-500" />,
    title: "11-Section BRD HTML Report",
    desc: "Downloads a self-contained HTML report: Executive Summary, Application Context, Pipeline Diagram, Integration Type, API Findings, Table Findings, Holistic Demographic Discovery, Data Origin Summary, Impacted Components (language-specific), Final Summary and Scan Provenance footer.",
  },
];

// ─── Language support matrix ──────────────────────────────────────────────────

const LANG_SUPPORT = [
  {
    lang: "Java",
    color: "bg-orange-50 border-orange-200",
    badge: "bg-orange-100 text-orange-700 border-orange-300",
    patterns: ["@FeignClient annotation", "RestTemplate / WebClient", "@RequestMapping routes", "JPA @Entity / @Table", "@Value config binding"],
    parsedBy: "javalang-regex",
  },
  {
    lang: "C#",
    color: "bg-purple-50 border-purple-200",
    badge: "bg-purple-100 text-purple-700 border-purple-300",
    patterns: ["HttpClient / RestSharp", "[Route] / [HttpGet] attributes", "EF DbSet<> table mappings", "appsettings.json bindings", "async GetAsync / PostAsync"],
    parsedBy: "roslyn-regex",
  },
  {
    lang: "Python",
    color: "bg-blue-50 border-blue-200",
    badge: "bg-blue-100 text-blue-700 border-blue-300",
    patterns: ["requests.* / httpx.*", "@app.route / @router.get", "SQLAlchemy __tablename__", "Django ORM models.Model", "FastAPI route decorators"],
    parsedBy: "ast-regex",
  },
  {
    lang: "React-JS / TS",
    color: "bg-cyan-50 border-cyan-200",
    badge: "bg-cyan-100 text-cyan-700 border-cyan-300",
    patterns: ["fetch(url) calls", "axios.get / post / put", "useQuery / useMutation", "API client classes", ".env base URL references"],
    parsedBy: "tree-sitter-regex",
  },
  {
    lang: "SQL",
    color: "bg-green-50 border-green-200",
    badge: "bg-green-100 text-green-700 border-green-300",
    patterns: ["SELECT FROM tablename", "INSERT INTO tablename", "UPDATE tablename SET", "DELETE FROM tablename", "Stored procedures"],
    parsedBy: "sqlparse-regex",
  },
  {
    lang: "Config",
    color: "bg-gray-50 border-gray-200",
    badge: "bg-gray-100 text-gray-700 border-gray-300",
    patterns: [".yml / .yaml url:", ".properties *.url=", ".env *_URL=", "appsettings.json BaseAddress", "OpenAPI / Swagger specs"],
    parsedBy: "yaml-properties-env-regex",
  },
];

// ─── PII categories ───────────────────────────────────────────────────────────

const PII_CATEGORIES = [
  { icon: "🪪", name: "SSN / National ID",             type: "String" },
  { icon: "🎂", name: "Date of Birth",                 type: "Date" },
  { icon: "👤", name: "Name (First/Last/Full)",        type: "String" },
  { icon: "🏠", name: "Address / Postal Code",         type: "String" },
  { icon: "📱", name: "Phone / Mobile Number",         type: "String" },
  { icon: "📧", name: "Email Address",                 type: "String" },
  { icon: "💳", name: "Account / Card Number",         type: "String" },
  { icon: "🌍", name: "Gender / Nationality",          type: "String" },
  { icon: "💰", name: "Income / Salary",               type: "Decimal" },
  { icon: "🌐", name: "IP / MAC Address",              type: "String" },
  { icon: "🛂", name: "Passport / Driver's License",  type: "String" },
  { icon: "💍", name: "Marital Status / Occupation",  type: "String" },
];

// ─── Tech stack ───────────────────────────────────────────────────────────────

const TECH_STACK = [
  { cat: "Frontend",       items: ["React 18", "TypeScript", "Tailwind CSS", "shadcn/ui", "React Flow", "TanStack Query", "Wouter", "Vite"] },
  { cat: "Backend",        items: ["Express.js", "Node.js", "TypeScript", "Drizzle ORM", "PostgreSQL", "bcrypt", "express-session"] },
  { cat: "AI & ML",        items: ["OpenAI GPT-4o", "Anthropic Claude", "Ollama (local LLM)", "Code Llama", "Deepseek Coder", "NumPy Neural Net"] },
  { cat: "Analysis",       items: ["Custom AST Parsers", "Regex + Pattern Engine", "CWE Rule Engine", "ISO 5055 Scorer", "Mermaid.js"] },
  { cat: "Visualisation",  items: ["React Flow", "Cytoscape.js", "Graphviz", "Mermaid.js", "jsPDF", "Inline SVG Diagrams"] },
  { cat: "Integrations",   items: ["GitHub REST API", "Confluence REST API", "Multer (ZIP upload)", "openpyxl", "ChromaDB (planned)"] },
  {
    cat: "API Scan",
    items: [
      "JSZip (ZIP extraction)", "Native fetch (GitHub archive)", "Two-Stage BRD Pipeline",
      "6-Language Parser Engine", "ExtractionJson (Stage 1 output)", "SOR Pattern Engine",
      "11 SOR Systems", "17 Approved Tables", "12 PII Categories",
      "Multi-Repo ZIP (up to 20)", "Multi-Repo GitHub (up to 10)", "SVG Flow Diagrams",
      "HTML BRD Report (11 sections)",
    ],
  },
];

// ─── BRD report sections ──────────────────────────────────────────────────────

const BRD_SECTIONS = [
  { num: "1", title: "Executive Summary",           desc: "Files scanned, SORs detected, PII fields, languages, repos — all in one glance." },
  { num: "2", title: "Application Context",         desc: "App name, domain, tech stack, compliance scope — filled before scanning." },
  { num: "3", title: "Pipeline Flow Diagram",       desc: "SVG diagram of the two-stage architecture embedded in the report." },
  { num: "4", title: "Integration Type",            desc: "API-Based / Query-Based / Both / None with WHY explanation." },
  { num: "5", title: "API-Based SOR Findings",      desc: "Verbatim endpoint URLs, HTTP methods, source files, languages — per approved SOR." },
  { num: "6", title: "Query-Based Table Findings",  desc: "Table name, query type, language, source file and query excerpt — per approved table." },
  { num: "7", title: "Holistic Demographic Discovery", desc: "All 12 PII categories found with line numbers and unlisted external HTTP sources." },
  { num: "8", title: "Demographic Data Origin Summary", desc: "Cross-reference: API endpoint ↔ SOR ↔ PII field ↔ source location ↔ language." },
  { num: "9", title: "Impacted Components",         desc: "Language-specific breakdown: Java (DAO/Service/POJO), C# (EF/Repo), Python (ORM/Flask), JS/TS (hooks/API clients)." },
  { num: "10", title: "Final Audit Summary",        desc: "Consolidated table of all findings, gaps, and scan statistics." },
  { num: "11", title: "Scan Provenance Footer",     desc: "Languages detected, libraries used, Stage 2 model, token usage — mandatory per BRD spec." },
];

// ─── Pipeline stages ──────────────────────────────────────────────────────────

const PIPELINE_STAGES = [
  {
    step: "01",
    color: "bg-blue-600",
    light: "bg-blue-50 border-blue-200",
    icon: <FileArchive className="w-5 h-5 text-blue-600" />,
    title: "Input Repos",
    sub: "ZIP or GitHub",
    desc: "Up to 20 ZIP archives or 10 GitHub repos in a single scan. Files merged with per-repo attribution.",
  },
  {
    step: "02",
    color: "bg-green-600",
    light: "bg-green-50 border-green-200",
    icon: <Cpu className="w-5 h-5 text-green-600" />,
    title: "Stage 1 — Parser",
    sub: "Deterministic · No LLM",
    desc: "Language-specific static analysis extracts exact facts: file paths, line numbers, endpoint strings, table names, PII fields.",
  },
  {
    step: "03",
    color: "bg-yellow-500",
    light: "bg-yellow-50 border-yellow-200",
    icon: <FileJson className="w-5 h-5 text-yellow-600" />,
    title: "extraction.json",
    sub: "Stage 1 Output",
    desc: "Structured JSON output — git-diffable, cacheable, downloadable. Running Stage 1 twice on identical code produces byte-identical JSON.",
  },
  {
    step: "04",
    color: "bg-purple-600",
    light: "bg-purple-50 border-purple-200",
    icon: <SquareCode className="w-5 h-5 text-purple-600" />,
    title: "Stage 2 — BRD",
    sub: "Rule-based · JSON-only",
    desc: "Consumes extraction.json only — never raw source. Cannot invent a table name or endpoint it was never shown. No hallucination, no drift.",
  },
  {
    step: "05",
    color: "bg-pink-600",
    light: "bg-pink-50 border-pink-200",
    icon: <Download className="w-5 h-5 text-pink-600" />,
    title: "BRD HTML Report",
    sub: "11 Sections · Self-contained",
    desc: "Downloadable HTML: Executive Summary → Application Context → Pipeline Diagram → SOR Findings → PII Discovery → Impact Analysis → Provenance.",
  },
];

// ─── Page component ───────────────────────────────────────────────────────────

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">

      {/* ── HERO ──────────────────────────────────────────────────────────────── */}
      <div className="text-center mb-14">
        <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 border border-blue-200 rounded-full px-4 py-1.5 text-sm font-semibold mb-4">
          <FlaskConical className="w-4 h-4" /> AMEX Diamond Project · Zensar Technologies
        </div>
        <h1 className="text-5xl font-extrabold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-3 leading-tight">
          Nucleus
        </h1>
        <h2 className="text-2xl font-bold text-gray-700 mb-4">
          Innersource Agentic SDLC Framework
        </h2>
        <p className="text-lg text-gray-500 max-w-3xl mx-auto mb-6">
          An enterprise AI platform combining multi-language code intelligence, ISO 5055 quality metrics,
          security scanning, the Nucleus 2.0 Agent Factory and a two-stage deterministic SOR Discovery scanner
          that produces non-hallucinated BRD reports from Java, C#, Python, JS/TS and SQL codebases.
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          {[
            "15 Nucleus 2.0 Agents","62 SDLC Activities","GPT-4o · Claude Powered","Multi-Language",
            "ISO 5055 Quality","PCI-DSS Scanning","Confluence Sync","GitHub Integration",
            "API Scan · 11 SORs","17 Approved Tables","12 PII Categories","Two-Stage BRD Pipeline",
            "Multi-Repo · 10 GitHub Repos","ExtractionJson · Stage 1",
          ].map(b => (
            <span key={b} className="bg-white border border-gray-200 text-gray-600 rounded-full px-3 py-1 text-sm font-medium shadow-sm">{b}</span>
          ))}
        </div>
      </div>

      {/* ── KEY METRICS ─────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 mb-14">
        {[
          { v:"15",    l:"Nucleus 2.0 Agents",  icon:<Bot className="w-4 h-4 text-blue-500" /> },
          { v:"62",    l:"SDLC Activities",      icon:<Zap className="w-4 h-4 text-yellow-500" /> },
          { v:"6",     l:"Languages Parsed",     icon:<Code className="w-4 h-4 text-orange-500" /> },
          { v:"11",    l:"SOR Systems",          icon:<ScanLine className="w-4 h-4 text-teal-500" /> },
          { v:"17",    l:"Approved Tables",      icon:<Table2 className="w-4 h-4 text-indigo-500" /> },
          { v:"12",    l:"PII Categories",       icon:<ShieldAlert className="w-4 h-4 text-red-500" /> },
          { v:"2",     l:"Pipeline Stages",      icon:<Workflow className="w-4 h-4 text-green-500" /> },
          { v:"10",    l:"GitHub Repos / Scan",  icon:<Github className="w-4 h-4 text-gray-700" /> },
          { v:"20",    l:"ZIPs / Scan",          icon:<FileArchive className="w-4 h-4 text-blue-500" /> },
          { v:"11",    l:"BRD Report Sections",  icon:<FileText className="w-4 h-4 text-pink-500" /> },
          { v:"30+",   l:"CWE Rules",            icon:<Shield className="w-4 h-4 text-red-500" /> },
          { v:"ISO",   l:"5055 Quality",         icon:<BarChart3 className="w-4 h-4 text-cyan-500" /> },
          { v:"GPT-4o",l:"AI Model",             icon:<BrainCircuit className="w-4 h-4 text-pink-500" /> },
          { v:"0",     l:"Hallucinations",       icon:<CheckCircle className="w-4 h-4 text-green-500" /> },
        ].map(m => (
          <div key={m.l} className="bg-white border border-gray-100 rounded-xl p-3 text-center shadow-sm">
            <div className="flex justify-center mb-1.5">{m.icon}</div>
            <div className="text-xl font-bold text-gray-900 leading-tight">{m.v}</div>
            <div className="text-xs text-gray-400 leading-tight mt-0.5">{m.l}</div>
          </div>
        ))}
      </div>

      {/* ── PLATFORM CAPABILITIES ───────────────────────────────────────────── */}
      <div className="mb-14">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Platform Capabilities</h2>
        <p className="text-gray-500 mb-6">Everything Nucleus delivers out of the box</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {NUCLEUS_CAPABILITIES.map(c => (
            <div key={c.title} className="bg-white border border-gray-200 rounded-xl p-5 hover:shadow-md transition-shadow">
              <div className="mb-3">{c.icon}</div>
              <h3 className="font-bold text-gray-900 text-sm mb-2">{c.title}</h3>
              <p className="text-xs text-gray-500 leading-relaxed">{c.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── API SCAN — FULL SECTION ───────────────────────────────────────────── */}
      <div className="mb-14">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-teal-600 rounded-lg">
            <ScanLine className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">API Scan — SOR & Demographic Discovery</h2>
            <p className="text-gray-500 text-sm">
              Two-stage BRD pipeline · Multi-language · Multi-repo · Zero hallucination
            </p>
          </div>
          <Link href="/api-scan" className="ml-auto">
            <button className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-xl font-bold text-sm shadow transition-all hover:scale-105">
              <Search className="w-4 h-4" /> Open API Scan
            </button>
          </Link>
        </div>

        {/* ── What the BRD spec requires ── */}
        <div className="bg-gradient-to-r from-teal-50 to-green-50 border border-teal-200 rounded-xl p-5 mb-6">
          <p className="text-xs font-bold text-teal-700 uppercase tracking-wide mb-2">BRD Specification — Core Design Principle</p>
          <p className="text-sm text-teal-900 leading-relaxed">
            <span className="font-semibold">Do not ask an LLM to "scan the codebase and report findings" in one shot.</span>{" "}
            That produces different results on every run (model drift) and invents details that aren't there (hallucination).
            Instead, build a <span className="font-semibold">two-stage pipeline</span>: Stage 1 extracts exact facts using real parsers
            into a structured JSON — 100% reproducible. Stage 2 feeds only that JSON (never raw source) to the classifier,
            which produces the BRD narrative without adding any fact not present in the JSON.
          </p>
        </div>

        {/* ── Pipeline stages ── */}
        <div className="mb-6">
          <h3 className="text-base font-bold text-gray-900 mb-3 flex items-center gap-2">
            <Workflow className="w-4 h-4 text-green-600" /> Two-Stage Pipeline
          </h3>
          <div className="flex flex-col md:flex-row gap-3">
            {PIPELINE_STAGES.map((s, i) => (
              <div key={s.step} className="flex-1">
                <div className={`border rounded-xl p-4 ${s.light} h-full`}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`text-xs font-black text-white px-2 py-0.5 rounded-full ${s.color}`}>{s.step}</span>
                    {s.icon}
                    <span className="text-xs font-bold text-gray-700">{s.title}</span>
                  </div>
                  <p className="text-xs font-semibold text-gray-500 mb-1">{s.sub}</p>
                  <p className="text-xs text-gray-600 leading-relaxed">{s.desc}</p>
                </div>
                {i < PIPELINE_STAGES.length - 1 && (
                  <div className="hidden md:flex justify-center mt-3 -mb-3 text-gray-300">
                    {/* arrow hidden on mobile, shown via flex on md */}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* ── Language support matrix ── */}
        <div className="mb-6">
          <h3 className="text-base font-bold text-gray-900 mb-3 flex items-center gap-2">
            <Code className="w-4 h-4 text-orange-500" /> Language Support Matrix (Stage 1)
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
            {LANG_SUPPORT.map(l => (
              <div key={l.lang} className={`border rounded-xl p-4 ${l.color}`}>
                <div className="flex items-center justify-between mb-2">
                  <span className={`px-2.5 py-0.5 text-xs font-bold rounded-full border ${l.badge}`}>{l.lang}</span>
                  <span className="text-xs text-gray-400 font-mono">{l.parsedBy}</span>
                </div>
                <ul className="space-y-0.5">
                  {l.patterns.map(p => (
                    <li key={p} className="text-xs text-gray-600 flex items-start gap-1">
                      <CheckCircle className="w-3 h-3 text-green-500 flex-shrink-0 mt-0.5" />
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* ── Feature cards ── */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-6">
          {API_SCAN_FEATURES.map(f => (
            <div key={f.title} className="bg-white border border-gray-200 rounded-xl p-5 hover:shadow-md transition-shadow">
              <div className="mb-3">{f.icon}</div>
              <h3 className="font-bold text-gray-900 text-sm mb-2">{f.title}</h3>
              <p className="text-xs text-gray-500 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>

        {/* ── PII / Demographic categories ── */}
        <div className="bg-red-50 border border-red-200 rounded-xl p-5 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <ShieldAlert className="w-4 h-4 text-red-600" />
            <h3 className="font-bold text-gray-900 text-sm">12 PII / Demographic Field Categories</h3>
            <span className="text-xs text-gray-400">— detected by line-by-line pattern scanning</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
            {PII_CATEGORIES.map(p => (
              <div key={p.name} className="flex items-center gap-2 bg-white border border-red-100 rounded-lg px-3 py-2">
                <span className="text-base">{p.icon}</span>
                <div>
                  <div className="text-xs font-semibold text-gray-700 leading-tight">{p.name}</div>
                  <div className="text-xs text-gray-400 font-mono">{p.type}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── BRD Report sections ── */}
        <div className="bg-pink-50 border border-pink-200 rounded-xl p-5 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <FileText className="w-4 h-4 text-pink-600" />
            <h3 className="font-bold text-gray-900 text-sm">11-Section BRD HTML Report (downloadable)</h3>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-2">
            {BRD_SECTIONS.map(s => (
              <div key={s.num} className="flex gap-2 bg-white border border-pink-100 rounded-lg px-3 py-2">
                <span className="text-xs font-black text-pink-600 bg-pink-100 rounded-full w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5">{s.num}</span>
                <div>
                  <div className="text-xs font-bold text-gray-800 leading-tight">{s.title}</div>
                  <div className="text-xs text-gray-400 leading-snug mt-0.5">{s.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Approved tables ── */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 mb-4">
          <div className="flex items-center gap-2 mb-3">
            <Table2 className="w-4 h-4 text-indigo-500" />
            <h3 className="font-bold text-gray-900 text-sm">17 Approved SOR Tables (Query-Based detection)</h3>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {[
              "triumph_demographics","triumph_card_account","triumph_plastic_card",
              "gstar_card_details","gstar_account_details","gstar_customer_demographics",
              "gstar_corp_customer_demographics","cars_cm_demographics","mns_demographics_ar",
              "care_demographic","apa_ar_demographic","dcp_cm_mobile_dtl","dcp_cm_email_dtl",
              "anagrafe_customer","crps_customer_linkage","gstar_corp_card_details","gstar_corp_account_details",
            ].map(t => (
              <span key={t} className="px-2 py-0.5 text-xs font-mono rounded bg-gray-50 border border-gray-200 text-gray-600">{t}</span>
            ))}
          </div>
        </div>

        <Link href="/api-scan">
          <button className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow transition-all hover:scale-105">
            <Search className="w-4 h-4" /> Open API Scan <ArrowRight className="w-4 h-4" />
          </button>
        </Link>
      </div>

      {/* ── ZENSEAI AGENT FACTORY ────────────────────────────────────────────── */}
      <div className="mb-14">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-1">Nucleus 2.0 Agent Factory — All 15 Agents</h2>
            <p className="text-gray-500 text-sm">Specialist AI agents covering every SDLC domain, powered by GPT-4o</p>
          </div>
          <Link href="/zenseai-platform">
            <button className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow hover:shadow-lg transition-all hover:scale-105">
              <Play className="w-4 h-4" /> Launch Platform
            </button>
          </Link>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
          {ZENSEAI_AGENTS.map(a => (
            <div key={a.id} className="bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{a.emoji}</span>
                  <div>
                    <div className="font-bold text-gray-900 text-sm leading-tight">{a.name}</div>
                    <div className="text-xs font-mono font-bold text-blue-500">{a.id}</div>
                  </div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full border font-medium flex-shrink-0 ${DOMAIN_COLOR[a.domain]}`}>{a.domain}</span>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed">{a.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── TECH STACK ──────────────────────────────────────────────────────── */}
      <div className="mb-14">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Technology Stack</h2>
        <p className="text-gray-500 mb-6 text-sm">The engineering foundations of the Nucleus platform</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {TECH_STACK.map(t => (
            <div key={t.cat} className={`bg-white border rounded-xl p-5 ${t.cat === "API Scan" ? "border-teal-200 lg:col-span-3" : "border-gray-200"}`}>
              <h3 className="font-bold text-gray-900 mb-3 text-sm border-b pb-2 flex items-center gap-2">
                {t.cat === "API Scan" && <ScanLine className="w-4 h-4 text-teal-600" />}
                {t.cat}
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {t.items.map(i => (
                  <span key={i} className={`border text-xs rounded-full px-2.5 py-1 ${
                    t.cat === "API Scan"
                      ? "bg-teal-50 border-teal-200 text-teal-700"
                      : "bg-gray-50 border-gray-200 text-gray-600"
                  }`}>{i}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── TEAM ─────────────────────────────────────────────────────────────── */}
      <div className="bg-gradient-to-br from-blue-900 to-indigo-900 rounded-2xl p-8 text-white">
        <div className="flex items-center gap-3 mb-6">
          <Users className="w-6 h-6 text-blue-300" />
          <div>
            <h2 className="text-2xl font-bold">Team Diamond</h2>
            <p className="text-blue-300 text-sm">Zensar Technologies · AMEX Diamond Project</p>
          </div>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {TEAM.map(m => (
            <div key={m.name} className={`rounded-xl border p-4 ${m.highlight ? "bg-white/15 border-white/30" : "bg-white/8 border-white/15"}`}>
              <div className="font-bold text-white mb-0.5">{m.name}</div>
              <div className={`text-sm font-semibold mb-1 ${m.highlight ? "text-blue-200" : "text-blue-300"}`}>{m.role}</div>
              <div className="text-xs text-blue-400">{m.org}</div>
            </div>
          ))}
        </div>
        <div className="mt-6 pt-6 border-t border-white/20 text-center">
          <p className="text-blue-300 text-sm">
            <strong className="text-white">Nucleus</strong> is built and maintained by the Diamond team at Zensar Technologies as part of the AMEX engagement,
            delivering AI-powered innersource intelligence, automated SDLC tooling and the two-stage SOR Discovery BRD pipeline.
          </p>
        </div>
      </div>

    </div>
  );
}
