/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { Link } from "wouter";
import {
  Bot, Code, Shield, Zap, Globe, FileText, Users, CheckCircle,
  Sparkles, Database, Lock, Layers, BrainCircuit, Workflow,
  GitBranch, TestTube, Rocket, Settings, BarChart3, FlaskConical,
  Terminal, Package, MonitorCheck, RefreshCw, BookMarked, Play
} from "lucide-react";

const TEAM = [
  { name: "Rajesh Madhai",        role: "Vice President — Products & Platforms", org: "AES, Zensar Technologies", highlight: true },
  { name: "Kaushik Saha",         role: "Project Manager — AES",                 org: "AMEX Diamond Project" },
  { name: "Piyush Gupta",         role: "Project Manager (Onshore)",              org: "AMEX Diamond Project" },
  { name: "Sameer Kumar Sharma",  role: "Project Manager (Offshore)",             org: "AMEX Diamond Project" },
  { name: "Ullas Krishnan",       role: "AI Solution Architect",                 org: "Nucleus Platform · Diamond Project" },
  { name: "Hrushikesh Nalawade",  role: "Solution Architect",                    org: "Nucleus Platform · Diamond Project" },
  { name: "Vinoj Kannan",         role: "Architect",                             org: "Nucleus Diamond Platform" },
];

const ZENSEAI_AGENTS = [
  { id:"A01", emoji:"🎯", name:"SDLC Orchestrator",        domain:"Control",      desc:"Plans delivery, sets stage gates, builds agent chains and manages risk across the pipeline." },
  { id:"A02", emoji:"⚖️", name:"Policy & Compliance",     domain:"Control",      desc:"Enforces PCI-DSS, GDPR, SOX, HIPAA requirements and produces audit trails." },
  { id:"A03", emoji:"📚", name:"Knowledge / RAG",          domain:"Control",      desc:"Retrieves context from Confluence, SharePoint, PDFs to augment downstream agents." },
  { id:"A04", emoji:"👤", name:"Human Approval Gate",      domain:"Control",      desc:"Inserts human-in-the-loop checkpoints — architecture sign-off, CAB, PO acceptance." },
  { id:"A05", emoji:"📊", name:"Eval & Telemetry",         domain:"Control",      desc:"Produces quality scorecards, pipeline metrics and improvement recommendations." },
  { id:"A06", emoji:"📋", name:"Requirements Intelligence",domain:"Requirements", desc:"Converts business needs into epics, user stories (INVEST), NFRs and acceptance criteria." },
  { id:"A07", emoji:"🎨", name:"Experience Design",        domain:"Requirements", desc:"Wireframe specs, BDD Gherkin, customer journey maps and accessibility requirements." },
  { id:"A08", emoji:"🏗️", name:"Solution Architecture",  domain:"Architecture", desc:"Generates HLD, LLD, OpenAPI 3.0 contracts, ADRs and security architecture patterns." },
  { id:"A09", emoji:"💻", name:"Engineering Delivery",     domain:"Development",  desc:"Produces production-ready backend/frontend code, DB schemas, READMEs and inline docs." },
  { id:"A10", emoji:"🔄", name:"Code Modernisation",       domain:"Development",  desc:"Migrates legacy code, upgrades frameworks, rewrites COBOL to Java/Python." },
  { id:"A11", emoji:"🔍", name:"Code Quality Review",      domain:"Development",  desc:"Reviews for CWE/OWASP vulnerabilities, cyclomatic complexity and merge readiness." },
  { id:"A12", emoji:"🧪", name:"Test Engineering",         domain:"Testing",      desc:"Creates unit, integration, BDD tests, test data sets and coverage reports." },
  { id:"A13", emoji:"🛡️", name:"Quality & Security",      domain:"Testing",      desc:"DAST/SAST scanning, performance test plans, CVE reports and OWASP Top 10 mapping." },
  { id:"A14", emoji:"🚀", name:"Release Engineering",      domain:"Release",      desc:"CI/CD pipelines (GitHub Actions/Jenkins), Terraform IaC, canary configs, CAB packs." },
  { id:"A15", emoji:"⚙️", name:"RunOps & Enhancement",    domain:"RunOps",       desc:"Incident RCA, runbooks, SLA monitoring, SLO configs and enhancement backlog." },
];

const DOMAIN_COLOR: Record<string, string> = {
  Control: "bg-pink-50 border-pink-200 text-pink-700",
  Requirements: "bg-blue-50 border-blue-200 text-blue-700",
  Architecture: "bg-green-50 border-green-200 text-green-700",
  Development: "bg-purple-50 border-purple-200 text-purple-700",
  Testing: "bg-amber-50 border-amber-200 text-amber-700",
  Release: "bg-red-50 border-red-200 text-red-700",
  RunOps: "bg-cyan-50 border-cyan-200 text-cyan-700",
};

const NUCLEUS_CAPABILITIES = [
  { icon: <Code className="w-5 h-5 text-blue-500" />,       title: "Multi-Language Code Analysis",    desc: "Analyse Java, Python, PySpark, COBOL/JCL, TypeScript and C# codebases with specialised parsers for each language and framework." },
  { icon: <BrainCircuit className="w-5 h-5 text-purple-500" />, title: "Nucleus 2.0 Agent Factory",       desc: "15 specialist AI agents covering every SDLC phase — drag-and-drop canvas, 6-tab inspector, GPT-4o execution with context chaining." },
  { icon: <Shield className="w-5 h-5 text-red-500" />,      title: "Security & Compliance Scanning",  desc: "CWE/OWASP vulnerability detection, demographic PII/PHI field scanning, PCI-DSS, GDPR, SOX and HIPAA compliance reporting." },
  { icon: <BarChart3 className="w-5 h-5 text-green-500" />, title: "ISO/IEC 5055 Quality Metrics",    desc: "Reliability, security, performance and maintainability scoring aligned to ISO 5055 standards with actionable improvement recommendations." },
  { icon: <FileText className="w-5 h-5 text-orange-500" />, title: "Automated Documentation",         desc: "AI-generated architecture docs, UML/sequence diagrams, ER diagrams, dependency graphs and Confluence-ready professional reports." },
  { icon: <Database className="w-5 h-5 text-cyan-500" />,   title: "Data Flow & Impact Analysis",      desc: "Function call graphs, field-level data tracking, cross-module dependency visualisation and blast-radius assessment for code changes." },
  { icon: <Globe className="w-5 h-5 text-indigo-500" />,    title: "GitHub & Confluence Integration",  desc: "Clone and analyse public/private GitHub repos. Publish reports directly to Confluence spaces with structured hierarchy." },
  { icon: <Rocket className="w-5 h-5 text-pink-500" />,     title: "Migration Planning",               desc: "POD→POA migration analysis, modernisation roadmaps, COBOL-to-Java transformation, migration priority scoring and effort estimation." },
];

const TECH_STACK = [
  { cat: "Frontend",       items: ["React 18", "TypeScript", "Tailwind CSS", "shadcn/ui", "React Flow", "TanStack Query", "Wouter", "Vite"] },
  { cat: "Backend",        items: ["Express.js", "Node.js", "TypeScript", "Drizzle ORM", "PostgreSQL", "bcrypt", "express-session"] },
  { cat: "AI & ML",        items: ["OpenAI GPT-4o", "Ollama (local LLM)", "Code Llama", "Deepseek Coder", "NumPy Neural Net"] },
  { cat: "Analysis",       items: ["Custom AST Parsers", "Regex + Pattern Engine", "CWE Rule Engine", "ISO 5055 Scorer", "Mermaid.js"] },
  { cat: "Visualisation",  items: ["React Flow", "Cytoscape.js", "Graphviz", "Mermaid.js", "jsPDF"] },
  { cat: "Integrations",   items: ["GitHub REST API", "Confluence REST API", "Multer (ZIP upload)", "openpyxl", "ChromaDB (planned)"] },
];

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">

      {/* ── HERO ──────────────────────────────────────────────────────────────── */}
      <div className="text-center mb-14">
        <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 border border-blue-200 rounded-full px-4 py-1.5 text-sm font-semibold mb-4">
          <FlaskConical className="w-4 h-4" /> AMEX Diamond Project · Zensar Technologies
        </div>
        <h1 className="text-5xl font-extrabold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-3 leading-tight">
          Nucleus
        </h1>
        <h2 className="text-2xl font-bold text-gray-700 mb-4">
          Innersource Agentic SDLC Framework
        </h2>
        <p className="text-lg text-gray-500 max-w-3xl mx-auto mb-6">
          An enterprise AI platform combining multi-language code intelligence, ISO 5055 quality metrics, 
          security scanning and the Nucleus 2.0 Agent Factory — 15 specialist GPT-4o agents that automate 
          every phase of your software delivery lifecycle.
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          {["15 Nucleus 2.0 Agents","62 SDLC Activities","GPT-4o Powered","Multi-Language","ISO 5055 Quality","PCI-DSS Scanning","Confluence Sync","GitHub Integration"].map(b => (
            <span key={b} className="bg-white border border-gray-200 text-gray-600 rounded-full px-3 py-1 text-sm font-medium shadow-sm">{b}</span>
          ))}
        </div>
      </div>

      {/* ── KEY METRICS ─────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3 mb-14">
        {[
          { v:"15",   l:"Nucleus 2.0 Agents",  icon:<Bot className="w-4 h-4 text-blue-500" /> },
          { v:"62",   l:"SDLC Activities", icon:<Zap className="w-4 h-4 text-yellow-500" /> },
          { v:"7",    l:"SDLC Domains",    icon:<Layers className="w-4 h-4 text-green-500" /> },
          { v:"30+",  l:"CWE Rules",       icon:<Shield className="w-4 h-4 text-red-500" /> },
          { v:"39",   l:"PII Patterns",    icon:<Lock className="w-4 h-4 text-purple-500" /> },
          { v:"5",    l:"Languages",       icon:<Code className="w-4 h-4 text-orange-500" /> },
          { v:"GPT-4o",l:"AI Model",       icon:<BrainCircuit className="w-4 h-4 text-pink-500" /> },
          { v:"ISO",  l:"5055 Quality",    icon:<BarChart3 className="w-4 h-4 text-cyan-500" /> },
        ].map(m => (
          <div key={m.l} className="bg-white border border-gray-100 rounded-xl p-3 text-center shadow-sm">
            <div className="flex justify-center mb-1.5">{m.icon}</div>
            <div className="text-xl font-bold text-gray-900 leading-tight">{m.v}</div>
            <div className="text-xs text-gray-400 leading-tight">{m.l}</div>
          </div>
        ))}
      </div>

      {/* ── PLATFORM CAPABILITIES ───────────────────────────────────────────── */}
      <div className="mb-14">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Platform Capabilities</h2>
        <p className="text-gray-500 mb-6">Everything Nucleus delivers out of the box</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {NUCLEUS_CAPABILITIES.map(c => (
            <div key={c.title} className="bg-white border border-gray-200 rounded-xl p-5 hover:shadow-md transition-shadow">
              <div className="mb-3">{c.icon}</div>
              <h3 className="font-bold text-gray-900 text-sm mb-2">{c.title}</h3>
              <p className="text-xs text-gray-500 leading-relaxed">{c.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── ZENSEAI AGENT FACTORY ────────────────────────────────────────────── */}
      <div className="mb-14">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-1">Nucleus 2.0 Agent Factory — All 15 Agents</h2>
            <p className="text-gray-500 text-sm">Specialist AI agents covering every SDLC domain, powered by GPT-4o</p>
          </div>
          <Link href="/zenseai-platform">
            <button className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow hover:shadow-lg transition-all hover:scale-105">
              <Play className="w-4 h-4" /> Launch Platform
            </button>
          </Link>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
          {ZENSEAI_AGENTS.map(a => (
            <div key={a.id} className="bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{a.emoji}</span>
                  <div>
                    <div className="font-bold text-gray-900 text-sm leading-tight">{a.name}</div>
                    <div className="text-xs font-mono font-bold text-blue-500">{a.id}</div>
                  </div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full border font-medium flex-shrink-0 ${DOMAIN_COLOR[a.domain]}`}>{a.domain}</span>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed">{a.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── TECH STACK ──────────────────────────────────────────────────────── */}
      <div className="mb-14">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Technology Stack</h2>
        <p className="text-gray-500 mb-6 text-sm">The engineering foundations of the Nucleus platform</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {TECH_STACK.map(t => (
            <div key={t.cat} className="bg-white border border-gray-200 rounded-xl p-5">
              <h3 className="font-bold text-gray-900 mb-3 text-sm border-b pb-2">{t.cat}</h3>
              <div className="flex flex-wrap gap-1.5">
                {t.items.map(i => (
                  <span key={i} className="bg-gray-50 border border-gray-200 text-gray-600 text-xs rounded-full px-2.5 py-1">{i}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── TEAM ─────────────────────────────────────────────────────────────── */}
      <div className="bg-gradient-to-br from-blue-900 to-indigo-900 rounded-2xl p-8 text-white">
        <div className="flex items-center gap-3 mb-6">
          <Users className="w-6 h-6 text-blue-300" />
          <div>
            <h2 className="text-2xl font-bold">Team Diamond</h2>
            <p className="text-blue-300 text-sm">Zensar Technologies · AMEX Diamond Project</p>
          </div>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {TEAM.map(m => (
            <div key={m.name} className={`rounded-xl border p-4 ${m.highlight ? "bg-white/15 border-white/30" : "bg-white/8 border-white/15"}`}>
              <div className="font-bold text-white mb-0.5">{m.name}</div>
              <div className={`text-sm font-semibold mb-1 ${m.highlight ? "text-blue-200" : "text-blue-300"}`}>{m.role}</div>
              <div className="text-xs text-blue-400">{m.org}</div>
            </div>
          ))}
        </div>
        <div className="mt-6 pt-6 border-t border-white/20 text-center">
          <p className="text-blue-300 text-sm">
            <strong className="text-white">Nucleus</strong> is built and maintained by the Diamond team at Zensar Technologies as part of the AMEX engagement, 
            delivering AI-powered innersource intelligence and automated SDLC tooling.
          </p>
        </div>
      </div>
    </div>
  );
}
