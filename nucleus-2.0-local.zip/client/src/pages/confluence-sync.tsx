/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Layout from "@/components/layout";
import { 
  Cloud, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  FileText, 
  Settings, 
  Link2, 
  ArrowRight,
  BookOpen,
  Upload,
  AlertCircle,
  Info
} from "lucide-react";

interface ConnectionStatus {
  connected: boolean;
}

export default function ConfluenceSync() {
  const { toast } = useToast();
  const [baseUrl, setBaseUrl] = useState("");
  const [spaceKey, setSpaceKey] = useState("");
  const [parentPageId, setParentPageId] = useState("");

  const { data: connectionStatus, isLoading: isCheckingConnection } = useQuery<ConnectionStatus>({
    queryKey: ['/api/confluence/status'],
    retry: false,
    refetchOnWindowFocus: false
  });

  const testConnectionMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/confluence/test', { baseUrl, spaceKey });
    },
    onSuccess: () => {
      toast({
        title: "Connection Successful",
        description: "Successfully connected to Confluence",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/confluence/status'] });
    },
    onError: (error: any) => {
      toast({
        title: "Connection Failed",
        description: error.message || "Could not connect to Confluence",
        variant: "destructive",
      });
    }
  });

  const saveConfigMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/confluence/config', { baseUrl, spaceKey, parentPageId });
    },
    onSuccess: () => {
      toast({
        title: "Configuration Saved",
        description: "Confluence settings have been saved",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save configuration",
        variant: "destructive",
      });
    }
  });

  const syncReportMutation = useMutation({
    mutationFn: async (projectId: number) => {
      return await apiRequest('POST', `/api/confluence/sync/${projectId}`);
    },
    onSuccess: () => {
      toast({
        title: "Sync Complete",
        description: "Report has been published to Confluence",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Sync Failed",
        description: error.message || "Failed to sync report to Confluence",
        variant: "destructive",
      });
    }
  });

  const steps = [
    {
      number: 1,
      title: "Get Confluence API Token",
      description: "Generate an API token from your Atlassian account",
      details: [
        "Go to https://id.atlassian.com/manage-profile/security/api-tokens",
        "Click 'Create API token'",
        "Give it a label (e.g., 'Nucleus Integration')",
        "Copy the generated token"
      ]
    },
    {
      number: 2,
      title: "Configure Connection",
      description: "Enter your Confluence instance details",
      details: [
        "Enter your Confluence base URL (e.g., https://yourcompany.atlassian.net)",
        "Specify the Space Key where reports will be published",
        "Optionally set a parent page ID for organization"
      ]
    },
    {
      number: 3,
      title: "Store Credentials Securely",
      description: "Add your credentials to the Secrets tab",
      details: [
        "Open the Secrets tab in the left panel",
        "Add CONFLUENCE_EMAIL with your Atlassian email",
        "Add CONFLUENCE_API_TOKEN with your API token",
        "These will be securely stored and encrypted"
      ]
    },
    {
      number: 4,
      title: "Test & Sync",
      description: "Verify connection and sync your reports",
      details: [
        "Test the connection to ensure credentials are valid",
        "Select reports to sync from your analyzed projects",
        "Reports will be automatically formatted for Confluence"
      ]
    }
  ];

  return (
    <Layout>
      <div className="container mx-auto px-6 py-8 max-w-6xl">
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-2">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Cloud className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Confluence Sync</h1>
              <p className="text-gray-600">Publish and synchronize documentation to Confluence</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                  <span>Setup Guide</span>
                </CardTitle>
                <CardDescription>
                  Follow these steps to connect Nucleus with your Confluence workspace
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {steps.map((step, index) => (
                    <div key={step.number} className="flex space-x-4">
                      <div className="flex-shrink-0">
                        <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold text-sm">
                          {step.number}
                        </div>
                        {index < steps.length - 1 && (
                          <div className="w-0.5 h-full bg-blue-200 ml-4 mt-2" />
                        )}
                      </div>
                      <div className="flex-1 pb-6">
                        <h3 className="font-semibold text-gray-900 mb-1">{step.title}</h3>
                        <p className="text-sm text-gray-600 mb-3">{step.description}</p>
                        <ul className="space-y-2">
                          {step.details.map((detail, detailIndex) => (
                            <li key={detailIndex} className="flex items-start space-x-2 text-sm text-gray-700">
                              <ArrowRight className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                              <span>{detail}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="w-5 h-5 text-gray-600" />
                  <span>Configuration</span>
                </CardTitle>
                <CardDescription>
                  Configure your Confluence connection settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="baseUrl">Confluence Base URL</Label>
                  <Input
                    id="baseUrl"
                    placeholder="https://yourcompany.atlassian.net"
                    value={baseUrl}
                    onChange={(e) => setBaseUrl(e.target.value)}
                    data-testid="input-confluence-url"
                  />
                  <p className="text-xs text-gray-500">Your Atlassian Confluence instance URL</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="spaceKey">Space Key</Label>
                  <Input
                    id="spaceKey"
                    placeholder="DOCS"
                    value={spaceKey}
                    onChange={(e) => setSpaceKey(e.target.value)}
                    data-testid="input-space-key"
                  />
                  <p className="text-xs text-gray-500">The key of the Confluence space where reports will be published</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="parentPageId">Parent Page ID (Optional)</Label>
                  <Input
                    id="parentPageId"
                    placeholder="123456789"
                    value={parentPageId}
                    onChange={(e) => setParentPageId(e.target.value)}
                    data-testid="input-parent-page-id"
                  />
                  <p className="text-xs text-gray-500">Reports will be created as children of this page</p>
                </div>

                <div className="flex space-x-3 pt-4">
                  <Button
                    onClick={() => testConnectionMutation.mutate()}
                    disabled={!baseUrl || !spaceKey || testConnectionMutation.isPending}
                    variant="outline"
                    data-testid="button-test-connection"
                  >
                    {testConnectionMutation.isPending ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Link2 className="w-4 h-4 mr-2" />
                    )}
                    Test Connection
                  </Button>
                  <Button
                    onClick={() => saveConfigMutation.mutate()}
                    disabled={!baseUrl || !spaceKey || saveConfigMutation.isPending}
                    data-testid="button-save-config"
                  >
                    {saveConfigMutation.isPending ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 mr-2" />
                    )}
                    Save Configuration
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Info className="w-5 h-5 text-blue-600" />
                  <span>Connection Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-3">
                  {isCheckingConnection ? (
                    <>
                      <RefreshCw className="w-5 h-5 text-gray-400 animate-spin" />
                      <span className="text-gray-600">Checking connection...</span>
                    </>
                  ) : connectionStatus?.connected ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                      <div>
                        <span className="text-green-700 font-medium">Connected</span>
                        <p className="text-xs text-gray-500">Ready to sync reports</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-5 h-5 text-gray-400" />
                      <div>
                        <span className="text-gray-600">Not Connected</span>
                        <p className="text-xs text-gray-500">Configure credentials to connect</p>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertCircle className="w-5 h-5 text-amber-600" />
                  <span>Important Notes</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start space-x-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-2 flex-shrink-0" />
                  <p className="text-gray-700">Store credentials in the Secrets tab for security</p>
                </div>
                <div className="flex items-start space-x-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-2 flex-shrink-0" />
                  <p className="text-gray-700">API tokens are more secure than passwords</p>
                </div>
                <div className="flex items-start space-x-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-2 flex-shrink-0" />
                  <p className="text-gray-700">Ensure you have write access to the target space</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-purple-600" />
                  <span>What Gets Synced</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    "Project overview and metadata",
                    "Architecture analysis diagrams",
                    "Code structure documentation",
                    "AI-generated insights",
                    "Quality metrics and recommendations",
                    "API documentation (if available)"
                  ].map((item, index) => (
                    <div key={index} className="flex items-center space-x-2 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
