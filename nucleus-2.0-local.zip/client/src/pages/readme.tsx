/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { 
  Play, 
  Download, 
  Terminal, 
  Folder, 
  Code2, 
  Database, 
  Globe, 
  Shield,
  Zap,
  Book,
  ExternalLink,
  Copy,
  CheckCircle,
  Settings
} from "lucide-react";
import Layout from "@/components/layout";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function ReadmePage() {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const { toast } = useToast();

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedCode(label);
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard`,
      });
      setTimeout(() => setCopiedCode(null), 2000);
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const CodeBlock = ({ code, label }: { code: string; label: string }) => (
    <div className="relative">
      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
        {code}
      </pre>
      <Button
        size="sm"
        variant="outline"
        className="absolute top-2 right-2 h-8 w-8 p-0"
        onClick={() => copyToClipboard(code, label)}
      >
        {copiedCode === label ? (
          <CheckCircle className="h-4 w-4 text-green-600" />
        ) : (
          <Copy className="h-4 w-4" />
        )}
      </Button>
    </div>
  );

  const prerequisites = [
    "Node.js 18+",
    "PostgreSQL database", 
    "OpenAI API key (optional, for online AI analysis)",
    "Local LLM setup with Ollama (optional, for offline AI analysis)",
    "Choose between Online AI models (GPT-4o, Claude, Gemini) or Local LLM models"
  ];

  const coreFeatures = [
    {
      category: "Code Analysis & Intelligence",
      items: [
        "Multi-language support: Java, Python, PySpark, Mainframe (COBOL/JCL), C#, Kotlin",
        "Automated source code parsing and architectural pattern detection",
        "Dependency graph generation and relationship mapping",
        "Component-level impact analysis and change tracking",
        "ISO-5055 quality metrics and CWE vulnerability detection",
        "Interactive UML-style diagrams with React Flow visualization"
      ]
    },
    {
      category: "Demographic Data Intelligence",
      items: [
        "30+ built-in demographic pattern detection (SSN, Credit Cards, DOB, Email, Phone)",
        "Excel field mapping for demographic data discovery",
        "PII/PHI compliance scanning (GDPR, HIPAA, PCI-DSS)",
        "Demographic field location tracking across codebase",
        "Compliance risk assessment with severity levels",
        "Custom pattern support for industry-specific data"
      ]
    },
    {
      category: "Integration Pattern Detection",
      items: [
        "30+ integration pattern detection across 5 categories",
        "API patterns: REST, SOAP, RPC, Service Discovery, API Gateway",
        "Database patterns: Shared DB, Stored Procedures, Vendor Lock-in",
        "Messaging patterns: JMS, MQ, Event-Driven, Pub/Sub",
        "File/Batch patterns: SFTP, Quartz, CSV/Excel processing",
        "Cross-cutting patterns: Logging, Caching, Security, Monitoring"
      ]
    },
    {
      category: "POD→POA Migration Planning",
      items: [
        "AI-powered migration strategy recommendations",
        "Phased migration roadmap with timeline and effort estimation",
        "Technology stack modernization suggestions",
        "Demographic data migration with security-first approach",
        "Cost-benefit analysis with ROI projections",
        "Risk assessment and mitigation strategies"
      ]
    },
    {
      category: "Data Image and Quality Measures",
      items: [
        "ISO-5055 quality metrics: Reliability, Security, Maintainability, Performance, Testability",
        "Data lineage and impact analysis with field-to-function mapping",
        "CWE vulnerability detection and compliance impact assessment",
        "Quality visualization with heat maps and dependency graphs",
        "Technical debt dashboard with risk-based prioritization",
        "Automated quality gate recommendations and cost estimation"
      ]
    },
    {
      category: "AI & Machine Learning",
      items: [
        "Multi-LLM support: OpenAI GPT-4o, Claude 3.5, Google Gemini",
        "Local LLM integration via Ollama (Code Llama, Deepseek Coder, Mistral)",
        "HuggingFace CodeBERT for code quality analysis",
        "ChromaDB vector database for semantic code search",
        "Langfuse for LLM observability and monitoring",
        "Privacy-first offline analysis capabilities"
      ]
    },
    {
      category: "Advanced Intelligence Features (Enterprise Add-on - Planned)",
      items: [
        "Real-time collaboration: Multi-analyst workspace, live code annotations, shared sessions",
        "Predictive analytics: Technical debt forecasting, defect probability scoring, maintenance cost prediction",
        "Automated code transformation: One-click refactoring, design pattern application, batch modernization",
        "CI/CD integration: Pipeline automation, quality gates, regression detection, live monitoring",
        "Multi-repository portfolio analysis: Cross-project insights, duplicate detection, enterprise compliance",
        "Advanced security: SAST/DAST integration, automated remediation, zero-day tracking, compliance reports",
        "Smart dependency management: Vulnerability scanning, upgrade planning, license compliance",
        "Custom pattern builder: Visual designer, pattern library, industry templates (finance, healthcare, retail)",
        "Executive dashboard: KPI tracking, ROI metrics, team productivity, risk heat maps, strategic insights",
        "AI code generation: Boilerplate generation, test creation, API documentation synthesis",
        "Vector database intelligence: ChromaDB/Pinecone/Weaviate, semantic code search, clone detection, architectural pattern discovery",
        "Generative AI functions: Multi-model orchestration (GPT-4o/Claude/Gemini), code explanation, migration code generation, security patch generation",
        "Agentic orchestrator with MCP: Multi-agent coordination, context sharing protocol, workflow automation, smart task routing, tool chaining",
        "Enterprise integrations: Jira, Slack, GitHub, Confluence, DataDog for seamless workflow"
      ]
    },
    {
      category: "Enterprise Features",
      items: [
        "Professional PDF report generation with corporate branding",
        "Swagger/OpenAPI documentation auto-generation",
        "RESTful API endpoints with comprehensive documentation",
        "User authentication and role-based access control",
        "PostgreSQL database with in-memory fallback option",
        "Cross-platform support (Windows, Mac, Linux)"
      ]
    }
  ];

  const qualitativeBenefits = [
    {
      category: "Strategic Decision Making",
      benefits: [
        "Data-driven modernization planning with AI-powered insights",
        "Clear visibility into technical debt and architectural risks",
        "Informed technology stack selection based on actual codebase analysis",
        "Compliance confidence with automated PII/PHI detection"
      ]
    },
    {
      category: "Risk Reduction",
      benefits: [
        "Early identification of security vulnerabilities (CWE patterns)",
        "Compliance violation detection before production deployment",
        "Dependency risk assessment and cyclic dependency breaking",
        "Migration risk mitigation with phased roadmap planning"
      ]
    },
    {
      category: "Team Collaboration",
      benefits: [
        "Shared understanding of complex legacy systems",
        "Visual architecture diagrams for stakeholder communication",
        "Comprehensive documentation reducing knowledge silos",
        "Onboarding acceleration for new team members"
      ]
    },
    {
      category: "Innovation Enablement",
      benefits: [
        "Modern architecture recommendations (microservices, cloud-native)",
        "Technology upgrade paths with clear migration strategies",
        "Best practice identification and anti-pattern detection",
        "AI-driven code quality improvements"
      ]
    }
  ];

  const quantitativeBenefits = [
    {
      metric: "Time Savings",
      value: "70-80%",
      description: "Reduction in manual code analysis time through automated parsing and AI insights",
      impact: "Manual review of 10,000+ line codebase: 40 hours → 8 hours with Code Lens"
    },
    {
      metric: "Cost Reduction",
      value: "40-60%",
      description: "Lower migration costs through phased planning and risk identification",
      impact: "Typical $500K migration project reduced to $200-300K with optimized strategy"
    },
    {
      metric: "Compliance Detection",
      value: "95%+ accuracy",
      description: "Demographic field detection across codebase with pattern matching",
      impact: "Identifies 95%+ of PII/PHI fields vs 60-70% manual review"
    },
    {
      metric: "Documentation Speed",
      value: "90% faster",
      description: "Automated architecture diagram and report generation",
      impact: "Architecture documentation: 20 hours → 2 hours with automated PDF generation"
    },
    {
      metric: "Code Quality Improvement",
      value: "30-50%",
      description: "Measurable quality increase through ISO-5055 metrics and AI recommendations",
      impact: "Technical debt reduction of 30-50% when following AI-generated recommendations"
    },
    {
      metric: "Migration ROI",
      value: "6-12 months",
      description: "Break-even timeline for cloud migration investments",
      impact: "Annual savings of $200K-500K after migration (infrastructure + license costs)"
    },
    {
      metric: "Risk Mitigation",
      value: "80%+",
      description: "Reduction in post-migration issues through comprehensive analysis",
      impact: "Prevents 80%+ of data loss/security incidents through pre-migration scanning"
    },
    {
      metric: "Developer Productivity",
      value: "2-3x increase",
      description: "Faster understanding of legacy systems and architecture",
      impact: "New developer ramp-up time: 2-3 weeks → 3-5 days with visual documentation"
    }
  ];

  const scripts = [
    { command: "npm run dev", description: "Start development server" },
    { command: "npm run build", description: "Build for production" },
    { command: "npm run db:push", description: "Push schema changes to database" },
    { command: "npm run db:studio", description: "Open Drizzle Studio (GUI)" },
    { command: "npm run lint", description: "Run ESLint" },
    { command: "npm run type-check", description: "Run TypeScript checks" }
  ];

  const apiEndpoints = [
    { method: "POST", path: "/api/auth/login", description: "User authentication" },
    { method: "GET", path: "/api/auth/user", description: "Get current user" },
    { method: "PATCH", path: "/api/auth/user", description: "Update user profile" },
    { method: "POST", path: "/api/auth/upload-avatar", description: "Upload profile image" },
    { method: "GET", path: "/api/projects", description: "List all projects" },
    { method: "POST", path: "/api/projects/upload", description: "Upload ZIP for analysis" },
    { method: "GET", path: "/api/projects/:id", description: "Get project details" },
    { method: "GET", path: "/api/admin/statistics", description: "Admin dashboard data" }
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
            Developer Documentation
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Complete setup and development guide for Zengent AI Enterprise Application Intelligence Platform
          </p>
        </div>

        {/* Quick Start */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Play className="h-6 w-6 text-green-600 mr-2" />
              Quick Start
            </CardTitle>
            <CardDescription>
              Get up and running in minutes
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Prerequisites */}
            <div>
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                <CheckCircle className="h-5 w-5 text-blue-500 mr-2" />
                Prerequisites
              </h3>
              <div className="grid md:grid-cols-3 gap-3">
                {prerequisites.map((item, index) => (
                  <div key={index} className="flex items-center space-x-2 p-3 bg-blue-50 rounded-lg">
                    <CheckCircle className="h-4 w-4 text-blue-600" />
                    <span className="text-sm font-medium">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Installation Steps */}
            <div>
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                <Download className="h-5 w-5 text-purple-500 mr-2" />
                Installation Steps
              </h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">1. Clone the repository</h4>
                  <CodeBlock 
                    code="git clone <repository-url>\ncd zengent-ai" 
                    label="Clone command"
                  />
                </div>

                <div>
                  <h4 className="font-medium mb-2">2. Install dependencies</h4>
                  <CodeBlock 
                    code="npm install" 
                    label="Install command"
                  />
                </div>

                <div>
                  <h4 className="font-medium mb-2">3. Set up environment variables</h4>
                  <CodeBlock 
                    code={`# Required
DATABASE_URL=postgresql://username:password@localhost:5432/zengent
SESSION_SECRET=your-secret-key

# Optional - Online AI Models (choose one or more)
OPENAI_API_KEY=your-openai-api-key
ANTHROPIC_API_KEY=your-claude-api-key
GOOGLE_API_KEY=your-gemini-api-key

# Optional - Local LLM (for privacy-first offline analysis)
# Install Ollama and download models like:
# ollama pull codellama
# ollama pull deepseek-coder
# ollama pull starcoder`}
                    label="Environment variables"
                  />
                </div>

                <div>
                  <h4 className="font-medium mb-2">4. Initialize the database</h4>
                  <CodeBlock 
                    code="npm run db:push" 
                    label="Database init"
                  />
                </div>

                <div>
                  <h4 className="font-medium mb-2">5. Start the development server</h4>
                  <CodeBlock 
                    code="npm run dev" 
                    label="Start server"
                  />
                </div>
              </div>

              <div className="mt-4 space-y-3">
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-green-800 font-medium flex items-center">
                    <Zap className="h-4 w-4 mr-2" />
                    Application will be available at http://localhost:5000
                  </p>
                </div>
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-blue-800 font-medium mb-2 flex items-center">
                    <Settings className="h-4 w-4 mr-2" />
                    AI Model Configuration
                  </p>
                  <p className="text-blue-700 text-sm">
                    <strong>Online Models:</strong> Provide API keys for GPT-4o, Claude 3.5, or Gemini Pro<br/>
                    <strong>Local Models:</strong> Install Ollama and download models for complete offline analysis
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Architecture */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Folder className="h-6 w-6 text-blue-600 mr-2" />
              Project Architecture
            </CardTitle>
            <CardDescription>
              Understanding the codebase structure
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <Code2 className="h-5 w-5 text-blue-500 mr-2" />
                  Frontend (client/)
                </h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• <strong>React + TypeScript</strong> for type-safe development</li>
                  <li>• <strong>Tailwind CSS + shadcn/ui</strong> for modern UI</li>
                  <li>• <strong>React Flow</strong> for interactive diagrams</li>
                  <li>• <strong>TanStack Query</strong> for state management</li>
                  <li>• <strong>Wouter</strong> for lightweight routing</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <Database className="h-5 w-5 text-green-500 mr-2" />
                  Backend (server/)
                </h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• <strong>Express.js + TypeScript</strong> for robust API</li>
                  <li>• <strong>Drizzle ORM</strong> for type-safe database ops</li>
                  <li>• <strong>Multer</strong> for secure file uploads</li>
                  <li>• <strong>bcrypt</strong> for password security</li>
                  <li>• <strong>Session-based auth</strong> with PostgreSQL</li>
                </ul>
              </div>
            </div>

            <div className="mt-6">
              <h3 className="font-semibold text-gray-900 mb-3">Project Structure</h3>
              <CodeBlock 
                code={`├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Page components
│   │   ├── hooks/          # Custom React hooks
│   │   └── lib/            # Utility functions
├── server/                 # Express.js backend
│   ├── services/           # Business logic services
│   ├── routes.ts           # API route definitions
│   ├── storage.ts          # Database operations
│   └── auth.ts             # Authentication logic
├── shared/                 # Shared types and schemas
│   └── schema.ts           # Database schema definitions
└── docs/                   # Documentation`}
                label="Project structure"
              />
            </div>
          </CardContent>
        </Card>

        {/* Available Scripts */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Terminal className="h-6 w-6 text-purple-600 mr-2" />
              Available Scripts
            </CardTitle>
            <CardDescription>
              Common development commands
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              {scripts.map((script, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <code className="text-sm font-mono bg-gray-100 px-2 py-1 rounded">
                      {script.command}
                    </code>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 w-6 p-0"
                      onClick={() => copyToClipboard(script.command, script.command)}
                    >
                      {copiedCode === script.command ? (
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      ) : (
                        <Copy className="h-3 w-3" />
                      )}
                    </Button>
                  </div>
                  <p className="text-sm text-gray-600">{script.description}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* API Documentation */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Globe className="h-6 w-6 text-orange-600 mr-2" />
              API Documentation
            </CardTitle>
            <CardDescription>
              Key API endpoints for development
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {apiEndpoints.map((endpoint, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center space-x-3">
                    <Badge 
                      variant={endpoint.method === 'GET' ? 'default' : endpoint.method === 'POST' ? 'destructive' : 'secondary'}
                      className="w-16 justify-center"
                    >
                      {endpoint.method}
                    </Badge>
                    <code className="text-sm font-mono">{endpoint.path}</code>
                  </div>
                  <span className="text-sm text-gray-600">{endpoint.description}</span>
                </div>
              ))}
            </div>
            
            <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-blue-800 text-sm flex items-center">
                <Book className="h-4 w-4 mr-2" />
                Full Swagger documentation available at <code className="mx-1">/api-docs</code> when server is running
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Complete Features */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Settings className="h-6 w-6 text-indigo-600 mr-2" />
              Complete Platform Features
            </CardTitle>
            <CardDescription>
              Comprehensive enterprise application intelligence capabilities
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {coreFeatures.map((featureGroup, idx) => (
                <div key={idx} className="border-l-4 border-blue-500 pl-4">
                  <h3 className="font-semibold text-gray-900 mb-3 text-lg">{featureGroup.category}</h3>
                  <div className="grid md:grid-cols-2 gap-2">
                    {featureGroup.items.map((item, index) => (
                      <div key={index} className="flex items-start space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-gray-700">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Qualitative Benefits */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Zap className="h-6 w-6 text-purple-600 mr-2" />
              Qualitative Benefits
            </CardTitle>
            <CardDescription>
              Strategic value and business impact
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              {qualitativeBenefits.map((benefit, idx) => (
                <div key={idx} className="bg-gradient-to-br from-purple-50 to-blue-50 p-4 rounded-lg border border-purple-200">
                  <h3 className="font-semibold text-purple-900 mb-3 flex items-center">
                    <div className="w-2 h-2 bg-purple-600 rounded-full mr-2"></div>
                    {benefit.category}
                  </h3>
                  <ul className="space-y-2">
                    {benefit.benefits.map((item, index) => (
                      <li key={index} className="text-sm text-gray-700 flex items-start">
                        <span className="text-purple-600 mr-2">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quantitative Benefits */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Database className="h-6 w-6 text-green-600 mr-2" />
              Quantitative Benefits & ROI Metrics
            </CardTitle>
            <CardDescription>
              Measurable impact and business outcomes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              {quantitativeBenefits.map((metric, idx) => (
                <div key={idx} className="bg-gradient-to-br from-green-50 to-emerald-50 p-5 rounded-lg border border-green-200">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-gray-900">{metric.metric}</h3>
                    <Badge className="bg-green-600 text-white text-lg px-3 py-1">
                      {metric.value}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-700 mb-2">{metric.description}</p>
                  <div className="bg-white/70 p-3 rounded border border-green-300 mt-3">
                    <p className="text-xs text-gray-600 font-medium">Real Impact:</p>
                    <p className="text-xs text-gray-800">{metric.impact}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-5 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg text-white">
              <h3 className="font-bold text-lg mb-2">💡 Total Value Proposition</h3>
              <div className="grid md:grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="font-semibold mb-1">Time Saved</p>
                  <p className="text-blue-100">70-80% reduction in manual analysis effort</p>
                </div>
                <div>
                  <p className="font-semibold mb-1">Cost Savings</p>
                  <p className="text-blue-100">$200K-500K annual savings post-migration</p>
                </div>
                <div>
                  <p className="font-semibold mb-1">ROI Timeline</p>
                  <p className="text-blue-100">6-12 month break-even on investment</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="h-6 w-6 text-red-600 mr-2" />
              Security Features
            </CardTitle>
            <CardDescription>
              Enterprise-grade security implementation
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Authentication</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• bcrypt password hashing</li>
                  <li>• PostgreSQL-backed sessions</li>
                  <li>• Session timeout handling</li>
                  <li>• Secure cookie configuration</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Data Protection</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Local processing options</li>
                  <li>• File upload validation</li>
                  <li>• SQL injection protection</li>
                  <li>• Privacy-first AI analysis</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Deployment */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Zap className="h-6 w-6 text-yellow-600 mr-2" />
              Deployment
            </CardTitle>
            <CardDescription>
              Production deployment guidelines
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Production Build</h3>
                <CodeBlock 
                  code="npm run build\nnpm start" 
                  label="Production build"
                />
              </div>

              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Environment Variables</h3>
                <CodeBlock 
                  code={`NODE_ENV=production
DATABASE_URL=your-production-db-url
SESSION_SECRET=your-production-secret
OPENAI_API_KEY=your-api-key`}
                  label="Production env"
                />
              </div>

              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Docker Support</h3>
                <CodeBlock 
                  code={`FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 5000
CMD ["npm", "start"]`}
                  label="Dockerfile"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center py-8 border-t">
          <p className="text-gray-600 mb-2">
            <strong>Built by the Amex Diamond Zensar Team</strong>
          </p>
          <p className="text-sm text-gray-500">
            For support, feature requests, or enterprise inquiries, please contact our team
          </p>
        </div>
      </div>
    </Layout>
  );
}