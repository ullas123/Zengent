/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type Project } from "@shared/schema";
import UploadSection from "@/components/upload-section";
import ProcessingSection from "@/components/processing-section";
import AnalysisResults from "@/components/analysis-results";
import Dashboard from "@/components/dashboard";
import JavaDashboard from "@/components/java-dashboard";
import AIModelSelector, { type AIModelConfig } from "@/components/ai-model-selector";
import { Button } from "@/components/ui/button";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { AIAnalysisResult } from "@shared/schema";
import { GitBranch, HelpCircle, Settings, Upload, Github, Code2, Database, Cpu, FileCode, Eye, GitMerge, Shield, Bot, Brain, Zap, Info, Search, BarChart4, ArrowRightLeft } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import Layout from "@/components/layout";
import { SiPython, SiApachespark } from "react-icons/si";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";
import zensarLogo from "@assets/Zensar_composite_logo_whit_ai_1754732936523.png";
import zenagentBanner from "@assets/zenagent_1754759778955.png";
import agentLogo from "@assets/agent_1754854183020.png";
import pythonLogo from "@assets/pyth_1754703124415.png";
import pysparkLogo from "@assets/pyspark-lang_1754703714412.png";
import ibmLogo from "@assets/ibm_1754703124415.png";
import javaLogo from "@assets/image_1760901920604.png";
import csharpLogo from "@assets/image_1760901951527.png";
import kotlinLogo from "@assets/image_1760902052334.png";
import codeLensIcon from "@assets/image_1760903680870.png";

type AppState = 'upload' | 'processing' | 'results';
type ProjectType = 'java' | 'pyspark' | 'mainframe' | 'python' | 'csharp' | 'kotlin' | 'code-lens' | 'match-lens' | 'validator' | 'zenvector' | 'knowledge' | 'datalens' | 'codeshift';

export default function Home() {
  const [appState, setAppState] = useState<AppState>('upload');
  const [currentProjectId, setCurrentProjectId] = useState<string | null>(null);
  const [selectedProjectType, setSelectedProjectType] = useState<ProjectType | null>(null);
  const [showAIConfig, setShowAIConfig] = useState(false);
  const [aiConfig, setAiConfig] = useState<AIModelConfig>({ type: 'openai' });
  const [showDevelopmentModal, setShowDevelopmentModal] = useState(false);
  const [selectedAgentName, setSelectedAgentName] = useState<string>('');
  const { toast } = useToast();

  const { data: currentProject, refetch: refetchProject } = useQuery<Project>({
    queryKey: ['/api/projects', currentProjectId],
    enabled: !!currentProjectId,
  });

  const handleFileUploaded = (project: Project) => {
    setCurrentProjectId(project.id);
    setAppState('processing');
    
    // Poll for completion
    const pollInterval = setInterval(async () => {
      const { data: updatedProject } = await refetchProject();
      if (updatedProject && updatedProject.status !== 'processing') {
        clearInterval(pollInterval);
        if (updatedProject.status === 'completed') {
          setAppState('results');
        } else {
          setAppState('upload');
          setCurrentProjectId(null);
        }
      }
    }, 2000);
  };

  const handleGitHubAnalyzed = (project: Project) => {
    setCurrentProjectId(project.id);
    setAppState('processing');
    
    // Poll for completion with longer interval for GitHub repos
    const pollInterval = setInterval(async () => {
      const { data: updatedProject } = await refetchProject();
      if (updatedProject && updatedProject.status !== 'processing') {
        clearInterval(pollInterval);
        if (updatedProject.status === 'completed') {
          setAppState('results');
        } else if (updatedProject.status === 'failed') {
          toast({
            title: "Analysis Failed",
            description: "GitHub repository analysis failed. Please try again.",
            variant: "destructive",
          });
          setAppState('upload');
          setCurrentProjectId(null);
        }
      }
    }, 3000); // Longer interval for GitHub repos
  };

  const handleNewAnalysis = () => {
    setAppState('upload');
    setCurrentProjectId(null);
  };

  const handleAIModelConfig = async (config: AIModelConfig) => {
    try {
      await apiRequest('/api/ai-config', 'POST', config);
      setAiConfig(config);
      setShowAIConfig(false);
    } catch (error) {
      console.error('Failed to configure AI model:', error);
    }
  };

  const handleAIAnalysisComplete = (analysis: AIAnalysisResult) => {
    if (currentProject && currentProject.analysisData) {
      // Update the project's analysisData with AI analysis
      const updatedAnalysisData = {
        ...currentProject.analysisData,
        aiAnalysis: analysis
      };
      
      // Update the query cache
      queryClient.setQueryData(
        ['/api/projects', currentProjectId],
        {
          ...currentProject,
          analysisData: updatedAnalysisData
        }
      );
    }
  };

  const handleAgentClick = (agentId: ProjectType) => {
    if (agentId === 'code-lens' || agentId === 'java' || agentId === 'mainframe') {
      // Java Agent, Mainframe Agent and Nucleus Agent navigate to analysis pages
      setSelectedProjectType(agentId);
    } else {
      // All other agents show development mode modal
      const agentNames: Record<ProjectType, string> = {
        'java': 'Java Agent',
        'pyspark': 'PySpark Agent',
        'mainframe': 'Mainframe Agent', 
        'python': 'Python Agent',
        'csharp': 'C# Agent',
        'kotlin': 'Kotlin Agent',
        'code-lens': 'Nucleus Agent',
        'match-lens': 'Match Lens Agent',
        'validator': 'Validator & Responsible AI Agent',
        'zenvector': 'Nucleus Vector Agent',
        'knowledge': 'Knowledge Agent',
        'datalens': 'Data Lens Agent',
        'codeshift': 'Code Conversion Agent'
      };
      
      setSelectedAgentName(agentNames[agentId]);
      setShowDevelopmentModal(true);
    }
  };

  // Original language project types with Validator Agent moved here
  const languageProjects = [
    {
      id: 'java' as ProjectType,
      name: 'Java',
      description: 'Comprehensive analysis of Java applications including Spring Boot frameworks, Maven/Gradle builds, and enterprise patterns',
      logoSrc: javaLogo,
      borderColor: 'border-primary',
      bgColor: 'bg-primary/5',
      hoverBgColor: 'hover:bg-primary/10',
      features: [
        'Spring Boot & Spring Framework analysis',
        'JPA/Hibernate entity relationship mapping', 
        'MVC architecture pattern detection',
        'Maven/Gradle dependency analysis',
        'RESTful API endpoint documentation',
        'Database connection and configuration review'
      ]
    },
    {
      id: 'pyspark' as ProjectType,
      name: 'PySpark',
      description: 'Advanced big data processing pipeline analysis with Apache Spark ecosystem integration and performance optimization insights',
      logoSrc: pysparkLogo,
      borderColor: 'border-warning',
      bgColor: 'bg-warning/10',
      hoverBgColor: 'hover:bg-warning/20',
      features: [
        'DataFrame operations and transformations',
        'Spark job execution flow visualization',
        'Performance bottleneck identification',
        'Data pipeline architecture mapping',
        'Cluster resource utilization analysis',
        'SQL query optimization recommendations'
      ]
    },
    {
      id: 'mainframe' as ProjectType,
      name: 'Mainframe & COBOL',
      description: 'Comprehensive mainframe analysis with master source library management (JCL, COPYBOOK, SOURCE, PROCLIB, DATALIB), COBOL code logic understanding, IMS/assembler routines, data flow charting, and ER relationship mapping',
      logoSrc: ibmLogo,
      borderColor: 'border-purple-600',
      bgColor: 'bg-purple-50',
      hoverBgColor: 'hover:bg-purple-100',
      features: [
        'Master Library Management - JCL, COPYBOOK, SOURCE, PROCLIB, DATALIB',
        'Component Search Across All Libraries with Version Tracking',
        'COBOL Code Logic and Flow Understanding',
        'IMS and Assembler Routine Analysis',
        'Files and Copybook Relationship Mapping',
        'SORT Card Creation for Data Extraction',
        'Data/Logic Flow Chart Generation',
        'ER Relationships and SQL Query Generation',
        'Data Field Details, Columns, and Delta Analysis',
        'DB2/CICS Transaction Processing Review'
      ]
    },
    {
      id: 'python' as ProjectType,
      name: 'Python',
      description: 'Deep analysis of Python applications with Django/Flask framework detection, package dependencies, and API architecture insights',
      logoSrc: pythonLogo,
      borderColor: 'border-blue-400',
      bgColor: 'bg-blue-50',
      hoverBgColor: 'hover:bg-blue-100',
      features: [
        'Django/Flask framework pattern analysis',
        'Package dependency mapping (pip, conda)',
        'API endpoint documentation and routing',
        'Database ORM relationship analysis',
        'Virtual environment configuration review',
        'Code quality and PEP compliance checking'
      ]
    },
    {
      id: 'csharp' as ProjectType,
      name: 'C#',
      description: 'Comprehensive analysis of C# applications including .NET Core, ASP.NET, Entity Framework, and enterprise patterns',
      logoSrc: csharpLogo,
      borderColor: 'border-purple-600',
      bgColor: 'bg-purple-50',
      hoverBgColor: 'hover:bg-purple-100',
      features: [
        '.NET Core & ASP.NET framework analysis',
        'Entity Framework ORM mapping',
        'MVC/MVVM architecture detection',
        'NuGet dependency analysis',
        'Web API and REST endpoint documentation',
        'LINQ query optimization'
      ]
    },
    {
      id: 'kotlin' as ProjectType,
      name: 'Kotlin',
      description: 'Advanced analysis of Kotlin applications with Android frameworks, coroutines, and JVM ecosystem integration',
      logoSrc: kotlinLogo,
      borderColor: 'border-orange-600',
      bgColor: 'bg-orange-50',
      hoverBgColor: 'hover:bg-orange-100',
      features: [
        'Kotlin coroutines and flow analysis',
        'Android framework pattern detection',
        'Gradle dependency mapping',
        'Spring Boot Kotlin integration',
        'Jetpack Compose UI analysis',
        'Multiplatform project support'
      ]
    }
  ];

  // AI Agent types for Diamond Project
  const aiAgents = [
    {
      id: 'knowledge' as ProjectType,
      name: 'Knowledge Agent',
      description: 'Document intelligence and Q&A system with Confluence integration, PDF processing, and intelligent knowledge extraction',
      logoSrc: agentLogo,
      borderColor: 'border-teal-500',
      bgColor: 'bg-teal-50',
      hoverBgColor: 'hover:bg-teal-100',
      features: [
        'Confluence web scraping integration',
        'IBM Doclinq PDF processing',
        'LangChain document processing',
        'Redis caching for performance',
        'Intelligent Q&A chat interface',
        'Multi-source knowledge aggregation'
      ]
    },
    {
      id: 'codeshift' as ProjectType,
      name: 'Code Conversion Agent',
      description: 'Multi-language code conversion agent for transforming source code between programming languages while preserving logic',
      logoSrc: agentLogo,
      borderColor: 'border-indigo-500',
      bgColor: 'bg-indigo-50',
      hoverBgColor: 'hover:bg-indigo-100',
      features: [
        'Multi-language code translation',
        'Framework migration support',
        'AST-based syntax conversion',
        'Code quality preservation',
        'Bulk project processing',
        'Language ecosystem mapping'
      ]
    },
    {
      id: 'validator' as ProjectType,
      name: 'Validator & Responsible AI Agent',
      description: 'Comprehensive validation covering security vulnerabilities, privacy compliance, ethics, bias detection, and AI governance',
      logoSrc: agentLogo,
      borderColor: 'border-purple-500',
      bgColor: 'bg-purple-50',
      hoverBgColor: 'hover:bg-purple-100',
      features: [
        'Security vulnerability detection and assessment',
        'Privacy compliance and data protection validation (GDPR, CCPA)',
        'AI ethics and bias detection in algorithms',
        'Fairness assessment across demographic groups',
        'Code quality metrics and best practices review',
        'Algorithmic transparency and explainability',
        'Responsible AI deployment and governance validation',
        'Performance bottleneck identification',
        'Security risk scoring and remediation guidance'
      ]
    }
  ];

  const projectTypes = [...languageProjects, ...aiAgents];

  const aiConfigButton = (
    <Button
      variant="outline"
      size="sm"
      onClick={() => setShowAIConfig(true)}
      className="text-primary bg-white border-primary hover:bg-primary hover:text-white font-medium transition-colors"
    >
      <Settings className="w-4 h-4 mr-2" />
      AI Settings
    </Button>
  );

  return (
    <TooltipProvider>
      <Layout aiConfigButton={aiConfigButton}>
        <div className="bg-white font-sans text-foreground min-h-screen">

      <div className="container mx-auto px-6 py-8">
        {appState === 'upload' && !selectedProjectType && (
          <div className="max-w-6xl mx-auto">

            {/* Language Project Types */}
            <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center p-1.5">
                  <img src={codeLensIcon} alt="Nucleus" className="w-full h-full object-contain" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Nucleus - AI Accelerator</h3>
                  <p className="text-sm text-gray-600">Multi-language codebase analysis supporting enterprise frameworks</p>
                </div>
              </div>
              
              {/* Enterprise AI Platform Summary */}
              <div className="bg-gradient-to-r from-blue-900 to-blue-800 rounded-xl p-6 mb-8 border border-blue-600">
                <div>
                  <h2 className="text-xl font-bold text-white mb-2">
                    Innersource Agentic SDLC Framework
                  </h2>
                  <p className="text-blue-100 text-sm mb-3">
                    Automated Technical Documentation, Using AI-Enhanced Documentation output, the generator delivers professional, branded documentation with AI-powered summaries, diagrams, and recommendations. It offers semantic search, natural-language explanations, and continuous synchronization with Confluence for living documentation. As code evolves, the system updates reports automatically, ensuring teams always have accurate, searchable, and up-to-date project documentation.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="text-xs text-emerald-300 border-emerald-300 bg-emerald-900/20">Java & Spring Boot</Badge>
                    <Badge variant="outline" className="text-xs text-blue-300 border-blue-300 bg-blue-800/30">Python & Django</Badge>
                    <Badge variant="outline" className="text-xs text-orange-300 border-orange-300 bg-orange-900/20">PySpark & Big Data</Badge>
                    <Badge variant="outline" className="text-xs text-purple-300 border-purple-300 bg-purple-900/20">Mainframe & COBOL</Badge>
                    <Badge variant="outline" className="text-xs text-indigo-300 border-indigo-300 bg-indigo-900/20">C# & .NET</Badge>
                    <Badge variant="outline" className="text-xs text-violet-300 border-violet-300 bg-violet-900/20">Kotlin & Android</Badge>
                    <Badge variant="outline" className="text-xs text-cyan-300 border-cyan-300 bg-cyan-900/20">AI/ML Analysis</Badge>
                  </div>
                </div>
              </div>
              {/* Modern Card Layout - Featured + Grid Style */}
              <div className="space-y-6 mb-8">
                {/* Featured Agents - Java and Mainframe Hero Cards */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Java Agent Hero Card */}
                  {languageProjects.filter(t => t.id === 'java').map((type) => (
                    <div
                      key={type.id}
                      onClick={() => handleAgentClick(type.id)}
                      className="relative group cursor-pointer bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 p-5 text-white overflow-hidden"
                    >
                      <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
                      <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2"></div>
                      
                      <div className="relative">
                        <div className="flex items-start gap-4 mb-4">
                          <div className="flex-shrink-0 bg-white rounded-xl p-3 shadow-lg">
                            <img 
                              src={type.logoSrc} 
                              alt={`${type.name} logo`}
                              className="w-12 h-12 object-contain"
                            />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="text-xl font-bold">{type.name} Agent</h3>
                              <span className="px-2 py-0.5 bg-white/20 rounded-full text-xs font-medium">Active</span>
                            </div>
                            <p className="text-blue-100 text-xs line-clamp-2">
                              {type.description}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-1.5 mb-3">
                          {type.features.slice(0, 4).map((feature, index) => (
                            <span key={index} className="px-2 py-1 bg-white/10 rounded-full text-xs">
                              {feature}
                            </span>
                          ))}
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-blue-200">Click to analyze Java projects</span>
                          <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center group-hover:bg-white/30 transition-colors">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {/* Mainframe & COBOL Agent Hero Card */}
                  {languageProjects.filter(t => t.id === 'mainframe').map((type) => (
                    <div
                      key={type.id}
                      onClick={() => handleAgentClick(type.id)}
                      className="relative group cursor-pointer bg-gradient-to-br from-violet-600 via-purple-700 to-purple-900 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 p-5 text-white overflow-hidden"
                    >
                      <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
                      <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2"></div>
                      
                      <div className="relative">
                        <div className="flex items-start gap-4 mb-4">
                          <div className="flex-shrink-0 bg-white rounded-xl p-3 shadow-lg">
                            <img 
                              src={type.logoSrc} 
                              alt={`${type.name} logo`}
                              className="w-12 h-12 object-contain"
                            />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="text-xl font-bold">{type.name} Agent</h3>
                              <span className="px-2 py-0.5 bg-white/20 rounded-full text-xs font-medium">Active</span>
                            </div>
                            <p className="text-purple-100 text-xs line-clamp-2">
                              {type.description}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-1.5 mb-3">
                          {type.features.slice(0, 4).map((feature, index) => (
                            <span key={index} className="px-2 py-1 bg-white/10 rounded-full text-xs">
                              {feature}
                            </span>
                          ))}
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-purple-200">Click to analyze Mainframe/COBOL projects</span>
                          <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center group-hover:bg-white/30 transition-colors">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Other Language Agents - Horizontal Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {languageProjects.filter(t => t.id !== 'java' && t.id !== 'mainframe').map((type) => (
                    <div
                      key={type.id}
                      onClick={() => handleAgentClick(type.id)}
                      className={`relative group cursor-pointer bg-white rounded-xl border-2 ${type.borderColor} hover:shadow-xl transition-all duration-300 overflow-hidden`}
                    >
                      {/* Color accent bar */}
                      <div className={`h-1 ${type.bgColor.replace('bg-', 'bg-').replace('/50', '-500').replace('/10', '-500')}`} style={{backgroundColor: type.borderColor.replace('border-', '').includes('warning') ? '#f59e0b' : type.borderColor.replace('border-', '').includes('emerald') ? '#10b981' : type.borderColor.replace('border-', '').includes('purple') ? '#9333ea' : type.borderColor.replace('border-', '').includes('orange') ? '#f97316' : type.borderColor.replace('border-', '').includes('red') ? '#ef4444' : '#3b82f6'}}></div>
                      
                      <div className="p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-12 h-12 bg-gray-50 rounded-lg p-2 flex items-center justify-center">
                            <img 
                              src={type.logoSrc} 
                              alt={`${type.name} logo`}
                              className="w-full h-full object-contain"
                            />
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900">{type.name}</h3>
                            <p className="text-xs text-gray-500">Agent</p>
                          </div>
                        </div>
                        
                        <p className="text-gray-600 text-xs mb-3 line-clamp-2">
                          {type.description}
                        </p>
                        
                        <div className="space-y-1">
                          {type.features.slice(0, 3).map((feature, index) => (
                            <div key={index} className="flex items-center gap-2 text-xs text-gray-500">
                              <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                              <span className="line-clamp-1">{feature}</span>
                            </div>
                          ))}
                          {type.features.length > 3 && (
                            <p className="text-xs text-blue-600 font-medium mt-2">+{type.features.length - 3} more features</p>
                          )}
                        </div>
                      </div>
                      
                      <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white">
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                          </svg>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>
        )}

        {appState === 'upload' && selectedProjectType && (
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <button
                onClick={() => setSelectedProjectType(null)}
                className="text-primary hover:text-primary/80 flex items-center space-x-2 mb-4"
              >
                <span>← Back to AI agents</span>
              </button>
              <div className="flex items-center space-x-4">
                {(() => {
                  const selectedType = projectTypes.find(t => t.id === selectedProjectType);
                  if (!selectedType) return null;
                  return (
                    <>
                      <div className="inline-flex items-center justify-center w-16 h-16 bg-white rounded-lg p-3">
                        <img 
                          src={selectedType.logoSrc} 
                          alt={`${selectedType.name} logo`}
                          className="w-full h-full object-contain"
                        />
                      </div>
                      <div>
                        <h1 className="text-2xl font-bold text-foreground">
                          {selectedType.name}
                        </h1>
                        <p className="text-muted-foreground">
                          {selectedType.description}
                        </p>
                      </div>
                    </>
                  );
                })()}
              </div>
            </div>
            <UploadSection onFileUploaded={handleFileUploaded} onGitHubAnalyzed={handleGitHubAnalyzed} projectType={selectedProjectType || 'java'} />
          </div>
        )}
        
        {appState === 'processing' && currentProject && (
          <ProcessingSection project={currentProject} projectType={selectedProjectType || 'java'} />
        )}
        
        {appState === 'results' && currentProject && currentProject.analysisData && (
          <div className="space-y-8">
            {currentProject.analysisData && typeof currentProject.analysisData === 'object' && (() => {
              const analysisData = currentProject.analysisData as any;
              const isCobolProject = analysisData.classes?.some((c: any) => 
                c.type === 'program' || c.type === 'copybook' || c.type === 'jcl' || c.type === 'procedure'
              );
              
              if (isCobolProject) {
                return (
                  <>
                    <Dashboard 
                      analysisData={analysisData} 
                      onAIAnalysisComplete={handleAIAnalysisComplete}
                    />
                    <AnalysisResults 
                      project={currentProject} 
                      onNewAnalysis={handleNewAnalysis}
                    />
                  </>
                );
              } else {
                return (
                  <>
                    <JavaDashboard 
                      analysisData={analysisData} 
                      onAIAnalysisComplete={handleAIAnalysisComplete}
                    />
                    <AnalysisResults 
                      project={currentProject} 
                      onNewAnalysis={handleNewAnalysis}
                    />
                  </>
                );
              }
            })()}
          </div>
        )}
      </div>

      {/* Floating Action Button - only show in results view */}
      {appState === 'results' && (
        <button
          onClick={handleNewAnalysis}
          className="fixed bottom-6 right-6 bg-primary text-primary-foreground p-4 rounded-full shadow-lg hover:bg-primary/90 transition-all hover:scale-105"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
        </button>
      )}

      {/* AI Model Configuration Modal */}
      {showAIConfig && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">AI Model Configuration</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowAIConfig(false)}
                >
                  ✕
                </Button>
              </div>
            </div>
            <div className="p-4">
              <AIModelSelector
                onModelSelect={handleAIModelConfig}
                currentConfig={aiConfig}
              />
            </div>
          </div>
        </div>
      )}

      {/* Development Mode Modal */}
      {showDevelopmentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full transform transition-all">
            <div className="text-center p-8">
              {/* Icon */}
              <div className="mx-auto flex items-center justify-center w-32 h-32 mb-4">
                <img 
                  src={agentLogo} 
                  alt="Agent" 
                  className="w-32 h-32 object-contain"
                />
              </div>
              
              {/* Title */}
              <h3 className="text-xl font-semibold text-gray-900 mb-1">
                {selectedAgentName}
              </h3>
              
              {/* Application Name */}
              <h4 className="text-sm font-medium text-gray-500 mb-2">
                Zengent AI
              </h4>
              
              {/* Subtitle */}
              <h4 className="text-lg font-medium text-blue-600 mb-3">
                Coming Soon!
              </h4>
              
              {/* Description */}
              <p className="text-gray-600 text-sm mb-6">
                This agent is currently under development and will be available in our next update. 
                Stay tuned for exciting new features!
              </p>
              
              {/* Button */}
              <Button
                onClick={() => setShowDevelopmentModal(false)}
                className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-2 rounded-lg font-medium transition-colors"
              >
                Got it!
              </Button>
            </div>
          </div>
        </div>
      )}
        </div>
      </Layout>
      <Toaster />
    </TooltipProvider>
  );
}
