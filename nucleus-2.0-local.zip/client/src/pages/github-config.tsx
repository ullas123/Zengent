/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Github, ArrowLeft, UploadCloud, DownloadCloud, CheckCircle2, Loader2, Trash2 } from "lucide-react";

interface ParsedFile {
  id: string; nodeId: string; agentId: string; agentName: string;
  lang: string; filename: string; code: string;
}

interface GithubConfigState {
  connected: boolean;
  owner?: string;
  repo?: string;
  branch?: string;
}

export default function GithubConfigPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const [config, setConfig] = useState<GithubConfigState>({ connected: false });
  const [token, setToken] = useState("");
  const [owner, setOwner] = useState("");
  const [repo, setRepo] = useState("");
  const [branch, setBranch] = useState("main");
  const [loading, setLoading] = useState(false);
  const [pushing, setPushing] = useState(false);
  const [pulling, setPulling] = useState(false);
  const [files, setFiles] = useState<ParsedFile[]>([]);

  useEffect(() => {
    const stored = sessionStorage.getItem("nucleus_generated_files");
    if (stored) {
      try { setFiles(JSON.parse(stored)); } catch { /* ignore */ }
    }
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      const res = await apiRequest("GET", "/api/zenseai/github/config");
      const data = await res.json();
      setConfig(data);
      if (data.connected) {
        setOwner(data.owner || "");
        setRepo(data.repo || "");
        setBranch(data.branch || "main");
      }
    } catch (err: any) {
      // no config yet, ignore
    }
  };

  const handleSave = async () => {
    if (!token || !owner || !repo) {
      toast({ title: "Missing fields", description: "Token, owner and repository are required.", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const res = await apiRequest("POST", "/api/zenseai/github/config", { token, owner, repo, branch: branch || "main" });
      const data = await res.json();
      toast({ title: "GitHub connected", description: `Linked to ${data.owner}/${data.repo} (${data.branch})` });
      setToken("");
      await loadConfig();
    } catch (err: any) {
      toast({ title: "Connection failed", description: err?.message || "Could not verify GitHub credentials", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = async () => {
    setLoading(true);
    try {
      await apiRequest("DELETE", "/api/zenseai/github/config");
      setConfig({ connected: false });
      setOwner(""); setRepo(""); setBranch("main");
      toast({ title: "Disconnected", description: "GitHub configuration removed." });
    } catch (err: any) {
      toast({ title: "Failed to disconnect", description: err?.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handlePush = async () => {
    if (files.length === 0) {
      toast({ title: "No generated files", description: "Go back to Agent Factory and run the flow to generate code first.", variant: "destructive" });
      return;
    }
    setPushing(true);
    try {
      const payloadFiles = files.map(f => ({
        path: `${(f.agentName || f.agentId).replace(/[^\w\- ]/g, "").trim()}/${f.filename}`,
        content: f.code,
      }));
      const res = await apiRequest("POST", "/api/zenseai/github/push", {
        files: payloadFiles,
        message: "Push generated code from Nucleus Agent Factory",
      });
      const data = await res.json();
      toast({
        title: data.success ? "Push complete" : "Push finished with errors",
        description: `${data.pushedCount} pushed, ${data.failedCount} failed`,
        variant: data.success ? "default" : "destructive",
      });
    } catch (err: any) {
      toast({ title: "Push failed", description: err?.message, variant: "destructive" });
    } finally {
      setPushing(false);
    }
  };

  const handlePull = async () => {
    setPulling(true);
    try {
      const res = await apiRequest("GET", "/api/zenseai/github/pull");
      const data = await res.json();
      sessionStorage.setItem("nucleus_pulled_files", JSON.stringify(data.files || []));
      toast({ title: "Pull complete", description: `Fetched ${data.fileCount} file(s) from ${data.owner}/${data.repo}` });
      navigate("/code-explorer?source=pulled");
    } catch (err: any) {
      toast({ title: "Pull failed", description: err?.message, variant: "destructive" });
    } finally {
      setPulling(false);
    }
  };

  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "32px 20px" }}>
      <button
        onClick={() => navigate("/zenseai-platform")}
        style={{ display: "flex", alignItems: "center", gap: 6, background: "none", border: "none", color: "#64748B", fontSize: 13, cursor: "pointer", marginBottom: 20 }}
      >
        <ArrowLeft size={14} /> Back to Agent Factory
      </button>

      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
        <Github size={22} />
        <h1 style={{ fontSize: 22, fontWeight: 800, margin: 0 }}>GitHub Configuration</h1>
      </div>
      <p style={{ color: "#64748B", fontSize: 13, marginBottom: 24 }}>
        Connect Nucleus to a GitHub repository using a personal access token, then push generated code or pull existing code for review.
      </p>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            Connection
            {config.connected && <CheckCircle2 className="text-green-600" size={16} />}
          </CardTitle>
          <CardDescription>
            {config.connected
              ? `Connected to ${config.owner}/${config.repo} (branch: ${config.branch})`
              : "Not connected yet. Create a token at github.com/settings/tokens with 'repo' scope."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="gh-token">Personal Access Token</Label>
            <Input id="gh-token" type="password" placeholder={config.connected ? "•••••••• (leave blank to keep current)" : "ghp_..."} value={token} onChange={e => setToken(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="gh-owner">Owner / Organization</Label>
              <Input id="gh-owner" placeholder="e.g. my-org" value={owner} onChange={e => setOwner(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="gh-repo">Repository</Label>
              <Input id="gh-repo" placeholder="e.g. nucleus-generated" value={repo} onChange={e => setRepo(e.target.value)} />
            </div>
          </div>
          <div>
            <Label htmlFor="gh-branch">Branch</Label>
            <Input id="gh-branch" placeholder="main" value={branch} onChange={e => setBranch(e.target.value)} />
          </div>
          <div className="flex gap-2">
            <Button onClick={handleSave} disabled={loading}>
              {loading ? <Loader2 className="animate-spin mr-2" size={14} /> : null}
              {config.connected ? "Update Connection" : "Connect GitHub"}
            </Button>
            {config.connected && (
              <Button variant="outline" onClick={handleDisconnect} disabled={loading}>
                <Trash2 size={14} className="mr-2" /> Disconnect
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Push & Pull</CardTitle>
          <CardDescription>
            {files.length > 0
              ? `${files.length} generated file(s) ready to push from your last Agent Factory session.`
              : "No generated files loaded — open Agent Factory, run the flow, then come back here to push."}
          </CardDescription>
        </CardHeader>
        <CardContent className="flex gap-3">
          <Button onClick={handlePush} disabled={!config.connected || pushing}>
            {pushing ? <Loader2 className="animate-spin mr-2" size={14} /> : <UploadCloud size={14} className="mr-2" />}
            Push Generated Code
          </Button>
          <Button variant="outline" onClick={handlePull} disabled={!config.connected || pulling}>
            {pulling ? <Loader2 className="animate-spin mr-2" size={14} /> : <DownloadCloud size={14} className="mr-2" />}
            Pull From Repository
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
