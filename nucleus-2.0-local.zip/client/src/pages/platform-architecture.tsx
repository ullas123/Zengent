/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useCallback, useMemo } from 'react';
import ReactFlow, {
  Node,
  Edge,
  Background,
  Controls,
  useNodesState,
  useEdgesState,
  MarkerType,
  Position,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Upload, 
  Database, 
  Brain, 
  FileText, 
  Shield, 
  Network,
  Code,
  Cpu,
  Cloud,
  BarChart3,
  Coins,
  Zap,
  Server,
  Globe,
  Palette,
  Lock,
  FileCode
} from "lucide-react";

const nodeDefaults = {
  sourcePosition: Position.Right,
  targetPosition: Position.Left,
};

const initialNodes: Node[] = [
  {
    id: 'input-header',
    type: 'default',
    position: { x: 50, y: 20 },
    data: { label: 'INPUT LAYER' },
    style: { 
      background: 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)', 
      color: 'white', 
      fontWeight: 'bold',
      fontSize: '14px',
      border: 'none',
      borderRadius: '8px',
      padding: '8px 16px',
      width: 180,
    },
    draggable: true,
  },
  {
    id: 'zip-upload',
    type: 'default',
    position: { x: 50, y: 80 },
    data: { label: '📦 ZIP Upload (≤50MB)' },
    style: { 
      background: '#dbeafe', 
      border: '2px solid #3b82f6',
      borderRadius: '8px',
      padding: '12px',
      width: 180,
    },
    ...nodeDefaults,
  },
  {
    id: 'github-clone',
    type: 'default',
    position: { x: 50, y: 150 },
    data: { label: '🔗 GitHub Repository' },
    style: { 
      background: '#dbeafe', 
      border: '2px solid #3b82f6',
      borderRadius: '8px',
      padding: '12px',
      width: 180,
    },
    ...nodeDefaults,
  },
  {
    id: 'excel-mapping',
    type: 'default',
    position: { x: 50, y: 220 },
    data: { label: '📊 Excel Field Mapping' },
    style: { 
      background: '#dbeafe', 
      border: '2px solid #3b82f6',
      borderRadius: '8px',
      padding: '12px',
      width: 180,
    },
    ...nodeDefaults,
  },

  {
    id: 'analysis-header',
    type: 'default',
    position: { x: 320, y: 20 },
    data: { label: 'ANALYSIS ENGINES' },
    style: { 
      background: 'linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%)', 
      color: 'white', 
      fontWeight: 'bold',
      fontSize: '14px',
      border: 'none',
      borderRadius: '8px',
      padding: '8px 16px',
      width: 200,
    },
    draggable: true,
  },
  {
    id: 'java-analyzer',
    type: 'default',
    position: { x: 320, y: 80 },
    data: { label: '☕ Java Analyzer\nSpring Boot, JPA, REST' },
    style: { 
      background: '#f3e8ff', 
      border: '2px solid #8b5cf6',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },
  {
    id: 'cobol-analyzer',
    type: 'default',
    position: { x: 320, y: 160 },
    data: { label: '🖥️ COBOL Analyzer\nPrograms, Copybooks, JCL' },
    style: { 
      background: '#f3e8ff', 
      border: '2px solid #8b5cf6',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },
  {
    id: 'python-analyzer',
    type: 'default',
    position: { x: 320, y: 240 },
    data: { label: '🐍 Python Analyzer\nDjango, Flask, PySpark' },
    style: { 
      background: '#f3e8ff', 
      border: '2px solid #8b5cf6',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },
  {
    id: 'demographic-scanner',
    type: 'default',
    position: { x: 320, y: 320 },
    data: { label: '🔍 Demographic Scanner\n39+ PII Patterns' },
    style: { 
      background: '#fef3c7', 
      border: '2px solid #f59e0b',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },

  {
    id: 'ai-header',
    type: 'default',
    position: { x: 610, y: 20 },
    data: { label: 'AI AGENTS' },
    style: { 
      background: 'linear-gradient(135deg, #06b6d4 0%, #0891b2 100%)', 
      color: 'white', 
      fontWeight: 'bold',
      fontSize: '14px',
      border: 'none',
      borderRadius: '8px',
      padding: '8px 16px',
      width: 200,
    },
    draggable: true,
  },
  {
    id: 'openai-agent',
    type: 'default',
    position: { x: 610, y: 80 },
    data: { label: '🤖 OpenAI GPT-4o\nCloud AI Analysis' },
    style: { 
      background: '#cffafe', 
      border: '2px solid #06b6d4',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },
  {
    id: 'ollama-agent',
    type: 'default',
    position: { x: 610, y: 160 },
    data: { label: '🦙 Ollama LLM\nOffline AI Analysis' },
    style: { 
      background: '#cffafe', 
      border: '2px solid #06b6d4',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },
  {
    id: 'vector-agent',
    type: 'default',
    position: { x: 610, y: 240 },
    data: { label: '🔎 Vector Search\nChromaDB + CodeBERT' },
    style: { 
      background: '#cffafe', 
      border: '2px solid #06b6d4',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },
  {
    id: 'knowledge-agent',
    type: 'default',
    position: { x: 610, y: 320 },
    data: { label: '📚 Knowledge Agent\nConfluence + PDF' },
    style: { 
      background: '#cffafe', 
      border: '2px solid #06b6d4',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },

  {
    id: 'output-header',
    type: 'default',
    position: { x: 900, y: 20 },
    data: { label: 'OUTPUT LAYER' },
    style: { 
      background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)', 
      color: 'white', 
      fontWeight: 'bold',
      fontSize: '14px',
      border: 'none',
      borderRadius: '8px',
      padding: '8px 16px',
      width: 200,
    },
    draggable: true,
  },
  {
    id: 'dashboards',
    type: 'default',
    position: { x: 900, y: 80 },
    data: { label: '📊 Interactive Dashboards\nReact Flow, Cytoscape' },
    style: { 
      background: '#d1fae5', 
      border: '2px solid #10b981',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },
  {
    id: 'exports',
    type: 'default',
    position: { x: 900, y: 160 },
    data: { label: '📄 Export Formats\nPDF, Word, HTML, SVG' },
    style: { 
      background: '#d1fae5', 
      border: '2px solid #10b981',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },
  {
    id: 'confluence-sync',
    type: 'default',
    position: { x: 900, y: 240 },
    data: { label: '☁️ Confluence Sync\nLiving Documentation' },
    style: { 
      background: '#d1fae5', 
      border: '2px solid #10b981',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },
  {
    id: 'quality-reports',
    type: 'default',
    position: { x: 900, y: 320 },
    data: { label: '🛡️ Quality & Security\nISO-5055, CWE Reports' },
    style: { 
      background: '#fee2e2', 
      border: '2px solid #ef4444',
      borderRadius: '8px',
      padding: '12px',
      width: 200,
      whiteSpace: 'pre-wrap',
      textAlign: 'center',
    },
    ...nodeDefaults,
  },
];

const initialEdges: Edge[] = [
  { id: 'e1', source: 'zip-upload', target: 'java-analyzer', animated: true, style: { stroke: '#3b82f6', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#3b82f6' } },
  { id: 'e2', source: 'zip-upload', target: 'cobol-analyzer', animated: true, style: { stroke: '#3b82f6', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#3b82f6' } },
  { id: 'e3', source: 'zip-upload', target: 'python-analyzer', animated: true, style: { stroke: '#3b82f6', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#3b82f6' } },
  { id: 'e4', source: 'github-clone', target: 'java-analyzer', animated: true, style: { stroke: '#3b82f6', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#3b82f6' } },
  { id: 'e5', source: 'github-clone', target: 'cobol-analyzer', animated: true, style: { stroke: '#3b82f6', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#3b82f6' } },
  { id: 'e6', source: 'excel-mapping', target: 'demographic-scanner', animated: true, style: { stroke: '#f59e0b', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#f59e0b' } },
  
  { id: 'e7', source: 'java-analyzer', target: 'openai-agent', animated: true, style: { stroke: '#8b5cf6', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#8b5cf6' } },
  { id: 'e8', source: 'cobol-analyzer', target: 'openai-agent', animated: true, style: { stroke: '#8b5cf6', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#8b5cf6' } },
  { id: 'e9', source: 'python-analyzer', target: 'ollama-agent', animated: true, style: { stroke: '#8b5cf6', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#8b5cf6' } },
  { id: 'e10', source: 'java-analyzer', target: 'vector-agent', animated: true, style: { stroke: '#8b5cf6', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#8b5cf6' } },
  { id: 'e11', source: 'demographic-scanner', target: 'knowledge-agent', animated: true, style: { stroke: '#f59e0b', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#f59e0b' } },
  
  { id: 'e12', source: 'openai-agent', target: 'dashboards', animated: true, style: { stroke: '#06b6d4', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#06b6d4' } },
  { id: 'e13', source: 'ollama-agent', target: 'dashboards', animated: true, style: { stroke: '#06b6d4', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#06b6d4' } },
  { id: 'e14', source: 'vector-agent', target: 'exports', animated: true, style: { stroke: '#06b6d4', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#06b6d4' } },
  { id: 'e15', source: 'knowledge-agent', target: 'confluence-sync', animated: true, style: { stroke: '#06b6d4', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#06b6d4' } },
  { id: 'e16', source: 'openai-agent', target: 'quality-reports', animated: true, style: { stroke: '#ef4444', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#ef4444' } },
];

export default function PlatformArchitecture() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  return (
    <div className="container mx-auto px-6 py-8" data-testid="platform-architecture-page">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          Platform Architecture
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          Interactive visualization of the Nucleus Multi-Language Analysis Platform
        </p>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
            <CardTitle className="flex items-center gap-2">
              <Network className="h-5 w-5 text-blue-600" />
              Multi-Language Analysis Platform Architecture
            </CardTitle>
            <CardDescription>
              Interactive diagram showing the complete data flow from input to output
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div style={{ width: '100%', height: '500px' }} className="border-t">
              <ReactFlow
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                fitView
                attributionPosition="bottom-left"
              >
                <Background color="#e2e8f0" gap={16} />
                <Controls />
              </ReactFlow>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-4 gap-4">
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Upload className="h-4 w-4 text-blue-600" />
                Input Layer
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• ZIP Upload (≤50MB)</li>
                <li>• GitHub Repository Clone</li>
                <li>• Excel Field Mapping</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Code className="h-4 w-4 text-purple-600" />
                Analysis Engines
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Java Analyzer (Spring Boot)</li>
                <li>• COBOL Analyzer (Mainframe)</li>
                <li>• Python Analyzer (Django/Flask)</li>
                <li>• Demographic Scanner</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-cyan-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Brain className="h-4 w-4 text-cyan-600" />
                AI Agents
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• OpenAI GPT-4o (Cloud)</li>
                <li>• Ollama LLM (Offline)</li>
                <li>• Vector Search (ChromaDB)</li>
                <li>• Knowledge Agent</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-green-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <FileText className="h-4 w-4 text-green-600" />
                Output Layer
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Interactive Dashboards</li>
                <li>• Export (PDF, Word, HTML)</li>
                <li>• Confluence Sync</li>
                <li>• Quality & Security Reports</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <Card className="border-2 border-cyan-200 dark:border-cyan-800">
          <CardHeader className="bg-gradient-to-r from-cyan-50 to-blue-50 dark:from-cyan-950 dark:to-blue-950">
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-cyan-600" />
              AI Models & Token Usage
            </CardTitle>
            <CardDescription>AI integration details and usage metrics per analysis</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-semibold flex items-center gap-2 text-lg">
                  <Cloud className="h-5 w-5 text-green-600" />
                  Cloud AI (OpenAI)
                </h4>
                <div className="bg-green-50 dark:bg-green-950 rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Model Version</span>
                    <Badge className="bg-green-600">GPT-4o (gpt-4o-2024-08-06)</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Context Window</span>
                    <span className="text-sm text-muted-foreground">128,000 tokens</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Max Output</span>
                    <span className="text-sm text-muted-foreground">16,384 tokens</span>
                  </div>
                  <div className="border-t pt-3 mt-3">
                    <p className="text-xs text-muted-foreground mb-2">Cost per Analysis (Estimated)</p>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center gap-1">
                        <Coins className="h-3 w-3 text-amber-500" />
                        <span>Input: $5.00/1M tokens</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Coins className="h-3 w-3 text-amber-500" />
                        <span>Output: $15.00/1M tokens</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-semibold flex items-center gap-2 text-lg">
                  <Server className="h-5 w-5 text-orange-600" />
                  Local AI (Ollama)
                </h4>
                <div className="bg-orange-50 dark:bg-orange-950 rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Supported Models</span>
                    <Badge className="bg-orange-600">Multiple</Badge>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Zap className="h-3 w-3 text-orange-500" />
                      <span>Code Llama (7B, 13B, 34B)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Zap className="h-3 w-3 text-orange-500" />
                      <span>Deepseek Coder (6.7B, 33B)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Zap className="h-3 w-3 text-orange-500" />
                      <span>StarCoder2 (3B, 7B, 15B)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Zap className="h-3 w-3 text-orange-500" />
                      <span>Llama 3 / Mistral</span>
                    </div>
                  </div>
                  <div className="border-t pt-3 mt-3">
                    <p className="text-xs text-muted-foreground">No internet required - fully offline analysis</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-600" />
                Typical Usage Per Analysis
              </h4>
              <div className="grid md:grid-cols-4 gap-4">
                <div className="text-center p-3 bg-white dark:bg-slate-800 rounded-lg">
                  <p className="text-2xl font-bold text-blue-600">3-5</p>
                  <p className="text-xs text-muted-foreground">API Calls</p>
                </div>
                <div className="text-center p-3 bg-white dark:bg-slate-800 rounded-lg">
                  <p className="text-2xl font-bold text-green-600">~8K</p>
                  <p className="text-xs text-muted-foreground">Input Tokens</p>
                </div>
                <div className="text-center p-3 bg-white dark:bg-slate-800 rounded-lg">
                  <p className="text-2xl font-bold text-purple-600">~2K</p>
                  <p className="text-xs text-muted-foreground">Output Tokens</p>
                </div>
                <div className="text-center p-3 bg-white dark:bg-slate-800 rounded-lg">
                  <p className="text-2xl font-bold text-amber-600">~$0.07</p>
                  <p className="text-xs text-muted-foreground">Est. Cost/Analysis</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-indigo-200 dark:border-indigo-800">
          <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950">
            <CardTitle className="flex items-center gap-2">
              <Cpu className="h-5 w-5 text-indigo-600" />
              Detailed Technology Stack
            </CardTitle>
            <CardDescription>Complete breakdown of technologies powering the platform</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="space-y-4">
                <h4 className="font-semibold flex items-center gap-2 border-b pb-2">
                  <Globe className="h-4 w-4 text-blue-600" />
                  Frontend
                </h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">React</span>
                    <Badge variant="outline" className="text-xs">v18.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">TypeScript</span>
                    <Badge variant="outline" className="text-xs">v5.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Vite</span>
                    <Badge variant="outline" className="text-xs">v5.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">TailwindCSS</span>
                    <Badge variant="outline" className="text-xs">v3.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">shadcn/ui</span>
                    <Badge variant="outline" className="text-xs">Latest</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">TanStack Query</span>
                    <Badge variant="outline" className="text-xs">v5.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Wouter</span>
                    <Badge variant="outline" className="text-xs">v3.x</Badge>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold flex items-center gap-2 border-b pb-2">
                  <Server className="h-4 w-4 text-green-600" />
                  Backend
                </h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Node.js</span>
                    <Badge variant="outline" className="text-xs">v20.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Express.js</span>
                    <Badge variant="outline" className="text-xs">v4.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">PostgreSQL</span>
                    <Badge variant="outline" className="text-xs">v15+</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Drizzle ORM</span>
                    <Badge variant="outline" className="text-xs">Latest</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Multer</span>
                    <Badge variant="outline" className="text-xs">v1.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">bcrypt</span>
                    <Badge variant="outline" className="text-xs">v5.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Zod</span>
                    <Badge variant="outline" className="text-xs">v3.x</Badge>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold flex items-center gap-2 border-b pb-2">
                  <Palette className="h-4 w-4 text-purple-600" />
                  Visualization
                </h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">React Flow</span>
                    <Badge variant="outline" className="text-xs">v11.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Cytoscape.js</span>
                    <Badge variant="outline" className="text-xs">v3.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Mermaid.js</span>
                    <Badge variant="outline" className="text-xs">v10.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Graphviz</span>
                    <Badge variant="outline" className="text-xs">v2.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Recharts</span>
                    <Badge variant="outline" className="text-xs">v2.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">html2canvas</span>
                    <Badge variant="outline" className="text-xs">v1.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">jsPDF</span>
                    <Badge variant="outline" className="text-xs">v2.x</Badge>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6 mt-6 pt-6 border-t">
              <div className="space-y-4">
                <h4 className="font-semibold flex items-center gap-2">
                  <Brain className="h-4 w-4 text-cyan-600" />
                  AI & Machine Learning
                </h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">OpenAI SDK</span>
                    <Badge variant="outline" className="text-xs">v4.x</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Ollama API</span>
                    <Badge variant="outline" className="text-xs">REST</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">ChromaDB</span>
                    <Badge variant="outline" className="text-xs">Vector DB</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">TensorFlow (Python)</span>
                    <Badge variant="outline" className="text-xs">NumPy</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">scikit-learn</span>
                    <Badge variant="outline" className="text-xs">ML</Badge>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold flex items-center gap-2">
                  <Lock className="h-4 w-4 text-red-600" />
                  Security & Quality
                </h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">ISO/IEC 5055</span>
                    <Badge variant="outline" className="text-xs">Quality Standard</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">CWE Scanner</span>
                    <Badge variant="outline" className="text-xs">30+ Rules</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">OWASP Top 10</span>
                    <Badge variant="outline" className="text-xs">Mapped</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Compliance</span>
                    <Badge variant="outline" className="text-xs">GDPR, HIPAA, PCI-DSS</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Session Auth</span>
                    <Badge variant="outline" className="text-xs">express-session</Badge>
                  </div>
                </div>
              </div>
            </div>

            {/* Code Analyzers & Parsers Section */}
            <div className="grid md:grid-cols-2 gap-6 mt-6 pt-6 border-t">
              <div className="space-y-4">
                <h4 className="font-semibold flex items-center gap-2">
                  <Code className="h-4 w-4 text-violet-600" />
                  COBOL/Mainframe Analyzer
                </h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Parser Engine</span>
                    <Badge variant="outline" className="text-xs">Custom TypeScript</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Division Detection</span>
                    <Badge variant="outline" className="text-xs">Regex-based AST</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">CALL Analysis</span>
                    <Badge variant="outline" className="text-xs">Static Extraction</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">COPY Statement</span>
                    <Badge variant="outline" className="text-xs">Dependency Mapping</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">JCL Parser</span>
                    <Badge variant="outline" className="text-xs">EXEC/DD Analysis</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Data Division</span>
                    <Badge variant="outline" className="text-xs">Field Extraction</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">File Handling</span>
                    <Badge variant="outline" className="text-xs">JSZip</Badge>
                  </div>
                </div>
                <div className="mt-3 p-3 bg-violet-50 dark:bg-violet-950 rounded-lg">
                  <p className="text-xs text-muted-foreground">
                    <strong>Supported:</strong> COBOL-85, COBOL-II, Enterprise COBOL, JCL, Copybooks (CPY/CBL)
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold flex items-center gap-2">
                  <Code className="h-4 w-4 text-orange-600" />
                  Java/Spring Analyzer
                </h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Parser Engine</span>
                    <Badge variant="outline" className="text-xs">Custom TypeScript</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Class Detection</span>
                    <Badge variant="outline" className="text-xs">Regex-based AST</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Annotation Parser</span>
                    <Badge variant="outline" className="text-xs">Spring/JPA/REST</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Method Extraction</span>
                    <Badge variant="outline" className="text-xs">Signature Analysis</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Import Analysis</span>
                    <Badge variant="outline" className="text-xs">Dependency Graph</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Package Structure</span>
                    <Badge variant="outline" className="text-xs">Hierarchy Mapping</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">File Handling</span>
                    <Badge variant="outline" className="text-xs">JSZip</Badge>
                  </div>
                </div>
                <div className="mt-3 p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
                  <p className="text-xs text-muted-foreground">
                    <strong>Supported:</strong> Java 8-21, Spring Boot, JPA/Hibernate, REST APIs, Maven/Gradle
                  </p>
                </div>
              </div>
            </div>

            {/* Parser Methodology Description */}
            <div className="mt-6 pt-6 border-t">
              <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 rounded-lg">
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <FileCode className="h-4 w-4 text-blue-600" />
                  Parser Engine Methodology
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Nucleus uses <strong>custom-built TypeScript parsers</strong> with <strong>Regex-based Abstract Syntax Tree (AST) construction</strong> rather than traditional parser generators like ANTLR or Yacc. 
                  For <strong>COBOL/Mainframe analysis</strong>, the parser scans source files to identify IDENTIFICATION, ENVIRONMENT, DATA, and PROCEDURE divisions using pattern matching, extracts CALL statements for program dependencies, parses COPY statements for copybook relationships, and maps DATA DIVISION fields for demographic scanning. 
                  For <strong>Java/Spring analysis</strong>, the parser detects class declarations, annotations (@Controller, @Service, @Repository, @Entity), method signatures, and import statements to build dependency graphs. 
                  Uploaded ZIP files are processed using <strong>JSZip</strong> for in-memory extraction. 
                  Interactive visualizations are generated using <strong>React Flow</strong> for data flow diagrams, <strong>Cytoscape.js</strong> for dependency graphs, <strong>Mermaid.js</strong> for sequence diagrams, and <strong>Graphviz</strong> for UML class diagrams. 
                  AI-powered insights are generated by sending extracted code structures to <strong>OpenAI GPT-4o</strong> for natural language explanations and business rule extraction.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
