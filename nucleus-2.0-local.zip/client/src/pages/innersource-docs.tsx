/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  FileText, 
  Code, 
  GitBranch, 
  Shield, 
  Database, 
  Brain,
  Zap,
  BarChart3,
  CheckCircle2,
  Book,
  Workflow,
  Search,
  Cloud,
  Lock,
  DollarSign,
  AlertTriangle,
  Package,
  FileCode,
  Settings,
  TrendingUp,
  Award,
  Network,
  Cpu,
  Users,
  Bot,
  Target,
  Sparkles,
  Download
} from "lucide-react";

export default function InnersourceDocsPage() {
  const exportToHTML = () => {
    const content = document.getElementById('innersource-content');
    if (!content) return;
    
    const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Innersource Agentic SDLC Framework - Code Lens</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        h1, h2, h3 { color: #2563eb; }
        .badge { display: inline-block; padding: 4px 12px; background: #e2e8f0; border-radius: 4px; margin: 4px; }
        .card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin: 20px 0; }
        .card-header { border-bottom: 1px solid #e2e8f0; padding-bottom: 10px; margin-bottom: 15px; }
        ul { list-style-type: none; padding-left: 0; }
        li:before { content: "✓ "; color: #10b981; font-weight: bold; }
    </style>
</head>
<body>
    ${content.innerHTML}
</body>
</html>
    `;
    
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'innersource-documentation-generator.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto p-6 space-y-8" id="innersource-content">
        {/* Header */}
        <div className="text-center space-y-4 py-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Book className="h-12 w-12 text-blue-600" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Innersource Agentic SDLC Framework
            </h1>
            <Button 
              onClick={exportToHTML}
              variant="outline"
              size="sm"
              className="flex items-center gap-2 ml-4"
              data-testid="button-export-html"
            >
              <Download className="h-4 w-4" />
              Export HTML
            </Button>
          </div>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Automate creation of delivery teams' documentation based on their code base
          </p>
          <div className="flex gap-2 justify-center flex-wrap">
            <Badge variant="secondary" className="px-4 py-1">
              <Sparkles className="h-3 w-3 mr-1" />
              AI-Powered
            </Badge>
            <Badge variant="secondary" className="px-4 py-1">
              <Zap className="h-3 w-3 mr-1" />
              Automated
            </Badge>
            <Badge variant="secondary" className="px-4 py-1">
              <FileText className="h-3 w-3 mr-1" />
              Comprehensive
            </Badge>
          </div>
        </div>

        {/* What is it? */}
        <Card className="border-2 border-blue-200 dark:border-blue-900 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900">
            <CardTitle className="text-2xl flex items-center gap-2">
              <Target className="h-6 w-6 text-blue-600" />
              What is Innersource Documentation Generator?
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              The Innersource Documentation Generator is an intelligent automation tool that analyzes your team's codebase 
              and automatically generates comprehensive, accurate, and up-to-date technical documentation. By leveraging 
              AI-powered code analysis, it eliminates manual documentation effort while ensuring consistency across delivery teams.
            </p>
            <div className="grid md:grid-cols-3 gap-4 mt-6">
              <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
                <Bot className="h-8 w-8 text-blue-600 mb-2" />
                <h4 className="font-semibold mb-1">AI-Driven Analysis</h4>
                <p className="text-sm text-muted-foreground">
                  Uses advanced AI models to understand code structure, dependencies, and architecture
                </p>
              </div>
              <div className="bg-purple-50 dark:bg-purple-950 p-4 rounded-lg">
                <Zap className="h-8 w-8 text-purple-600 mb-2" />
                <h4 className="font-semibold mb-1">Zero Manual Effort</h4>
                <p className="text-sm text-muted-foreground">
                  Automatically generates documentation from source code without manual intervention
                </p>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg">
                <FileText className="h-8 w-8 text-green-600 mb-2" />
                <h4 className="font-semibold mb-1">Team Collaboration</h4>
                <p className="text-sm text-muted-foreground">
                  Enables knowledge sharing across delivery teams with standardized documentation
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Core Features */}
        <div className="space-y-6">
          <h2 className="text-3xl font-bold text-center">
            Comprehensive Nucleus Features
          </h2>
          
          {/* Multi-Language Support */}
          <Card>
            <CardHeader className="bg-gradient-to-r from-indigo-50 to-indigo-100 dark:from-indigo-950 dark:to-indigo-900">
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5 text-indigo-600" />
                Multi-Language Code Analysis
              </CardTitle>
              <CardDescription>Support for enterprise programming languages and frameworks</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-semibold flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    Java Ecosystem
                  </h4>
                  <ul className="ml-6 space-y-1 text-sm text-muted-foreground">
                    <li>• Spring Boot, JPA, Hibernate frameworks</li>
                    <li>• REST API controllers and services</li>
                    <li>• Repository pattern detection</li>
                    <li>• Annotation-based configuration analysis</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    Python Frameworks
                  </h4>
                  <ul className="ml-6 space-y-1 text-sm text-muted-foreground">
                    <li>• Django, Flask, FastAPI detection</li>
                    <li>• ORM model extraction</li>
                    <li>• API route documentation</li>
                    <li>• Decorator pattern analysis</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    PySpark & Big Data
                  </h4>
                  <ul className="ml-6 space-y-1 text-sm text-muted-foreground">
                    <li>• DataFrame operations tracking</li>
                    <li>• Job orchestration flow analysis</li>
                    <li>• Data transformation pipeline detection</li>
                    <li>• Spark SQL query extraction</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    Mainframe & Legacy
                  </h4>
                  <ul className="ml-6 space-y-1 text-sm text-muted-foreground">
                    <li>• COBOL program analysis</li>
                    <li>• JCL batch processing documentation</li>
                    <li>• Legacy system integration patterns</li>
                    <li>• Copybook structure extraction</li>
                  </ul>
                </div>
              </div>
              <Separator className="my-4" />
              <div className="flex gap-2 flex-wrap">
                <Badge>C#</Badge>
                <Badge>Kotlin</Badge>
                <Badge>JavaScript</Badge>
                <Badge>TypeScript</Badge>
                <Badge>And more...</Badge>
              </div>
            </CardContent>
          </Card>

          {/* Mainframe COBOL Analysis - NEW SECTION */}
          <Card className="border-2 border-violet-300 dark:border-violet-800">
            <CardHeader className="bg-gradient-to-r from-violet-50 to-purple-100 dark:from-violet-950 dark:to-purple-900">
              <CardTitle className="flex items-center gap-2">
                <Cpu className="h-5 w-5 text-violet-600" />
                Mainframe/COBOL Analysis Agent
              </CardTitle>
              <CardDescription>Comprehensive mainframe code intelligence and documentation</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              <p className="text-muted-foreground">
                The Mainframe Agent provides deep analysis capabilities specifically designed for legacy COBOL systems,
                JCL batch processing, and mainframe infrastructure. It generates dedicated mainframe-specific reports
                with program flows, copybook structures, and job scheduling documentation.
              </p>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="border border-violet-200 dark:border-violet-800 rounded-lg p-4 bg-violet-50/50 dark:bg-violet-950/30">
                  <FileCode className="h-6 w-6 text-violet-600 mb-2" />
                  <h4 className="font-semibold mb-2">COBOL Program Analysis</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Division and section extraction</li>
                    <li>• Paragraph and procedure analysis</li>
                    <li>• PERFORM statement tracing</li>
                    <li>• Working-storage data items</li>
                    <li>• File definitions and I/O operations</li>
                  </ul>
                </div>
                
                <div className="border border-violet-200 dark:border-violet-800 rounded-lg p-4 bg-violet-50/50 dark:bg-violet-950/30">
                  <Database className="h-6 w-6 text-violet-600 mb-2" />
                  <h4 className="font-semibold mb-2">Copybook Management</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Data structure extraction</li>
                    <li>• PIC clause analysis</li>
                    <li>• Level-based hierarchy mapping</li>
                    <li>• REDEFINES relationship tracking</li>
                    <li>• Cross-program usage detection</li>
                  </ul>
                </div>
                
                <div className="border border-violet-200 dark:border-violet-800 rounded-lg p-4 bg-violet-50/50 dark:bg-violet-950/30">
                  <Settings className="h-6 w-6 text-violet-600 mb-2" />
                  <h4 className="font-semibold mb-2">JCL Job Analysis</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Job step extraction and sequencing</li>
                    <li>• DD statement dataset analysis</li>
                    <li>• EXEC PGM program references</li>
                    <li>• PROC procedure calls</li>
                    <li>• Batch job scheduling flows</li>
                  </ul>
                </div>
                
                <div className="border border-violet-200 dark:border-violet-800 rounded-lg p-4 bg-violet-50/50 dark:bg-violet-950/30">
                  <Network className="h-6 w-6 text-violet-600 mb-2" />
                  <h4 className="font-semibold mb-2">Program Relationships</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• CALL statement dependency graphs</li>
                    <li>• COPY statement inclusion tracking</li>
                    <li>• Inter-program data flow</li>
                    <li>• Static and dynamic CALLs</li>
                    <li>• Program linkage documentation</li>
                  </ul>
                </div>
                
                <div className="border border-violet-200 dark:border-violet-800 rounded-lg p-4 bg-violet-50/50 dark:bg-violet-950/30">
                  <Workflow className="h-6 w-6 text-violet-600 mb-2" />
                  <h4 className="font-semibold mb-2">Library Management</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• SOURCE library organization</li>
                    <li>• COPYBOOK library structure</li>
                    <li>• JCL library management</li>
                    <li>• PROCLIB procedure libraries</li>
                    <li>• DATALIB data definitions</li>
                  </ul>
                </div>
                
                <div className="border border-violet-200 dark:border-violet-800 rounded-lg p-4 bg-violet-50/50 dark:bg-violet-950/30">
                  <BarChart3 className="h-6 w-6 text-violet-600 mb-2" />
                  <h4 className="font-semibold mb-2">Mainframe Patterns</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Batch processing patterns</li>
                    <li>• Online transaction patterns</li>
                    <li>• DB2/IMS database access</li>
                    <li>• CICS program detection</li>
                    <li>• SORT/MERGE operations</li>
                  </ul>
                </div>
              </div>

              <Separator className="my-4" />
              
              <div className="bg-violet-100 dark:bg-violet-900/30 p-4 rounded-lg">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <FileText className="h-5 w-5 text-violet-600" />
                  Dedicated Mainframe Report Format
                </h4>
                <p className="text-sm text-muted-foreground mb-3">
                  COBOL projects receive a specialized analysis report designed for mainframe environments:
                </p>
                <div className="grid md:grid-cols-4 gap-3">
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-2xl font-bold text-violet-600">Programs</div>
                    <div className="text-xs text-muted-foreground">COBOL source files</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-2xl font-bold text-blue-600">Copybooks</div>
                    <div className="text-xs text-muted-foreground">Data definitions</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-2xl font-bold text-amber-600">JCL Jobs</div>
                    <div className="text-xs text-muted-foreground">Batch processing</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-2xl font-bold text-green-600">Procedures</div>
                    <div className="text-xs text-muted-foreground">Reusable procs</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Architecture Analysis */}
          <Card>
            <CardHeader className="bg-gradient-to-r from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900">
              <CardTitle className="flex items-center gap-2">
                <Network className="h-5 w-5 text-purple-600" />
                Automated Architecture Documentation
              </CardTitle>
              <CardDescription>Intelligent extraction of system architecture and design patterns</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="border rounded-lg p-4">
                  <GitBranch className="h-6 w-6 text-purple-600 mb-2" />
                  <h4 className="font-semibold mb-2">Dependency Graphs</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Class-to-class dependencies</li>
                    <li>• Module relationships</li>
                    <li>• API endpoint call chains</li>
                    <li>• Database entity relationships</li>
                  </ul>
                </div>
                <div className="border rounded-lg p-4">
                  <Cpu className="h-6 w-6 text-purple-600 mb-2" />
                  <h4 className="font-semibold mb-2">Design Patterns</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• MVC/MVVM pattern detection</li>
                    <li>• Repository pattern analysis</li>
                    <li>• Factory/Builder patterns</li>
                    <li>• Singleton and dependency injection</li>
                  </ul>
                </div>
                <div className="border rounded-lg p-4">
                  <Cloud className="h-6 w-6 text-purple-600 mb-2" />
                  <h4 className="font-semibold mb-2">Architecture Styles</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Monolithic vs Microservices</li>
                    <li>• Layered architecture detection</li>
                    <li>• Event-driven patterns</li>
                    <li>• Service-oriented architecture</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quality & Security */}
          <Card>
            <CardHeader className="bg-gradient-to-r from-red-50 to-red-100 dark:from-red-950 dark:to-red-900">
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-red-600" />
                Quality Metrics & Security Analysis
              </CardTitle>
              <CardDescription>Automated code quality assessment and vulnerability detection</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold flex items-center gap-2">
                    <Award className="h-5 w-5 text-blue-600" />
                    ISO-5055 Quality Metrics
                  </h4>
                  <ul className="space-y-2 ml-6">
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Reliability score (0-100)</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Security vulnerability index</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Maintainability assessment</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Performance efficiency metrics</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Technical debt estimation</span>
                    </li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                    CWE Security Scanning
                  </h4>
                  <ul className="space-y-2 ml-6">
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>SQL injection vulnerabilities (CWE-89)</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Cross-site scripting (CWE-79)</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Buffer overflow detection (CWE-120)</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Authentication vulnerabilities (CWE-287)</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Insecure deserialization (CWE-502)</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Data Compliance - Enhanced */}
          <Card className="border-2 border-orange-300 dark:border-orange-800">
            <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-100 dark:from-orange-950 dark:to-amber-900">
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-orange-600" />
                Demographic Data Compliance Scanner
              </CardTitle>
              <CardDescription>Automated PII/sensitive data detection, compliance tracking, and data migration support</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              <p className="text-muted-foreground">
                The Demographic Data Compliance Scanner provides comprehensive detection and tracking of personally identifiable information (PII) 
                and sensitive data across your codebase. It enables compliance auditing, risk assessment, and supports data migration initiatives 
                with detailed field mapping capabilities.
              </p>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="border border-orange-200 dark:border-orange-800 rounded-lg p-4 bg-orange-50/50 dark:bg-orange-950/30">
                  <Users className="h-6 w-6 text-orange-600 mb-2" />
                  <h4 className="font-semibold mb-2">Personal Identifiers</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Social Security Numbers (SSN)</li>
                    <li>• National ID numbers</li>
                    <li>• Driver's license numbers</li>
                    <li>• Passport identifiers</li>
                    <li>• Employee/Customer IDs</li>
                  </ul>
                </div>

                <div className="border border-orange-200 dark:border-orange-800 rounded-lg p-4 bg-orange-50/50 dark:bg-orange-950/30">
                  <DollarSign className="h-6 w-6 text-orange-600 mb-2" />
                  <h4 className="font-semibold mb-2">Financial Data</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Credit card numbers (PCI-DSS)</li>
                    <li>• Bank account numbers</li>
                    <li>• Routing numbers</li>
                    <li>• Tax identification numbers</li>
                    <li>• Financial transaction data</li>
                  </ul>
                </div>

                <div className="border border-orange-200 dark:border-orange-800 rounded-lg p-4 bg-orange-50/50 dark:bg-orange-950/30">
                  <Lock className="h-6 w-6 text-orange-600 mb-2" />
                  <h4 className="font-semibold mb-2">Contact Information</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Email addresses</li>
                    <li>• Phone numbers</li>
                    <li>• Physical addresses</li>
                    <li>• IP addresses</li>
                    <li>• Geographic coordinates</li>
                  </ul>
                </div>

                <div className="border border-orange-200 dark:border-orange-800 rounded-lg p-4 bg-orange-50/50 dark:bg-orange-950/30">
                  <Shield className="h-6 w-6 text-orange-600 mb-2" />
                  <h4 className="font-semibold mb-2">Health & Biometric</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Medical record numbers</li>
                    <li>• Health insurance IDs</li>
                    <li>• Biometric identifiers</li>
                    <li>• Genetic information</li>
                    <li>• HIPAA-protected data</li>
                  </ul>
                </div>

                <div className="border border-orange-200 dark:border-orange-800 rounded-lg p-4 bg-orange-50/50 dark:bg-orange-950/30">
                  <FileCode className="h-6 w-6 text-orange-600 mb-2" />
                  <h4 className="font-semibold mb-2">Code Context Analysis</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• File and line-level tracking</li>
                    <li>• Function/method context</li>
                    <li>• Class hierarchy analysis</li>
                    <li>• Data flow tracing</li>
                    <li>• Variable usage patterns</li>
                  </ul>
                </div>

                <div className="border border-orange-200 dark:border-orange-800 rounded-lg p-4 bg-orange-50/50 dark:bg-orange-950/30">
                  <TrendingUp className="h-6 w-6 text-orange-600 mb-2" />
                  <h4 className="font-semibold mb-2">Risk Assessment</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Priority levels (CRITICAL/HIGH/MEDIUM/LOW)</li>
                    <li>• GDPR compliance scoring</li>
                    <li>• HIPAA risk assessment</li>
                    <li>• PCI-DSS validation</li>
                    <li>• Custom compliance rules</li>
                  </ul>
                </div>
              </div>

              <Separator className="my-4" />

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-orange-100 dark:bg-orange-900/30 p-4 rounded-lg">
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Database className="h-5 w-5 text-orange-600" />
                    Excel Field Mapping
                  </h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Upload Excel files to map demographic fields for data migration projects:
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Automatic field type detection from column headers</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Source-to-target field mapping</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Codebase field matching with similarity scoring</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Unmatched field identification</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-orange-100 dark:bg-orange-900/30 p-4 rounded-lg">
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Settings className="h-5 w-5 text-orange-600" />
                    Custom Pattern Management
                  </h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Define and manage custom demographic patterns for your organization:
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Create custom regex patterns</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Define field name patterns</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Set custom priority and category</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Organization-wide pattern sharing</span>
                    </li>
                  </ul>
                </div>
              </div>

              <Separator className="my-4" />

              <div className="bg-gradient-to-r from-orange-100 to-amber-100 dark:from-orange-900/40 dark:to-amber-900/40 p-4 rounded-lg">
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  <FileText className="h-5 w-5 text-orange-600" />
                  Compliance Report Generation
                </h4>
                <div className="grid md:grid-cols-4 gap-3">
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-xl font-bold text-red-600">CRITICAL</div>
                    <div className="text-xs text-muted-foreground">Immediate action required</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-xl font-bold text-orange-600">HIGH</div>
                    <div className="text-xs text-muted-foreground">Priority remediation</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-xl font-bold text-yellow-600">MEDIUM</div>
                    <div className="text-xs text-muted-foreground">Scheduled review</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-xl font-bold text-green-600">LOW</div>
                    <div className="text-xs text-muted-foreground">Monitor and track</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Data Imaging Feature */}
          <Card className="border-2 border-teal-300 dark:border-teal-800">
            <CardHeader className="bg-gradient-to-r from-teal-50 to-cyan-100 dark:from-teal-950 dark:to-cyan-900">
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-teal-600" />
                Data Imaging & Visualization
              </CardTitle>
              <CardDescription>Interactive visual representations of code architecture and data flows</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              <p className="text-muted-foreground">
                The Data Imaging feature provides powerful visual representations of your codebase, enabling teams to understand 
                complex architectures, data relationships, and program flows through interactive diagrams and charts.
              </p>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="border border-teal-200 dark:border-teal-800 rounded-lg p-4 bg-teal-50/50 dark:bg-teal-950/30">
                  <Network className="h-6 w-6 text-teal-600 mb-2" />
                  <h4 className="font-semibold mb-2">Dependency Graphs</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Interactive node-based diagrams</li>
                    <li>• Zoom and pan navigation</li>
                    <li>• Relationship highlighting</li>
                    <li>• Clustering by module/package</li>
                    <li>• Export to PNG/SVG/PDF</li>
                  </ul>
                </div>

                <div className="border border-teal-200 dark:border-teal-800 rounded-lg p-4 bg-teal-50/50 dark:bg-teal-950/30">
                  <Workflow className="h-6 w-6 text-teal-600 mb-2" />
                  <h4 className="font-semibold mb-2">Data Flow Charts</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• End-to-end data tracing</li>
                    <li>• Input/output mapping</li>
                    <li>• Transformation visualization</li>
                    <li>• Database interaction flows</li>
                    <li>• API call sequences</li>
                  </ul>
                </div>

                <div className="border border-teal-200 dark:border-teal-800 rounded-lg p-4 bg-teal-50/50 dark:bg-teal-950/30">
                  <Database className="h-6 w-6 text-teal-600 mb-2" />
                  <h4 className="font-semibold mb-2">ER Diagrams</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Entity relationship mapping</li>
                    <li>• Cardinality notation</li>
                    <li>• Primary/foreign key visualization</li>
                    <li>• Table schema display</li>
                    <li>• SQL generation from diagrams</li>
                  </ul>
                </div>

                <div className="border border-teal-200 dark:border-teal-800 rounded-lg p-4 bg-teal-50/50 dark:bg-teal-950/30">
                  <Code className="h-6 w-6 text-teal-600 mb-2" />
                  <h4 className="font-semibold mb-2">UML Class Diagrams</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Graphviz-powered generation</li>
                    <li>• Inheritance hierarchies</li>
                    <li>• Interface implementations</li>
                    <li>• Method signatures</li>
                    <li>• Attribute visibility</li>
                  </ul>
                </div>

                <div className="border border-teal-200 dark:border-teal-800 rounded-lg p-4 bg-teal-50/50 dark:bg-teal-950/30">
                  <GitBranch className="h-6 w-6 text-teal-600 mb-2" />
                  <h4 className="font-semibold mb-2">Sequence Diagrams</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Mermaid.js rendering</li>
                    <li>• Method call sequences</li>
                    <li>• Async operation flows</li>
                    <li>• Actor interactions</li>
                    <li>• Loop and condition blocks</li>
                  </ul>
                </div>

                <div className="border border-teal-200 dark:border-teal-800 rounded-lg p-4 bg-teal-50/50 dark:bg-teal-950/30">
                  <Cpu className="h-6 w-6 text-teal-600 mb-2" />
                  <h4 className="font-semibold mb-2">Component Architecture</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• React Flow interactive diagrams</li>
                    <li>• Layer visualization</li>
                    <li>• Service boundaries</li>
                    <li>• Integration points</li>
                    <li>• Microservice topology</li>
                  </ul>
                </div>
              </div>

              <Separator className="my-4" />

              <div className="bg-teal-100 dark:bg-teal-900/30 p-4 rounded-lg">
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  <Download className="h-5 w-5 text-teal-600" />
                  Export & Sharing Options
                </h4>
                <div className="grid md:grid-cols-4 gap-3">
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-lg font-bold text-teal-600">PNG</div>
                    <div className="text-xs text-muted-foreground">High-res images</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-lg font-bold text-blue-600">SVG</div>
                    <div className="text-xs text-muted-foreground">Scalable vectors</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-lg font-bold text-red-600">PDF</div>
                    <div className="text-xs text-muted-foreground">Print-ready docs</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border text-center">
                    <div className="text-lg font-bold text-green-600">HTML</div>
                    <div className="text-xs text-muted-foreground">Interactive embed</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Confluence Integration */}
          <Card className="border-2 border-blue-300 dark:border-blue-800">
            <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-100 dark:from-blue-950 dark:to-indigo-900">
              <CardTitle className="flex items-center gap-2">
                <Cloud className="h-5 w-5 text-blue-600" />
                Confluence Integration
              </CardTitle>
              <CardDescription>Bi-directional sync for living documentation in Atlassian Confluence</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              <p className="text-muted-foreground">
                Seamlessly integrate with Atlassian Confluence to publish, update, and synchronize your technical documentation.
                Create living documentation that stays current with your codebase through automated sync capabilities.
              </p>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="border border-blue-200 dark:border-blue-800 rounded-lg p-4 bg-blue-50/50 dark:bg-blue-950/30">
                  <Cloud className="h-6 w-6 text-blue-600 mb-2" />
                  <h4 className="font-semibold mb-2">Publish to Confluence</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• One-click page publishing</li>
                    <li>• Space and parent page selection</li>
                    <li>• Automatic page creation</li>
                    <li>• Rich text formatting</li>
                    <li>• Embedded diagrams and images</li>
                  </ul>
                </div>

                <div className="border border-blue-200 dark:border-blue-800 rounded-lg p-4 bg-blue-50/50 dark:bg-blue-950/30">
                  <Workflow className="h-6 w-6 text-blue-600 mb-2" />
                  <h4 className="font-semibold mb-2">Bi-Directional Sync</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Push updates to Confluence</li>
                    <li>• Pull existing documentation</li>
                    <li>• Merge conflict detection</li>
                    <li>• Version history tracking</li>
                    <li>• Scheduled auto-sync</li>
                  </ul>
                </div>

                <div className="border border-blue-200 dark:border-blue-800 rounded-lg p-4 bg-blue-50/50 dark:bg-blue-950/30">
                  <Book className="h-6 w-6 text-blue-600 mb-2" />
                  <h4 className="font-semibold mb-2">Living Documentation</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Auto-update on code changes</li>
                    <li>• API documentation sync</li>
                    <li>• Architecture diagram updates</li>
                    <li>• Change notification alerts</li>
                    <li>• Documentation freshness tracking</li>
                  </ul>
                </div>

                <div className="border border-blue-200 dark:border-blue-800 rounded-lg p-4 bg-blue-50/50 dark:bg-blue-950/30">
                  <Settings className="h-6 w-6 text-blue-600 mb-2" />
                  <h4 className="font-semibold mb-2">Configuration</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Atlassian Cloud authentication</li>
                    <li>• API token management</li>
                    <li>• Space key configuration</li>
                    <li>• Parent page hierarchy</li>
                    <li>• Template customization</li>
                  </ul>
                </div>

                <div className="border border-blue-200 dark:border-blue-800 rounded-lg p-4 bg-blue-50/50 dark:bg-blue-950/30">
                  <FileText className="h-6 w-6 text-blue-600 mb-2" />
                  <h4 className="font-semibold mb-2">Content Types</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Technical specifications</li>
                    <li>• API reference pages</li>
                    <li>• Architecture overviews</li>
                    <li>• Code analysis reports</li>
                    <li>• Quality metrics dashboards</li>
                  </ul>
                </div>

                <div className="border border-blue-200 dark:border-blue-800 rounded-lg p-4 bg-blue-50/50 dark:bg-blue-950/30">
                  <Shield className="h-6 w-6 text-blue-600 mb-2" />
                  <h4 className="font-semibold mb-2">Security & Access</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Secure API token storage</li>
                    <li>• Role-based access control</li>
                    <li>• Audit trail logging</li>
                    <li>• Enterprise SSO support</li>
                    <li>• Data encryption in transit</li>
                  </ul>
                </div>
              </div>

              <Separator className="my-4" />

              <div className="bg-gradient-to-r from-blue-100 to-indigo-100 dark:from-blue-900/40 dark:to-indigo-900/40 p-4 rounded-lg">
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  <Zap className="h-5 w-5 text-blue-600" />
                  Quick Setup Guide
                </h4>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border">
                    <div className="text-sm font-semibold text-blue-600 mb-1">Step 1: Configure</div>
                    <div className="text-xs text-muted-foreground">Add your Confluence base URL and API token in the settings</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border">
                    <div className="text-sm font-semibold text-blue-600 mb-1">Step 2: Select Space</div>
                    <div className="text-xs text-muted-foreground">Choose the Confluence space and parent page for documentation</div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-3 rounded border">
                    <div className="text-sm font-semibold text-blue-600 mb-1">Step 3: Publish</div>
                    <div className="text-xs text-muted-foreground">Click sync to publish your analysis reports to Confluence</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Comprehensive Analysis Reports */}
          <Card>
            <CardHeader className="bg-gradient-to-r from-green-50 to-green-100 dark:from-green-950 dark:to-green-900">
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-green-600" />
                Comprehensive Analysis Reports
              </CardTitle>
              <CardDescription>Detailed technical analysis and documentation reports</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="border rounded-lg p-4">
                  <Brain className="h-6 w-6 text-green-600 mb-2" />
                  <h4 className="font-semibold mb-2">AI-Powered Insights</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Project overview and summary</li>
                    <li>• Architecture analysis and patterns</li>
                    <li>• Code quality assessment</li>
                    <li>• Actionable recommendations</li>
                  </ul>
                </div>
                <div className="border rounded-lg p-4">
                  <Network className="h-6 w-6 text-green-600 mb-2" />
                  <h4 className="font-semibold mb-2">Dependency Mapping</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Complete dependency graphs</li>
                    <li>• Component relationship visualization</li>
                    <li>• Call chain analysis</li>
                    <li>• Cyclic dependency detection</li>
                  </ul>
                </div>
                <div className="border rounded-lg p-4">
                  <FileText className="h-6 w-6 text-green-600 mb-2" />
                  <h4 className="font-semibold mb-2">API Documentation</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Swagger/OpenAPI specifications</li>
                    <li>• REST endpoint documentation</li>
                    <li>• Request/response schemas</li>
                    <li>• Authentication methods</li>
                  </ul>
                </div>
                <div className="border rounded-lg p-4">
                  <Code className="h-6 w-6 text-green-600 mb-2" />
                  <h4 className="font-semibold mb-2">Code Documentation</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Class and method documentation</li>
                    <li>• Code complexity metrics</li>
                    <li>• Function signatures and parameters</li>
                    <li>• Usage examples</li>
                  </ul>
                </div>
                <div className="border rounded-lg p-4">
                  <Database className="h-6 w-6 text-green-600 mb-2" />
                  <h4 className="font-semibold mb-2">Data Model Documentation</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Entity relationship diagrams</li>
                    <li>• Database schema documentation</li>
                    <li>• Field descriptions and constraints</li>
                    <li>• Data flow diagrams</li>
                  </ul>
                </div>
                <div className="border rounded-lg p-4">
                  <Award className="h-6 w-6 text-green-600 mb-2" />
                  <h4 className="font-semibold mb-2">Quality Reports</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• ISO-5055 compliance scores</li>
                    <li>• Technical debt metrics</li>
                    <li>• Code coverage analysis</li>
                    <li>• Best practice adherence</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Advanced AI Agents */}
          <Card>
            <CardHeader className="bg-gradient-to-r from-cyan-50 to-cyan-100 dark:from-cyan-950 dark:to-cyan-900">
              <CardTitle className="flex items-center gap-2">
                <Bot className="h-5 w-5 text-cyan-600" />
                Enterprise AI Agents
              </CardTitle>
              <CardDescription>Specialized AI agents for advanced code intelligence</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold flex items-center gap-2">
                    <Search className="h-5 w-5 text-cyan-600" />
                    Nucleus Vector Agent - Vector Database Intelligence
                  </h4>
                  <ul className="space-y-2 ml-6">
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>ChromaDB persistent vector storage</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Code similarity detection and semantic search</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>HuggingFace CodeBERT for code quality analysis</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Langfuse LLM monitoring and tracing</span>
                    </li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold flex items-center gap-2">
                    <Book className="h-5 w-5 text-cyan-600" />
                    Knowledge Agent - Document Intelligence
                  </h4>
                  <ul className="space-y-2 ml-6">
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Confluence integration for document scraping</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>IBM Doclinq for PDF processing</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>LangChain document processing & Q&A</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Context-aware chat interface with memory</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Professional Reporting */}
          <Card>
            <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100 dark:from-orange-950 dark:to-orange-900">
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5 text-orange-600" />
                Professional Documentation Output
              </CardTitle>
              <CardDescription>Enterprise-grade documentation generation and export</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold">PDF Report Generation</h4>
                  <ul className="space-y-2 ml-4">
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Corporate branding and logo integration</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Executive summary with key metrics</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Detailed technical analysis sections</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Interactive table of contents</span>
                    </li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold">Visual Diagrams</h4>
                  <ul className="space-y-2 ml-4">
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Interactive dependency graphs</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>UML-style architecture diagrams</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Data flow visualizations</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      <span>Swagger API documentation</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Integration Methods */}
        <Card className="border-2 border-green-200 dark:border-green-900 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-green-50 to-green-100 dark:from-green-950 dark:to-green-900">
            <CardTitle className="text-2xl flex items-center gap-2">
              <Zap className="h-6 w-6 text-green-600" />
              How Teams Use Innersource Documentation
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center space-y-3">
                <div className="w-16 h-16 mx-auto bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                  <FileCode className="h-8 w-8 text-blue-600" />
                </div>
                <h4 className="font-semibold">1. Upload Code</h4>
                <p className="text-sm text-muted-foreground">
                  Upload ZIP or connect GitHub repository with your team's codebase
                </p>
              </div>
              
              <div className="text-center space-y-3">
                <div className="w-16 h-16 mx-auto bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center">
                  <Brain className="h-8 w-8 text-purple-600" />
                </div>
                <h4 className="font-semibold">2. AI Analysis</h4>
                <p className="text-sm text-muted-foreground">
                  AI automatically analyzes architecture, dependencies, and patterns
                </p>
              </div>
              
              <div className="text-center space-y-3">
                <div className="w-16 h-16 mx-auto bg-yellow-100 dark:bg-yellow-900 rounded-full flex items-center justify-center">
                  <FileText className="h-8 w-8 text-yellow-600" />
                </div>
                <h4 className="font-semibold">3. Generate Docs</h4>
                <p className="text-sm text-muted-foreground">
                  Comprehensive documentation automatically generated with diagrams
                </p>
              </div>
              
              <div className="text-center space-y-3">
                <div className="w-16 h-16 mx-auto bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                  <Users className="h-8 w-8 text-green-600" />
                </div>
                <h4 className="font-semibold">4. Share & Collaborate</h4>
                <p className="text-sm text-muted-foreground">
                  Export PDFs and share knowledge across delivery teams
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Benefits */}
        <Card className="border-2 border-blue-200 dark:border-blue-900 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900">
            <CardTitle className="text-2xl">Key Benefits for Delivery Teams</CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-blue-600">
                  <Zap className="h-5 w-5" />
                  <h4 className="font-semibold">Time Savings</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  Eliminate 80% of manual documentation effort. Focus developers on coding instead of writing docs.
                </p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-purple-600">
                  <CheckCircle2 className="h-5 w-5" />
                  <h4 className="font-semibold">Accuracy</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  Documentation always reflects actual code. No outdated or incorrect information from manual updates.
                </p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-green-600">
                  <Users className="h-5 w-5" />
                  <h4 className="font-semibold">Knowledge Sharing</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  Standardized documentation format enables easy knowledge transfer between teams and new developers.
                </p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-yellow-600">
                  <Lock className="h-5 w-5" />
                  <h4 className="font-semibold">Compliance</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  Automatic tracking of PII/sensitive data helps teams meet GDPR, HIPAA, and PCI-DSS requirements.
                </p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-red-600">
                  <Shield className="h-5 w-5" />
                  <h4 className="font-semibold">Security</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  Automated vulnerability detection and security best practices documentation for safer code.
                </p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-indigo-600">
                  <BarChart3 className="h-5 w-5" />
                  <h4 className="font-semibold">Complete Analysis</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  Comprehensive code analysis reports with quality metrics, dependencies, and architecture documentation.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center py-6">
          <p className="text-sm text-muted-foreground">
            Powered by Code Lens - Enterprise Application Intelligence Platform
          </p>
        </div>
      </div>
    </div>
  );
}
