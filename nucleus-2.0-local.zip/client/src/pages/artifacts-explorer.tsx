/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useState, useEffect, useMemo } from "react";
import { useLocation } from "wouter";
import {
  FileCode, FolderOpen, FolderClosed, Copy, Download, ChevronLeft,
  Search, Code2, FileText, X, CheckCircle, LayoutGrid, Maximize2,
  BookOpen, Terminal, ExternalLink, Info
} from "lucide-react";

// ── Types ────────────────────────────────────────────────────────────────────

interface ParsedFile {
  id: string; nodeId: string; agentId: string; agentName: string;
  lang: string; filename: string; code: string;
}

interface AgentDoc {
  id: string; agentId: string; agentName: string;
  content: string; tokens: number;
}

interface ArtifactsPayload {
  parsedFiles: ParsedFile[];
  agentDocs: AgentDoc[];
  savedAt: string;
  projectContext?: string;
}

// ── Helpers ──────────────────────────────────────────────────────────────────

const LANG_COLOR: Record<string, string> = {
  java: "#F59E0B", typescript: "#3B82F6", tsx: "#06B6D4", javascript: "#EAB308",
  python: "#22C55E", sql: "#A855F7", yaml: "#10B981", json: "#F97316",
  hcl: "#7C3AED", bash: "#10B981", shell: "#10B981", gherkin: "#10B981",
  markdown: "#64748B", text: "#94A3B8", xml: "#EC4899", html: "#F97316",
  css: "#818CF8", dockerfile: "#06B6D4", groovy: "#F59E0B", kotlin: "#A855F7",
  "c#": "#9333EA", rust: "#EF4444",
};

const AGENT_EMOJIS: Record<string, string> = {
  A01:"🎯", A02:"🔒", A03:"📚", A04:"👤", A05:"📊", A06:"📋",
  A07:"🎨", A08:"🏗️", A09:"💻", A10:"🔄", A11:"🔍", A12:"🧪",
  A13:"🛡️", A14:"🚀", A15:"⚙️",
};

const AGENT_ACCENT: Record<string, string> = {
  A01:"#EC4899", A02:"#EF4444", A03:"#F97316", A04:"#F59E0B",
  A05:"#EAB308", A06:"#3B82F6", A07:"#8B5CF6", A08:"#10B981",
  A09:"#A855F7", A10:"#A855F7", A11:"#A855F7", A12:"#F59E0B",
  A13:"#F59E0B", A14:"#EF4444", A15:"#06B6D4",
};

function langBadgeStyle(lang: string): React.CSSProperties {
  const c = LANG_COLOR[lang] || "#94A3B8";
  return { fontSize: 9, fontFamily: "JetBrains Mono, monospace", padding: "1px 6px", borderRadius: 10,
    border: `1px solid ${c}40`, color: c, background: `${c}15`, letterSpacing: 0.5, textTransform: "uppercase" as const };
}

function lineNumbers(code: string): string[] {
  return code.split("\n").map((_, i) => String(i + 1));
}

function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text).catch(() => {});
}

function downloadFile(filename: string, content: string) {
  const blob = new Blob([content], { type: "text/plain" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
  a.download = filename; a.click(); URL.revokeObjectURL(a.href);
}

// ── Main Component ────────────────────────────────────────────────────────────

export default function ArtifactsExplorer() {
  const [, navigate] = useLocation();
  const [data, setData] = useState<ArtifactsPayload | null>(null);
  const [search, setSearch] = useState("");
  const [selectedItem, setSelectedItem] = useState<{ type: "file"; file: ParsedFile } | { type: "doc"; doc: AgentDoc } | null>(null);
  const [expandedAgents, setExpandedAgents] = useState<Record<string, boolean>>({});
  const [activeView, setActiveView] = useState<"files" | "docs" | "all">("all");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [treeWidth, setTreeWidth] = useState(280);
  const [isResizing, setIsResizing] = useState(false);

  useEffect(() => {
    const raw = sessionStorage.getItem("nucleus_artifacts");
    if (raw) {
      try {
        const parsed = JSON.parse(raw) as ArtifactsPayload;
        setData(parsed);
        // Auto-expand all agents
        const expanded: Record<string, boolean> = {};
        parsed.parsedFiles.forEach(f => { expanded[f.agentId] = true; });
        parsed.agentDocs.forEach(d => { expanded[d.agentId] = true; });
        setExpandedAgents(expanded);
        // Select first item
        if (parsed.parsedFiles.length > 0) setSelectedItem({ type: "file", file: parsed.parsedFiles[0] });
        else if (parsed.agentDocs.length > 0) setSelectedItem({ type: "doc", doc: parsed.agentDocs[0] });
      } catch { setData(null); }
    }
  }, []);

  // Group items by agent
  const grouped = useMemo(() => {
    if (!data) return {};
    const g: Record<string, { files: ParsedFile[]; docs: AgentDoc[]; agentId: string; agentName: string }> = {};
    data.parsedFiles.forEach(f => {
      if (!g[f.agentId]) g[f.agentId] = { files: [], docs: [], agentId: f.agentId, agentName: f.agentName };
      g[f.agentId].files.push(f);
    });
    data.agentDocs.forEach(d => {
      if (!g[d.agentId]) g[d.agentId] = { files: [], docs: [], agentId: d.agentId, agentName: d.agentName };
      g[d.agentId].docs.push(d);
    });
    return g;
  }, [data]);

  // Filtered for search
  const filteredGrouped = useMemo(() => {
    if (!search.trim()) return grouped;
    const q = search.toLowerCase();
    const result: typeof grouped = {};
    Object.entries(grouped).forEach(([agentId, group]) => {
      const files = group.files.filter(f =>
        f.filename.toLowerCase().includes(q) || f.code.toLowerCase().includes(q) || f.lang.toLowerCase().includes(q)
      );
      const docs = group.docs.filter(d =>
        d.content.toLowerCase().includes(q) || d.agentName.toLowerCase().includes(q)
      );
      if (files.length > 0 || docs.length > 0) {
        result[agentId] = { ...group, files, docs };
      }
    });
    return result;
  }, [grouped, search]);

  const totalFiles = data ? data.parsedFiles.length : 0;
  const totalDocs = data ? data.agentDocs.length : 0;
  const agentCount = Object.keys(grouped).length;

  const handleCopy = (id: string, text: string) => {
    copyToClipboard(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Resize handler
  const startResize = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsResizing(true);
    const startX = e.clientX;
    const startW = treeWidth;
    const onMove = (ev: MouseEvent) => {
      const newW = Math.max(180, Math.min(480, startW + ev.clientX - startX));
      setTreeWidth(newW);
    };
    const onUp = () => {
      setIsResizing(false);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  const content = selectedItem?.type === "file" ? selectedItem.file.code
    : selectedItem?.type === "doc" ? selectedItem.doc.content
    : "";
  const contentLines = content ? lineNumbers(content) : [];

  return (
    <div style={{
      display: "flex", flexDirection: "column", height: "calc(100vh - 56px)",
      background: "#0F172A", fontFamily: "'JetBrains Mono', 'Syne', monospace",
      userSelect: isResizing ? "none" : "auto"
    }}>

      {/* ── TOP BAR ────────────────────────────────────────────────────────── */}
      <div style={{
        display: "flex", alignItems: "center", gap: 12, padding: "0 16px",
        height: 42, background: "#1E293B", borderBottom: "1px solid #334155", flexShrink: 0
      }}>
        <button onClick={() => navigate("/zenseai-platform")} style={{
          display: "flex", alignItems: "center", gap: 5, background: "#334155",
          border: "1px solid #475569", borderRadius: 6, padding: "4px 10px",
          color: "#94A3B8", cursor: "pointer", fontSize: 11, fontFamily: "Syne, sans-serif"
        }}>
          <ChevronLeft size={12} /> Back to Platform
        </button>

        <div style={{ fontSize: 13, fontWeight: 700, color: "#F1F5F9", fontFamily: "Syne, sans-serif" }}>
          📦 Artifacts Explorer
        </div>
        {data?.savedAt && (
          <div style={{ fontSize: 10, color: "#475569" }}>
            Generated {new Date(data.savedAt).toLocaleTimeString()}
          </div>
        )}

        {/* Stats pills */}
        <div style={{ display: "flex", gap: 8, marginLeft: 8 }}>
          {[
            { label: `${agentCount} Agents`, color: "#A855F7" },
            { label: `${totalFiles} Code Files`, color: "#3B82F6" },
            { label: `${totalDocs} Doc Outputs`, color: "#10B981" },
          ].map(s => (
            <div key={s.label} style={{
              fontSize: 10, fontFamily: "Syne, sans-serif", padding: "2px 8px",
              borderRadius: 12, border: `1px solid ${s.color}40`,
              color: s.color, background: `${s.color}15`
            }}>{s.label}</div>
          ))}
        </div>

        {/* View toggle */}
        <div style={{ marginLeft: "auto", display: "flex", gap: 4 }}>
          {(["all","files","docs"] as const).map(v => (
            <button key={v} onClick={() => setActiveView(v)} style={{
              padding: "3px 10px", borderRadius: 5, fontSize: 10,
              background: activeView === v ? "#3B82F6" : "#334155",
              color: activeView === v ? "#fff" : "#94A3B8",
              border: `1px solid ${activeView === v ? "#3B82F6" : "#475569"}`,
              cursor: "pointer", fontFamily: "Syne, sans-serif", textTransform: "capitalize"
            }}>{v}</button>
          ))}
        </div>

        {/* Search */}
        <div style={{ display: "flex", alignItems: "center", gap: 6, background: "#334155", border: "1px solid #475569", borderRadius: 6, padding: "3px 8px" }}>
          <Search size={11} color="#64748B" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search files & content…"
            style={{ background: "transparent", border: "none", outline: "none", color: "#F1F5F9", fontSize: 11, width: 160, fontFamily: "JetBrains Mono, monospace" }} />
          {search && <button onClick={() => setSearch("")} style={{ background: "none", border: "none", cursor: "pointer", color: "#64748B", lineHeight: 1 }}><X size={10} /></button>}
        </div>
      </div>

      {/* ── BODY ───────────────────────────────────────────────────────────── */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>

        {/* LEFT TREE */}
        <div style={{ width: treeWidth, background: "#1E293B", borderRight: "1px solid #334155", display: "flex", flexDirection: "column", flexShrink: 0, overflow: "hidden" }}>
          <div style={{ padding: "10px 12px 6px", fontSize: 9, fontWeight: 700, color: "#475569", letterSpacing: 1, textTransform: "uppercase", borderBottom: "1px solid #334155" }}>
            Explorer
          </div>
          <div style={{ flex: 1, overflowY: "auto" }}>
            {!data ? (
              <div style={{ padding: 20, textAlign: "center", color: "#475569", fontSize: 11 }}>
                <Info size={20} style={{ margin: "0 auto 8px", display: "block", opacity: 0.5 }} />
                No artifacts loaded.<br />Run a demo flow first.
              </div>
            ) : Object.keys(filteredGrouped).length === 0 ? (
              <div style={{ padding: 20, textAlign: "center", color: "#475569", fontSize: 11 }}>No results for "{search}"</div>
            ) : (
              Object.entries(filteredGrouped)
                .sort(([a], [b]) => a.localeCompare(b))
                .map(([agentId, group]) => {
                  const isOpen = expandedAgents[agentId] !== false;
                  const accent = AGENT_ACCENT[agentId] || "#3B82F6";
                  const emoji = AGENT_EMOJIS[agentId] || "🤖";
                  const showFiles = activeView !== "docs";
                  const showDocs = activeView !== "files";
                  return (
                    <div key={agentId}>
                      {/* Agent folder */}
                      <div onClick={() => setExpandedAgents(p => ({ ...p, [agentId]: !isOpen }))}
                        style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 10px", cursor: "pointer",
                          borderLeft: `3px solid ${accent}`, background: isOpen ? `${accent}10` : "transparent" }}
                        onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.background = `${accent}18`; }}
                        onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.background = isOpen ? `${accent}10` : "transparent"; }}
                      >
                        <span style={{ fontSize: 13 }}>{emoji}</span>
                        {isOpen
                          ? <FolderOpen size={11} style={{ color: accent }} />
                          : <FolderClosed size={11} style={{ color: accent }} />}
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 10, fontWeight: 700, color: "#E2E8F0", fontFamily: "Syne, sans-serif", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                            {group.agentName}
                          </div>
                          <div style={{ fontSize: 8, color: "#475569", fontFamily: "JetBrains Mono, monospace" }}>{agentId}</div>
                        </div>
                        <div style={{ fontSize: 9, color: "#475569" }}>
                          {group.files.length + group.docs.length}
                        </div>
                      </div>

                      {isOpen && (
                        <>
                          {/* Code Files */}
                          {showFiles && group.files.map(f => {
                            const isSelected = selectedItem?.type === "file" && selectedItem.file.id === f.id;
                            const lc = LANG_COLOR[f.lang] || "#94A3B8";
                            return (
                              <div key={f.id} onClick={() => setSelectedItem({ type: "file", file: f })}
                                style={{ display: "flex", alignItems: "center", gap: 5, padding: "4px 10px 4px 28px", cursor: "pointer",
                                  background: isSelected ? "#1E3A5F" : "transparent",
                                  borderLeft: isSelected ? `2px solid ${lc}` : "2px solid transparent" }}
                                onMouseEnter={e => { if (!isSelected) (e.currentTarget as HTMLDivElement).style.background = "#253347"; }}
                                onMouseLeave={e => { if (!isSelected) (e.currentTarget as HTMLDivElement).style.background = "transparent"; }}
                              >
                                <FileCode size={10} style={{ color: lc, flexShrink: 0 }} />
                                <span style={{ fontSize: 9.5, color: isSelected ? "#F1F5F9" : "#94A3B8", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1 }}>
                                  {f.filename}
                                </span>
                                <span style={langBadgeStyle(f.lang)}>{f.lang}</span>
                              </div>
                            );
                          })}

                          {/* Doc Outputs */}
                          {showDocs && group.docs.map(d => {
                            const isSelected = selectedItem?.type === "doc" && selectedItem.doc.id === d.id;
                            return (
                              <div key={d.id} onClick={() => setSelectedItem({ type: "doc", doc: d })}
                                style={{ display: "flex", alignItems: "center", gap: 5, padding: "4px 10px 4px 28px", cursor: "pointer",
                                  background: isSelected ? "#1A3A2F" : "transparent",
                                  borderLeft: isSelected ? "2px solid #10B981" : "2px solid transparent" }}
                                onMouseEnter={e => { if (!isSelected) (e.currentTarget as HTMLDivElement).style.background = "#253347"; }}
                                onMouseLeave={e => { if (!isSelected) (e.currentTarget as HTMLDivElement).style.background = "transparent"; }}
                              >
                                <FileText size={10} style={{ color: "#10B981", flexShrink: 0 }} />
                                <span style={{ fontSize: 9.5, color: isSelected ? "#F1F5F9" : "#94A3B8", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1 }}>
                                  {d.agentName} — Output
                                </span>
                                <span style={{ fontSize: 8, color: "#10B981", background: "#10B98115", border: "1px solid #10B98140", padding: "1px 5px", borderRadius: 8 }}>md</span>
                              </div>
                            );
                          })}
                        </>
                      )}
                    </div>
                  );
                })
            )}
          </div>
        </div>

        {/* Resize handle */}
        <div onMouseDown={startResize} style={{
          width: 4, cursor: "col-resize", background: "#334155", flexShrink: 0,
          transition: "background 0.15s"
        }}
          onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.background = "#3B82F6"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.background = "#334155"; }}
        />

        {/* MAIN CONTENT */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>

          {selectedItem ? (
            <>
              {/* Tab bar */}
              <div style={{
                display: "flex", alignItems: "center", gap: 0,
                background: "#1E293B", borderBottom: "1px solid #334155", flexShrink: 0, overflowX: "auto"
              }}>
                <div style={{
                  display: "flex", alignItems: "center", gap: 6, padding: "7px 14px",
                  background: "#0F172A", borderBottom: "2px solid #3B82F6",
                  borderRight: "1px solid #334155", minWidth: 0, maxWidth: 300
                }}>
                  {selectedItem.type === "file"
                    ? <FileCode size={11} style={{ color: LANG_COLOR[selectedItem.file.lang] || "#94A3B8", flexShrink: 0 }} />
                    : <FileText size={11} style={{ color: "#10B981", flexShrink: 0 }} />}
                  <span style={{ fontSize: 11, color: "#F1F5F9", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {selectedItem.type === "file" ? selectedItem.file.filename : `${selectedItem.doc.agentName} — Full Output`}
                  </span>
                  {selectedItem.type === "file" && (
                    <span style={langBadgeStyle(selectedItem.file.lang)}>{selectedItem.file.lang}</span>
                  )}
                </div>
              </div>

              {/* Toolbar */}
              <div style={{
                display: "flex", alignItems: "center", gap: 8, padding: "5px 14px",
                background: "#1A2235", borderBottom: "1px solid #334155", flexShrink: 0
              }}>
                {selectedItem.type === "file" && (
                  <div style={{ fontSize: 10, color: "#475569", fontFamily: "JetBrains Mono, monospace" }}>
                    from <span style={{ color: "#94A3B8" }}>{selectedItem.file.agentName}</span>
                    <span style={{ color: "#475569", margin: "0 6px" }}>·</span>
                    {selectedItem.file.code.split("\n").length} lines
                    <span style={{ color: "#475569", margin: "0 6px" }}>·</span>
                    {selectedItem.file.code.length.toLocaleString()} chars
                  </div>
                )}
                {selectedItem.type === "doc" && (
                  <div style={{ fontSize: 10, color: "#475569", fontFamily: "JetBrains Mono, monospace" }}>
                    <span style={{ color: "#94A3B8" }}>Agent Output — {selectedItem.doc.agentId}</span>
                    <span style={{ color: "#475569", margin: "0 6px" }}>·</span>
                    {selectedItem.doc.content.split("\n").length} lines
                    <span style={{ color: "#475569", margin: "0 6px" }}>·</span>
                    {selectedItem.doc.tokens ? `${selectedItem.doc.tokens} tokens` : `${selectedItem.doc.content.length.toLocaleString()} chars`}
                  </div>
                )}
                <div style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
                  <button onClick={() => handleCopy(selectedItem.type === "file" ? selectedItem.file.id : selectedItem.doc.id, content)}
                    style={{ display: "flex", alignItems: "center", gap: 4, padding: "3px 9px", borderRadius: 5,
                      background: copiedId === (selectedItem.type === "file" ? selectedItem.file.id : selectedItem.doc.id) ? "#065F46" : "#334155",
                      border: "1px solid #475569", color: "#94A3B8", cursor: "pointer", fontSize: 10, fontFamily: "Syne, sans-serif" }}>
                    {copiedId === (selectedItem.type === "file" ? selectedItem.file.id : selectedItem.doc.id)
                      ? <><CheckCircle size={10} style={{ color: "#10B981" }} /> Copied!</>
                      : <><Copy size={10} /> Copy</>}
                  </button>
                  <button onClick={() => downloadFile(
                    selectedItem.type === "file" ? selectedItem.file.filename : `${selectedItem.doc.agentId}_output.md`,
                    content
                  )} style={{ display: "flex", alignItems: "center", gap: 4, padding: "3px 9px", borderRadius: 5,
                    background: "#334155", border: "1px solid #475569", color: "#94A3B8", cursor: "pointer", fontSize: 10, fontFamily: "Syne, sans-serif" }}>
                    <Download size={10} /> Download
                  </button>
                </div>
              </div>

              {/* Code / Doc view */}
              <div style={{ flex: 1, overflow: "auto", display: "flex" }}>
                {/* Line numbers */}
                <div style={{
                  minWidth: 48, background: "#141E2E", padding: "14px 8px",
                  textAlign: "right", userSelect: "none", flexShrink: 0, borderRight: "1px solid #1E293B"
                }}>
                  {contentLines.map(n => (
                    <div key={n} style={{ fontSize: 11, lineHeight: "1.6em", color: "#334155", fontFamily: "JetBrains Mono, monospace" }}>{n}</div>
                  ))}
                </div>
                {/* Content */}
                <div style={{ flex: 1, padding: "14px 20px", overflow: "auto" }}>
                  <pre style={{
                    margin: 0, fontSize: 12.5, fontFamily: "JetBrains Mono, monospace",
                    color: "#E2E8F0", lineHeight: "1.6em", whiteSpace: "pre-wrap",
                    wordBreak: "break-word"
                  }}>
                    {content}
                  </pre>
                </div>
              </div>
            </>
          ) : (
            /* Empty state */
            <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#334155" }}>
              {!data ? (
                <>
                  <Terminal size={48} style={{ marginBottom: 16, opacity: 0.4 }} />
                  <div style={{ fontSize: 16, fontWeight: 700, color: "#475569", fontFamily: "Syne, sans-serif", marginBottom: 8 }}>No Artifacts Found</div>
                  <div style={{ fontSize: 12, color: "#334155", maxWidth: 340, textAlign: "center", lineHeight: 1.6, marginBottom: 20 }}>
                    Go to the Nucleus 2.0 platform, load the demo, run agents, then click <strong style={{ color: "#94A3B8" }}>Open Full Explorer</strong> to see all generated artifacts here.
                  </div>
                  <button onClick={() => navigate("/zenseai-platform")} style={{
                    display: "flex", alignItems: "center", gap: 6, padding: "8px 18px",
                    background: "#3B82F6", border: "none", borderRadius: 8,
                    color: "#fff", cursor: "pointer", fontSize: 12, fontFamily: "Syne, sans-serif", fontWeight: 700
                  }}>
                    <ExternalLink size={13} /> Go to Platform
                  </button>
                </>
              ) : (
                <>
                  <LayoutGrid size={36} style={{ marginBottom: 12, opacity: 0.3 }} />
                  <div style={{ fontSize: 13, color: "#475569", fontFamily: "Syne, sans-serif" }}>Select a file or document from the tree</div>
                </>
              )}
            </div>
          )}
        </div>

        {/* RIGHT SUMMARY PANEL */}
        {selectedItem && (
          <div style={{ width: 220, background: "#1E293B", borderLeft: "1px solid #334155", flexShrink: 0, overflowY: "auto" }}>
            <div style={{ padding: "10px 12px 6px", fontSize: 9, fontWeight: 700, color: "#475569", letterSpacing: 1, textTransform: "uppercase", borderBottom: "1px solid #334155" }}>
              Details
            </div>
            <div style={{ padding: 12, display: "flex", flexDirection: "column", gap: 10 }}>

              {selectedItem.type === "file" ? (
                <>
                  <DetailRow label="File" value={selectedItem.file.filename} mono />
                  <DetailRow label="Language" value={selectedItem.file.lang} accent={LANG_COLOR[selectedItem.file.lang]} />
                  <DetailRow label="Agent" value={`${selectedItem.file.agentId} — ${selectedItem.file.agentName}`} />
                  <DetailRow label="Lines" value={String(selectedItem.file.code.split("\n").length)} />
                  <DetailRow label="Size" value={`${selectedItem.file.code.length.toLocaleString()} chars`} />
                </>
              ) : (
                <>
                  <DetailRow label="Agent" value={`${selectedItem.doc.agentId} — ${selectedItem.doc.agentName}`} />
                  <DetailRow label="Type" value="Markdown Output" accent="#10B981" />
                  <DetailRow label="Lines" value={String(selectedItem.doc.content.split("\n").length)} />
                  {selectedItem.doc.tokens > 0 && <DetailRow label="Tokens" value={String(selectedItem.doc.tokens)} />}
                  <DetailRow label="Size" value={`${selectedItem.doc.content.length.toLocaleString()} chars`} />
                </>
              )}

              <div style={{ borderTop: "1px solid #334155", paddingTop: 10 }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: "#475569", letterSpacing: 1, marginBottom: 6, textTransform: "uppercase" }}>Project Stats</div>
                {[
                  { label: "Code Files", value: totalFiles, color: "#3B82F6" },
                  { label: "Doc Outputs", value: totalDocs, color: "#10B981" },
                  { label: "Agents Run", value: agentCount, color: "#A855F7" },
                ].map(s => (
                  <div key={s.label} style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                    <span style={{ fontSize: 10, color: "#64748B" }}>{s.label}</span>
                    <span style={{ fontSize: 10, color: s.color, fontWeight: 700 }}>{s.value}</span>
                  </div>
                ))}
              </div>

              {data?.projectContext && (
                <div style={{ borderTop: "1px solid #334155", paddingTop: 10 }}>
                  <div style={{ fontSize: 9, fontWeight: 700, color: "#475569", letterSpacing: 1, marginBottom: 6, textTransform: "uppercase" }}>Project Context</div>
                  <div style={{ fontSize: 9.5, color: "#64748B", lineHeight: 1.5, wordBreak: "break-word" }}>
                    {data.projectContext.substring(0, 180)}{data.projectContext.length > 180 ? "…" : ""}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #1E293B; }
        ::-webkit-scrollbar-thumb { background: #334155; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #475569; }
      `}</style>
    </div>
  );
}

function DetailRow({ label, value, mono, accent }: { label: string; value: string; mono?: boolean; accent?: string }) {
  return (
    <div>
      <div style={{ fontSize: 9, fontWeight: 700, color: "#475569", letterSpacing: 0.8, textTransform: "uppercase", marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 10, color: accent || (mono ? "#A5B4FC" : "#94A3B8"), fontFamily: mono ? "JetBrains Mono, monospace" : "Syne, sans-serif", wordBreak: "break-word" }}>
        {value}
      </div>
    </div>
  );
}
