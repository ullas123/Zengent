/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { useState, useCallback, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import JSZip from "jszip";
import ReactFlow, {
  ReactFlowProvider, useNodesState, useEdgesState, addEdge,
  MiniMap, Controls, Background, BackgroundVariant,
  type Connection, type Edge, type Node, type NodeTypes,
  Handle, Position, MarkerType, Panel
} from "reactflow";
import "reactflow/dist/style.css";
import { AGENT_DEFINITIONS, AGENT_DOMAINS, OUTPUT_FORMATS, RESOURCE_TYPES, getAgentById } from "@/data/zenseai-agents";
import { DEMO_OUTPUTS, DEMO_CRITERIA, DEMO_FLOW_LAYOUT, DEMO_EDGES, DEMO_PROJECT_CONTEXT, DEMO_BEFORE_CODE, DEMO_AFTER_CODE } from "@/data/zenseai-demo";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Play, Save, Upload, Trash2, LayoutGrid, CheckCircle,
  Search, Bot, Settings, Sparkles, FolderOpen, FileCode,
  FolderClosed, ChevronRight, X, GripVertical, PanelBottomOpen,
  Copy, BookOpen, Info, Download, Github, Code2, Sun, Moon
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

interface NodeConfig {
  label: string;
  priority: string;
  systemPrompt: string;
  additionalInstructions: string;
  temperature: number;
  maxTokens: number;
  contextWindow: string;
  criteria: string[];
  dod: string;
  constraints: string;
  outputFormats: string[];
  outputSchema: string;
  responseLanguage: string;
  downstreamRouting: string;
  failureHandling: string;
  knowledgeLinks: { url: string; label: string; type: string }[];
  ragContext: string;
  activityLog: { ts: string; status: "success"|"running"|"error"|"info"; message: string; preview?: string }[];
  status: "idle"|"running"|"success"|"error";
  lastOutput: string;
}

const defaultConfig = (agentId: string): NodeConfig => {
  const def = getAgentById(agentId);
  return {
    label: def?.name || agentId,
    priority: "Medium",
    systemPrompt: def?.defaultPrompt || "",
    additionalInstructions: "",
    temperature: 0.7,
    maxTokens: 1500,
    contextWindow: "8K",
    criteria: def?.defaultCriteria || [],
    dod: "",
    constraints: "",
    outputFormats: ["markdown"],
    outputSchema: "",
    responseLanguage: "English",
    downstreamRouting: "Next node",
    failureHandling: "Retry then escalate",
    knowledgeLinks: [],
    ragContext: "",
    activityLog: [],
    status: "idle",
    lastOutput: ""
  };
};

// ─── Agent node status styles (injected once) ─────────────────────────────────
if (typeof document !== "undefined" && !document.getElementById("nucleus-node-styles")) {
  const s = document.createElement("style");
  s.id = "nucleus-node-styles";
  s.textContent = `
    @keyframes nucleus-pulse-ring {
      0%   { box-shadow: 0 0 0 0 rgba(245,158,11,0.7), 0 0 0 0 rgba(245,158,11,0.4); }
      50%  { box-shadow: 0 0 0 8px rgba(245,158,11,0.2), 0 0 0 16px rgba(245,158,11,0.05); }
      100% { box-shadow: 0 0 0 0 rgba(245,158,11,0), 0 0 0 0 rgba(245,158,11,0); }
    }
    @keyframes nucleus-spin {
      from { transform: rotate(0deg); }
      to   { transform: rotate(360deg); }
    }
    @keyframes nucleus-bg-breathe {
      0%, 100% { background-color: rgba(254,243,199,0.6); }
      50%       { background-color: rgba(253,230,138,0.9); }
    }
    @keyframes nucleus-success-flash {
      0%   { box-shadow: 0 0 0 0 rgba(16,185,129,0.6); }
      60%  { box-shadow: 0 0 0 10px rgba(16,185,129,0); }
      100% { box-shadow: 0 0 0 0 rgba(16,185,129,0); }
    }
    @keyframes nucleus-dot-blink {
      0%, 100% { opacity: 1; }
      50%       { opacity: 0.3; }
    }
    .nucleus-node-running {
      animation: nucleus-pulse-ring 1.4s ease-out infinite, nucleus-bg-breathe 1.4s ease-in-out infinite !important;
    }
    .nucleus-node-success {
      animation: nucleus-success-flash 0.6s ease-out 1 !important;
    }
    .nucleus-spinner {
      width: 12px; height: 12px; border-radius: 50%;
      border: 2px solid rgba(245,158,11,0.25);
      border-top-color: #F59E0B;
      animation: nucleus-spin 0.7s linear infinite;
      flex-shrink: 0;
    }
    .nucleus-dot-running {
      animation: nucleus-dot-blink 0.8s ease-in-out infinite !important;
    }
  `;
  document.head.appendChild(s);
}

// ─── Custom Agent Node ────────────────────────────────────────────────────────

function AgentNode({ data, selected }: { data: any; selected: boolean }) {
  const def = getAgentById(data.agentId);
  const cfg: NodeConfig = data.config;
  const st = cfg.status;

  const statusColor = { idle: "#94A3B8", running: "#F59E0B", success: "#10B981", error: "#EF4444" }[st] || "#94A3B8";

  const accentColor = st === "running" ? "#F59E0B" : st === "success" ? "#10B981" : st === "error" ? "#EF4444" : (def?.accent || "#3B82F6");

  // Per-status node styles — no shorthand border mixing
  const nodeStyleByStatus: Record<string, React.CSSProperties> = {
    idle: {
      background: "#FFFFFF",
      borderTopWidth: 1.5, borderRightWidth: 1.5, borderBottomWidth: 1.5, borderLeftWidth: 4,
      borderStyle: "solid",
      borderTopColor: selected ? "#3B82F6" : (def?.border || "#E2E8F0"),
      borderRightColor: selected ? "#3B82F6" : (def?.border || "#E2E8F0"),
      borderBottomColor: selected ? "#3B82F6" : (def?.border || "#E2E8F0"),
      borderLeftColor: def?.accent || "#3B82F6",
      boxShadow: selected
        ? "0 0 0 2px rgba(59,130,246,0.3), 0 4px 20px rgba(59,130,246,0.15)"
        : "0 2px 8px rgba(0,0,0,0.06)",
    },
    running: {
      background: "rgba(254,243,199,0.7)",
      borderTopWidth: 2, borderRightWidth: 2, borderBottomWidth: 2, borderLeftWidth: 4,
      borderStyle: "solid",
      borderTopColor: "#F59E0B", borderRightColor: "#F59E0B", borderBottomColor: "#F59E0B",
      borderLeftColor: "#D97706",
      boxShadow: "0 0 0 3px rgba(245,158,11,0.25), 0 4px 20px rgba(245,158,11,0.2)",
    },
    success: {
      background: "rgba(240,253,244,1)",
      borderTopWidth: 2, borderRightWidth: 2, borderBottomWidth: 2, borderLeftWidth: 4,
      borderStyle: "solid",
      borderTopColor: "#10B981", borderRightColor: "#10B981", borderBottomColor: "#10B981",
      borderLeftColor: "#059669",
      boxShadow: "0 0 0 2px rgba(16,185,129,0.2), 0 4px 12px rgba(16,185,129,0.15)",
    },
    error: {
      background: "rgba(254,242,242,1)",
      borderTopWidth: 2, borderRightWidth: 2, borderBottomWidth: 2, borderLeftWidth: 4,
      borderStyle: "solid",
      borderTopColor: "#EF4444", borderRightColor: "#EF4444", borderBottomColor: "#EF4444",
      borderLeftColor: "#DC2626",
      boxShadow: "0 0 0 2px rgba(239,68,68,0.2), 0 4px 12px rgba(239,68,68,0.15)",
    },
  };

  const statusLabel: Record<string, string> = {
    idle: "READY",
    running: "⚡ EXECUTING",
    success: "✓ DONE",
    error: "✗ ERROR",
  };

  const statusLabelColor: Record<string, string> = {
    idle: "#94A3B8",
    running: "#D97706",
    success: "#059669",
    error: "#DC2626",
  };

  return (
    <div
      className={st === "running" ? "nucleus-node-running" : st === "success" ? "nucleus-node-success" : ""}
      style={{
        ...(nodeStyleByStatus[st] || nodeStyleByStatus.idle),
        borderRadius: 10, minWidth: 185, padding: "10px 12px", position: "relative",
        fontFamily: "'Syne', sans-serif", transition: "background 0.3s, box-shadow 0.3s",
      }}>

      <Handle type="target" position={Position.Left} style={{ background: def?.border || "#3B82F6", width: 10, height: 10 }} />

      {/* Header row */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 5 }}>
        <span style={{
          fontSize: 20,
          filter: st === "running" ? "drop-shadow(0 0 4px #F59E0B)" : "none",
          transition: "filter 0.3s",
        }}>{def?.emoji}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#0F172A", letterSpacing: 0.3, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{cfg.label}</div>
          <div style={{ fontSize: 9, color: "#64748B", fontFamily: "JetBrains Mono, monospace" }}>{data.agentId}</div>
        </div>

        {/* Status indicator — spinner when running, dot otherwise */}
        {st === "running" ? (
          <div className="nucleus-spinner" />
        ) : (
          <div className={st === "running" ? "nucleus-dot-running" : ""} style={{
            width: 8, height: 8, borderRadius: "50%",
            background: statusColor,
            boxShadow: `0 0 ${st === "success" ? "8px" : "4px"} ${statusColor}`,
            transition: "background 0.3s, box-shadow 0.3s",
          }} />
        )}
      </div>

      {/* Domain tag */}
      <div style={{ fontSize: 9, color: def?.accent || "#3B82F6", fontWeight: 700, marginBottom: 5, letterSpacing: 0.5 }}>
        {def?.domain?.toUpperCase()}
      </div>

      {/* Status label pill */}
      <div style={{
        display: "inline-flex", alignItems: "center", gap: 4,
        fontSize: 8, fontWeight: 800, letterSpacing: 0.6,
        color: statusLabelColor[st] || "#94A3B8",
        background: st === "running" ? "rgba(245,158,11,0.12)"
          : st === "success" ? "rgba(16,185,129,0.10)"
          : st === "error" ? "rgba(239,68,68,0.10)"
          : "rgba(148,163,184,0.1)",
        border: `1px solid ${
          st === "running" ? "rgba(245,158,11,0.3)"
          : st === "success" ? "rgba(16,185,129,0.25)"
          : st === "error" ? "rgba(239,68,68,0.25)"
          : "rgba(148,163,184,0.2)"}`,
        padding: "2px 6px", borderRadius: 4, marginBottom: 4,
      }}>
        {statusLabel[st] || "READY"}
      </div>

      {/* Running progress bar */}
      {st === "running" && (
        <div style={{ height: 2, background: "rgba(245,158,11,0.15)", borderRadius: 1, overflow: "hidden", marginBottom: 4 }}>
          <div style={{
            height: "100%", width: "40%", borderRadius: 1,
            background: "linear-gradient(90deg, transparent, #F59E0B, transparent)",
            backgroundSize: "200% 100%",
          }} />
        </div>
      )}

      {/* Chips row */}
      <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
        {cfg.criteria.length > 0 && (
          <span style={{ fontSize: 8, background: "#E2E8F0", color: "#64748B", padding: "1px 5px", borderRadius: 4 }}>
            ✓ {cfg.criteria.length}
          </span>
        )}
        {cfg.knowledgeLinks.length > 0 && (
          <span style={{ fontSize: 8, background: "#E2E8F0", color: "#64748B", padding: "1px 5px", borderRadius: 4 }}>
            🔗 {cfg.knowledgeLinks.length}
          </span>
        )}
        {cfg.activityLog.length > 0 && (
          <span style={{ fontSize: 8, background: "#E2E8F0", color: "#64748B", padding: "1px 5px", borderRadius: 4 }}>
            📋 {cfg.activityLog.length}
          </span>
        )}
      </div>

      <Handle type="source" position={Position.Right} style={{ background: def?.border || "#3B82F6", width: 10, height: 10 }} />
    </div>
  );
}

const nodeTypes: NodeTypes = { agentNode: AgentNode };

// ─── Inspector ────────────────────────────────────────────────────────────────

function Inspector({
  nodeId, config, agentId, onUpdate, onRun, onDelete, isRunning
}: {
  nodeId: string; config: NodeConfig; agentId: string;
  onUpdate: (cfg: NodeConfig) => void;
  onRun: () => void; onDelete: () => void; isRunning: boolean;
}) {
  const [tab, setTab] = useState("identity");
  const [newCriterion, setNewCriterion] = useState("");
  const [newLinkUrl, setNewLinkUrl] = useState("");
  const [newLinkLabel, setNewLinkLabel] = useState("");
  const [newLinkType, setNewLinkType] = useState("Confluence page");
  const def = getAgentById(agentId);

  const upd = (partial: Partial<NodeConfig>) => onUpdate({ ...config, ...partial });
  const TABS = ["identity", "prompt", "criteria", "output", "resources", "activity"];
  const TAB_LABELS = ["Identity", "Prompt", "Criteria", "Output", "Resources", "Activity"];

  const statusColors: Record<string, string> = { success: "#10B981", running: "#F59E0B", error: "#EF4444", info: "#06B6D4" };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#FFFFFF", overflow: "hidden" }}>
      {/* Tab headers */}
      <div style={{ display: "flex", borderBottom: "1px solid #E2E8F0", flexShrink: 0 }}>
        {TABS.map((t, i) => (
          <button key={t} onClick={() => setTab(t)} style={{
            flex: 1, padding: "8px 4px", fontSize: 9, fontWeight: 700,
            color: tab === t ? "#3B82F6" : "#64748B",
            borderBottom: tab === t ? "2px solid #3B82F6" : "2px solid transparent",
            background: "transparent", border: "none", cursor: "pointer",
            fontFamily: "Syne, sans-serif", letterSpacing: 0.5, textTransform: "uppercase"
          }}>{TAB_LABELS[i]}</button>
        ))}
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: 12 }}>

        {/* TAB 1: Identity */}
        {tab === "identity" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <Field label="Agent ID"><div style={{ fontFamily: "JetBrains Mono, monospace", color: def?.accent || "#3B82F6", fontSize: 13, fontWeight: 700 }}>{agentId} — {def?.name}</div></Field>
            <Field label="Display Label">
              <input value={config.label} onChange={e => upd({ label: e.target.value })} style={inputSt} />
            </Field>
            <Field label="Priority">
              <select value={config.priority} onChange={e => upd({ priority: e.target.value })} style={inputSt}>
                {["Low","Medium","High","Critical"].map(p => <option key={p}>{p}</option>)}
              </select>
            </Field>
            <Field label="Domain"><div style={{ color: def?.accent, fontSize: 12 }}>{def?.domain}</div></Field>
            <Field label="Wave"><Badge style={{ background: def?.bg, color: def?.accent, border: `1px solid ${def?.border}` }}>Wave {def?.wave}</Badge></Field>
            <Field label="Key Outputs"><div style={{ fontSize: 11, color: "#64748B" }}>{def?.keyOutputs}</div></Field>
            <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
              <button onClick={onRun} disabled={isRunning} style={{
                flex: 1, padding: "8px 0", background: isRunning ? "#E2E8F0" : "#10B981",
                color: "#fff", border: "none", borderRadius: 6, cursor: isRunning ? "not-allowed" : "pointer",
                fontWeight: 700, fontSize: 12, fontFamily: "Syne, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 6
              }}>
                {isRunning ? <><span style={{ animation: "spin 1s linear infinite", display: "inline-block" }}>⟳</span> Running…</> : <><Play size={12} /> Run Agent</>}
              </button>
              <button onClick={onDelete} style={{
                padding: "8px 12px", background: "#FEF2F2", color: "#EF4444",
                border: "1px solid #EF4444", borderRadius: 6, cursor: "pointer", fontSize: 12
              }}><Trash2 size={12} /></button>
            </div>
          </div>
        )}

        {/* TAB 2: Prompt */}
        {tab === "prompt" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <Field label="System Prompt">
              <textarea value={config.systemPrompt} onChange={e => upd({ systemPrompt: e.target.value })}
                rows={8} style={{ ...inputSt, resize: "vertical", fontFamily: "JetBrains Mono, monospace", fontSize: 11 }} />
            </Field>
            <Field label="Additional Instructions (project context)">
              <textarea value={config.additionalInstructions} onChange={e => upd({ additionalInstructions: e.target.value })}
                rows={4} placeholder="e.g. Tech stack: React + Node.js. Target: AWS EKS. Branching: GitFlow"
                style={{ ...inputSt, resize: "vertical", fontSize: 11 }} />
            </Field>
            <Field label={`Temperature: ${config.temperature.toFixed(1)}`}>
              <input type="range" min={0} max={1} step={0.1} value={config.temperature}
                onChange={e => upd({ temperature: parseFloat(e.target.value) })} style={{ width: "100%", accentColor: "#3B82F6" }} />
            </Field>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              <Field label="Max Tokens">
                <input type="number" value={config.maxTokens} onChange={e => upd({ maxTokens: parseInt(e.target.value) || 1000 })} style={inputSt} />
              </Field>
              <Field label="Context Window">
                <select value={config.contextWindow} onChange={e => upd({ contextWindow: e.target.value })} style={inputSt}>
                  {["2K","4K","8K","16K","32K","64K","128K"].map(c => <option key={c}>{c}</option>)}
                </select>
              </Field>
            </div>
          </div>
        )}

        {/* TAB 3: Criteria */}
        {tab === "criteria" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <div style={{ fontSize: 10, color: "#64748B", fontWeight: 700, letterSpacing: 1, marginBottom: 4 }}>ACCEPTANCE CRITERIA ({config.criteria.length})</div>
            {config.criteria.map((c, i) => (
              <div key={i} style={{ display: "flex", gap: 6, alignItems: "flex-start", background: "#F1F5F9", borderRadius: 6, padding: "6px 8px" }}>
                <span style={{ color: "#10B981", fontSize: 10, marginTop: 2 }}>✓</span>
                <span style={{ flex: 1, fontSize: 11, color: "#1E293B" }}>{c}</span>
                <button onClick={() => upd({ criteria: config.criteria.filter((_, j) => j !== i) })}
                  style={{ background: "none", border: "none", color: "#EF4444", cursor: "pointer", fontSize: 14, lineHeight: 1 }}>✕</button>
              </div>
            ))}
            <div style={{ display: "flex", gap: 6 }}>
              <input value={newCriterion} onChange={e => setNewCriterion(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter" && newCriterion.trim()) { upd({ criteria: [...config.criteria, newCriterion.trim()] }); setNewCriterion(""); }}}
                placeholder="Add acceptance criterion…" style={{ ...inputSt, flex: 1 }} />
              <button onClick={() => { if (newCriterion.trim()) { upd({ criteria: [...config.criteria, newCriterion.trim()] }); setNewCriterion(""); }}}
                style={{ padding: "6px 10px", background: "#3B82F6", color: "#fff", border: "none", borderRadius: 6, cursor: "pointer", fontSize: 12 }}>+</button>
            </div>
            <Field label="Definition of Done">
              <textarea value={config.dod} onChange={e => upd({ dod: e.target.value })} rows={3}
                placeholder="What does 'done' look like for this agent's output?" style={{ ...inputSt, resize: "vertical", fontSize: 11 }} />
            </Field>
            <Field label="Constraints (what the agent must NOT do)">
              <textarea value={config.constraints} onChange={e => upd({ constraints: e.target.value })} rows={3}
                placeholder="e.g. Do not generate infrastructure code. Do not include real credentials." style={{ ...inputSt, resize: "vertical", fontSize: 11 }} />
            </Field>
          </div>
        )}

        {/* TAB 4: Output */}
        {tab === "output" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <Field label="Output Formats">
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {OUTPUT_FORMATS.map(f => (
                  <button key={f} onClick={() => {
                    const cur = config.outputFormats;
                    upd({ outputFormats: cur.includes(f) ? cur.filter(x => x !== f) : [...cur, f] });
                  }} style={{
                    padding: "4px 10px", borderRadius: 20, fontSize: 11, cursor: "pointer",
                    background: config.outputFormats.includes(f) ? "#3B82F6" : "#F1F5F9",
                    color: config.outputFormats.includes(f) ? "#fff" : "#64748B",
                    border: `1px solid ${config.outputFormats.includes(f) ? "#3B82F6" : "#E2E8F0"}`
                  }}>{f}</button>
                ))}
              </div>
            </Field>
            <Field label="Output Schema (JSON/YAML structure)">
              <textarea value={config.outputSchema} onChange={e => upd({ outputSchema: e.target.value })} rows={5}
                placeholder='{"stories": [], "epics": [], "nfrs": []}'
                style={{ ...inputSt, resize: "vertical", fontFamily: "JetBrains Mono, monospace", fontSize: 11 }} />
            </Field>
            <Field label="Response Language">
              <select value={config.responseLanguage} onChange={e => upd({ responseLanguage: e.target.value })} style={inputSt}>
                {["English","Hindi","Tamil","Spanish","French","German","Japanese","Chinese","Arabic"].map(l => <option key={l}>{l}</option>)}
              </select>
            </Field>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              <Field label="Downstream Routing">
                <select value={config.downstreamRouting} onChange={e => upd({ downstreamRouting: e.target.value })} style={inputSt}>
                  {["Next node","All nodes","Conditional","Human review first"].map(v => <option key={v}>{v}</option>)}
                </select>
              </Field>
              <Field label="Failure Handling">
                <select value={config.failureHandling} onChange={e => upd({ failureHandling: e.target.value })} style={inputSt}>
                  {["Retry then escalate","Skip and continue","Stop flow","Route to guardrail"].map(v => <option key={v}>{v}</option>)}
                </select>
              </Field>
            </div>
            {config.lastOutput && (
              <Field label="Last Output Preview">
                <div style={{ background: "#F1F5F9", borderRadius: 6, padding: 8, fontSize: 10, color: "#64748B", fontFamily: "JetBrains Mono, monospace", maxHeight: 120, overflowY: "auto", whiteSpace: "pre-wrap" }}>
                  {config.lastOutput.substring(0, 500)}{config.lastOutput.length > 500 ? "…" : ""}
                </div>
              </Field>
            )}
          </div>
        )}

        {/* TAB 5: Resources */}
        {tab === "resources" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <Field label="Knowledge Links">
              <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 8 }}>
                {config.knowledgeLinks.map((l, i) => (
                  <div key={i} style={{ display: "flex", gap: 6, alignItems: "center", background: "#F1F5F9", borderRadius: 6, padding: "5px 8px" }}>
                    <span style={{ fontSize: 9, color: "#3B82F6", fontWeight: 700 }}>{l.type}</span>
                    <span style={{ flex: 1, fontSize: 11, color: "#1E293B", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{l.label || l.url}</span>
                    <button onClick={() => upd({ knowledgeLinks: config.knowledgeLinks.filter((_, j) => j !== i) })}
                      style={{ background: "none", border: "none", color: "#EF4444", cursor: "pointer" }}>✕</button>
                  </div>
                ))}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                <select value={newLinkType} onChange={e => setNewLinkType(e.target.value)} style={inputSt}>
                  {RESOURCE_TYPES.map(t => <option key={t}>{t}</option>)}
                </select>
                <input value={newLinkLabel} onChange={e => setNewLinkLabel(e.target.value)} placeholder="Resource name / label" style={inputSt} />
                <input value={newLinkUrl} onChange={e => setNewLinkUrl(e.target.value)} placeholder="URL or identifier" style={inputSt} />
                <button onClick={() => {
                  if (newLinkUrl.trim() || newLinkLabel.trim()) {
                    upd({ knowledgeLinks: [...config.knowledgeLinks, { url: newLinkUrl, label: newLinkLabel, type: newLinkType }] });
                    setNewLinkUrl(""); setNewLinkLabel(""); setNewLinkType("Confluence page");
                  }
                }} style={{ padding: "6px", background: "#3B82F6", color: "#fff", border: "none", borderRadius: 6, cursor: "pointer", fontSize: 12 }}>Add Resource</button>
              </div>
            </Field>
            <Field label="RAG Context (paste reference content)">
              <textarea value={config.ragContext} onChange={e => upd({ ragContext: e.target.value })} rows={8}
                placeholder="Paste Confluence content, design docs, API specs, or any reference material here. This will be injected into the prompt."
                style={{ ...inputSt, resize: "vertical", fontSize: 11 }} />
            </Field>
          </div>
        )}

        {/* TAB 6: Activity Log */}
        {tab === "activity" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {config.activityLog.length === 0 && !config.lastOutput && (
              <div style={{ color: "#64748B", fontSize: 11, textAlign: "center", padding: 24 }}>No activity yet. Run the agent to see results.</div>
            )}

            {/* Live streaming output — shown immediately as tokens arrive */}
            {(config.lastOutput || config.status === "running") && (
              <div style={{ marginBottom: 4 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
                  <div style={{ fontSize: 10, color: "#64748B", fontWeight: 700, letterSpacing: 1 }}>
                    {config.status === "running" ? "⚡ STREAMING LIVE" : "FULL OUTPUT"}
                  </div>
                  {config.status === "running" && (
                    <div style={{ display: "flex", gap: 3, alignItems: "center" }}>
                      {[0,1,2].map(i => (
                        <div key={i} style={{
                          width: 5, height: 5, borderRadius: "50%", background: "#7C3AED",
                          animation: "pulse 1.2s ease-in-out infinite",
                          animationDelay: `${i * 0.2}s`, opacity: 0.8
                        }} />
                      ))}
                    </div>
                  )}
                </div>
                <div style={{
                  background: config.status === "running" ? "#1a1035" : "#F0F4FF",
                  borderRadius: 6, padding: 10,
                  fontSize: 11, color: config.status === "running" ? "#a78bfa" : "#1E293B",
                  fontFamily: "JetBrains Mono, monospace", whiteSpace: "pre-wrap",
                  maxHeight: 380, overflowY: "auto", lineHeight: 1.6,
                  border: config.status === "running" ? "1px solid #4c1d95" : "none",
                  transition: "background 0.3s, color 0.3s"
                }}>
                  {config.lastOutput || ""}
                  {config.status === "running" && (
                    <span style={{ animation: "blink 1s step-end infinite", fontWeight: 700, color: "#7C3AED" }}>▋</span>
                  )}
                </div>
                {config.lastOutput && config.status !== "running" && (
                  <button onClick={() => { navigator.clipboard.writeText(config.lastOutput); }}
                    style={{ marginTop: 6, padding: "4px 10px", background: "#F1F5F9", color: "#64748B", border: "1px solid #E2E8F0", borderRadius: 4, cursor: "pointer", fontSize: 11 }}>
                    Copy Output
                  </button>
                )}
              </div>
            )}

            {/* Activity log entries */}
            {[...config.activityLog].reverse().map((entry, i) => (
              <div key={i} style={{ background: "#F1F5F9", borderRadius: 6, padding: "8px 10px", borderLeft: `3px solid ${statusColors[entry.status] || "#64748B"}` }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                  <span style={{ fontSize: 9, color: statusColors[entry.status] || "#64748B", fontWeight: 700 }}>{entry.status.toUpperCase()}</span>
                  <span style={{ fontSize: 9, color: "#64748B", fontFamily: "JetBrains Mono, monospace" }}>{entry.ts}</span>
                </div>
                <div style={{ fontSize: 11, color: "#1E293B" }}>{entry.message}</div>
                {entry.preview && <div style={{ fontSize: 10, color: "#64748B", marginTop: 4, fontFamily: "JetBrains Mono, monospace", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{entry.preview.substring(0, 80)}</div>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Field wrapper
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div style={{ fontSize: 9, fontWeight: 700, color: "#64748B", letterSpacing: 1, marginBottom: 4, textTransform: "uppercase", fontFamily: "Syne, sans-serif" }}>{label}</div>
      {children}
    </div>
  );
}

const inputSt: React.CSSProperties = {
  width: "100%", background: "#F1F5F9", border: "1px solid #E2E8F0", borderRadius: 6,
  color: "#1E293B", padding: "6px 8px", fontSize: 12, fontFamily: "Syne, sans-serif",
  outline: "none", boxSizing: "border-box"
};

// ─── File Explorer Utilities ──────────────────────────────────────────────────

interface ParsedFile {
  id: string; nodeId: string; agentId: string; agentName: string;
  lang: string; filename: string; code: string;
}

const LANG_EXT: Record<string, string> = {
  java: ".java", typescript: ".ts", tsx: ".tsx", javascript: ".js",
  python: ".py", sql: ".sql", yaml: ".yml", json: ".json", hcl: ".tf",
  bash: ".sh", shell: ".sh", gherkin: ".feature", css: ".css", html: ".html",
  xml: ".xml", markdown: ".md", "c#": ".cs", kotlin: ".kt", rust: ".rs",
  groovy: ".groovy", dockerfile: ".dockerfile"
};

const LANG_COLOR: Record<string, string> = {
  java: "#F59E0B", typescript: "#3B82F6", tsx: "#06B6D4", javascript: "#F59E0B",
  python: "#3B82F6", sql: "#A855F7", yaml: "#10B981", json: "#F59E0B",
  hcl: "#7C3AED", bash: "#10B981", shell: "#10B981", gherkin: "#10B981",
  markdown: "#1E293B"
};

function parseCodeBlocks(cfgs: Record<string, NodeConfig>, nodes: Node[]): ParsedFile[] {
  const files: ParsedFile[] = [];
  let globalIdx = 0;
  nodes.forEach(node => {
    const cfg = cfgs[node.id];
    if (!cfg?.lastOutput) return;
    const def = getAgentById(node.data.agentId);
    const regex = /```(\w+)?\n([\s\S]*?)```/g;
    let match; let nodeIdx = 0;
    while ((match = regex.exec(cfg.lastOutput)) !== null) {
      nodeIdx++; globalIdx++;
      const lang = (match[1] || "text").toLowerCase();
      const code = match[2].trim();
      if (!code) continue;
      const cm = code.match(/^\/\/ (\S+\.\w+)/m)
        || code.match(/^# (\S+\.\w+)/m)
        || code.match(/^public class (\w+)/m)
        || code.match(/^class (\w+)/m)
        || code.match(/^def (\w+)/m)
        || code.match(/^name: (.+)/m);
      const ext = LANG_EXT[lang] || `.${lang}`;
      let filename = cm ? (cm[1].includes(".") ? cm[1] : `${cm[1]}${ext}`) : `${def?.shortName || node.data.agentId}_${nodeIdx}${ext}`;
      filename = filename.split("/").pop() || filename;
      // Unique ID uses globalIdx to guarantee no duplicates across all nodes
      files.push({ id: `file_${globalIdx}_${node.id}`, nodeId: node.id, agentId: node.data.agentId, agentName: cfg.label, lang, filename, code });
    }
  });
  return files;
}

// ─── Agent Descriptions ───────────────────────────────────────────────────────
const AGENT_DESCRIPTIONS: Record<string, string> = {
  A01: "Orchestrates the entire SDLC. Sets stage gates, builds agent chains, manages dependencies and delivery risk.",
  A02: "Enforces policy, compliance and audit requirements (GDPR, PCI-DSS, SOX, HIPAA) throughout delivery.",
  A03: "Retrieves knowledge from Confluence, SharePoint, PDFs and RAG sources to augment other agents.",
  A04: "Inserts human-in-the-loop approval checkpoints — architecture sign-off, CAB, PO acceptance.",
  A05: "Evaluates quality across the pipeline. Produces scorecards, metrics and improvement recommendations.",
  A06: "Converts business needs into epics, user stories (INVEST), NFRs and acceptance criteria.",
  A07: "Produces wireframe specs, BDD Gherkin scenarios, journey maps and UI accessibility requirements.",
  A08: "Creates HLD, LLD, OpenAPI contracts, ADRs, and architecture security patterns.",
  A09: "Generates production-ready backend/frontend code, DB schemas, READMEs and inline docs.",
  A10: "Modernises legacy code — migrates frameworks, upgrades dependencies, rewrites COBOL to Java.",
  A11: "Reviews code for quality, security vulnerabilities (CWE/OWASP), complexity and merge readiness.",
  A12: "Creates unit tests, integration tests, BDD scenarios, test data and coverage reports.",
  A13: "Executes DAST/SAST security scanning, performance test plans and CVE vulnerability reports.",
  A14: "Generates CI/CD pipelines (GitHub Actions/Jenkins), IaC (Terraform), canary configs and CAB packs.",
  A15: "Monitors production incidents, produces RCA documents, runbooks and enhancement backlogs.",
};

// ─── Main Platform ────────────────────────────────────────────────────────────

let nodeIdCounter = 100;
const genId = () => `node_${++nodeIdCounter}`;

export default function ZenseAIPlatform() {
  const { toast } = useToast();
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [configs, setConfigs] = useState<Record<string, NodeConfig>>({});
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [isRunningFlow, setIsRunningFlow] = useState(false);
  const [runningAgentId, setRunningAgentId] = useState<string | null>(null);
  const [history, setHistory] = useState<{ nodes: Node[]; edges: Edge[] }[]>([]);
  const reactFlowWrapper = useRef<HTMLDivElement>(null);
  const [reactFlowInstance, setReactFlowInstance] = useState<any>(null);

  // Inspector resize
  const [inspectorWidth, setInspectorWidth] = useState(380);
  const isResizingInspector = useRef(false);

  // File Explorer
  const [showFileExplorer, setShowFileExplorer] = useState(false);
  const [fileExplorerHeight, setFileExplorerHeight] = useState(300);
  const [selectedFile, setSelectedFile] = useState<ParsedFile | null>(null);
  const [expandedAgents, setExpandedAgents] = useState<Record<string, boolean>>({});
  const isResizingExplorer = useRef(false);

  // Sidebar agent hover
  const [hoveredAgentId, setHoveredAgentId] = useState<string | null>(null);

  // Completion modal
  const [showCompletionModal, setShowCompletionModal] = useState(false);
  const [completionStats, setCompletionStats] = useState<{ total: number; success: number; errors: number }>({ total: 0, success: 0, errors: 0 });

  // Git Repo loading
  const [showRepoModal, setShowRepoModal] = useState(false);
  const [repoUrl, setRepoUrl] = useState("");
  const [repoBranch, setRepoBranch] = useState("");
  const [repoToken, setRepoToken] = useState("");
  const [repoLoading, setRepoLoading] = useState(false);
  const [loadedRepo, setLoadedRepo] = useState<{ owner: string; repo: string; branch: string; fileCount: number; description: string; language: string; projectContext: string } | null>(null);

  const [, navigate] = useLocation();
  const [darkMode, setDarkMode] = useState(false);

  // Before/After Code Panel
  const [isDemoLoaded, setIsDemoLoaded] = useState(false);
  const [showCodePanel, setShowCodePanel] = useState(false);
  const [codePanelHeight, setCodePanelHeight] = useState(340);
  const [beforeTab, setBeforeTab] = useState(0);
  const [afterTab, setAfterTab] = useState(0);
  const isResizingCodePanel = useRef(false);

  const startCodePanelResize = (e: React.MouseEvent) => {
    isResizingCodePanel.current = true;
    const startY = e.clientY;
    const startH = codePanelHeight;
    const onMove = (me: MouseEvent) => {
      if (!isResizingCodePanel.current) return;
      setCodePanelHeight(Math.max(200, Math.min(600, startH - (me.clientY - startY))));
    };
    const onUp = () => { isResizingCodePanel.current = false; window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp); };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  const theme = darkMode ? {
    pageBg: "#0F172A", panelBg: "#1E293B", topBarBg: "#1E293B", border: "#334155",
    text: "#F1F5F9", textMuted: "#94A3B8", chip: "#334155", chipHover: "#475569",
    canvasBg: "#0F172A", dots: "#334155",
  } : {
    pageBg: "#F0F4FF", panelBg: "#FFFFFF", topBarBg: "#FFFFFF", border: "#E2E8F0",
    text: "#1E293B", textMuted: "#64748B", chip: "#F1F5F9", chipHover: "#E2E8F0",
    canvasBg: "#F0F4FF", dots: "#E2E8F0",
  };

  const parsedFiles = parseCodeBlocks(configs, nodes);

  const downloadAllCode = useCallback(async () => {
    if (parsedFiles.length === 0) {
      toast({ title: "No code to download", description: "Run the flow first to generate code.", variant: "destructive" });
      return;
    }
    const zip = new JSZip();
    parsedFiles.forEach(f => {
      const folder = f.agentName ? f.agentName.replace(/[^\w\- ]/g, "").trim() : f.agentId;
      zip.file(`${folder}/${f.filename}`, f.code);
    });
    const blob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "nucleus-generated-code.zip";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast({ title: "Download started", description: `${parsedFiles.length} file(s) zipped.` });
  }, [parsedFiles, toast]);

  const goToCodeExplorer = useCallback(() => {
    sessionStorage.setItem("nucleus_generated_files", JSON.stringify(parsedFiles));
    navigate("/code-explorer");
  }, [parsedFiles, navigate]);

  const goToArtifactsExplorer = useCallback(() => {
    // Build agentDocs from all nodes that have lastOutput
    const agentDocs = nodes
      .filter(n => configs[n.id]?.lastOutput?.trim())
      .map(n => ({
        id: `doc_${n.id}`,
        agentId: n.data.agentId as string,
        agentName: configs[n.id].label,
        content: configs[n.id].lastOutput,
        tokens: 0,
      }));
    const payload = {
      parsedFiles,
      agentDocs,
      savedAt: new Date().toISOString(),
      projectContext: nodes.length > 0 ? configs[nodes[0].id]?.additionalInstructions : undefined,
    };
    sessionStorage.setItem("nucleus_artifacts", JSON.stringify(payload));
    sessionStorage.setItem("nucleus_generated_files", JSON.stringify(parsedFiles));
    navigate("/artifacts-explorer");
  }, [parsedFiles, nodes, configs, navigate]);

  const goToGithubConfig = useCallback(() => {
    sessionStorage.setItem("nucleus_generated_files", JSON.stringify(parsedFiles));
    navigate("/github-config");
  }, [parsedFiles, navigate]);

  const filesByAgent = parsedFiles.reduce((acc, f) => {
    if (!acc[f.agentId]) acc[f.agentId] = [];
    acc[f.agentId].push(f);
    return acc;
  }, {} as Record<string, ParsedFile[]>);

  const startInspectorResize = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isResizingInspector.current = true;
    const startX = e.clientX;
    const startW = inspectorWidth;
    const onMove = (ev: MouseEvent) => {
      if (!isResizingInspector.current) return;
      const delta = startX - ev.clientX;
      setInspectorWidth(Math.max(300, Math.min(720, startW + delta)));
    };
    const onUp = () => {
      isResizingInspector.current = false;
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  }, [inspectorWidth]);

  const startExplorerResize = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isResizingExplorer.current = true;
    const startY = e.clientY;
    const startH = fileExplorerHeight;
    const onMove = (ev: MouseEvent) => {
      if (!isResizingExplorer.current) return;
      const delta = startY - ev.clientY;
      setFileExplorerHeight(Math.max(180, Math.min(600, startH + delta)));
    };
    const onUp = () => {
      isResizingExplorer.current = false;
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  }, [fileExplorerHeight]);

  const selectedConfig = selectedId ? configs[selectedId] : null;
  const selectedNode = selectedId ? nodes.find(n => n.id === selectedId) : null;

  // ── Helpers ─────────────────────────────────────────────────────────────────

  const pushHistory = useCallback(() => {
    setHistory(h => [...h.slice(-29), { nodes: JSON.parse(JSON.stringify(nodes)), edges: JSON.parse(JSON.stringify(edges)) }]);
  }, [nodes, edges]);

  const undo = useCallback(() => {
    setHistory(h => {
      if (h.length === 0) return h;
      const prev = h[h.length - 1];
      setNodes(prev.nodes); setEdges(prev.edges);
      return h.slice(0, -1);
    });
  }, [setNodes, setEdges]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "z") undo();
      if (e.key === "Delete" && selectedId) deleteSelectedNode();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [selectedId, undo]);

  const updateConfig = useCallback((nodeId: string, cfg: NodeConfig) => {
    setConfigs(c => ({ ...c, [nodeId]: cfg }));
    setNodes(ns => ns.map(n => n.id === nodeId ? { ...n, data: { ...n.data, config: cfg } } : n));
  }, [setNodes]);

  // Load a GitHub repo as project context for all agents
  const loadRepoContext = useCallback(async () => {
    if (!repoUrl.trim()) {
      toast({ title: "URL required", description: "Enter a GitHub repository URL.", variant: "destructive" });
      return;
    }
    setRepoLoading(true);
    try {
      const res = await fetch("/api/zenseai/github/load-repo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: repoUrl.trim(), branch: repoBranch.trim() || undefined, token: repoToken.trim() || undefined }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data.error || "Failed to load repository");
      setLoadedRepo(data);
      // Apply repo context to all existing agent configs on canvas
      setConfigs(prev => {
        const updated: Record<string, NodeConfig> = {};
        Object.entries(prev).forEach(([id, cfg]) => {
          updated[id] = { ...cfg, additionalInstructions: data.projectContext };
        });
        return updated;
      });
      setShowRepoModal(false);
      setRepoUrl(""); setRepoBranch(""); setRepoToken("");
      toast({ title: `Repo loaded: ${data.owner}/${data.repo}`, description: `${data.fileCount} files · ${data.language} · Context injected into all agents` });
    } catch (err: any) {
      toast({ title: "Failed to load repo", description: err.message, variant: "destructive" });
    } finally {
      setRepoLoading(false);
    }
  }, [repoUrl, repoBranch, repoToken, toast]);

  const addAgentNode = useCallback((agentId: string, position?: { x: number; y: number }) => {
    pushHistory();
    const id = genId();
    const cfg = defaultConfig(agentId);
    // Inject loaded repo context into new agents automatically
    if (loadedRepo) cfg.additionalInstructions = loadedRepo.projectContext;
    const pos = position || { x: 100 + Math.random() * 400, y: 100 + Math.random() * 300 };
    setConfigs(c => ({ ...c, [id]: cfg }));
    setNodes(ns => [...ns, { id, type: "agentNode", position: pos, data: { agentId, config: cfg } }]);
  }, [pushHistory, setNodes, loadedRepo]);

  const deleteSelectedNode = useCallback(() => {
    if (!selectedId) return;
    pushHistory();
    setNodes(ns => ns.filter(n => n.id !== selectedId));
    setEdges(es => es.filter(e => e.source !== selectedId && e.target !== selectedId));
    setConfigs(c => { const nc = { ...c }; delete nc[selectedId]; return nc; });
    setSelectedId(null);
  }, [selectedId, pushHistory, setNodes, setEdges]);

  const onConnect = useCallback((params: Connection) => {
    pushHistory();
    setEdges(es => addEdge({ ...params, markerEnd: { type: MarkerType.ArrowClosed, color: "#3B82F6" }, style: { stroke: "#3B82F6", strokeWidth: 2 }, animated: true }, es));
  }, [pushHistory, setEdges]);

  const onEdgeClick = useCallback((_: any, edge: Edge) => {
    pushHistory(); setEdges(es => es.filter(e => e.id !== edge.id));
  }, [pushHistory, setEdges]);

  const onDragOver = useCallback((e: React.DragEvent) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; }, []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const agentId = e.dataTransfer.getData("application/zenseai-agent");
    if (!agentId || !reactFlowInstance) return;
    const bounds = reactFlowWrapper.current?.getBoundingClientRect();
    if (!bounds) return;
    const pos = reactFlowInstance.project({ x: e.clientX - bounds.left, y: e.clientY - bounds.top });
    addAgentNode(agentId, pos);
  }, [reactFlowInstance, addAgentNode]);

  // ── Agent Execution (streaming) ───────────────────────────────────────────────

  const runAgent = useCallback(async (nodeId: string) => {
    const cfg = configs[nodeId];
    const node = nodes.find(n => n.id === nodeId);
    if (!cfg || !node) return;
    const agentId = node.data.agentId;
    setRunningAgentId(nodeId);
    const ts = new Date().toLocaleTimeString();

    // Mark as running and clear previous output
    setConfigs(c => {
      const updated = {
        ...c,
        [nodeId]: {
          ...c[nodeId],
          status: "running" as const,
          lastOutput: "",
          activityLog: [...(c[nodeId]?.activityLog || []), {
            ts, status: "running" as const,
            message: `⚡ ${agentId} started — streaming output live…`
          }]
        }
      };
      setNodes(ns => ns.map(n => n.id === nodeId ? { ...n, data: { ...n.data, config: updated[nodeId] } } : n));
      return updated;
    });

    try {
      const res = await fetch("/api/zenseai/run-agent-stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          agentId, agentName: cfg.label,
          systemPrompt: cfg.systemPrompt,
          additionalInstructions: cfg.additionalInstructions,
          criteria: cfg.criteria,
          ragContext: cfg.ragContext,
          outputFormats: cfg.outputFormats,
          outputSchema: cfg.outputSchema,
          temperature: cfg.temperature,
          maxTokens: cfg.maxTokens,
        })
      });

      if (!res.ok || !res.body) throw new Error(`Server error: HTTP ${res.status}`);

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let accumulated = "";
      let finalMeta = { tokens: 0, duration: 0, model: "Claude AI" };
      let streamError = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const raw = decoder.decode(value, { stream: true });
        for (const line of raw.split("\n")) {
          if (!line.startsWith("data: ")) continue;
          const payload = line.slice(6).trim();
          if (!payload || payload === "[DONE]") continue;
          try {
            const parsed = JSON.parse(payload);
            if (parsed.text) {
              accumulated += parsed.text;
              // Live update — write growing output to Activity tab in real time
              setConfigs(c => ({
                ...c,
                [nodeId]: { ...c[nodeId], lastOutput: accumulated }
              }));
            }
            if (parsed.done) {
              finalMeta = {
                tokens: parsed.tokens || 0,
                duration: parsed.duration || 0,
                model: parsed.model || "Claude AI",
              };
            }
            if (parsed.error) streamError = parsed.error;
          } catch { /* malformed chunk — skip */ }
        }
      }

      if (streamError) throw new Error(streamError);

      const donets = new Date().toLocaleTimeString();
      setConfigs(c => {
        const updated = {
          ...c,
          [nodeId]: {
            ...c[nodeId],
            status: "success" as const,
            lastOutput: accumulated,
            activityLog: [...(c[nodeId]?.activityLog || []), {
              ts: donets, status: "success" as const,
              message: `✅ ${finalMeta.model} · ${(finalMeta.duration / 1000).toFixed(1)}s · ${finalMeta.tokens} tokens`,
              preview: accumulated.substring(0, 80)
            }]
          }
        };
        setNodes(ns => ns.map(n => n.id === nodeId ? { ...n, data: { ...n.data, config: updated[nodeId] } } : n));
        return updated;
      });
      toast({
        title: `${cfg.label} completed`,
        description: `${finalMeta.tokens} tokens · ${(finalMeta.duration / 1000).toFixed(1)}s · ${finalMeta.model}`
      });

    } catch (err: any) {
      setConfigs(c => {
        const updated = {
          ...c,
          [nodeId]: {
            ...c[nodeId],
            status: "error" as const,
            activityLog: [...(c[nodeId]?.activityLog || []), {
              ts: new Date().toLocaleTimeString(), status: "error" as const,
              message: `Error: ${err.message}`
            }]
          }
        };
        setNodes(ns => ns.map(n => n.id === nodeId ? { ...n, data: { ...n.data, config: updated[nodeId] } } : n));
        return updated;
      });
      toast({ title: "Agent failed", description: err.message, variant: "destructive" });
    }

    setRunningAgentId(null);
  }, [configs, nodes, toast]);

  // Topological sort
  const topoSort = useCallback((nodeIds: string[]): string[] => {
    const inDegree: Record<string, number> = {};
    const adj: Record<string, string[]> = {};
    nodeIds.forEach(id => { inDegree[id] = 0; adj[id] = []; });
    edges.forEach(e => { if (inDegree[e.target] !== undefined) inDegree[e.target]++; if (adj[e.source]) adj[e.source].push(e.target); });
    const queue = nodeIds.filter(id => inDegree[id] === 0);
    const result: string[] = [];
    while (queue.length > 0) {
      const cur = queue.shift()!; result.push(cur);
      (adj[cur] || []).forEach(nxt => { inDegree[nxt]--; if (inDegree[nxt] === 0) queue.push(nxt); });
    }
    return result.length === nodeIds.length ? result : nodeIds;
  }, [edges]);

  const runFlow = useCallback(async () => {
    if (nodes.length === 0) { toast({ title: "No agents on canvas", description: "Drag agents from the sidebar to begin", variant: "destructive" }); return; }
    setIsRunningFlow(true);
    toast({ title: "▶ Running flow", description: `Executing ${nodes.length} agents in sequence…` });
    const order = topoSort(nodes.map(n => n.id));
    for (const nodeId of order) {
      if (configs[nodeId]?.failureHandling === "Stop flow" && configs[nodeId]?.status === "error") break;
      await runAgent(nodeId);
    }
    setIsRunningFlow(false);
    // Count outcomes from updated configs after run
    const total = order.length;
    const successCount = order.filter(id => configs[id]?.status === "success").length;
    const errorCount = order.filter(id => configs[id]?.status === "error").length;
    setCompletionStats({ total, success: successCount || total, errors: errorCount });
    setShowCompletionModal(true);
    if (isDemoLoaded) setShowCodePanel(true);
  }, [nodes, configs, topoSort, runAgent, toast, isDemoLoaded]);

  // ── Save / Load / Validate / Auto-layout ─────────────────────────────────────

  const saveFlow = useCallback(() => {
    const data = { nodes: nodes.map(n => ({ ...n, data: { agentId: n.data.agentId } })), edges, configs, version: "1.0", savedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `zenseai-flow-${Date.now()}.json`; a.click();
    toast({ title: "Flow saved", description: "JSON file downloaded" });
  }, [nodes, edges, configs, toast]);

  const loadFlow = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target?.result as string);
        const restoredConfigs: Record<string, NodeConfig> = data.configs || {};
        const restoredNodes = (data.nodes || []).map((n: any) => ({ ...n, type: "agentNode", data: { agentId: n.data.agentId, config: restoredConfigs[n.id] || defaultConfig(n.data.agentId) } }));
        setNodes(restoredNodes); setEdges(data.edges || []);
        setConfigs(restoredConfigs);
        toast({ title: "Flow loaded", description: `${restoredNodes.length} nodes restored` });
      } catch { toast({ title: "Load failed", description: "Invalid flow file", variant: "destructive" }); }
    };
    reader.readAsText(file);
    e.target.value = "";
  }, [setNodes, setEdges, toast]);

  const validateFlow = useCallback(() => {
    const disconnected = nodes.filter(n => !edges.some(e => e.source === n.id || e.target === n.id));
    if (disconnected.length === 0) toast({ title: "✅ Flow is valid", description: `${nodes.length} nodes, ${edges.length} connections` });
    else toast({ title: `⚠ ${disconnected.length} disconnected node(s)`, description: disconnected.map(n => configs[n.id]?.label || n.id).join(", "), variant: "destructive" });
  }, [nodes, edges, configs, toast]);

  const autoLayout = useCallback(() => {
    pushHistory();
    const cols = Math.ceil(Math.sqrt(nodes.length)); const spacing = { x: 250, y: 160 };
    setNodes(ns => ns.map((n, i) => ({ ...n, position: { x: 60 + (i % cols) * spacing.x, y: 60 + Math.floor(i / cols) * spacing.y } })));
  }, [nodes.length, pushHistory, setNodes]);

  const clearCanvas = useCallback(() => {
    if (nodes.length === 0) return;
    if (!confirm("Clear all nodes and connections?")) return;
    pushHistory(); setNodes([]); setEdges([]); setConfigs({}); setSelectedId(null);
    toast({ title: "Canvas cleared" });
  }, [nodes.length, pushHistory, setNodes, setEdges, toast]);

  const loadDemo = useCallback(() => {
    if (nodes.length > 0 && !confirm("Load Banking Demo? This will replace the current canvas with the Customer Demographics Migration project.")) return;
    pushHistory();
    const now = new Date().toLocaleTimeString();
    const newConfigs: Record<string, NodeConfig> = {};
    const newNodes: Node[] = DEMO_FLOW_LAYOUT.map(({ id: agentId, pos }) => {
      const nodeId = `demo_${agentId}`;
      const base = defaultConfig(agentId);
      const output = DEMO_OUTPUTS[agentId] || "";
      const criteria = DEMO_CRITERIA[agentId] || base.criteria;
      const cfg: NodeConfig = {
        ...base,
        additionalInstructions: DEMO_PROJECT_CONTEXT,
        criteria,
        outputFormats: ["markdown", "code"],
        status: "idle",
        lastOutput: output,
        activityLog: [
          { ts: now, status: "info", message: "Demo loaded — Banking: CUST_IDENTITY + CUST_TAX_INFO → CUSTOMER_DEMOGRAPHICS. Click ▶ Run Flow to execute." }
        ]
      };
      newConfigs[nodeId] = cfg;
      return { id: nodeId, type: "agentNode" as const, position: pos, data: { agentId, config: cfg } };
    });
    const nodeIdMap: Record<string, string> = {};
    DEMO_FLOW_LAYOUT.forEach(({ id }) => { nodeIdMap[id] = `demo_${id}`; });
    const newEdges: Edge[] = DEMO_EDGES
      .filter(e => nodeIdMap[e.source] && nodeIdMap[e.target])
      .map((e, i) => ({
        id: `demo_edge_${i}`, source: nodeIdMap[e.source], target: nodeIdMap[e.target],
        markerEnd: { type: MarkerType.ArrowClosed, color: "#3B82F6" },
        style: { stroke: "#3B82F6", strokeWidth: 2 }, animated: true
      }));
    setNodes(newNodes); setEdges(newEdges); setConfigs(newConfigs); setSelectedId(null);
    setIsDemoLoaded(true);
    setShowCodePanel(true);
    setBeforeTab(0);
    setAfterTab(0);
    setTimeout(() => reactFlowInstance?.fitView({ padding: 0.1 }), 100);
    toast({ title: "✨ Banking Demo loaded", description: "Customer Demographics Migration — 7 agents ready. Click ▶ Run Flow to execute agents and see the migrated code." });
  }, [nodes.length, pushHistory, setNodes, setEdges, reactFlowInstance, toast]);

  // ── Filtered agents ──────────────────────────────────────────────────────────
  const filteredDomains = AGENT_DOMAINS.map(d => ({
    ...d,
    agents: d.agents.filter(id => {
      const def = getAgentById(id);
      return !search || def?.name.toLowerCase().includes(search.toLowerCase()) || id.toLowerCase().includes(search.toLowerCase());
    })
  })).filter(d => d.agents.length > 0);

  // ── Render ───────────────────────────────────────────────────────────────────

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 60px)", background: theme.pageBg, color: theme.text, fontFamily: "Syne, sans-serif", overflow: "hidden" }}>

      {/* TOP BAR */}
      <div style={{ height: 48, background: theme.topBarBg, borderBottom: `1px solid ${theme.border}`, display: "flex", alignItems: "center", gap: 8, padding: "0 16px", flexShrink: 0, zIndex: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginRight: 16 }}>
          <Bot size={20} color="#3B82F6" />
          <span style={{ fontWeight: 800, fontSize: 14, color: theme.text }}>Nucleus 2.0</span>
          <span style={{ fontSize: 11, color: theme.textMuted }}>Agent Factory</span>
          <span style={{ fontSize: 10, color: theme.textMuted, fontStyle: "italic" }}>Agent Development Lifecycle (ADLC)</span>
        </div>

        <div style={{ width: 1, height: 24, background: theme.border, margin: "0 4px" }} />

        <TopBtn icon={<Play size={13} />} label="Run Flow" color="#10B981" onClick={runFlow} disabled={isRunningFlow} />
        <TopBtn icon={<LayoutGrid size={13} />} label="Auto Layout" onClick={autoLayout} />
        <TopBtn icon={<CheckCircle size={13} />} label="Validate" onClick={validateFlow} />

        <div style={{ width: 1, height: 24, background: "#E2E8F0", margin: "0 4px" }} />

        <TopBtn icon={<Save size={13} />} label="Save" onClick={saveFlow} />
        <label style={{ cursor: "pointer" }}>
          <input type="file" accept=".json" onChange={loadFlow} style={{ display: "none" }} />
          <div style={{ display: "flex", alignItems: "center", gap: 4, padding: "5px 10px", background: "#F1F5F9", borderRadius: 6, cursor: "pointer", fontSize: 11, color: "#64748B", border: "1px solid #E2E8F0" }}>
            <Upload size={13} /> Load
          </div>
        </label>
        <TopBtn icon={<Trash2 size={13} />} label="Clear" color="#EF4444" onClick={clearCanvas} />

        <div style={{ width: 1, height: 24, background: "#E2E8F0", margin: "0 4px" }} />

        <button onClick={() => { setShowFileExplorer(v => !v); if (!showFileExplorer && parsedFiles.length > 0) setSelectedFile(parsedFiles[0]); }} style={{
          display: "flex", alignItems: "center", gap: 4, padding: "5px 10px",
          background: showFileExplorer ? "#ECFDF5" : "#F1F5F9",
          border: `1px solid ${showFileExplorer ? "#10B981" : "#E2E8F0"}`,
          borderRadius: 6, cursor: "pointer", fontSize: 11,
          color: showFileExplorer ? "#10B981" : "#64748B", fontFamily: "Syne, sans-serif"
        }}>
          <FolderOpen size={13} /> Files {parsedFiles.length > 0 && <span style={{ background: "#10B981", color: "#fff", borderRadius: 8, padding: "0 5px", fontSize: 9, fontWeight: 700 }}>{parsedFiles.length}</span>}
        </button>

        <button onClick={() => setShowCodePanel(v => !v)} style={{
          display: "flex", alignItems: "center", gap: 4, padding: "5px 10px",
          background: showCodePanel ? (isDemoLoaded ? "#FFF7ED" : "#EFF6FF") : "#F1F5F9",
          border: `1px solid ${showCodePanel ? (isDemoLoaded ? "#F97316" : "#3B82F6") : "#E2E8F0"}`,
          borderRadius: 6, cursor: "pointer", fontSize: 11,
          color: showCodePanel ? (isDemoLoaded ? "#EA580C" : "#3B82F6") : "#64748B",
          fontFamily: "Syne, sans-serif", fontWeight: isDemoLoaded ? 700 : 400
        }}>
          <Code2 size={13} /> Code Changes {isDemoLoaded && <span style={{ background: "#F97316", color: "#fff", borderRadius: 8, padding: "0 5px", fontSize: 9, fontWeight: 700 }}>DEMO</span>}
        </button>

        <TopBtn icon={<Download size={13} />} label="Download Code" onClick={downloadAllCode} />
        <TopBtn icon={<Code2 size={13} />} label="Code Explorer" onClick={goToCodeExplorer} />
        <button onClick={goToArtifactsExplorer} style={{
          display: "flex", alignItems: "center", gap: 4, padding: "5px 10px",
          background: "linear-gradient(135deg, #1E3A5F, #1E293B)",
          border: "1px solid #3B82F6", borderRadius: 6, cursor: "pointer", fontSize: 11,
          color: "#60A5FA", fontFamily: "Syne, sans-serif", fontWeight: 700
        }}>
          📦 Full Explorer {(parsedFiles.length > 0 || nodes.some(n => configs[n.id]?.lastOutput)) &&
            <span style={{ background: "#3B82F6", color: "#fff", borderRadius: 8, padding: "0 5px", fontSize: 9, fontWeight: 700 }}>
              {parsedFiles.length + nodes.filter(n => configs[n.id]?.lastOutput?.trim()).length}
            </span>}
        </button>
        <TopBtn icon={<Github size={13} />} label="GitHub" onClick={goToGithubConfig} />

        <div style={{ width: 1, height: 24, background: theme.border, margin: "0 4px" }} />

        {/* Load Repo button */}
        <button onClick={() => setShowRepoModal(true)} style={{
          display: "flex", alignItems: "center", gap: 4, padding: "5px 10px",
          background: loadedRepo ? "#ECFDF5" : theme.chip,
          border: `1px solid ${loadedRepo ? "#10B981" : theme.border}`,
          borderRadius: 6, cursor: "pointer", fontSize: 11,
          color: loadedRepo ? "#059669" : theme.text, fontFamily: "Syne, sans-serif", fontWeight: loadedRepo ? 700 : 400
        }}>
          <Github size={13} /> {loadedRepo ? `${loadedRepo.owner}/${loadedRepo.repo}` : "Load Repo"}
        </button>

        {loadedRepo && (
          <button onClick={() => { setLoadedRepo(null); toast({ title: "Repo context cleared" }); }} title="Clear repo context" style={{ background: "none", border: "none", cursor: "pointer", color: "#EF4444", padding: "2px 4px", fontSize: 10, lineHeight: 1 }}>
            ✕
          </button>
        )}

        <div style={{ width: 1, height: 24, background: theme.border, margin: "0 4px" }} />

        <button onClick={() => setDarkMode(v => !v)} title={darkMode ? "Switch to light theme" : "Switch to dark theme"} style={{
          display: "flex", alignItems: "center", gap: 4, padding: "5px 10px",
          background: theme.chip, border: `1px solid ${theme.border}`, borderRadius: 6,
          cursor: "pointer", fontSize: 11, color: theme.text, fontFamily: "Syne, sans-serif"
        }}>
          {darkMode ? <Sun size={13} /> : <Moon size={13} />} {darkMode ? "Light" : "Dark"}
        </button>

        <div style={{ width: 1, height: 24, background: theme.border, margin: "0 4px" }} />

        <button onClick={loadDemo} style={{
          display: "flex", alignItems: "center", gap: 4, padding: "5px 12px",
          background: "linear-gradient(135deg, #7C3AED, #EC4899)",
          border: "none", borderRadius: 6, cursor: "pointer", fontSize: 11,
          color: "#fff", fontFamily: "Syne, sans-serif", fontWeight: 700,
          boxShadow: "0 0 12px rgba(124,58,237,0.4)"
        }}>
          <Sparkles size={12} /> Load Demo
        </button>

        <div style={{ flex: 1 }} />

        <div style={{ fontSize: 10, color: theme.textMuted, background: theme.chip, padding: "4px 10px", borderRadius: 20, border: `1px solid ${theme.border}` }}>
          <span style={{ color: "#10B981" }}>⬤</span> GPT-4o
        </div>
        {isRunningFlow && <div style={{ fontSize: 10, color: "#F59E0B", animation: "pulse 1s infinite" }}>⟳ Running flow…</div>}
      </div>

      {/* MAIN AREA */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>

        {/* LEFT SIDEBAR — Agent Library */}
        <div style={{ width: 210, background: theme.panelBg, borderRight: `1px solid ${theme.border}`, display: "flex", flexDirection: "column", flexShrink: 0, overflow: "hidden", position: "relative" }}>
          <div style={{ padding: "10px 10px 6px" }}>
            <div style={{ fontSize: 9, fontWeight: 700, color: theme.textMuted, letterSpacing: 1, marginBottom: 6 }}>AGENT LIBRARY</div>
            <div style={{ position: "relative" }}>
              <Search size={10} style={{ position: "absolute", left: 7, top: "50%", transform: "translateY(-50%)", color: theme.textMuted }} />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search agents…"
                style={{ ...inputSt, paddingLeft: 22, fontSize: 10, width: "100%", background: theme.chip, color: theme.text, borderColor: theme.border }} />
            </div>
          </div>
          <div style={{ flex: 1, overflowY: "auto", padding: "4px 6px 12px" }}>
            {filteredDomains.map(domain => (
              <div key={domain.name} style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 8, fontWeight: 700, color: theme.textMuted, letterSpacing: 1, padding: "4px 4px 2px", borderBottom: `1px solid ${theme.border}`, marginBottom: 4 }}>
                  {domain.name.toUpperCase()}
                </div>
                {domain.agents.map(agentId => {
                  const def = getAgentById(agentId)!;
                  const isHovered = hoveredAgentId === agentId;
                  const desc = AGENT_DESCRIPTIONS[agentId] || def.keyOutputs;
                  return (
                    <div key={agentId} style={{ position: "relative", marginBottom: 2 }}>
                      <div draggable
                        onDragStart={e => { e.dataTransfer.setData("application/zenseai-agent", agentId); e.dataTransfer.effectAllowed = "move"; }}
                        onDoubleClick={() => addAgentNode(agentId)}
                        onMouseEnter={() => setHoveredAgentId(agentId)}
                        onMouseLeave={() => setHoveredAgentId(null)}
                        style={{ display: "flex", alignItems: "flex-start", gap: 6, padding: "6px 6px", borderRadius: 6, cursor: "grab",
                          background: isHovered ? (darkMode ? "#1E3A5F" : "#EBF4FF") : theme.chip,
                          border: `1px solid ${isHovered ? def.accent : theme.border}`, transition: "all 0.15s"
                        }}
                      >
                        <span style={{ fontSize: 14, flexShrink: 0, marginTop: 1 }}>{def.emoji}</span>
                        <div style={{ minWidth: 0, flex: 1 }}>
                          <div style={{ fontSize: 10, fontWeight: 700, color: theme.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{def.shortName}</div>
                          <div style={{ fontSize: 8, color: theme.textMuted, fontFamily: "JetBrains Mono, monospace" }}>{agentId}</div>
                          {isHovered && (
                            <div style={{ fontSize: 9, color: theme.textMuted, marginTop: 4, lineHeight: 1.4, whiteSpace: "normal" }}>{desc}</div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
          <div style={{ padding: "8px 10px", borderTop: `1px solid ${theme.border}`, fontSize: 9, color: theme.textMuted, textAlign: "center" }}>
            Drag to canvas · Double-click to add · Hover for info
          </div>
        </div>

        {/* CANVAS + FILE EXPLORER column */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>

          {/* CANVAS */}
          <div ref={reactFlowWrapper} style={{ flex: 1, position: "relative", overflow: "hidden" }} onDrop={onDrop} onDragOver={onDragOver}>
            <ReactFlow
              nodes={nodes} edges={edges}
              onNodesChange={onNodesChange} onEdgesChange={onEdgesChange}
              onConnect={onConnect} onEdgeClick={onEdgeClick}
              nodeTypes={nodeTypes}
              onNodeClick={(_, node) => setSelectedId(node.id)}
              onPaneClick={() => setSelectedId(null)}
              onInit={setReactFlowInstance}
              fitView
              style={{ background: theme.canvasBg }}
              defaultEdgeOptions={{ markerEnd: { type: MarkerType.ArrowClosed, color: "#3B82F6" }, style: { stroke: "#3B82F6", strokeWidth: 2 }, animated: true }}
            >
              <Background variant={BackgroundVariant.Dots} gap={20} size={1} color={theme.dots} />
              <MiniMap style={{ background: theme.panelBg, border: `1px solid ${theme.border}` }} nodeColor={n => { const def = getAgentById(n.data?.agentId); return def?.accent || "#3B82F6"; }} />
              <Controls style={{ background: theme.panelBg, border: `1px solid ${theme.border}` }} />
              {nodes.length === 0 && (
                <Panel position="top-center">
                  <div style={{ marginTop: 120, textAlign: "center", color: theme.textMuted, pointerEvents: "none" }}>
                    <div style={{ fontSize: 36, marginBottom: 12 }}>🤖</div>
                    <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 6, color: theme.text }}>Nucleus 2.0 Agent Factory</div>
                    <div style={{ fontSize: 12 }}>Drag agents from the left panel to build your delivery pipeline</div>
                    <div style={{ fontSize: 11, marginTop: 8, color: "#3B82F6" }}>15 specialist agents · 62 SDLC activities · Powered by GPT-4o</div>
                  </div>
                </Panel>
              )}
            </ReactFlow>
          </div>

          {/* FILE EXPLORER PANEL (slides up from bottom) */}
          {showFileExplorer && (
            <div style={{ height: fileExplorerHeight, flexShrink: 0, background: theme.panelBg, borderTop: `1px solid ${theme.border}`, display: "flex", flexDirection: "column", overflow: "hidden" }}>
              {/* Resize handle */}
              <div onMouseDown={startExplorerResize} style={{ height: 5, cursor: "ns-resize", background: theme.chip, borderBottom: `1px solid ${theme.border}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <GripVertical size={12} style={{ color: theme.textMuted, transform: "rotate(90deg)" }} />
              </div>
              {/* Explorer header */}
              <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 12px", borderBottom: `1px solid ${theme.border}`, flexShrink: 0, background: theme.panelBg }}>
                <FolderOpen size={13} style={{ color: "#10B981" }} />
                <span style={{ fontSize: 10, fontWeight: 700, color: theme.text, letterSpacing: 1 }}>FILE EXPLORER</span>
                <span style={{ fontSize: 9, color: theme.textMuted }}>— {parsedFiles.length} file{parsedFiles.length !== 1 ? "s" : ""} generated</span>
                <div style={{ flex: 1 }} />
                {selectedFile && (
                  <button onClick={() => { navigator.clipboard.writeText(selectedFile.code); }} style={{ display: "flex", alignItems: "center", gap: 4, padding: "3px 8px", background: theme.chip, border: `1px solid ${theme.border}`, borderRadius: 4, cursor: "pointer", fontSize: 9, color: theme.textMuted }}>
                    <Copy size={10} /> Copy
                  </button>
                )}
                <button onClick={() => setShowFileExplorer(false)} style={{ background: "none", border: "none", cursor: "pointer", color: theme.textMuted, padding: 2 }}><X size={14} /></button>
              </div>
              {/* Explorer body */}
              <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
                {/* File tree */}
                <div style={{ width: 220, flexShrink: 0, borderRight: `1px solid ${theme.border}`, overflowY: "auto", padding: "6px 0" }}>
                  {parsedFiles.length === 0 ? (
                    <div style={{ padding: "20px 12px", textAlign: "center", color: theme.textMuted, fontSize: 10 }}>
                      No code files yet.<br />Run agents to generate artefacts.
                    </div>
                  ) : (
                    Object.entries(filesByAgent).map(([agentId, files]) => {
                      const isOpen = expandedAgents[agentId] !== false;
                      const def = getAgentById(agentId);
                      return (
                        <div key={agentId}>
                          <div onClick={() => setExpandedAgents(s => ({ ...s, [agentId]: !isOpen }))}
                            style={{ display: "flex", alignItems: "center", gap: 5, padding: "4px 10px", cursor: "pointer", userSelect: "none" }}
                          >
                            <ChevronRight size={10} style={{ color: theme.textMuted, transform: isOpen ? "rotate(90deg)" : "none", transition: "transform 0.15s" }} />
                            {isOpen ? <FolderOpen size={11} style={{ color: def?.accent || "#3B82F6" }} /> : <FolderClosed size={11} style={{ color: def?.accent || "#3B82F6" }} />}
                            <span style={{ fontSize: 9, fontWeight: 700, color: theme.text }}>{files[0].agentName}</span>
                            <span style={{ fontSize: 8, color: theme.textMuted, fontFamily: "JetBrains Mono, monospace" }}>{agentId}</span>
                          </div>
                          {isOpen && files.map(f => (
                            <div key={f.id} onClick={() => setSelectedFile(f)}
                              style={{ display: "flex", alignItems: "center", gap: 5, padding: "3px 10px 3px 26px", cursor: "pointer",
                                background: selectedFile?.id === f.id ? (darkMode ? "#1E3A5F" : "#EBF4FF") : "transparent",
                                borderLeft: selectedFile?.id === f.id ? `2px solid ${LANG_COLOR[f.lang] || "#3B82F6"}` : "2px solid transparent"
                              }}
                              onMouseEnter={e => { if (selectedFile?.id !== f.id) e.currentTarget.style.background = theme.chip; }}
                              onMouseLeave={e => { if (selectedFile?.id !== f.id) e.currentTarget.style.background = "transparent"; }}
                            >
                              <FileCode size={10} style={{ color: LANG_COLOR[f.lang] || theme.textMuted, flexShrink: 0 }} />
                              <span style={{ fontSize: 9, color: selectedFile?.id === f.id ? theme.text : theme.textMuted, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{f.filename}</span>
                              <span style={{ fontSize: 7, color: theme.textMuted, marginLeft: "auto", flexShrink: 0, fontFamily: "JetBrains Mono, monospace" }}>{f.lang}</span>
                            </div>
                          ))}
                        </div>
                      );
                    })
                  )}
                </div>
                {/* Code Preview */}
                <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column" }}>
                  {selectedFile ? (
                    <>
                      <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "5px 12px", borderBottom: `1px solid ${theme.border}`, flexShrink: 0, background: theme.chip }}>
                        <FileCode size={11} style={{ color: LANG_COLOR[selectedFile.lang] || theme.textMuted }} />
                        <span style={{ fontSize: 10, fontWeight: 700, color: theme.text, fontFamily: "JetBrains Mono, monospace" }}>{selectedFile.filename}</span>
                        <span style={{ fontSize: 8, color: theme.textMuted, background: theme.border, padding: "1px 6px", borderRadius: 10, fontFamily: "JetBrains Mono, monospace" }}>{selectedFile.lang}</span>
                        <span style={{ fontSize: 8, color: theme.textMuted, marginLeft: 4 }}>from {selectedFile.agentName}</span>
                      </div>
                      <div style={{ flex: 1, overflow: "auto", padding: "10px 16px" }}>
                        <pre style={{ margin: 0, fontSize: 11, color: theme.text, fontFamily: "JetBrains Mono, monospace", lineHeight: 1.6, whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
                          {selectedFile.code}
                        </pre>
                      </div>
                    </>
                  ) : (
                    <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: theme.textMuted, flexDirection: "column", gap: 8 }}>
                      <FileCode size={24} style={{ opacity: 0.3 }} />
                      <span style={{ fontSize: 11 }}>Select a file to preview</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ── BEFORE / AFTER CODE PANEL ─────────────────────────────────── */}
          {showCodePanel && isDemoLoaded && (() => {
            const demoNodeIds = nodes.filter(n => n.id.startsWith("demo_")).map(n => n.id);
            const allDone = demoNodeIds.length > 0 && demoNodeIds.every(id => configs[id]?.status === "success");

            const BEFORE_TABS = [
              { label: "CustomerIdentity.java", lang: "java", code: DEMO_BEFORE_CODE.identity },
              { label: "CustomerTaxInfo.java",  lang: "java", code: DEMO_BEFORE_CODE.tax },
              { label: "CustomerService.java",  lang: "java", code: DEMO_BEFORE_CODE.service },
            ];
            const AFTER_TABS = [
              { label: "CustomerDemographics.java",       lang: "java", code: DEMO_AFTER_CODE.entity },
              { label: "CustomerService.java (refactored)", lang: "java", code: DEMO_AFTER_CODE.service },
              { label: "V3__consolidate_demographics.sql", lang: "sql",  code: DEMO_AFTER_CODE.migration },
            ];

            const tabBtn = (label: string, active: boolean, onClick: () => void, color: string) => (
              <button key={label} onClick={onClick} style={{
                padding: "4px 10px", fontSize: 10, fontFamily: "JetBrains Mono, monospace",
                background: active ? color + "22" : "transparent",
                border: `1px solid ${active ? color : "transparent"}`,
                borderRadius: "4px 4px 0 0", cursor: "pointer",
                color: active ? color : "#94A3B8", fontWeight: active ? 700 : 400,
                whiteSpace: "nowrap"
              }}>{label}</button>
            );

            const codeView = (code: string, border: string) => (
              <div style={{ flex: 1, overflow: "auto", background: "#0D1117", borderTop: `2px solid ${border}` }}>
                <pre style={{ margin: 0, padding: "12px 16px", fontSize: 10.5, fontFamily: "JetBrains Mono, monospace", lineHeight: 1.65, color: "#E6EDF3", whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
                  {code}
                </pre>
              </div>
            );

            const activeTabs  = allDone ? AFTER_TABS  : BEFORE_TABS;
            const activeTab   = allDone ? afterTab    : beforeTab;
            const setActive   = allDone ? setAfterTab : setBeforeTab;
            const accentClr   = allDone ? "#10B981"   : "#EF4444";
            const sideLabel   = allDone ? "⬤ AFTER — Migrated Code" : "⬤ BEFORE — Legacy Code";

            return (
              <div style={{ height: codePanelHeight, flexShrink: 0, background: "#0D1117", borderTop: `2px solid ${accentClr}55`, display: "flex", flexDirection: "column", overflow: "hidden" }}>
                {/* Resize handle */}
                <div onMouseDown={startCodePanelResize} style={{ height: 5, cursor: "ns-resize", background: "#161B22", borderBottom: "1px solid #30363D", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <GripVertical size={12} style={{ color: "#8B949E", transform: "rotate(90deg)" }} />
                </div>

                {/* Panel header */}
                <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "5px 14px", borderBottom: "1px solid #30363D", flexShrink: 0, background: "#161B22" }}>
                  <span style={{ fontSize: 10, fontWeight: 800, color: "#F1F5F9", letterSpacing: 1 }}>MIGRATION CODE VIEWER</span>
                  <span style={{ fontSize: 9, color: "#8B949E" }}>CUST_IDENTITY + CUST_TAX_INFO → CUSTOMER_DEMOGRAPHICS</span>
                  <div style={{ flex: 1 }} />
                  {allDone
                    ? <span style={{ fontSize: 9, fontWeight: 700, color: "#10B981", background: "#10B98122", border: "1px solid #10B981", borderRadius: 10, padding: "2px 10px" }}>✓ All agents done — showing AFTER code</span>
                    : <span style={{ fontSize: 9, color: "#F59E0B", background: "#F59E0B18", border: "1px solid #F59E0B44", borderRadius: 10, padding: "2px 10px" }}>Showing BEFORE · Press ▶ Run Flow to see AFTER</span>
                  }
                  <button onClick={() => setShowCodePanel(false)} style={{ background: "none", border: "none", cursor: "pointer", color: "#8B949E", padding: 2 }}><X size={13} /></button>
                </div>

                {/* Single full-width pane — switches BEFORE → AFTER when all done */}
                <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 0, padding: "5px 10px 0", background: "#161B22", flexShrink: 0 }}>
                    <span style={{ fontSize: 9, fontWeight: 800, color: accentClr, marginRight: 10, letterSpacing: 1 }}>{sideLabel}</span>
                    {activeTabs.map((t, i) => tabBtn(t.label, activeTab === i, () => setActive(i), accentClr))}
                  </div>
                  {codeView(activeTabs[activeTab].code, accentClr + "66")}
                </div>
              </div>
            );
          })()}

        </div>

        {/* RIGHT INSPECTOR — resizable */}
        <div style={{ width: inspectorWidth, background: theme.panelBg, borderLeft: `1px solid ${theme.border}`, flexShrink: 0, overflow: "hidden", display: "flex" }}>
          {/* Drag resize handle */}
          <div onMouseDown={startInspectorResize} style={{ width: 5, cursor: "col-resize", background: theme.chip, borderRight: `1px solid ${theme.border}`, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", userSelect: "none" }}>
            <GripVertical size={12} style={{ color: theme.textMuted }} />
          </div>
          <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column" }}>
            {selectedConfig && selectedId && selectedNode ? (
              <Inspector
                nodeId={selectedId}
                config={selectedConfig}
                agentId={selectedNode.data.agentId}
                onUpdate={(cfg) => updateConfig(selectedId, cfg)}
                onRun={() => runAgent(selectedId)}
                onDelete={deleteSelectedNode}
                isRunning={runningAgentId === selectedId}
              />
            ) : (
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", color: theme.textMuted, textAlign: "center", padding: 24 }}>
                <Settings size={32} style={{ marginBottom: 12, opacity: 0.4 }} />
                <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8, color: theme.text }}>Agent Inspector</div>
                <div style={{ fontSize: 11, marginBottom: 20, lineHeight: 1.6 }}>Click any agent node on the canvas to open its configuration panel</div>
                <div style={{ width: "100%", textAlign: "left" }}>
                  {[
                    { tab: "Identity", desc: "Agent ID, display label, priority, run agent solo", color: "#3B82F6" },
                    { tab: "Prompt", desc: "System prompt, project context, temperature, token limit", color: "#A855F7" },
                    { tab: "Criteria", desc: "Acceptance criteria, Definition of Done, constraints", color: "#10B981" },
                    { tab: "Output", desc: "Format pills, schema, routing, failure handling", color: "#F59E0B" },
                    { tab: "Resources", desc: "Confluence links, GitHub, API specs, RAG context", color: "#06B6D4" },
                    { tab: "Activity", desc: "Execution logs, full output, copy to clipboard", color: "#EC4899" },
                  ].map(t => (
                    <div key={t.tab} style={{ display: "flex", gap: 10, padding: "8px 0", borderBottom: `1px solid ${theme.border}` }}>
                      <div style={{ width: 6, borderRadius: 3, background: t.color, flexShrink: 0 }} />
                      <div>
                        <div style={{ fontSize: 11, fontWeight: 700, color: "#1E293B", marginBottom: 2 }}>{t.tab}</div>
                        <div style={{ fontSize: 10, color: "#64748B", lineHeight: 1.4 }}>{t.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div style={{ marginTop: 20, fontSize: 9, color: "#64748B", textAlign: "center", lineHeight: 1.6 }}>
                  Drag the left edge of this panel to resize it
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* BOTTOM STATUS BAR */}
      <div style={{ height: 26, background: theme.panelBg, borderTop: `1px solid ${theme.border}`, display: "flex", alignItems: "center", padding: "0 16px", gap: 16, flexShrink: 0 }}>
        {[
          { label: "Nodes", value: nodes.length },
          { label: "Connections", value: edges.length },
          { label: "Files", value: parsedFiles.length },
          { label: "Selected", value: selectedId ? (selectedConfig?.label || selectedId) : "—" },
          { label: "Inspector", value: `${inspectorWidth}px` },
          { label: "Model", value: "GPT-4o" },
        ].map(({ label, value }) => (
          <div key={label} style={{ fontSize: 9, color: theme.textMuted }}>
            <span style={{ fontWeight: 700 }}>{label}:</span> <span style={{ color: theme.text }}>{value}</span>
          </div>
        ))}
      </div>

      {/* ── COMPLETION MODAL ────────────────────────────────────────────────── */}
      {showCompletionModal && (
        <div style={{
          position: "fixed", inset: 0, zIndex: 1000,
          background: "rgba(0,0,0,0.72)", backdropFilter: "blur(6px)",
          display: "flex", alignItems: "center", justifyContent: "center"
        }}>
          <div style={{
            background: "linear-gradient(145deg, #FFFFFF 0%, #F1F5F9 100%)",
            border: "1px solid #CBD5E1", borderRadius: 20,
            padding: "44px 48px", maxWidth: 520, width: "90%", textAlign: "center",
            boxShadow: "0 0 0 1px rgba(59,130,246,0.2), 0 24px 80px rgba(0,0,0,0.12)",
            animation: "modalIn 0.35s cubic-bezier(0.34,1.56,0.64,1)"
          }}>
            {/* Glow ring + check icon */}
            <div style={{ position: "relative", display: "inline-block", marginBottom: 24 }}>
              <div style={{
                width: 88, height: 88, borderRadius: "50%",
                background: "radial-gradient(circle, rgba(16,185,129,0.25) 0%, transparent 70%)",
                border: "2px solid #10B981", display: "flex", alignItems: "center",
                justifyContent: "center", margin: "0 auto",
                boxShadow: "0 0 32px rgba(16,185,129,0.4)"
              }}>
                <span style={{ fontSize: 40 }}>✅</span>
              </div>
              {/* Orbiting dots */}
              {[0,1,2,3].map(i => (
                <div key={i} style={{
                  position: "absolute", width: 8, height: 8, borderRadius: "50%",
                  background: ["#3B82F6","#A855F7","#10B981","#F59E0B"][i],
                  top: "50%", left: "50%",
                  transform: `rotate(${i*90}deg) translateX(52px) translateY(-50%)`,
                  animation: `orbit 3s linear ${i*0.75}s infinite`,
                  boxShadow: `0 0 8px ${["#3B82F6","#A855F7","#10B981","#F59E0B"][i]}`
                }} />
              ))}
            </div>

            {/* Title */}
            <div style={{ fontSize: 26, fontWeight: 800, color: "#1E293B", marginBottom: 8, fontFamily: "Syne, sans-serif" }}>
              All Agents Completed!
            </div>
            <div style={{ fontSize: 13, color: "#64748B", marginBottom: 28, lineHeight: 1.6 }}>
              Your SDLC pipeline has finished executing. All artefacts have been generated and are ready to review.
            </div>

            {/* Stats row */}
            <div style={{ display: "flex", justifyContent: "center", gap: 20, marginBottom: 28 }}>
              {[
                { icon: "🤖", value: completionStats.total, label: "Agents run" },
                { icon: "✅", value: completionStats.success, label: "Successful" },
                { icon: "📄", value: parsedFiles.length, label: "Files generated" },
              ].map(s => (
                <div key={s.label} style={{
                  background: "#F0F4FF", border: "1px solid #E2E8F0", borderRadius: 12,
                  padding: "14px 20px", minWidth: 100
                }}>
                  <div style={{ fontSize: 22, marginBottom: 4 }}>{s.icon}</div>
                  <div style={{ fontSize: 24, fontWeight: 800, color: "#1E293B", fontFamily: "Syne, sans-serif" }}>{s.value}</div>
                  <div style={{ fontSize: 10, color: "#64748B", fontWeight: 600, letterSpacing: 0.5, textTransform: "uppercase" }}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* CTA hint */}
            <div style={{
              background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.3)",
              borderRadius: 10, padding: "12px 16px", marginBottom: 28,
              display: "flex", alignItems: "center", gap: 10
            }}>
              <span style={{ fontSize: 18 }}>📁</span>
              <div style={{ textAlign: "left" }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: "#10B981", marginBottom: 2 }}>View Generated Code Files</div>
                <div style={{ fontSize: 11, color: "#64748B", lineHeight: 1.5 }}>
                  Click the <strong style={{ color: "#1E293B" }}>📁 Files</strong> button in the top toolbar to open the File Explorer and preview all generated source code, tests, and configs.
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
              <button onClick={() => { setShowCompletionModal(false); setShowFileExplorer(true); if (parsedFiles.length > 0) setSelectedFile(parsedFiles[0]); }}
                style={{
                  flex: 1, minWidth: 160, padding: "12px 0",
                  background: "linear-gradient(135deg, #10B981, #059669)",
                  color: "#fff", border: "none", borderRadius: 10, cursor: "pointer",
                  fontWeight: 800, fontSize: 13, fontFamily: "Syne, sans-serif",
                  boxShadow: "0 4px 16px rgba(16,185,129,0.35)"
                }}>
                📁 File Explorer
              </button>
              <button onClick={() => { setShowCompletionModal(false); goToArtifactsExplorer(); }}
                style={{
                  flex: 1, minWidth: 160, padding: "12px 0",
                  background: "linear-gradient(135deg, #1D4ED8, #3B82F6)",
                  color: "#fff", border: "none", borderRadius: 10, cursor: "pointer",
                  fontWeight: 800, fontSize: 13, fontFamily: "Syne, sans-serif",
                  boxShadow: "0 4px 16px rgba(59,130,246,0.35)"
                }}>
                📦 Full Explorer (New Page)
              </button>
              <button onClick={() => setShowCompletionModal(false)}
                style={{
                  padding: "12px 28px",
                  background: "#F1F5F9", color: "#64748B",
                  border: "1px solid #E2E8F0", borderRadius: 10, cursor: "pointer",
                  fontWeight: 700, fontSize: 13, fontFamily: "Syne, sans-serif"
                }}>
                OK
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── LOAD REPO MODAL ─────────────────────────────────────────────────── */}
      {showRepoModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)", zIndex: 9999, display: "flex", alignItems: "center", justifyContent: "center" }}
          onClick={e => { if (e.target === e.currentTarget) setShowRepoModal(false); }}>
          <div style={{ background: theme.panelBg, border: `1px solid ${theme.border}`, borderRadius: 14, width: 480, padding: 28, boxShadow: "0 24px 64px rgba(0,0,0,0.25)", fontFamily: "Syne, sans-serif" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
              <Github size={20} color="#3B82F6" />
              <span style={{ fontSize: 16, fontWeight: 800, color: theme.text }}>Load Git Repository</span>
              <button onClick={() => setShowRepoModal(false)} style={{ marginLeft: "auto", background: "none", border: "none", cursor: "pointer", color: theme.textMuted }}><X size={16} /></button>
            </div>
            <p style={{ fontSize: 12, color: theme.textMuted, marginBottom: 20, lineHeight: 1.6 }}>
              Enter any GitHub repo URL. The file structure, README and metadata are loaded as project context — every agent on the canvas will use it when running.
            </p>

            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: theme.textMuted, marginBottom: 4, letterSpacing: 0.5 }}>REPOSITORY URL <span style={{ color: "#EF4444" }}>*</span></div>
              <input
                value={repoUrl}
                onChange={e => setRepoUrl(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") loadRepoContext(); }}
                placeholder="https://github.com/owner/repo"
                style={{ width: "100%", padding: "8px 10px", borderRadius: 7, border: `1px solid ${theme.border}`, background: theme.chip, color: theme.text, fontSize: 12, fontFamily: "JetBrains Mono, monospace", boxSizing: "border-box" }}
                autoFocus
              />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 14 }}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: theme.textMuted, marginBottom: 4, letterSpacing: 0.5 }}>BRANCH</div>
                <input
                  value={repoBranch}
                  onChange={e => setRepoBranch(e.target.value)}
                  placeholder="main (default)"
                  style={{ width: "100%", padding: "8px 10px", borderRadius: 7, border: `1px solid ${theme.border}`, background: theme.chip, color: theme.text, fontSize: 12, fontFamily: "JetBrains Mono, monospace", boxSizing: "border-box" }}
                />
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: theme.textMuted, marginBottom: 4, letterSpacing: 0.5 }}>PAT TOKEN (private repos)</div>
                <input
                  value={repoToken}
                  onChange={e => setRepoToken(e.target.value)}
                  type="password"
                  placeholder="ghp_… (optional)"
                  style={{ width: "100%", padding: "8px 10px", borderRadius: 7, border: `1px solid ${theme.border}`, background: theme.chip, color: theme.text, fontSize: 12, fontFamily: "JetBrains Mono, monospace", boxSizing: "border-box" }}
                />
              </div>
            </div>

            <div style={{ background: darkMode ? "#0F172A" : "#F0F9FF", border: `1px solid ${darkMode ? "#1E3A5F" : "#BAE6FD"}`, borderRadius: 8, padding: "10px 14px", marginBottom: 20, fontSize: 11, color: darkMode ? "#94A3B8" : "#0369A1", lineHeight: 1.6 }}>
              <strong>Public repos</strong> work without a token (rate-limited to 60 req/hr). For private repos, add a GitHub Personal Access Token with <code>repo</code> scope. You can also connect one permanently via the <strong>GitHub Config</strong> page.
            </div>

            {loadedRepo && (
              <div style={{ background: darkMode ? "#064E3B" : "#ECFDF5", border: `1px solid #10B981`, borderRadius: 8, padding: "10px 14px", marginBottom: 16, fontSize: 11, color: "#065F46" }}>
                ✅ <strong>{loadedRepo.owner}/{loadedRepo.repo}</strong> is currently loaded — {loadedRepo.fileCount} files ({loadedRepo.language}). Loading a new repo will replace it.
              </div>
            )}

            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button onClick={() => setShowRepoModal(false)} style={{ padding: "8px 18px", borderRadius: 7, border: `1px solid ${theme.border}`, background: theme.chip, color: theme.textMuted, fontSize: 12, cursor: "pointer", fontFamily: "Syne, sans-serif" }}>
                Cancel
              </button>
              <button onClick={loadRepoContext} disabled={repoLoading || !repoUrl.trim()} style={{
                padding: "8px 20px", borderRadius: 7, border: "none",
                background: repoLoading || !repoUrl.trim() ? "#93C5FD" : "#3B82F6",
                color: "#fff", fontSize: 12, cursor: repoLoading || !repoUrl.trim() ? "not-allowed" : "pointer",
                fontFamily: "Syne, sans-serif", fontWeight: 700, display: "flex", alignItems: "center", gap: 6
              }}>
                {repoLoading ? <><span style={{ display: "inline-block", width: 12, height: 12, border: "2px solid #fff", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} /> Loading…</> : <><Github size={13} /> Load Repository</>}
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap');
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.5; } }
        @keyframes orbit { from { transform: rotate(var(--start,0deg)) translateX(52px) translateY(-50%); } to { transform: rotate(calc(var(--start,0deg) + 360deg)) translateX(52px) translateY(-50%); } }
        @keyframes modalIn { from { opacity:0; transform: scale(0.85) translateY(20px); } to { opacity:1; transform: scale(1) translateY(0); } }
        .react-flow__node { cursor: pointer; }
        .react-flow__controls button { background: ${theme.chip} !important; border: 1px solid ${theme.border} !important; color: ${theme.text} !important; }
        .react-flow__controls button:hover { background: ${theme.border} !important; }
        .react-flow__attribution { background: ${theme.panelBg} !important; color: ${theme.textMuted} !important; }
      `}</style>
    </div>
  );
}

function TopBtn({ icon, label, onClick, color, disabled }: { icon: React.ReactNode; label: string; onClick?: () => void; color?: string; disabled?: boolean }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      display: "flex", alignItems: "center", gap: 4, padding: "5px 10px",
      background: "#F1F5F9", border: "1px solid #E2E8F0", borderRadius: 6,
      cursor: disabled ? "not-allowed" : "pointer", fontSize: 11,
      color: disabled ? "#64748B" : (color || "#1E293B"), fontFamily: "Syne, sans-serif",
      opacity: disabled ? 0.6 : 1, transition: "all 0.15s"
    }}>{icon}{label}</button>
  );
}
