/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

// Demo project: Retail Banking — Customer Demographics Consolidation
// Migrating customer demographic data from two legacy tables (CUST_IDENTITY + CUST_TAX_INFO)
// into a single unified table (CUSTOMER_DEMOGRAPHICS)

export const DEMO_PROJECT_CONTEXT = `Project: Retail Banking — Customer Demographics Consolidation
Client: AMEX Diamond Project
Tech Stack: Spring Boot 3.2 / JPA / PostgreSQL 15 / Flyway 9
Source Tables: CUST_IDENTITY (Name, DOB, Customer ID) · CUST_TAX_INFO (Tax ID, Tax Type)
Target Table: CUSTOMER_DEMOGRAPHICS (unified, AES-256 encrypted Tax ID)
Compliance: GDPR, CCPA, PCI-DSS — all PII fields must be audited
Migration Strategy: LEFT JOIN consolidation → 90-day archived legacy tables → feature-flag cutover
Team: Diamond Team — Zensar Technologies`;

export const DEMO_OUTPUTS: Record<string, string> = {
  A01: `# 🎯 SDLC Orchestrator — Delivery Plan
**Project:** Customer Demographics Consolidation — Retail Banking
**Version:** v3.0.0 | **Date:** ${new Date().toLocaleDateString()}

---

## 📋 Project Summary
Two legacy tables — CUST_IDENTITY (2007) and CUST_TAX_INFO (2009) — store customer
demographic data (Name, DOB, Customer ID, Tax ID) in separate schemas owned by separate
teams. Every customer profile fetch requires 2 DB calls and a manual JOIN in Java.
This pipeline consolidates both into a single CUSTOMER_DEMOGRAPHICS table.

## 🔗 Recommended Agent Chain
\`\`\`
A01 (Orchestrator)
 → A06 (Requirements Intelligence)  — migration user story + NFRs
 → A08 (Solution Architecture)      — ADR-007: consolidation decision
 → A10 (Code Modernisation)         — 3-sprint migration plan + Flyway SQL
 → A09 (Engineering Delivery)       — unified JPA entity + updated service
 → A11 (Code Quality / Security)    — PII security findings
 → A12 (Test Engineering)           — migration validation tests
\`\`\`

## 🚦 Stage Gates

| Gate | Condition | Owner |
|------|-----------|-------|
| G1 — Requirements | PO sign-off on EPIC-042 and all NFRs | Kaushik Saha |
| G2 — Architecture | ADR-007 approved by Principal Architect | Ullas Krishnan |
| G3 — Migration SQL | DBA review of Flyway V3 script | Hrushikesh Nalawade |
| G4 — Code | Zero Critical/High PII findings in A11 output | Security Lead |
| G5 — Test | All 4 migration validation tests pass | QA Lead |
| G6 — Release | Feature flag enabled after 48h canary health green | Release Manager |

## ⚠️ Risk Flags
- Tax ID (SSN/EIN) is regulated PII — AES-256 encryption mandatory at column level
- LEFT JOIN migration must validate row counts before archive (zero data loss policy)
- 90-day rollback window required — legacy tables archived, not dropped
- Feature flag must control cutover to allow instant revert if p99 latency regresses

## 📅 Estimated Delivery
Sprint 1: Schema design + Flyway migration script + entity code
Sprint 2: Service refactor + PII audit + security hardening
Sprint 3: Test coverage + CI/CD pipeline + canary deploy + feature flag enablement`,

  A06: `# 📋 Requirements Intelligence — Customer Demographics Consolidation

## 🎯 Epic

**EPIC-042: Consolidate Customer Demographic Data into Single Table**
Consolidate CUST_IDENTITY and CUST_TAX_INFO into a single CUSTOMER_DEMOGRAPHICS table
to eliminate the two-call pattern, reduce p99 latency from ~120ms to ~50ms, and create
a single auditable PII surface for GDPR/CCPA compliance.

---

## 📖 User Story

**US-042-01 — Migrate Customer Demographics to Unified Table**

> As a backend engineer on the Customer Profile team,
> I want all customer demographic fields (Name, DOB, Customer ID, Tax ID)
> stored in a single CUSTOMER_DEMOGRAPHICS table,
> so that we can fetch a complete customer profile in a single DB call
> and maintain a single PII audit surface for GDPR compliance.

- **Story Points:** 13 | **Priority:** Must Have | **Sprint:** 1–3
- **Epic:** EPIC-042 | **Assignee:** Engineering Team | **Label:** data-migration, pii, compliance

### Acceptance Criteria (INVEST)

**AC-01 — Schema Migration**
- Given the Flyway V3 migration script runs on a clean PostgreSQL 15 instance,
  When \`flyway migrate\` completes,
  Then CUSTOMER_DEMOGRAPHICS table exists with all 7 columns defined in ADR-007.

**AC-02 — Zero Data Loss**
- Given CUST_IDENTITY has N rows and CUST_TAX_INFO has M rows (M ≤ N),
  When the LEFT JOIN migration INSERT completes,
  Then SELECT COUNT(*) FROM CUSTOMER_DEMOGRAPHICS equals N (all identity rows preserved).

**AC-03 — Single-Call Profile Fetch**
- Given a valid CUST_ID exists in CUSTOMER_DEMOGRAPHICS,
  When CustomerService.getProfile(custId) is called,
  Then exactly ONE SQL SELECT is issued (verified by Hibernate query count).

**AC-04 — p99 Latency Improvement**
- Given the production replica is seeded with 10,000 rows,
  When 500 concurrent getProfile() calls are executed,
  Then p99 latency is ≤ 50ms (down from baseline ~120ms).

**AC-05 — PII Encryption**
- Given a customer record with a Tax ID value,
  When the record is written to CUSTOMER_DEMOGRAPHICS,
  Then TAX_ID_NUM is stored AES-256 encrypted at the column level.

**AC-06 — GDPR Erasure**
- Given a GDPR erasure request for a CUST_ID,
  When DELETE FROM CUSTOMER_DEMOGRAPHICS WHERE CUST_ID = ? is executed,
  Then all PII for that customer is removed in a single statement.

---

## 🏗️ NFRs

| Category | Requirement | Target |
|----------|-------------|--------|
| Performance | getProfile() p99 latency | ≤ 50ms |
| Availability | Zero downtime migration | Blue/green deploy |
| Data Integrity | Row count post-migration | 100% — zero data loss |
| Security | Tax ID storage | AES-256 column encryption |
| Compliance | GDPR erasure | Single DELETE per customer |
| Rollback | Legacy table retention | 90 days archived |
| Observability | Migration progress | Row-count validation step in pipeline |

---

## 🔗 Traceability Matrix

| AC | Business Goal | Compliance Driver |
|----|---------------|-------------------|
| AC-01 | Unified data model | Engineering quality |
| AC-02 | Zero data loss guarantee | GDPR Art. 5 — data integrity |
| AC-03 | Reduce backend latency 58% | Performance SLA |
| AC-04 | p99 ≤ 50ms | Platform NFR |
| AC-05 | Protect regulated PII | PCI-DSS + GDPR Art. 32 |
| AC-06 | Right to erasure | GDPR Art. 17 |`,

  A08: `# 🏗️ Solution Architecture — ADR-007: Customer Demographics Consolidation

## Architecture Decision Record — ADR-007

**Status:** Accepted
**Date:** ${new Date().toLocaleDateString()}
**Deciders:** Ullas Krishnan (AI Solution Architect), Hrushikesh Nalawade (Solution Architect)
**Reviewed by:** Rajesh Madhai (VP — Products & Platforms)

---

## Context

The retail banking backend maintains customer demographic data across two separate
legacy tables created by independent teams in 2007 and 2009:

\`\`\`
CUST_IDENTITY       CUST_TAX_INFO
─────────────       ─────────────
CUST_ID (PK)        CUST_ID (PK → FK)
FIRST_NM            TAX_ID_NUM
LAST_NM             TAX_TYPE_CD
DT_OF_BIRTH
\`\`\`

Every customer profile lookup requires two separate JPA repository calls and
manual field assembly in CustomerService — the "two-call anti-pattern".
Measured p99 latency: ~120ms per profile fetch under production load.

---

## Decision

**Consolidate CUST_IDENTITY and CUST_TAX_INFO into a single table CUSTOMER_DEMOGRAPHICS.**

Target schema:
\`\`\`sql
CREATE TABLE CUSTOMER_DEMOGRAPHICS (
    CUST_ID       VARCHAR(20)  PRIMARY KEY,
    FIRST_NM      VARCHAR(50)  NOT NULL,
    LAST_NM       VARCHAR(50)  NOT NULL,
    DT_OF_BIRTH   DATE         NOT NULL,
    TAX_ID_NUM    VARCHAR(255),          -- AES-256 encrypted
    TAX_TYPE_CD   VARCHAR(10)  CHECK (TAX_TYPE_CD IN ('SSN','EIN','ITIN','FOREIGN')),
    MIGRATED_AT   TIMESTAMP    DEFAULT NOW(),
    VERSION       INTEGER      DEFAULT 0  -- optimistic locking
);
\`\`\`

---

## Rationale

| Option | Decision | Reason |
|--------|----------|--------|
| Keep two tables, add DB view | ❌ Rejected | View does not reduce I/O; PII surface still split |
| Merge via application-layer cache | ❌ Rejected | Cache invalidation complexity; PII in cache is GDPR risk |
| **Single consolidated table** | ✅ **Accepted** | Single DB call, single PII surface, simpler audit trail |

---

## Consequences

**Positive:**
- Single DB call per profile — projected p99 ~50ms (58% reduction)
- Single PII surface — GDPR erasure via one DELETE statement
- Optimistic locking (VERSION column) prevents concurrent update conflicts
- AES-256 column encryption on TAX_ID_NUM satisfies PCI-DSS requirement

**Negative / Mitigations:**
- Legacy tables CUST_IDENTITY and CUST_TAX_INFO renamed to _ARCHIVED, retained 90 days
- Feature flag \`demographics-consolidation.enabled\` controls cutover — instant revert
- CustomerService refactor required (A09) — estimated 2 sprints

---

## Migration Architecture

\`\`\`
Phase 1 (Sprint 1): Deploy v2 (new schema) with feature flag OFF
  ↓
Phase 2 (Sprint 2): Run Flyway V3 — LEFT JOIN INSERT into CUSTOMER_DEMOGRAPHICS
  ↓
Phase 3 (Sprint 3): Enable feature flag → monitor 48h → archive legacy tables
\`\`\`

---

## API Contract (OpenAPI 3.0 — unchanged, transparent to consumers)

\`\`\`yaml
paths:
  /api/v1/customers/{custId}/profile:
    get:
      summary: Get unified customer demographic profile
      parameters:
        - name: custId
          in: path
          required: true
          schema: { type: string }
      responses:
        200:
          content:
            application/json:
              schema:
                properties:
                  custId:      { type: string }
                  firstName:   { type: string }
                  lastName:    { type: string }
                  dateOfBirth: { type: string, format: date }
                  taxIdMasked: { type: string, example: "***-**-6789" }
                  taxType:     { type: string, enum: [SSN, EIN, ITIN, FOREIGN] }
\`\`\``,

  A10: `# 🗺️ Code Modernisation — Migration Plan: CUST_IDENTITY + CUST_TAX_INFO → CUSTOMER_DEMOGRAPHICS

## Executive Summary

This plan details the 3-sprint zero-downtime migration of customer demographic data
from two legacy PostgreSQL tables into a unified CUSTOMER_DEMOGRAPHICS table, following
the blue/green deployment pattern with feature-flag-controlled cutover.

---

## Current State Analysis

\`\`\`
BEFORE (Legacy Two-Table Pattern)
──────────────────────────────────
CustomerService.java — getProfile(custId)
  Step 1: identityRepo.findById(custId)    → SELECT * FROM CUST_IDENTITY WHERE CUST_ID = ?
  Step 2: taxRepo.findById(custId)         → SELECT * FROM CUST_TAX_INFO WHERE CUST_ID = ?
  Step 3: manual assembly in Java

Problems:
  ✗ 2 DB round-trips per profile fetch
  ✗ Orphan risk: tax record with no identity record
  ✗ Two separate PII audit surfaces (GDPR: must report both tables)
  ✗ p99 latency: ~120ms under load
  ✗ No optimistic locking — concurrent updates cause silent data corruption
\`\`\`

## Target State

\`\`\`
AFTER (Unified Table Pattern)
──────────────────────────────
CustomerService.java — getProfile(custId)
  Step 1: demographicsRepo.findById(custId) → SELECT * FROM CUSTOMER_DEMOGRAPHICS WHERE CUST_ID = ?

Gains:
  ✓ 1 DB round-trip per profile fetch
  ✓ Referential integrity enforced at schema level
  ✓ Single PII surface — GDPR erasure: 1 DELETE
  ✓ p99 latency target: ≤ 50ms (58% improvement)
  ✓ Optimistic locking via VERSION column
\`\`\`

---

## 3-Sprint Migration Roadmap

### Sprint 1 — Schema & Code (2 weeks)

| Task | Owner | Effort | Output |
|------|-------|--------|--------|
| Design CUSTOMER_DEMOGRAPHICS schema | A08 | Done | ADR-007 |
| Write Flyway V3 migration script | A10 | 2d | V3__consolidate_demographics.sql |
| Generate CustomerDemographics JPA entity | A09 | 1d | CustomerDemographics.java |
| Refactor CustomerService (feature flag) | A09 | 2d | CustomerService.java |
| DBA review of Flyway script | DBA | 1d | Signed-off migration plan |

### Sprint 2 — Security & Quality (2 weeks)

| Task | Owner | Effort | Output |
|------|-------|--------|--------|
| PII security audit | A11 | 1d | Security findings report |
| Implement AES-256 column encryption | A09 | 2d | Updated entity + @Convert |
| Code quality review | A11 | 1d | Quality scorecard |
| Integration testing on staging | A12 | 2d | Test report |
| Performance test (10K rows, 500 concurrent) | A12 | 1d | p99 latency measurement |

### Sprint 3 — Deploy & Cutover (1 week)

| Task | Owner | Effort | Output |
|------|-------|--------|--------|
| CI/CD pipeline update | A14 | 1d | GitHub Actions workflow |
| Deploy v2 to production (flag OFF) | A14 | 0.5d | Blue deployment |
| Run Flyway V3 on production | DBA | 0.5d | Migration complete |
| Validate row counts | A12 | 0.5d | Data integrity report |
| Enable feature flag | A14 | 0.5d | Cutover live |
| Monitor 48h (p99 + error rate) | Ops | 2d | Health report |
| Archive legacy tables (90-day retention) | DBA | 0.5d | CUST_IDENTITY_ARCHIVED |

---

## Flyway Migration Script — V3__consolidate_demographics.sql

\`\`\`sql
-- ============================================================
-- V3__consolidate_demographics.sql
-- Migrate CUST_IDENTITY + CUST_TAX_INFO → CUSTOMER_DEMOGRAPHICS
-- Author: Nucleus A10 · Date: ${new Date().toLocaleDateString()}
-- ============================================================

-- Step 1: Create target table
CREATE TABLE CUSTOMER_DEMOGRAPHICS (
    CUST_ID       VARCHAR(20)  PRIMARY KEY,
    FIRST_NM      VARCHAR(50)  NOT NULL,
    LAST_NM       VARCHAR(50)  NOT NULL,
    DT_OF_BIRTH   DATE         NOT NULL,
    TAX_ID_NUM    VARCHAR(255),
    TAX_TYPE_CD   VARCHAR(10)  CHECK (TAX_TYPE_CD IN ('SSN','EIN','ITIN','FOREIGN')),
    MIGRATED_AT   TIMESTAMP    NOT NULL DEFAULT NOW(),
    VERSION       INTEGER      NOT NULL DEFAULT 0
);

-- Step 2: Migrate data — LEFT JOIN preserves all identity rows
--         even if no corresponding tax record exists
INSERT INTO CUSTOMER_DEMOGRAPHICS
    (CUST_ID, FIRST_NM, LAST_NM, DT_OF_BIRTH,
     TAX_ID_NUM, TAX_TYPE_CD, MIGRATED_AT, VERSION)
SELECT
    i.CUST_ID,
    i.FIRST_NM,
    i.LAST_NM,
    i.DT_OF_BIRTH,
    t.TAX_ID_NUM,        -- NULL if no tax record (LEFT JOIN)
    t.TAX_TYPE_CD,       -- NULL if no tax record (LEFT JOIN)
    NOW(),
    0
FROM      CUST_IDENTITY  i
LEFT JOIN CUST_TAX_INFO  t ON i.CUST_ID = t.CUST_ID;

-- Step 3: Validate row count (must equal CUST_IDENTITY row count)
DO $$
DECLARE
    identity_count    INTEGER;
    migrated_count    INTEGER;
BEGIN
    SELECT COUNT(*) INTO identity_count    FROM CUST_IDENTITY;
    SELECT COUNT(*) INTO migrated_count    FROM CUSTOMER_DEMOGRAPHICS;
    IF migrated_count <> identity_count THEN
        RAISE EXCEPTION 'Migration row count mismatch: identity=% migrated=%',
            identity_count, migrated_count;
    END IF;
    RAISE NOTICE 'Migration validated: % rows successfully migrated', migrated_count;
END $$;

-- Step 4: Archive legacy tables (NOT dropped — 90-day retention policy)
ALTER TABLE CUST_IDENTITY  RENAME TO CUST_IDENTITY_ARCHIVED;
ALTER TABLE CUST_TAX_INFO  RENAME TO CUST_TAX_INFO_ARCHIVED;

-- Step 5: Create performance index
CREATE INDEX idx_demographics_cust_id   ON CUSTOMER_DEMOGRAPHICS (CUST_ID);
CREATE INDEX idx_demographics_last_nm   ON CUSTOMER_DEMOGRAPHICS (LAST_NM);
\`\`\`

---

## Rollback Plan

| Trigger | Action | RTO |
|---------|--------|-----|
| Row count mismatch | Migration script raises EXCEPTION — auto-rollback | Immediate |
| p99 > 100ms after cutover | Disable feature flag | < 1 min |
| P1 incident within 90 days | Re-enable legacy tables from _ARCHIVED | < 30 min |
| Data corruption detected | Point-in-time restore from pre-migration snapshot | < 2 hours |`,

  A09: `# 💻 Engineering Delivery — Unified CustomerDemographics Entity + Service

## CustomerDemographics.java — Unified JPA Entity

\`\`\`java
package com.bank.customer.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Unified customer demographic entity — consolidates CUST_IDENTITY + CUST_TAX_INFO.
 * Generated by Nucleus A09 as part of EPIC-042 (ADR-007).
 *
 * Tax ID is AES-256 encrypted at the column level via TaxIdAttributeConverter.
 * Optimistic locking via @Version prevents concurrent update conflicts.
 */
@Entity
@Table(name = "CUSTOMER_DEMOGRAPHICS")
public class CustomerDemographics {

    @Id
    @Column(name = "CUST_ID", length = 20, nullable = false)
    private String custId;

    @Column(name = "FIRST_NM", length = 50, nullable = false)
    private String firstName;

    @Column(name = "LAST_NM", length = 50, nullable = false)
    private String lastName;

    @Column(name = "DT_OF_BIRTH", nullable = false)
    private LocalDate dateOfBirth;

    /**
     * Tax ID Number (SSN / EIN / ITIN).
     * Stored AES-256 encrypted. Never logged. Never returned to client in plaintext.
     */
    @Convert(converter = TaxIdAttributeConverter.class)
    @Column(name = "TAX_ID_NUM", length = 255)
    private String taxIdNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "TAX_TYPE_CD", length = 10)
    private TaxType taxType;

    @CreationTimestamp
    @Column(name = "MIGRATED_AT", nullable = false, updatable = false)
    private LocalDateTime migratedAt;

    @Version
    @Column(name = "VERSION", nullable = false)
    private Integer version;

    public enum TaxType { SSN, EIN, ITIN, FOREIGN }

    // Constructors
    protected CustomerDemographics() {}

    public CustomerDemographics(String custId, String firstName, String lastName,
                                 LocalDate dateOfBirth) {
        this.custId = custId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
    }

    // Getters — no setters for PII fields (immutable after creation)
    public String getCustId()          { return custId; }
    public String getFirstName()       { return firstName; }
    public String getLastName()        { return lastName; }
    public LocalDate getDateOfBirth()  { return dateOfBirth; }
    public TaxType getTaxType()        { return taxType; }
    public LocalDateTime getMigratedAt() { return migratedAt; }
    public Integer getVersion()        { return version; }

    /** Returns last 4 digits only — NEVER return full Tax ID to callers */
    public String getMaskedTaxId() {
        if (taxIdNumber == null || taxIdNumber.length() < 4) return "****";
        return "***-**-" + taxIdNumber.substring(taxIdNumber.length() - 4);
    }

    public void setTaxDetails(String taxIdNumber, TaxType taxType) {
        this.taxIdNumber = taxIdNumber;
        this.taxType = taxType;
    }
}
\`\`\`

## CustomerService.java — Single-Call Profile Fetch

\`\`\`java
package com.bank.customer.service;

import com.bank.customer.entity.CustomerDemographics;
import com.bank.customer.repository.CustomerDemographicsRepository;
import com.bank.customer.dto.CustomerProfileResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.Optional;

/**
 * Refactored by Nucleus A09 for EPIC-042.
 *
 * BEFORE: two separate repository calls + manual field assembly
 * AFTER:  single repository call to CUSTOMER_DEMOGRAPHICS
 *
 * Feature flag 'demographics-consolidation.enabled' controls routing
 * during the canary deployment window (Sprint 3).
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class CustomerService {

    private final CustomerDemographicsRepository demographicsRepository;

    @Value("\${feature.demographics-consolidation.enabled:false}")
    private boolean demographicsConsolidationEnabled;

    /**
     * Fetch complete customer profile.
     * Single DB call to CUSTOMER_DEMOGRAPHICS when feature flag is enabled.
     */
    public CustomerProfileResponse getProfile(String custId) {
        log.info("Profile request — custId: {}***", custId.substring(0, 4));

        if (!demographicsConsolidationEnabled) {
            // Fallback: legacy two-call path (Sprint 1 + Sprint 2)
            return getLegacyProfile(custId);
        }

        // New single-call path (Sprint 3 — feature flag ON)
        CustomerDemographics demographics = demographicsRepository
            .findById(custId)
            .orElseThrow(() -> new CustomerNotFoundException(
                "Customer not found: " + custId.substring(0, 4) + "***"));

        return CustomerProfileResponse.builder()
            .custId(demographics.getCustId())
            .firstName(demographics.getFirstName())
            .lastName(demographics.getLastName())
            .dateOfBirth(demographics.getDateOfBirth())
            .taxIdMasked(demographics.getMaskedTaxId())   // NEVER expose full Tax ID
            .taxType(demographics.getTaxType() != null
                ? demographics.getTaxType().name() : null)
            .build();
    }

    private CustomerProfileResponse getLegacyProfile(String custId) {
        // Retained during canary window — removed after 90-day rollback period
        log.debug("Legacy profile path (feature flag OFF) for custId prefix: {}",
            custId.substring(0, 4));
        return legacyProfileAssembler.assemble(custId);
    }
}
\`\`\`

## CustomerDemographicsRepository.java

\`\`\`java
package com.bank.customer.repository;

import com.bank.customer.entity.CustomerDemographics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.Optional;

public interface CustomerDemographicsRepository
        extends JpaRepository<CustomerDemographics, String> {

    /** Single-query profile fetch — replaces two-table JOIN in legacy service */
    @Query("SELECT cd FROM CustomerDemographics cd WHERE cd.custId = :custId")
    Optional<CustomerDemographics> findById(String custId);
}
\`\`\``,

  A11: `# 🔍 Code Quality & Security Review — Customer Demographics Consolidation

## 📊 Quality Scorecard

| Dimension | Score | Status |
|-----------|-------|--------|
| Security / PII handling | 91/100 | ✅ Pass |
| Maintainability | 94/100 | ✅ Pass |
| Reliability | 88/100 | ✅ Pass |
| Performance | 92/100 | ✅ Pass |
| **Overall** | **91/100** | ✅ **PASS** |

---

## 🔒 PII Security Findings

**[HIGH] — Tax ID exposed in CustomerProfileResponse DTO**
- File: \`CustomerProfileResponse.java\`
- Issue: \`taxIdNumber\` field present as plaintext String on response object
- Risk: If serialised directly to JSON, Tax ID (SSN/EIN) is exposed in API response
- Fix: Remove \`taxIdNumber\` field; use \`taxIdMasked\` (last 4 digits only) — ALREADY
  applied in CustomerService via \`getMaskedTaxId()\`. Confirm DTO has NO plaintext field.
- Status: ✅ Mitigated in CustomerService — confirm DTO audit before merge

**[HIGH] — TaxIdAttributeConverter encryption key must come from secrets manager**
- File: \`TaxIdAttributeConverter.java\`
- Issue: AES-256 encryption key must NOT be hardcoded or stored in application.properties
- Risk: Key exposure = full Tax ID dataset decryption
- Fix: Inject key from AWS Secrets Manager or HashiCorp Vault via Spring \`@Value\`
  bound to environment variable \`TAX_ID_ENCRYPTION_KEY\`
- Status: ⚠️ Requires implementation before Sprint 3 deploy

**[MEDIUM] — Tax ID visible in Hibernate SQL debug logs**
- File: \`CustomerDemographicsRepository.java\`
- Issue: If \`spring.jpa.show-sql=true\` is set, encrypted Tax ID value appears in logs
- Risk: Encrypted value in logs is a GDPR audit finding (even if encrypted)
- Fix: Set \`spring.jpa.show-sql=false\` in production profile; use P6Spy with
  masking for dev environments only
- Status: ⚠️ Configuration fix required

**[MEDIUM] — Missing \`@Transactional\` on migration validation step**
- File: \`CustomerService.java\` (legacy path)
- Issue: getLegacyProfile() reads from two repositories without a transaction boundary
- Risk: Non-repeatable read if a record is updated between the two SELECT calls
- Fix: Add \`@Transactional(readOnly = true)\` to getLegacyProfile()
- Status: ⚠️ Fix before Sprint 2 deploy

**[LOW] — CustomerNotFoundException leaks custId prefix in message**
- File: \`CustomerService.java:38\`
- Issue: Even truncated custId in exception messages can leak enumeration information
  if exception messages reach API consumers
- Fix: Generic message: "Customer profile not found" (no identifier in message body)
  Log full details at DEBUG level with audit log only
- Status: 💡 Recommendation

---

## 🔒 GDPR Compliance Assessment

| Requirement | Status | Evidence |
|-------------|--------|---------|
| Single PII surface | ✅ Pass | CUSTOMER_DEMOGRAPHICS is the only live PII table |
| Right to erasure (Art. 17) | ✅ Pass | Single DELETE WHERE CUST_ID = ? removes all PII |
| Data minimisation (Art. 5) | ✅ Pass | Legacy tables archived, not retained indefinitely |
| Encryption at rest (Art. 32) | ⚠️ Partial | AES-256 implemented; key management fix needed |
| Audit trail | ✅ Pass | MIGRATED_AT + VERSION columns track record history |

---

## ✅ Merge Readiness: **CONDITIONAL GO**

Two HIGH findings require resolution before Sprint 3 production deploy:
1. Confirm CustomerProfileResponse DTO has no plaintext \`taxIdNumber\` field
2. Implement secrets-manager-backed encryption key injection

Estimated remediation: 4 hours. All other findings are LOW/MEDIUM and tracked in backlog.`,

  A12: `# 🧪 Test Engineering — Customer Demographics Migration Validation

## Migration Validation Test Suite (JUnit 5)

\`\`\`java
package com.bank.customer.migration;

import com.bank.customer.entity.CustomerDemographics;
import com.bank.customer.repository.CustomerDemographicsRepository;
import com.bank.customer.service.CustomerService;
import com.bank.customer.dto.CustomerProfileResponse;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import static org.assertj.core.api.Assertions.*;

/**
 * Migration validation tests — EPIC-042 / AC-01 through AC-06
 * Generated by Nucleus A12
 */
@SpringBootTest
@ActiveProfiles("test")
@TestPropertySource(properties = "feature.demographics-consolidation.enabled=true")
@DisplayName("Customer Demographics Migration — Validation Tests")
class CustomerDemographicsMigrationTest {

    @Autowired
    private CustomerDemographicsRepository demographicsRepository;

    @Autowired
    private CustomerService customerService;

    // ──────────────────────────────────────────────────────────
    // TC-01 — AC-01: Schema — all required columns exist
    // ──────────────────────────────────────────────────────────
    @Test
    @DisplayName("TC-01 — CUSTOMER_DEMOGRAPHICS table has all 8 required columns")
    void schema_AllRequiredColumnsExist() {
        CustomerDemographics demo = new CustomerDemographics(
            "CUST-TEST-001", "Jane", "Doe",
            java.time.LocalDate.of(1985, 6, 15));
        demo.setTaxDetails("078-05-1120", CustomerDemographics.TaxType.SSN);

        CustomerDemographics saved = demographicsRepository.save(demo);

        assertThat(saved.getCustId()).isEqualTo("CUST-TEST-001");
        assertThat(saved.getFirstName()).isEqualTo("Jane");
        assertThat(saved.getLastName()).isEqualTo("Doe");
        assertThat(saved.getDateOfBirth()).isEqualTo("1985-06-15");
        assertThat(saved.getTaxType()).isEqualTo(CustomerDemographics.TaxType.SSN);
        assertThat(saved.getMigratedAt()).isNotNull();
        assertThat(saved.getVersion()).isEqualTo(0);
    }

    // ──────────────────────────────────────────────────────────
    // TC-02 — AC-03 + AC-04: Single-call profile fetch
    // ──────────────────────────────────────────────────────────
    @Test
    @DisplayName("TC-02 — getProfile() issues exactly ONE SQL SELECT (single-call)")
    void getProfile_SingleDbCall_NoDualRepositoryAccess() {
        // Seed test data
        CustomerDemographics demo = demographicsRepository.save(
            new CustomerDemographics("CUST-TEST-002", "John", "Smith",
                java.time.LocalDate.of(1972, 3, 22)));

        // Capture SQL query count via Hibernate statistics
        org.hibernate.stat.Statistics stats =
            entityManager.getEntityManagerFactory()
                .unwrap(org.hibernate.SessionFactory.class)
                .getStatistics();
        stats.setStatisticsEnabled(true);
        long queriesBefore = stats.getQueryExecutionCount();

        CustomerProfileResponse profile = customerService.getProfile("CUST-TEST-002");

        long queriesAfter = stats.getQueryExecutionCount();

        // Exactly 1 query — not 2 as in legacy pattern
        assertThat(queriesAfter - queriesBefore).isEqualTo(1);
        assertThat(profile.getFirstName()).isEqualTo("John");
        assertThat(profile.getLastName()).isEqualTo("Smith");
    }

    // ──────────────────────────────────────────────────────────
    // TC-03 — AC-05: Tax ID is masked in API response
    // ──────────────────────────────────────────────────────────
    @Test
    @DisplayName("TC-03 — Tax ID is masked in response (last 4 digits only)")
    void getProfile_TaxId_IsMaskedInResponse() {
        CustomerDemographics demo = new CustomerDemographics(
            "CUST-TEST-003", "Alice", "Wang",
            java.time.LocalDate.of(1990, 11, 5));
        demo.setTaxDetails("123-45-6789", CustomerDemographics.TaxType.SSN);
        demographicsRepository.save(demo);

        CustomerProfileResponse profile = customerService.getProfile("CUST-TEST-003");

        // Full SSN must NEVER appear in API response
        assertThat(profile.getTaxIdMasked()).doesNotContain("123-45");
        assertThat(profile.getTaxIdMasked()).endsWith("6789");
        assertThat(profile.getTaxIdMasked()).startsWith("***");
    }

    // ──────────────────────────────────────────────────────────
    // TC-04 — AC-06: GDPR erasure — single DELETE removes all PII
    // ──────────────────────────────────────────────────────────
    @Test
    @DisplayName("TC-04 — GDPR erasure: DELETE by CUST_ID removes all PII in one call")
    void gdprErasure_SingleDelete_RemovesAllPii() {
        CustomerDemographics demo = new CustomerDemographics(
            "CUST-TEST-004", "Bob", "Brown",
            java.time.LocalDate.of(1968, 7, 19));
        demo.setTaxDetails("987-65-4321", CustomerDemographics.TaxType.SSN);
        demographicsRepository.save(demo);

        // Single DELETE — the GDPR erasure operation
        demographicsRepository.deleteById("CUST-TEST-004");

        // Verify all PII removed — no partial records
        assertThat(demographicsRepository.findById("CUST-TEST-004")).isEmpty();
    }
}
\`\`\`

## 📊 Test Coverage Summary

| Test Case | Acceptance Criteria | Status |
|-----------|---------------------|--------|
| TC-01 — Schema columns | AC-01 — all 8 columns present | ✅ Pass |
| TC-02 — Single DB call | AC-03 + AC-04 — 1 query, no dual-repo | ✅ Pass |
| TC-03 — Tax ID masked | AC-05 — PII encryption + masking | ✅ Pass |
| TC-04 — GDPR erasure | AC-06 — single DELETE removes all PII | ✅ Pass |

**Overall: 4/4 tests pass | All critical acceptance criteria covered**

## Performance Benchmark (10K rows · 500 concurrent calls)

| Metric | Before (Legacy) | After (Consolidated) | Delta |
|--------|----------------|---------------------|-------|
| p50 latency | 48ms | 22ms | -54% |
| p95 latency | 95ms | 41ms | -57% |
| p99 latency | 121ms | 49ms | -60% ✅ |
| Throughput | 820 req/s | 1,940 req/s | +137% |`
};

export const DEMO_CRITERIA: Record<string, string[]> = {
  A01: [
    "All 6 agents complete before stage advance",
    "Human approval required at architecture gate (ADR-007)",
    "Feature flag OFF until all tests pass",
    "Delivery plan reviewed by Rajesh Madhai (VP)"
  ],
  A06: [
    "EPIC-042 user story meets INVEST criteria",
    "All 6 acceptance criteria have measurable conditions",
    "NFRs captured with numeric targets (p99 ≤ 50ms)",
    "GDPR and PCI-DSS traceability documented"
  ],
  A08: [
    "ADR-007 explicitly states rejected alternatives with rationale",
    "OpenAPI 3.0 contract covers /profile endpoint",
    "Migration architecture phases clearly defined",
    "Decision approved by Ullas Krishnan (AI Solution Architect)"
  ],
  A10: [
    "Flyway V3 script uses LEFT JOIN — zero data loss guaranteed",
    "Row count validation step included in script (raises EXCEPTION on mismatch)",
    "Legacy tables renamed _ARCHIVED — NOT dropped (90-day retention)",
    "Feature flag controls cutover — instant revert path defined"
  ],
  A09: [
    "CustomerDemographics entity uses @Version for optimistic locking",
    "getMaskedTaxId() returns last 4 digits only — full Tax ID never exposed",
    "Feature flag wired in CustomerService for safe canary cutover",
    "No hardcoded encryption keys — key injected via @Value"
  ],
  A11: [
    "No Critical PII findings unresolved before Sprint 3 deploy",
    "All HIGH findings have explicit fix instructions and owners",
    "GDPR compliance table covers all 5 GDPR requirements",
    "Merge readiness verdict explicitly stated"
  ],
  A12: [
    "TC-01 validates all 8 schema columns present",
    "TC-02 verifies exactly 1 SQL query issued (Hibernate statistics)",
    "TC-03 confirms Tax ID is masked — full SSN never in response",
    "TC-04 verifies single DELETE satisfies GDPR erasure (AC-06)"
  ]
};

export const DEMO_FLOW_LAYOUT = [
  { id: "A01", pos: { x: 60,  y: 200 } },
  { id: "A06", pos: { x: 310, y: 60  } },
  { id: "A08", pos: { x: 560, y: 60  } },
  { id: "A10", pos: { x: 810, y: 60  } },
  { id: "A09", pos: { x: 810, y: 280 } },
  { id: "A11", pos: { x: 560, y: 280 } },
  { id: "A12", pos: { x: 310, y: 280 } },
];

export const DEMO_EDGES = [
  { source: "A01", target: "A06" },
  { source: "A06", target: "A08" },
  { source: "A08", target: "A10" },
  { source: "A10", target: "A09" },
  { source: "A09", target: "A11" },
  { source: "A11", target: "A12" },
  { source: "A01", target: "A12" },
];

// ─── Before/After Source Code ─────────────────────────────────────────────────

export const DEMO_BEFORE_CODE = {
  identity: `// ── BEFORE ─────────────────────────────────────────────────────────────
// CustomerIdentity.java
// Table: CUST_IDENTITY  (created 2007 — Identity Team)
// Problem: stores only Name + DOB; Tax ID lives in a separate table
// Every profile lookup requires TWO repository calls + manual JOIN

package com.bank.customer.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "CUST_IDENTITY")
public class CustomerIdentity {

    @Id
    @Column(name = "CUST_ID", length = 20, updatable = false)
    private String customerId;

    @Column(name = "FIRST_NM", nullable = false, length = 50)
    private String firstName;

    @Column(name = "LAST_NM", nullable = false, length = 50)
    private String lastName;

    @Column(name = "DT_OF_BIRTH", nullable = false)
    private LocalDate dateOfBirth;

    // ⚠  No Tax ID here — Tax data is in CUST_TAX_INFO table
    // ⚠  No optimistic locking — concurrent updates cause silent corruption
    // ⚠  No audit trail — no created/updated timestamps

    public String getCustomerId()       { return customerId; }
    public String getFirstName()        { return firstName; }
    public String getLastName()         { return lastName; }
    public LocalDate getDateOfBirth()   { return dateOfBirth; }
}`,

  tax: `// ── BEFORE ─────────────────────────────────────────────────────────────
// CustomerTaxInfo.java
// Table: CUST_TAX_INFO  (created 2009 — Tax Compliance Team)
// Problem: PII data (SSN/EIN) stored in a separate table, unencrypted
// Creates a second PII audit surface — GDPR erasure needs TWO DELETEs

package com.bank.customer.model;

import javax.persistence.*;

@Entity
@Table(name = "CUST_TAX_INFO")
public class CustomerTaxInfo {

    @Id
    @Column(name = "CUST_ID", length = 20)
    private String customerId;   // FK to CUST_IDENTITY — no FK constraint enforced!

    // ⚠  SSN/EIN stored as plain VARCHAR — no encryption
    @Column(name = "TAX_ID_NUM", length = 11)
    private String taxId;        // "078-05-1120" stored in plaintext

    @Column(name = "TAX_TYPE_CD", length = 3)
    private String taxType;      // "SSN" | "EIN" — no enum validation

    // ⚠  Orphan risk: tax records can exist without an identity record
    // ⚠  No version column — concurrent writes cause data corruption
    // ⚠  10,000 rows have NULL taxId (legacy records pre-2009)

    public String getCustomerId()   { return customerId; }
    public String getTaxId()        { return taxId; }
    public String getTaxType()      { return taxType; }
}`,

  service: `// ── BEFORE ─────────────────────────────────────────────────────────────
// CustomerService.java  — THE TWO-CALL ANTI-PATTERN
// Problem: every profile fetch = 2 DB round-trips + manual field assembly
// p99 latency under load: ~120ms  |  Orphan risk  |  No transaction boundary

package com.bank.customer.service;

import com.bank.customer.model.CustomerIdentity;
import com.bank.customer.model.CustomerTaxInfo;
import com.bank.customer.dto.CustomerProfileDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

    @Autowired private CustomerIdentityRepository identityRepo;  // → CUST_IDENTITY
    @Autowired private CustomerTaxInfoRepository  taxInfoRepo;   // → CUST_TAX_INFO

    public CustomerProfileDto getProfile(String customerId) {

        // ── DB Call 1 ──────────────────────────────────────────────────────
        CustomerIdentity identity = identityRepo.findById(customerId)
            .orElseThrow(() -> new CustomerNotFoundException(customerId));
        // Hibernate: SELECT * FROM CUST_IDENTITY WHERE CUST_ID = ?

        // ── DB Call 2 ──────────────────────────────────────────────────────
        CustomerTaxInfo taxInfo = taxInfoRepo.findById(customerId)
            .orElse(null);   // ⚠ May return null for 10,000 legacy records
        // Hibernate: SELECT * FROM CUST_TAX_INFO WHERE CUST_ID = ?

        // ── Manual assembly — error-prone ──────────────────────────────────
        return CustomerProfileDto.builder()
            .customerId(identity.getCustomerId())
            .firstName(identity.getFirstName())
            .lastName(identity.getLastName())
            .dateOfBirth(identity.getDateOfBirth())
            .taxId(taxInfo != null ? taxInfo.getTaxId() : null)      // ⚠ plaintext SSN
            .taxType(taxInfo != null ? taxInfo.getTaxType() : null)
            .build();
        // ⚠ No @Transactional — non-repeatable read if record updated between calls
        // ⚠ Two separate PII surfaces — GDPR erasure requires two DELETEs
    }
}`
};

export const DEMO_AFTER_CODE = {
  entity: `// ── AFTER — Generated by Nucleus A09 ────────────────────────────────
// CustomerDemographics.java
// Table: CUSTOMER_DEMOGRAPHICS  (Flyway V3 — unified schema)
// ✓ Single table: Name + DOB + Tax ID in one row
// ✓ AES-256 encrypted Tax ID via @Convert
// ✓ Optimistic locking with @Version
// ✓ Audit timestamp with @CreationTimestamp

package com.bank.customer.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "CUSTOMER_DEMOGRAPHICS",
    indexes = {
        @Index(name = "idx_demographics_last_nm", columnList = "LAST_NM"),
        @Index(name = "idx_demographics_dob",     columnList = "DT_OF_BIRTH")
    })
public class CustomerDemographics {

    @Id
    @Column(name = "CUST_ID", length = 20, updatable = false, nullable = false)
    private String custId;

    @Column(name = "FIRST_NM", nullable = false, length = 50)
    private String firstName;

    @Column(name = "LAST_NM", nullable = false, length = 50)
    private String lastName;

    @Column(name = "DT_OF_BIRTH", nullable = false)
    private LocalDate dateOfBirth;

    // ✓ Tax ID stored AES-256 encrypted — TaxIdAttributeConverter handles it
    @Convert(converter = TaxIdAttributeConverter.class)
    @Column(name = "TAX_ID_NUM", length = 255)
    private String taxIdNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "TAX_TYPE_CD", length = 10)
    private TaxType taxType;           // SSN | EIN | ITIN | FOREIGN

    // ✓ Audit trail
    @CreationTimestamp
    @Column(name = "MIGRATED_AT", nullable = false, updatable = false)
    private LocalDateTime migratedAt;

    // ✓ Optimistic locking — no more silent concurrent update corruption
    @Version
    @Column(name = "VERSION", nullable = false)
    private Integer version;

    public enum TaxType { SSN, EIN, ITIN, FOREIGN }

    protected CustomerDemographics() {}

    /** Returns last 4 digits only — full Tax ID NEVER exposed to callers */
    public String getMaskedTaxId() {
        if (taxIdNumber == null || taxIdNumber.length() < 4) return "****";
        return "***-**-" + taxIdNumber.substring(taxIdNumber.length() - 4);
    }

    public String getCustId()           { return custId; }
    public String getFirstName()        { return firstName; }
    public String getLastName()         { return lastName; }
    public LocalDate getDateOfBirth()   { return dateOfBirth; }
    public TaxType getTaxType()         { return taxType; }
    public LocalDateTime getMigratedAt(){ return migratedAt; }
    public Integer getVersion()         { return version; }
}`,

  service: `// ── AFTER — Refactored by Nucleus A09 ───────────────────────────────
// CustomerService.java  — SINGLE-CALL PATTERN
// ✓ One repository call to CUSTOMER_DEMOGRAPHICS
// ✓ p99 latency: ~49ms (was ~120ms — 59% improvement)
// ✓ @Transactional(readOnly=true) — safe concurrent reads
// ✓ Feature flag controls cutover — instant rollback if needed

package com.bank.customer.service;

import com.bank.customer.entity.CustomerDemographics;
import com.bank.customer.repository.CustomerDemographicsRepository;
import com.bank.customer.dto.CustomerProfileResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomerService {

    // ✓ ONE repository — replaces identityRepo + taxInfoRepo
    private final CustomerDemographicsRepository demographicsRepo;

    @Value("\${feature.demographics-consolidation.enabled:false}")
    private boolean consolidationEnabled;

    @Transactional(readOnly = true)
    public CustomerProfileResponse getProfile(String custId) {
        log.info("Profile request — prefix: {}***", custId.substring(0, 4));

        if (!consolidationEnabled) {
            return getLegacyProfile(custId);   // fallback during canary window
        }

        // ── Single DB call — replaces the two-call anti-pattern ────────────
        CustomerDemographics demo = demographicsRepo
            .findById(custId)
            .orElseThrow(() -> new CustomerNotFoundException("Customer not found"));
        // Hibernate: SELECT * FROM CUSTOMER_DEMOGRAPHICS WHERE CUST_ID = ?
        // One round-trip. All fields. No assembly.

        return CustomerProfileResponse.builder()
            .custId(demo.getCustId())
            .firstName(demo.getFirstName())
            .lastName(demo.getLastName())
            .dateOfBirth(demo.getDateOfBirth())
            .taxIdMasked(demo.getMaskedTaxId())  // ✓ last 4 digits only
            .taxType(demo.getTaxType() != null ? demo.getTaxType().name() : null)
            .build();
    }

    private CustomerProfileResponse getLegacyProfile(String custId) {
        // Retained for 90-day rollback window — removed after Sprint 3
        log.debug("Legacy path (flag OFF) — custId prefix: {}", custId.substring(0, 4));
        return legacyAssembler.assemble(custId);
    }
}`,

  migration: `-- ── AFTER — Generated by Nucleus A10 ────────────────────────────────
-- V3__consolidate_customer_demographics.sql
-- Flyway migration — runs automatically on deploy
-- ✓ LEFT JOIN: zero data loss (preserves records without tax info)
-- ✓ Row count validation: script aborts if counts mismatch
-- ✓ Legacy tables archived (NOT dropped) — 90-day rollback window

-- ════════════════════════════════════════════════════════════════════
-- Step 1: Create unified target table
-- ════════════════════════════════════════════════════════════════════
CREATE TABLE CUSTOMER_DEMOGRAPHICS (
    CUST_ID       VARCHAR(20)  NOT NULL PRIMARY KEY,
    FIRST_NM      VARCHAR(50)  NOT NULL,
    LAST_NM       VARCHAR(50)  NOT NULL,
    DT_OF_BIRTH   DATE         NOT NULL,
    TAX_ID_NUM    VARCHAR(255),            -- AES-256 encrypted at app layer
    TAX_TYPE_CD   VARCHAR(10)
        CHECK (TAX_TYPE_CD IN ('SSN','EIN','ITIN','FOREIGN')),
    MIGRATED_AT   TIMESTAMP    NOT NULL DEFAULT NOW(),
    VERSION       INTEGER      NOT NULL DEFAULT 0
);

-- ════════════════════════════════════════════════════════════════════
-- Step 2: Migrate — LEFT JOIN preserves all 10,000 identity rows
--         even if no corresponding tax record exists
-- ════════════════════════════════════════════════════════════════════
INSERT INTO CUSTOMER_DEMOGRAPHICS
    (CUST_ID, FIRST_NM, LAST_NM, DT_OF_BIRTH,
     TAX_ID_NUM, TAX_TYPE_CD, MIGRATED_AT, VERSION)
SELECT
    i.CUST_ID,
    i.FIRST_NM,
    i.LAST_NM,
    i.DT_OF_BIRTH,
    t.TAX_ID_NUM,    -- NULL for ~10,000 legacy records without tax info
    t.TAX_TYPE_CD,
    NOW(),
    0
FROM      CUST_IDENTITY  i
LEFT JOIN CUST_TAX_INFO  t ON i.CUST_ID = t.CUST_ID;

-- ════════════════════════════════════════════════════════════════════
-- Step 3: Validate row counts — abort if mismatch (zero data loss policy)
-- ════════════════════════════════════════════════════════════════════
DO $$
DECLARE
    src_count  INTEGER;
    tgt_count  INTEGER;
BEGIN
    SELECT COUNT(*) INTO src_count FROM CUST_IDENTITY;
    SELECT COUNT(*) INTO tgt_count FROM CUSTOMER_DEMOGRAPHICS;
    IF tgt_count <> src_count THEN
        RAISE EXCEPTION 'Row count mismatch: CUST_IDENTITY=% CUSTOMER_DEMOGRAPHICS=%',
            src_count, tgt_count;
    END IF;
    RAISE NOTICE 'Migration OK — % rows migrated', tgt_count;
END $$;

-- ════════════════════════════════════════════════════════════════════
-- Step 4: Archive legacy tables — NOT dropped (90-day retention policy)
-- ════════════════════════════════════════════════════════════════════
ALTER TABLE CUST_IDENTITY  RENAME TO CUST_IDENTITY_ARCHIVED;
ALTER TABLE CUST_TAX_INFO  RENAME TO CUST_TAX_INFO_ARCHIVED;

-- ════════════════════════════════════════════════════════════════════
-- Step 5: Indexes for query performance
-- ════════════════════════════════════════════════════════════════════
CREATE INDEX idx_demographics_cust_id  ON CUSTOMER_DEMOGRAPHICS (CUST_ID);
CREATE INDEX idx_demographics_last_nm  ON CUSTOMER_DEMOGRAPHICS (LAST_NM);
CREATE INDEX idx_demographics_dob      ON CUSTOMER_DEMOGRAPHICS (DT_OF_BIRTH);

-- Result: single-table profile fetch, p99 ~49ms (was ~120ms)`
};
