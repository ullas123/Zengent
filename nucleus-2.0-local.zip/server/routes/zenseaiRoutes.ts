/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { Router } from "express";
import { requireAuth } from "../auth";
import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";
import { storage } from "../storage";
import { aiKeyStore } from "../services/aiKeyStore";

const router = Router();

/**
 * Returns a fresh Anthropic client using the active key (user-provided → env var).
 * Returns null when no key is available.
 */
function getAnthropicClient(): Anthropic | null {
  const key = aiKeyStore.getAnthropicKey();
  if (!key) return null;
  return new Anthropic({
    apiKey: key,
    defaultHeaders: { "anthropic-beta": "prompt-caching-2024-07-31" },
  });
}

/**
 * Returns a fresh OpenAI client using the active key (user-provided → env var).
 */
function getOpenAIClient(): OpenAI {
  return new OpenAI({ apiKey: aiKeyStore.getOpenAIKey() });
}

const GITHUB_API = "https://api.github.com";

// ── Claude model routing ──────────────────────────────────────────────────────
// All agents use Claude when key is available (prompt caching benefits all)
const CLAUDE_AGENTS = new Set([
  "A01","A02","A03","A04","A05","A06","A07",
  "A08","A09","A10","A11","A12","A13","A14","A15"
]);

// A01 (Orchestrator) and A08 (Architecture) get Extended Thinking
const THINKING_AGENTS = new Set(["A01", "A08"]);

// Higher token ceiling for code-heavy agents
const AGENT_TOKEN_CEILING: Record<string, number> = {
  A01: 16000, A08: 16000,
  A09: 8000,  A10: 8000,  A11: 8000,
  A12: 6000,  A13: 6000,
};

function resolveModel(agentId: string): string {
  if (THINKING_AGENTS.has(agentId)) return "claude-sonnet-4-5";
  return "claude-opus-4-5";
}

const MIN_THINKING_BUDGET = 1024;   // Anthropic hard minimum for budget_tokens
const MIN_THINKING_MAX    = 2048;   // must be > budget_tokens; leave room for output

function resolveMaxTokens(agentId: string, requested: number): number {
  const ceiling = AGENT_TOKEN_CEILING[agentId] ?? 4000;
  const base = Math.min(Math.max(requested || 2000, 1024), ceiling);
  // Thinking agents need at least MIN_THINKING_MAX so budget_tokens can be >= 1024
  if (THINKING_AGENTS.has(agentId)) return Math.max(base, MIN_THINKING_MAX);
  return base;
}

function resolveThinkingBudget(maxTokens: number): number {
  // budget_tokens must be >= 1024 AND < max_tokens
  const budget = Math.max(MIN_THINKING_BUDGET, Math.floor(maxTokens * 0.5));
  return Math.min(budget, maxTokens - 1);
}

function buildPromptParts(body: any): { contextBlock: string; taskMessage: string } {
  const {
    additionalInstructions, criteria, ragContext,
    outputFormats, outputSchema, upstreamContext, language
  } = body;

  const contextParts: string[] = [];
  if (additionalInstructions?.trim())
    contextParts.push(`## Project Context & Instructions\n${additionalInstructions}`);
  if (ragContext?.trim())
    contextParts.push(`## Reference Context (RAG)\n${ragContext}`);

  const taskParts: string[] = [];
  if (criteria?.length > 0)
    taskParts.push(`## Acceptance Criteria\n${criteria.map((c: string, i: number) => `${i + 1}. ${c}`).join("\n")}`);
  if (outputFormats?.length > 0)
    taskParts.push(`## Output Format\nRespond in the following format(s): ${outputFormats.join(", ")}`);
  if (outputSchema?.trim())
    taskParts.push(`## Output Schema\nStructure your output to match:\n${outputSchema}`);
  if (upstreamContext?.trim())
    taskParts.push(`## Context from Previous Agents\n${upstreamContext}`);
  if (language && language !== "English")
    taskParts.push(`## Language\nRespond in ${language}.`);

  return {
    contextBlock: contextParts.join("\n\n"),
    taskMessage: taskParts.join("\n\n") || "Proceed with your SDLC analysis.",
  };
}

// ── Streaming endpoint (primary — used by all agent runs) ─────────────────────
router.post("/run-agent-stream", requireAuth, async (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");

  const send = (payload: object) => {
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
    if ((res as any).flush) (res as any).flush();
  };

  const { agentId = "", systemPrompt = "", temperature = 0.7, maxTokens = 2000 } = req.body;
  if (!systemPrompt) { send({ error: "systemPrompt is required" }); return res.end(); }

  const { contextBlock, taskMessage } = buildPromptParts(req.body);
  const start = Date.now();

  // ── Claude path ────────────────────────────────────────────────────────────
  const anthropic = getAnthropicClient();
  if (anthropic && CLAUDE_AGENTS.has(agentId)) {
    const useThinking = THINKING_AGENTS.has(agentId);
    const model = resolveModel(agentId);
    const effectiveMax = resolveMaxTokens(agentId, maxTokens);

    const systemContent: Anthropic.Messages.TextBlockParam[] = [{
      type: "text",
      text: systemPrompt,
      // @ts-ignore – cache_control is valid with the beta header
      cache_control: { type: "ephemeral" },
    }];

    const userContent: Anthropic.Messages.ContentBlockParam[] = [];
    if (contextBlock) {
      userContent.push({
        type: "text",
        text: contextBlock,
        // @ts-ignore
        cache_control: { type: "ephemeral" },
      });
    }
    userContent.push({ type: "text", text: taskMessage });

    const params: any = {
      model,
      max_tokens: effectiveMax,
      system: systemContent,
      messages: [{ role: "user", content: userContent }],
    };

    if (useThinking) {
      params.thinking = { type: "enabled", budget_tokens: resolveThinkingBudget(effectiveMax) };
    } else {
      params.temperature = Math.min(Math.max(temperature, 0), 1);
    }

    try {
      const stream = await anthropic.messages.create({ ...params, stream: true });
      let inputTokens = 0; let outputTokens = 0;

      for await (const event of stream as any) {
        if (event.type === "content_block_delta") {
          if (event.delta?.type === "text_delta" && event.delta.text) {
            send({ text: event.delta.text });
          }
        }
        if (event.type === "message_delta" && event.usage) {
          outputTokens = event.usage.output_tokens || 0;
        }
        if (event.type === "message_start" && event.message?.usage) {
          inputTokens = event.message.usage.input_tokens || 0;
        }
      }

      const modelLabel = useThinking
        ? `Claude ${model} + Extended Thinking`
        : `Claude ${model}`;

      send({
        done: true,
        tokens: inputTokens + outputTokens,
        inputTokens,
        outputTokens,
        duration: Date.now() - start,
        model: modelLabel,
        cached: true,
      });
      return res.end();
    } catch (err: any) {
      console.error("Claude stream error:", err?.message);
      send({ error: err?.message || "Claude streaming failed" });
      return res.end();
    }
  }

  // ── GPT-4o fallback (when no Anthropic key) ────────────────────────────────
  const openaiKey = aiKeyStore.getOpenAIKey();
  if (!openaiKey) {
    send({ error: "No AI key configured. Please provide an Anthropic or OpenAI API key in AI Settings." });
    return res.end();
  }

  try {
    const parts = [contextBlock, taskMessage].filter(Boolean).join("\n\n");
    const gptStream = await getOpenAIClient().chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: parts },
      ],
      temperature: Math.min(Math.max(temperature, 0), 1),
      max_tokens: Math.min(maxTokens || 1500, 4000),
      stream: true,
      stream_options: { include_usage: true },
    });

    let totalTokens = 0;
    for await (const chunk of gptStream) {
      const text = chunk.choices[0]?.delta?.content || "";
      if (text) send({ text });
      if (chunk.usage) totalTokens = chunk.usage.total_tokens;
    }

    send({ done: true, tokens: totalTokens, duration: Date.now() - start, model: "GPT-4o", cached: false });
    return res.end();
  } catch (err: any) {
    send({ error: err?.message || "GPT-4o streaming failed" });
    return res.end();
  }
});

// ── Non-streaming endpoint (kept for compatibility / run-flow) ────────────────
router.post("/run-agent", requireAuth, async (req, res) => {
  const { agentId = "", systemPrompt = "", temperature = 0.7, maxTokens = 2000 } = req.body;
  if (!systemPrompt) return res.status(400).json({ error: "systemPrompt is required" });

  const { contextBlock, taskMessage } = buildPromptParts(req.body);
  const start = Date.now();

  // Claude path
  const anthropic = getAnthropicClient();
  if (anthropic && CLAUDE_AGENTS.has(agentId)) {
    const useThinking = THINKING_AGENTS.has(agentId);
    const model = resolveModel(agentId);
    const effectiveMax = resolveMaxTokens(agentId, maxTokens);

    const systemContent: any[] = [{
      type: "text", text: systemPrompt,
      cache_control: { type: "ephemeral" },
    }];
    const userContent: any[] = [];
    if (contextBlock) userContent.push({ type: "text", text: contextBlock, cache_control: { type: "ephemeral" } });
    userContent.push({ type: "text", text: taskMessage });

    const params: any = {
      model, max_tokens: effectiveMax,
      system: systemContent,
      messages: [{ role: "user", content: userContent }],
    };
    if (useThinking) {
      params.thinking = { type: "enabled", budget_tokens: resolveThinkingBudget(effectiveMax) };
    } else {
      params.temperature = Math.min(Math.max(temperature, 0), 1);
    }

    try {
      const response = await anthropic.messages.create(params);
      const textBlock = response.content.find((b: any) => b.type === "text") as any;
      const output = textBlock?.text || "";
      const tokens = (response.usage?.input_tokens || 0) + (response.usage?.output_tokens || 0);
      const modelLabel = useThinking ? `Claude ${model} + Extended Thinking` : `Claude ${model}`;
      return res.json({ success: true, output, tokens, duration: Date.now() - start, model: modelLabel, agentId });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err?.message, output: `Claude error: ${err?.message}` });
    }
  }

  // GPT-4o fallback
  try {
    const parts = [contextBlock, taskMessage].filter(Boolean).join("\n\n");
    const response = await getOpenAIClient().chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: parts },
      ],
      temperature: Math.min(Math.max(temperature, 0), 1),
      max_tokens: Math.min(maxTokens || 1500, 4000),
    });
    const output = response.choices[0]?.message?.content || "";
    const tokens = response.usage?.total_tokens || 0;
    return res.json({ success: true, output, tokens, duration: Date.now() - start, model: "GPT-4o", agentId });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error?.message, output: `Error: ${error?.message}` });
  }
});

// ── Run-flow endpoint (sequential, server-side) ───────────────────────────────
router.post("/run-flow", requireAuth, async (req, res) => {
  const { agents } = req.body;
  const results: any[] = [];

  for (const agent of agents) {
    const { agentId = "", systemPrompt = "", temperature, maxTokens } = agent;
    const body = {
      ...agent,
      upstreamContext: results.length > 0
        ? results.slice(-2).map((r: any) => `### Output from ${r.agentName}:\n${r.output?.substring(0, 800)}`).join("\n\n")
        : "",
    };
    const { contextBlock, taskMessage } = buildPromptParts(body);
    const start = Date.now();

    try {
      let output = ""; let tokens = 0; let model = "GPT-4o";

      const anthropic = getAnthropicClient();
      if (anthropic && CLAUDE_AGENTS.has(agentId)) {
        const useThinking = THINKING_AGENTS.has(agentId);
        const m = resolveModel(agentId);
        const effectiveMax = resolveMaxTokens(agentId, maxTokens || 2000);
        const systemContent: any[] = [{ type: "text", text: systemPrompt, cache_control: { type: "ephemeral" } }];
        const userContent: any[] = [];
        if (contextBlock) userContent.push({ type: "text", text: contextBlock, cache_control: { type: "ephemeral" } });
        userContent.push({ type: "text", text: taskMessage });
        const params: any = { model: m, max_tokens: effectiveMax, system: systemContent, messages: [{ role: "user", content: userContent }] };
        if (useThinking) params.thinking = { type: "enabled", budget_tokens: resolveThinkingBudget(effectiveMax) };
        else params.temperature = Math.min(Math.max(temperature ?? 0.7, 0), 1);
        const resp = await anthropic.messages.create(params);
        const tb = resp.content.find((b: any) => b.type === "text") as any;
        output = tb?.text || "";
        tokens = (resp.usage?.input_tokens || 0) + (resp.usage?.output_tokens || 0);
        model = useThinking ? `Claude ${m} + Thinking` : `Claude ${m}`;
      } else {
        const parts = [contextBlock, taskMessage].filter(Boolean).join("\n\n");
        const resp = await getOpenAIClient().chat.completions.create({
          model: "gpt-4o",
          messages: [{ role: "system", content: systemPrompt }, { role: "user", content: parts }],
          temperature: temperature ?? 0.7,
          max_tokens: Math.min(maxTokens ?? 2000, 4000),
        });
        output = resp.choices[0]?.message?.content || "";
        tokens = resp.usage?.total_tokens || 0;
      }

      results.push({ agentId, agentName: agent.agentName, success: true, output, tokens, duration: Date.now() - start, model, timestamp: new Date().toISOString() });
    } catch (error: any) {
      results.push({ agentId, agentName: agent.agentName, success: false, output: `Error: ${error?.message}`, tokens: 0, duration: 0, timestamp: new Date().toISOString() });
    }
  }

  res.json({ success: true, results });
});

// ── GitHub helpers ────────────────────────────────────────────────────────────

function githubHeaders(token: string) {
  return {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
  };
}

router.get("/github/config", requireAuth, async (_req, res) => {
  const config = await storage.getGithubConfig();
  if (!config) return res.json({ connected: false });
  res.json({ connected: true, owner: config.owner, repo: config.repo, branch: config.branch, tokenSet: !!config.token });
});

router.post("/github/config", requireAuth, async (req, res) => {
  const { token, owner, repo, branch } = req.body || {};
  if (!token || !owner || !repo) return res.status(400).json({ error: "token, owner and repo are required" });
  try {
    const verifyRes = await fetch(`${GITHUB_API}/repos/${owner}/${repo}`, { headers: githubHeaders(token) });
    if (!verifyRes.ok) {
      const body = await verifyRes.text();
      return res.status(400).json({ error: `Could not access repo ${owner}/${repo}: ${verifyRes.status} ${body.slice(0, 200)}` });
    }
    await storage.setGithubConfig({ token, owner, repo, branch: branch || "main" });
    res.json({ success: true, owner, repo, branch: branch || "main" });
  } catch (error: any) {
    res.status(500).json({ error: error?.message || "Failed to verify GitHub credentials" });
  }
});

router.delete("/github/config", requireAuth, async (_req, res) => {
  await storage.setGithubConfig({ token: "", owner: "", repo: "", branch: "" });
  res.json({ success: true });
});

router.post("/github/push", requireAuth, async (req, res) => {
  const config = await storage.getGithubConfig();
  if (!config?.token) return res.status(400).json({ error: "GitHub is not connected. Configure it first." });

  const { files, message } = req.body as { files: Array<{ path: string; content: string }>; message?: string };
  if (!Array.isArray(files) || files.length === 0) return res.status(400).json({ error: "No files provided to push" });

  const { token, owner, repo, branch } = config;
  const results: Array<{ path: string; success: boolean; error?: string }> = [];

  for (const file of files) {
    try {
      let sha: string | undefined;
      const existingRes = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/contents/${encodeURI(file.path)}?ref=${branch}`, { headers: githubHeaders(token) });
      if (existingRes.ok) { const existing = await existingRes.json(); sha = existing.sha; }
      const putRes = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/contents/${encodeURI(file.path)}`, {
        method: "PUT",
        headers: { ...githubHeaders(token), "Content-Type": "application/json" },
        body: JSON.stringify({ message: message || `Update ${file.path} via Nucleus Agent Factory`, content: Buffer.from(file.content, "utf-8").toString("base64"), branch, ...(sha ? { sha } : {}) }),
      });
      if (!putRes.ok) { const body = await putRes.text(); results.push({ path: file.path, success: false, error: `${putRes.status}: ${body.slice(0, 200)}` }); }
      else results.push({ path: file.path, success: true });
    } catch (error: any) {
      results.push({ path: file.path, success: false, error: error?.message || "Unknown error" });
    }
  }

  const failed = results.filter(r => !r.success);
  res.json({ success: failed.length === 0, results, pushedCount: results.length - failed.length, failedCount: failed.length });
});

router.post("/github/load-repo", requireAuth, async (req, res) => {
  const { url, token, branch } = req.body;
  if (!url) return res.status(400).json({ error: "url is required" });

  const match = url.trim().replace(/\.git$/, "").match(/github\.com[\/:]([^\/]+)\/([^\/]+)/);
  if (!match) return res.status(400).json({ error: "Could not parse GitHub URL. Use format: https://github.com/owner/repo" });

  const owner = match[1]; const repo = match[2];
  const storedCfg = await storage.getGithubConfig();
  const authToken = token?.trim() || storedCfg?.token || "";
  const targetBranch = branch?.trim() || storedCfg?.branch || "main";

  const baseHeaders: Record<string, string> = { Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "Nucleus-2.0" };
  if (authToken) baseHeaders["Authorization"] = `Bearer ${authToken}`;

  try {
    const metaRes = await fetch(`${GITHUB_API}/repos/${owner}/${repo}`, { headers: baseHeaders });
    if (!metaRes.ok) { const body = await metaRes.text(); return res.status(metaRes.status).json({ error: `Repository not found or access denied: ${body.slice(0, 200)}` }); }
    const meta = await metaRes.json();
    const defaultBranch: string = meta.default_branch || "main";
    const useBranch = targetBranch === "main" ? defaultBranch : targetBranch;

    const treeRes = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/git/trees/${useBranch}?recursive=1`, { headers: baseHeaders });
    const treeData = treeRes.ok ? await treeRes.json() : { tree: [] };
    const allBlobs: any[] = (treeData.tree || []).filter((t: any) => t.type === "blob");
    const fileTree = allBlobs.map((b: any) => b.path);

    let readme = "";
    const readmePath = allBlobs.find((b: any) => /^readme(\.(md|txt|rst))?$/i.test(b.path));
    if (readmePath) {
      const rRes = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/git/blobs/${readmePath.sha}`, { headers: baseHeaders });
      if (rRes.ok) { const rData = await rRes.json(); const raw = rData.encoding === "base64" ? Buffer.from(rData.content, "base64").toString("utf-8") : rData.content; readme = raw.slice(0, 3000); }
    }

    const extCount: Record<string, number> = {};
    fileTree.forEach((p: string) => { const ext = p.split(".").pop()?.toLowerCase() || "other"; extCount[ext] = (extCount[ext] || 0) + 1; });
    const topLangs = Object.entries(extCount).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([ext, n]) => `${ext}(${n})`).join(", ");

    const contextLines: string[] = [
      `Repository: ${owner}/${repo}`, `Branch: ${useBranch}`,
      `Description: ${meta.description || "No description provided"}`,
      `Language: ${meta.language || "Mixed"}`,
      `Stars: ${meta.stargazers_count}  Forks: ${meta.forks_count}`,
      `Total files: ${fileTree.length}  File types: ${topLangs}`,
      "", "## File Structure (first 80 paths)", fileTree.slice(0, 80).join("\n"),
    ];
    if (readme) contextLines.push("", "## README", readme);

    res.json({ success: true, owner, repo, branch: useBranch, fileCount: fileTree.length, description: meta.description || "", language: meta.language || "Mixed", projectContext: contextLines.join("\n") });
  } catch (error: any) {
    res.status(500).json({ error: error?.message || "Failed to load repository" });
  }
});

router.get("/github/pull", requireAuth, async (_req, res) => {
  const config = await storage.getGithubConfig();
  if (!config?.token) return res.status(400).json({ error: "GitHub is not connected. Configure it first." });

  const { token, owner, repo, branch } = config;
  try {
    const treeRes = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/git/trees/${branch}?recursive=1`, { headers: githubHeaders(token) });
    if (!treeRes.ok) { const body = await treeRes.text(); return res.status(400).json({ error: `Could not read repo tree: ${treeRes.status} ${body.slice(0, 200)}` }); }
    const tree = await treeRes.json();
    const blobs = (tree.tree || []).filter((t: any) => t.type === "blob").slice(0, 200);
    const files = await Promise.all(blobs.map(async (blob: any) => {
      try {
        const blobRes = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/git/blobs/${blob.sha}`, { headers: githubHeaders(token) });
        if (!blobRes.ok) return { path: blob.path, content: "", error: "Failed to fetch content" };
        const blobData = await blobRes.json();
        const content = blobData.encoding === "base64" ? Buffer.from(blobData.content, "base64").toString("utf-8") : blobData.content;
        return { path: blob.path, content };
      } catch (error: any) { return { path: blob.path, content: "", error: error?.message || "Unknown error" }; }
    }));
    res.json({ success: true, owner, repo, branch, fileCount: files.length, files });
  } catch (error: any) {
    res.status(500).json({ error: error?.message || "Failed to pull from GitHub" });
  }
});

export default router;
