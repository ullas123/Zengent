/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { Router } from "express";
import multer from "multer";
import { requireAuth } from "../auth";
import {
  scanZipFiles,
  directLlmScan,
  compareScan,
  ApplicationContext,
} from "../services/apiScanService";
import { aiKeyStore } from "../services/aiKeyStore";

const router = Router();

const uploadMultiZip = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 }, // 100 MB per file
  fileFilter: (_req, file, cb) => {
    const isZip =
      file.mimetype === "application/zip" ||
      file.mimetype === "application/x-zip-compressed" ||
      file.originalname.endsWith(".zip");
    isZip ? cb(null, true) : cb(new Error("Only ZIP files are allowed"));
  },
});

function parseContext(raw: unknown): ApplicationContext {
  if (!raw || typeof raw !== "object") return {};
  const r = raw as Record<string, unknown>;
  return {
    applicationName:   typeof r.applicationName  === "string" ? r.applicationName  : undefined,
    businessFunction:  typeof r.businessFunction === "string" ? r.businessFunction : undefined,
    domain:            typeof r.domain           === "string" ? r.domain           : undefined,
    techStack:         typeof r.techStack        === "string" ? r.techStack        : undefined,
    repositoryPath:    typeof r.repositoryPath   === "string" ? r.repositoryPath   : undefined,
    knownSystems:      typeof r.knownSystems     === "string" ? r.knownSystems     : undefined,
    complianceScope:   typeof r.complianceScope  === "string" ? r.complianceScope  : undefined,
  };
}

/** Serialize an ApiScanResult into the JSON response shape (htmlReport base64-encoded). */
function serializeResult(result: Awaited<ReturnType<typeof scanZipFiles>>, extra?: Record<string, unknown>) {
  return {
    integrationType:        result.integrationType,
    zipFiles:               result.zipFiles,
    totalFilesScanned:      result.totalFilesScanned,
    scanDuration:           result.scanDuration,
    elapsedTime:            result.elapsedTime,
    languagesDetected:      result.languagesDetected,
    sorFindings:            result.sorFindings,
    tableFindings:          result.tableFindings,
    demographicFindings:    result.demographicFindings,
    unlisted_sources_found: result.unlisted_sources_found,
    notFoundSors:           result.notFoundSors,
    notFoundTables:         result.notFoundTables,
    htmlReport:             Buffer.from(result.htmlReport).toString("base64"),
    extractionJson:         result.extractionJson,
    ...extra,
  };
}

/**
 * POST /api/api-scan/scan
 * Body: multipart/form-data  field "files" (one or more .zip)
 *                            field "context"            (optional JSON string)
 *                            field "pipelineMode"       (s12 | s123 | s3direct | compare)
 *                            field "customInstructions" (optional, s123 only)
 */
router.post(
  "/scan",
  requireAuth,
  uploadMultiZip.array("files", 20),
  async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[] | undefined;
      if (!files || files.length === 0) {
        return res.status(400).json({ error: "At least one ZIP file is required" });
      }

      let context: ApplicationContext = {};
      try { context = parseContext(JSON.parse(req.body.context || "{}")); } catch { /* ignore */ }

      const pipelineMode: string = req.body.pipelineMode || "s123";
      const customInstructions: string = pipelineMode === "s123" && typeof req.body.customInstructions === "string"
        ? req.body.customInstructions.trim()
        : "";

      const aiKey = aiKeyStore.getAnthropicKey() || aiKeyStore.getOpenAIKey() || "";

      if ((pipelineMode === "s3direct" || pipelineMode === "compare") && !aiKey) {
        return res.status(400).json({ error: "An AI key must be configured in AI Settings for this pipeline mode." });
      }

      const zipBuffers = files.map(f => ({ name: f.originalname, buffer: f.buffer }));

      if (pipelineMode === "s3direct") {
        const r = await directLlmScan(zipBuffers, context, aiKey);
        return res.json({ success: true, mode: "s3direct", ...serializeResult(r) });
      }

      if (pipelineMode === "compare") {
        const { s1, s3, comparisonHtml } = await compareScan(zipBuffers, context, aiKey);
        return res.json({
          success: true,
          mode: "compare",
          ...serializeResult(s1, {
            s3HtmlReport:     Buffer.from(s3.htmlReport).toString("base64"),
            s3ExtractionJson: s3.extractionJson,
            comparisonHtml:   Buffer.from(comparisonHtml).toString("base64"),
          }),
        });
      }

      // s12 or s123
      const result = await scanZipFiles(
        zipBuffers,
        context,
        pipelineMode === "s123" ? customInstructions : "",
        pipelineMode === "s123" ? aiKey : ""
      );
      return res.json({ success: true, mode: pipelineMode, ...serializeResult(result) });

    } catch (err: any) {
      console.error("[API Scan] Error:", err);
      return res.status(500).json({ error: err.message || "Scan failed" });
    }
  }
);

// ─── GitHub helpers ───────────────────────────────────────────────────────────

function parseGithubUrl(url: string): { host: string; owner: string; repo: string } | null {
  try {
    const u = new URL(url.trim());
    if (!u.hostname.toLowerCase().startsWith("github")) return null;
    const parts = u.pathname.replace(/^\//, "").replace(/\.git$/, "").split("/").filter(Boolean);
    if (parts.length < 2) return null;
    return { host: u.hostname, owner: parts[0], repo: parts[1] };
  } catch { return null; }
}

async function downloadGithubZip(
  githubUrl: string,
  branch?: string,
  token?: string
): Promise<{ zipBuffer: Buffer; repoLabel: string; usedBranch: string }> {
  const parsed = parseGithubUrl(githubUrl);
  if (!parsed) throw new Error("Invalid GitHub URL. Expected: https://github[.domain.com]/owner/repo");

  const { host, owner, repo } = parsed;
  const headers: Record<string, string> = {
    "User-Agent": "Nucleus-2.0-API-Scanner",
    Accept: "application/octet-stream",
  };
  if (token) headers["Authorization"] = `token ${token}`;

  const candidates = branch ? [branch, "main", "master"] : ["main", "master", "HEAD"];
  let lastError = "";

  for (const b of candidates) {
    const archiveUrl = b === "HEAD"
      ? `https://${host}/${owner}/${repo}/archive/HEAD.zip`
      : `https://${host}/${owner}/${repo}/archive/refs/heads/${b}.zip`;

    try {
      const response = await fetch(archiveUrl, { headers, redirect: "follow" });
      if (response.ok) {
        const ab = await response.arrayBuffer();
        return { zipBuffer: Buffer.from(ab), repoLabel: `${owner}/${repo}@${b}`, usedBranch: b };
      }
      lastError = `HTTP ${response.status} for branch "${b}"`;
    } catch (fetchErr: any) {
      lastError = fetchErr.message;
    }
  }

  throw new Error(`Could not download repository archive. ${lastError}. Check the URL, branch name, and token.`);
}

/**
 * POST /api/api-scan/scan-github
 * Body: { githubUrl, branch?, token?, context?, pipelineMode?, customInstructions? }
 */
router.post("/scan-github", requireAuth, async (req, res) => {
  try {
    const { githubUrl, branch, token, context: rawContext } = req.body as {
      githubUrl?: string; branch?: string; token?: string; context?: unknown;
    };

    if (!githubUrl) return res.status(400).json({ error: "githubUrl is required" });

    const context = parseContext(rawContext);
    const pipelineMode: string = (req.body as any).pipelineMode || "s123";
    const customInstructions: string = pipelineMode === "s123" && typeof (req.body as any).customInstructions === "string"
      ? (req.body as any).customInstructions.trim()
      : "";
    const aiKey = aiKeyStore.getAnthropicKey() || aiKeyStore.getOpenAIKey() || "";

    if ((pipelineMode === "s3direct" || pipelineMode === "compare") && !aiKey) {
      return res.status(400).json({ error: "An AI key must be configured in AI Settings for this pipeline mode." });
    }

    const { zipBuffer, repoLabel, usedBranch } = await downloadGithubZip(githubUrl, branch, token);
    const zipBuffers = [{ name: repoLabel, buffer: zipBuffer }];

    if (pipelineMode === "s3direct") {
      const r = await directLlmScan(zipBuffers, context, aiKey);
      return res.json({ success: true, mode: "s3direct", source: "github", githubUrl, repoLabel, branch: usedBranch, ...serializeResult(r, { zipFiles: [repoLabel] }) });
    }

    if (pipelineMode === "compare") {
      const { s1, s3, comparisonHtml } = await compareScan(zipBuffers, context, aiKey);
      return res.json({
        success: true, mode: "compare", source: "github", githubUrl, repoLabel, branch: usedBranch,
        ...serializeResult(s1, {
          zipFiles: [repoLabel],
          s3HtmlReport:     Buffer.from(s3.htmlReport).toString("base64"),
          s3ExtractionJson: s3.extractionJson,
          comparisonHtml:   Buffer.from(comparisonHtml).toString("base64"),
        }),
      });
    }

    const result = await scanZipFiles(
      zipBuffers,
      context,
      pipelineMode === "s123" ? customInstructions : "",
      pipelineMode === "s123" ? aiKey : ""
    );
    return res.json({
      success: true, mode: pipelineMode, source: "github", githubUrl, repoLabel, branch: usedBranch,
      ...serializeResult(result, { zipFiles: [repoLabel] }),
    });

  } catch (err: any) {
    console.error("[API Scan GitHub] Error:", err);
    return res.status(500).json({ error: err.message || "GitHub scan failed" });
  }
});

/**
 * POST /api/api-scan/scan-multi-github
 * Body: { repos: [{ githubUrl, branch?, token? }], context?, pipelineMode?, customInstructions? }
 */
router.post("/scan-multi-github", requireAuth, async (req, res) => {
  try {
    const { repos, context: rawContext } = req.body as {
      repos?: { githubUrl: string; branch?: string; token?: string }[];
      context?: unknown;
    };

    if (!repos || !Array.isArray(repos) || repos.length === 0) {
      return res.status(400).json({ error: "repos array is required and must not be empty" });
    }
    if (repos.length > 10) {
      return res.status(400).json({ error: "Maximum 10 repositories per scan" });
    }

    const context = parseContext(rawContext);
    const pipelineMode: string = (req.body as any).pipelineMode || "s123";
    const customInstructions: string = pipelineMode === "s123" && typeof (req.body as any).customInstructions === "string"
      ? (req.body as any).customInstructions.trim()
      : "";
    const aiKey = aiKeyStore.getAnthropicKey() || aiKeyStore.getOpenAIKey() || "";

    if ((pipelineMode === "s3direct" || pipelineMode === "compare") && !aiKey) {
      return res.status(400).json({ error: "An AI key must be configured in AI Settings for this pipeline mode." });
    }

    // Download all repos in parallel
    const downloadResults = await Promise.allSettled(
      repos.map(({ githubUrl, branch, token }) => downloadGithubZip(githubUrl, branch, token))
    );

    const zipBuffers: { name: string; buffer: Buffer }[] = [];
    const repoLabels: string[] = [];
    const errors: string[] = [];

    downloadResults.forEach((r, i) => {
      if (r.status === "fulfilled") {
        zipBuffers.push({ name: r.value.repoLabel, buffer: r.value.zipBuffer });
        repoLabels.push(r.value.repoLabel);
      } else {
        errors.push(`Repo ${i + 1} (${repos[i].githubUrl}): ${r.reason?.message || "Download failed"}`);
      }
    });

    if (zipBuffers.length === 0) {
      return res.status(400).json({ error: "All repository downloads failed", details: errors });
    }

    if (pipelineMode === "s3direct") {
      const r = await directLlmScan(zipBuffers, context, aiKey);
      return res.json({ success: true, mode: "s3direct", source: "multi-github", repoLabels, downloadErrors: errors, ...serializeResult(r, { zipFiles: repoLabels }) });
    }

    if (pipelineMode === "compare") {
      const { s1, s3, comparisonHtml } = await compareScan(zipBuffers, context, aiKey);
      return res.json({
        success: true, mode: "compare", source: "multi-github", repoLabels, downloadErrors: errors,
        ...serializeResult(s1, {
          zipFiles: repoLabels,
          s3HtmlReport:     Buffer.from(s3.htmlReport).toString("base64"),
          s3ExtractionJson: s3.extractionJson,
          comparisonHtml:   Buffer.from(comparisonHtml).toString("base64"),
        }),
      });
    }

    const result = await scanZipFiles(
      zipBuffers,
      context,
      pipelineMode === "s123" ? customInstructions : "",
      pipelineMode === "s123" ? aiKey : ""
    );
    return res.json({
      success: true, mode: pipelineMode, source: "multi-github", repoLabels, downloadErrors: errors,
      ...serializeResult(result, { zipFiles: repoLabels }),
    });

  } catch (err: any) {
    console.error("[API Scan Multi-GitHub] Error:", err);
    return res.status(500).json({ error: err.message || "Multi-GitHub scan failed" });
  }
});

/**
 * GET /api/api-scan/sor-list
 */
router.get("/sor-list", requireAuth, (_req, res) => {
  const { SOR_SYSTEMS, APPROVED_TABLES } = require("../services/apiScanService");
  return res.json({ sorSystems: SOR_SYSTEMS, approvedTables: APPROVED_TABLES });
});

export default router;
