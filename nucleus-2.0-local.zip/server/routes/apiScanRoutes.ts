/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { Router } from "express";
import multer from "multer";
import { requireAuth } from "../auth";
import { scanZipFiles } from "../services/apiScanService";

const router = Router();

const uploadMultiZip = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 }, // 100 MB per file
  fileFilter: (_req, file, cb) => {
    const isZip =
      file.mimetype === "application/zip" ||
      file.mimetype === "application/x-zip-compressed" ||
      file.originalname.endsWith(".zip");
    isZip ? cb(null, true) : cb(new Error("Only ZIP files are allowed"));
  },
});

/**
 * POST /api/api-scan/scan
 * Body: multipart/form-data  field: "files" (one or more .zip)
 */
router.post(
  "/scan",
  requireAuth,
  uploadMultiZip.array("files", 10),
  async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[] | undefined;
      if (!files || files.length === 0) {
        return res.status(400).json({ error: "At least one ZIP file is required" });
      }

      const zipBuffers = files.map((f) => ({ name: f.originalname, buffer: f.buffer }));
      const result = await scanZipFiles(zipBuffers);

      // Return JSON summary + HTML report as base64
      return res.json({
        success: true,
        integrationType: result.integrationType,
        zipFiles: result.zipFiles,
        totalFilesScanned: result.totalFilesScanned,
        scanDuration: result.scanDuration,
        elapsedTime: result.elapsedTime,
        sorFindings: result.sorFindings,
        tableFindings: result.tableFindings,
        notFoundSors: result.notFoundSors,
        notFoundTables: result.notFoundTables,
        htmlReport: Buffer.from(result.htmlReport).toString("base64"),
      });
    } catch (err: any) {
      console.error("[API Scan] Error:", err);
      return res.status(500).json({ error: err.message || "Scan failed" });
    }
  }
);

/**
 * GET /api/api-scan/sor-list
 * Returns the list of known SOR systems and approved tables
 */
router.get("/sor-list", requireAuth, (_req, res) => {
  const { SOR_SYSTEMS, APPROVED_TABLES } = require("../services/apiScanService");
  return res.json({ sorSystems: SOR_SYSTEMS, approvedTables: APPROVED_TABLES });
});

export default router;
