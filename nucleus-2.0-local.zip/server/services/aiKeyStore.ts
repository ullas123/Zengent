/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

/**
 * AIKeyStore — singleton that holds the active user-configured AI provider and keys.
 * User-provided keys always take precedence over server environment variables.
 * Keys are held in memory for the lifetime of the server process (cleared on restart).
 */

export interface StoredAIConfig {
  type: "openai" | "claude" | "gemini" | "local";
  openaiApiKey?: string;
  anthropicApiKey?: string;
  geminiApiKey?: string;
  localEndpoint?: string;
  modelName?: string;
}

class AIKeyStore {
  private config: StoredAIConfig = { type: "openai" };

  /** Save the user-provided config */
  set(config: StoredAIConfig) {
    this.config = { ...config };
    console.log(`[AIKeyStore] Provider set to "${config.type}" — user keys: openai=${!!config.openaiApiKey}, anthropic=${!!config.anthropicApiKey}`);
  }

  get(): StoredAIConfig {
    return { ...this.config };
  }

  /** Active provider type */
  getProviderType(): string {
    return this.config.type;
  }

  /**
   * Effective OpenAI API key.
   * Priority: user-provided key → OPENAI_API_KEY env var
   */
  getOpenAIKey(): string | undefined {
    return this.config.openaiApiKey?.trim() || process.env.OPENAI_API_KEY;
  }

  /**
   * Effective Anthropic API key.
   * Priority: user-provided key → ANTHROPIC_API_KEY env var
   */
  getAnthropicKey(): string | undefined {
    return this.config.anthropicApiKey?.trim() || process.env.ANTHROPIC_API_KEY;
  }

  getLocalEndpoint(): string {
    return this.config.localEndpoint?.trim() || process.env.OLLAMA_ENDPOINT || "http://localhost:11434";
  }

  getLocalModel(): string {
    return this.config.modelName?.trim() || process.env.OLLAMA_MODEL || "mistral:7b";
  }

  /** Safe summary for API response — never exposes actual key values */
  getSafeConfig(): object {
    return {
      type:            this.config.type,
      hasOpenAIKey:    !!(this.config.openaiApiKey?.trim() || process.env.OPENAI_API_KEY),
      hasAnthropicKey: !!(this.config.anthropicApiKey?.trim() || process.env.ANTHROPIC_API_KEY),
      localEndpoint:   this.config.localEndpoint || process.env.OLLAMA_ENDPOINT || "http://localhost:11434",
      modelName:       this.config.modelName || process.env.OLLAMA_MODEL || "mistral:7b",
    };
  }
}

export const aiKeyStore = new AIKeyStore();
