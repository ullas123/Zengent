/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 *
 * Two-stage SOR & Demographic Data Discovery Scanner
 * ─────────────────────────────────────────────────
 * Stage 1  Deterministic, no-LLM: multi-language static extraction → ExtractionJson
 * Stage 2  Rule-based BRD narrative + HTML report (constrained, reproducible)
 * BRD Spec : sor-discovery-brd-spec-multilang
 */

import JSZip from "jszip";
import Anthropic from "@anthropic-ai/sdk";
import OpenAI from "openai";

// ─── Optional Stage 3: LLM Insights helper ───────────────────────────────────

async function callLlmInsights(
  extractionJson: ExtractionJson,
  customInstructions: string,
  aiKey: string
): Promise<string> {
  const systemPrompt = `You are an expert enterprise software architect analyzing a System of Record (SOR) discovery scan.
Provide focused AI analysis based ONLY on the extraction data provided.
CRITICAL RULES:
- Only reference facts present in the extraction data — never invent endpoints, tables, or PII fields
- Follow the user's additional instructions precisely
- Be structured, professional and concise
- Format your response with HTML tags (h4, p, ul, li, strong) — no markdown`;

  const snippet = {
    scan_metadata: extractionJson.scan_metadata,
    api_integrations: extractionJson.api_integrations.slice(0, 30),
    table_usages: extractionJson.table_usages.slice(0, 30),
    demographic_fields_found: extractionJson.demographic_fields_found.slice(0, 30),
    unlisted_sources_found: extractionJson.unlisted_sources_found.slice(0, 15),
  };

  const userPrompt = `EXTRACTION DATA (Stage 1 output — use ONLY these facts):\n${JSON.stringify(snippet, null, 2)}\n\nADDITIONAL INSTRUCTIONS:\n${customInstructions}\n\nProvide HTML-formatted analysis.`;

  if (aiKey.startsWith("sk-ant-")) {
    const client = new Anthropic({ apiKey: aiKey });
    const response = await client.messages.create({
      model: "claude-opus-4-5",
      max_tokens: 2048,
      messages: [{ role: "user", content: userPrompt }],
      system: systemPrompt,
    });
    const block = response.content[0];
    return block.type === "text" ? block.text : "";
  }

  // OpenAI fallback
  const oaiClient = new OpenAI({ apiKey: aiKey });
  const response = await oaiClient.chat.completions.create({
    model: "gpt-4o",
    max_tokens: 2048,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
  });
  return response.choices[0]?.message?.content || "";
}

// ─── SOR & Table definitions ─────────────────────────────────────────────────

export const SOR_SYSTEMS = [
  "CRPS", "Anagrafe", "Income SOR", "Triumph", "MNS",
  "GSTAR", "CM-CARS", "APA AR", "CARE", "DIG", "GAR",
];

export const APPROVED_TABLES = [
  "triumph_demographics", "triumph_card_account", "triumph_plastic_card",
  "gstar_card_details", "gstar_account_details", "gstar_customer_demographics",
  "gstar_corp_customer_demographics", "cars_cm_demographics", "mns_demographics_ar",
  "care_demographic", "apa_ar_demographic", "dcp_cm_mobile_dtl", "dcp_cm_email_dtl",
  "anagrafe_customer", "crps_customer_linkage", "gstar_corp_card_details",
  "gstar_corp_account_details",
];

// ─── Application Context (filled before scan) ─────────────────────────────────

export interface ApplicationContext {
  applicationName?: string;
  businessFunction?: string;
  domain?: string;
  techStack?: string;
  repositoryPath?: string;
  knownSystems?: string;
  complianceScope?: string;
}

// ─── ExtractionJson — Stage 1 output (BRD spec shape) ────────────────────────

export interface ExtractionApiIntegration {
  sor_name: string;
  endpoint: string;
  http_method: string;
  language: string;
  source_file: string;
  source_class_or_function: string;
  config_location: string;
  matched_by: string;
}

export interface ExtractionTableUsage {
  table_name: string;
  query_type: string;
  language: string;
  source_file: string;
  source_class_or_proc: string;
  raw_query: string;
  matched_by: string;
}

export interface ExtractionDemographicField {
  field_name: string;
  data_type: string;
  language: string;
  source_file: string;
  line_number: number;
  matched_by: string;
}

export interface ExtractionJson {
  scan_metadata: {
    repo_paths: string[];
    languages_detected: string[];
    scan_timestamp: string;
    libraries_used: { language: string; artifact_type: string; library: string; version: string }[];
    files_scanned_count: number;
    elapsed_seconds: number;
  };
  api_integrations: ExtractionApiIntegration[];
  table_usages: ExtractionTableUsage[];
  demographic_fields_found: ExtractionDemographicField[];
  unlisted_sources_found: string[];
}

// ─── Existing result types (preserved for API compatibility) ─────────────────

export interface SorFinding {
  sorName: string;
  endpoints: EndpointFinding[];
  files: string[];
}

export interface EndpointFinding {
  url: string;
  method: string;
  description: string;
  sourceFile: string;
  className?: string;
  configFile?: string;
  language?: string;
}

export interface TableFinding {
  tableName: string;
  queryType: string;
  sourceFile: string;
  exactQuery?: string;
  language?: string;
}

export interface DemographicFinding {
  fieldName: string;
  dataType: string;
  language: string;
  sourceFile: string;
  lineNumber: number;
  matchedBy: string;
}

export interface ApiScanResult {
  integrationType: "API-Based" | "Query-Based" | "Both" | "None";
  zipFiles: string[];
  totalFilesScanned: number;
  scanDuration: number;
  sorFindings: SorFinding[];
  tableFindings: TableFinding[];
  demographicFindings: DemographicFinding[];
  unlisted_sources_found: string[];
  notFoundSors: string[];
  notFoundTables: string[];
  languagesDetected: string[];
  htmlReport: string;
  extractionJson: ExtractionJson;
  elapsedTime: string;
}

// ─── Language detection ───────────────────────────────────────────────────────

function detectLanguages(files: Map<string, string>): string[] {
  const langs = new Set<string>();
  for (const path of files.keys()) {
    const lower = path.toLowerCase();
    if (lower.endsWith(".java") || lower.endsWith("pom.xml") || lower.endsWith("build.gradle")) langs.add("Java");
    if (lower.endsWith(".cs") || lower.endsWith(".csproj") || lower.endsWith(".sln")) langs.add("C#");
    if (lower.endsWith(".py") || lower.endsWith("requirements.txt") || lower.endsWith("pyproject.toml")) langs.add("Python");
    if (lower.endsWith(".ts") || lower.endsWith(".tsx") || lower.endsWith(".js") || lower.endsWith(".jsx") || lower.endsWith("package.json")) langs.add("React-JS");
    if (lower.endsWith(".sql") || lower.endsWith(".procedure") || lower.endsWith(".sp")) langs.add("SQL");
    if (lower.endsWith(".go")) langs.add("Go");
    if (lower.endsWith(".rb")) langs.add("Ruby");
  }
  return Array.from(langs).sort();
}

function languageOfFile(path: string): string {
  const lower = path.toLowerCase();
  if (lower.endsWith(".java")) return "Java";
  if (lower.endsWith(".cs")) return "C#";
  if (lower.endsWith(".py")) return "Python";
  if (lower.endsWith(".ts") || lower.endsWith(".tsx") || lower.endsWith(".js") || lower.endsWith(".jsx")) return "React-JS";
  if (lower.endsWith(".sql") || lower.endsWith(".procedure") || lower.endsWith(".sp")) return "SQL";
  if (lower.endsWith(".go")) return "Go";
  if (lower.endsWith(".rb")) return "Ruby";
  if (lower.endsWith(".xml") || lower.endsWith(".yml") || lower.endsWith(".yaml") || lower.endsWith(".properties") || lower.endsWith(".env") || lower.endsWith(".json") || lower.endsWith(".conf") || lower.endsWith(".config")) return "Config";
  return "Unknown";
}

// ─── SOR patterns (per-SOR regex sets) ───────────────────────────────────────

const SOR_PATTERNS: Record<string, RegExp[]> = {
  CRPS:        [/crps/i, /crps[_\-.]?client/i, /crps[_\-.]?service/i, /crps[_\-.]?api/i],
  Anagrafe:    [/anagrafe/i, /anagrafe[_\-.]?client/i, /anagrafe[_\-.]?service/i],
  "Income SOR":[/income[_\-.]?sor/i, /income[_\-.]?service/i, /incomeSor/i],
  Triumph:     [/triumph/i, /triumph[_\-.]?client/i, /triumph[_\-.]?service/i],
  MNS:         [/\bmns\b/i, /mns[_\-.]?client/i, /mns[_\-.]?service/i, /mns[_\-.]?api/i],
  GSTAR:       [/gstar/i, /gstar[_\-.]?client/i, /gstar[_\-.]?service/i],
  "CM-CARS":   [/cm[_\-.]?cars/i, /cmcars/i, /cars[_\-.]?cm/i],
  "APA AR":    [/apa[_\-.]?ar/i, /apaAr/i, /apa[_\-.]?ar[_\-.]?service/i],
  CARE:        [/\bcare\b/i, /care[_\-.]?client/i, /care[_\-.]?service/i],
  DIG:         [/\bdig\b/i, /dig[_\-.]?client/i, /dig[_\-.]?service/i, /dig[_\-.]?api/i],
  GAR:         [/\bgar\b/i, /gar[_\-.]?client/i, /gar[_\-.]?service/i],
};

// ─── Language-specific API signal patterns ────────────────────────────────────

// Java
const JAVA_API_PATTERN = /@FeignClient|@RestTemplate|RestTemplate|WebClient|RestClient\.|HttpClient|restTemplate\.|webClient\.|feignClient\./i;
const JAVA_CLASS_PATTERN = /(?:class|interface)\s+(\w+)/;
const JAVA_METHOD_PATTERN = /(?:public|private|protected)\s+\w+\s+(\w+)\s*\(/;
const JAVA_VALUE_PATTERN = /@Value\("(\$\{[^}]+\})"\)/g;
const JAVA_FEIGN_PATTERN = /@FeignClient\s*\(\s*(?:name\s*=\s*)?["']([^"']+)["']/;

// C#
const CSHARP_API_PATTERN = /HttpClient|RestSharp|RestClient|_client\.(Get|Post|Put|Delete|Patch)|await\s+\w+\.(GetAsync|PostAsync|PutAsync|DeleteAsync|PatchAsync)/i;
const CSHARP_CLASS_PATTERN = /(?:class|interface)\s+(\w+)/;
const CSHARP_ROUTE_PATTERN = /\[(?:Route|HttpGet|HttpPost|HttpPut|HttpDelete|HttpPatch)\s*\(\s*["']([^"']*)['"]/g;
const CSHARP_DBSET_PATTERN = /DbSet<(\w+)>/g;
const CSHARP_CONFIG_PATTERN = /(?:BaseAddress|HttpClient\s*\().*?["'`](https?:\/\/[^"'`\s]+)/;

// Python
const PYTHON_API_PATTERN = /requests\.(get|post|put|delete|patch|head)|httpx\.(get|post|put|delete|patch)|aiohttp\.|urllib\.request/i;
const PYTHON_CLASS_PATTERN = /^class\s+(\w+)/m;
const PYTHON_ROUTE_PATTERN = /@(?:app|router|bp)\.(route|get|post|put|delete|patch)\s*\(\s*["']([^"']+)['"]/g;
const PYTHON_TABLENAME_PATTERN = /__tablename__\s*=\s*["'](\w+)['"]/g;
const PYTHON_FUNC_PATTERN = /^(?:async\s+)?def\s+(\w+)\s*\(/m;

// JS/TS/React
const JS_FETCH_PATTERN = /fetch\s*\(\s*["'`](https?:\/\/[^"'`\s]{5,})["'`]|fetch\s*\(\s*`[^`]*`/i;
const JS_AXIOS_PATTERN = /axios\.(get|post|put|delete|patch)\s*\(\s*["'`]([^"'`\s]+)["'`]/gi;
const JS_API_SIGNAL = /fetch\(|axios\.|useQuery|useMutation|apiClient\.|api\.(get|post|put|delete|patch)\b/i;
const JS_FUNC_PATTERN = /(?:function\s+(\w+)|const\s+(\w+)\s*=\s*(?:async\s+)?\(|(\w+)\s*:\s*(?:async\s+)?\()/;

// General HTTP
const HTTP_METHOD_PATTERN = /\b(GET|POST|PUT|PATCH|DELETE)\b/;
const REST_URL_PATTERN = /["'`](https?:\/\/[^"'`\s]{5,})[`'"]/g;

// SQL
const SQL_QUERY_PATTERN = /\b(SELECT|INSERT|UPDATE|DELETE)\b/i;
const SQL_TABLE_FROM_PATTERN = /\bFROM\s+([`'"]?\w+[`'"]?)/gi;
const SQL_TABLE_INTO_PATTERN = /\bINTO\s+([`'"]?\w+[`'"]?)/gi;
const SQL_TABLE_UPDATE_PATTERN = /\bUPDATE\s+([`'"]?\w+[`'"]?)\s+SET\b/gi;

// Config
const CONFIG_URL_PATTERN = /(?:url|baseUrl|base-url|endpoint|host)\s*[=:]\s*(https?:\/\/[^\s,'"]+)/gi;
const YAML_URL_PATTERN = /(?:url|base-url|endpoint|host|uri):\s*(https?:\/\/[^\s]+)/gi;
const ENV_URL_PATTERN = /\w+_(?:URL|HOST|ENDPOINT|URI)\s*=\s*(https?:\/\/[^\s]+)/gi;

// OpenAPI/Swagger
const OPENAPI_PATH_PATTERN = /"paths"\s*:\s*\{|paths:\s*\n\s+\//gi;

// ─── Demographic / PII field patterns ────────────────────────────────────────

const DEMOGRAPHIC_PATTERNS: { pattern: RegExp; fieldName: string; dataType: string; matchedBy: string }[] = [
  { pattern: /\b(ssn|social[_-]?security[_-]?number|tax[_-]?id|nationalId|national[_-]?id)\b/i, fieldName: "SSN / National ID", dataType: "String", matchedBy: "pii-pattern" },
  { pattern: /\b(dateOfBirth|date[_-]?of[_-]?birth|dob|birthDate|birth[_-]?date)\b/i, fieldName: "Date of Birth", dataType: "Date", matchedBy: "pii-pattern" },
  { pattern: /\b(firstName|first[_-]?name|givenName|given[_-]?name|surname|lastName|last[_-]?name|fullName|full[_-]?name)\b/i, fieldName: "Name (First/Last/Full)", dataType: "String", matchedBy: "pii-pattern" },
  { pattern: /\b(streetAddress|street[_-]?address|addressLine|address[_-]?line[12]|postalCode|postal[_-]?code|zipCode|zip[_-]?code|city|state|country)\b/i, fieldName: "Address / Postal Code", dataType: "String", matchedBy: "pii-pattern" },
  { pattern: /\b(phoneNumber|phone[_-]?number|mobileNumber|mobile[_-]?number|cellPhone|cell[_-]?phone|telephone)\b/i, fieldName: "Phone / Mobile Number", dataType: "String", matchedBy: "pii-pattern" },
  { pattern: /\b(emailAddress|email[_-]?address|email)\b/i, fieldName: "Email Address", dataType: "String", matchedBy: "pii-pattern" },
  { pattern: /\b(accountNumber|account[_-]?number|cardNumber|card[_-]?number|cardPan|pan)\b/i, fieldName: "Account / Card Number", dataType: "String", matchedBy: "pii-pattern" },
  { pattern: /\b(gender|nationality|ethnicity|race)\b/i, fieldName: "Gender / Nationality / Ethnicity", dataType: "String", matchedBy: "pii-pattern" },
  { pattern: /\b(income|salary|wage|annualIncome|annual[_-]?income)\b/i, fieldName: "Income / Salary", dataType: "Decimal", matchedBy: "pii-pattern" },
  { pattern: /\b(ipAddress|ip[_-]?address|macAddress|mac[_-]?address)\b/i, fieldName: "IP / MAC Address", dataType: "String", matchedBy: "pii-pattern" },
  { pattern: /\b(passport[_-]?number|passportNo|driversLicense|driver[_-]?license|licenseNumber)\b/i, fieldName: "Passport / License Number", dataType: "String", matchedBy: "pii-pattern" },
  { pattern: /\b(maritalStatus|marital[_-]?status|occupation|employer)\b/i, fieldName: "Marital Status / Occupation", dataType: "String", matchedBy: "pii-pattern" },
];

// ─── Scannable extensions ─────────────────────────────────────────────────────

const SCANNABLE_EXTS = new Set([
  ".java", ".kt", ".xml", ".properties", ".yml", ".yaml",
  ".ts", ".tsx", ".js", ".jsx", ".py", ".json", ".sql",
  ".conf", ".config", ".env", ".cs", ".go", ".rb", ".sp",
  ".procedure", ".pkb", ".pks",
]);

function isScannable(filename: string): boolean {
  const ext = filename.substring(filename.lastIndexOf(".")).toLowerCase();
  return SCANNABLE_EXTS.has(ext);
}

// ─── ZIP extraction ───────────────────────────────────────────────────────────

async function extractZip(buffer: Buffer): Promise<Map<string, string>> {
  const zip = await JSZip.loadAsync(buffer);
  const files = new Map<string, string>();
  for (const [path, file] of Object.entries(zip.files)) {
    if (file.dir || !isScannable(path)) continue;
    try {
      const content = await file.async("string");
      files.set(path, content);
    } catch { /* skip binary/unreadable */ }
  }
  return files;
}

// ─── Integration signal detection (broad, any language) ───────────────────────

function detectIntegrationSignals(files: Map<string, string>): {
  hasApiSignals: boolean;
  hasQuerySignals: boolean;
} {
  let hasApiSignals = false;
  let hasQuerySignals = false;

  const API_SIGNALS = [JAVA_API_PATTERN, CSHARP_API_PATTERN, PYTHON_API_PATTERN, JS_API_SIGNAL];
  const QUERY_SIGNALS = [SQL_QUERY_PATTERN];

  for (const [, content] of files) {
    if (!hasApiSignals && API_SIGNALS.some(p => p.test(content))) hasApiSignals = true;
    if (!hasQuerySignals && QUERY_SIGNALS.some(p => p.test(content))) hasQuerySignals = true;
    if (hasApiSignals && hasQuerySignals) break;
  }
  return { hasApiSignals, hasQuerySignals };
}

// ─── Stage 1: SOR scanner ─────────────────────────────────────────────────────

function scanForSors(files: Map<string, string>): {
  sorFindings: SorFinding[];
  apiIntegrations: ExtractionApiIntegration[];
} {
  const resultMap = new Map<string, SorFinding>();
  const apiIntegrations: ExtractionApiIntegration[] = [];

  for (const sorName of SOR_SYSTEMS) {
    resultMap.set(sorName, { sorName, endpoints: [], files: [] });
  }

  for (const [filePath, content] of files) {
    const lang = languageOfFile(filePath);
    const lines = content.split("\n");

    // Extract class/function context
    const classMatch = content.match(JAVA_CLASS_PATTERN) || content.match(CSHARP_CLASS_PATTERN) || content.match(PYTHON_CLASS_PATTERN);
    const funcMatch = content.match(JAVA_METHOD_PATTERN) || content.match(PYTHON_FUNC_PATTERN);
    const contextName = classMatch?.[1] || funcMatch?.[1] || filePath.split("/").pop()?.replace(/\.\w+$/, "") || "";

    for (const [sorName, patterns] of Object.entries(SOR_PATTERNS)) {
      const sorResult = resultMap.get(sorName)!;
      if (!patterns.some(p => p.test(content))) continue;
      if (!sorResult.files.includes(filePath)) sorResult.files.push(filePath);

      // Extract URL endpoints
      REST_URL_PATTERN.lastIndex = 0;
      let urlMatch: RegExpExecArray | null;
      while ((urlMatch = REST_URL_PATTERN.exec(content)) !== null) {
        const url = urlMatch[1];
        const lineIdx = content.substring(0, urlMatch.index).split("\n").length - 1;
        const contextLine = lines[lineIdx] || "";
        const methodMatch = contextLine.match(HTTP_METHOD_PATTERN);
        const method = methodMatch ? methodMatch[1] : "Unknown";

        if (!sorResult.endpoints.find(e => e.url === url)) {
          const ep: EndpointFinding = {
            url, method,
            description: `Outbound call found in ${filePath.split("/").pop()}`,
            sourceFile: filePath,
            language: lang,
          };
          sorResult.endpoints.push(ep);

          // Add to extraction JSON
          apiIntegrations.push({
            sor_name: sorName,
            endpoint: url,
            http_method: method,
            language: lang,
            source_file: filePath,
            source_class_or_function: contextName,
            config_location: "",
            matched_by: getMatchedBy(lang),
          });
        }
      }

      // Config-reference endpoints (e.g. ${crps.url})
      if (sorResult.endpoints.length === 0) {
        const propMatch = content.match(/["'](https?:\/\/\$\{[^}]+\}[^"']*)['"]/);
        if (propMatch) {
          sorResult.endpoints.push({
            url: propMatch[1], method: "Unknown",
            description: `Configured endpoint for ${sorName}`,
            sourceFile: filePath, configFile: filePath, language: lang,
          });
          apiIntegrations.push({
            sor_name: sorName, endpoint: propMatch[1], http_method: "Unknown",
            language: lang, source_file: filePath, source_class_or_function: contextName,
            config_location: filePath, matched_by: "config-property",
          });
        }

        // YAML / properties URL patterns
        CONFIG_URL_PATTERN.lastIndex = 0;
        YAML_URL_PATTERN.lastIndex = 0;
        let cfgMatch: RegExpExecArray | null;
        const cfgPatterns = [CONFIG_URL_PATTERN, YAML_URL_PATTERN, ENV_URL_PATTERN];
        for (const cp of cfgPatterns) {
          cp.lastIndex = 0;
          while ((cfgMatch = cp.exec(content)) !== null) {
            const url = cfgMatch[1];
            if (!sorResult.endpoints.find(e => e.url === url)) {
              sorResult.endpoints.push({
                url, method: "Unknown",
                description: `Config endpoint for ${sorName}`,
                sourceFile: filePath, configFile: filePath, language: lang,
              });
              apiIntegrations.push({
                sor_name: sorName, endpoint: url, http_method: "Unknown",
                language: lang, source_file: filePath, source_class_or_function: contextName,
                config_location: filePath, matched_by: "config-url-pattern",
              });
            }
          }
        }
      }
    }
  }

  return { sorFindings: Array.from(resultMap.values()), apiIntegrations };
}

function getMatchedBy(lang: string): string {
  const map: Record<string, string> = {
    "Java": "javalang-regex",
    "C#": "roslyn-regex",
    "Python": "ast-regex",
    "React-JS": "tree-sitter-regex",
    "SQL": "sqlparse-regex",
    "Config": "yaml-properties-regex",
  };
  return map[lang] || "ripgrep-fallback";
}

// ─── Stage 1: Table scanner ───────────────────────────────────────────────────

function scanForTables(files: Map<string, string>): {
  tableFindings: TableFinding[];
  tableUsages: ExtractionTableUsage[];
} {
  const tableFindings: TableFinding[] = [];
  const tableUsages: ExtractionTableUsage[] = [];
  const seen = new Set<string>();

  for (const [filePath, content] of files) {
    const lang = languageOfFile(filePath);
    const classMatch = content.match(JAVA_CLASS_PATTERN) || content.match(PYTHON_CLASS_PATTERN);
    const contextName = classMatch?.[1] || filePath.split("/").pop()?.replace(/\.\w+$/, "") || "";

    for (const tableName of APPROVED_TABLES) {
      const tableRegex = new RegExp(`\\b${tableName}\\b`, "i");
      if (!tableRegex.test(content)) continue;

      const lines = content.split("\n");
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (!tableRegex.test(line)) continue;

        const key = `${tableName}:${filePath}`;
        if (seen.has(key)) continue;
        seen.add(key);

        const queryTypeMatch = line.match(/\b(SELECT|INSERT|UPDATE|DELETE)\b/i);
        const queryType = queryTypeMatch ? queryTypeMatch[1].toUpperCase() : "SELECT";

        tableFindings.push({
          tableName, queryType, sourceFile: filePath,
          exactQuery: line.trim().substring(0, 200),
          language: lang,
        });
        tableUsages.push({
          table_name: tableName, query_type: queryType, language: lang,
          source_file: filePath, source_class_or_proc: contextName,
          raw_query: line.trim().substring(0, 200),
          matched_by: lang === "SQL" ? "sqlparse-regex" : lang === "Java" ? "javalang-regex" : getMatchedBy(lang),
        });
      }
    }
  }

  return { tableFindings, tableUsages };
}

// ─── Stage 1: Demographic / PII field scanner ─────────────────────────────────

function scanForDemographics(files: Map<string, string>): {
  demographicFindings: DemographicFinding[];
  demographicFields: ExtractionDemographicField[];
  unlistedSources: string[];
} {
  const demographicFindings: DemographicFinding[] = [];
  const demographicFields: ExtractionDemographicField[] = [];
  const unlistedSources: string[] = [];
  const seen = new Set<string>();

  for (const [filePath, content] of files) {
    const lang = languageOfFile(filePath);
    const lines = content.split("\n");

    for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
      const line = lines[lineIdx];
      for (const { pattern, fieldName, dataType, matchedBy } of DEMOGRAPHIC_PATTERNS) {
        if (!pattern.test(line)) continue;
        const key = `${fieldName}:${filePath}`;
        if (seen.has(key)) continue;
        seen.add(key);

        demographicFindings.push({ fieldName, dataType, language: lang, sourceFile: filePath, lineNumber: lineIdx + 1, matchedBy });
        demographicFields.push({ field_name: fieldName, data_type: dataType, language: lang, source_file: filePath, line_number: lineIdx + 1, matched_by: matchedBy });
      }
    }

    // Unlisted SOR sources (generic HTTP calls without a known SOR pattern)
    if ((JAVA_API_PATTERN.test(content) || PYTHON_API_PATTERN.test(content) || JS_API_SIGNAL.test(content)) &&
        !SOR_SYSTEMS.some(s => SOR_PATTERNS[s]?.some(p => p.test(content)))) {
      REST_URL_PATTERN.lastIndex = 0;
      let urlMatch: RegExpExecArray | null;
      while ((urlMatch = REST_URL_PATTERN.exec(content)) !== null) {
        const entry = `${urlMatch[1]} (${filePath.split("/").slice(-2).join("/")})`;
        if (!unlistedSources.includes(entry)) unlistedSources.push(entry);
      }
    }
  }

  return { demographicFindings, demographicFields, unlistedSources };
}

// ─── Flow diagram SVG generator ───────────────────────────────────────────────

function generateFlowDiagramSvg(
  repoNames: string[],
  foundSors: string[],
  langs: string[]
): string {
  const repoCount = Math.max(repoNames.length, 1);
  const height = Math.max(400, 200 + repoCount * 40 + foundSors.length * 28);

  // Repo boxes on the left
  const repoBoxes = repoNames.map((name, i) => {
    const y = 60 + i * 50;
    const label = name.length > 22 ? name.substring(0, 20) + "…" : name;
    return `
    <rect x="10" y="${y}" width="160" height="36" rx="6" fill="#dbeafe" stroke="#3b82f6" stroke-width="1.5"/>
    <text x="90" y="${y + 13}" text-anchor="middle" font-size="9" font-weight="600" fill="#1d4ed8">📦 ${label}</text>
    <text x="90" y="${y + 26}" text-anchor="middle" font-size="8" fill="#3b82f6">ZIP / GitHub</text>
    <line x1="170" y1="${y + 18}" x2="210" y2="${140}" stroke="#3b82f6" stroke-width="1.5" stroke-dasharray="4,2" marker-end="url(#arrow)"/>`;
  }).join("");

  // Stage 1 box
  const stage1 = `
  <rect x="210" y="100" width="160" height="80" rx="8" fill="#dcfce7" stroke="#16a34a" stroke-width="2"/>
  <text x="290" y="126" text-anchor="middle" font-size="10" font-weight="700" fill="#15803d">⚙️ STAGE 1</text>
  <text x="290" y="143" text-anchor="middle" font-size="8.5" fill="#166534">Deterministic Parser</text>
  <text x="290" y="157" text-anchor="middle" font-size="8" fill="#166534">${langs.join(" · ") || "Multi-Language"}</text>
  <text x="290" y="170" text-anchor="middle" font-size="8" fill="#166534">No LLM · Reproducible</text>
  <line x1="370" y1="140" x2="410" y2="140" stroke="#16a34a" stroke-width="2" marker-end="url(#arrow-green)"/>`;

  // Extraction JSON box
  const exJson = `
  <rect x="410" y="110" width="130" height="60" rx="8" fill="#fef9c3" stroke="#d97706" stroke-width="1.5"/>
  <text x="475" y="132" text-anchor="middle" font-size="10" font-weight="700" fill="#854d0e">📄 extraction</text>
  <text x="475" y="148" text-anchor="middle" font-size="10" font-weight="700" fill="#854d0e">.json</text>
  <text x="475" y="163" text-anchor="middle" font-size="8" fill="#92400e">Stage 1 output</text>
  <line x1="540" y1="140" x2="580" y2="140" stroke="#d97706" stroke-width="2" marker-end="url(#arrow-amber)"/>`;

  // Stage 2 box
  const stage2 = `
  <rect x="580" y="100" width="150" height="80" rx="8" fill="#ede9fe" stroke="#7c3aed" stroke-width="2"/>
  <text x="655" y="126" text-anchor="middle" font-size="10" font-weight="700" fill="#6d28d9">🤖 STAGE 2</text>
  <text x="655" y="143" text-anchor="middle" font-size="8.5" fill="#5b21b6">BRD Narrative</text>
  <text x="655" y="157" text-anchor="middle" font-size="8" fill="#5b21b6">Temp=0, JSON-only</text>
  <text x="655" y="170" text-anchor="middle" font-size="8" fill="#5b21b6">No hallucination</text>
  <line x1="730" y1="140" x2="770" y2="140" stroke="#7c3aed" stroke-width="2" marker-end="url(#arrow-purple)"/>`;

  // BRD Report box
  const brd = `
  <rect x="770" y="100" width="130" height="80" rx="8" fill="#fce7f3" stroke="#db2777" stroke-width="1.5"/>
  <text x="835" y="126" text-anchor="middle" font-size="10" font-weight="700" fill="#9d174d">📑 BRD</text>
  <text x="835" y="142" text-anchor="middle" font-size="10" font-weight="700" fill="#9d174d">HTML Report</text>
  <text x="835" y="158" text-anchor="middle" font-size="8" fill="#be185d">SOR Findings</text>
  <text x="835" y="172" text-anchor="middle" font-size="8" fill="#be185d">Demographics · Impact</text>`;

  // SOR dependency boxes at bottom
  const sorBoxes = foundSors.map((sor, i) => {
    const x = 30 + i * 88;
    const y = height - 90;
    return `
    <rect x="${x}" y="${y}" width="78" height="28" rx="5" fill="#dcfce7" stroke="#16a34a" stroke-width="1.2"/>
    <text x="${x + 39}" y="${y + 18}" text-anchor="middle" font-size="9" font-weight="600" fill="#15803d">${sor}</text>
    <line x1="${x + 39}" y1="${y}" x2="290" y2="180" stroke="#16a34a" stroke-width="1" stroke-dasharray="3,2" opacity="0.5"/>`;
  }).join("");

  const totalWidth = Math.max(920, 30 + foundSors.length * 88);

  return `<svg viewBox="0 0 ${totalWidth} ${height}" xmlns="http://www.w3.org/2000/svg" font-family="'Segoe UI',system-ui,sans-serif">
  <defs>
    <marker id="arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
      <path d="M0,0 L0,6 L8,3 z" fill="#3b82f6"/>
    </marker>
    <marker id="arrow-green" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
      <path d="M0,0 L0,6 L8,3 z" fill="#16a34a"/>
    </marker>
    <marker id="arrow-amber" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
      <path d="M0,0 L0,6 L8,3 z" fill="#d97706"/>
    </marker>
    <marker id="arrow-purple" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
      <path d="M0,0 L0,6 L8,3 z" fill="#7c3aed"/>
    </marker>
  </defs>
  <!-- Background -->
  <rect width="${totalWidth}" height="${height}" fill="#f8fafc" rx="12"/>
  <!-- Title -->
  <text x="${totalWidth / 2}" y="30" text-anchor="middle" font-size="13" font-weight="700" fill="#1e3a5f">Two-Stage SOR Discovery Pipeline</text>
  <text x="${totalWidth / 2}" y="48" text-anchor="middle" font-size="9" fill="#64748b">Stage 1: Deterministic extraction → Stage 2: BRD narrative generation</text>
  <!-- Repo boxes -->
  ${repoBoxes}
  <!-- Stage 1 -->
  ${stage1}
  <!-- Extraction JSON -->
  ${exJson}
  <!-- Stage 2 -->
  ${stage2}
  <!-- BRD -->
  ${brd}
  <!-- SOR dependencies -->
  ${foundSors.length > 0 ? `
  <text x="${totalWidth / 2}" y="${height - 110}" text-anchor="middle" font-size="9" fill="#64748b" font-weight="600">SOR Systems Detected</text>
  ${sorBoxes}` : ""}
</svg>`;
}

// ─── HTML report (BRD spec: all required sections) ───────────────────────────

function generateHtmlReport(
  result: Omit<ApiScanResult, "htmlReport" | "extractionJson">,
  zipNames: string[],
  context: ApplicationContext,
  extractionJson: ExtractionJson,
  aiInsights?: string
): string {
  const now = new Date().toLocaleString();
  const isApiBased  = result.integrationType === "API-Based"   || result.integrationType === "Both";
  const isQueryBased = result.integrationType === "Query-Based" || result.integrationType === "Both";
  const foundSorNames = result.sorFindings.filter(s => s.endpoints.length > 0 || s.files.length > 0).map(s => s.sorName);
  const flowSvg = generateFlowDiagramSvg(zipNames, foundSorNames, result.languagesDetected);

  const sorRows = result.sorFindings.map(s => {
    if (s.endpoints.length === 0 && s.files.length === 0) {
      return `<tr class="not-found"><td><span class="sor-badge">${s.sorName}</span></td>
        <td colspan="5"><em>No outbound API integration with <strong>${s.sorName}</strong> found</em></td></tr>`;
    }
    if (s.endpoints.length === 0) {
      return `<tr><td><span class="sor-badge found">${s.sorName}</span></td>
        <td colspan="3"><em>Referenced in: <code>${s.files.slice(0,3).map(f=>f.split("/").slice(-2).join("/")).join(", ")}</code></em></td>
        <td>Unknown</td><td><code>${s.files[0]?.split("/").slice(-2).join("/") || ""}</code></td></tr>`;
    }
    return s.endpoints.map((e, i) => `<tr>
      ${i === 0 ? `<td rowspan="${s.endpoints.length}"><span class="sor-badge found">${s.sorName}</span></td>` : ""}
      <td><code>${e.url}</code></td>
      <td><span class="method method-${e.method.toLowerCase()}">${e.method}</span></td>
      <td>${e.description}</td>
      <td><span class="chip">${e.language || "Unknown"}</span></td>
      <td><code>${e.sourceFile.split("/").slice(-2).join("/")}</code></td>
    </tr>`).join("");
  }).join("");

  const tableRows = result.tableFindings.length
    ? result.tableFindings.map(t => `<tr>
        <td><code>${t.tableName}</code></td>
        <td><span class="method method-${t.queryType.toLowerCase()}">${t.queryType}</span></td>
        <td><span class="chip">${t.language || "SQL"}</span></td>
        <td><code>${t.sourceFile.split("/").slice(-2).join("/")}</code></td>
        <td><code class="query-text">${(t.exactQuery || "").replace(/</g,"&lt;").replace(/>/g,"&gt;")}</code></td>
      </tr>`).join("")
    : `<tr><td colspan="5"><em>No approved SOR tables found in the workspace</em></td></tr>`;

  const demoRows = result.demographicFindings.length
    ? result.demographicFindings.map(d => `<tr>
        <td><strong>${d.fieldName}</strong></td>
        <td><code>${d.dataType}</code></td>
        <td><span class="chip">${d.language}</span></td>
        <td><code>${d.sourceFile.split("/").slice(-2).join("/")}</code></td>
        <td>${d.lineNumber}</td>
        <td><code>${d.matchedBy}</code></td>
      </tr>`).join("")
    : `<tr><td colspan="6"><em>No demographic/PII fields found in the scanned files</em></td></tr>`;

  // Origin summary — cross-reference api_integrations with demographic_fields by source_file
  const originRows: string[] = [];
  for (const api of extractionJson.api_integrations) {
    const demoFields = extractionJson.demographic_fields_found
      .filter(d => d.source_file === api.source_file)
      .map(d => d.field_name).join(", ");
    if (demoFields) {
      originRows.push(`<tr>
        <td><code>${api.endpoint}</code></td>
        <td><span class="method method-${api.http_method.toLowerCase()}">${api.http_method}</span></td>
        <td><span class="sor-badge found">${api.sor_name}</span></td>
        <td>${demoFields}</td>
        <td><code>${api.source_file.split("/").slice(-2).join("/")}</code></td>
        <td><span class="chip">${api.language}</span></td>
      </tr>`);
    }
  }
  const originSection = originRows.length
    ? `<table><thead><tr><th>API Endpoint</th><th>HTTP Method</th><th>SOR Name</th><th>Demographic Field(s)</th><th>Source Location</th><th>Language</th></tr></thead><tbody>${originRows.join("")}</tbody></table>`
    : `<p class="muted">No API found returning demographic data (no demographic fields co-located with API integration files).</p>`;

  const contextHtml = `
  <table>
    <tbody>
      <tr><td><strong>Application Name</strong></td><td>${context.applicationName || "<em>Not specified</em>"}</td></tr>
      <tr><td><strong>Business Function</strong></td><td>${context.businessFunction || "<em>Not specified</em>"}</td></tr>
      <tr><td><strong>Domain</strong></td><td>${context.domain || "<em>Not specified</em>"}</td></tr>
      <tr><td><strong>Primary Tech Stack</strong></td><td>${context.techStack || result.languagesDetected.join(", ") || "<em>Auto-detected</em>"}</td></tr>
      <tr><td><strong>Repository / Path</strong></td><td>${context.repositoryPath || zipNames.join(", ")}</td></tr>
      <tr><td><strong>Known Systems</strong></td><td>${context.knownSystems || "<em>Not specified</em>"}</td></tr>
      <tr><td><strong>Compliance Scope</strong></td><td>${context.complianceScope || "<em>Not specified</em>"}</td></tr>
    </tbody>
  </table>`;

  const libsUsed = extractionJson.scan_metadata.libraries_used.map(l =>
    `<span class="chip">${l.language}: ${l.library}</span>`).join(" ");

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>SOR Discovery BRD — ${context.applicationName || "Nucleus 2.0"}</title>
<style>
  :root{--blue:#1e3a5f;--accent:#2563eb;--green:#16a34a;--red:#dc2626;--amber:#d97706;--bg:#f8fafc;--card:#fff}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:#1e293b;line-height:1.6}
  .header{background:linear-gradient(135deg,#1e3a5f 0%,#2563eb 100%);color:#fff;padding:32px 40px}
  .header h1{font-size:1.8rem;font-weight:700;margin-bottom:4px}
  .header p{opacity:.8;font-size:.9rem}
  .badge-row{display:flex;gap:10px;margin-top:14px;flex-wrap:wrap}
  .badge{padding:4px 14px;border-radius:20px;font-size:.78rem;font-weight:600;background:rgba(255,255,255,.18)}
  .badge.api{background:#16a34a22;color:#bbf7d0;border:1px solid #16a34a55}
  .badge.query{background:#d9770622;color:#fde68a;border:1px solid #d9770655}
  .badge.both{background:#7c3aed22;color:#ddd6fe;border:1px solid #7c3aed55}
  .content{max-width:1200px;margin:0 auto;padding:32px 24px}
  .section{background:var(--card);border-radius:10px;border:1px solid #e2e8f0;margin-bottom:28px;overflow:hidden}
  .section-header{background:#f1f5f9;padding:14px 24px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;gap:10px}
  .section-header h2{font-size:1rem;font-weight:700;color:var(--blue)}
  .section-body{padding:20px 24px}
  .meta-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;margin-bottom:24px}
  .meta-card{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px;text-align:center}
  .meta-card .value{font-size:1.5rem;font-weight:700;color:var(--accent)}
  .meta-card .label{font-size:.75rem;color:#64748b;margin-top:2px}
  .int-type{display:inline-flex;align-items:center;gap:8px;padding:8px 20px;border-radius:8px;font-weight:700;font-size:1rem;margin-bottom:16px}
  .int-type.api-based{background:#dcfce7;color:#15803d;border:2px solid #86efac}
  .int-type.query-based{background:#fef9c3;color:#854d0e;border:2px solid #fde047}
  .int-type.both{background:#ede9fe;color:#6d28d9;border:2px solid #c4b5fd}
  .int-type.none{background:#f1f5f9;color:#475569;border:2px solid #cbd5e1}
  table{width:100%;border-collapse:collapse;font-size:.84rem}
  th{background:#f1f5f9;padding:9px 14px;text-align:left;font-weight:600;color:#475569;border-bottom:2px solid #e2e8f0}
  td{padding:9px 14px;border-bottom:1px solid #f1f5f9;vertical-align:top}
  tr:last-child td{border-bottom:none}
  tr.not-found td{color:#94a3b8;background:#fafafa}
  .sor-badge{padding:2px 10px;border-radius:12px;font-size:.75rem;font-weight:600;background:#dbeafe;color:#1d4ed8}
  .sor-badge.found{background:#dcfce7;color:#15803d}
  .method{padding:2px 8px;border-radius:4px;font-size:.72rem;font-weight:700;font-family:monospace}
  .method-get,.method-select{background:#dbeafe;color:#1d4ed8}
  .method-post,.method-insert{background:#dcfce7;color:#15803d}
  .method-put,.method-update{background:#fef9c3;color:#854d0e}
  .method-patch{background:#ede9fe;color:#6d28d9}
  .method-delete{background:#fee2e2;color:#dc2626}
  .method-unknown{background:#f1f5f9;color:#475569}
  code{font-family:'Consolas','Courier New',monospace;font-size:.8rem;color:#0f172a;word-break:break-all}
  .query-text{font-size:.72rem;color:#64748b}
  .why-box{background:#eff6ff;border-left:4px solid #3b82f6;padding:12px 16px;border-radius:0 6px 6px 0;margin-top:12px;font-size:.83rem;color:#1e40af}
  .why-box strong{display:block;margin-bottom:4px;font-size:.78rem;text-transform:uppercase;letter-spacing:.05em}
  .elapsed{font-size:.75rem;color:#94a3b8;margin-top:8px}
  .footer{text-align:center;padding:24px;color:#94a3b8;font-size:.8rem;border-top:1px solid #e2e8f0;margin-top:8px}
  .chip{display:inline-block;padding:2px 8px;background:#e2e8f0;border-radius:10px;font-size:.72rem;color:#475569;margin:2px}
  .muted{color:#94a3b8;font-style:italic;font-size:.85rem}
  .flow-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px;overflow-x:auto}
  pre.json-block{background:#0f172a;color:#e2e8f0;padding:16px;border-radius:8px;font-size:.75rem;overflow-x:auto;max-height:300px;overflow-y:auto}
  .ai-insights-body h4{font-size:.9rem;font-weight:700;color:#6d28d9;margin:12px 0 4px}
  .ai-insights-body p{font-size:.84rem;color:#374151;margin-bottom:8px}
  .ai-insights-body ul{padding-left:20px;margin-bottom:8px}
  .ai-insights-body li{font-size:.83rem;color:#374151;margin-bottom:4px}
  .ai-insights-body strong{color:#1e293b}
</style>
</head>
<body>
<div class="header">
  <h1>📋 SOR & Demographic Data Discovery — BRD</h1>
  <p>${context.applicationName ? `<strong>${context.applicationName}</strong> · ` : ""}Nucleus 2.0 · Zensar Diamond Team · Generated: ${now}</p>
  <div class="badge-row">
    <span class="badge">📦 ${zipNames.length} Repo${zipNames.length !== 1 ? "s" : ""}</span>
    <span class="badge">🔍 ${result.totalFilesScanned} Files</span>
    <span class="badge">⚡ ${result.elapsedTime}</span>
    <span class="badge ${result.integrationType === "Both" ? "both" : result.integrationType === "API-Based" ? "api" : "query"}">${result.integrationType}</span>
    ${result.languagesDetected.map(l => `<span class="badge">🔤 ${l}</span>`).join("")}
  </div>
</div>

<div class="content">

<!-- 1. Executive Summary -->
<div class="section">
  <div class="section-header"><h2>1. Executive Summary</h2></div>
  <div class="section-body">
    <p>This Business Requirements Document was generated by Nucleus 2.0 API Scan using a two-stage deterministic pipeline. Stage 1 extracted exact facts (file paths, line numbers, endpoint strings, table names) from <strong>${result.totalFilesScanned} source files</strong> across <strong>${zipNames.length} repository${zipNames.length !== 1 ? "ies" : "y"}</strong> without invoking any LLM. Stage 2 produced this narrative from the Stage 1 JSON only — no raw source code was shown to the classifier.</p>
    <div class="meta-grid" style="margin-top:16px">
      <div class="meta-card"><div class="value">${result.totalFilesScanned}</div><div class="label">Files Scanned</div></div>
      <div class="meta-card"><div class="value">${foundSorNames.length}</div><div class="label">SORs Detected</div></div>
      <div class="meta-card"><div class="value">${result.tableFindings.length}</div><div class="label">Table References</div></div>
      <div class="meta-card"><div class="value">${result.demographicFindings.length}</div><div class="label">PII Fields Found</div></div>
      <div class="meta-card"><div class="value">${result.languagesDetected.length}</div><div class="label">Languages</div></div>
      <div class="meta-card"><div class="value">${zipNames.length}</div><div class="label">Repositories</div></div>
    </div>
  </div>
</div>

<!-- 2. Application Context -->
<div class="section">
  <div class="section-header"><h2>2. Application Context</h2></div>
  <div class="section-body">${contextHtml}</div>
</div>

<!-- 3. Pipeline Flow Diagram -->
<div class="section">
  <div class="section-header"><h2>3. Scan Pipeline — Two-Stage Architecture</h2></div>
  <div class="section-body">
    <div class="flow-box">${flowSvg}</div>
    <div class="why-box" style="margin-top:12px">
      <strong>Why Two Stages?</strong>
      Pattern-matching or LLM-only scans produce hallucination (model fills gaps with plausible-looking but fabricated endpoints/tables) and drift (re-running gives different results). Separating extraction (deterministic parsers, git-diffable JSON) from narrative generation (constrained classifier, temperature 0, JSON-only input) removes both failure modes structurally.
    </div>
  </div>
</div>

<!-- 4. Integration Type -->
<div class="section">
  <div class="section-header"><h2>4. Integration Type Determination</h2></div>
  <div class="section-body">
    <div class="int-type ${result.integrationType === "Both" ? "both" : result.integrationType === "None" ? "none" : result.integrationType.toLowerCase().replace(" ", "-")}">
      Integration Type: ${result.integrationType}
    </div>
    <div class="why-box">
      <strong>WHY</strong>
      ${result.integrationType === "API-Based"
        ? "The workspace contains outbound HTTP client declarations (FeignClient, RestTemplate, WebClient, fetch, axios, HttpClient) targeting external URLs. No significant direct SQL access patterns were detected for the approved SOR tables."
        : result.integrationType === "Query-Based"
        ? "The workspace accesses SOR data through direct SQL queries or ORM table mappings targeting approved SOR tables, without observable outbound HTTP API calls to external SOR endpoints."
        : result.integrationType === "Both"
        ? "The workspace exhibits both outbound HTTP API calls and direct SQL table access patterns. Some SOR systems are integrated via REST APIs while others are accessed through approved database tables — a Mixed integration."
        : "No definitive API or Query integration signals were detected. The workspace may use indirect patterns, code generation, or frameworks not covered by the current rule set."}
    </div>
    <div class="elapsed">Elapsed Time: ${result.elapsedTime} · Languages detected: ${result.languagesDetected.join(", ") || "None"}</div>
  </div>
</div>

<!-- 5. API-Based SOR Findings -->
${isApiBased ? `
<div class="section">
  <div class="section-header"><h2>5. API-Based SOR Findings</h2></div>
  <div class="section-body">
    <p style="margin-bottom:12px;font-size:.85rem;color:#475569">Cross-referenced against approved SOR list: ${SOR_SYSTEMS.map(s => `<span class="chip">${s}</span>`).join("")}</p>
    <table>
      <thead><tr><th>SOR</th><th>Endpoint URL</th><th>Method</th><th>Description</th><th>Language</th><th>Source</th></tr></thead>
      <tbody>${sorRows}</tbody>
    </table>
    <div class="why-box">
      <strong>WHY</strong>
      Each SOR entry is identified by matching language-specific client patterns (FeignClient annotations in Java, HttpClient in C#, requests/httpx in Python, fetch/axios in JS/TS) and URL literals in source files. Only URLs explicitly present in code are reported; inferred endpoints are excluded.
    </div>
    <div class="elapsed">Elapsed Time: ${result.elapsedTime}</div>
  </div>
</div>` : `
<div class="section">
  <div class="section-header"><h2>5. API-Based SOR Findings</h2></div>
  <div class="section-body"><p class="muted">No outbound API integration signals detected. Integration type is ${result.integrationType}.</p></div>
</div>`}

<!-- 6. Query-Based SOR Table Findings -->
${isQueryBased ? `
<div class="section">
  <div class="section-header"><h2>6. Query-Based SOR Table Findings</h2></div>
  <div class="section-body">
    <table>
      <thead><tr><th>Table</th><th>Query Type</th><th>Language</th><th>Source File</th><th>Query Excerpt</th></tr></thead>
      <tbody>${tableRows}</tbody>
    </table>
    <div class="why-box">
      <strong>WHY</strong>
      Only the ${APPROVED_TABLES.length} pre-approved SOR tables are checked. Table references are matched by exact name (case-insensitive) in SQL files, ORM entity definitions (JPA @Table, SQLAlchemy __tablename__, EF DbSet), repository classes, and query strings.
    </div>
    <div class="elapsed">Elapsed Time: ${result.elapsedTime}</div>
  </div>
</div>` : `
<div class="section">
  <div class="section-header"><h2>6. Query-Based SOR Table Findings</h2></div>
  <div class="section-body"><p class="muted">No approved SOR tables found in the workspace.</p></div>
</div>`}

<!-- 7. Holistic Demographic Discovery -->
<div class="section">
  <div class="section-header"><h2>7. Holistic Demographic Discovery (PII Fields)</h2></div>
  <div class="section-body">
    ${result.demographicFindings.length > 0
      ? `<table>
          <thead><tr><th>Field Name</th><th>Data Type</th><th>Language</th><th>Source File</th><th>Line #</th><th>Matched By</th></tr></thead>
          <tbody>${demoRows}</tbody>
        </table>`
      : `<p class="muted">No additional demographic fields or unlisted SOR/table sources found.</p>`}
    ${result.unlisted_sources_found.length > 0 ? `
    <h3 style="font-size:.9rem;font-weight:600;margin-top:16px;color:#374151">Unlisted External Sources</h3>
    <ul style="margin-top:8px;padding-left:18px;font-size:.83rem;color:#64748b">
      ${result.unlisted_sources_found.slice(0,20).map(s => `<li>${s}</li>`).join("")}
    </ul>` : ""}
    <div class="why-box" style="margin-top:12px">
      <strong>WHY</strong>
      Demographic fields are detected by scanning field declarations, column names, and variable names against a curated PII pattern set (SSN, DOB, name, address, phone, email, account/card numbers, gender, income, IP). All matches are verbatim from source — no inferred fields are added.
    </div>
  </div>
</div>

<!-- 8. Demographic Data Origin Summary -->
<div class="section">
  <div class="section-header"><h2>8. Demographic Data Origin Summary</h2></div>
  <div class="section-body">
    ${originSection}
    <div class="why-box" style="margin-top:12px">
      <strong>WHY</strong>
      This table cross-references API integrations and demographic fields by source file co-location — if a file containing an SOR endpoint call also declares PII fields, those fields are likely flowing through that endpoint.
    </div>
  </div>
</div>

<!-- 9. Impacted Components -->
<div class="section">
  <div class="section-header"><h2>9. Impacted Components (Full Stack Engineer View)</h2></div>
  <div class="section-body">
    <table>
      <thead><tr><th>Language/Layer</th><th>Components</th><th>Required Changes</th><th>Recommended Tests</th><th>Priority</th></tr></thead>
      <tbody>
        ${result.languagesDetected.includes("Java") ? `
        <tr>
          <td><span class="chip">Java</span> Backend — Service/DAO</td>
          <td>@FeignClient interfaces, RestTemplate/WebClient beans, JPA Repositories, DAO classes, @Entity POJOs</td>
          <td>Update base URLs, retry/circuit-breaker config, error-handling per SOR; update query filters for approved tables</td>
          <td>Unit tests per service method (mock SOR), integration tests with test DB, SQL assertion tests</td>
          <td><span class="method method-delete">HIGH</span></td>
        </tr>
        <tr>
          <td><span class="chip">Java</span> DTOs / Config</td>
          <td>Request/response models, MapStruct/ModelMapper mappers, application.yml, FeignClient config beans</td>
          <td>Add/remove fields matching SOR API contracts; update endpoint base URLs, auth headers, timeouts</td>
          <td>Serialization/deserialization tests, contract tests, config-loading tests</td>
          <td><span class="method method-put">MEDIUM</span></td>
        </tr>` : ""}
        ${result.languagesDetected.includes("C#") ? `
        <tr>
          <td><span class="chip">C#</span> Backend — Repositories/EF</td>
          <td>HttpClient / RestSharp clients, IRepository implementations, DbContext DbSet mappings, appsettings.json</td>
          <td>Update HttpClient base addresses, add Polly retry/circuit-breaker, update EF migrations for table changes</td>
          <td>xUnit / NUnit unit tests, EF in-memory integration tests, Moq for HttpClient</td>
          <td><span class="method method-delete">HIGH</span></td>
        </tr>` : ""}
        ${result.languagesDetected.includes("Python") ? `
        <tr>
          <td><span class="chip">Python</span> Services/ORM</td>
          <td>requests/httpx service clients, SQLAlchemy models (__tablename__), Django ORM models, Flask/FastAPI routes</td>
          <td>Update service URLs, add retry logic (tenacity), update ORM model fields for SOR schema changes</td>
          <td>pytest unit tests with responses mock, sqlalchemy-pytest for DB, httpretty for HTTP</td>
          <td><span class="method method-delete">HIGH</span></td>
        </tr>` : ""}
        ${result.languagesDetected.includes("React-JS") ? `
        <tr>
          <td><span class="chip">React-JS</span> Frontend / API Consumers</td>
          <td>fetch/axios API clients, React Query hooks (useQuery/useMutation), TypeScript response interfaces, .env base URLs</td>
          <td>Update API base URLs, update TypeScript interface fields, handle new/removed response fields in hooks</td>
          <td>Jest component tests, React Testing Library, E2E tests for data display flows</td>
          <td><span class="method method-get">LOW</span></td>
        </tr>` : ""}
        ${result.languagesDetected.includes("SQL") ? `
        <tr>
          <td><span class="chip">SQL</span> Stored Procedures / Scripts</td>
          <td>Stored procedures, SQL scripts, views referencing approved SOR tables</td>
          <td>Update column references, add/remove joins as SOR schema changes, update stored proc signatures</td>
          <td>SQL unit tests (tSQLt / pgTAP), data validation scripts post-migration</td>
          <td><span class="method method-put">MEDIUM</span></td>
        </tr>` : ""}
        ${!result.languagesDetected.length ? `
        <tr>
          <td><strong>General</strong></td>
          <td>Service classes, repositories, DTOs, config files</td>
          <td>Update SOR base URLs, error handling, field mappings</td>
          <td>Unit and integration tests per affected component</td>
          <td><span class="method method-put">MEDIUM</span></td>
        </tr>` : ""}
      </tbody>
    </table>
    <div class="why-box" style="margin-top:12px">
      <strong>WHY</strong>
      Impacted component breakdown is derived from the detected languages and source_class_or_function values in the Stage 1 extraction JSON. Priority is assigned High for backend integration layers (direct SOR contact), Medium for data/config layers, Low for frontend consumers.
    </div>
  </div>
</div>

<!-- 10. Final Summary -->
<div class="section">
  <div class="section-header"><h2>10. Final Audit Summary</h2></div>
  <div class="section-body">
    <table>
      <tbody>
        <tr><td><strong>Repositories scanned</strong></td><td>${zipNames.join("<br/>")}</td></tr>
        <tr><td><strong>Total files scanned</strong></td><td>${result.totalFilesScanned}</td></tr>
        <tr><td><strong>Languages detected</strong></td><td>${result.languagesDetected.join(", ") || "None"}</td></tr>
        <tr><td><strong>Integration type</strong></td><td>${result.integrationType}</td></tr>
        <tr><td><strong>SORs with findings</strong></td><td>${foundSorNames.join(", ") || "None"}</td></tr>
        <tr><td><strong>SORs not found</strong></td><td>${result.notFoundSors.join(", ") || "All SORs detected"}</td></tr>
        <tr><td><strong>Approved tables found</strong></td><td>${[...new Set(result.tableFindings.map(t=>t.tableName))].join(", ") || "None"}</td></tr>
        <tr><td><strong>PII/Demographic fields</strong></td><td>${result.demographicFindings.length} field type${result.demographicFindings.length !== 1 ? "s" : ""} detected</td></tr>
        <tr><td><strong>Unlisted sources</strong></td><td>${result.unlisted_sources_found.length} external URL${result.unlisted_sources_found.length !== 1 ? "s" : ""} outside known SOR list</td></tr>
      </tbody>
    </table>
    <div class="why-box" style="margin-top:12px">
      <strong>WHY</strong>
      This report only reflects what is explicitly present in the uploaded source code. No endpoints, tables, or integrations are inferred or assumed. Per the BRD specification, Stage 1 extraction is deterministic — running the scan twice on identical source produces byte-identical extraction.json output.
    </div>
    <div class="elapsed">Total Scan Time: ${result.elapsedTime} · Report generated: ${now}</div>
  </div>
</div>

${aiInsights ? `
<!-- AI Insights (Stage 3 — LLM-enhanced, JSON-constrained) -->
<div class="section" style="border-color:#7c3aed">
  <div class="section-header" style="background:#f5f3ff">
    <h2 style="color:#6d28d9">🤖 AI Insights — Stage 3 (Custom Instructions Applied)</h2>
  </div>
  <div class="section-body">
    <div class="why-box" style="border-color:#7c3aed;background:#f5f3ff;color:#5b21b6;margin-bottom:14px">
      <strong>NOTE</strong>
      This section was generated by an LLM constrained to the Stage 1 extraction.json only. It cannot introduce findings not present in that JSON. The user's custom instructions were applied verbatim.
    </div>
    <div class="ai-insights-body">${aiInsights}</div>
  </div>
</div>` : ""}

<!-- 11. Scan Provenance -->
<div class="section">
  <div class="section-header"><h2>11. Scan Provenance</h2></div>
  <div class="section-body">
    <p><strong>Languages detected:</strong> ${result.languagesDetected.join(", ") || "None"}</p>
    <p style="margin-top:8px"><strong>Libraries / parsers used (Stage 1):</strong> ${libsUsed || "<em>regex-based multi-language patterns</em>"}</p>
    <p style="margin-top:8px"><strong>Stage 2 classification:</strong> Rule-based BRD narrative (JSON-constrained, no LLM drift)</p>
    <p style="margin-top:8px"><strong>Stage 1 output (extraction.json):</strong></p>
    <pre class="json-block">${JSON.stringify(extractionJson.scan_metadata, null, 2)}</pre>
    <p style="margin-top:8px"><strong>API integrations extracted:</strong> ${extractionJson.api_integrations.length} entries</p>
    <p style="margin-top:4px"><strong>Table usages extracted:</strong> ${extractionJson.table_usages.length} entries</p>
    <p style="margin-top:4px"><strong>Demographic fields extracted:</strong> ${extractionJson.demographic_fields_found.length} entries</p>
  </div>
</div>

</div>
<div class="footer">Nucleus 2.0 · Zensar Diamond Team · SOR Discovery BRD · Internal Use Only · ${now}</div>
</body>
</html>`;
}

// ─── Library detection for provenance ─────────────────────────────────────────

function buildLibrariesUsed(langs: string[]): ExtractionJson["scan_metadata"]["libraries_used"] {
  const libs = [];
  if (langs.includes("Java"))     libs.push({ language: "Java", artifact_type: "source", library: "javalang-regex", version: "N/A" });
  if (langs.includes("C#"))       libs.push({ language: "C#", artifact_type: "source", library: "roslyn-regex", version: "N/A" });
  if (langs.includes("Python"))   libs.push({ language: "Python", artifact_type: "source", library: "ast-regex", version: "N/A" });
  if (langs.includes("React-JS")) libs.push({ language: "React-JS", artifact_type: "source", library: "tree-sitter-regex", version: "N/A" });
  if (langs.includes("SQL"))      libs.push({ language: "all", artifact_type: "SQL", library: "sqlparse-regex", version: "N/A" });
  libs.push({ language: "all", artifact_type: "config", library: "yaml-properties-env-regex", version: "N/A" });
  libs.push({ language: "all", artifact_type: "fallback", library: "ripgrep-fallback", version: "N/A" });
  return libs;
}

// ─── Public API ───────────────────────────────────────────────────────────────

export async function scanZipFiles(
  zipBuffers: { name: string; buffer: Buffer }[],
  context: ApplicationContext = {},
  customInstructions: string = "",
  aiKey: string = ""
): Promise<ApiScanResult> {
  const start = Date.now();

  // Extract all ZIP files into a unified file map (prefixed by repo name)
  const allFiles = new Map<string, string>();
  for (const { name, buffer } of zipBuffers) {
    const extracted = await extractZip(buffer);
    for (const [path, content] of extracted) {
      allFiles.set(`[${name}] ${path}`, content);
    }
  }

  const totalFilesScanned = allFiles.size;

  // ── Stage 1: Deterministic extraction ────────────────────────────────────
  const languagesDetected = detectLanguages(allFiles);
  const { hasApiSignals, hasQuerySignals } = detectIntegrationSignals(allFiles);

  let integrationType: ApiScanResult["integrationType"] = "None";
  if (hasApiSignals && hasQuerySignals) integrationType = "Both";
  else if (hasApiSignals) integrationType = "API-Based";
  else if (hasQuerySignals) integrationType = "Query-Based";

  const { sorFindings, apiIntegrations } = scanForSors(allFiles);
  const { tableFindings, tableUsages } = scanForTables(allFiles);
  const { demographicFindings, demographicFields, unlistedSources } = scanForDemographics(allFiles);

  const notFoundSors = sorFindings.filter(s => s.endpoints.length === 0 && s.files.length === 0).map(s => s.sorName);
  const notFoundTables = APPROVED_TABLES.filter(t => !tableFindings.some(f => f.tableName === t));

  const scanDuration = Date.now() - start;
  const elapsedTime = `${scanDuration}ms`;
  const zipNames = zipBuffers.map(z => z.name);

  // Build ExtractionJson (Stage 1 output)
  const extractionJson: ExtractionJson = {
    scan_metadata: {
      repo_paths: zipNames,
      languages_detected: languagesDetected,
      scan_timestamp: new Date().toISOString(),
      libraries_used: buildLibrariesUsed(languagesDetected),
      files_scanned_count: totalFilesScanned,
      elapsed_seconds: scanDuration / 1000,
    },
    api_integrations: apiIntegrations,
    table_usages: tableUsages,
    demographic_fields_found: demographicFields,
    unlisted_sources_found: unlistedSources,
  };

  const partial = {
    integrationType,
    zipFiles: zipNames,
    totalFilesScanned,
    scanDuration,
    sorFindings,
    tableFindings,
    demographicFindings,
    unlisted_sources_found: unlistedSources,
    notFoundSors,
    notFoundTables,
    languagesDetected,
    elapsedTime,
  };

  // ── Optional Stage 3: AI Insights (only when key + custom instructions provided) ──
  let aiInsights: string | undefined;
  if (customInstructions && aiKey) {
    try {
      console.log("[API Scan] Calling LLM for AI Insights (Stage 3)...");
      aiInsights = await callLlmInsights(extractionJson, customInstructions, aiKey);
      console.log("[API Scan] LLM Insights generated successfully.");
    } catch (err: any) {
      console.error("[API Scan] LLM insights call failed:", err.message);
      aiInsights = `<p style="color:#dc2626;font-size:.85rem">⚠️ AI analysis could not be completed: ${err.message}</p>`;
    }
  }

  // ── Stage 2: BRD HTML report (rule-based, JSON-constrained) ──────────────
  const htmlReport = generateHtmlReport(partial, zipNames, context, extractionJson, aiInsights);

  return { ...partial, htmlReport, extractionJson };
}

// ─── Stage 3 Direct + Compare ─────────────────────────────────────────────────

export interface CompareResult {
  s1: ApiScanResult;
  s3: ApiScanResult;
  comparisonHtml: string;
}

const DIRECT_CODE_EXT = /\.(ts|tsx|js|jsx|py|java|go|cs|php|rb|kt|swift)$/i;
const DIRECT_CONFIG_EXT = /\.(xml|yaml|yml|json|properties|gradle)$/i;
const DIRECT_MAX_TOTAL = 80_000;
const DIRECT_MAX_PER_FILE = 4_000;

async function collectCodeFiles(
  zipBuffers: { name: string; buffer: Buffer }[]
): Promise<{ path: string; content: string }[]> {
  const result: { path: string; content: string }[] = [];
  let total = 0;
  for (const { name, buffer } of zipBuffers) {
    const zip = await JSZip.loadAsync(buffer);
    const entries = Object.entries(zip.files)
      .filter(([p, f]) => !f.dir && (DIRECT_CODE_EXT.test(p) || DIRECT_CONFIG_EXT.test(p)))
      .sort(([a], [b]) => (DIRECT_CODE_EXT.test(a) ? 0 : 1) - (DIRECT_CODE_EXT.test(b) ? 0 : 1));
    for (const [fp, file] of entries) {
      if (total >= DIRECT_MAX_TOTAL) break;
      const raw = await file.async("text").catch(() => "");
      if (!raw.trim()) continue;
      const slice = raw.slice(0, DIRECT_MAX_PER_FILE);
      result.push({ path: `[${name}]/${fp}`, content: slice });
      total += slice.length;
    }
  }
  return result;
}

const EXTRACTION_SCHEMA = `{
  "scan_metadata": { "repo_paths":["string"], "languages_detected":["Java|Python|C#|React-JS|SQL|Go|Ruby"], "scan_timestamp":"ISO string", "libraries_used":[], "files_scanned_count":0, "elapsed_seconds":0 },
  "api_integrations": [{ "sor_name":"system name (CRPS/Anagrafe/Triumph/etc)", "endpoint":"URL or path", "http_method":"GET|POST|PUT|DELETE|PATCH", "language":"string", "source_file":"path", "source_class_or_function":"class/method", "config_location":"config path", "matched_by":"LLM-Direct" }],
  "table_usages": [{ "table_name":"string", "query_type":"SELECT|INSERT|UPDATE|DELETE|DDL", "language":"string", "source_file":"path", "source_class_or_proc":"string", "raw_query":"SQL snippet", "matched_by":"LLM-Direct" }],
  "demographic_fields_found": [{ "field_name":"string", "data_type":"string", "language":"string", "source_file":"path", "line_number":0, "matched_by":"LLM-Direct" }],
  "unlisted_sources_found": ["URL or hostname not matching known SORs"]
}`;

export async function directLlmScan(
  zipBuffers: { name: string; buffer: Buffer }[],
  context: ApplicationContext = {},
  aiKey: string = ""
): Promise<ApiScanResult> {
  if (!aiKey) throw new Error("An AI key is required for Stage 3 Direct scan.");
  const t0 = Date.now();
  const codeFiles = await collectCodeFiles(zipBuffers);

  const fileBlock = codeFiles.map(f => `=== ${f.path} ===\n${f.content}`).join("\n\n");

  const systemPrompt =
    `You are an expert enterprise software architect performing a System of Record (SOR) discovery scan.\n` +
    `Extract ALL of the following from the provided source code:\n` +
    `1. API integrations — outbound HTTP calls, REST/SOAP clients, WebClient/HttpClient/axios/fetch/RestTemplate/Feign\n` +
    `2. Database table usages — SQL queries, ORM entities, JPA/Hibernate/Entity Framework table names, stored proc calls\n` +
    `3. Demographic/PII fields — name, email, phone, SSN, DOB, address, national ID in models/DTOs/entities/forms\n` +
    `4. Unlisted external sources — hostnames/URLs not matching known SOR systems\n\n` +
    `Known SOR keywords (set sor_name if endpoint/class matches): CRPS, Anagrafe, Income SOR, Triumph, MNS, GSTAR, CM-CARS, APA AR, CARE, DIG, GAR.\n` +
    `Application context: ${JSON.stringify(context)}\n\n` +
    `STRICT RULES:\n` +
    `- Include ONLY what you actually find in the code\n` +
    `- matched_by must always be exactly "LLM-Direct"\n` +
    `- Respond with ONLY valid JSON matching the schema — no markdown, no explanation, no code fences`;

  const userPrompt = `SOURCE CODE:\n${fileBlock}\n\nSchema to match exactly:\n${EXTRACTION_SCHEMA}\n\nJSON only:`;

  let rawText = "";
  if (aiKey.startsWith("sk-ant-")) {
    const client = new Anthropic({ apiKey: aiKey });
    const resp = await client.messages.create({
      model: "claude-opus-4-5",
      max_tokens: 4096,
      messages: [{ role: "user", content: userPrompt }],
      system: systemPrompt,
    });
    rawText = resp.content[0]?.type === "text" ? resp.content[0].text : "{}";
  } else {
    const oai = new OpenAI({ apiKey: aiKey });
    const resp = await oai.chat.completions.create({
      model: "gpt-4o",
      max_tokens: 4096,
      response_format: { type: "json_object" },
      messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userPrompt }],
    });
    rawText = resp.choices[0]?.message?.content || "{}";
  }

  const jsonStr = rawText.replace(/^```(?:json)?\n?/, "").replace(/\n?```$/, "").trim();
  let parsed: any;
  try { parsed = JSON.parse(jsonStr); } catch {
    throw new Error("LLM returned invalid JSON. Please try again or use a different pipeline mode.");
  }

  const elapsed = (Date.now() - t0) / 1000;
  const zipNames = zipBuffers.map(z => z.name);

  const extractionJson: ExtractionJson = {
    scan_metadata: {
      repo_paths: zipNames,
      languages_detected: parsed.scan_metadata?.languages_detected ?? [],
      scan_timestamp: new Date().toISOString(),
      libraries_used: parsed.scan_metadata?.libraries_used ?? [],
      files_scanned_count: codeFiles.length,
      elapsed_seconds: elapsed,
    },
    api_integrations: (parsed.api_integrations ?? []).map((x: any) => ({
      sor_name: x.sor_name ?? "",
      endpoint: x.endpoint ?? "",
      http_method: x.http_method ?? "GET",
      language: x.language ?? "",
      source_file: x.source_file ?? "",
      source_class_or_function: x.source_class_or_function ?? "",
      config_location: x.config_location ?? "",
      matched_by: "LLM-Direct",
    })),
    table_usages: (parsed.table_usages ?? []).map((x: any) => ({
      table_name: x.table_name ?? "",
      query_type: x.query_type ?? "SELECT",
      language: x.language ?? "",
      source_file: x.source_file ?? "",
      source_class_or_proc: x.source_class_or_proc ?? "",
      raw_query: x.raw_query ?? "",
      matched_by: "LLM-Direct",
    })),
    demographic_fields_found: (parsed.demographic_fields_found ?? []).map((x: any) => ({
      field_name: x.field_name ?? "",
      data_type: x.data_type ?? "string",
      language: x.language ?? "",
      source_file: x.source_file ?? "",
      line_number: x.line_number ?? 0,
      matched_by: "LLM-Direct",
    })),
    unlisted_sources_found: (parsed.unlisted_sources_found ?? []).map((x: any) => String(x)),
  };

  // Map ExtractionJson → SorFinding / TableFinding / DemographicFinding
  const sorSystemNames = Object.keys(SOR_PATTERNS);
  const sorMap = new Map<string, SorFinding>();
  for (const s of sorSystemNames) sorMap.set(s, { sorName: s, endpoints: [], files: [] });

  for (const ai of extractionJson.api_integrations) {
    const nameUp = (ai.sor_name ?? "").toUpperCase();
    let matched = sorSystemNames.find(s =>
      nameUp.includes(s.toUpperCase()) ||
      (ai.endpoint ?? "").toUpperCase().includes(s.toUpperCase()) ||
      (ai.source_file ?? "").toUpperCase().includes(s.replace(/\s/g, "").toUpperCase())
    );
    if (!matched) {
      const label = `Unlisted: ${ai.sor_name || (ai.endpoint?.split("/")[2]) || "Unknown"}`;
      if (!sorMap.has(label)) sorMap.set(label, { sorName: label, endpoints: [], files: [] });
      matched = label;
    }
    sorMap.get(matched)!.endpoints.push({
      url: ai.endpoint,
      method: ai.http_method,
      description: ai.source_class_or_function,
      sourceFile: ai.source_file,
      language: ai.language,
    });
  }

  const sorFindings = Array.from(sorMap.values());
  const foundNames = new Set(sorFindings.filter(s => s.endpoints.length > 0).map(s => s.sorName));
  const notFoundSors = sorSystemNames.filter(s => !foundNames.has(s));

  const tableFindings: TableFinding[] = extractionJson.table_usages.map(t => ({
    tableName: t.table_name,
    queryType: t.query_type,
    sourceFile: t.source_file,
    exactQuery: t.raw_query,
    language: t.language,
  }));

  const demographicFindings: DemographicFinding[] = extractionJson.demographic_fields_found.map(d => ({
    fieldName: d.field_name,
    dataType: d.data_type,
    language: d.language,
    sourceFile: d.source_file,
    lineNumber: d.line_number,
    matchedBy: d.matched_by,
  }));

  const apiCnt = sorFindings.reduce((n, s) => n + s.endpoints.length, 0);
  const integrationType: ApiScanResult["integrationType"] =
    apiCnt > 0 && tableFindings.length > 0 ? "Both"
    : apiCnt > 0 ? "API-Based"
    : tableFindings.length > 0 ? "Query-Based"
    : "None";

  const partial = {
    integrationType,
    zipFiles: zipNames,
    totalFilesScanned: codeFiles.length,
    scanDuration: Date.now() - t0,
    sorFindings,
    tableFindings,
    demographicFindings,
    unlisted_sources_found: extractionJson.unlisted_sources_found,
    notFoundSors,
    notFoundTables: [],
    languagesDetected: extractionJson.scan_metadata.languages_detected,
    elapsedTime: `${elapsed.toFixed(1)}s`,
  };

  const s3Banner = `<div style="text-align:center;padding:14px;background:#f0fdf4;border-radius:8px;color:#15803d;font-size:.85rem;margin-bottom:16px">✅ Generated by <strong>Stage 3 Direct LLM Analysis</strong> — source code was sent directly to the AI model for end-to-end extraction and BRD generation.</div>`;
  const htmlReport = generateHtmlReport(partial, zipNames, context, extractionJson, s3Banner);
  return { ...partial, htmlReport, extractionJson };
}

function generateComparisonHtml(s1: ApiScanResult, s3: ApiScanResult): string {
  const s1Eps  = new Set(s1.extractionJson.api_integrations.map(a => `${a.http_method}:${a.endpoint}`));
  const s3Eps  = new Set(s3.extractionJson.api_integrations.map(a => `${a.http_method}:${a.endpoint}`));
  const commonEps  = [...s1Eps].filter(e => s3Eps.has(e));
  const onlyS1Eps  = [...s1Eps].filter(e => !s3Eps.has(e));
  const onlyS3Eps  = [...s3Eps].filter(e => !s1Eps.has(e));

  const s1Tbls = new Set(s1.extractionJson.table_usages.map(t => t.table_name.toLowerCase()));
  const s3Tbls = new Set(s3.extractionJson.table_usages.map(t => t.table_name.toLowerCase()));
  const commonTbls = [...s1Tbls].filter(t => s3Tbls.has(t));
  const onlyS1Tbls = [...s1Tbls].filter(t => !s3Tbls.has(t));
  const onlyS3Tbls = [...s3Tbls].filter(t => !s1Tbls.has(t));

  const s1Pii  = new Set(s1.extractionJson.demographic_fields_found.map(d => d.field_name.toLowerCase()));
  const s3Pii  = new Set(s3.extractionJson.demographic_fields_found.map(d => d.field_name.toLowerCase()));
  const commonPii  = [...s1Pii].filter(p => s3Pii.has(p));
  const onlyS1Pii  = [...s1Pii].filter(p => !s3Pii.has(p));
  const onlyS3Pii  = [...s3Pii].filter(p => !s1Pii.has(p));

  const totalUnique = new Set([...s1Eps, ...s3Eps]).size;
  const overlapPct = totalUnique > 0 ? Math.round((commonEps.length / totalUnique) * 100) : 100;

  function diffRows(only1: string[], only3: string[], common: string[]): string {
    const rows: string[] = [];
    for (const x of common)  rows.push(`<tr><td style="padding:8px 12px;border-bottom:1px solid #f1f5f9"><span style="padding:2px 8px;border-radius:9999px;font-size:.75rem;font-weight:600;background:#dcfce7;color:#166534">Both</span></td><td style="padding:8px 12px;border-bottom:1px solid #f1f5f9;font-family:monospace;word-break:break-all">${x}</td><td style="padding:8px 12px;border-bottom:1px solid #f1f5f9">✅ Agreed</td></tr>`);
    for (const x of only1)  rows.push(`<tr><td style="padding:8px 12px;border-bottom:1px solid #f1f5f9"><span style="padding:2px 8px;border-radius:9999px;font-size:.75rem;font-weight:600;background:#fef9c3;color:#854d0e">S1 only</span></td><td style="padding:8px 12px;border-bottom:1px solid #f1f5f9;font-family:monospace;word-break:break-all">${x}</td><td style="padding:8px 12px;border-bottom:1px solid #f1f5f9">⚙️ Deterministic found; LLM missed</td></tr>`);
    for (const x of only3)  rows.push(`<tr><td style="padding:8px 12px;border-bottom:1px solid #f1f5f9"><span style="padding:2px 8px;border-radius:9999px;font-size:.75rem;font-weight:600;background:#ede9fe;color:#6d28d9">S3 only</span></td><td style="padding:8px 12px;border-bottom:1px solid #f1f5f9;font-family:monospace;word-break:break-all">${x}</td><td style="padding:8px 12px;border-bottom:1px solid #f1f5f9">🤖 LLM found; deterministic missed</td></tr>`);
    if (!rows.length) rows.push(`<tr><td colspan="3" style="padding:20px;text-align:center;color:#94a3b8">None found by either stage</td></tr>`);
    return rows.join("\n");
  }

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>S1 vs S3 Comparison — Nucleus 2.0</title>
<style>
*{box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;margin:0;background:#f8fafc;color:#1e293b}
.header{background:linear-gradient(135deg,#1e3a5f,#7c3aed);color:#fff;padding:28px 36px}
.header h1{margin:0 0 6px;font-size:1.5rem}
.header p{margin:0;opacity:.8;font-size:.85rem}
.content{max-width:1100px;margin:28px auto;padding:0 20px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:12px;margin-bottom:24px}
.card{background:#fff;border-radius:10px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.08);text-align:center}
.num{font-size:1.8rem;font-weight:800;margin-bottom:2px}
.lbl{font-size:.75rem;color:#64748b}
.section{background:#fff;border-radius:10px;box-shadow:0 1px 3px rgba(0,0,0,.08);margin-bottom:20px;overflow:hidden}
.sh{padding:14px 18px;font-weight:700;font-size:.9rem;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;gap:8px}
.sh .meta{margin-left:auto;font-size:.78rem;font-weight:400;color:#64748b}
table{width:100%;border-collapse:collapse;font-size:.82rem}
th{padding:9px 12px;background:#f8fafc;text-align:left;font-weight:600;color:#475569;border-bottom:2px solid #e2e8f0;font-size:.78rem;text-transform:uppercase;letter-spacing:.04em}
.legend{display:flex;gap:14px;flex-wrap:wrap;padding:10px 18px;background:#f8fafc;border-top:1px solid #e2e8f0;font-size:.78rem;color:#64748b;align-items:center}
.verdict{background:#fff;border-radius:10px;box-shadow:0 1px 3px rgba(0,0,0,.08);padding:18px 22px;margin-bottom:20px}
.verdict h3{margin:0 0 10px;font-size:.95rem}
.verdict p{margin:0 0 8px;font-size:.83rem;color:#475569;line-height:1.6}
</style>
</head>
<body>
<div class="header">
  <h1>🔬 Stage 1 vs Stage 3 Comparison Report</h1>
  <p>Deterministic Parser (S1+2) vs Direct LLM Analysis (S3 Direct) — Generated ${new Date().toLocaleString()}</p>
</div>
<div class="content">
  <div class="grid">
    <div class="card"><div class="num" style="color:#2563eb">${s1.extractionJson.api_integrations.length}</div><div class="lbl">S1 API Integrations</div></div>
    <div class="card"><div class="num" style="color:#7c3aed">${s3.extractionJson.api_integrations.length}</div><div class="lbl">S3 API Integrations</div></div>
    <div class="card"><div class="num" style="color:#16a34a">${commonEps.length}</div><div class="lbl">Agreed Endpoints</div></div>
    <div class="card"><div class="num" style="color:#d97706">${overlapPct}%</div><div class="lbl">API Overlap Score</div></div>
    <div class="card"><div class="num" style="color:#2563eb">${s1.extractionJson.table_usages.length}</div><div class="lbl">S1 Tables</div></div>
    <div class="card"><div class="num" style="color:#7c3aed">${s3.extractionJson.table_usages.length}</div><div class="lbl">S3 Tables</div></div>
    <div class="card"><div class="num" style="color:#2563eb">${s1.extractionJson.demographic_fields_found.length}</div><div class="lbl">S1 PII Fields</div></div>
    <div class="card"><div class="num" style="color:#7c3aed">${s3.extractionJson.demographic_fields_found.length}</div><div class="lbl">S3 PII Fields</div></div>
  </div>

  <div class="section">
    <div class="sh">🔌 API Integrations<span class="meta">${commonEps.length} agreed · ${onlyS1Eps.length} S1-only · ${onlyS3Eps.length} S3-only</span></div>
    <table><thead><tr><th>Source</th><th>Endpoint</th><th>Verdict</th></tr></thead>
    <tbody>${diffRows(onlyS1Eps, onlyS3Eps, commonEps)}</tbody></table>
    <div class="legend">
      <span style="padding:2px 8px;border-radius:9999px;font-weight:600;background:#dcfce7;color:#166534">Both</span> Agreed
      <span style="padding:2px 8px;border-radius:9999px;font-weight:600;background:#fef9c3;color:#854d0e">S1 only</span> Deterministic found; LLM missed
      <span style="padding:2px 8px;border-radius:9999px;font-weight:600;background:#ede9fe;color:#6d28d9">S3 only</span> LLM found; deterministic missed
    </div>
  </div>

  <div class="section">
    <div class="sh">🗄️ Database Tables<span class="meta">${commonTbls.length} agreed · ${onlyS1Tbls.length} S1-only · ${onlyS3Tbls.length} S3-only</span></div>
    <table><thead><tr><th>Source</th><th>Table Name</th><th>Verdict</th></tr></thead>
    <tbody>${diffRows(onlyS1Tbls, onlyS3Tbls, commonTbls)}</tbody></table>
    <div class="legend">
      <span style="padding:2px 8px;border-radius:9999px;font-weight:600;background:#dcfce7;color:#166534">Both</span>
      <span style="padding:2px 8px;border-radius:9999px;font-weight:600;background:#fef9c3;color:#854d0e">S1 only</span>
      <span style="padding:2px 8px;border-radius:9999px;font-weight:600;background:#ede9fe;color:#6d28d9">S3 only</span>
    </div>
  </div>

  <div class="section">
    <div class="sh">🔒 PII / Demographic Fields<span class="meta">${commonPii.length} agreed · ${onlyS1Pii.length} S1-only · ${onlyS3Pii.length} S3-only</span></div>
    <table><thead><tr><th>Source</th><th>Field Name</th><th>Verdict</th></tr></thead>
    <tbody>${diffRows(onlyS1Pii, onlyS3Pii, commonPii)}</tbody></table>
    <div class="legend">
      <span style="padding:2px 8px;border-radius:9999px;font-weight:600;background:#dcfce7;color:#166534">Both</span>
      <span style="padding:2px 8px;border-radius:9999px;font-weight:600;background:#fef9c3;color:#854d0e">S1 only</span>
      <span style="padding:2px 8px;border-radius:9999px;font-weight:600;background:#ede9fe;color:#6d28d9">S3 only</span>
    </div>
  </div>

  <div class="verdict">
    <h3>🏁 Analysis Verdict</h3>
    <p><strong>API Overlap Score: ${overlapPct}%</strong> — ${overlapPct >= 80 ? "High agreement. Both stages are consistent — results are reliable." : overlapPct >= 50 ? "Moderate agreement. Review S1-only and S3-only endpoints for completeness." : "Low overlap. The approaches diverge significantly — manual review recommended."}</p>
    <p><strong>S1-only findings</strong> (${onlyS1Eps.length + onlyS1Tbls.length + onlyS1Pii.length} total): High confidence — deterministic regex matched these; LLM may have missed due to context window limits or code style.</p>
    <p><strong>S3-only findings</strong> (${onlyS3Eps.length + onlyS3Tbls.length + onlyS3Pii.length} total): Validate manually — the LLM inferred these from context; the deterministic parser's patterns may not cover them yet.</p>
    <p style="margin-top:10px;font-size:.78rem;color:#94a3b8">Nucleus 2.0 · ${new Date().toISOString()}</p>
  </div>
</div>
</body>
</html>`;
}

export async function compareScan(
  zipBuffers: { name: string; buffer: Buffer }[],
  context: ApplicationContext = {},
  aiKey: string = ""
): Promise<CompareResult> {
  if (!aiKey) throw new Error("An AI key is required for Compare mode.");
  const [s1, s3] = await Promise.all([
    scanZipFiles(zipBuffers, context),
    directLlmScan(zipBuffers, context, aiKey),
  ]);
  return { s1, s3, comparisonHtml: generateComparisonHtml(s1, s3) };
}
