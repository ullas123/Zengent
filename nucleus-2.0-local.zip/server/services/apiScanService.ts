/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import JSZip from "jszip";

// ─── SOR definitions ────────────────────────────────────────────────────────

export const SOR_SYSTEMS = [
  "CRPS", "Anagrafe", "Income SOR", "Triumph", "MNS",
  "GSTAR", "CM-CARS", "APA AR", "CARE", "DIG", "GAR",
];

export const APPROVED_TABLES = [
  "triumph_demographics", "triumph_card_account", "triumph_plastic_card",
  "gstar_card_details", "gstar_account_details", "gstar_customer_demographics",
  "gstar_corp_customer_demographics", "cars_cm_demographics", "mns_demographics_ar",
  "care_demographic", "apa_ar_demographic", "dcp_cm_mobile_dtl", "dcp_cm_email_dtl",
  "anagrafe_customer", "crps_customer_linkage", "gstar_corp_card_details",
  "gstar_corp_account_details",
];

const SOR_PATTERNS: Record<string, RegExp[]> = {
  CRPS:        [/crps/i, /crps[_\-.]?client/i, /crps[_\-.]?service/i, /crps[_\-.]?api/i],
  Anagrafe:    [/anagrafe/i, /anagrafe[_\-.]?client/i, /anagrafe[_\-.]?service/i],
  "Income SOR":[/income[_\-.]?sor/i, /income[_\-.]?service/i, /incomeSor/i],
  Triumph:     [/triumph/i, /triumph[_\-.]?client/i, /triumph[_\-.]?service/i],
  MNS:         [/\bmns\b/i, /mns[_\-.]?client/i, /mns[_\-.]?service/i, /mns[_\-.]?api/i],
  GSTAR:       [/gstar/i, /gstar[_\-.]?client/i, /gstar[_\-.]?service/i],
  "CM-CARS":   [/cm[_\-.]?cars/i, /cmcars/i, /cars[_\-.]?cm/i],
  "APA AR":    [/apa[_\-.]?ar/i, /apaAr/i, /apa[_\-.]?ar[_\-.]?service/i],
  CARE:        [/\bcare\b/i, /care[_\-.]?client/i, /care[_\-.]?service/i],
  DIG:         [/\bdig\b/i, /dig[_\-.]?client/i, /dig[_\-.]?service/i, /dig[_\-.]?api/i],
  GAR:         [/\bgar\b/i, /gar[_\-.]?client/i, /gar[_\-.]?service/i],
};

const HTTP_METHOD_PATTERN = /\b(GET|POST|PUT|PATCH|DELETE)\b/;
const REST_URL_PATTERN = /["'`](https?:\/\/[^"'`\s]{5,})[`'"]/g;
const FEIGN_CLIENT_PATTERN = /@FeignClient|@RestTemplate|RestTemplate|WebClient|HttpClient|RestClient|axios\.|fetch\(|http\.(get|post|put|delete|patch)/i;
const SQL_PATTERN = /\b(SELECT|INSERT|UPDATE|DELETE)\b.*\bFROM\b|\b(SELECT|INSERT|UPDATE|DELETE)\b/i;

// ─── Types ───────────────────────────────────────────────────────────────────

export interface SorFinding {
  sorName: string;
  endpoints: EndpointFinding[];
  files: string[];
}

export interface EndpointFinding {
  url: string;
  method: string;
  description: string;
  sourceFile: string;
  className?: string;
  configFile?: string;
}

export interface TableFinding {
  tableName: string;
  queryType: string;
  sourceFile: string;
  exactQuery?: string;
}

export interface ApiScanResult {
  integrationType: "API-Based" | "Query-Based" | "Both" | "None";
  zipFiles: string[];
  totalFilesScanned: number;
  scanDuration: number;
  sorFindings: SorFinding[];
  tableFindings: TableFinding[];
  notFoundSors: string[];
  notFoundTables: string[];
  htmlReport: string;
  elapsedTime: string;
}

// ─── Scannable file extensions ────────────────────────────────────────────────

const SCANNABLE_EXTS = new Set([
  ".java", ".kt", ".xml", ".properties", ".yml", ".yaml",
  ".ts", ".tsx", ".js", ".jsx", ".py", ".json", ".sql",
  ".conf", ".config", ".env", ".cs", ".go", ".rb",
]);

function isScannable(filename: string): boolean {
  const ext = filename.substring(filename.lastIndexOf(".")).toLowerCase();
  return SCANNABLE_EXTS.has(ext);
}

// ─── Core scan logic ─────────────────────────────────────────────────────────

async function extractZip(buffer: Buffer): Promise<Map<string, string>> {
  const zip = await JSZip.loadAsync(buffer);
  const files = new Map<string, string>();
  for (const [path, file] of Object.entries(zip.files)) {
    if (file.dir || !isScannable(path)) continue;
    try {
      const content = await file.async("string");
      files.set(path, content);
    } catch {
      // skip binary/unreadable
    }
  }
  return files;
}

function detectIntegrationSignals(files: Map<string, string>): {
  hasApiSignals: boolean;
  hasQuerySignals: boolean;
} {
  let hasApiSignals = false;
  let hasQuerySignals = false;

  for (const [, content] of files) {
    if (!hasApiSignals && FEIGN_CLIENT_PATTERN.test(content)) hasApiSignals = true;
    if (!hasQuerySignals && SQL_PATTERN.test(content)) hasQuerySignals = true;
    if (hasApiSignals && hasQuerySignals) break;
  }
  return { hasApiSignals, hasQuerySignals };
}

function scanForSors(files: Map<string, string>): SorFinding[] {
  const results: Map<string, SorFinding> = new Map();

  for (const sorName of SOR_SYSTEMS) {
    results.set(sorName, { sorName, endpoints: [], files: [] });
  }

  for (const [filePath, content] of files) {
    const lines = content.split("\n");

    for (const [sorName, patterns] of Object.entries(SOR_PATTERNS)) {
      const sorResult = results.get(sorName)!;
      const sorMatchInFile = patterns.some((p) => p.test(content));
      if (!sorMatchInFile) continue;

      if (!sorResult.files.includes(filePath)) sorResult.files.push(filePath);

      // Extract URL endpoints near SOR mentions
      let urlMatch: RegExpExecArray | null;
      REST_URL_PATTERN.lastIndex = 0;
      while ((urlMatch = REST_URL_PATTERN.exec(content)) !== null) {
        const url = urlMatch[1];
        // find surrounding lines for method
        const charIdx = urlMatch.index;
        const upTo = content.lastIndexOf("\n", charIdx);
        const contextLine = lines[content.substring(0, charIdx).split("\n").length - 1] || "";
        const methodMatch = contextLine.match(HTTP_METHOD_PATTERN);

        const existing = sorResult.endpoints.find((e) => e.url === url);
        if (!existing) {
          sorResult.endpoints.push({
            url,
            method: methodMatch ? methodMatch[1] : "Unknown",
            description: `Outbound call found in ${filePath.split("/").pop()}`,
            sourceFile: filePath,
          });
        }
      }

      // If no URLs found but SOR keyword present, record the file reference
      if (sorResult.endpoints.length === 0) {
        // look for @Value or property references as config endpoints
        const propMatch = content.match(/["'](https?:\/\/\$\{[^}]+\}[^"']*)['"]/);
        if (propMatch) {
          sorResult.endpoints.push({
            url: propMatch[1],
            method: "Unknown",
            description: `Configured endpoint for ${sorName}`,
            sourceFile: filePath,
            configFile: filePath,
          });
        }
      }
    }
  }

  return Array.from(results.values());
}

function scanForTables(files: Map<string, string>): TableFinding[] {
  const findings: TableFinding[] = [];
  const seen = new Set<string>();

  for (const [filePath, content] of files) {
    for (const tableName of APPROVED_TABLES) {
      const tableRegex = new RegExp(`\\b${tableName}\\b`, "i");
      if (!tableRegex.test(content)) continue;

      const lines = content.split("\n");
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (!tableRegex.test(line)) continue;

        const key = `${tableName}:${filePath}`;
        if (seen.has(key)) continue;
        seen.add(key);

        const queryTypeMatch = line.match(/\b(SELECT|INSERT|UPDATE|DELETE)\b/i);
        findings.push({
          tableName,
          queryType: queryTypeMatch ? queryTypeMatch[1].toUpperCase() : "SELECT",
          sourceFile: filePath,
          exactQuery: line.trim().substring(0, 200),
        });
      }
    }
  }

  return findings;
}

// ─── HTML report generator ────────────────────────────────────────────────────

function generateHtmlReport(
  result: Omit<ApiScanResult, "htmlReport">,
  zipNames: string[]
): string {
  const now = new Date().toLocaleString();
  const isApiBased = result.integrationType === "API-Based" || result.integrationType === "Both";
  const isQueryBased = result.integrationType === "Query-Based" || result.integrationType === "Both";

  const sorRows = result.sorFindings
    .map((s) => {
      if (s.endpoints.length === 0) {
        return `<tr class="not-found"><td><span class="sor-badge">${s.sorName}</span></td>
          <td colspan="4"><em>No outbound API integration with <strong>${s.sorName}</strong> found</em></td></tr>`;
      }
      return s.endpoints
        .map(
          (e, i) => `
        <tr>
          ${i === 0 ? `<td rowspan="${s.endpoints.length}"><span class="sor-badge found">${s.sorName}</span></td>` : ""}
          <td><code>${e.url}</code></td>
          <td><span class="method method-${e.method.toLowerCase()}">${e.method}</span></td>
          <td>${e.description}</td>
          <td><code>${e.sourceFile.split("/").slice(-2).join("/")}</code></td>
        </tr>`
        )
        .join("");
    })
    .join("");

  const tableRows = result.tableFindings.length
    ? result.tableFindings
        .map(
          (t) => `<tr>
          <td><code>${t.tableName}</code></td>
          <td><span class="method method-${t.queryType.toLowerCase()}">${t.queryType}</span></td>
          <td><code>${t.sourceFile.split("/").slice(-2).join("/")}</code></td>
          <td><code class="query-text">${(t.exactQuery || "").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</code></td>
        </tr>`
        )
        .join("")
    : `<tr><td colspan="4"><em>No approved SOR tables found in the workspace</em></td></tr>`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>API Scan Report — Nucleus 2.0</title>
<style>
  :root{--blue:#1e3a5f;--accent:#2563eb;--green:#16a34a;--red:#dc2626;--amber:#d97706;--bg:#f8fafc;--card:#fff}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:#1e293b;line-height:1.6}
  .header{background:linear-gradient(135deg,#1e3a5f 0%,#2563eb 100%);color:#fff;padding:32px 40px}
  .header h1{font-size:1.8rem;font-weight:700;margin-bottom:4px}
  .header p{opacity:.8;font-size:.9rem}
  .badge-row{display:flex;gap:12px;margin-top:16px;flex-wrap:wrap}
  .badge{padding:4px 14px;border-radius:20px;font-size:.78rem;font-weight:600;background:rgba(255,255,255,.18)}
  .badge.api{background:#16a34a22;color:#bbf7d0;border:1px solid #16a34a55}
  .badge.query{background:#d9770622;color:#fde68a;border:1px solid #d9770655}
  .badge.both{background:#7c3aed22;color:#ddd6fe;border:1px solid #7c3aed55}
  .content{max-width:1200px;margin:0 auto;padding:32px 24px}
  .section{background:var(--card);border-radius:10px;border:1px solid #e2e8f0;margin-bottom:28px;overflow:hidden}
  .section-header{background:#f1f5f9;padding:16px 24px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;gap:10px}
  .section-header h2{font-size:1rem;font-weight:700;color:var(--blue)}
  .section-body{padding:20px 24px}
  .meta-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px}
  .meta-card{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px;text-align:center}
  .meta-card .value{font-size:1.6rem;font-weight:700;color:var(--accent)}
  .meta-card .label{font-size:.78rem;color:#64748b;margin-top:2px}
  .int-type{display:inline-flex;align-items:center;gap:8px;padding:8px 20px;border-radius:8px;font-weight:700;font-size:1rem;margin-bottom:16px}
  .int-type.api-based{background:#dcfce7;color:#15803d;border:2px solid #86efac}
  .int-type.query-based{background:#fef9c3;color:#854d0e;border:2px solid #fde047}
  .int-type.both{background:#ede9fe;color:#6d28d9;border:2px solid #c4b5fd}
  .int-type.none{background:#f1f5f9;color:#475569;border:2px solid #cbd5e1}
  table{width:100%;border-collapse:collapse;font-size:.85rem}
  th{background:#f1f5f9;padding:10px 14px;text-align:left;font-weight:600;color:#475569;border-bottom:2px solid #e2e8f0}
  td{padding:10px 14px;border-bottom:1px solid #f1f5f9;vertical-align:top}
  tr:last-child td{border-bottom:none}
  tr.not-found td{color:#94a3b8;background:#fafafa}
  .sor-badge{padding:2px 10px;border-radius:12px;font-size:.75rem;font-weight:600;background:#dbeafe;color:#1d4ed8}
  .sor-badge.found{background:#dcfce7;color:#15803d}
  .method{padding:2px 8px;border-radius:4px;font-size:.72rem;font-weight:700;font-family:monospace}
  .method-get{background:#dbeafe;color:#1d4ed8}
  .method-post{background:#dcfce7;color:#15803d}
  .method-put{background:#fef9c3;color:#854d0e}
  .method-patch{background:#ede9fe;color:#6d28d9}
  .method-delete{background:#fee2e2;color:#dc2626}
  .method-unknown{background:#f1f5f9;color:#475569}
  .method-select{background:#dbeafe;color:#1d4ed8}
  .method-insert{background:#dcfce7;color:#15803d}
  .method-update{background:#fef9c3;color:#854d0e}
  .method-delete{background:#fee2e2;color:#dc2626}
  code{font-family:'Consolas','Courier New',monospace;font-size:.8rem;color:#0f172a;word-break:break-all}
  .query-text{font-size:.73rem;color:#64748b}
  .why-box{background:#eff6ff;border-left:4px solid #3b82f6;padding:12px 16px;border-radius:0 6px 6px 0;margin-top:12px;font-size:.83rem;color:#1e40af}
  .why-box strong{display:block;margin-bottom:4px;font-size:.8rem;text-transform:uppercase;letter-spacing:.05em}
  .elapsed{font-size:.75rem;color:#94a3b8;margin-top:8px}
  .footer{text-align:center;padding:24px;color:#94a3b8;font-size:.8rem;border-top:1px solid #e2e8f0;margin-top:8px}
  .chip{display:inline-block;padding:2px 8px;background:#e2e8f0;border-radius:10px;font-size:.72rem;color:#475569;margin:2px}
</style>
</head>
<body>
<div class="header">
  <h1>🔍 API Scan Report</h1>
  <p>Nucleus 2.0 · Zensar Diamond Team · Generated: ${now}</p>
  <div class="badge-row">
    <span class="badge">Scanned: ${result.totalFilesScanned} files</span>
    <span class="badge">ZIPs: ${zipNames.join(", ")}</span>
    <span class="badge">Duration: ${result.scanDuration}ms</span>
  </div>
</div>

<div class="content">

  <!-- Meta summary -->
  <div class="meta-grid">
    <div class="meta-card"><div class="value">${result.totalFilesScanned}</div><div class="label">Files Scanned</div></div>
    <div class="meta-card"><div class="value">${result.sorFindings.filter(s=>s.endpoints.length>0).length}</div><div class="label">SORs Detected</div></div>
    <div class="meta-card"><div class="value">${result.tableFindings.length}</div><div class="label">Table References</div></div>
    <div class="meta-card"><div class="value">${zipNames.length}</div><div class="label">ZIP Files</div></div>
  </div>

  <!-- Integration type -->
  <div class="section">
    <div class="section-header"><h2>🔌 Integration Type</h2></div>
    <div class="section-body">
      <div class="int-type ${result.integrationType.toLowerCase().replace(" ","-").replace("/","-")}-based ${result.integrationType==="Both"?"both":result.integrationType==="None"?"none":""}">
        Integration Type: ${result.integrationType}
      </div>
      <div class="why-box">
        <strong>WHY</strong>
        ${result.integrationType === "API-Based"
          ? "The workspace contains REST/HTTP client declarations (e.g., FeignClient, RestTemplate, WebClient, fetch, axios) pointing to external URLs, indicating outbound API-based integration with SOR systems. No significant direct SQL table access patterns were detected for the approved SOR tables."
          : result.integrationType === "Query-Based"
          ? "The workspace accesses SOR data through direct SQL queries or ORM mappings targeting approved SOR tables, without observable outbound HTTP client calls to external SOR endpoints. This confirms Query-Based integration."
          : result.integrationType === "Both"
          ? "The workspace exhibits both outbound HTTP API calls and direct SQL table access patterns. Some SOR systems are integrated via REST APIs while others are accessed through approved database tables."
          : "No definitive API or Query integration signals were detected in the scanned source files. The workspace may use indirect patterns, code generation, or frameworks not covered by the current rule set."}
      </div>
      <div class="elapsed">Elapsed Time: ${result.elapsedTime}</div>
    </div>
  </div>

  ${isApiBased ? `
  <!-- API-Based SOR findings -->
  <div class="section">
    <div class="section-header"><h2>🌐 Outbound SOR API Integrations</h2></div>
    <div class="section-body">
      <p style="margin-bottom:12px;font-size:.85rem;color:#475569">Only outbound calls to the following SOR systems are listed: ${SOR_SYSTEMS.map(s=>`<span class="chip">${s}</span>`).join("")}</p>
      <table>
        <thead><tr><th>SOR</th><th>Endpoint URL</th><th>Method</th><th>Description</th><th>Source</th></tr></thead>
        <tbody>${sorRows}</tbody>
      </table>
      <div class="why-box">
        <strong>WHY</strong>
        Each SOR entry is identified by matching well-known client-side patterns (FeignClient annotations, RestTemplate/WebClient usage, fetch/axios calls) and URL literals in source files. Only URLs explicitly present in code are reported; inferred or undeclared endpoints are excluded per the audit requirement.
      </div>
    </div>
  </div>
  ` : ""}

  ${isQueryBased ? `
  <!-- Query-Based table findings -->
  <div class="section">
    <div class="section-header"><h2>🗄️ Approved SOR Table Usage</h2></div>
    <div class="section-body">
      <table>
        <thead><tr><th>Table</th><th>Query Type</th><th>Source File</th><th>Query Excerpt</th></tr></thead>
        <tbody>${tableRows}</tbody>
      </table>
      <div class="why-box">
        <strong>WHY</strong>
        Only the ${APPROVED_TABLES.length} pre-approved SOR tables are checked. Table references are matched by exact name (case-insensitive) in SQL files, ORM entity definitions, repository classes, and query strings. No inferred or assumed table access is reported.
      </div>
    </div>
  </div>
  ` : ""}

  <!-- Not-found SORs -->
  ${result.notFoundSors.length ? `
  <div class="section">
    <div class="section-header"><h2>⚠️ SORs Not Found</h2></div>
    <div class="section-body">
      ${result.notFoundSors.map(s=>`<p>• No outbound API integration with <strong>${s}</strong> found</p>`).join("")}
    </div>
  </div>` : ""}

  <!-- Impacted components -->
  <div class="section">
    <div class="section-header"><h2>🏗️ Impacted Components (Java Full Stack Engineer View)</h2></div>
    <div class="section-body">
      <table>
        <thead><tr><th>Layer</th><th>Components</th><th>Required Changes</th><th>Tests</th><th>Priority</th></tr></thead>
        <tbody>
          <tr>
            <td><strong>Backend — Service Layer</strong></td>
            <td>Service classes calling SOR clients, SOR client interfaces/stubs</td>
            <td>Update base URLs, retry logic, circuit breakers, error handling per SOR</td>
            <td>Unit tests for each service method, mock SOR responses</td>
            <td><span class="method method-delete">HIGH</span></td>
          </tr>
          <tr>
            <td><strong>Backend — Repository/DAO</strong></td>
            <td>JPA Repositories, DAO classes, SQL mappers for approved tables</td>
            <td>Update query filters, add/remove columns per SOR schema changes</td>
            <td>Integration tests with test database, SQL assertion tests</td>
            <td><span class="method method-delete">HIGH</span></td>
          </tr>
          <tr>
            <td><strong>Backend — DTOs/POJOs</strong></td>
            <td>Request/response models, mapping classes (MapStruct/ModelMapper)</td>
            <td>Add/remove fields matching SOR API contracts or table columns</td>
            <td>Serialization/deserialization unit tests, contract tests</td>
            <td><span class="method method-put">MEDIUM</span></td>
          </tr>
          <tr>
            <td><strong>Configuration</strong></td>
            <td>application.yml/properties, FeignClient config, datasource beans</td>
            <td>Update endpoint base URLs, auth headers, timeout settings</td>
            <td>Config loading tests, environment parity checks</td>
            <td><span class="method method-put">MEDIUM</span></td>
          </tr>
          <tr>
            <td><strong>Frontend / API Consumers</strong></td>
            <td>TypeScript API clients, React Query hooks, UI data bindings</td>
            <td>Update field mappings, handle new/removed response fields</td>
            <td>Component tests, E2E tests for data display flows</td>
            <td><span class="method method-get">LOW</span></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Final summary -->
  <div class="section">
    <div class="section-header"><h2>📋 Final Audit Summary</h2></div>
    <div class="section-body">
      <p><strong>ZIP files scanned:</strong> ${zipNames.join(", ")}</p>
      <p style="margin-top:8px"><strong>Total files scanned:</strong> ${result.totalFilesScanned}</p>
      <p style="margin-top:8px"><strong>Integration type determined:</strong> ${result.integrationType}</p>
      <p style="margin-top:8px"><strong>SORs with findings:</strong> ${result.sorFindings.filter(s=>s.endpoints.length>0).map(s=>s.sorName).join(", ") || "None"}</p>
      <p style="margin-top:8px"><strong>SORs not found:</strong> ${result.notFoundSors.join(", ") || "All checked"}</p>
      <p style="margin-top:8px"><strong>Approved tables found:</strong> ${[...new Set(result.tableFindings.map(t=>t.tableName))].join(", ") || "None"}</p>
      <div class="why-box" style="margin-top:16px">
        <strong>WHY</strong>
        This report only reflects what is explicitly present in the uploaded workspace source code. No endpoints, tables, or integrations are inferred or assumed. API and Query findings are kept strictly separate in accordance with the audit requirements.
      </div>
      <div class="elapsed">Total Scan Time: ${result.elapsedTime} | Report generated: ${now}</div>
    </div>
  </div>

</div>
<div class="footer">Nucleus 2.0 · Zensar Diamond Team · API Scan Report · Internal Use Only</div>
</body>
</html>`;
}

// ─── Public API ───────────────────────────────────────────────────────────────

export async function scanZipFiles(
  zipBuffers: { name: string; buffer: Buffer }[]
): Promise<ApiScanResult> {
  const start = Date.now();

  // Extract all ZIP files
  const allFiles = new Map<string, string>();
  for (const { name, buffer } of zipBuffers) {
    const extracted = await extractZip(buffer);
    for (const [path, content] of extracted) {
      allFiles.set(`[${name}] ${path}`, content);
    }
  }

  const totalFilesScanned = allFiles.size;
  const { hasApiSignals, hasQuerySignals } = detectIntegrationSignals(allFiles);

  let integrationType: ApiScanResult["integrationType"] = "None";
  if (hasApiSignals && hasQuerySignals) integrationType = "Both";
  else if (hasApiSignals) integrationType = "API-Based";
  else if (hasQuerySignals) integrationType = "Query-Based";

  const sorFindings = scanForSors(allFiles);
  const tableFindings = scanForTables(allFiles);
  const notFoundSors = sorFindings.filter((s) => s.endpoints.length === 0 && s.files.length === 0).map((s) => s.sorName);
  const notFoundTables = APPROVED_TABLES.filter((t) => !tableFindings.some((f) => f.tableName === t));

  const scanDuration = Date.now() - start;
  const elapsedTime = `${scanDuration}ms`;
  const zipNames = zipBuffers.map((z) => z.name);

  const partial = {
    integrationType,
    zipFiles: zipNames,
    totalFilesScanned,
    scanDuration,
    sorFindings,
    tableFindings,
    notFoundSors,
    notFoundTables,
    elapsedTime,
  };

  const htmlReport = generateHtmlReport(partial, zipNames);

  return { ...partial, htmlReport };
}
