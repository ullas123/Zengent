/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { storage } from "../storage";
import { AnalysisData, JavaClass } from "@shared/schema";
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import JSZip from 'jszip';
import OpenAI from 'openai';
import { EventEmitter } from 'events';

const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

export interface EnrichmentProgress {
  projectId: string;
  totalFiles: number;
  completedFiles: number;
  currentFile: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  fileStatuses: Map<string, { status: 'pending' | 'processing' | 'completed' | 'failed'; description?: string }>;
}

export const enrichmentEmitter = new EventEmitter();
const activeEnrichments = new Map<string, EnrichmentProgress>();

export function getEnrichmentProgress(projectId: string): EnrichmentProgress | undefined {
  return activeEnrichments.get(projectId);
}

async function generateCobolProgramExplanation(
  programName: string,
  programType: string,
  content: string,
  divisions: string[],
  paragraphs: string[],
  copyStatements: string[],
  callStatements: string[],
  fileDefinitions: string[]
): Promise<string> {
  if (!openai) {
    return `${programType.toUpperCase()} program with ${paragraphs.length} paragraphs, ${copyStatements.length} copybooks, and ${callStatements.length} program calls.`;
  }

  try {
    const truncatedContent = content.length > 4000 ? content.substring(0, 4000) + '\n... (truncated)' : content;
    
    const prompt = `You are a COBOL/Mainframe documentation specialist. Document ONLY what is explicitly found in this ${programType} code. Do NOT make assumptions or add information not present in the source.

IMPORTANT FORMATTING RULES:
- Do NOT use markdown symbols like ## or ** or *** 
- Use plain text with clear section headers followed by colons
- Use simple dashes (-) for bullet points
- Keep formatting clean and readable

Program Name: ${programName}
Type: ${programType}
Divisions Found: ${divisions.join(', ') || 'None detected'}
Paragraphs Found: ${paragraphs.slice(0, 20).join(', ')}${paragraphs.length > 20 ? ` ... and ${paragraphs.length - 20} more` : ''}
Copybooks Used: ${copyStatements.join(', ') || 'None'}
Called Programs: ${callStatements.join(', ') || 'None'}
File Definitions: ${fileDefinitions.join(', ') || 'None'}

Source Code:
${truncatedContent}

Provide factual documentation in these sections:

PROGRAM SUMMARY:
State what this program does based only on the code structure, divisions, and paragraphs found.

COMPONENTS DETECTED:
- List the ${divisions.length} divisions found
- List the ${paragraphs.length} paragraphs/sections found
- List the ${copyStatements.length} copybooks referenced
- List the ${callStatements.length} program calls made
- List the ${fileDefinitions.length} file definitions

DATA PROCESSING:
Describe the data flow based on actual file definitions and data items found in the code. Only mention files, datasets, and data structures that are explicitly defined.

PROGRAM CALLS AND DEPENDENCIES:
List only the actual CALL statements and COPY statements found. Do not assume additional dependencies.

KEY PARAGRAPHS:
For each major paragraph found, provide a brief description of what it appears to do based on the code.

Only document what you can see in the code. If something is not clear from the code, state "Not determinable from source" rather than guessing.`;

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-2024-08-06',
      messages: [
        { role: 'system', content: 'You are a COBOL/Mainframe documentation specialist. Document only what is explicitly present in the source code. Never make assumptions or add information not found in the code. Use plain text formatting without markdown symbols (no ##, **, or ***). Provide factual, verifiable documentation based solely on the scanned code.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.2,
      max_tokens: 1500
    });

    return response.choices[0]?.message?.content || `${programType} program - analysis pending`;
  } catch (error) {
    console.error(`Error generating AI explanation for ${programName}:`, error);
    return `${programType.toUpperCase()} program with ${paragraphs.length} paragraphs, ${copyStatements.length} copybooks, and ${callStatements.length} program calls.`;
  }
}

interface CobolProgram {
  name: string;
  type: 'program' | 'copybook' | 'jcl' | 'proc';
  filePath: string;
  divisions: string[];
  sections: string[];
  paragraphs: string[];
  copyStatements: string[];
  callStatements: string[];
  fileDefinitions: string[];
  dataItems: DataItem[];
  procedures: string[];
  cicsCommands: string[];
  imsCommands: string[];
  db2Tables: string[];
  vsamDatasets: string[];
  programType: 'batch' | 'online-cics' | 'online-ims' | 'subroutine';
}

interface DataItem {
  level: string;
  name: string;
  picture: string;
  usage: string;
  occurs: number;
  redefines: string;
}

interface JclJob {
  name: string;
  steps: JclStep[];
  datasets: string[];
  procedures: string[];
}

interface JclStep {
  name: string;
  program: string;
  ddStatements: string[];
}

export async function analyzeCobolProject(projectId: string, zipBuffer: Buffer): Promise<void> {
  let tempDir: string | null = null;
  
  try {
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cobol-analyzer-'));
    
    const zip = new JSZip();
    const zipContent = await zip.loadAsync(zipBuffer);
    
    const cobolFiles: string[] = [];
    const jclFiles: string[] = [];
    const copybookFiles: string[] = [];
    const procFiles: string[] = [];
    
    for (const filename of Object.keys(zipContent.files)) {
      const file = zipContent.files[filename];
      
      if (!file.dir) {
        const filePath = path.join(tempDir, filename);
        const fileDir = path.dirname(filePath);
        
        if (!fs.existsSync(fileDir)) {
          fs.mkdirSync(fileDir, { recursive: true });
        }
        
        const content = await file.async('nodebuffer');
        fs.writeFileSync(filePath, content);
        
        const lowerFilename = filename.toLowerCase();
        if (lowerFilename.endsWith('.cbl') || lowerFilename.endsWith('.cob') || lowerFilename.endsWith('.cobol')) {
          cobolFiles.push(filePath);
        } else if (lowerFilename.endsWith('.jcl')) {
          jclFiles.push(filePath);
        } else if (lowerFilename.endsWith('.cpy') || lowerFilename.endsWith('.copy')) {
          copybookFiles.push(filePath);
        } else if (lowerFilename.endsWith('.proc')) {
          procFiles.push(filePath);
        }
      }
    }

    const allFiles = [...cobolFiles, ...jclFiles, ...copybookFiles, ...procFiles];
    
    if (allFiles.length === 0) {
      await storage.updateProject(projectId, {
        status: 'failed',
      });
      return;
    }

    console.log(`Analyzing COBOL project: ${cobolFiles.length} COBOL, ${jclFiles.length} JCL, ${copybookFiles.length} copybooks`);

    const { analysisData, fileContents } = performQuickCobolAnalysis(cobolFiles, jclFiles, copybookFiles, procFiles, tempDir);
    
    await storage.deleteProjectSourceFiles(projectId);
    
    const sourceFilesToStore = allFiles.map(filePath => {
      const content = fs.readFileSync(filePath, 'utf-8');
      const relativePath = path.relative(tempDir!, filePath);
      const fileSize = Buffer.byteLength(content, 'utf-8');
      const ext = path.extname(filePath).toLowerCase();
      
      let language = 'cobol';
      if (ext === '.jcl') language = 'jcl';
      else if (ext === '.cpy' || ext === '.copy') language = 'copybook';
      else if (ext === '.proc') language = 'proc';
      
      return {
        projectId,
        relativePath,
        content,
        fileSize,
        language,
      };
    });
    
    if (sourceFilesToStore.length > 0) {
      await storage.createSourceFiles(sourceFilesToStore);
      console.log(`Stored ${sourceFilesToStore.length} mainframe source files for project ${projectId}`);
    }
    
    await storage.updateProject(projectId, {
      status: 'completed',
      analysisData,
      fileCount: allFiles.length,
      controllerCount: analysisData.classes.filter(c => c.type === 'program').length,
      serviceCount: analysisData.classes.filter(c => c.type === 'copybook').length,
      repositoryCount: analysisData.classes.filter(c => c.type === 'jcl').length,
      entityCount: analysisData.entities?.length || 0,
    });

    startAiEnrichment(projectId, fileContents);

  } catch (error) {
    console.error('COBOL Analysis error:', error);
    await storage.updateProject(projectId, {
      status: 'failed',
    });
  } finally {
    if (tempDir && fs.existsSync(tempDir)) {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  }
}

function performQuickCobolAnalysis(
  cobolFiles: string[],
  jclFiles: string[],
  copybookFiles: string[],
  procFiles: string[],
  baseDir: string
): { analysisData: AnalysisData; fileContents: Map<string, { name: string; type: string; content: string; metadata: any }> } {
  const classes: AnalysisData['classes'] = [];
  const relationships: AnalysisData['relationships'] = [];
  const patterns: AnalysisData['patterns'] = [];
  const entities: AnalysisData['entities'] = [];
  const packages = new Set<string>();
  const sourceFiles: string[] = [];
  const fileContents = new Map<string, { name: string; type: string; content: string; metadata: any }>();

  for (const filePath of cobolFiles) {
    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      const relativePath = path.relative(baseDir, filePath);
      sourceFiles.push(relativePath);
      
      const program = parseCobolProgram(content, relativePath);
      if (program) {
        fileContents.set(program.name, {
          name: program.name,
          type: 'program',
          content,
          metadata: {
            divisions: program.divisions,
            paragraphs: program.paragraphs,
            copyStatements: program.copyStatements,
            callStatements: program.callStatements,
            fileDefinitions: program.fileDefinitions
          }
        });
        
        classes.push({
          name: program.name,
          package: getLibraryFromPath(relativePath),
          type: 'program',
          annotations: program.divisions,
          methods: program.paragraphs.map(p => ({
            name: p,
            returnType: 'PERFORM',
            parameters: [],
            annotations: []
          })),
          fields: program.dataItems.map(d => ({
            name: d.name,
            type: d.picture || d.usage || 'PIC X',
            annotations: [d.level]
          })),
          dependencies: [...program.copyStatements, ...program.callStatements],
          description: `PROGRAM with ${program.paragraphs.length} paragraphs, ${program.copyStatements.length} copybooks, ${program.callStatements.length} calls. AI analysis pending...`,
          cicsCommands: program.cicsCommands,
          imsCommands: program.imsCommands,
          db2Tables: program.db2Tables,
          vsamDatasets: program.vsamDatasets,
          programType: program.programType
        });
        packages.add(getLibraryFromPath(relativePath));
        
        for (const copybook of program.copyStatements) {
          relationships.push({
            from: program.name,
            to: copybook,
            type: 'COPY'
          });
        }
        
        for (const calledProgram of program.callStatements) {
          relationships.push({
            from: program.name,
            to: calledProgram,
            type: 'CALL'
          });
        }
        
        if (program.fileDefinitions.length > 0) {
          entities.push({
            name: program.name,
            tableName: program.fileDefinitions.join(', '),
            fields: program.fileDefinitions.map(f => ({
              name: f,
              type: 'FILE',
              annotations: ['FILE-DEFINITION']
            }))
          });
        }
      }
    } catch (error) {
      console.error(`Error parsing COBOL file ${filePath}:`, error);
    }
  }

  for (const filePath of copybookFiles) {
    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      const relativePath = path.relative(baseDir, filePath);
      sourceFiles.push(relativePath);
      
      const copybook = parseCopybook(content, relativePath);
      fileContents.set(copybook.name, {
        name: copybook.name,
        type: 'copybook',
        content,
        metadata: {}
      });
      
      classes.push({
        name: copybook.name,
        package: getLibraryFromPath(relativePath),
        type: 'copybook',
        annotations: ['COPYBOOK'],
        methods: [],
        fields: copybook.dataItems.map(d => ({
          name: d.name,
          type: d.picture || 'GROUP',
          annotations: [d.level]
        })),
        dependencies: [],
        description: `COPYBOOK with ${copybook.dataItems.length} data items. AI analysis pending...`
      });
      packages.add(getLibraryFromPath(relativePath));
    } catch (error) {
      console.error(`Error parsing copybook ${filePath}:`, error);
    }
  }

  for (const filePath of jclFiles) {
    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      const relativePath = path.relative(baseDir, filePath);
      sourceFiles.push(relativePath);
      
      const jclJob = parseJcl(content, relativePath);
      fileContents.set(jclJob.name, {
        name: jclJob.name,
        type: 'jcl',
        content,
        metadata: {
          steps: jclJob.steps.map(s => s.name),
          programs: jclJob.steps.map(s => s.program).filter(Boolean),
          datasets: jclJob.datasets
        }
      });
      
      classes.push({
        name: jclJob.name,
        package: 'JCL',
        type: 'jcl',
        annotations: ['JOB'],
        methods: jclJob.steps.map(s => ({
          name: s.name,
          returnType: 'EXEC',
          parameters: s.ddStatements.map(dd => ({ name: dd, type: 'DD' })),
          annotations: [s.program]
        })),
        fields: jclJob.datasets.map(d => ({
          name: d,
          type: 'DATASET',
          annotations: []
        })),
        dependencies: jclJob.procedures,
        description: `JCL JOB with ${jclJob.steps.length} steps, ${jclJob.datasets.length} datasets. AI analysis pending...`
      });
      
      for (const step of jclJob.steps) {
        if (step.program) {
          relationships.push({
            from: jclJob.name,
            to: step.program,
            type: 'EXEC'
          });
        }
      }
    } catch (error) {
      console.error(`Error parsing JCL ${filePath}:`, error);
    }
  }

  for (const filePath of procFiles) {
    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      const relativePath = path.relative(baseDir, filePath);
      sourceFiles.push(relativePath);
      
      const procName = path.basename(filePath, path.extname(filePath)).toUpperCase();
      classes.push({
        name: procName,
        package: 'PROCLIB',
        type: 'procedure',
        annotations: ['PROC'],
        methods: [],
        fields: [],
        dependencies: []
      });
      packages.add('PROCLIB');
    } catch (error) {
      console.error(`Error parsing PROC ${filePath}:`, error);
    }
  }

  patterns.push(...detectCobolPatterns(classes, relationships));

  return {
    analysisData: {
      classes,
      relationships,
      patterns,
      entities,
      dependencies: relationships,
      structure: {
        packages: Array.from(packages),
        sourceFiles
      }
    },
    fileContents
  };
}

const BATCH_SIZE = 5; // Process 5 files in parallel

// Store pending file contents for continuation
const pendingEnrichments = new Map<string, Array<[string, { name: string; type: string; content: string; metadata: any }]>>();

export async function startAiEnrichment(
  projectId: string,
  fileContents: Map<string, { name: string; type: string; content: string; metadata: any }>
): Promise<void> {
  if (!openai) {
    console.log('OpenAI not configured, skipping AI enrichment');
    return;
  }

  const progress: EnrichmentProgress = {
    projectId,
    totalFiles: fileContents.size,
    completedFiles: 0,
    currentFile: '',
    status: 'processing',
    fileStatuses: new Map()
  };

  const fileEntriesArray = Array.from(fileContents.entries());
  for (const [name] of fileEntriesArray) {
    progress.fileStatuses.set(name, { status: 'pending' });
  }

  activeEnrichments.set(projectId, progress);
  enrichmentEmitter.emit('progress', { projectId, ...serializeProgress(progress) });

  setImmediate(async () => {
    try {
      // Process only first batch initially
      const firstBatch = fileEntriesArray.slice(0, BATCH_SIZE);
      const remainingFiles = fileEntriesArray.slice(BATCH_SIZE);
      
      // Store remaining files for later continuation
      if (remainingFiles.length > 0) {
        pendingEnrichments.set(projectId, remainingFiles);
      }

      // Process first batch
      await processBatch(projectId, firstBatch, progress, 0);

      // After first batch, mark as paused if there are remaining files
      if (remainingFiles.length > 0) {
        progress.status = 'paused' as any;
        progress.currentFile = `First batch complete. ${remainingFiles.length} files remaining - click "Continue AI Analysis" to process more.`;
        enrichmentEmitter.emit('progress', { projectId, ...serializeProgress(progress) });
      } else {
        progress.status = 'completed';
        progress.currentFile = '';
        enrichmentEmitter.emit('progress', { projectId, ...serializeProgress(progress) });
        setTimeout(() => activeEnrichments.delete(projectId), 60000);
      }
    } catch (error) {
      console.error('AI enrichment error:', error);
      progress.status = 'failed';
      enrichmentEmitter.emit('progress', { projectId, ...serializeProgress(progress) });
    }
  });
}

export async function continueAiEnrichment(projectId: string): Promise<boolean> {
  const remainingFiles = pendingEnrichments.get(projectId);
  const progress = activeEnrichments.get(projectId);
  
  if (!remainingFiles || remainingFiles.length === 0 || !progress) {
    return false;
  }

  progress.status = 'processing';
  enrichmentEmitter.emit('progress', { projectId, ...serializeProgress(progress) });

  setImmediate(async () => {
    try {
      // Process all remaining batches
      for (let i = 0; i < remainingFiles.length; i += BATCH_SIZE) {
        const batch = remainingFiles.slice(i, i + BATCH_SIZE);
        const batchNumber = Math.floor((progress.completedFiles + i) / BATCH_SIZE) + 1;
        await processBatch(projectId, batch, progress, batchNumber);
      }

      pendingEnrichments.delete(projectId);
      progress.status = 'completed';
      progress.currentFile = '';
      enrichmentEmitter.emit('progress', { projectId, ...serializeProgress(progress) });
      setTimeout(() => activeEnrichments.delete(projectId), 60000);
    } catch (error) {
      console.error('AI enrichment continuation error:', error);
      progress.status = 'failed';
      enrichmentEmitter.emit('progress', { projectId, ...serializeProgress(progress) });
    }
  });

  return true;
}

export function hasPendingEnrichment(projectId: string): boolean {
  const pending = pendingEnrichments.get(projectId);
  return pending !== undefined && pending.length > 0;
}

async function processBatch(
  projectId: string,
  batch: Array<[string, { name: string; type: string; content: string; metadata: any }]>,
  progress: EnrichmentProgress,
  batchNumber: number
): Promise<void> {
  const batchNames = batch.map(([name]) => name);
  
  // Mark batch as processing
  for (const [name] of batch) {
    progress.fileStatuses.set(name, { status: 'processing' });
  }
  progress.currentFile = `Batch ${batchNumber + 1}: ${batchNames.join(', ')}`;
  enrichmentEmitter.emit('progress', { projectId, ...serializeProgress(progress) });

  // Process batch in parallel
  const batchResults = await Promise.allSettled(
    batch.map(async ([name, fileData]) => {
      const meta = fileData.metadata;
      const aiExplanation = await generateCobolProgramExplanation(
        name,
        fileData.type,
        fileData.content,
        meta.divisions || [],
        meta.paragraphs || meta.steps || [],
        meta.copyStatements || [],
        meta.callStatements || meta.programs || [],
        meta.fileDefinitions || meta.datasets || []
      );
      return { name, aiExplanation };
    })
  );

  // Process batch results and update storage
  const successfulUpdates: { name: string; description: string }[] = [];
  
  for (let j = 0; j < batchResults.length; j++) {
    const result = batchResults[j];
    const [name] = batch[j];
    
    if (result.status === 'fulfilled') {
      progress.fileStatuses.set(name, { status: 'completed', description: result.value.aiExplanation });
      successfulUpdates.push({ name, description: result.value.aiExplanation });
    } else {
      console.error(`Error enriching ${name}:`, result.reason);
      progress.fileStatuses.set(name, { status: 'failed' });
    }
    progress.completedFiles++;
  }

  // Batch update storage for all successful enrichments
  if (successfulUpdates.length > 0) {
    const project = await storage.getProject(projectId);
    if (project?.analysisData) {
      const analysisData = project.analysisData as AnalysisData;
      const updatedClasses = analysisData.classes.map((c: JavaClass) => {
        const update = successfulUpdates.find(u => u.name === c.name);
        if (update) {
          return { ...c, description: update.description };
        }
        return c;
      });
      await storage.updateProject(projectId, {
        analysisData: { ...analysisData, classes: updatedClasses }
      });
    }
  }

  enrichmentEmitter.emit('progress', { projectId, ...serializeProgress(progress) });
}

function serializeProgress(progress: EnrichmentProgress): object {
  return {
    totalFiles: progress.totalFiles,
    completedFiles: progress.completedFiles,
    currentFile: progress.currentFile,
    status: progress.status,
    fileStatuses: Object.fromEntries(progress.fileStatuses)
  };
}

function parseCobolProgram(content: string, filePath: string): CobolProgram {
  const lines = content.split('\n');
  const name = extractProgramId(content) || path.basename(filePath, path.extname(filePath)).toUpperCase();
  
  const divisions = extractDivisions(content);
  const sections = extractSections(content);
  const paragraphs = extractParagraphs(content);
  const copyStatements = extractCopyStatements(content);
  const callStatements = extractCallStatements(content);
  const fileDefinitions = extractFileDefinitions(content);
  const dataItems = extractDataItems(content);
  const procedures = extractProcedures(content);
  const cicsCommands = extractCicsCommands(content);
  const imsCommands = extractImsCommands(content);
  const db2Tables = extractDb2Tables(content);
  const vsamDatasets = extractVsamDatasets(content);
  
  let programType: 'batch' | 'online-cics' | 'online-ims' | 'subroutine' = 'batch';
  if (cicsCommands.length > 0) {
    programType = 'online-cics';
  } else if (imsCommands.length > 0) {
    programType = 'online-ims';
  }
  
  return {
    name,
    type: 'program',
    filePath,
    divisions,
    sections,
    paragraphs,
    copyStatements,
    callStatements,
    fileDefinitions,
    dataItems,
    procedures,
    cicsCommands,
    imsCommands,
    db2Tables,
    vsamDatasets,
    programType
  };
}

function parseCopybook(content: string, filePath: string): CobolProgram {
  const name = path.basename(filePath, path.extname(filePath)).toUpperCase();
  const dataItems = extractDataItems(content);
  
  return {
    name,
    type: 'copybook',
    filePath,
    divisions: [],
    sections: [],
    paragraphs: [],
    copyStatements: [],
    callStatements: [],
    fileDefinitions: [],
    dataItems,
    procedures: [],
    cicsCommands: [],
    imsCommands: [],
    db2Tables: [],
    vsamDatasets: [],
    programType: 'subroutine'
  };
}

function parseJcl(content: string, filePath: string): JclJob {
  const lines = content.split('\n');
  const name = extractJobName(content) || path.basename(filePath, path.extname(filePath)).toUpperCase();
  
  const steps: JclStep[] = [];
  const datasets: string[] = [];
  const procedures: string[] = [];
  
  let currentStep: JclStep | null = null;
  
  for (const line of lines) {
    const upperLine = line.toUpperCase();
    
    const execMatch = upperLine.match(/\/\/(\w+)\s+EXEC\s+(?:PGM=)?(\w+)/);
    if (execMatch) {
      if (currentStep) steps.push(currentStep);
      currentStep = {
        name: execMatch[1],
        program: execMatch[2],
        ddStatements: []
      };
    }
    
    const ddMatch = upperLine.match(/\/\/(\w+)\s+DD\s+/);
    if (ddMatch && currentStep) {
      currentStep.ddStatements.push(ddMatch[1]);
    }
    
    const dsnMatch = upperLine.match(/DSN=([^\s,)]+)/);
    if (dsnMatch) {
      datasets.push(dsnMatch[1]);
    }
    
    const procMatch = upperLine.match(/\/\/\s+EXEC\s+(\w+)/);
    if (procMatch && !upperLine.includes('PGM=')) {
      procedures.push(procMatch[1]);
    }
  }
  
  if (currentStep) steps.push(currentStep);
  
  return { name, steps, datasets, procedures };
}

function extractProgramId(content: string): string | null {
  const match = content.match(/PROGRAM-ID\.\s+(\w+)/i);
  return match ? match[1].toUpperCase() : null;
}

function extractJobName(content: string): string | null {
  const match = content.match(/\/\/(\w+)\s+JOB/i);
  return match ? match[1].toUpperCase() : null;
}

function extractDivisions(content: string): string[] {
  const divisions: string[] = [];
  const divisionPatterns = [
    'IDENTIFICATION DIVISION',
    'ENVIRONMENT DIVISION',
    'DATA DIVISION',
    'PROCEDURE DIVISION'
  ];
  
  for (const pattern of divisionPatterns) {
    if (content.toUpperCase().includes(pattern)) {
      divisions.push(pattern);
    }
  }
  
  return divisions;
}

function extractSections(content: string): string[] {
  const sections: string[] = [];
  const regex = /^\s{6,}\w+[\w-]*\s+SECTION\s*\.?\s*$/gim;
  let match;
  
  while ((match = regex.exec(content)) !== null) {
    const sectionName = match[0].trim().replace(/\s+SECTION\s*\.?\s*$/i, '');
    sections.push(sectionName);
  }
  
  return sections;
}

function extractParagraphs(content: string): string[] {
  const paragraphs: string[] = [];
  const lines = content.split('\n');
  
  for (const line of lines) {
    if (line.length >= 8 && /^[\s]{7}[A-Z0-9][\w-]*\s*\.\s*$/i.test(line)) {
      const paragraphName = line.trim().replace(/\.\s*$/, '');
      if (!paragraphName.includes(' ') && paragraphName.length > 0) {
        paragraphs.push(paragraphName);
      }
    }
  }
  
  return paragraphs;
}

function extractCopyStatements(content: string): string[] {
  const copies: string[] = [];
  const regex = /COPY\s+(\w+)/gi;
  let match;
  
  while ((match = regex.exec(content)) !== null) {
    copies.push(match[1].toUpperCase());
  }
  
  return Array.from(new Set(copies));
}

function extractCallStatements(content: string): string[] {
  const calls: string[] = [];
  const regex = /CALL\s+['"]?(\w+)['"]?/gi;
  let match;
  
  while ((match = regex.exec(content)) !== null) {
    calls.push(match[1].toUpperCase());
  }
  
  return Array.from(new Set(calls));
}

function extractFileDefinitions(content: string): string[] {
  const files: string[] = [];
  const regex = /SELECT\s+(\w+)\s+ASSIGN/gi;
  let match;
  
  while ((match = regex.exec(content)) !== null) {
    files.push(match[1].toUpperCase());
  }
  
  return files;
}

function extractDataItems(content: string): DataItem[] {
  const items: DataItem[] = [];
  const regex = /^\s{6,}(\d{2})\s+([\w-]+)(?:\s+PIC(?:TURE)?\s+([^\s.]+))?(?:\s+USAGE\s+(\w+))?(?:\s+OCCURS\s+(\d+))?(?:\s+REDEFINES\s+(\w+))?/gim;
  let match;
  
  while ((match = regex.exec(content)) !== null) {
    items.push({
      level: match[1],
      name: match[2].toUpperCase(),
      picture: match[3] || '',
      usage: match[4] || '',
      occurs: match[5] ? parseInt(match[5]) : 0,
      redefines: match[6] || ''
    });
  }
  
  return items;
}

function extractProcedures(content: string): string[] {
  const procedures: string[] = [];
  const regex = /PERFORM\s+(\w+)/gi;
  let match;
  
  while ((match = regex.exec(content)) !== null) {
    procedures.push(match[1].toUpperCase());
  }
  
  return Array.from(new Set(procedures));
}

function extractCicsCommands(content: string): string[] {
  const commands: string[] = [];
  const regex = /EXEC\s+CICS\s+(\w+)/gi;
  let match;
  
  while ((match = regex.exec(content)) !== null) {
    commands.push(match[1].toUpperCase());
  }
  
  return Array.from(new Set(commands));
}

function extractImsCommands(content: string): string[] {
  const commands: string[] = [];
  const patterns = [
    /EXEC\s+DLI\s+(\w+)/gi,
    /CALL\s+['"]?CBLTDLI['"]?/gi,
    /GU\s+|GN\s+|GNP\s+|GHU\s+|ISRT\s+|DLET\s+|REPL\s+/gi
  ];
  
  for (const regex of patterns) {
    let match;
    while ((match = regex.exec(content)) !== null) {
      if (match[1]) {
        commands.push(match[1].toUpperCase());
      } else {
        commands.push('DL/I');
      }
    }
  }
  
  return Array.from(new Set(commands));
}

function extractDb2Tables(content: string): string[] {
  const tables: string[] = [];
  const patterns = [
    /EXEC\s+SQL[\s\S]*?FROM\s+(\w+)/gi,
    /EXEC\s+SQL[\s\S]*?INTO\s+(\w+)/gi,
    /EXEC\s+SQL[\s\S]*?UPDATE\s+(\w+)/gi,
    /EXEC\s+SQL[\s\S]*?DELETE\s+FROM\s+(\w+)/gi,
    /EXEC\s+SQL[\s\S]*?INSERT\s+INTO\s+(\w+)/gi
  ];
  
  for (const regex of patterns) {
    let match;
    while ((match = regex.exec(content)) !== null) {
      if (match[1] && !['INTO', 'FROM', 'SET', 'VALUES', 'WHERE'].includes(match[1].toUpperCase())) {
        tables.push(match[1].toUpperCase());
      }
    }
  }
  
  return Array.from(new Set(tables));
}

function extractVsamDatasets(content: string): string[] {
  const datasets: string[] = [];
  const patterns = [
    /SELECT\s+(\w+)\s+ASSIGN\s+TO\s+['"]?(\w+)['"]?/gi,
    /ORGANIZATION\s+IS\s+(INDEXED|SEQUENTIAL|RELATIVE)/gi,
    /ACCESS\s+MODE\s+IS\s+(SEQUENTIAL|RANDOM|DYNAMIC)/gi
  ];
  
  const regex = /SELECT\s+(\w+)\s+ASSIGN/gi;
  let match;
  
  while ((match = regex.exec(content)) !== null) {
    datasets.push(match[1].toUpperCase());
  }
  
  return Array.from(new Set(datasets));
}

function getLibraryFromPath(filePath: string): string {
  const parts = filePath.split(path.sep);
  if (parts.length > 1) {
    const parentDir = parts[parts.length - 2].toUpperCase();
    if (['SOURCE', 'SRC', 'COBOL', 'CBL'].includes(parentDir)) return 'SOURCE';
    if (['COPYLIB', 'COPY', 'CPY'].includes(parentDir)) return 'COPYBOOK';
    if (['JCL', 'JOBS'].includes(parentDir)) return 'JCL';
    if (['PROC', 'PROCS', 'PROCLIB'].includes(parentDir)) return 'PROCLIB';
    if (['DATA', 'DATALIB'].includes(parentDir)) return 'DATALIB';
    return parentDir;
  }
  return 'SOURCE';
}

function detectCobolPatterns(classes: AnalysisData['classes'], relationships: AnalysisData['relationships']): AnalysisData['patterns'] {
  const patterns: AnalysisData['patterns'] = [];
  
  const programs = classes.filter(c => c.type === 'program');
  const copybooks = classes.filter(c => c.type === 'copybook');
  const jcls = classes.filter(c => c.type === 'jcl');
  
  if (programs.length > 0) {
    patterns.push({
      name: 'COBOL Batch Processing',
      type: 'Architectural Pattern',
      classes: programs.map(c => c.name),
      description: 'Traditional COBOL batch processing programs'
    });
  }
  
  if (copybooks.length > 0) {
    patterns.push({
      name: 'Copybook Data Structures',
      type: 'Data Pattern',
      classes: copybooks.map(c => c.name),
      description: 'Reusable data definitions shared across programs'
    });
  }
  
  if (jcls.length > 0) {
    patterns.push({
      name: 'JCL Job Scheduling',
      type: 'Infrastructure Pattern',
      classes: jcls.map(c => c.name),
      description: 'Job Control Language for batch job orchestration'
    });
  }
  
  const callRelationships = relationships.filter(r => r.type === 'CALL');
  if (callRelationships.length > 0) {
    patterns.push({
      name: 'Program Linkage',
      type: 'Integration Pattern',
      classes: Array.from(new Set(callRelationships.flatMap(r => [r.from, r.to]))),
      description: 'Inter-program communication via CALL statements'
    });
  }
  
  const copyRelationships = relationships.filter(r => r.type === 'COPY');
  if (copyRelationships.length > 0) {
    patterns.push({
      name: 'Copybook Inclusion',
      type: 'Code Reuse Pattern',
      classes: Array.from(new Set(copyRelationships.map(r => r.to))),
      description: 'Shared data definitions included via COPY statements'
    });
  }
  
  return patterns;
}

export function isCobolProject(zipBuffer: Buffer): Promise<boolean> {
  return new Promise(async (resolve) => {
    try {
      const zip = new JSZip();
      const zipContent = await zip.loadAsync(zipBuffer);
      
      for (const filename of Object.keys(zipContent.files)) {
        const lowerFilename = filename.toLowerCase();
        if (lowerFilename.endsWith('.cbl') || 
            lowerFilename.endsWith('.cob') || 
            lowerFilename.endsWith('.cobol') ||
            lowerFilename.endsWith('.jcl') ||
            lowerFilename.endsWith('.cpy') ||
            lowerFilename.endsWith('.copy') ||
            lowerFilename.endsWith('.proc')) {
          resolve(true);
          return;
        }
      }
      resolve(false);
    } catch {
      resolve(false);
    }
  });
}
