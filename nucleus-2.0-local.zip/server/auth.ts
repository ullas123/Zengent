/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import express from 'express';
import session from 'express-session';
import MemoryStore from 'memorystore';
import bcrypt from 'bcrypt';
import type { User } from '@shared/schema';

// Hardcoded credentials (encrypted with bcrypt)
// Username: nucleus, Password: nucleus
const HARDCODED_USER = {
  id: '1',
  username: 'nucleus',
  // This is the bcrypt hash of 'nucleus'
  passwordHash: '$2b$10$6Aqzz8tSUCJswtDyBAxope0St3BunvlFXGaobmws3br4kRHlTJJGC',
  email: 'nucleus@example.com',
  createdAt: new Date(),
  updatedAt: new Date()
};

// Validate user credentials
export async function validateHardcodedUser(username: string, password: string): Promise<User | undefined> {
  if (username.toLowerCase() !== HARDCODED_USER.username.toLowerCase()) {
    return undefined;
  }
  
  // Compare password with hash
  const isValid = await bcrypt.compare(password, HARDCODED_USER.passwordHash);
  if (!isValid) {
    return undefined;
  }
  
  return {
    id: HARDCODED_USER.id,
    username: HARDCODED_USER.username,
    password: HARDCODED_USER.passwordHash,
    email: HARDCODED_USER.email,
    firstName: null,
    lastName: null,
    position: null,
    profileImageUrl: null,
    isActive: true,
    createdAt: HARDCODED_USER.createdAt,
    updatedAt: HARDCODED_USER.updatedAt
  };
}

// Session configuration
export function setupSession(app: express.Application) {
  const MemStore = MemoryStore(session);
  
  app.use(session({
    store: new MemStore({
      checkPeriod: 86400000 // 24 hours cleanup
    }),
    // Hardcoded session secret (no external dependencies per user requirement)
    // Note: In production, this should be stored securely or loaded from environment
    secret: 'code-lens-session-secret-2024',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false,
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
      sameSite: 'lax',
    },
    name: 'connect.sid',
  }));
}

// Auth middleware
export function requireAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  if (!req.session?.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  next();
}

// Optional auth middleware (doesn't require auth but adds user if available)
export function optionalAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  // User info is available in req.session.user if logged in
  next();
}

// Extend session type
declare module 'express-session' {
  interface SessionData {
    user?: User;
  }
}