# Nucleus 2.0 — Local Installation Guide

**Developer**: Ullas Krishnan · Sr Solution Architect  
**Organisation**: Zensar Technologies · Diamond Team  
**Date**: 17 August 2026

---

## Prerequisites

| Requirement | Minimum version | Check |
|---|---|---|
| Node.js | 18.x or higher | `node --version` |
| npm | 9.x or higher | `npm --version` |
| PostgreSQL *(optional)* | 14+ | Only needed for persistent data |

> **No database? No problem.** The app runs fully on in-memory storage.  
> Login works, all scans work, AI features work — data just resets on restart.

---

## Quick Start (No Database)

```bash
# 1. Unzip the package
unzip nucleus-2.0-local.zip
cd nucleus-2.0-local

# 2. Install dependencies
npm install

# 3. Create environment file
cp .env.example .env
# Edit .env — set SESSION_SECRET to any long random string

# 4. Start the application
npm run dev

# 5. Open in browser
#    http://localhost:5000
#    Login: nucleus / nucleus
```

---

## With PostgreSQL Database

```bash
# 1. Create .env from example
cp .env.example .env

# 2. Edit .env — set both SESSION_SECRET and DATABASE_URL
#    Example (local Postgres):
#    DATABASE_URL=postgresql://postgres:password@localhost:5432/nucleus
#    Example (Neon cloud):
#    DATABASE_URL=postgresql://user:pass@ep-xxx.neon.tech/nucleus?sslmode=require

# 3. Install dependencies
npm install

# 4. Create database tables (run once)
npm run db:push

# 5. Start the application
npm run dev
```

---

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `SESSION_SECRET` | ✅ Yes | Any long random string for session signing |
| `DATABASE_URL` | ❌ Optional | PostgreSQL connection string. Omit for in-memory mode |
| `ANTHROPIC_API_KEY` | ❌ Optional | Enables Claude for S3 Direct / Compare / AI Insights |
| `OPENAI_API_KEY` | ❌ Optional | GPT-4o fallback when Anthropic key is not set |
| `PORT` | ❌ Optional | Server port (default: 5000) |

> **AI keys can also be configured inside the app** via the AI Settings page — no restart needed.

---

## Available Scripts

| Command | Purpose |
|---|---|
| `npm run dev` | Start in development mode with hot-reload |
| `npm run build` | Build for production (creates `dist/`) |
| `npm start` | Serve the production build |
| `npm run db:push` | Apply schema to database (run after DATABASE_URL is set) |
| `npm run check` | TypeScript type check |

---

## Login Credentials

| Field | Value |
|---|---|
| Username | `nucleus` |
| Password | `nucleus` |

*(Hardcoded — no database required for login)*

---

## API Scan — Pipeline Modes

After logging in, go to **API Scan** in the sidebar.

| Mode | AI Key needed? | What it does |
|---|---|---|
| ⚙️ S1+2 Standard | No | Deterministic multi-language parser only |
| ✨ S1+2+3 Enhanced | Optional | S1+2 + LLM appendix (default) |
| 🤖 S3 Direct LLM | Yes | Source code → AI → BRD report |
| 🔬 Compare S1 vs S3 | Yes | Parallel run → 3 reports + comparison |

---

## Project Structure

```
nucleus-2.0-local/
├── client/                 # React 18 + TypeScript frontend (Vite)
│   ├── index.html
│   └── src/
│       ├── App.tsx
│       ├── main.tsx
│       ├── pages/          # All page components
│       ├── components/     # Shared UI components
│       ├── hooks/          # Custom React hooks
│       ├── lib/            # Utilities & query client
│       └── services/       # Frontend API services
├── server/                 # Express + TypeScript backend
│   ├── index.ts            # Server entry point
│   ├── auth.ts             # Session & authentication
│   ├── db.ts               # PostgreSQL / Drizzle ORM
│   ├── storage.ts          # Data access layer
│   ├── routes.ts           # Route registration
│   ├── routes/             # Feature-specific routes
│   │   ├── apiScanRoutes.ts
│   │   ├── knowledgeAgentRoutes.ts
│   │   ├── zenseaiRoutes.ts
│   │   └── zenVectorRoutes.ts
│   ├── services/           # Business logic
│   │   ├── apiScanService.ts   ← API Scan core (Stage 1+2+3)
│   │   ├── aiKeyStore.ts       ← AI key management
│   │   └── ... (other services)
│   └── python/             # Python ML helpers
│       └── models/         # Pre-trained demographic model
├── shared/
│   └── schema.ts           # Drizzle ORM schema (shared between client & server)
├── attached_assets/        # UI images and assets
├── docs/                   # Documentation files
├── test_project/           # Sample Java project for testing scans
├── .env.example            # Environment variable template
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.ts
├── drizzle.config.ts
└── postcss.config.js
```

---

## Troubleshooting

**Port already in use:**
```bash
PORT=3000 npm run dev
```

**Database connection refused:**
- Check your `DATABASE_URL` is correct
- Ensure PostgreSQL is running: `pg_isready`
- Run `npm run db:push` to create tables

**`tsx` not found:**
```bash
npm install -g tsx
# or
npx tsx server/index.ts
```

**Python features not available:**
- Some AI features use Python scripts in `server/python/`
- Install Python 3.10+ and run: `pip install scikit-learn numpy pandas`
- Python features are optional — the app works without them

**Session not persisting:**
- Make sure `SESSION_SECRET` is set in your `.env` file

---

## Technology Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript, Vite, TailwindCSS, shadcn/ui |
| Backend | Node.js, Express, TypeScript, tsx |
| ORM | Drizzle ORM |
| Database | PostgreSQL (optional — Neon, local Postgres, or none) |
| AI (S3/Compare) | Anthropic claude-opus-4-5, OpenAI gpt-4o |
| Auth | express-session with MemoryStore |

---

*Nucleus 2.0 · Zensar Diamond Team · Innersource Agentic SDLC Platform*
