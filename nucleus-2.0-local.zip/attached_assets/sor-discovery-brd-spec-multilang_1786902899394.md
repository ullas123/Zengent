# SOR & Demographic Data Discovery Scanner — Build Spec (Multi-Language, Deterministic, BRD Output)

> This document specifies a scanning tool to be built and run against a source code repository. It is written to be handed to a coding agent as a build task. Fill in the Application Context block before running against a given repo.

---

## Objective

Build and run a repository discovery tool that produces a single, reproducible, non-hallucinated **Business Requirements Document (BRD)** in HTML, identifying:
1. How the application integrates with external Systems of Record (SOR) — API-based or Query-based
2. All demographic/PII fields, tables, and endpoints — both from an approved list and anything found beyond it
3. A clear API ↔ SOR ↔ demographic-field mapping

**Core design principle — read this before building anything:**
Do NOT ask an LLM to "scan the codebase and report findings" in one shot. That produces different results on every run (model drift) and invents details that aren't there (hallucination). Instead, build a **two-stage pipeline**:

- **Stage 1 (deterministic, no LLM):** Use real parsers/static-analysis libraries to extract exact facts — file paths, line numbers, class names, endpoint strings, SQL table names, HTTP methods — into a structured JSON file. This stage must be 100% reproducible: running it twice on the same code produces byte-identical JSON.
- **Stage 2 (LLM, constrained):** Feed *only* the Stage 1 JSON (never raw source) to the LLM, with instructions to classify, summarize, and write the BRD narrative — but never to add facts not present in the JSON. Run once, temperature 0.

This is what "no hallucination, no model drift, no need for multiple runs" actually requires architecturally — a prompt alone cannot guarantee it.

---

## Application Context (fill in before running against a repo)

```
Application Name: [ ]
Business Function / Purpose: [ ]
Domain (e.g., Card Servicing, KYC, Onboarding, Collections): [ ]
Primary Tech Stack for this repo (Java / C# / Python / React-JS / Mixed): [ ]
Repository Path: [ ]
Known Upstream/Downstream Systems (optional): [ ]
Compliance/Regulatory Scope (e.g., PCI, GDPR, KYC/AML): [ ]
```

This context is used only to frame the BRD narrative (executive summary, priority calls in Impacted Components) — it does not affect what Stage 1 extracts. Leaving it blank still produces a valid technical report, just without business framing.

---

## Stage 1 — Deterministic Extraction (build this first)

The tool must first detect which languages are present in the repo (by file extension / build files: `pom.xml`/`build.gradle` → Java, `.csproj`/`.sln` → C#, `requirements.txt`/`pyproject.toml` → Python, `package.json` → JS/TS/React), then run the matching parser(s) below. A single repo may contain more than one — run all that apply.

| Source Type | Recommended Library/Tool | What to extract |
|---|---|---|
| **Java** (services, DAOs, POJOs, DI config) | `javalang` (Python) or `JavaParser` (Java) | Class names, method signatures, annotations (`@RestTemplate`, `@FeignClient`, `@RequestMapping`, `@Value`), field names/types |
| **C#** (.NET services, repositories, HttpClient calls) | Roslyn (`Microsoft.CodeAnalysis.CSharp`) via a small analyzer, or `tree-sitter-c-sharp` as a lighter alternative | Class/method signatures, `HttpClient`/`RestSharp` calls, `[Route]`/`[HttpGet]` attributes, `appsettings.json` bindings, Entity Framework `DbContext`/`DbSet` table mappings |
| **Python** (services, ORM models, API clients) | Built-in `ast` module, or `libcst` for higher-fidelity extraction | `requests`/`httpx` calls, Flask/FastAPI/Django route decorators, SQLAlchemy/Django ORM model → table mappings |
| **React / JS / TS** (API clients, frontend bindings) | `tree-sitter` with `tree-sitter-javascript`/`tree-sitter-typescript` grammars, or `@babel/parser` for JSX-heavy code | `fetch`/`axios`/`react-query` calls, base URLs, request/response shapes, `.env` variable references used in API config |
| **SQL files, stored procedures** (any stack) | `sqlparse` (Python) or `JSQLParser` (Java) | Table names, query type (SELECT/INSERT/UPDATE/DELETE), joins, stored proc names |
| **Config files** — `.yml`, `.properties`, `.xml`, `.env`, `appsettings.json`, `application.properties` | `PyYAML`, `javaproperties`, `xml.etree.ElementTree`, `json` | Base URLs, connection strings, external host configs |
| **OpenAPI/Swagger specs**, if present (any stack) | `openapi-spec-validator` / `prance` | Declared endpoints, methods, payload schemas |
| **Generic text/pattern fallback**, all stacks | `ripgrep` (`rg`) invoked as a subprocess — faster and more reliable than manual grep for large repos | Any raw string matches for SOR names or table names not caught by the structured parsers above |

**Stage 1 output requirement:** a single `extraction.json` file with this shape (adapt fields as needed, but keep it structured, not prose):

```json
{
  "scan_metadata": {
    "repo_path": "",
    "languages_detected": ["Java", "C#", "Python", "React-JS"],
    "scan_timestamp": "",
    "libraries_used": [
      {"language": "Java", "artifact_type": "source", "library": "javalang", "version": ""},
      {"language": "C#", "artifact_type": "source", "library": "Roslyn", "version": ""},
      {"language": "Python", "artifact_type": "source", "library": "ast", "version": ""},
      {"language": "React-JS", "artifact_type": "source", "library": "tree-sitter-javascript", "version": ""},
      {"language": "all", "artifact_type": "SQL", "library": "sqlparse", "version": ""}
    ],
    "files_scanned_count": 0,
    "elapsed_seconds": 0
  },
  "api_integrations": [
    {
      "sor_name": "",
      "endpoint": "",
      "http_method": "",
      "language": "Java | C# | Python | React-JS",
      "source_file": "",
      "source_class_or_function": "",
      "config_location": "",
      "matched_by": "javalang | roslyn | ast | tree-sitter | ripgrep-fallback"
    }
  ],
  "table_usages": [
    {
      "table_name": "",
      "query_type": "",
      "language": "",
      "source_file": "",
      "source_class_or_proc": "",
      "raw_query": "",
      "matched_by": "sqlparse | JSQLParser | orm-model | ripgrep-fallback"
    }
  ],
  "demographic_fields_found": [
    {
      "field_name": "",
      "data_type": "",
      "language": "",
      "source_file": "",
      "line_number": 0,
      "matched_by": ""
    }
  ],
  "unlisted_sources_found": []
}
```

Run Stage 1 **once** per repo. Save `extraction.json` to disk. Do not regenerate it unless the source code changes — this is what guarantees identical results across multiple report generations.

---

## Stage 2 — LLM Classification & BRD Narrative (constrained)

Feed `extraction.json` (never the raw repo) to the LLM with the instructions below. Set **temperature to 0**, run **once**, and log the model name, prompt tokens, completion tokens, and total tokens used for this call in the report metadata.

### Stage 2 Instructions to the LLM

You are producing a Business Requirements Document from structured extraction data only. You must not invent, infer, or add any endpoint, table, class name, or field that is not present in the provided JSON. If a section of the JSON is empty, state that explicitly rather than filling it with a plausible-sounding guess.

1. **Integration Type Determination** — based on whether `api_integrations` or `table_usages` (or both) is non-empty, state: `Integration Type: API-Based`, `Integration Type: Query-Based`, or `Integration Type: Mixed`.

2. **API-Based SOR Findings** — cross-reference `api_integrations` against this approved list: `CRPS, Anagrafe, Income SOR, Triumph, MNS, GSTAR, CM-CARS, APA AR, CARE, DIG, GAR`. For each approved SOR found, list its extracted details verbatim from the JSON, including which language/component it was found in. For each not found, state: `No outbound API integration with <SOR_NAME> found.`

3. **Query-Based SOR Table Findings** — cross-reference `table_usages` against this approved list: `triumph_demographics, triumph_card_account, triumph_plastic_card, gstar_card_details, gstar_account_details, gstar_customer_demographics, gstar_corp_customer_demographics, cars_cm_demographics, mns_demographics_ar, care_demographic, apa_ar_demographic, dcp_cm_mobile_dtl, dcp_cm_email_dtl, anagrafe_customer, crps_customer_linkage, gstar_corp_card_details, gstar_corp_account_details`. For each found, list verbatim from the JSON. For none found: `No approved SOR tables found in the workspace.`

4. **Holistic Demographic Discovery** — present `demographic_fields_found` and `unlisted_sources_found` verbatim as tables. If empty: `No additional demographic fields or unlisted SOR/table sources found.`

5. **Demographic Data Origin Summary** — cross-reference entries in `api_integrations` and `table_usages` against `demographic_fields_found` (matched by source file) to build: `API Endpoint | HTTP Method | SOR Name | Demographic Field(s) | Source Location | Language`. If no cross-reference match exists, state: `No API found returning demographic data.`

6. **Impacted Components (Full Stack Engineer View)** — for each SOR/table block, based only on the `source_class_or_function`/`source_file` values present, describe: backend components affected (by language — e.g., POJOs/DTOs and DAOs for Java, EF models and repositories for C#, SQLAlchemy models and services for Python), frontend/API-consumer implications for React/JS clients if applicable, required code changes, recommended tests, priority (High/Medium/Low).

7. **WHY + Elapsed Time** — for every block, include exactly two sentences of technical justification (`WHY`) and reuse the `elapsed_seconds` value from `scan_metadata` for that block's `Elapsed Time` field — do not fabricate a new time.

8. **Scan Provenance footer** (mandatory, once per report) — state explicitly: languages detected, libraries used per language/artifact type (from `scan_metadata.libraries_used`), LLM model name used for Stage 2, and token usage (prompt/completion/total) for the Stage 2 call.

---

## Output Requirements

- Export as a single downloadable **`.html`** file — structured as a formal BRD: Executive Summary, Application Context, Integration Type, API Findings, Query Findings, Holistic Demographic Discovery, Origin Summary, Impacted Components, Final Summary, Scan Provenance footer.
- Do not regenerate Stage 1 extraction on repeated report runs — regenerating only Stage 2 from the same `extraction.json` is what guarantees you don't get different findings each time.
- Provide the local file path (or download link) to the generated HTML at the end.
- For multi-repo workspaces, run Stage 1 separately per repo (each producing its own `extraction.json`). A Stage 3 merge step (combining multiple `extraction.json` files into one consolidated BRD) can be added if a cross-repo view is needed — flag this as a future enhancement rather than building it into the first version, to keep per-repo attribution clean.

---

## Why this two-stage approach is the right method

Pattern-matching or LLM-only scans over large codebases produce two failure modes: **hallucination** (the model fills gaps with plausible-looking but fabricated endpoints/tables) and **drift** (re-running the same prompt gives different results because LLM output isn't deterministic). Separating extraction (language-specific deterministic parsers, git-diffable JSON) from narrative generation (LLM, temperature 0, JSON-only input) removes both failure modes structurally rather than trying to prompt around them — the LLM literally cannot invent a table name it was never shown.
