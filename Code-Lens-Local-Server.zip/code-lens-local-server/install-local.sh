#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

node -e 'const major = Number(process.versions.node.split(".")[0]); if (major < 24) { console.error("Node.js 24 or later is required."); process.exit(1); }'
[[ -f .env ]] || cp .env.example .env
npm ci
npm run build
printf '\nInstallation complete. Configure DATABASE_URL and SESSION_SECRET in .env.\n'
printf 'Then run npm run db:push once for a new dedicated database, and npm start.\n'
