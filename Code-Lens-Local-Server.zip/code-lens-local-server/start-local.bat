@echo off
setlocal
cd /d "%~dp0"
if not exist .env (
  echo Configure .env first. Run install-local.bat to create it.
  pause
  exit /b 1
)
call npm start
