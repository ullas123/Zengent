/**
 * Developer      : Ullas Krishnan
 * Designation    : Sr Solution Architect
 * Organisation   : Zensar Technologies
 * Developed by   : Zensar Diamond Team
 * Date           : 29 July 2026
 */

import { Router } from "express";
import multer from "multer";
import { requireAuth } from "../auth";
import { scanZipFiles } from "../services/apiScanService";

const router = Router();

const uploadMultiZip = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 }, // 100 MB per file
  fileFilter: (_req, file, cb) => {
    const isZip =
      file.mimetype === "application/zip" ||
      file.mimetype === "application/x-zip-compressed" ||
      file.originalname.endsWith(".zip");
    isZip ? cb(null, true) : cb(new Error("Only ZIP files are allowed"));
  },
});

/**
 * POST /api/api-scan/scan
 * Body: multipart/form-data  field: "files" (one or more .zip)
 */
router.post(
  "/scan",
  requireAuth,
  uploadMultiZip.array("files", 10),
  async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[] | undefined;
      if (!files || files.length === 0) {
        return res.status(400).json({ error: "At least one ZIP file is required" });
      }

      const zipBuffers = files.map((f) => ({ name: f.originalname, buffer: f.buffer }));
      const result = await scanZipFiles(zipBuffers);

      // Return JSON summary + HTML report as base64
      return res.json({
        success: true,
        integrationType: result.integrationType,
        zipFiles: result.zipFiles,
        totalFilesScanned: result.totalFilesScanned,
        scanDuration: result.scanDuration,
        elapsedTime: result.elapsedTime,
        sorFindings: result.sorFindings,
        tableFindings: result.tableFindings,
        notFoundSors: result.notFoundSors,
        notFoundTables: result.notFoundTables,
        htmlReport: Buffer.from(result.htmlReport).toString("base64"),
      });
    } catch (err: any) {
      console.error("[API Scan] Error:", err);
      return res.status(500).json({ error: err.message || "Scan failed" });
    }
  }
);

/**
 * POST /api/api-scan/scan-github
 * Body: { githubUrl: string, branch?: string, token?: string }
 * Downloads the repository archive from GitHub (or enterprise GHE) and scans it.
 */
function parseGithubUrl(url: string): { host: string; owner: string; repo: string } | null {
  try {
    const u = new URL(url.trim());
    if (!u.hostname.toLowerCase().startsWith("github")) return null;
    const parts = u.pathname.replace(/^\//, "").replace(/\.git$/, "").split("/").filter(Boolean);
    if (parts.length < 2) return null;
    return { host: u.hostname, owner: parts[0], repo: parts[1] };
  } catch {
    return null;
  }
}

router.post("/scan-github", requireAuth, async (req, res) => {
  try {
    const { githubUrl, branch, token } = req.body as {
      githubUrl?: string;
      branch?: string;
      token?: string;
    };

    if (!githubUrl) {
      return res.status(400).json({ error: "githubUrl is required" });
    }

    const parsed = parseGithubUrl(githubUrl);
    if (!parsed) {
      return res.status(400).json({
        error: "Invalid GitHub URL. Expected format: https://github[.domain.com]/owner/repo",
      });
    }

    const { host, owner, repo } = parsed;
    const headers: Record<string, string> = {
      "User-Agent": "Nucleus-2.0-API-Scanner",
      Accept: "application/octet-stream",
    };
    if (token) headers["Authorization"] = `token ${token}`;

    // Try specified branch first, then fall back to main → master → HEAD
    const candidates = branch
      ? [branch, "main", "master"]
      : ["main", "master", "HEAD"];

    let zipBuffer: Buffer | null = null;
    let usedBranch = "";
    let lastError = "";

    for (const b of candidates) {
      const archiveUrl =
        b === "HEAD"
          ? `https://${host}/${owner}/${repo}/archive/HEAD.zip`
          : `https://${host}/${owner}/${repo}/archive/refs/heads/${b}.zip`;

      try {
        const response = await fetch(archiveUrl, { headers, redirect: "follow" });
        if (response.ok) {
          const ab = await response.arrayBuffer();
          zipBuffer = Buffer.from(ab);
          usedBranch = b;
          break;
        }
        lastError = `HTTP ${response.status} for branch "${b}"`;
      } catch (fetchErr: any) {
        lastError = fetchErr.message;
      }
    }

    if (!zipBuffer) {
      return res.status(404).json({
        error: `Could not download repository archive. ${lastError}. Check the URL, branch name, and access token (for private/enterprise repos).`,
      });
    }

    const repoLabel = `${owner}/${repo}@${usedBranch}`;
    const result = await scanZipFiles([{ name: repoLabel, buffer: zipBuffer }]);

    return res.json({
      success: true,
      source: "github",
      githubUrl,
      repoLabel,
      branch: usedBranch,
      integrationType: result.integrationType,
      zipFiles: [repoLabel],
      totalFilesScanned: result.totalFilesScanned,
      scanDuration: result.scanDuration,
      elapsedTime: result.elapsedTime,
      sorFindings: result.sorFindings,
      tableFindings: result.tableFindings,
      notFoundSors: result.notFoundSors,
      notFoundTables: result.notFoundTables,
      htmlReport: Buffer.from(result.htmlReport).toString("base64"),
    });
  } catch (err: any) {
    console.error("[API Scan GitHub] Error:", err);
    return res.status(500).json({ error: err.message || "GitHub scan failed" });
  }
});

/**
 * GET /api/api-scan/sor-list
 * Returns the list of known SOR systems and approved tables
 */
router.get("/sor-list", requireAuth, (_req, res) => {
  const { SOR_SYSTEMS, APPROVED_TABLES } = require("../services/apiScanService");
  return res.json({ sorSystems: SOR_SYSTEMS, approvedTables: APPROVED_TABLES });
});

export default router;
