@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 24 or later is required. Install it, then run this file again.
  pause
  exit /b 1
)

node -e "const v=Number(process.versions.node.split('.')[0]); if(v<24) process.exit(1)"
if errorlevel 1 (
  echo Node.js 24 or later is required. Install it, then run this file again.
  pause
  exit /b 1
)

if not exist .env copy .env.example .env >nul
call npm ci
if errorlevel 1 exit /b 1
call npm run build
if errorlevel 1 exit /b 1

echo.
echo Installation complete. Configure DATABASE_URL and SESSION_SECRET in .env.
echo Then run npm run db:push once for a new dedicated database, and npm start.
pause
