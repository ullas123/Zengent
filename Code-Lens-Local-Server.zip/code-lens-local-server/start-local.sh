#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -f .env ]]; then
  echo "Configure .env first. Run bash install-local.sh to create it." >&2
  exit 1
fi
npm start
