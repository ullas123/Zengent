# Code Lens Local Server

This package runs Code Lens as a local web application on your computer.

## Requirements

- Windows, macOS, or Linux
- Node.js 24 or later
- Internet access during installation to download Node packages
- A PostgreSQL database connection for data that persists between restarts. A Neon PostgreSQL connection is recommended for this build.

Without `DATABASE_URL`, the app uses temporary in-memory storage. Saved data is lost when the server stops, and database-backed features are unavailable.

## Install

1. Extract the ZIP to a folder you can write to.
2. Install Node.js 24 or later if it is not already installed.
3. Run `install-local.bat` on Windows, or run `bash install-local.sh` on macOS/Linux. This installs dependencies and builds the app.
4. Open the generated `.env` file. Set `DATABASE_URL` to your PostgreSQL connection string, keep `HOST=127.0.0.1` for local-only access, and replace `SESSION_SECRET` with a unique random value.
5. For a new, dedicated Code Lens database, open a terminal in the extracted folder and run `npm run db:push` once to create the tables. Do not point this schema setup at a database containing unrelated application data.
6. Start the app with `npm start`, or use `start-local.bat` / `bash start-local.sh`.
7. Open <http://localhost:5000>.

The installer creates `.env` from `.env.example` if it does not exist. It does not include or generate database credentials.

## Sign in

The current default account is:

- Username: `nucleus`
- Password: `nucleus`

Keep the server bound to `127.0.0.1` unless you have changed the account credentials and configured your network security.

## Optional AI features

Add your own `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` to `.env` to enable the corresponding AI features. These keys are not included in this download.

## Troubleshooting

- If the app says the database is unavailable, check `DATABASE_URL` in `.env`, then restart it.
- If port 5000 is already in use, change `PORT` in `.env` and open the matching `localhost` port.
- If dependency installation fails, confirm Node.js 24 or later is installed and try `npm ci` again.
