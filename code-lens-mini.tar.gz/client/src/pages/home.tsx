import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type Project } from "@shared/schema";
import UploadSection from "@/components/upload-section";
import ProcessingSection from "@/components/processing-section";
import AnalysisResults from "@/components/analysis-results";
import Dashboard from "@/components/dashboard";
import AIModelSelector, { type AIModelConfig } from "@/components/ai-model-selector";
import { Button } from "@/components/ui/button";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { AIAnalysisResult } from "@shared/schema";
import { Settings } from "lucide-react";
import Layout from "@/components/layout";
import {
  TooltipProvider,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";
import codeLensIcon from "@assets/image_1760903680870.png";

type AppState = 'upload' | 'processing' | 'results';

export default function Home() {
  const [appState, setAppState] = useState<AppState>('upload');
  const [currentProjectId, setCurrentProjectId] = useState<string | null>(null);
  const [showAIConfig, setShowAIConfig] = useState(false);
  const [aiConfig, setAiConfig] = useState<AIModelConfig>({ type: 'openai' });
  const { toast } = useToast();

  const { data: currentProject, refetch: refetchProject } = useQuery<Project>({
    queryKey: ['/api/projects', currentProjectId],
    enabled: !!currentProjectId,
  });

  const handleFileUploaded = (project: Project) => {
    setCurrentProjectId(project.id);
    setAppState('processing');
    
    const pollInterval = setInterval(async () => {
      const { data: updatedProject } = await refetchProject();
      if (updatedProject && updatedProject.status !== 'processing') {
        clearInterval(pollInterval);
        if (updatedProject.status === 'completed') {
          setAppState('results');
        } else {
          setAppState('upload');
          setCurrentProjectId(null);
        }
      }
    }, 2000);
  };

  const handleGitHubAnalyzed = (project: Project) => {
    setCurrentProjectId(project.id);
    setAppState('processing');
    
    const pollInterval = setInterval(async () => {
      const { data: updatedProject } = await refetchProject();
      if (updatedProject && updatedProject.status !== 'processing') {
        clearInterval(pollInterval);
        if (updatedProject.status === 'completed') {
          setAppState('results');
        } else if (updatedProject.status === 'failed') {
          toast({
            title: "Analysis Failed",
            description: "GitHub repository analysis failed. Please try again.",
            variant: "destructive",
          });
          setAppState('upload');
          setCurrentProjectId(null);
        }
      }
    }, 3000);
  };

  const handleNewAnalysis = () => {
    setAppState('upload');
    setCurrentProjectId(null);
  };

  const handleAIModelConfig = async (config: AIModelConfig) => {
    try {
      await apiRequest('/api/ai-config', 'POST', config);
      setAiConfig(config);
      setShowAIConfig(false);
    } catch (error) {
      console.error('Failed to configure AI model:', error);
    }
  };

  const handleAIAnalysisComplete = (analysis: AIAnalysisResult) => {
    if (currentProject && currentProject.analysisData) {
      const updatedAnalysisData = {
        ...currentProject.analysisData,
        aiAnalysis: analysis
      };
      
      queryClient.setQueryData(
        ['/api/projects', currentProjectId],
        {
          ...currentProject,
          analysisData: updatedAnalysisData
        }
      );
    }
  };

  const aiConfigButton = (
    <Button
      variant="outline"
      size="sm"
      onClick={() => setShowAIConfig(true)}
      className="text-primary bg-white border-primary hover:bg-primary hover:text-white font-medium transition-colors"
    >
      <Settings className="w-4 h-4 mr-2" />
      AI Settings
    </Button>
  );

  return (
    <TooltipProvider>
      <Layout aiConfigButton={aiConfigButton}>
        <div className="bg-white font-sans text-foreground min-h-screen">
          <div className="container mx-auto px-6 py-8">
            {appState === 'upload' && (
              <div className="max-w-4xl mx-auto">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center p-2">
                    <img src={codeLensIcon} alt="Code Lens" className="w-full h-full object-contain" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">Code Lens Mini - AI Code Scan</h1>
                    <p className="text-sm text-gray-600">Upload source code or connect GitHub to scan for demographic/PII fields</p>
                  </div>
                </div>
                
                <UploadSection onFileUploaded={handleFileUploaded} onGitHubAnalyzed={handleGitHubAnalyzed} />
              </div>
            )}
            
            {appState === 'processing' && currentProject && (
              <ProcessingSection project={currentProject} />
            )}
            
            {appState === 'results' && currentProject && currentProject.analysisData && (
              <div className="space-y-8">
                {currentProject.analysisData && typeof currentProject.analysisData === 'object' && (
                  <>
                    <Dashboard 
                      analysisData={currentProject.analysisData as any} 
                      onAIAnalysisComplete={handleAIAnalysisComplete}
                    />
                    <AnalysisResults 
                      project={currentProject} 
                      onNewAnalysis={handleNewAnalysis}
                    />
                  </>
                )}
              </div>
            )}
          </div>

          {appState === 'results' && (
            <button
              onClick={handleNewAnalysis}
              className="fixed bottom-6 right-6 bg-primary text-primary-foreground p-4 rounded-full shadow-lg hover:bg-primary/90 transition-all hover:scale-105"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
            </button>
          )}

          {showAIConfig && (
            <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                <div className="p-4 border-b">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">AI Model Configuration</h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowAIConfig(false)}
                    >
                      ✕
                    </Button>
                  </div>
                </div>
                <div className="p-4">
                  <AIModelSelector
                    onModelSelect={handleAIModelConfig}
                    currentConfig={aiConfig}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </Layout>
      <Toaster />
    </TooltipProvider>
  );
}
