import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const pythonBackendPath = path.join(__dirname, '..', 'python_backend');

const pythonProcess = spawn('python', ['app.py'], {
  cwd: pythonBackendPath,
  stdio: 'inherit',
  shell: true
});

pythonProcess.on('error', (err) => {
  console.error('Failed to start Python backend:', err);
});

pythonProcess.on('close', (code) => {
  console.log(`Python backend exited with code ${code}`);
});
