# VerifAI Installation Guide

## AI-Powered KYC Document Verification Platform

This guide will help you install and run VerifAI on your local machine (Windows, macOS, or Linux).

---

## Prerequisites

Before installing VerifAI, ensure you have the following installed:

### Required Software

1. **Node.js** (v18 or higher)
   - Download: https://nodejs.org/
   - Verify: `node --version`

2. **Python** (v3.10 or higher)
   - Download: https://www.python.org/downloads/
   - Verify: `python --version` or `python3 --version`

3. **PostgreSQL Database**
   - Option A: Local PostgreSQL installation
   - Option B: Cloud database (e.g., Neon, Supabase, AWS RDS)

4. **OpenAI API Key**
   - Get your API key from: https://platform.openai.com/api-keys

---

## Installation Steps

### Step 1: Extract the Package

Extract the `verifai.zip` file to your desired location.

```bash
unzip verifai.zip
cd verifai
```

### Step 2: Install Node.js Dependencies

```bash
npm install
```

### Step 3: Install Python Dependencies

```bash
cd python_backend
pip install -r requirements.txt
cd ..
```

**Windows Users:** If you encounter issues, try:
```bash
python -m pip install -r requirements.txt
```

### Step 4: Configure Environment Variables

1. Copy the example environment file:
   ```bash
   cp .env.example python_backend/.env
   ```

2. Edit `python_backend/.env` with your configuration:
   ```
   DATABASE_URL=postgresql://username:password@host:5432/database_name
   OPENAI_API_KEY=sk-your-openai-api-key-here
   SESSION_SECRET=generate-a-random-string-here
   ```

3. Also create a root `.env` file for the Node.js server:
   ```bash
   cp .env.example .env
   ```

### Step 5: Initialize the Database

Push the database schema:

```bash
npm run db:push
```

If you encounter warnings about data loss, use:
```bash
npm run db:push:force
```

---

## Running the Application

### Development Mode

Start both the Python backend and Node.js frontend:

**Option 1: Using npm (recommended)**
```bash
npm run dev
```

**Option 2: Manual startup (if Option 1 fails)**

Terminal 1 - Python Backend:
```bash
cd python_backend
python app.py
```

Terminal 2 - Node.js Frontend:
```bash
npx tsx server/index.ts
```

### Accessing the Application

Once running, open your browser and navigate to:

- **Application:** http://localhost:5000
- **Setup Page:** http://localhost:5000/setup

### Default Login Credentials

- **Username:** analyst
- **Password:** analyst

---

## Configuration (Post-Installation)

After starting the application, visit the Setup page (`/setup`) to:

1. **Verify Database Connection** - Confirm your PostgreSQL database is connected
2. **Configure OpenAI API Key** - Enter or update your API key
3. **View System Status** - Check connection status for all services

---

## Folder Structure

```
verifai/
├── client/              # React frontend
│   ├── src/
│   │   ├── components/  # UI components
│   │   ├── pages/       # Application pages
│   │   ├── hooks/       # Custom React hooks
│   │   └── lib/         # Utility functions
│   └── public/          # Static assets
├── server/              # Node.js Express server
├── shared/              # Shared TypeScript schemas
├── python_backend/      # Flask API server
│   ├── app.py           # Main Flask application
│   ├── rag_service.py   # RAG/LangChain service
│   └── .env             # Environment configuration
├── chroma_db/           # ChromaDB vector store (auto-created)
├── attached_assets/     # Static images
├── scripts/             # Helper scripts
├── package.json         # Node.js dependencies
└── INSTALL.md           # This file
```

---

## Troubleshooting

### Common Issues

**1. "Module not found" errors in Python**
```bash
pip install --upgrade pip
pip install -r python_backend/requirements.txt
```

**2. Database connection failed**
- Verify your DATABASE_URL is correct
- Ensure PostgreSQL is running
- Check firewall/network settings

**3. OpenAI API errors**
- Verify your API key is valid
- Check your OpenAI account has available credits
- Ensure the key has the correct permissions

**4. Port already in use**
- Kill existing processes on ports 5000 and 5001
- Windows: `netstat -ano | findstr :5000`
- Linux/Mac: `lsof -i :5000`

**5. ChromaDB errors**
- The `chroma_db` folder is created automatically
- If issues persist, delete the folder and restart

### Windows-Specific Issues

**Python not found:**
- Add Python to your PATH environment variable
- Use `py` instead of `python`

**Permission errors:**
- Run terminal as Administrator
- Check folder permissions

---

## Technology Stack

- **Frontend:** React 18, TypeScript, Tailwind CSS, Shadcn UI
- **Backend:** Node.js Express, Python Flask
- **Database:** PostgreSQL with Drizzle ORM
- **AI/ML:** OpenAI GPT-4o, LangChain, LangGraph, ChromaDB
- **Authentication:** Session-based (express-session)

---

## Support

For issues or questions, please contact your system administrator or refer to the technical documentation.

---

**Version:** 1.0.0  
**Last Updated:** January 2026
