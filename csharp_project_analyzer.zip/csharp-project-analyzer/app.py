import streamlit as st
import os
import pandas as pd
from csharp_parser import extract_zip, analyze_project, search_table_name
from diagram_generator import (
    generate_class_diagram,
    generate_architecture_diagram,
    generate_data_flow_diagram,
    generate_class_relationship_diagram,
    generate_etl_diagram,
    generate_namespace_diagram,
    generate_flow_diagram,
    get_dot_source,
)

st.set_page_config(page_title="C# Project Analyzer", layout="wide", page_icon="🔍")

st.title("C# Project Analyzer")
st.markdown("Upload a `.zip` file containing your C# project to analyze its architecture, modules, classes, data flow, and more.")

if "analysis" not in st.session_state:
    st.session_state.analysis = None
if "root_dir" not in st.session_state:
    st.session_state.root_dir = None


def render_diagram(dot_graph, key_prefix):
    col1, col2 = st.columns([1, 1])
    with col1:
        st.download_button(
            label="Download as PNG",
            data=dot_graph.pipe(format="png"),
            file_name=f"{key_prefix}.png",
            mime="image/png",
            key=f"dl_png_{key_prefix}",
        )
    with col2:
        dot_src = get_dot_source(dot_graph)
        st.download_button(
            label="Download as DOT",
            data=dot_src,
            file_name=f"{key_prefix}.dot",
            mime="text/plain",
            key=f"dl_dot_{key_prefix}",
        )
    st.image(dot_graph.pipe(format="png"))


def render_class_detail(cls, root_dir, key_suffix=""):
    st.markdown(f"**{cls.class_type.upper()}: {cls.name}**")

    info_data = {
        "Property": ["Full Name", "Type", "Access", "Abstract", "Static", "File"],
        "Value": [
            f"{cls.namespace}.{cls.name}",
            cls.class_type,
            cls.access_modifier,
            "Yes" if cls.is_abstract else "No",
            "Yes" if cls.is_static else "No",
            os.path.relpath(cls.file_path, root_dir),
        ],
    }
    st.dataframe(pd.DataFrame(info_data), use_container_width=True, hide_index=True)

    if cls.base_classes or cls.interfaces:
        inh_data = []
        for b in cls.base_classes:
            inh_data.append({"Name": b, "Relationship": "Inherits"})
        for iface in cls.interfaces:
            inh_data.append({"Name": iface, "Relationship": "Implements"})
        st.markdown("**Inheritance & Interfaces**")
        st.dataframe(pd.DataFrame(inh_data), use_container_width=True, hide_index=True)

    if cls.properties:
        st.markdown("**Properties**")
        prop_data = [{"Name": p.name, "Type": p.type, "Access": p.access_modifier} for p in cls.properties]
        st.dataframe(pd.DataFrame(prop_data), use_container_width=True, hide_index=True)

    if cls.methods:
        st.markdown("**Methods**")
        meth_data = []
        for m in cls.methods:
            params = ", ".join(f"{p['type']} {p['name']}" for p in m.parameters)
            meth_data.append({
                "Name": m.name,
                "Return Type": m.return_type,
                "Parameters": params or "-",
                "Access": m.access_modifier,
                "Static": "Yes" if m.is_static else "",
                "Async": "Yes" if m.is_async else "",
            })
        st.dataframe(pd.DataFrame(meth_data), use_container_width=True, hide_index=True)

    if cls.fields:
        st.markdown("**Fields**")
        fld_data = [{"Name": f["name"], "Type": f["type"], "Access": f["access"]} for f in cls.fields]
        st.dataframe(pd.DataFrame(fld_data), use_container_width=True, hide_index=True)

    if cls.is_enum and cls.enum_values:
        st.markdown("**Enum Values**")
        enum_data = [{"Value": v} for v in cls.enum_values]
        st.dataframe(pd.DataFrame(enum_data), use_container_width=True, hide_index=True)


def render_diagrams_for_classes(classes, label, key_prefix):
    diagram_type = st.selectbox("Select Diagram", [
        "Class Diagram",
        "Class Relationships",
        "Data Flow Diagram (DFD)",
        "ETL / Data Pipeline",
        "Namespace Overview",
        "Program Flow",
    ], key=f"diag_select_{key_prefix}")

    if not classes:
        st.info("No classes found to generate diagrams.")
        return

    if diagram_type == "Class Diagram":
        dot = generate_class_diagram(classes, f"Class Diagram: {label}")
        render_diagram(dot, f"class_{key_prefix}")
    elif diagram_type == "Class Relationships":
        dot = generate_class_relationship_diagram(classes, f"Relationships: {label}")
        render_diagram(dot, f"rel_{key_prefix}")
    elif diagram_type == "Data Flow Diagram (DFD)":
        dot = generate_data_flow_diagram(classes, label)
        render_diagram(dot, f"dfd_{key_prefix}")
    elif diagram_type == "ETL / Data Pipeline":
        dot = generate_etl_diagram(classes, label)
        render_diagram(dot, f"etl_{key_prefix}")
    elif diagram_type == "Namespace Overview":
        dot = generate_namespace_diagram(classes, label)
        render_diagram(dot, f"ns_{key_prefix}")
    elif diagram_type == "Program Flow":
        dot = generate_flow_diagram(classes, label)
        render_diagram(dot, f"flow_{key_prefix}")


uploaded = st.sidebar.file_uploader("Upload C# Project (.zip)", type=["zip"])

if uploaded:
    if st.session_state.analysis is None or st.sidebar.button("Re-analyze"):
        with st.spinner("Extracting and analyzing project..."):
            root_dir = extract_zip(uploaded)
            analysis = analyze_project(root_dir)
            st.session_state.analysis = analysis
            st.session_state.root_dir = root_dir

if st.session_state.analysis:
    analysis = st.session_state.analysis
    modules = analysis["modules"]
    solutions = analysis["solutions"]
    projects = analysis["projects"]
    all_classes = analysis["classes"]
    root_dir = st.session_state.root_dir

    st.sidebar.markdown("---")
    st.sidebar.subheader("Project Summary")
    st.sidebar.metric("Solutions", len(solutions))
    st.sidebar.metric("Projects / Modules", len(modules))
    st.sidebar.metric("Total Classes", len(all_classes))
    st.sidebar.metric("Total Files", len(analysis.get("all_files", [])))

    tab_overview, tab_project, tab_module, tab_diagrams, tab_search = st.tabs([
        "Solution Overview",
        "Project Explorer",
        "Module Explorer",
        "All Diagrams",
        "Table Name Search",
    ])

    with tab_overview:
        st.header("Solution Overview")

        if solutions:
            st.subheader("Solutions")
            for sol in solutions:
                sol_data = []
                for p in sol.projects:
                    sol_data.append({"Project Name": p["name"], "Path": p["path"]})
                if sol_data:
                    st.markdown(f"**{sol.name}.sln**")
                    st.dataframe(pd.DataFrame(sol_data), use_container_width=True, hide_index=True)

        if projects:
            st.subheader("Projects")
            proj_data = []
            for p in projects:
                proj_data.append({
                    "Project": p.name,
                    "Framework": p.target_framework,
                    "NuGet Packages": len(p.package_references),
                    "Project References": len(p.project_references),
                    "C# Files": len(p.cs_files),
                })
            st.dataframe(pd.DataFrame(proj_data), use_container_width=True, hide_index=True)

            st.subheader("NuGet Package References")
            pkg_data = []
            for p in projects:
                for pkg in p.package_references:
                    pkg_data.append({
                        "Project": p.name,
                        "Package": pkg["name"],
                        "Version": pkg["version"],
                    })
            if pkg_data:
                st.dataframe(pd.DataFrame(pkg_data), use_container_width=True, hide_index=True)

        st.subheader("Modules Identified")
        mod_data = []
        for name, mod in modules.items():
            interfaces = sum(1 for c in mod.classes if c.is_interface)
            enums = sum(1 for c in mod.classes if c.is_enum)
            plain = len(mod.classes) - interfaces - enums
            mod_data.append({
                "Module": name,
                "Namespaces": len(mod.namespaces),
                "Classes": plain,
                "Interfaces": interfaces,
                "Enums": enums,
                "Total Types": len(mod.classes),
            })
        st.dataframe(pd.DataFrame(mod_data), use_container_width=True, hide_index=True)

        st.subheader("All Classes Summary")
        cls_data = []
        for c in all_classes:
            cls_data.append({
                "Namespace": c.namespace,
                "Name": c.name,
                "Type": c.class_type,
                "Access": c.access_modifier,
                "Properties": len(c.properties),
                "Methods": len(c.methods),
                "Fields": len(c.fields),
                "Inherits": ", ".join(c.base_classes) or "-",
                "Implements": ", ".join(c.interfaces) or "-",
            })
        if cls_data:
            st.dataframe(pd.DataFrame(cls_data), use_container_width=True, hide_index=True)

        if len(modules) > 0:
            st.subheader("Solution Architecture Diagram")
            sol_name = solutions[0].name if solutions else "Project"
            arch_dot = generate_architecture_diagram(modules, sol_name)
            render_diagram(arch_dot, "architecture_overview")

    with tab_project:
        st.header("Project Explorer")

        if not projects:
            st.info("No .csproj projects found. Use the Module Explorer tab instead.")
        else:
            if solutions:
                sol_names = [s.name for s in solutions]
                selected_sol = st.selectbox("Select Solution", sol_names, key="sol_select")
                sol = next(s for s in solutions if s.name == selected_sol)

                sol_proj_names = [p["name"] for p in sol.projects]
                matched_projects = [p for p in projects if p.name in sol_proj_names]
                if not matched_projects:
                    matched_projects = projects

                st.markdown(f"**Solution: {selected_sol}.sln** — {len(sol.projects)} project(s)")
                sol_proj_data = []
                for p in sol.projects:
                    sol_proj_data.append({"Project Name": p["name"], "Path": p["path"]})
                st.dataframe(pd.DataFrame(sol_proj_data), use_container_width=True, hide_index=True)
            else:
                matched_projects = projects

            proj_names = [p.name for p in matched_projects]
            selected_proj_name = st.selectbox("Select Project", proj_names, key="proj_select")
            proj = next(p for p in matched_projects if p.name == selected_proj_name)

            proj_dir = os.path.abspath(os.path.dirname(proj.path))
            proj_classes = []
            for c in all_classes:
                try:
                    abs_file = os.path.abspath(c.file_path)
                    if abs_file.startswith(proj_dir + os.sep) or abs_file.startswith(proj_dir + "/"):
                        proj_classes.append(c)
                except (ValueError, OSError):
                    pass

            st.markdown("---")
            st.subheader(f"Project: {selected_proj_name}")

            m1, m2, m3, m4 = st.columns(4)
            with m1:
                st.metric("Framework", proj.target_framework or "N/A")
            with m2:
                st.metric("C# Files", len(proj.cs_files))
            with m3:
                st.metric("Types Found", len(proj_classes))
            with m4:
                st.metric("Total Methods", sum(len(c.methods) for c in proj_classes))

            proj_tabs = st.tabs([
                "Project Config",
                "Files & Namespaces",
                "Classes & Types",
                "Class Detail",
                "Diagrams",
            ])

            with proj_tabs[0]:
                st.subheader("Project Configuration")
                config_data = {
                    "Property": [
                        "Project Name",
                        "Project File",
                        "Target Framework",
                        "NuGet Packages",
                        "Project References",
                        "Assembly References",
                        "C# Files",
                    ],
                    "Value": [
                        proj.name,
                        os.path.relpath(proj.path, root_dir),
                        proj.target_framework or "N/A",
                        len(proj.package_references),
                        len(proj.project_references),
                        len(proj.references),
                        len(proj.cs_files),
                    ],
                }
                st.dataframe(pd.DataFrame(config_data), use_container_width=True, hide_index=True)

                if proj.package_references:
                    st.subheader("NuGet Packages")
                    pkg_df = pd.DataFrame(proj.package_references)
                    pkg_df.columns = ["Package", "Version"]
                    st.dataframe(pkg_df, use_container_width=True, hide_index=True)

                if proj.project_references:
                    st.subheader("Project References")
                    ref_data = [{"Reference": r, "Project": os.path.basename(r).replace(".csproj", "")} for r in proj.project_references]
                    st.dataframe(pd.DataFrame(ref_data), use_container_width=True, hide_index=True)

                if proj.references:
                    st.subheader("Assembly References")
                    asm_data = [{"Assembly": r} for r in proj.references]
                    st.dataframe(pd.DataFrame(asm_data), use_container_width=True, hide_index=True)

            with proj_tabs[1]:
                st.subheader("C# Files")
                file_data = []
                for f in proj.cs_files:
                    rel = os.path.relpath(f, root_dir)
                    file_classes = [c for c in proj_classes if os.path.abspath(c.file_path) == os.path.abspath(f)]
                    file_data.append({
                        "File": rel,
                        "Types": len(file_classes),
                        "Types List": ", ".join(c.name for c in file_classes) or "-",
                    })
                if file_data:
                    st.dataframe(pd.DataFrame(file_data), use_container_width=True, hide_index=True)

                st.subheader("Namespaces")
                ns_set = sorted(set(c.namespace for c in proj_classes))
                ns_data = []
                for ns in ns_set:
                    ns_cls = [c for c in proj_classes if c.namespace == ns]
                    ns_data.append({
                        "Namespace": ns,
                        "Classes": sum(1 for c in ns_cls if not c.is_interface and not c.is_enum),
                        "Interfaces": sum(1 for c in ns_cls if c.is_interface),
                        "Enums": sum(1 for c in ns_cls if c.is_enum),
                        "Total": len(ns_cls),
                    })
                if ns_data:
                    st.dataframe(pd.DataFrame(ns_data), use_container_width=True, hide_index=True)

            with proj_tabs[2]:
                st.subheader("All Classes & Types in Project")
                cls_table = []
                for c in proj_classes:
                    cls_table.append({
                        "Namespace": c.namespace,
                        "Name": c.name,
                        "Type": c.class_type,
                        "Access": c.access_modifier,
                        "Abstract": "Yes" if c.is_abstract else "",
                        "Static": "Yes" if c.is_static else "",
                        "Properties": len(c.properties),
                        "Methods": len(c.methods),
                        "Fields": len(c.fields),
                        "Inherits": ", ".join(c.base_classes) or "-",
                        "Implements": ", ".join(c.interfaces) or "-",
                        "File": os.path.relpath(c.file_path, root_dir),
                    })
                if cls_table:
                    st.dataframe(pd.DataFrame(cls_table), use_container_width=True, hide_index=True)
                else:
                    st.info("No types found in this project.")

                st.subheader("Methods Summary")
                meth_all = []
                for c in proj_classes:
                    for m in c.methods:
                        params = ", ".join(f"{p['type']} {p['name']}" for p in m.parameters)
                        meth_all.append({
                            "Class": c.name,
                            "Method": m.name,
                            "Return Type": m.return_type,
                            "Parameters": params or "-",
                            "Access": m.access_modifier,
                            "Static": "Yes" if m.is_static else "",
                            "Async": "Yes" if m.is_async else "",
                        })
                if meth_all:
                    st.dataframe(pd.DataFrame(meth_all), use_container_width=True, hide_index=True)

                st.subheader("Properties Summary")
                prop_all = []
                for c in proj_classes:
                    for p in c.properties:
                        prop_all.append({
                            "Class": c.name,
                            "Property": p.name,
                            "Type": p.type,
                            "Access": p.access_modifier,
                        })
                if prop_all:
                    st.dataframe(pd.DataFrame(prop_all), use_container_width=True, hide_index=True)

            with proj_tabs[3]:
                st.subheader("Class Detail View")
                if proj_classes:
                    class_names = [f"{c.namespace}.{c.name}" for c in proj_classes]
                    selected = st.selectbox("Select a Class/Type", class_names, key="proj_class_detail")
                    cls = proj_classes[class_names.index(selected)]
                    render_class_detail(cls, root_dir, key_suffix="proj")
                else:
                    st.info("No types found in this project.")

            with proj_tabs[4]:
                st.subheader(f"Diagrams for {selected_proj_name}")
                render_diagrams_for_classes(proj_classes, selected_proj_name, f"proj_{selected_proj_name}")

    with tab_module:
        st.header("Module Explorer")
        mod_names = list(modules.keys())
        if not mod_names:
            st.info("No modules found in the project.")
        else:
            selected_module = st.selectbox("Select a Module", mod_names)
            mod = modules[selected_module]

            st.subheader(f"Module: {selected_module}")

            detail_col1, detail_col2, detail_col3 = st.columns(3)
            with detail_col1:
                st.metric("Namespaces", len(mod.namespaces))
            with detail_col2:
                st.metric("Types", len(mod.classes))
            with detail_col3:
                methods_count = sum(len(c.methods) for c in mod.classes)
                st.metric("Total Methods", methods_count)

            if mod.project:
                st.subheader("Project Details")
                proj_detail = {
                    "Property": ["Name", "Target Framework", "NuGet Packages",
                                 "Project References", "Assembly References", "C# Files"],
                    "Value": [
                        mod.project.name,
                        mod.project.target_framework or "N/A",
                        len(mod.project.package_references),
                        len(mod.project.project_references),
                        len(mod.project.references),
                        len(mod.project.cs_files),
                    ],
                }
                st.dataframe(pd.DataFrame(proj_detail), use_container_width=True, hide_index=True)

                if mod.project.package_references:
                    st.subheader("NuGet Packages")
                    st.dataframe(pd.DataFrame(mod.project.package_references), use_container_width=True, hide_index=True)

                if mod.project.project_references:
                    st.subheader("Project References")
                    ref_data = [{"Reference": r} for r in mod.project.project_references]
                    st.dataframe(pd.DataFrame(ref_data), use_container_width=True, hide_index=True)

            st.subheader("Namespaces")
            ns_data = []
            for ns in mod.namespaces:
                ns_classes = [c for c in mod.classes if c.namespace == ns]
                ns_data.append({
                    "Namespace": ns,
                    "Classes": sum(1 for c in ns_classes if not c.is_interface and not c.is_enum),
                    "Interfaces": sum(1 for c in ns_classes if c.is_interface),
                    "Enums": sum(1 for c in ns_classes if c.is_enum),
                    "Total": len(ns_classes),
                })
            st.dataframe(pd.DataFrame(ns_data), use_container_width=True, hide_index=True)

            st.subheader("Classes & Types")
            cls_table = []
            for c in mod.classes:
                cls_table.append({
                    "Namespace": c.namespace,
                    "Name": c.name,
                    "Type": c.class_type,
                    "Access": c.access_modifier,
                    "Abstract": "Yes" if c.is_abstract else "",
                    "Static": "Yes" if c.is_static else "",
                    "Properties": len(c.properties),
                    "Methods": len(c.methods),
                    "Inherits": ", ".join(c.base_classes) or "-",
                    "Implements": ", ".join(c.interfaces) or "-",
                })
            if cls_table:
                st.dataframe(pd.DataFrame(cls_table), use_container_width=True, hide_index=True)

            st.subheader("Class Detail View")
            class_names = [c.name for c in mod.classes]
            if class_names:
                selected_class = st.selectbox("Select a Class/Type", class_names, key="mod_class_select")
                cls = next(c for c in mod.classes if c.name == selected_class)
                render_class_detail(cls, root_dir, key_suffix="mod")

            st.markdown("---")
            st.subheader("Module Diagrams")
            render_diagrams_for_classes(mod.classes, selected_module, f"mod_{selected_module}")

    with tab_diagrams:
        st.header("All Diagrams (Full Project)")

        if all_classes:
            diag_tabs = st.tabs([
                "Architecture",
                "Class Diagram",
                "Class Relationships",
                "Data Flow (DFD)",
                "ETL Pipeline",
                "Namespace Overview",
                "Program Flow",
            ])

            with diag_tabs[0]:
                st.subheader("Solution Architecture")
                sol_name = solutions[0].name if solutions else "Project"
                dot = generate_architecture_diagram(modules, sol_name)
                render_diagram(dot, "full_architecture")

            with diag_tabs[1]:
                st.subheader("Full Class Diagram")
                if len(all_classes) > 50:
                    st.warning(f"Project has {len(all_classes)} types. Showing first 50 for readability.")
                    dot = generate_class_diagram(all_classes[:50], "Class Diagram (Top 50)")
                else:
                    dot = generate_class_diagram(all_classes, "Full Class Diagram")
                render_diagram(dot, "full_class")

            with diag_tabs[2]:
                st.subheader("Class Relationships")
                limit = min(len(all_classes), 50)
                dot = generate_class_relationship_diagram(all_classes[:limit], "Class Relationships")
                render_diagram(dot, "full_relationships")

            with diag_tabs[3]:
                st.subheader("Data Flow Diagram")
                dot = generate_data_flow_diagram(all_classes, "Full Project")
                render_diagram(dot, "full_dfd")

            with diag_tabs[4]:
                st.subheader("ETL / Data Pipeline")
                dot = generate_etl_diagram(all_classes, "Full Project")
                render_diagram(dot, "full_etl")

            with diag_tabs[5]:
                st.subheader("Namespace Overview")
                dot = generate_namespace_diagram(all_classes, "Full Project")
                render_diagram(dot, "full_namespace")

            with diag_tabs[6]:
                st.subheader("Program Flow")
                dot = generate_flow_diagram(all_classes, "Full Project")
                render_diagram(dot, "full_flow")
        else:
            st.info("No classes found to generate diagrams.")

    with tab_search:
        st.header("Table Name Search")
        st.markdown("Search for database table names across all project files including C# code, SQL files, config files, and more.")
        st.markdown("**Step 1:** Choose how to provide table names below. **Step 2:** Enter or upload your table names. **Step 3:** Click Search.")

        input_method = st.radio(
            "How would you like to provide table names?",
            ["Type table names (comma-separated)", "Upload a file (TXT, CSV, or Excel)"],
            horizontal=True,
            key="table_input_method",
        )

        table_names = []

        if input_method == "Type table names (comma-separated)":
            table_input = st.text_area(
                "Enter Table Names",
                placeholder="e.g. Users, OrderDetails, tbl_Products, Customers",
                help="Enter one or more table names separated by commas",
            )
            if table_input:
                table_names = [t.strip() for t in table_input.split(",") if t.strip()]
        else:
            table_file = st.file_uploader(
                "Upload table names file",
                type=["txt", "csv", "xlsx", "xls"],
                help="Upload a .txt (one per line), .csv (first column), or .xlsx/.xls (first column) file with table names",
                key="table_file_uploader",
            )
            if table_file:
                fname = table_file.name.lower()
                if fname.endswith((".xlsx", ".xls")):
                    try:
                        df_excel = pd.read_excel(table_file, header=None, engine="openpyxl" if fname.endswith(".xlsx") else None)
                        if df_excel.shape[0] > 0:
                            first_val = str(df_excel.iloc[0, 0]).strip().lower()
                            skip_headers = {"table_name", "tablename", "table name", "name", "table", "tables"}
                            start_row = 1 if first_val in skip_headers else 0
                            for idx in range(start_row, len(df_excel)):
                                val = str(df_excel.iloc[idx, 0]).strip()
                                if val and val.lower() != "nan":
                                    table_names.append(val)
                        if not table_names:
                            st.warning("No table names found in the Excel file. Make sure table names are in the first column.")
                    except Exception as e:
                        st.error(f"Error reading Excel file: {e}")
                else:
                    file_content = table_file.getvalue().decode("utf-8", errors="ignore")
                    for line in file_content.splitlines():
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        parts = line.split(",")
                        name = parts[0].strip().strip('"').strip("'")
                        if name and name.lower() not in ("table_name", "tablename", "table name", "name"):
                            table_names.append(name)

        if table_names:
            st.markdown(f"**{len(table_names)} table name(s) loaded:**")
            names_df = pd.DataFrame({"#": range(1, len(table_names) + 1), "Table Name": table_names})
            st.dataframe(names_df, use_container_width=True, hide_index=True, height=min(200, 35 * len(table_names) + 38))

        if table_names and st.button("Search All Tables", key="search_tables"):
            all_results = {}
            summary_rows = []
            progress = st.progress(0, text="Searching...")

            for i, tname in enumerate(table_names):
                progress.progress((i + 1) / len(table_names), text=f"Searching for '{tname}' ({i+1}/{len(table_names)})...")
                results = search_table_name(root_dir, tname)
                all_results[tname] = results
                ctx_types = set(r["context_type"] for r in results)
                files_found = set(r["file"] for r in results)
                summary_rows.append({
                    "Table Name": tname,
                    "Occurrences": len(results),
                    "Files": len(files_found),
                    "Context Types": ", ".join(sorted(ctx_types)) if ctx_types else "-",
                })

            progress.empty()

            total_hits = sum(len(v) for v in all_results.values())
            found_count = sum(1 for v in all_results.values() if v)
            not_found = [t for t, v in all_results.items() if not v]

            st.success(f"Search complete: {found_count}/{len(table_names)} tables found, {total_hits} total occurrences")

            st.subheader("Summary")
            st.dataframe(pd.DataFrame(summary_rows), use_container_width=True, hide_index=True)

            if not_found:
                st.warning(f"Not found in any file: {', '.join(not_found)}")

            st.subheader("Results by Table")
            found_tables = [t for t in table_names if all_results[t]]
            if found_tables:
                selected_table = st.selectbox("Select a table to view details", found_tables, key="table_detail_select")
                results = all_results[selected_table]

                context_counts = {}
                file_counts = {}
                for r in results:
                    ctx = r["context_type"]
                    context_counts[ctx] = context_counts.get(ctx, 0) + 1
                    f = r["file"]
                    file_counts[f] = file_counts.get(f, 0) + 1

                sum_col1, sum_col2 = st.columns(2)
                with sum_col1:
                    st.markdown("**By Context Type**")
                    ctx_data = [{"Type": k, "Count": v} for k, v in sorted(context_counts.items(), key=lambda x: -x[1])]
                    st.dataframe(pd.DataFrame(ctx_data), use_container_width=True, hide_index=True)

                with sum_col2:
                    st.markdown("**By File**")
                    file_data = [{"File": k, "Occurrences": v} for k, v in sorted(file_counts.items(), key=lambda x: -x[1])]
                    st.dataframe(pd.DataFrame(file_data), use_container_width=True, hide_index=True)

                st.markdown("**Detailed Results**")
                detail_data = []
                for r in results:
                    detail_data.append({
                        "File": r["file"],
                        "Line": r["line_number"],
                        "Type": r["context_type"],
                        "Matched Terms": ", ".join(r["matched_terms"]),
                        "Line Content": r["line_content"][:200],
                    })
                st.dataframe(pd.DataFrame(detail_data), use_container_width=True, hide_index=True)

                st.markdown("**Code Context**")
                for i, r in enumerate(results[:30]):
                    with st.expander(f"{r['file']} : Line {r['line_number']} ({r['context_type']})"):
                        code_text = "\n".join(
                            f"{cl['num']:>6} | {cl['text']}" for cl in r["context_lines"]
                        )
                        st.code(code_text, language="csharp")
                        if r["matched_terms"]:
                            st.markdown(f"**Matched terms:** `{'`, `'.join(r['matched_terms'])}`")

                if len(results) > 30:
                    st.info(f"Showing first 30 results with context. {len(results) - 30} more results available in the table above.")

            st.subheader("All Occurrences (Combined)")
            combined_data = []
            for tname, results in all_results.items():
                for r in results:
                    combined_data.append({
                        "Table Name": tname,
                        "File": r["file"],
                        "Line": r["line_number"],
                        "Type": r["context_type"],
                        "Line Content": r["line_content"][:150],
                    })
            if combined_data:
                st.dataframe(pd.DataFrame(combined_data), use_container_width=True, hide_index=True)

        if not table_names:
            st.info("Enter table names above (comma-separated) or upload a TXT, CSV, or Excel file, then click Search.")

else:
    st.info("Upload a C# project ZIP file using the sidebar to get started.")

    st.subheader("What This Tool Analyzes")
    features = pd.DataFrame({
        "Feature": [
            "Solution Overview",
            "Project Explorer",
            "Module Identification",
            "Architecture Diagram",
            "Class Diagram (UML)",
            "Class Relationships",
            "Data Flow Diagram (DFD)",
            "ETL / Data Pipeline",
            "Namespace Overview",
            "Program Flow",
            "Table Name Search",
        ],
        "Description": [
            "Solution structure with all projects, NuGet packages, and references",
            "Select any project under the solution to see all its details, files, classes, methods, and diagrams",
            "Identifies all projects/modules in the solution with namespace grouping",
            "Shows solution structure, project dependencies, and layer organization",
            "Full UML class diagram with properties, methods, inheritance",
            "Inheritance, interface implementation, composition, and aggregation",
            "Controller > Service > Repository > Database data flow layers",
            "Extract, Transform, Load pipeline visualization",
            "Namespace grouping and cross-namespace dependencies",
            "Entry points and method call chains through the application",
            "Search for table names via text, CSV, or Excel file upload",
        ],
    })
    st.dataframe(features, use_container_width=True, hide_index=True)

    st.subheader("Supported File Types")
    files_df = pd.DataFrame({
        "File Type": [".sln", ".csproj", ".cs", ".sql", ".config/.json/.xml/.yml"],
        "Purpose": [
            "Solution structure and project listing",
            "Project details, NuGet packages, references, target framework",
            "Classes, interfaces, enums, methods, properties, inheritance",
            "SQL queries, table references, stored procedures",
            "Configuration files with connection strings and table mappings",
        ],
    })
    st.dataframe(files_df, use_container_width=True, hide_index=True)
