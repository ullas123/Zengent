#!/bin/bash
echo "Installing dependencies..."
pip install -r requirements.txt
echo
echo "Starting C# Project Analyzer..."
streamlit run app.py
