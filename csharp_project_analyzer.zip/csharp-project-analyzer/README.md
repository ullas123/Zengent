# C# Project Analyzer

A Streamlit web application that analyzes C# code projects. Upload a ZIP file containing your C# solution and get a complete breakdown of the architecture, modules, classes, data flow, and more — with interactive diagrams and detailed tables.

---

## Features

### Solution Overview
- Parses `.sln` files to list all projects in the solution
- Shows NuGet packages, project references, and assembly references across all projects
- Identifies modules with namespace grouping
- Displays a full architecture diagram of the solution

### Project Explorer
- Select any project under the solution to explore in detail
- **Project Config**: Target framework, NuGet packages, project/assembly references
- **Files & Namespaces**: All C# files with types they contain, namespace breakdown
- **Classes & Types**: Every class, interface, enum, struct, and record with properties, methods, fields
- **Class Detail**: Drill into any class to see full details — inheritance, properties, methods, fields, enum values
- **Diagrams**: All diagram types scoped to just the selected project

### Module Explorer
- Identifies modules based on `.csproj` projects or namespace grouping
- Detailed view of each module's namespaces, classes, and relationships
- All diagram types per module

### Diagrams (Exportable as PNG or DOT)
- **Architecture Diagram** — Solution structure with project dependencies
- **Class Diagram (UML)** — Full class diagram with properties, methods, inheritance
- **Class Relationships** — Inheritance, interface implementation, composition, aggregation
- **Data Flow Diagram (DFD)** — Controller > Service > Repository > Database layers
- **ETL / Data Pipeline** — Extract, Transform, Load pipeline visualization
- **Namespace Overview** — Namespace grouping and cross-namespace dependencies
- **Program Flow** — Entry points and method call chains

### Table Name Search
Search for database table names across all project files (C#, SQL, config, XML, JSON, YAML, etc.)
- **Input methods**:
  - Type comma-separated names
  - Upload a `.txt` file (one table name per line)
  - Upload a `.csv` file (table names in first column)
  - Upload an `.xlsx` / `.xls` Excel file (table names in first column)
- **Detection types**: SQL queries, ORM/Entity mappings, stored procedures, database connections, configuration references
- **Results**: Summary tables, per-file breakdown, code context with surrounding lines

---

## Installation

### Prerequisites
- Python 3.11 or higher
- Graphviz system package (for diagram rendering)

### Step 1: Install Graphviz (System Dependency)

**Windows:**
Download and install from https://graphviz.org/download/
Make sure to add Graphviz to your system PATH during installation.

**macOS:**
```bash
brew install graphviz
```

**Ubuntu / Debian:**
```bash
sudo apt-get install graphviz
```

**Fedora / RHEL:**
```bash
sudo dnf install graphviz
```

### Step 2: Install Python Dependencies

```bash
pip install -r requirements.txt
```

### Step 3: Run the Application

```bash
streamlit run app.py
```

The app will open in your browser at `http://localhost:8501`.

To use a specific port:
```bash
streamlit run app.py --server.port 5000
```

---

## Usage

1. **Upload** — Click "Browse files" in the sidebar and upload a `.zip` file containing your C# project (`.sln`, `.csproj`, `.cs` files, etc.)
2. **Explore** — Use the tabs to navigate:
   - **Solution Overview** — High-level view of the entire solution
   - **Project Explorer** — Select a project to see all its details
   - **Module Explorer** — Explore by module/namespace grouping
   - **All Diagrams** — Full project diagrams
   - **Table Name Search** — Search for database table references
3. **Download** — Click "Download as PNG" or "Download as DOT" on any diagram to save it

---

## Project Structure

```
csharp-project-analyzer/
├── app.py                  # Main Streamlit application
├── csharp_parser.py        # C# code parser (solutions, projects, classes, table search)
├── diagram_generator.py    # Graphviz diagram generators
├── requirements.txt        # Python dependencies
├── .streamlit/
│   └── config.toml         # Streamlit server configuration
└── README.md               # This file
```

---

## Supported File Types

| File Type                  | Purpose                                                      |
|---------------------------|--------------------------------------------------------------|
| `.sln`                    | Solution structure and project listing                        |
| `.csproj`                 | Project config, NuGet packages, references, target framework  |
| `.cs`                     | Classes, interfaces, enums, methods, properties, inheritance  |
| `.sql`                    | SQL queries, table references, stored procedures              |
| `.config` / `.json` / `.xml` / `.yml` | Configuration files, connection strings, table mappings |

---

## Notes

- Large projects (50+ types) will show the first 50 classes in full diagrams for readability
- The parser uses regex-based analysis — it handles most standard C# patterns including file-scoped namespaces, generics, and async methods
- Diagrams are generated using Graphviz and rendered as PNG images in the browser
