import re
import os
import zipfile
import tempfile
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class PropertyInfo:
    name: str
    type: str
    access_modifier: str = "public"


@dataclass
class MethodInfo:
    name: str
    return_type: str
    parameters: list = field(default_factory=list)
    access_modifier: str = "public"
    is_static: bool = False
    is_async: bool = False
    body_calls: list = field(default_factory=list)


@dataclass
class ClassInfo:
    name: str
    namespace: str
    file_path: str
    base_classes: list = field(default_factory=list)
    interfaces: list = field(default_factory=list)
    properties: list = field(default_factory=list)
    methods: list = field(default_factory=list)
    fields: list = field(default_factory=list)
    is_interface: bool = False
    is_abstract: bool = False
    is_static: bool = False
    is_enum: bool = False
    enum_values: list = field(default_factory=list)
    access_modifier: str = "public"
    using_statements: list = field(default_factory=list)
    class_type: str = "class"


@dataclass
class ProjectInfo:
    name: str
    path: str
    target_framework: str = ""
    references: list = field(default_factory=list)
    package_references: list = field(default_factory=list)
    project_references: list = field(default_factory=list)
    cs_files: list = field(default_factory=list)


@dataclass
class SolutionInfo:
    name: str
    projects: list = field(default_factory=list)


@dataclass
class ModuleInfo:
    name: str
    namespaces: list = field(default_factory=list)
    classes: list = field(default_factory=list)
    project: Optional[ProjectInfo] = None


def extract_zip(uploaded_file):
    temp_dir = tempfile.mkdtemp()
    zip_path = os.path.join(temp_dir, "project.zip")
    with open(zip_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    extract_dir = os.path.join(temp_dir, "extracted")
    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(extract_dir)
    return extract_dir


def find_files(root_dir, extension):
    results = []
    for dirpath, _, filenames in os.walk(root_dir):
        for f in filenames:
            if f.endswith(extension):
                results.append(os.path.join(dirpath, f))
    return results


def parse_solution(sln_path):
    sol = SolutionInfo(name=os.path.basename(sln_path).replace(".sln", ""))
    with open(sln_path, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()
    proj_pattern = r'Project\("\{[^}]+\}"\)\s*=\s*"([^"]+)"\s*,\s*"([^"]+)"'
    for match in re.finditer(proj_pattern, content):
        proj_name = match.group(1)
        proj_path = match.group(2).replace("\\", "/")
        if proj_path.endswith(".csproj"):
            sol.projects.append({"name": proj_name, "path": proj_path})
    return sol


def parse_csproj(csproj_path):
    proj = ProjectInfo(
        name=os.path.basename(csproj_path).replace(".csproj", ""),
        path=csproj_path,
    )
    try:
        with open(csproj_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except Exception:
        return proj

    fw = re.search(r"<TargetFramework>(.*?)</TargetFramework>", content)
    if fw:
        proj.target_framework = fw.group(1)

    for m in re.finditer(r'<PackageReference\s+Include="([^"]+)"(?:\s+Version="([^"]*)")?', content):
        proj.package_references.append({"name": m.group(1), "version": m.group(2) or ""})

    for m in re.finditer(r'<ProjectReference\s+Include="([^"]+)"', content):
        proj.project_references.append(m.group(1).replace("\\", "/"))

    for m in re.finditer(r'<Reference\s+Include="([^"]+)"', content):
        proj.references.append(m.group(1))

    proj_dir = os.path.dirname(csproj_path)
    proj.cs_files = find_files(proj_dir, ".cs")
    return proj


def _find_namespace_for_position(content, pos):
    ns_pattern = re.compile(r"namespace\s+([\w.]+)\s*[{;]")
    best_ns = "(Global)"
    for m in ns_pattern.finditer(content):
        if m.start() < pos:
            best_ns = m.group(1)
        else:
            break
    return best_ns


def parse_cs_file(file_path):
    classes = []
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except Exception:
        return classes

    using_stmts = re.findall(r"using\s+([\w.]+)\s*;", content)

    type_pattern = re.compile(
        r"(public|private|protected|internal)?\s*"
        r"(static\s+|abstract\s+|sealed\s+)?"
        r"(class|interface|struct|enum|record)\s+"
        r"(\w+)(?:<[^>]+>)?"
        r"(?:\s*:\s*([^{]+))?"
        r"\s*\{",
        re.MULTILINE,
    )

    for m in type_pattern.finditer(content):
        access = m.group(1) or "internal"
        modifiers = m.group(2) or ""
        class_type = m.group(3)
        name = m.group(4)
        inheritance = m.group(5)

        namespace = _find_namespace_for_position(content, m.start())

        ci = ClassInfo(
            name=name,
            namespace=namespace,
            file_path=file_path,
            access_modifier=access,
            is_interface=class_type == "interface",
            is_abstract="abstract" in modifiers,
            is_static="static" in modifiers,
            is_enum=class_type == "enum",
            using_statements=using_stmts,
            class_type=class_type,
        )

        if inheritance:
            parts = [p.strip() for p in inheritance.split(",")]
            for p in parts:
                clean = re.sub(r"<.*?>", "", p).strip()
                if not clean:
                    continue
                if clean.startswith("I") and len(clean) > 1 and clean[1].isupper():
                    ci.interfaces.append(clean)
                else:
                    ci.base_classes.append(clean)

        start = m.end()
        body = _extract_body(content, start - 1)

        if ci.is_enum:
            enum_vals = re.findall(r"(\w+)\s*(?:=\s*[^,}]+)?[,}]", body)
            ci.enum_values = enum_vals
        else:
            ci.properties = _extract_properties(body)
            ci.methods = _extract_methods(body)
            ci.fields = _extract_fields(body)

        classes.append(ci)

    return classes


def _extract_body(content, brace_start):
    depth = 0
    start = None
    for i in range(brace_start, len(content)):
        if content[i] == "{":
            if depth == 0:
                start = i + 1
            depth += 1
        elif content[i] == "}":
            depth -= 1
            if depth == 0:
                return content[start:i] if start else ""
    return content[start:] if start else ""


def _extract_properties(body):
    props = []
    pattern = re.compile(
        r"(public|private|protected|internal)\s+"
        r"(?:static\s+|virtual\s+|override\s+|abstract\s+)?"
        r"([\w<>\[\]?,\s]+?)\s+"
        r"(\w+)\s*\{",
    )
    skip = {"get", "set", "class", "interface", "void", "return", "if", "else", "for", "while", "new"}
    for m in pattern.finditer(body):
        type_name = m.group(2).strip()
        prop_name = m.group(3)
        if prop_name in skip:
            continue
        props.append(PropertyInfo(name=prop_name, type=type_name, access_modifier=m.group(1)))
    return props


def _extract_methods(body):
    methods = []
    pattern = re.compile(
        r"(public|private|protected|internal)\s+"
        r"(static\s+)?(async\s+)?"
        r"(?:virtual\s+|override\s+|abstract\s+)?"
        r"([\w<>\[\]?,\s]+?)\s+"
        r"(\w+)\s*\(([^)]*)\)",
    )
    skip = {"if", "else", "for", "while", "switch", "catch", "using", "lock", "foreach"}
    for m in pattern.finditer(body):
        name = m.group(5)
        if name in skip:
            continue

        params = []
        params_str = m.group(6).strip()
        if params_str:
            for p in params_str.split(","):
                p = p.strip()
                if p:
                    parts = p.rsplit(" ", 1)
                    if len(parts) == 2:
                        params.append({"type": parts[0].strip(), "name": parts[1].strip()})

        calls = []
        try:
            search_start = m.end()
            brace_idx = body.find("{", search_start)
            if brace_idx >= 0:
                method_body = _extract_body(body, brace_idx)
                call_pattern = re.compile(r"(?:(\w+)\.)?(\w+)\s*\(")
                exclude = {"if", "else", "for", "while", "switch", "catch", "new", "return", "typeof", "nameof"}
                for c in call_pattern.finditer(method_body):
                    call_name = c.group(2)
                    if call_name not in exclude:
                        obj = c.group(1) or ""
                        calls.append(f"{obj}.{call_name}" if obj else call_name)
        except Exception:
            pass

        methods.append(MethodInfo(
            name=name,
            return_type=m.group(4).strip(),
            parameters=params,
            access_modifier=m.group(1),
            is_static=bool(m.group(2)),
            is_async=bool(m.group(3)),
            body_calls=calls[:20],
        ))
    return methods


def _extract_fields(body):
    fields = []
    pattern = re.compile(
        r"(public|private|protected|internal)\s+"
        r"(?:static\s+|readonly\s+|const\s+)*"
        r"([\w<>\[\]?,]+)\s+"
        r"(\w+)\s*[;=]",
    )
    for m in pattern.finditer(body):
        fields.append({"access": m.group(1), "type": m.group(2), "name": m.group(3)})
    return fields


def analyze_project(root_dir):
    sln_files = find_files(root_dir, ".sln")
    csproj_files = find_files(root_dir, ".csproj")
    cs_files = find_files(root_dir, ".cs")

    solutions = [parse_solution(s) for s in sln_files]
    projects = [parse_csproj(p) for p in csproj_files]

    all_classes = []
    for cs in cs_files:
        all_classes.extend(parse_cs_file(cs))

    modules = _build_modules(projects, all_classes, root_dir)

    return {
        "solutions": solutions,
        "projects": projects,
        "classes": all_classes,
        "modules": modules,
        "root_dir": root_dir,
        "all_files": cs_files,
    }


def _build_modules(projects, all_classes, root_dir):
    modules = {}

    if projects:
        for proj in projects:
            mod_name = proj.name
            proj_dir = os.path.abspath(os.path.dirname(proj.path))
            mod_classes = []
            for c in all_classes:
                try:
                    abs_file = os.path.abspath(c.file_path)
                    if abs_file.startswith(proj_dir + os.sep) or abs_file.startswith(proj_dir + "/"):
                        mod_classes.append(c)
                except (ValueError, OSError):
                    pass
            namespaces = list(set(c.namespace for c in mod_classes))
            modules[mod_name] = ModuleInfo(
                name=mod_name,
                namespaces=namespaces,
                classes=mod_classes,
                project=proj,
            )
    else:
        ns_groups = {}
        for c in all_classes:
            top_ns = c.namespace.split(".")[0] if c.namespace != "(Global)" else "(Global)"
            if top_ns not in ns_groups:
                ns_groups[top_ns] = []
            ns_groups[top_ns].append(c)
        for ns, cls_list in ns_groups.items():
            namespaces = list(set(c.namespace for c in cls_list))
            modules[ns] = ModuleInfo(name=ns, namespaces=namespaces, classes=cls_list)

    return modules


def analyze_data_feed_flow(root_dir, all_classes):
    feed_analysis = {
        "sftp_components": [],
        "file_processors": [],
        "data_readers": [],
        "data_transformers": [],
        "data_loaders": [],
        "schedulers": [],
        "loggers": [],
        "config_references": [],
        "connection_strings": [],
        "file_patterns": [],
        "flow_steps": [],
    }

    sftp_keywords = re.compile(
        r"(sftp|sshclient|sftpclient|scpclient|ssh\.net|renci|"
        r"ftpclient|ftpwebresponse|ftpwebrequest|winscp|"
        r"remotepath|remotefile|remotehost|sftpfile|"
        r"uploadfile|downloadfile|getlisting|listdirectory|"
        r"connectsftp|sftpconnection|ftpconnection)",
        re.IGNORECASE,
    )
    file_proc_keywords = re.compile(
        r"(streamreader|streamwriter|filestream|fileinfo|directoryinfo|"
        r"file\.read|file\.write|file\.copy|file\.move|file\.delete|file\.exists|"
        r"path\.combine|path\.getextension|path\.getfilename|"
        r"csvreader|csvwriter|csvhelper|xmlreader|xmlwriter|xmldocument|"
        r"jsonreader|jsonwriter|jsonconvert|jsonserializer|"
        r"excelpackage|epplus|npoi|closedxml|openxml|spreadsheet|"
        r"textfieldparser|oledb|datatable\.load|"
        r"fileprocessor|fileparser|filewatcher|filesystemwatcher|"
        r"\.csv|\.txt|\.xml|\.json|\.xlsx|\.xls|\.dat|\.tsv|\.fixed)",
        re.IGNORECASE,
    )
    data_read_keywords = re.compile(
        r"(sqldatareader|sqlcommand|sqldataadapter|sqlconnection|"
        r"dbcommand|dbconnection|dbdatareader|oledbcommand|"
        r"executenonquery|executereader|executescalar|"
        r"datatable|dataset|datarow|datacolumn|"
        r"bulkcopy|sqlbulkcopy|bulkinsert|"
        r"entity\s*framework|dbcontext|dbset|"
        r"linq|iqueryable|idbconnection|dapper)",
        re.IGNORECASE,
    )
    scheduler_keywords = re.compile(
        r"(timer|schedule|cron|quartz|hangfire|"
        r"backgroundservice|ihostedservice|backgroundworker|"
        r"task\.delay|task\.run|thread\.sleep|"
        r"windowsservice|servicebase|topshelf|"
        r"triggerbuilder|jobbuilder|itrigger|ijob)",
        re.IGNORECASE,
    )

    all_cs_files = find_files(root_dir, ".cs")
    all_config_files = []
    for ext in (".config", ".json", ".xml", ".yml", ".yaml"):
        all_config_files.extend(find_files(root_dir, ext))

    for fpath in all_cs_files:
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                lines = content.splitlines()
        except Exception:
            continue

        rel_path = os.path.relpath(fpath, root_dir)

        for line_num, line in enumerate(lines, 1):
            if sftp_keywords.search(line):
                context_start = max(0, line_num - 3)
                context_end = min(len(lines), line_num + 2)
                feed_analysis["sftp_components"].append({
                    "file": rel_path,
                    "line": line_num,
                    "content": line.strip(),
                    "context": [{"num": context_start + i + 1, "text": lines[context_start + i]}
                                for i in range(context_end - context_start)],
                })

            if file_proc_keywords.search(line):
                feed_analysis["file_processors"].append({
                    "file": rel_path,
                    "line": line_num,
                    "content": line.strip(),
                })

            if data_read_keywords.search(line):
                feed_analysis["data_readers"].append({
                    "file": rel_path,
                    "line": line_num,
                    "content": line.strip(),
                })

            if scheduler_keywords.search(line):
                feed_analysis["schedulers"].append({
                    "file": rel_path,
                    "line": line_num,
                    "content": line.strip(),
                })

        conn_pattern = re.compile(
            r'(connectionstring|connection\s*string|data\s+source|server\s*=|database\s*=|'
            r'initial\s+catalog|integrated\s+security|user\s+id|password\s*=)',
            re.IGNORECASE,
        )
        for line_num, line in enumerate(lines, 1):
            if conn_pattern.search(line):
                feed_analysis["connection_strings"].append({
                    "file": rel_path,
                    "line": line_num,
                    "content": line.strip(),
                })

        file_ext_pattern = re.compile(
            r'["\'][\w/\\]*\.(csv|txt|xml|json|xlsx|xls|dat|tsv|fixed|log|zip|gz)["\']',
            re.IGNORECASE,
        )
        for m in file_ext_pattern.finditer(content):
            feed_analysis["file_patterns"].append({
                "file": rel_path,
                "pattern": m.group(0),
                "extension": m.group(1),
            })

    for fpath in all_config_files:
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                clines = content.splitlines()
        except Exception:
            continue

        rel_path = os.path.relpath(fpath, root_dir)
        config_patterns = re.compile(
            r"(sftp|ftp|remotepath|remotehost|inputpath|outputpath|archivepath|"
            r"sourcepath|destinationpath|filemask|filepattern|"
            r"connectionstring|data\s+source|server|database|"
            r"schedule|cron|interval|timeout|retrycount|"
            r"inputfolder|outputfolder|processedfolder|errorfolder|backupfolder)",
            re.IGNORECASE,
        )
        for line_num, line in enumerate(clines, 1):
            if config_patterns.search(line):
                feed_analysis["config_references"].append({
                    "file": rel_path,
                    "line": line_num,
                    "content": line.strip(),
                })

    for c in all_classes:
        name_lower = c.name.lower()
        ns_lower = c.namespace.lower()
        combined = name_lower + " " + ns_lower

        role = None
        if any(k in combined for k in ("sftp", "ftp", "ssh", "remote", "transfer", "download", "upload")):
            role = "SFTP / File Transfer"
        elif any(k in combined for k in ("watch", "monitor", "listener", "trigger", "schedule", "job", "timer")):
            role = "Scheduler / Trigger"
        elif any(k in combined for k in ("read", "parse", "extract", "ingest", "import", "fetch", "source", "input")):
            role = "Data Reader / Extractor"
        elif any(k in combined for k in ("transform", "convert", "map", "validate", "clean", "normalize", "enrich", "format")):
            role = "Data Transformer"
        elif any(k in combined for k in ("write", "load", "save", "persist", "insert", "export", "output", "sink", "bulk")):
            role = "Data Loader / Writer"
        elif any(k in combined for k in ("log", "audit", "trace", "notify", "alert", "email", "report")):
            role = "Logging / Notification"
        elif any(k in combined for k in ("config", "setting", "option", "parameter")):
            role = "Configuration"
        elif any(k in combined for k in ("service", "processor", "engine", "worker", "handler", "manager", "orchestrat")):
            role = "Orchestrator / Service"
        elif any(k in combined for k in ("repository", "dal", "dao", "context", "dbcontext", "database")):
            role = "Data Access"

        if role:
            feed_analysis["flow_steps"].append({
                "class": c.name,
                "namespace": c.namespace,
                "role": role,
                "methods": [m.name for m in c.methods],
                "file": os.path.relpath(c.file_path, root_dir),
            })

    return feed_analysis


def search_table_name(root_dir, table_name):
    results = []
    all_files = []
    search_extensions = (
        ".cs", ".sql", ".config", ".json", ".xml", ".csproj",
        ".cshtml", ".razor", ".txt", ".yml", ".yaml", ".resx",
    )
    for dirpath, _, filenames in os.walk(root_dir):
        for f in filenames:
            if any(f.endswith(ext) for ext in search_extensions):
                all_files.append(os.path.join(dirpath, f))

    pattern = re.compile(re.escape(table_name), re.IGNORECASE)
    wildcard_pattern = re.compile(r"[\w.]*" + re.escape(table_name) + r"[\w.]*", re.IGNORECASE)

    sql_keywords = re.compile(
        r"(SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM|FROM|JOIN|INTO|CREATE\s+TABLE|ALTER\s+TABLE|DROP\s+TABLE|TRUNCATE\s+TABLE|MERGE\s+INTO)",
        re.IGNORECASE,
    )

    for fpath in all_files:
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()
        except Exception:
            continue

        rel_path = os.path.relpath(fpath, root_dir)
        for line_num, line in enumerate(lines, 1):
            if pattern.search(line):
                context_type = "General Reference"
                if sql_keywords.search(line):
                    context_type = "SQL Query"
                elif re.search(r'(connectionString|SqlConnection|SqlCommand|DbContext|DbSet)', line, re.IGNORECASE):
                    context_type = "Database Connection"
                elif re.search(r'(\.Table\(|\.ToTable\(|\.HasTable\(|\[Table\()', line, re.IGNORECASE):
                    context_type = "ORM/Entity Mapping"
                elif re.search(r'(stored\s*proc|exec\s+|execute\s+|sp_)', line, re.IGNORECASE):
                    context_type = "Stored Procedure"
                elif fpath.endswith(".sql"):
                    context_type = "SQL File"
                elif fpath.endswith((".config", ".json", ".xml", ".yml", ".yaml")):
                    context_type = "Configuration"

                matches = wildcard_pattern.findall(line)

                context_start = max(0, line_num - 4)
                context_end = min(len(lines), line_num + 3)
                context_lines = lines[context_start:context_end]

                results.append({
                    "file": rel_path,
                    "line_number": line_num,
                    "line_content": line.strip(),
                    "context_type": context_type,
                    "matched_terms": list(set(matches)),
                    "context_lines": [
                        {"num": context_start + i + 1, "text": l.rstrip()}
                        for i, l in enumerate(context_lines)
                    ],
                })

    return results
