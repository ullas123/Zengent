import graphviz
import os
import tempfile


COLORS = {
    "class": "#4A90D9",
    "interface": "#50C878",
    "enum": "#FFB347",
    "struct": "#DDA0DD",
    "record": "#87CEEB",
    "abstract": "#FF6B6B",
    "static": "#C0C0C0",
    "module": "#E8E8E8",
    "namespace": "#FFF8DC",
    "data_store": "#B0E0E6",
    "process": "#FFDAB9",
    "external": "#D3D3D3",
}


def _type_color(cls):
    if cls.is_interface:
        return COLORS["interface"]
    if cls.is_enum:
        return COLORS["enum"]
    if cls.is_abstract:
        return COLORS["abstract"]
    if cls.is_static:
        return COLORS["static"]
    if cls.class_type == "struct":
        return COLORS["struct"]
    if cls.class_type == "record":
        return COLORS["record"]
    return COLORS["class"]


def _safe_id(name):
    return name.replace(".", "_").replace("<", "_").replace(">", "_").replace(",", "_").replace(" ", "_")


def generate_class_diagram(classes, title="Class Diagram"):
    dot = graphviz.Digraph(comment=title, format="png")
    dot.attr(rankdir="BT", label=title, fontsize="16", fontname="Helvetica", bgcolor="white", pad="0.5")
    dot.attr("node", shape="record", fontname="Helvetica", fontsize="10", style="filled")
    dot.attr("edge", fontname="Helvetica", fontsize="8")

    class_names = {c.name for c in classes}

    for cls in classes:
        sid = _safe_id(f"{cls.namespace}_{cls.name}")
        color = _type_color(cls)

        stereotype = f"\\<\\<{cls.class_type}\\>\\>\\n" if cls.class_type != "class" else ""

        props_str = ""
        if cls.properties:
            props_str = "\\l".join(
                f"{'+ ' if p.access_modifier == 'public' else '- '}{p.name}: {p.type}"
                for p in cls.properties[:15]
            )
            if len(cls.properties) > 15:
                props_str += f"\\l... +{len(cls.properties) - 15} more"
            props_str += "\\l"

        if cls.is_enum and cls.enum_values:
            props_str = "\\l".join(cls.enum_values[:15])
            if len(cls.enum_values) > 15:
                props_str += f"\\l... +{len(cls.enum_values) - 15} more"
            props_str += "\\l"

        methods_str = ""
        if cls.methods:
            methods_str = "\\l".join(
                f"{'+ ' if m.access_modifier == 'public' else '- '}{m.name}(): {m.return_type}"
                for m in cls.methods[:15]
            )
            if len(cls.methods) > 15:
                methods_str += f"\\l... +{len(cls.methods) - 15} more"
            methods_str += "\\l"

        label = f"{{{stereotype}{cls.name}|{props_str}|{methods_str}}}"
        dot.node(sid, label=label, fillcolor=color)

        for base in cls.base_classes:
            if base in class_names:
                base_cls = next((c for c in classes if c.name == base), None)
                if base_cls:
                    base_id = _safe_id(f"{base_cls.namespace}_{base_cls.name}")
                    dot.edge(sid, base_id, arrowhead="empty", style="solid", color="#333333")

        for iface in cls.interfaces:
            if iface in class_names:
                iface_cls = next((c for c in classes if c.name == iface), None)
                if iface_cls:
                    iface_id = _safe_id(f"{iface_cls.namespace}_{iface_cls.name}")
                    dot.edge(sid, iface_id, arrowhead="empty", style="dashed", color="#50C878")

    return dot


def generate_architecture_diagram(modules, solution_name="Solution"):
    dot = graphviz.Digraph(comment="Architecture", format="png")
    dot.attr(rankdir="TB", label=f"Architecture: {solution_name}", fontsize="18",
             fontname="Helvetica", bgcolor="white", pad="0.5", compound="true")
    dot.attr("node", fontname="Helvetica", fontsize="10")
    dot.attr("edge", fontname="Helvetica", fontsize="8")

    for mod_name, mod in modules.items():
        with dot.subgraph(name=f"cluster_{_safe_id(mod_name)}") as sub:
            sub.attr(label=mod_name, style="rounded,filled", fillcolor=COLORS["module"],
                     fontsize="14", fontname="Helvetica Bold")

            for ns in mod.namespaces[:10]:
                ns_id = _safe_id(f"{mod_name}_{ns}")
                ns_classes = [c for c in mod.classes if c.namespace == ns]
                class_list = "\\n".join(c.name for c in ns_classes[:8])
                if len(ns_classes) > 8:
                    class_list += f"\\n... +{len(ns_classes) - 8} more"
                sub.node(ns_id, label=f"{ns}\\n---\\n{class_list}",
                         shape="box", style="filled", fillcolor=COLORS["namespace"])

    for mod_name, mod in modules.items():
        if mod.project:
            for ref in mod.project.project_references:
                ref_name = os.path.basename(ref).replace(".csproj", "")
                if ref_name in modules:
                    src_ns = mod.namespaces[0] if mod.namespaces else mod_name
                    dst_ns = modules[ref_name].namespaces[0] if modules[ref_name].namespaces else ref_name
                    dot.edge(_safe_id(f"{mod_name}_{src_ns}"),
                             _safe_id(f"{ref_name}_{dst_ns}"),
                             label="references", style="dashed", color="#4A90D9")

    return dot


def generate_data_flow_diagram(classes, module_name="Module"):
    dot = graphviz.Digraph(comment="Data Flow Diagram", format="png")
    dot.attr(rankdir="LR", label=f"Data Flow: {module_name}", fontsize="16",
             fontname="Helvetica", bgcolor="white", pad="0.5")
    dot.attr("node", fontname="Helvetica", fontsize="10")
    dot.attr("edge", fontname="Helvetica", fontsize="8")

    controllers = []
    services = []
    repositories = []
    models = []
    others = []

    for c in classes:
        name_lower = c.name.lower()
        if any(k in name_lower for k in ("controller", "handler", "endpoint", "api")):
            controllers.append(c)
        elif any(k in name_lower for k in ("service", "manager", "engine", "processor", "worker")):
            services.append(c)
        elif any(k in name_lower for k in ("repository", "repo", "dal", "dao", "context", "dbcontext")):
            repositories.append(c)
        elif any(k in name_lower for k in ("model", "entity", "dto", "viewmodel", "vm")):
            models.append(c)
        else:
            others.append(c)

    dot.node("external", "External\\nClient/User", shape="box3d", style="filled",
             fillcolor=COLORS["external"], width="1.5")

    if controllers:
        with dot.subgraph(name="cluster_controllers") as sub:
            sub.attr(label="Controllers / API Layer", style="rounded,filled",
                     fillcolor="#FFE4E1")
            for c in controllers:
                sub.node(_safe_id(c.name), c.name, shape="box", style="filled",
                         fillcolor=COLORS["process"])
        for c in controllers:
            dot.edge("external", _safe_id(c.name), label="request", color="#4A90D9")

    if services:
        with dot.subgraph(name="cluster_services") as sub:
            sub.attr(label="Business Logic / Services", style="rounded,filled",
                     fillcolor="#E1FFE1")
            for c in services:
                sub.node(_safe_id(c.name), c.name, shape="box", style="filled",
                         fillcolor=COLORS["process"])
        for ctrl in controllers:
            for svc in services:
                dot.edge(_safe_id(ctrl.name), _safe_id(svc.name), color="#333333")

    if repositories:
        with dot.subgraph(name="cluster_repos") as sub:
            sub.attr(label="Data Access Layer", style="rounded,filled",
                     fillcolor="#E1E1FF")
            for c in repositories:
                sub.node(_safe_id(c.name), c.name, shape="box", style="filled",
                         fillcolor=COLORS["data_store"])
        source = services if services else controllers
        for s in source:
            for r in repositories:
                dot.edge(_safe_id(s.name), _safe_id(r.name), color="#333333")

    dot.node("database", "Database\\nStorage", shape="cylinder", style="filled",
             fillcolor=COLORS["data_store"], width="1.5")
    if repositories:
        for r in repositories:
            dot.edge(_safe_id(r.name), "database", label="CRUD", color="#FF6B6B")
    elif services:
        for s in services:
            dot.edge(_safe_id(s.name), "database", label="data", color="#FF6B6B")

    if models:
        with dot.subgraph(name="cluster_models") as sub:
            sub.attr(label="Models / Entities", style="rounded,filled",
                     fillcolor="#FFFFF0")
            for c in models[:12]:
                sub.node(_safe_id(c.name), c.name, shape="note", style="filled",
                         fillcolor=COLORS["enum"])

    if not controllers and not services and not repositories:
        for i, c in enumerate(classes[:15]):
            dot.node(_safe_id(c.name), c.name, shape="box", style="filled",
                     fillcolor=_type_color(c))
            for m in c.methods:
                for call in m.body_calls[:3]:
                    call_name = call.split(".")[-1] if "." in call else call
                    target = next((x for x in classes if x.name == call_name or
                                   any(mt.name == call_name for mt in x.methods)), None)
                    if target and target.name != c.name:
                        dot.edge(_safe_id(c.name), _safe_id(target.name),
                                 label=call_name, color="#333333", fontsize="7")

    return dot


def generate_class_relationship_diagram(classes, title="Class Relationships"):
    dot = graphviz.Digraph(comment=title, format="png")
    dot.attr(rankdir="LR", label=title, fontsize="16", fontname="Helvetica",
             bgcolor="white", pad="0.5")
    dot.attr("node", fontname="Helvetica", fontsize="10", shape="box", style="filled,rounded")
    dot.attr("edge", fontname="Helvetica", fontsize="8")

    class_names = {c.name for c in classes}

    for cls in classes:
        color = _type_color(cls)
        label = f"{cls.name}\\n({cls.class_type})"
        dot.node(_safe_id(cls.name), label=label, fillcolor=color)

    for cls in classes:
        for base in cls.base_classes:
            if base in class_names:
                dot.edge(_safe_id(cls.name), _safe_id(base),
                         label="inherits", arrowhead="empty", color="#4A90D9", style="bold")

        for iface in cls.interfaces:
            if iface in class_names:
                dot.edge(_safe_id(cls.name), _safe_id(iface),
                         label="implements", arrowhead="empty", style="dashed", color="#50C878")

        for prop in cls.properties:
            prop_type = prop.type.replace("List<", "").replace("IEnumerable<", "").replace(
                "IList<", "").replace("ICollection<", "").replace(">", "").replace("?", "")
            if prop_type in class_names and prop_type != cls.name:
                dot.edge(_safe_id(cls.name), _safe_id(prop_type),
                         label=prop.name, arrowhead="diamond", color="#FFB347")

        for fld in cls.fields:
            fld_type = fld["type"].replace("List<", "").replace(">", "").replace("?", "")
            if fld_type in class_names and fld_type != cls.name:
                dot.edge(_safe_id(cls.name), _safe_id(fld_type),
                         label=fld["name"], arrowhead="odiamond", color="#DDA0DD", style="dashed")

    return dot


def generate_etl_diagram(classes, module_name="Module"):
    dot = graphviz.Digraph(comment="ETL Flow", format="png")
    dot.attr(rankdir="LR", label=f"ETL / Data Pipeline: {module_name}", fontsize="16",
             fontname="Helvetica", bgcolor="white", pad="0.5")
    dot.attr("node", fontname="Helvetica", fontsize="10")

    extractors = []
    transformers = []
    loaders = []
    general = []

    for c in classes:
        name_lower = c.name.lower()
        ns_lower = c.namespace.lower()
        combined = name_lower + " " + ns_lower

        if any(k in combined for k in ("extract", "reader", "source", "import", "input", "fetch",
                                        "pull", "ingest", "scrape", "crawl", "receive")):
            extractors.append(c)
        elif any(k in combined for k in ("transform", "convert", "map", "parse", "process",
                                          "validator", "filter", "format", "normalize", "enrich")):
            transformers.append(c)
        elif any(k in combined for k in ("load", "writer", "sink", "output", "export", "save",
                                          "persist", "store", "publish", "send")):
            loaders.append(c)
        else:
            general.append(c)

    if not extractors and not transformers and not loaders:
        for c in classes:
            has_read = any(any(k in m.name.lower() for k in ("get", "read", "fetch", "find", "query", "select"))
                          for m in c.methods)
            has_write = any(any(k in m.name.lower() for k in ("save", "write", "insert", "update", "delete", "add", "create", "put", "post"))
                           for m in c.methods)
            has_transform = any(any(k in m.name.lower() for k in ("convert", "map", "transform", "parse", "process", "validate", "calculate"))
                               for m in c.methods)
            if has_read:
                extractors.append(c)
            if has_transform:
                transformers.append(c)
            if has_write:
                loaders.append(c)

    dot.node("source", "Data\\nSource", shape="cylinder", style="filled",
             fillcolor="#B0E0E6", width="1.3")

    if extractors:
        with dot.subgraph(name="cluster_extract") as sub:
            sub.attr(label="EXTRACT", style="rounded,filled", fillcolor="#FFE4E1",
                     fontsize="14", fontname="Helvetica Bold")
            for c in extractors[:10]:
                sub.node(_safe_id(f"e_{c.name}"), c.name, shape="box",
                         style="filled", fillcolor="#FFDAB9")
        for c in extractors[:10]:
            dot.edge("source", _safe_id(f"e_{c.name}"), color="#4A90D9")

    if transformers:
        with dot.subgraph(name="cluster_transform") as sub:
            sub.attr(label="TRANSFORM", style="rounded,filled", fillcolor="#E1FFE1",
                     fontsize="14", fontname="Helvetica Bold")
            for c in transformers[:10]:
                sub.node(_safe_id(f"t_{c.name}"), c.name, shape="box",
                         style="filled", fillcolor="#98FB98")
        src = extractors[:10] if extractors else [None]
        for e in src:
            for t in transformers[:10]:
                if e:
                    dot.edge(_safe_id(f"e_{e.name}"), _safe_id(f"t_{t.name}"), color="#333333")
                else:
                    dot.edge("source", _safe_id(f"t_{t.name}"), color="#333333")

    if loaders:
        with dot.subgraph(name="cluster_load") as sub:
            sub.attr(label="LOAD", style="rounded,filled", fillcolor="#E1E1FF",
                     fontsize="14", fontname="Helvetica Bold")
            for c in loaders[:10]:
                sub.node(_safe_id(f"l_{c.name}"), c.name, shape="box",
                         style="filled", fillcolor="#ADD8E6")
        src = transformers[:10] if transformers else (extractors[:10] if extractors else [None])
        for t in src:
            for l in loaders[:10]:
                if t:
                    dot.edge(_safe_id(f"t_{t.name}") if t in transformers else _safe_id(f"e_{t.name}"),
                             _safe_id(f"l_{l.name}"), color="#333333")
                else:
                    dot.edge("source", _safe_id(f"l_{l.name}"), color="#333333")

    dot.node("dest", "Data\\nDestination", shape="cylinder", style="filled",
             fillcolor="#B0E0E6", width="1.3")
    if loaders:
        for l in loaders[:10]:
            dot.edge(_safe_id(f"l_{l.name}"), "dest", color="#FF6B6B")
    elif transformers:
        for t in transformers[:10]:
            dot.edge(_safe_id(f"t_{t.name}"), "dest", color="#FF6B6B")

    return dot


def generate_namespace_diagram(classes, module_name="Module"):
    dot = graphviz.Digraph(comment="Namespace Overview", format="png")
    dot.attr(rankdir="TB", label=f"Namespace Overview: {module_name}", fontsize="16",
             fontname="Helvetica", bgcolor="white", pad="0.5")
    dot.attr("node", fontname="Helvetica", fontsize="10")

    ns_groups = {}
    for c in classes:
        ns_groups.setdefault(c.namespace, []).append(c)

    for ns, cls_list in ns_groups.items():
        with dot.subgraph(name=f"cluster_{_safe_id(ns)}") as sub:
            sub.attr(label=ns, style="rounded,filled", fillcolor=COLORS["namespace"],
                     fontsize="12")
            for c in cls_list:
                sub.node(_safe_id(f"ns_{c.namespace}_{c.name}"), c.name,
                         shape="box", style="filled", fillcolor=_type_color(c))

    ns_list = list(ns_groups.keys())
    for ns in ns_list:
        for c in ns_groups[ns]:
            for using in c.using_statements:
                for other_ns in ns_list:
                    if other_ns != ns and (using == other_ns or other_ns.startswith(using + ".")):
                        dot.edge(_safe_id(f"ns_{ns}_{ns_groups[ns][0].name}"),
                                 _safe_id(f"ns_{other_ns}_{ns_groups[other_ns][0].name}"),
                                 label="uses", style="dashed", color="#999999")
                        break

    return dot


def generate_flow_diagram(classes, module_name="Module"):
    dot = graphviz.Digraph(comment="Program Flow", format="png")
    dot.attr(rankdir="TB", label=f"Program Flow: {module_name}", fontsize="16",
             fontname="Helvetica", bgcolor="white", pad="0.5")
    dot.attr("node", fontname="Helvetica", fontsize="10")

    entry_points = []
    for c in classes:
        for m in c.methods:
            if m.name in ("Main", "ConfigureServices", "Configure", "Startup", "Run",
                          "CreateHostBuilder", "CreateWebHostBuilder"):
                entry_points.append((c, m))

    if not entry_points:
        for c in classes:
            name_lower = c.name.lower()
            if any(k in name_lower for k in ("program", "startup", "app", "main", "host")):
                entry_points.append((c, c.methods[0] if c.methods else None))

    if entry_points:
        dot.node("start", "START", shape="oval", style="filled", fillcolor="#50C878",
                 fontcolor="white", width="1")
        for c, m in entry_points:
            node_id = _safe_id(f"entry_{c.name}")
            label = f"{c.name}\\n{m.name}()" if m else c.name
            dot.node(node_id, label, shape="box", style="filled,rounded", fillcolor="#4A90D9",
                     fontcolor="white")
            dot.edge("start", node_id)

    class_map = {c.name: c for c in classes}
    visited = set()

    def add_calls(src_cls, src_method, depth=0):
        if depth > 3:
            return
        src_id = _safe_id(f"flow_{src_cls.name}_{src_method.name}")
        if src_id in visited:
            return
        visited.add(src_id)
        dot.node(src_id, f"{src_cls.name}.{src_method.name}()", shape="box",
                 style="filled,rounded", fillcolor="#FFDAB9")
        for call in src_method.body_calls[:5]:
            call_name = call.split(".")[-1] if "." in call else call
            for target_cls in classes:
                for target_m in target_cls.methods:
                    if target_m.name == call_name and target_cls.name != src_cls.name:
                        target_id = _safe_id(f"flow_{target_cls.name}_{target_m.name}")
                        dot.node(target_id, f"{target_cls.name}.{target_m.name}()",
                                 shape="box", style="filled,rounded", fillcolor="#FFDAB9")
                        dot.edge(src_id, target_id, color="#333333")
                        add_calls(target_cls, target_m, depth + 1)
                        break
                else:
                    continue
                break

    for c, m in entry_points:
        if m:
            entry_id = _safe_id(f"entry_{c.name}")
            flow_id = _safe_id(f"flow_{c.name}_{m.name}")
            dot.node(flow_id, f"{c.name}.{m.name}()", shape="box",
                     style="filled,rounded", fillcolor="#FFDAB9")
            dot.edge(entry_id, flow_id)
            add_calls(c, m)

    if not entry_points:
        for c in classes[:10]:
            dot.node(_safe_id(c.name), c.name, shape="box", style="filled,rounded",
                     fillcolor=_type_color(c))
        for c in classes[:10]:
            for m in c.methods:
                for call in m.body_calls[:3]:
                    call_name = call.split(".")[-1] if "." in call else call
                    target = next((x for x in classes if x.name == call_name), None)
                    if target and target.name != c.name:
                        dot.edge(_safe_id(c.name), _safe_id(target.name), color="#333333")

    dot.node("end", "END", shape="oval", style="filled", fillcolor="#FF6B6B",
             fontcolor="white", width="1")

    return dot


def generate_data_feed_diagram(feed_analysis, title="Data Feed Flow"):
    dot = graphviz.Digraph(comment=title, format="png")
    dot.attr(rankdir="LR", label=title, fontsize="18", fontname="Helvetica",
             bgcolor="white", pad="0.5")
    dot.attr("node", fontname="Helvetica", fontsize="10")
    dot.attr("edge", fontname="Helvetica", fontsize="8")

    role_colors = {
        "SFTP / File Transfer": "#87CEEB",
        "Scheduler / Trigger": "#DDA0DD",
        "Data Reader / Extractor": "#98FB98",
        "Data Transformer": "#FFDAB9",
        "Data Loader / Writer": "#ADD8E6",
        "Logging / Notification": "#F0E68C",
        "Configuration": "#E8E8E8",
        "Orchestrator / Service": "#FFB347",
        "Data Access": "#B0E0E6",
    }

    role_order = [
        "Scheduler / Trigger",
        "SFTP / File Transfer",
        "Data Reader / Extractor",
        "Data Transformer",
        "Orchestrator / Service",
        "Data Access",
        "Data Loader / Writer",
        "Logging / Notification",
        "Configuration",
    ]

    role_shapes = {
        "SFTP / File Transfer": "folder",
        "Scheduler / Trigger": "diamond",
        "Data Reader / Extractor": "box",
        "Data Transformer": "box",
        "Data Loader / Writer": "box",
        "Logging / Notification": "note",
        "Configuration": "component",
        "Orchestrator / Service": "box3d",
        "Data Access": "cylinder",
    }

    steps = feed_analysis.get("flow_steps", [])
    if not steps:
        dot.node("empty", "No data feed\\ncomponents detected", shape="box",
                 style="filled", fillcolor="#FFE4E1")
        return dot

    role_groups = {}
    for step in steps:
        role = step["role"]
        role_groups.setdefault(role, []).append(step)

    dot.node("source", "External\\nSource / SFTP", shape="folder", style="filled",
             fillcolor="#D3D3D3", width="1.5")

    prev_role_nodes = ["source"]
    for role in role_order:
        if role not in role_groups:
            continue
        classes = role_groups[role]
        cluster_name = f"cluster_{_safe_id(role)}"
        color = role_colors.get(role, "#E8E8E8")
        shape = role_shapes.get(role, "box")

        with dot.subgraph(name=cluster_name) as sub:
            sub.attr(label=role, style="rounded,filled", fillcolor=color,
                     fontsize="12", fontname="Helvetica Bold")
            current_nodes = []
            for c in classes[:10]:
                nid = _safe_id(f"feed_{c['class']}")
                methods_str = "\\n".join(c["methods"][:5])
                if len(c["methods"]) > 5:
                    methods_str += f"\\n... +{len(c['methods']) - 5}"
                label = f"{c['class']}\\n---\\n{methods_str}" if methods_str else c["class"]
                sub.node(nid, label, shape=shape, style="filled", fillcolor="white")
                current_nodes.append(nid)

        if role not in ("Logging / Notification", "Configuration"):
            for prev in prev_role_nodes[:3]:
                for curr in current_nodes[:3]:
                    dot.edge(prev, curr, color="#333333")
            prev_role_nodes = current_nodes

    dot.node("destination", "Database /\\nOutput", shape="cylinder", style="filled",
             fillcolor="#B0E0E6", width="1.5")
    for node in prev_role_nodes[:3]:
        dot.edge(node, "destination", color="#FF6B6B", label="load")

    sftp_items = feed_analysis.get("sftp_components", [])
    if sftp_items:
        sftp_files = list(set(s["file"] for s in sftp_items))
        for sf in sftp_files[:5]:
            nid = _safe_id(f"sftpfile_{sf}")
            dot.node(nid, sf.split("/")[-1], shape="note", style="filled",
                     fillcolor="#87CEEB", fontsize="8")
            dot.edge("source", nid, style="dashed", color="#4A90D9", label="SFTP")

    file_pats = feed_analysis.get("file_patterns", [])
    if file_pats:
        exts = list(set(f["extension"].lower() for f in file_pats))
        for ext in exts[:6]:
            nid = _safe_id(f"filetype_{ext}")
            dot.node(nid, f".{ext} files", shape="note", style="filled",
                     fillcolor="#FAFAD2", fontsize="8")
            dot.edge("source", nid, style="dotted", color="#999999")

    return dot


def render_to_png(dot_graph):
    tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
    tmp.close()
    dot_graph.render(tmp.name.replace(".png", ""), format="png", cleanup=True)
    return tmp.name


def get_dot_source(dot_graph):
    return dot_graph.source
