import streamlit as st
import os
import pandas as pd
from csharp_parser import extract_zip, analyze_project, search_table_name, analyze_data_feed_flow
from diagram_generator import (
    generate_class_diagram,
    generate_architecture_diagram,
    generate_data_flow_diagram,
    generate_class_relationship_diagram,
    generate_etl_diagram,
    generate_namespace_diagram,
    generate_flow_diagram,
    generate_data_feed_diagram,
    get_dot_source,
)

st.set_page_config(page_title="C# Project Analyzer", layout="wide", page_icon="🔍")

st.title("C# Project Analyzer")
st.markdown("Upload a `.zip` file containing your C# project to analyze its architecture, modules, classes, data flow, and more.")

if "analysis" not in st.session_state:
    st.session_state.analysis = None
if "root_dir" not in st.session_state:
    st.session_state.root_dir = None
if "table_names" not in st.session_state:
    st.session_state.table_names = []
if "feed_analysis" not in st.session_state:
    st.session_state.feed_analysis = None


def sdf(df, **kwargs):
    try:
        st.dataframe(df, width="stretch", **kwargs)
    except Exception:
        try:
            st.dataframe(df, use_container_width=True, **kwargs)
        except Exception:
            st.dataframe(df, **kwargs)


def render_diagram(dot_graph, key_prefix):
    col1, col2 = st.columns([1, 1])
    with col1:
        st.download_button(
            label="Download as PNG",
            data=dot_graph.pipe(format="png"),
            file_name=f"{key_prefix}.png",
            mime="image/png",
            key=f"dl_png_{key_prefix}",
        )
    with col2:
        dot_src = get_dot_source(dot_graph)
        st.download_button(
            label="Download as DOT",
            data=dot_src,
            file_name=f"{key_prefix}.dot",
            mime="text/plain",
            key=f"dl_dot_{key_prefix}",
        )
    st.image(dot_graph.pipe(format="png"))


def render_class_detail(cls, root_dir, key_suffix=""):
    st.markdown(f"**{cls.class_type.upper()}: {cls.name}**")
    info_data = {
        "Property": ["Full Name", "Type", "Access", "Abstract", "Static", "File"],
        "Value": [
            f"{cls.namespace}.{cls.name}", cls.class_type, cls.access_modifier,
            "Yes" if cls.is_abstract else "No", "Yes" if cls.is_static else "No",
            os.path.relpath(cls.file_path, root_dir),
        ],
    }
    sdf(pd.DataFrame(info_data), hide_index=True)

    if cls.base_classes or cls.interfaces:
        inh_data = [{"Name": b, "Relationship": "Inherits"} for b in cls.base_classes]
        inh_data += [{"Name": i, "Relationship": "Implements"} for i in cls.interfaces]
        st.markdown("**Inheritance & Interfaces**")
        sdf(pd.DataFrame(inh_data), hide_index=True)

    if cls.properties:
        st.markdown("**Properties**")
        sdf(pd.DataFrame([{"Name": p.name, "Type": p.type, "Access": p.access_modifier} for p in cls.properties]), hide_index=True)

    if cls.methods:
        st.markdown("**Methods**")
        meth_data = []
        for m in cls.methods:
            params = ", ".join(f"{p['type']} {p['name']}" for p in m.parameters)
            meth_data.append({"Name": m.name, "Return Type": m.return_type, "Parameters": params or "-",
                              "Access": m.access_modifier, "Static": "Yes" if m.is_static else "", "Async": "Yes" if m.is_async else ""})
        sdf(pd.DataFrame(meth_data), hide_index=True)

    if cls.fields:
        st.markdown("**Fields**")
        sdf(pd.DataFrame([{"Name": f["name"], "Type": f["type"], "Access": f["access"]} for f in cls.fields]), hide_index=True)

    if cls.is_enum and cls.enum_values:
        st.markdown("**Enum Values**")
        sdf(pd.DataFrame([{"Value": v} for v in cls.enum_values]), hide_index=True)


def render_diagrams_for_classes(classes, label, key_prefix):
    diagram_type = st.selectbox("Select Diagram", [
        "Class Diagram", "Class Relationships", "Data Flow Diagram (DFD)",
        "ETL / Data Pipeline", "Namespace Overview", "Program Flow",
    ], key=f"diag_select_{key_prefix}")
    if not classes:
        st.info("No classes found to generate diagrams.")
        return
    generators = {
        "Class Diagram": lambda: generate_class_diagram(classes, f"Class Diagram: {label}"),
        "Class Relationships": lambda: generate_class_relationship_diagram(classes, f"Relationships: {label}"),
        "Data Flow Diagram (DFD)": lambda: generate_data_flow_diagram(classes, label),
        "ETL / Data Pipeline": lambda: generate_etl_diagram(classes, label),
        "Namespace Overview": lambda: generate_namespace_diagram(classes, label),
        "Program Flow": lambda: generate_flow_diagram(classes, label),
    }
    dot = generators[diagram_type]()
    safe_name = diagram_type.lower().replace("/", "-").replace(" ", "_").replace("(", "").replace(")", "")
    render_diagram(dot, f"{safe_name}_{key_prefix}")


uploaded = st.sidebar.file_uploader("Upload C# Project (.zip)", type=["zip"])

st.sidebar.markdown("---")
st.sidebar.subheader("Table Names (Optional)")
st.sidebar.markdown("Upload an Excel, CSV, or TXT file with table names to scan across the project.")
table_file = st.sidebar.file_uploader(
    "Upload Table Names",
    type=["xlsx", "xls", "csv", "txt"],
    help="Excel (.xlsx/.xls), CSV, or TXT file with table names in the first column",
    key="sidebar_table_upload",
)

if table_file:
    new_names = []
    fname = table_file.name.lower()
    if fname.endswith((".xlsx", ".xls")):
        try:
            df_excel = pd.read_excel(table_file, header=None, engine="openpyxl" if fname.endswith(".xlsx") else None)
            if df_excel.shape[0] > 0:
                first_val = str(df_excel.iloc[0, 0]).strip().lower()
                skip_headers = {"table_name", "tablename", "table name", "name", "table", "tables"}
                start_row = 1 if first_val in skip_headers else 0
                for idx in range(start_row, len(df_excel)):
                    val = str(df_excel.iloc[idx, 0]).strip()
                    if val and val.lower() != "nan":
                        new_names.append(val)
        except Exception as e:
            st.sidebar.error(f"Error reading Excel: {e}")
    else:
        file_content = table_file.getvalue().decode("utf-8", errors="ignore")
        for line in file_content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(",")
            name = parts[0].strip().strip('"').strip("'")
            if name and name.lower() not in ("table_name", "tablename", "table name", "name"):
                new_names.append(name)
    if new_names:
        st.session_state.table_names = new_names
        st.sidebar.success(f"{len(new_names)} table name(s) loaded")

if uploaded:
    if st.session_state.analysis is None or st.sidebar.button("Re-analyze"):
        with st.spinner("Extracting and analyzing project..."):
            root_dir = extract_zip(uploaded)
            analysis = analyze_project(root_dir)
            st.session_state.analysis = analysis
            st.session_state.root_dir = root_dir
            feed = analyze_data_feed_flow(root_dir, analysis["classes"])
            st.session_state.feed_analysis = feed

if st.session_state.analysis:
    analysis = st.session_state.analysis
    modules = analysis["modules"]
    solutions = analysis["solutions"]
    projects = analysis["projects"]
    all_classes = analysis["classes"]
    root_dir = st.session_state.root_dir
    feed_analysis = st.session_state.feed_analysis
    table_names = st.session_state.table_names

    st.sidebar.markdown("---")
    st.sidebar.subheader("Project Summary")
    st.sidebar.metric("Solutions", len(solutions))
    st.sidebar.metric("Projects / Modules", len(modules))
    st.sidebar.metric("Total Classes", len(all_classes))
    st.sidebar.metric("Total Files", len(analysis.get("all_files", [])))
    if table_names:
        st.sidebar.metric("Table Names Loaded", len(table_names))

    tab_overview, tab_project, tab_module, tab_feed, tab_diagrams, tab_search = st.tabs([
        "Solution Overview",
        "Project Explorer",
        "Module Explorer",
        "Data Feed / SFTP Flow",
        "All Diagrams",
        "Table Name Search",
    ])

    with tab_overview:
        st.header("Solution Overview")

        if solutions:
            st.subheader("Solutions")
            for sol in solutions:
                sol_data = [{"Project Name": p["name"], "Path": p["path"]} for p in sol.projects]
                if sol_data:
                    st.markdown(f"**{sol.name}.sln**")
                    sdf(pd.DataFrame(sol_data), hide_index=True)

        if projects:
            st.subheader("Projects")
            proj_data = [{"Project": p.name, "Framework": p.target_framework, "NuGet Packages": len(p.package_references),
                          "Project References": len(p.project_references), "C# Files": len(p.cs_files)} for p in projects]
            sdf(pd.DataFrame(proj_data), hide_index=True)

            st.subheader("NuGet Package References")
            pkg_data = [{"Project": p.name, "Package": pkg["name"], "Version": pkg["version"]}
                        for p in projects for pkg in p.package_references]
            if pkg_data:
                sdf(pd.DataFrame(pkg_data), hide_index=True)

        st.subheader("Modules Identified")
        mod_data = []
        for name, mod in modules.items():
            interfaces = sum(1 for c in mod.classes if c.is_interface)
            enums = sum(1 for c in mod.classes if c.is_enum)
            mod_data.append({"Module": name, "Namespaces": len(mod.namespaces),
                             "Classes": len(mod.classes) - interfaces - enums, "Interfaces": interfaces,
                             "Enums": enums, "Total Types": len(mod.classes)})
        sdf(pd.DataFrame(mod_data), hide_index=True)

        st.subheader("All Classes Summary")
        cls_data = [{"Namespace": c.namespace, "Name": c.name, "Type": c.class_type, "Access": c.access_modifier,
                     "Properties": len(c.properties), "Methods": len(c.methods), "Fields": len(c.fields),
                     "Inherits": ", ".join(c.base_classes) or "-", "Implements": ", ".join(c.interfaces) or "-"}
                    for c in all_classes]
        if cls_data:
            sdf(pd.DataFrame(cls_data), hide_index=True)

        if len(modules) > 0:
            st.subheader("Solution Architecture Diagram")
            sol_name = solutions[0].name if solutions else "Project"
            render_diagram(generate_architecture_diagram(modules, sol_name), "architecture_overview")

    with tab_project:
        st.header("Project Explorer")
        if not projects:
            st.info("No .csproj projects found. Use the Module Explorer tab instead.")
        else:
            if solutions:
                sol_names = [s.name for s in solutions]
                selected_sol = st.selectbox("Select Solution", sol_names, key="sol_select")
                sol = next(s for s in solutions if s.name == selected_sol)
                sol_proj_names = [p["name"] for p in sol.projects]
                matched_projects = [p for p in projects if p.name in sol_proj_names] or projects
                st.markdown(f"**Solution: {selected_sol}.sln** — {len(sol.projects)} project(s)")
                sdf(pd.DataFrame([{"Project Name": p["name"], "Path": p["path"]} for p in sol.projects]), hide_index=True)
            else:
                matched_projects = projects

            proj_names = [p.name for p in matched_projects]
            selected_proj_name = st.selectbox("Select Project", proj_names, key="proj_select")
            proj = next(p for p in matched_projects if p.name == selected_proj_name)

            proj_dir = os.path.abspath(os.path.dirname(proj.path))
            proj_classes = []
            for c in all_classes:
                try:
                    abs_file = os.path.abspath(c.file_path)
                    if abs_file.startswith(proj_dir + os.sep) or abs_file.startswith(proj_dir + "/"):
                        proj_classes.append(c)
                except (ValueError, OSError):
                    pass

            st.markdown("---")
            st.subheader(f"Project: {selected_proj_name}")
            m1, m2, m3, m4 = st.columns(4)
            with m1: st.metric("Framework", proj.target_framework or "N/A")
            with m2: st.metric("C# Files", len(proj.cs_files))
            with m3: st.metric("Types Found", len(proj_classes))
            with m4: st.metric("Total Methods", sum(len(c.methods) for c in proj_classes))

            proj_tabs = st.tabs(["Project Config", "Files & Namespaces", "Classes & Types", "Class Detail", "Diagrams"])

            with proj_tabs[0]:
                st.subheader("Project Configuration")
                config_data = {"Property": ["Project Name", "Project File", "Target Framework", "NuGet Packages",
                                            "Project References", "Assembly References", "C# Files"],
                               "Value": [proj.name, os.path.relpath(proj.path, root_dir), proj.target_framework or "N/A",
                                         len(proj.package_references), len(proj.project_references), len(proj.references), len(proj.cs_files)]}
                sdf(pd.DataFrame(config_data), hide_index=True)
                if proj.package_references:
                    st.subheader("NuGet Packages")
                    pkg_df = pd.DataFrame(proj.package_references)
                    pkg_df.columns = ["Package", "Version"]
                    sdf(pkg_df, hide_index=True)
                if proj.project_references:
                    st.subheader("Project References")
                    sdf(pd.DataFrame([{"Reference": r, "Project": os.path.basename(r).replace(".csproj", "")} for r in proj.project_references]), hide_index=True)
                if proj.references:
                    st.subheader("Assembly References")
                    sdf(pd.DataFrame([{"Assembly": r} for r in proj.references]), hide_index=True)

            with proj_tabs[1]:
                st.subheader("C# Files")
                file_data = []
                for f in proj.cs_files:
                    rel = os.path.relpath(f, root_dir)
                    fc = [c for c in proj_classes if os.path.abspath(c.file_path) == os.path.abspath(f)]
                    file_data.append({"File": rel, "Types": len(fc), "Types List": ", ".join(c.name for c in fc) or "-"})
                if file_data:
                    sdf(pd.DataFrame(file_data), hide_index=True)
                st.subheader("Namespaces")
                ns_set = sorted(set(c.namespace for c in proj_classes))
                ns_data = []
                for ns in ns_set:
                    nc = [c for c in proj_classes if c.namespace == ns]
                    ns_data.append({"Namespace": ns, "Classes": sum(1 for c in nc if not c.is_interface and not c.is_enum),
                                    "Interfaces": sum(1 for c in nc if c.is_interface), "Enums": sum(1 for c in nc if c.is_enum), "Total": len(nc)})
                if ns_data:
                    sdf(pd.DataFrame(ns_data), hide_index=True)

            with proj_tabs[2]:
                st.subheader("All Classes & Types in Project")
                cls_table = [{"Namespace": c.namespace, "Name": c.name, "Type": c.class_type, "Access": c.access_modifier,
                              "Abstract": "Yes" if c.is_abstract else "", "Static": "Yes" if c.is_static else "",
                              "Properties": len(c.properties), "Methods": len(c.methods), "Fields": len(c.fields),
                              "Inherits": ", ".join(c.base_classes) or "-", "Implements": ", ".join(c.interfaces) or "-",
                              "File": os.path.relpath(c.file_path, root_dir)} for c in proj_classes]
                if cls_table:
                    sdf(pd.DataFrame(cls_table), hide_index=True)
                else:
                    st.info("No types found in this project.")
                st.subheader("Methods Summary")
                meth_all = [{"Class": c.name, "Method": m.name, "Return Type": m.return_type,
                             "Parameters": ", ".join(f"{p['type']} {p['name']}" for p in m.parameters) or "-",
                             "Access": m.access_modifier, "Static": "Yes" if m.is_static else "", "Async": "Yes" if m.is_async else ""}
                            for c in proj_classes for m in c.methods]
                if meth_all:
                    sdf(pd.DataFrame(meth_all), hide_index=True)
                st.subheader("Properties Summary")
                prop_all = [{"Class": c.name, "Property": p.name, "Type": p.type, "Access": p.access_modifier}
                            for c in proj_classes for p in c.properties]
                if prop_all:
                    sdf(pd.DataFrame(prop_all), hide_index=True)

            with proj_tabs[3]:
                st.subheader("Class Detail View")
                if proj_classes:
                    cn = [f"{c.namespace}.{c.name}" for c in proj_classes]
                    selected = st.selectbox("Select a Class/Type", cn, key="proj_class_detail")
                    render_class_detail(proj_classes[cn.index(selected)], root_dir, key_suffix="proj")
                else:
                    st.info("No types found in this project.")

            with proj_tabs[4]:
                st.subheader(f"Diagrams for {selected_proj_name}")
                render_diagrams_for_classes(proj_classes, selected_proj_name, f"proj_{selected_proj_name}")

    with tab_module:
        st.header("Module Explorer")
        mod_names = list(modules.keys())
        if not mod_names:
            st.info("No modules found in the project.")
        else:
            selected_module = st.selectbox("Select a Module", mod_names)
            mod = modules[selected_module]
            st.subheader(f"Module: {selected_module}")
            mc1, mc2, mc3 = st.columns(3)
            with mc1: st.metric("Namespaces", len(mod.namespaces))
            with mc2: st.metric("Types", len(mod.classes))
            with mc3: st.metric("Total Methods", sum(len(c.methods) for c in mod.classes))

            if mod.project:
                st.subheader("Project Details")
                sdf(pd.DataFrame({"Property": ["Name", "Target Framework", "NuGet Packages", "Project References", "Assembly References", "C# Files"],
                                   "Value": [mod.project.name, mod.project.target_framework or "N/A", len(mod.project.package_references),
                                             len(mod.project.project_references), len(mod.project.references), len(mod.project.cs_files)]}), hide_index=True)
                if mod.project.package_references:
                    st.subheader("NuGet Packages")
                    sdf(pd.DataFrame(mod.project.package_references), hide_index=True)
                if mod.project.project_references:
                    st.subheader("Project References")
                    sdf(pd.DataFrame([{"Reference": r} for r in mod.project.project_references]), hide_index=True)

            st.subheader("Namespaces")
            ns_data = []
            for ns in mod.namespaces:
                nc = [c for c in mod.classes if c.namespace == ns]
                ns_data.append({"Namespace": ns, "Classes": sum(1 for c in nc if not c.is_interface and not c.is_enum),
                                "Interfaces": sum(1 for c in nc if c.is_interface), "Enums": sum(1 for c in nc if c.is_enum), "Total": len(nc)})
            sdf(pd.DataFrame(ns_data), hide_index=True)

            st.subheader("Classes & Types")
            cls_table = [{"Namespace": c.namespace, "Name": c.name, "Type": c.class_type, "Access": c.access_modifier,
                          "Abstract": "Yes" if c.is_abstract else "", "Static": "Yes" if c.is_static else "",
                          "Properties": len(c.properties), "Methods": len(c.methods),
                          "Inherits": ", ".join(c.base_classes) or "-", "Implements": ", ".join(c.interfaces) or "-"} for c in mod.classes]
            if cls_table:
                sdf(pd.DataFrame(cls_table), hide_index=True)

            st.subheader("Class Detail View")
            class_names = [c.name for c in mod.classes]
            if class_names:
                selected_class = st.selectbox("Select a Class/Type", class_names, key="mod_class_select")
                cls = next(c for c in mod.classes if c.name == selected_class)
                render_class_detail(cls, root_dir, key_suffix="mod")

            st.markdown("---")
            st.subheader("Module Diagrams")
            render_diagrams_for_classes(mod.classes, selected_module, f"mod_{selected_module}")

    with tab_feed:
        st.header("Data Feed / SFTP Flow Analysis")

        if feed_analysis:
            fc1, fc2, fc3, fc4 = st.columns(4)
            with fc1: st.metric("SFTP References", len(feed_analysis["sftp_components"]))
            with fc2: st.metric("File Processing", len(feed_analysis["file_processors"]))
            with fc3: st.metric("DB Operations", len(feed_analysis["data_readers"]))
            with fc4: st.metric("Scheduler Refs", len(feed_analysis["schedulers"]))

            feed_tabs = st.tabs([
                "Data Feed Flow Diagram",
                "SFTP / File Transfer",
                "File Processing",
                "Database Operations",
                "Schedulers / Jobs",
                "Config & Connections",
                "File Types Detected",
                "Component Roles",
            ])

            with feed_tabs[0]:
                st.subheader("Data Feed Flow Diagram")
                sol_name = solutions[0].name if solutions else "Project"
                dot = generate_data_feed_diagram(feed_analysis, f"Data Feed Flow: {sol_name}")
                render_diagram(dot, "data_feed_flow")

            with feed_tabs[1]:
                st.subheader("SFTP / File Transfer References")
                if feed_analysis["sftp_components"]:
                    sftp_data = [{"File": s["file"], "Line": s["line"], "Code": s["content"][:200]} for s in feed_analysis["sftp_components"]]
                    sdf(pd.DataFrame(sftp_data), hide_index=True)
                    st.subheader("Code Context")
                    for i, s in enumerate(feed_analysis["sftp_components"][:20]):
                        with st.expander(f"{s['file']} : Line {s['line']}"):
                            code_text = "\n".join(f"{cl['num']:>6} | {cl['text']}" for cl in s.get("context", []))
                            st.code(code_text, language="csharp")
                else:
                    st.info("No SFTP/FTP references found in the project.")

            with feed_tabs[2]:
                st.subheader("File Processing References")
                if feed_analysis["file_processors"]:
                    fp_files = {}
                    for fp in feed_analysis["file_processors"]:
                        fp_files.setdefault(fp["file"], []).append(fp)
                    fp_summary = [{"File": f, "References": len(refs)} for f, refs in sorted(fp_files.items(), key=lambda x: -len(x[1]))]
                    sdf(pd.DataFrame(fp_summary), hide_index=True)
                    sel_fp = st.selectbox("Select file to view details", [f["File"] for f in fp_summary], key="fp_file_select")
                    if sel_fp:
                        fp_detail = [{"Line": fp["line"], "Code": fp["content"][:200]} for fp in fp_files[sel_fp]]
                        sdf(pd.DataFrame(fp_detail), hide_index=True)
                else:
                    st.info("No file processing references found.")

            with feed_tabs[3]:
                st.subheader("Database Operation References")
                if feed_analysis["data_readers"]:
                    dr_files = {}
                    for dr in feed_analysis["data_readers"]:
                        dr_files.setdefault(dr["file"], []).append(dr)
                    dr_summary = [{"File": f, "References": len(refs)} for f, refs in sorted(dr_files.items(), key=lambda x: -len(x[1]))]
                    sdf(pd.DataFrame(dr_summary), hide_index=True)
                    sel_dr = st.selectbox("Select file to view details", [d["File"] for d in dr_summary], key="dr_file_select")
                    if sel_dr:
                        dr_detail = [{"Line": dr["line"], "Code": dr["content"][:200]} for dr in dr_files[sel_dr]]
                        sdf(pd.DataFrame(dr_detail), hide_index=True)
                else:
                    st.info("No database operation references found.")

            with feed_tabs[4]:
                st.subheader("Schedulers / Background Jobs")
                if feed_analysis["schedulers"]:
                    sch_data = [{"File": s["file"], "Line": s["line"], "Code": s["content"][:200]} for s in feed_analysis["schedulers"]]
                    sdf(pd.DataFrame(sch_data), hide_index=True)
                else:
                    st.info("No scheduler or background job references found.")

            with feed_tabs[5]:
                st.subheader("Configuration References")
                if feed_analysis["config_references"]:
                    cfg_data = [{"File": c["file"], "Line": c["line"], "Content": c["content"][:200]} for c in feed_analysis["config_references"]]
                    sdf(pd.DataFrame(cfg_data), hide_index=True)
                else:
                    st.info("No feed-related configuration references found.")
                st.subheader("Connection Strings")
                if feed_analysis["connection_strings"]:
                    conn_data = [{"File": c["file"], "Line": c["line"], "Content": c["content"][:200]} for c in feed_analysis["connection_strings"]]
                    sdf(pd.DataFrame(conn_data), hide_index=True)
                else:
                    st.info("No connection string references found.")

            with feed_tabs[6]:
                st.subheader("File Types / Patterns Detected")
                if feed_analysis["file_patterns"]:
                    ext_counts = {}
                    for fp in feed_analysis["file_patterns"]:
                        ext = fp["extension"].lower()
                        ext_counts[ext] = ext_counts.get(ext, 0) + 1
                    ext_data = [{"Extension": f".{k}", "Occurrences": v} for k, v in sorted(ext_counts.items(), key=lambda x: -x[1])]
                    sdf(pd.DataFrame(ext_data), hide_index=True)
                    all_pats = [{"File": fp["file"], "Pattern": fp["pattern"], "Extension": fp["extension"]} for fp in feed_analysis["file_patterns"]]
                    sdf(pd.DataFrame(all_pats), hide_index=True)
                else:
                    st.info("No file type patterns detected in code.")

            with feed_tabs[7]:
                st.subheader("Component Roles in Data Flow")
                if feed_analysis["flow_steps"]:
                    role_counts = {}
                    for step in feed_analysis["flow_steps"]:
                        role_counts[step["role"]] = role_counts.get(step["role"], 0) + 1
                    role_data = [{"Role": k, "Components": v} for k, v in sorted(role_counts.items(), key=lambda x: -x[1])]
                    sdf(pd.DataFrame(role_data), hide_index=True)
                    step_data = [{"Class": s["class"], "Namespace": s["namespace"], "Role": s["role"],
                                  "Methods": ", ".join(s["methods"][:5]) + ("..." if len(s["methods"]) > 5 else ""),
                                  "File": s["file"]} for s in feed_analysis["flow_steps"]]
                    sdf(pd.DataFrame(step_data), hide_index=True)
                else:
                    st.info("No data feed components identified by class naming conventions.")
        else:
            st.info("Feed analysis not available. Re-upload your project ZIP to generate.")

    with tab_diagrams:
        st.header("All Diagrams (Full Project)")
        if all_classes:
            diag_tabs = st.tabs(["Architecture", "Class Diagram", "Class Relationships", "Data Flow (DFD)",
                                 "ETL Pipeline", "Namespace Overview", "Program Flow", "Data Feed Flow"])
            with diag_tabs[0]:
                st.subheader("Solution Architecture")
                render_diagram(generate_architecture_diagram(modules, solutions[0].name if solutions else "Project"), "full_architecture")
            with diag_tabs[1]:
                st.subheader("Full Class Diagram")
                if len(all_classes) > 50:
                    st.warning(f"Project has {len(all_classes)} types. Showing first 50.")
                    render_diagram(generate_class_diagram(all_classes[:50], "Class Diagram (Top 50)"), "full_class")
                else:
                    render_diagram(generate_class_diagram(all_classes, "Full Class Diagram"), "full_class")
            with diag_tabs[2]:
                st.subheader("Class Relationships")
                render_diagram(generate_class_relationship_diagram(all_classes[:50], "Class Relationships"), "full_relationships")
            with diag_tabs[3]:
                st.subheader("Data Flow Diagram")
                render_diagram(generate_data_flow_diagram(all_classes, "Full Project"), "full_dfd")
            with diag_tabs[4]:
                st.subheader("ETL / Data Pipeline")
                render_diagram(generate_etl_diagram(all_classes, "Full Project"), "full_etl")
            with diag_tabs[5]:
                st.subheader("Namespace Overview")
                render_diagram(generate_namespace_diagram(all_classes, "Full Project"), "full_namespace")
            with diag_tabs[6]:
                st.subheader("Program Flow")
                render_diagram(generate_flow_diagram(all_classes, "Full Project"), "full_flow")
            with diag_tabs[7]:
                st.subheader("Data Feed Flow")
                if feed_analysis:
                    render_diagram(generate_data_feed_diagram(feed_analysis, "Data Feed Flow"), "full_data_feed")
                else:
                    st.info("Feed analysis not available.")
        else:
            st.info("No classes found to generate diagrams.")

    with tab_search:
        st.header("Table Name Search")
        st.markdown("Search for database table names across all project files.")

        if table_names:
            st.success(f"{len(table_names)} table name(s) loaded from sidebar upload")
            sdf(pd.DataFrame({"#": range(1, len(table_names) + 1), "Table Name": table_names}), hide_index=True,
                height=min(200, 35 * len(table_names) + 38))

        st.markdown("**Or type additional table names:**")
        extra_input = st.text_area("Enter Table Names (comma-separated)",
                                   placeholder="e.g. Users, OrderDetails, tbl_Products",
                                   help="Enter one or more table names separated by commas", key="extra_tables")
        search_names = list(table_names)
        if extra_input:
            extras = [t.strip() for t in extra_input.split(",") if t.strip()]
            search_names.extend(extras)
            search_names = list(dict.fromkeys(search_names))

        if search_names and st.button("Search All Tables", key="search_tables"):
            all_results = {}
            summary_rows = []
            progress = st.progress(0, text="Searching...")
            for i, tname in enumerate(search_names):
                progress.progress((i + 1) / len(search_names), text=f"Searching for '{tname}' ({i+1}/{len(search_names)})...")
                results = search_table_name(root_dir, tname)
                all_results[tname] = results
                ctx_types = set(r["context_type"] for r in results)
                files_found = set(r["file"] for r in results)
                summary_rows.append({"Table Name": tname, "Occurrences": len(results), "Files": len(files_found),
                                     "Context Types": ", ".join(sorted(ctx_types)) if ctx_types else "-"})
            progress.empty()

            total_hits = sum(len(v) for v in all_results.values())
            found_count = sum(1 for v in all_results.values() if v)
            not_found = [t for t, v in all_results.items() if not v]

            st.success(f"Search complete: {found_count}/{len(search_names)} tables found, {total_hits} total occurrences")
            st.subheader("Summary")
            sdf(pd.DataFrame(summary_rows), hide_index=True)
            if not_found:
                st.warning(f"Not found in any file: {', '.join(not_found)}")

            st.subheader("Results by Table")
            found_tables = [t for t in search_names if all_results[t]]
            if found_tables:
                selected_table = st.selectbox("Select a table to view details", found_tables, key="table_detail_select")
                results = all_results[selected_table]
                context_counts = {}
                file_counts = {}
                for r in results:
                    context_counts[r["context_type"]] = context_counts.get(r["context_type"], 0) + 1
                    file_counts[r["file"]] = file_counts.get(r["file"], 0) + 1
                sc1, sc2 = st.columns(2)
                with sc1:
                    st.markdown("**By Context Type**")
                    sdf(pd.DataFrame([{"Type": k, "Count": v} for k, v in sorted(context_counts.items(), key=lambda x: -x[1])]), hide_index=True)
                with sc2:
                    st.markdown("**By File**")
                    sdf(pd.DataFrame([{"File": k, "Occurrences": v} for k, v in sorted(file_counts.items(), key=lambda x: -x[1])]), hide_index=True)
                st.markdown("**Detailed Results**")
                sdf(pd.DataFrame([{"File": r["file"], "Line": r["line_number"], "Type": r["context_type"],
                                   "Matched Terms": ", ".join(r["matched_terms"]), "Line Content": r["line_content"][:200]} for r in results]), hide_index=True)
                st.markdown("**Code Context**")
                for i, r in enumerate(results[:30]):
                    with st.expander(f"{r['file']} : Line {r['line_number']} ({r['context_type']})"):
                        st.code("\n".join(f"{cl['num']:>6} | {cl['text']}" for cl in r["context_lines"]), language="csharp")
                        if r["matched_terms"]:
                            st.markdown(f"**Matched terms:** `{'`, `'.join(r['matched_terms'])}`")
                if len(results) > 30:
                    st.info(f"Showing first 30 results with context. {len(results) - 30} more in the table above.")

            st.subheader("All Occurrences (Combined)")
            combined_data = [{"Table Name": tname, "File": r["file"], "Line": r["line_number"],
                              "Type": r["context_type"], "Line Content": r["line_content"][:150]}
                             for tname, results in all_results.items() for r in results]
            if combined_data:
                sdf(pd.DataFrame(combined_data), hide_index=True)

        if not search_names:
            st.info("Upload an Excel/CSV/TXT file in the sidebar or type table names above, then click Search.")

else:
    st.info("Upload a C# project ZIP file using the sidebar to get started.")

    st.subheader("What This Tool Analyzes")
    features = pd.DataFrame({
        "Feature": ["Solution Overview", "Project Explorer", "Module Explorer", "Data Feed / SFTP Flow",
                     "Architecture Diagram", "Class Diagram (UML)", "Class Relationships",
                     "Data Flow Diagram (DFD)", "ETL / Data Pipeline", "Program Flow", "Table Name Search"],
        "Description": [
            "Solution structure with all projects, NuGet packages, and references",
            "Select any project under the solution to see all its details",
            "Identifies modules with namespace grouping",
            "SFTP/FTP file transfer, file processing, data pipeline, schedulers, and connections",
            "Shows solution structure, project dependencies, and layer organization",
            "Full UML class diagram with properties, methods, inheritance",
            "Inheritance, interface implementation, composition, and aggregation",
            "Controller > Service > Repository > Database data flow layers",
            "Extract, Transform, Load pipeline visualization",
            "Entry points and method call chains through the application",
            "Search for table names via sidebar Excel/CSV upload or text input",
        ],
    })
    sdf(features, hide_index=True)

    st.subheader("How to Use")
    sdf(pd.DataFrame({
        "Step": ["1", "2", "3"],
        "Action": [
            "Upload your C# project ZIP file in the sidebar",
            "(Optional) Upload an Excel/CSV/TXT file with table names in the sidebar",
            "Explore tabs: Solution Overview, Project Explorer, Module Explorer, Data Feed Flow, Diagrams, Table Search",
        ],
    }), hide_index=True)
