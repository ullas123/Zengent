import streamlit as st
import zipfile
import io
import os
import tempfile
from collections import defaultdict
from typing import Dict, List

from csharp_parser import CSharpParser
from diagram_generator import (
    generate_class_diagram,
    generate_flow_diagram,
    generate_architecture_diagram,
    generate_sftp_feed_diagram,
    generate_field_usage_diagram,
    generate_module_overview_diagram,
    render_to_png,
    render_to_svg,
    render_to_dot,
    render_to_jpg,
)

st.set_page_config(
    page_title="C# Repo Analyser",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Light theme styles ───────────────────────────────────────────────────────
st.markdown("""
<style>
    [data-testid="stAppViewContainer"] { background: #FFFFFF; }
    [data-testid="stSidebar"] { background: #F8FAFC; border-right: 1px solid #E2E8F0; }
    [data-testid="stHeader"] { background: transparent; }
    .stTabs [data-baseweb="tab-list"] { background: #F8FAFC; border-bottom: 1px solid #E2E8F0; }
    .stTabs [data-baseweb="tab"] { color: #64748B; }
    .stTabs [data-baseweb="tab"][aria-selected="true"] { color: #2563EB; border-bottom: 2px solid #2563EB; }
    .metric-card {
        background: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 8px;
        padding: 16px 20px;
        text-align: center;
    }
    .metric-card .value { font-size: 2rem; font-weight: 700; color: #2563EB; }
    .metric-card .label { font-size: 0.8rem; color: #64748B; margin-top: 4px; }
    .stDownloadButton > button {
        background: #EFF6FF;
        border: 1px solid #BFDBFE;
        color: #1E40AF;
        border-radius: 6px;
        font-size: 0.85rem;
    }
    .stDownloadButton > button:hover { background: #DBEAFE; border-color: #2563EB; }
    .section-header {
        color: #64748B;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        margin-bottom: 8px;
        margin-top: 16px;
    }
</style>
""", unsafe_allow_html=True)


# ─── Session state ────────────────────────────────────────────────────────────
if "parser" not in st.session_state:
    st.session_state.parser = None
if "loaded" not in st.session_state:
    st.session_state.loaded = False


# ─── Helpers ─────────────────────────────────────────────────────────────────
def load_zip(uploaded_file) -> Dict[str, str]:
    files = {}
    with zipfile.ZipFile(io.BytesIO(uploaded_file.read())) as zf:
        for info in zf.infolist():
            if info.filename.endswith(".cs") and not info.is_dir():
                try:
                    content = zf.read(info.filename).decode("utf-8", errors="replace")
                    files[info.filename] = content
                except Exception:
                    pass
    return files


def export_buttons(graph, name: str):
    col1, col2, col3, col4 = st.columns([1, 1, 1, 1])
    try:
        png_bytes = render_to_png(graph)
        with col1:
            st.download_button(
                label="⬇ Export PNG",
                data=png_bytes,
                file_name=f"{name}.png",
                mime="image/png",
                use_container_width=True,
            )
    except Exception as e:
        with col1:
            st.caption(f"PNG failed: {e}")

    try:
        jpg_bytes = render_to_jpg(graph)
        with col2:
            st.download_button(
                label="⬇ Export JPG",
                data=jpg_bytes,
                file_name=f"{name}.jpg",
                mime="image/jpeg",
                use_container_width=True,
            )
    except Exception as e:
        with col2:
            st.caption(f"JPG failed: {e}")

    try:
        svg_bytes = render_to_svg(graph)
        with col3:
            st.download_button(
                label="⬇ Export SVG",
                data=svg_bytes,
                file_name=f"{name}.svg",
                mime="image/svg+xml",
                use_container_width=True,
            )
    except Exception as e:
        with col3:
            st.caption(f"SVG failed: {e}")

    try:
        dot_src = render_to_dot(graph)
        with col4:
            st.download_button(
                label="⬇ Export DOT",
                data=dot_src.encode(),
                file_name=f"{name}.dot",
                mime="text/plain",
                use_container_width=True,
            )
    except Exception as e:
        with col4:
            st.caption(f"DOT failed: {e}")


def show_diagram(graph, name: str):
    try:
        png_bytes = render_to_png(graph)
        st.image(png_bytes, use_container_width=True)
        st.markdown("<div class='section-header'>Export</div>", unsafe_allow_html=True)
        export_buttons(graph, name)
    except Exception as e:
        st.error(f"Render error: {e}")
        st.code(render_to_dot(graph), language="dot")
        export_buttons(graph, name)


# ─── Live ZIP builder ────────────────────────────────────────────────────────
def _build_source_zip() -> bytes:
    """Build a ZIP of the app source files from disk at call-time (always current)."""
    base = os.path.dirname(os.path.abspath(__file__))
    entries = {
        "app.py":                    os.path.join(base, "app.py"),
        "csharp_parser.py":          os.path.join(base, "csharp_parser.py"),
        "diagram_generator.py":      os.path.join(base, "diagram_generator.py"),
        "requirements.txt":          os.path.join(base, "requirements.txt"),
        "README.md":                 os.path.join(base, "README.md"),
        ".streamlit/config.toml":    os.path.join(base, ".streamlit", "config.toml"),
    }
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc_name, src_path in entries.items():
            if os.path.isfile(src_path):
                zf.write(src_path, arc_name)
    return buf.getvalue()


# ─── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🔬 C# Repo Analyser")
    st.markdown("<div class='section-header'>Load Repository</div>", unsafe_allow_html=True)

    uploaded = st.file_uploader(
        "Upload C# repository ZIP",
        type=["zip"],
        help="ZIP file containing your C# project (.cs files will be scanned)",
    )

    if uploaded:
        with st.spinner("Parsing C# source files…"):
            cs_files = load_zip(uploaded)
            if cs_files:
                parser = CSharpParser()
                parser.parse_zip_contents(cs_files)
                st.session_state.parser = parser
                st.session_state.loaded = True
                st.success(f"Loaded **{len(cs_files)}** C# files")
            else:
                st.error("No .cs files found in ZIP")

    if st.session_state.loaded:
        parser: CSharpParser = st.session_state.parser
        modules = parser.get_modules()

        st.markdown("<div class='section-header'>Scope</div>", unsafe_allow_html=True)
        scope = st.radio(
            "Analyse",
            ["All modules", "Select module"],
            label_visibility="collapsed",
        )

        selected_module = None
        if scope == "Select module" and modules:
            selected_module = st.selectbox(
                "Module / Namespace",
                modules,
                label_visibility="collapsed",
            )

        st.markdown("<div class='section-header'>Stats</div>", unsafe_allow_html=True)
        all_cls = parser.get_all_classes()
        total_methods = sum(len(c.methods) for c in all_cls)
        total_props = sum(len(c.properties) for c in all_cls)

        for val, label in [
            (len(modules), "Namespaces"),
            (len(all_cls), "Classes"),
            (total_methods, "Methods"),
            (total_props, "Properties"),
        ]:
            st.markdown(
                f'<div class="metric-card"><div class="value">{val}</div>'
                f'<div class="label">{label}</div></div>',
                unsafe_allow_html=True,
            )
            st.write("")

    st.markdown("---")
    st.markdown("<div class='section-header'>Download App Source</div>", unsafe_allow_html=True)
    st.download_button(
        label="⬇ Download source ZIP",
        data=_build_source_zip(),
        file_name="csharp-analyser.zip",
        mime="application/zip",
        use_container_width=True,
        help="Always contains the latest version of every source file",
    )


# ─── Main area ────────────────────────────────────────────────────────────────
if not st.session_state.loaded:
    st.markdown("## C# Repository Diagram Generator")
    st.markdown(
        "Upload a **ZIP file** of your C# repository using the sidebar to begin. "
        "The tool will scan all `.cs` files and generate professional diagrams."
    )
    st.markdown("---")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("#### 🗂 What you get")
        st.markdown("""
- Class Diagrams with properties & methods
- Flow Diagrams per class / module
- Architecture Overview (namespace map)
- SFTP / Feed File data flow
- Field & Table usage tracing
- Module-level overview map
        """)
    with col2:
        st.markdown("#### 📦 Supported patterns")
        st.markdown("""
- Class / Interface / Abstract / Struct
- Inheritance & interface implementation
- EF Core DbSet & raw SQL references
- SFTP / FTP / WinSCP file operations
- Feed / inbound file processing
- Method call chains
        """)
    with col3:
        st.markdown("#### 💾 Export formats")
        st.markdown("""
- **PNG** — high-resolution raster image
- **JPG** — compressed JPEG image
- **SVG** — scalable vector graphic
- **DOT** — Graphviz source (editable)

All diagrams use a clean professional light theme.
        """)
    st.stop()


# Determine scope
parser: CSharpParser = st.session_state.parser
all_classes = parser.get_all_classes()
if selected_module:
    scoped_classes = parser.get_classes_in_module(selected_module)
    scope_label = selected_module
else:
    scoped_classes = all_classes
    scope_label = "All Modules"

if not scoped_classes:
    st.warning("No classes found for the selected scope.")
    st.stop()

# ─── Tabs ─────────────────────────────────────────────────────────────────────
tabs = st.tabs([
    "🗺 Overview",
    "🏛 Class Diagram",
    "🔄 Flow Diagram",
    "🏗 Architecture",
    "📡 SFTP / Feed",
    "🔎 Field & Table Search",
])


# ── Tab 0: Overview ───────────────────────────────────────────────────────────
with tabs[0]:
    st.subheader(f"Module Overview — {scope_label}")
    st.caption("Namespace-level map showing relationships and type counts.")

    with st.spinner("Generating overview…"):
        g = generate_module_overview_diagram(scoped_classes, title=scope_label)
    show_diagram(g, f"overview_{scope_label.replace('.', '_')}")


# ── Tab 1: Class Diagram ──────────────────────────────────────────────────────
with tabs[1]:
    st.subheader(f"Class Diagram — {scope_label}")

    cls_names = sorted(set(c.name for c in scoped_classes))
    class_filter = st.multiselect(
        "Filter classes (leave empty for all)",
        options=cls_names,
        placeholder="Select specific classes…",
    )
    filtered = [c for c in scoped_classes if not class_filter or c.name in class_filter]

    if len(filtered) > 40:
        st.info(f"Showing first 40 of {len(filtered)} classes for readability.")
        filtered = filtered[:40]

    with st.spinner("Generating class diagram…"):
        g = generate_class_diagram(filtered, title=f"Class Diagram — {scope_label}")
    show_diagram(g, f"class_diagram_{scope_label.replace('.', '_')}")


# ── Tab 2: Flow Diagram ───────────────────────────────────────────────────────
with tabs[2]:
    st.subheader(f"Flow Diagram — {scope_label}")

    cls_options = [c.name for c in scoped_classes if c.methods]
    if not cls_options:
        st.warning("No classes with methods found in this scope.")
    else:
        selected_cls_name = st.selectbox("Select class to inspect", cls_options)
        selected_cls = next(
            (c for c in scoped_classes if c.name == selected_cls_name), None
        )
        if selected_cls:
            with st.spinner(f"Generating flow diagram for {selected_cls_name}…"):
                g = generate_flow_diagram(selected_cls)
            show_diagram(g, f"flow_{selected_cls_name}")

            with st.expander("Method details table"):
                rows = []
                for m in selected_cls.methods:
                    rows.append({
                        "Method": m.name,
                        "Returns": m.return_type,
                        "Access": m.access,
                        "Parameters": len(m.parameters),
                        "Internal Calls": len(m.calls),
                        "Async": "async" in m.return_type.lower(),
                    })
                if rows:
                    import pandas as pd
                    st.dataframe(pd.DataFrame(rows), use_container_width=True)


# ── Tab 3: Architecture ───────────────────────────────────────────────────────
with tabs[3]:
    st.subheader(f"Architecture Diagram — {scope_label}")
    st.caption("Namespace clusters with class nodes and cross-namespace dependencies.")

    with st.spinner("Generating architecture diagram…"):
        g = generate_architecture_diagram(scoped_classes, title=scope_label)
    show_diagram(g, f"architecture_{scope_label.replace('.', '_')}")


# ── Tab 4: SFTP / Feed ────────────────────────────────────────────────────────
with tabs[4]:
    st.subheader("SFTP / Feed File Flow")
    st.caption("Detects file I/O patterns: SFTP clients, FTP, StreamReader, feed/inbound file handling.")

    sftp_refs = parser.file_io_references
    scoped_class_names = set(c.name for c in scoped_classes)
    scoped_refs = [r for r in sftp_refs if r.class_name in scoped_class_names]

    col1, col2, col3 = st.columns(3)
    with col1:
        sftp_count = sum(1 for r in scoped_refs if r.is_sftp)
        st.metric("SFTP References", sftp_count)
    with col2:
        feed_count = sum(1 for r in scoped_refs if r.is_feed)
        st.metric("Feed File References", feed_count)
    with col3:
        st.metric("Total IO References", len(scoped_refs))

    with st.spinner("Generating SFTP / feed flow diagram…"):
        g = generate_sftp_feed_diagram(scoped_classes, scoped_refs, title=scope_label)
    show_diagram(g, f"sftp_feed_{scope_label.replace('.', '_')}")

    if scoped_refs:
        with st.expander("All detected file I/O references"):
            import pandas as pd
            rows = [{
                "Class": r.class_name,
                "Operation": r.operation,
                "SFTP": "✓" if r.is_sftp else "",
                "Feed": "✓" if r.is_feed else "",
                "File": r.source_file.replace("\\", "/").split("/")[-1],
                "Context (truncated)": r.context[:80],
            } for r in scoped_refs]
            st.dataframe(pd.DataFrame(rows), use_container_width=True)


# ── Tab 5: Field & Table Search ───────────────────────────────────────────────
with tabs[5]:
    st.subheader("Field & Table Usage Search")
    st.caption("Enter a field name, table name, or column name to trace its usage across the codebase.")

    search_col, btn_col = st.columns([4, 1])
    with search_col:
        search_term = st.text_input(
            "Search term",
            placeholder="e.g. CustomerID, Orders, ProcessDate, AccountNumber…",
            label_visibility="collapsed",
        )
    with btn_col:
        do_search = st.button("Search", use_container_width=True, type="primary")

    if do_search and search_term.strip():
        term = search_term.strip()
        with st.spinner(f'Searching for "{term}"…'):
            results = parser.search_field_table(term)

        if results:
            st.success(f"Found **{len(results)}** references to `{term}`")

            import pandas as pd
            df = pd.DataFrame(results)
            df["file_short"] = df["file"].apply(
                lambda f: f.replace("\\", "/").split("/")[-1] if f else ""
            )

            col_a, col_b, col_c = st.columns(3)
            type_counts = df["type"].value_counts()
            for i, (t, cnt) in enumerate(type_counts.items()):
                [col_a, col_b, col_c][i % 3].metric(t, cnt)

            with st.expander("Usage table", expanded=True):
                display_df = df[["type", "class", "field", "method", "file_short", "context", "line"]].rename(columns={
                    "type": "Type",
                    "class": "Class",
                    "field": "Field / Property",
                    "method": "Method",
                    "file_short": "File",
                    "context": "Context",
                    "line": "Line",
                })
                st.dataframe(display_df, use_container_width=True)

            st.markdown("<div class='section-header'>Usage Diagram</div>", unsafe_allow_html=True)
            with st.spinner("Generating usage diagram…"):
                g = generate_field_usage_diagram(
                    term, results,
                    {c.name: c for c in all_classes}
                )
            show_diagram(g, f"field_usage_{term.replace(' ', '_')}")

            # Class diagram with matching classes highlighted in amber
            matched_names = {r["class"] for r in results if r.get("class")}
            if matched_names:
                st.markdown("<div class='section-header'>Highlighted Class Diagram</div>", unsafe_allow_html=True)
                st.caption(f"Classes containing **{term}** are shown in amber ★. All other classes in the same scope are shown in their normal colour.")
                with st.spinner("Generating highlighted class diagram…"):
                    gc = generate_class_diagram(
                        all_classes,
                        title=f'Class Diagram — matches for "{term}"',
                        highlight_term=term,
                    )
                show_diagram(gc, f"class_highlight_{term.replace(' ', '_')}")

        else:
            st.warning(f'No references found for `{term}` in the selected scope.')
            with st.spinner("Generating empty usage diagram…"):
                g = generate_field_usage_diagram(term, [], {})
            show_diagram(g, f"field_usage_{term.replace(' ', '_')}")

    elif not search_term and not do_search:
        st.markdown("""
        **Examples to try:**
        - A database table name like `Orders`, `Customers`, `AccountDetails`
        - A column/field name like `AccountId`, `ProcessDate`, `Status`
        - A method name like `ProcessFeed`, `DownloadFile`, `ValidateRecord`
        """)
