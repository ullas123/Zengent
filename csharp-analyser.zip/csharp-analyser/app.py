import streamlit as st
import zipfile
import io
import os
import tempfile
from collections import defaultdict
from typing import Dict, List

from csharp_parser import CSharpParser
from diagram_generator import (
    generate_class_diagram,
    generate_flow_diagram,
    generate_architecture_diagram,
    generate_sftp_feed_diagram,
    generate_sftp_folder_flow_diagram,
    generate_field_usage_diagram,
    generate_module_overview_diagram,
    render_to_png,
    render_to_svg,
    render_to_dot,
)

st.set_page_config(
    page_title="C# Repo Analyser",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Light theme overrides ───────────────────────────────────────────────────
st.markdown("""
<style>
    [data-testid="stAppViewContainer"] { background: #FFFFFF; }
    [data-testid="stSidebar"] { background: #F6F8FA; border-right: 1px solid #D0D7DE; }
    [data-testid="stHeader"] { background: transparent; }
    .stTabs [data-baseweb="tab-list"] { background: #F6F8FA; border-bottom: 1px solid #D0D7DE; }
    .stTabs [data-baseweb="tab"] { color: #57606A; }
    .stTabs [data-baseweb="tab"][aria-selected="true"] { color: #0969DA; border-bottom: 2px solid #0969DA; }
    .metric-card {
        background: #F6F8FA;
        border: 1px solid #D0D7DE;
        border-radius: 8px;
        padding: 16px 20px;
        text-align: center;
    }
    .metric-card .value { font-size: 2rem; font-weight: 700; color: #0969DA; }
    .metric-card .label { font-size: 0.8rem; color: #57606A; margin-top: 4px; }
    .stDownloadButton > button {
        background: #F6F8FA;
        border: 1px solid #D0D7DE;
        color: #1F2328;
        border-radius: 6px;
        font-size: 0.85rem;
    }
    .stDownloadButton > button:hover { background: #EAECEF; border-color: #0969DA; }
    .section-header {
        color: #57606A;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        margin-bottom: 8px;
        margin-top: 16px;
    }
</style>
""", unsafe_allow_html=True)


# ─── Session state ────────────────────────────────────────────────────────────
if "parser" not in st.session_state:
    st.session_state.parser = None
if "loaded" not in st.session_state:
    st.session_state.loaded = False


# ─── Helpers ─────────────────────────────────────────────────────────────────
def load_zip(uploaded_file) -> Dict[str, str]:
    files = {}
    with zipfile.ZipFile(io.BytesIO(uploaded_file.read())) as zf:
        for info in zf.infolist():
            if info.filename.endswith(".cs") and not info.is_dir():
                try:
                    content = zf.read(info.filename).decode("utf-8", errors="replace")
                    files[info.filename] = content
                except Exception:
                    pass
    return files


def export_buttons(graph, name: str):
    col1, col2, col3 = st.columns([1, 1, 1])
    try:
        png_bytes = render_to_png(graph)
        with col1:
            st.download_button(
                label="⬇ Export PNG",
                data=png_bytes,
                file_name=f"{name}.png",
                mime="image/png",
                use_container_width=True,
            )
    except Exception as e:
        with col1:
            st.caption(f"PNG failed: {e}")

    try:
        svg_bytes = render_to_svg(graph)
        with col2:
            st.download_button(
                label="⬇ Export SVG",
                data=svg_bytes,
                file_name=f"{name}.svg",
                mime="image/svg+xml",
                use_container_width=True,
            )
    except Exception as e:
        with col2:
            st.caption(f"SVG failed: {e}")

    try:
        dot_src = render_to_dot(graph)
        with col3:
            st.download_button(
                label="⬇ Export DOT",
                data=dot_src.encode(),
                file_name=f"{name}.dot",
                mime="text/plain",
                use_container_width=True,
            )
    except Exception as e:
        with col3:
            st.caption(f"DOT failed: {e}")


def show_diagram(graph, name: str):
    try:
        png_bytes = render_to_png(graph)
        st.image(io.BytesIO(png_bytes), use_column_width="always")
        st.markdown("<div class='section-header'>Export</div>", unsafe_allow_html=True)
        export_buttons(graph, name)
    except Exception as e:
        st.error(f"Render error: {e}")
        try:
            dot_src = render_to_dot(graph)
            st.code(dot_src, language="dot")
        except Exception:
            pass
        export_buttons(graph, name)


# ─── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🔬 C# Repo Analyser")
    st.markdown("<div class='section-header'>Load Repository</div>", unsafe_allow_html=True)

    uploaded = st.file_uploader(
        "Upload C# repository ZIP",
        type=["zip"],
        help="ZIP file containing your C# project (.cs files will be scanned)",
    )

    if uploaded:
        with st.spinner("Parsing C# source files…"):
            cs_files = load_zip(uploaded)
            if cs_files:
                parser = CSharpParser()
                parser.parse_zip_contents(cs_files)
                st.session_state.parser = parser
                st.session_state.loaded = True
                st.success(f"Loaded **{len(cs_files)}** C# files")
            else:
                st.error("No .cs files found in ZIP")

    if st.session_state.loaded:
        parser: CSharpParser = st.session_state.parser
        modules = parser.get_modules()

        st.markdown("<div class='section-header'>Scope</div>", unsafe_allow_html=True)
        scope = st.radio(
            "Analyse",
            ["All modules", "Select module"],
            label_visibility="collapsed",
        )

        selected_module = None
        if scope == "Select module" and modules:
            selected_module = st.selectbox(
                "Module / Namespace",
                modules,
                label_visibility="collapsed",
            )

        st.markdown("<div class='section-header'>Stats</div>", unsafe_allow_html=True)
        all_cls = parser.get_all_classes()
        total_methods = sum(len(c.methods) for c in all_cls)
        total_props = sum(len(c.properties) for c in all_cls)

        for val, label in [
            (len(modules), "Namespaces"),
            (len(all_cls), "Classes"),
            (total_methods, "Methods"),
            (total_props, "Properties"),
        ]:
            st.markdown(
                f'<div class="metric-card"><div class="value">{val}</div>'
                f'<div class="label">{label}</div></div>',
                unsafe_allow_html=True,
            )
            st.write("")


# ─── Main area ────────────────────────────────────────────────────────────────
if not st.session_state.loaded:
    st.markdown("## C# Repository Diagram Generator")
    st.markdown(
        "Upload a **ZIP file** of your C# repository using the sidebar to begin. "
        "The tool will scan all `.cs` files and generate professional diagrams."
    )
    st.markdown("---")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("#### 🗂 What you get")
        st.markdown("""
- Class Diagrams with properties & methods
- Flow Diagrams per class / module
- Architecture Overview (namespace map)
- SFTP / Feed File data flow
- Field & Table usage tracing
- Module-level overview map
        """)
    with col2:
        st.markdown("#### 📦 Supported patterns")
        st.markdown("""
- Class / Interface / Abstract / Struct
- Inheritance & interface implementation
- EF Core DbSet & raw SQL references
- SFTP / FTP / WinSCP file operations
- Feed / inbound file processing
- Method call chains
        """)
    with col3:
        st.markdown("#### 💾 Export formats")
        st.markdown("""
- **PNG** — high-resolution raster image
- **SVG** — scalable vector graphic
- **DOT** — Graphviz source (editable)

All diagrams use a professional dark-mode theme.
        """)
    st.stop()


# Determine scope
parser: CSharpParser = st.session_state.parser
all_classes = parser.get_all_classes()
if selected_module:
    scoped_classes = parser.get_classes_in_module(selected_module)
    scope_label = selected_module
else:
    scoped_classes = all_classes
    scope_label = "All Modules"

if not scoped_classes:
    st.warning("No classes found for the selected scope.")
    st.stop()

# ─── Tabs ─────────────────────────────────────────────────────────────────────
tabs = st.tabs([
    "🗺 Overview",
    "🏛 Class Diagram",
    "🔄 Flow Diagram",
    "🏗 Architecture",
    "📡 SFTP / Feed",
    "📂 SFTP Folder Flow",
    "🗂 Feed → DB Mapping",
    "🔎 Field & Table Search",
])


# ── Tab 0: Overview ───────────────────────────────────────────────────────────
with tabs[0]:
    st.subheader(f"Module Overview — {scope_label}")
    st.caption("Namespace-level map showing relationships and type counts.")

    with st.spinner("Generating overview…"):
        g = generate_module_overview_diagram(scoped_classes, title=scope_label)
    show_diagram(g, f"overview_{scope_label.replace('.', '_')}")


# ── Tab 1: Class Diagram ──────────────────────────────────────────────────────
with tabs[1]:
    st.subheader(f"Class Diagram — {scope_label}")

    cls_names = sorted(set(c.name for c in scoped_classes))
    class_filter = st.multiselect(
        "Filter classes (leave empty for all)",
        options=cls_names,
        placeholder="Select specific classes…",
    )
    filtered = [c for c in scoped_classes if not class_filter or c.name in class_filter]

    CHUNK = 34
    total = len(filtered)

    if total == 0:
        st.warning("No classes found for the selected filter.")
    elif total <= CHUNK:
        with st.spinner("Generating class diagram…"):
            g = generate_class_diagram(filtered, title=f"Class Diagram — {scope_label}")
        show_diagram(g, f"class_diagram_{scope_label.replace('.', '_')}")
    else:
        chunks = [filtered[i:i + CHUNK] for i in range(0, total, CHUNK)]
        st.info(f"{total} classes split across {len(chunks)} diagrams (≤{CHUNK} per diagram).")
        for idx, chunk in enumerate(chunks, 1):
            part_label = f"Part {idx} of {len(chunks)}  ({chunk[0].name} … {chunk[-1].name})"
            with st.expander(part_label, expanded=(idx == 1)):
                title = f"Class Diagram — {scope_label} (Part {idx}/{len(chunks)})"
                with st.spinner(f"Generating Part {idx}…"):
                    g = generate_class_diagram(chunk, title=title)
                name = f"class_diagram_{scope_label.replace('.', '_')}_part{idx}"
                show_diagram(g, name)


# ── Tab 2: Flow Diagram ───────────────────────────────────────────────────────
with tabs[2]:
    st.subheader(f"Flow Diagram — {scope_label}")

    cls_options = [c.name for c in scoped_classes if c.methods]
    if not cls_options:
        st.warning("No classes with methods found in this scope.")
    else:
        selected_cls_name = st.selectbox("Select class to inspect", cls_options)
        selected_cls = next(
            (c for c in scoped_classes if c.name == selected_cls_name), None
        )
        if selected_cls:
            with st.spinner(f"Generating flow diagram for {selected_cls_name}…"):
                g = generate_flow_diagram(selected_cls)
            show_diagram(g, f"flow_{selected_cls_name}")

            with st.expander("Method details table"):
                rows = []
                for m in selected_cls.methods:
                    rows.append({
                        "Method": m.name,
                        "Returns": m.return_type,
                        "Access": m.access,
                        "Parameters": len(m.parameters),
                        "Internal Calls": len(m.calls),
                        "Async": "async" in m.return_type.lower(),
                    })
                if rows:
                    import pandas as pd
                    st.dataframe(pd.DataFrame(rows), use_container_width=True)


# ── Tab 3: Architecture ───────────────────────────────────────────────────────
with tabs[3]:
    st.subheader(f"Architecture Diagram — {scope_label}")
    st.caption("Namespace clusters with class nodes and cross-namespace dependencies.")

    with st.spinner("Generating architecture diagram…"):
        g = generate_architecture_diagram(scoped_classes, title=scope_label)
    show_diagram(g, f"architecture_{scope_label.replace('.', '_')}")


# ── Tab 4: SFTP / Feed ────────────────────────────────────────────────────────
with tabs[4]:
    st.subheader("SFTP / Feed File Flow")
    st.caption("Detects file I/O patterns: SFTP clients, FTP, StreamReader, feed/inbound file handling.")

    sftp_refs = parser.file_io_references
    scoped_class_names = set(c.name for c in scoped_classes)
    scoped_refs = [r for r in sftp_refs if r.class_name in scoped_class_names]

    col1, col2, col3 = st.columns(3)
    with col1:
        sftp_count = sum(1 for r in scoped_refs if r.is_sftp)
        st.metric("SFTP References", sftp_count)
    with col2:
        feed_count = sum(1 for r in scoped_refs if r.is_feed)
        st.metric("Feed File References", feed_count)
    with col3:
        st.metric("Total IO References", len(scoped_refs))

    with st.spinner("Generating SFTP / feed flow diagram…"):
        g = generate_sftp_feed_diagram(scoped_classes, scoped_refs, title=scope_label)
    show_diagram(g, f"sftp_feed_{scope_label.replace('.', '_')}")

    if scoped_refs:
        with st.expander("All detected file I/O references"):
            import pandas as pd
            rows = [{
                "Class": r.class_name,
                "Operation": r.operation,
                "SFTP": "✓" if r.is_sftp else "",
                "Feed": "✓" if r.is_feed else "",
                "File": r.source_file.replace("\\", "/").split("/")[-1],
                "Context (truncated)": r.context[:80],
            } for r in scoped_refs]
            st.dataframe(pd.DataFrame(rows), use_container_width=True)


# ── Tab 5: SFTP Folder Flow ───────────────────────────────────────────────────
with tabs[5]:
    st.subheader("SFTP Folder File Processing Flow")
    st.caption("Step-by-step flow of how SFTP folder files are picked up, which modules handle them, and where data ends up.")

    sftp_refs2 = parser.file_io_references
    scoped_class_names2 = set(c.name for c in scoped_classes)
    scoped_refs2 = [r for r in sftp_refs2 if r.class_name in scoped_class_names2]

    sftp_only = [r for r in scoped_refs2 if r.is_sftp or any(
        kw in r.context.lower() for kw in ["getfiles", "directory", "sftp", "ftp", "download", "pickup", "folder"]
    )]
    refs_for_flow = sftp_only if sftp_only else scoped_refs2

    if refs_for_flow:
        from collections import Counter
        import pandas as pd

        cls_counts = Counter(r.class_name for r in refs_for_flow)
        ns_counts: Dict[str, int] = {}
        for cls in scoped_classes:
            if cls.name in cls_counts:
                ns_counts[cls.namespace] = ns_counts.get(cls.namespace, 0) + cls_counts[cls.name]

        ranked_cls_list = cls_counts.most_common()
        primary_module = max(ns_counts, key=ns_counts.get) if ns_counts else "—"

        col1, col2, col3, col4 = st.columns(4)
        col1.metric("SFTP References", len(sftp_only))
        col2.metric("Classes Involved", len(cls_counts))
        col3.metric("Namespaces Involved", len(ns_counts))
        col4.metric("Primary Module", primary_module.split(".")[-1] if primary_module != "—" else "—")

        with st.expander("Module ranking by SFTP activity", expanded=True):
            rows_rank = [{"Rank": i + 1, "Class": cls, "References": cnt,
                          "Namespace": next((c.namespace for c in scoped_classes if c.name == cls), "—")}
                         for i, (cls, cnt) in enumerate(ranked_cls_list)]
            st.dataframe(pd.DataFrame(rows_rank), use_container_width=True)

    with st.spinner("Generating SFTP folder flow diagram…"):
        g = generate_sftp_folder_flow_diagram(scoped_classes, scoped_refs2, title=scope_label)
    show_diagram(g, f"sftp_folder_{scope_label.replace('.', '_')}")


# ── Tab 6: Feed → DB Mapping ──────────────────────────────────────────────────
with tabs[6]:
    st.subheader("Feed File → Database Table/Column Mapping")
    st.caption(
        "Detects how feed file fields are mapped to database tables and columns in the code — "
        "via indexer access, GetField(), ORM attributes, Fluent API, and assignment patterns."
    )

    import pandas as pd

    with st.spinner("Scanning for feed-to-database mappings…"):
        all_mappings = parser.find_feed_table_mappings()

    scoped_cls_names_map = set(c.name for c in scoped_classes)
    mappings = [m for m in all_mappings if m["Class"] in scoped_cls_names_map]

    if not mappings:
        st.info(
            "No explicit feed-to-table mappings detected in this scope. "
            "This can mean the codebase uses dynamic mapping, reflection, or stored procedures."
        )
    else:
        df_map = pd.DataFrame(mappings)

        unique_tables = df_map["DB Table"].nunique()
        unique_fields = df_map["Feed Field"].nunique()
        unique_classes = df_map["Class"].nunique()
        mapping_types = df_map["Mapping Type"].nunique()

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Mapping Records", len(df_map))
        c2.metric("DB Tables Referenced", unique_tables)
        c3.metric("Unique Feed Fields", unique_fields)
        c4.metric("Classes Involved", unique_classes)

        # ── Filters ──────────────────────────────────────────────────────────
        with st.expander("Filters", expanded=False):
            fcol1, fcol2, fcol3 = st.columns(3)
            sel_class = fcol1.multiselect(
                "Class", sorted(df_map["Class"].unique()), key="map_cls")
            sel_table = fcol2.multiselect(
                "DB Table", sorted(df_map["DB Table"].unique()), key="map_tbl")
            sel_type  = fcol3.multiselect(
                "Mapping Type", sorted(df_map["Mapping Type"].unique()), key="map_type")

        filtered_df = df_map.copy()
        if sel_class:
            filtered_df = filtered_df[filtered_df["Class"].isin(sel_class)]
        if sel_table:
            filtered_df = filtered_df[filtered_df["DB Table"].isin(sel_table)]
        if sel_type:
            filtered_df = filtered_df[filtered_df["Mapping Type"].isin(sel_type)]

        # ── Main mapping table ────────────────────────────────────────────────
        st.markdown("<div class='section-header'>Mapping Table</div>", unsafe_allow_html=True)
        display_cols = ["Class", "Method", "Feed Field", "DB Table", "DB Column",
                        "Mapping Type", "File Op", "Namespace"]
        st.dataframe(
            filtered_df[display_cols].reset_index(drop=True),
            use_container_width=True,
        )

        # ── Grouped summary by table ──────────────────────────────────────────
        with st.expander("Summary — Fields per DB Table", expanded=True):
            summary = (
                filtered_df.groupby("DB Table")["Feed Field"]
                .apply(lambda x: ", ".join(sorted(set(x))))
                .reset_index()
                .rename(columns={"Feed Field": "Feed Fields Mapped"})
            )
            summary["Count"] = filtered_df.groupby("DB Table")["Feed Field"].nunique().values
            st.dataframe(summary.sort_values("Count", ascending=False).reset_index(drop=True),
                         use_container_width=True)

        # ── Grouped summary by class ──────────────────────────────────────────
        with st.expander("Summary — Tables per Class"):
            cls_summary = (
                filtered_df.groupby(["Class", "Namespace"])["DB Table"]
                .apply(lambda x: ", ".join(sorted(set(x))))
                .reset_index()
                .rename(columns={"DB Table": "DB Tables"})
            )
            st.dataframe(cls_summary.reset_index(drop=True), use_container_width=True)

        # ── Context viewer ────────────────────────────────────────────────────
        with st.expander("Full context (code snippets)"):
            ctx_cols = ["Class", "Method", "Feed Field", "DB Table", "Mapping Type", "Context"]
            st.dataframe(filtered_df[ctx_cols].reset_index(drop=True),
                         use_container_width=True)

        # ── Download ──────────────────────────────────────────────────────────
        st.markdown("<div class='section-header'>Export</div>", unsafe_allow_html=True)
        csv_data = filtered_df.to_csv(index=False).encode()
        st.download_button(
            "⬇ Download mappings as CSV",
            data=csv_data,
            file_name=f"feed_db_mappings_{scope_label.replace('.', '_')}.csv",
            mime="text/csv",
            use_container_width=True,
        )


# ── Tab 7: Field & Table Search ───────────────────────────────────────────────
with tabs[7]:
    st.subheader("Field & Table Usage Search")
    st.caption("Enter a field name, table name, or column name to trace its usage across the codebase.")

    search_col, btn_col = st.columns([4, 1])
    with search_col:
        search_term = st.text_input(
            "Search term",
            placeholder="e.g. CustomerID, Orders, ProcessDate, AccountNumber…",
            label_visibility="collapsed",
        )
    with btn_col:
        do_search = st.button("Search", use_container_width=True, type="primary")

    if do_search and search_term.strip():
        term = search_term.strip()
        with st.spinner(f'Searching for "{term}"…'):
            results = parser.search_field_table(term)

        if results:
            st.success(f"Found **{len(results)}** references to `{term}`")

            import pandas as pd
            df = pd.DataFrame(results)
            df["file_short"] = df["file"].apply(
                lambda f: f.replace("\\", "/").split("/")[-1] if f else ""
            )

            col_a, col_b, col_c = st.columns(3)
            type_counts = df["type"].value_counts()
            for i, (t, cnt) in enumerate(type_counts.items()):
                [col_a, col_b, col_c][i % 3].metric(t, cnt)

            with st.expander("Usage table", expanded=True):
                display_df = df[["type", "class", "field", "method", "file_short", "context", "line"]].rename(columns={
                    "type": "Type",
                    "class": "Class",
                    "field": "Field / Property",
                    "method": "Method",
                    "file_short": "File",
                    "context": "Context",
                    "line": "Line",
                })
                st.dataframe(display_df, use_container_width=True)

            st.markdown("<div class='section-header'>Usage Diagram</div>", unsafe_allow_html=True)
            with st.spinner("Generating usage diagram…"):
                g = generate_field_usage_diagram(
                    term, results,
                    {c.name: c for c in all_classes}
                )
            show_diagram(g, f"field_usage_{term.replace(' ', '_')}")

        else:
            st.warning(f'No references found for `{term}` in the selected scope.')
            with st.spinner("Generating empty usage diagram…"):
                g = generate_field_usage_diagram(term, [], {})
            show_diagram(g, f"field_usage_{term.replace(' ', '_')}")

    elif not search_term and not do_search:
        st.markdown("""
        **Examples to try:**
        - A database table name like `Orders`, `Customers`, `AccountDetails`
        - A column/field name like `AccountId`, `ProcessDate`, `Status`
        - A method name like `ProcessFeed`, `DownloadFile`, `ValidateRecord`
        """)
