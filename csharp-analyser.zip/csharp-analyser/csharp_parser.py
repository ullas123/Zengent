import re
import os
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Set, Tuple
from collections import defaultdict


@dataclass
class CSharpProperty:
    name: str
    type: str
    access: str = "public"
    is_static: bool = False


@dataclass
class CSharpMethod:
    name: str
    return_type: str
    parameters: List[str] = field(default_factory=list)
    access: str = "public"
    is_static: bool = False
    calls: List[str] = field(default_factory=list)
    body: str = ""


@dataclass
class CSharpClass:
    name: str
    namespace: str
    file_path: str
    base_class: Optional[str] = None
    interfaces: List[str] = field(default_factory=list)
    properties: List[CSharpProperty] = field(default_factory=list)
    methods: List[CSharpMethod] = field(default_factory=list)
    usings: List[str] = field(default_factory=list)
    is_interface: bool = False
    is_abstract: bool = False
    is_static: bool = False
    attributes: List[str] = field(default_factory=list)
    dependencies: Set[str] = field(default_factory=set)


@dataclass
class DatabaseReference:
    table_name: str
    field_name: str
    file_path: str
    class_name: str
    method_name: str
    context: str
    line_number: int


@dataclass
class FileIOReference:
    file_path_code: str
    operation: str
    source_file: str
    class_name: str
    method_name: str
    context: str
    is_sftp: bool = False
    is_feed: bool = False


class CSharpParser:
    def __init__(self):
        self.classes: Dict[str, CSharpClass] = {}
        self.namespaces: Set[str] = set()
        self.all_files: List[str] = []
        self.db_references: List[DatabaseReference] = []
        self.file_io_references: List[FileIOReference] = []

    def parse_zip_contents(self, files: Dict[str, str]):
        """Parse a dict of {filepath: content} for C# files."""
        self.classes = {}
        self.namespaces = set()
        self.all_files = list(files.keys())
        self.db_references = []
        self.file_io_references = []

        for filepath, content in files.items():
            if filepath.endswith(".cs"):
                self._parse_file(filepath, content)

        self._resolve_dependencies()

    def _parse_file(self, filepath: str, content: str):
        usings = self._extract_usings(content)
        namespace = self._extract_namespace(content)
        if namespace:
            self.namespaces.add(namespace)

        classes = self._extract_classes(content, namespace, filepath, usings)
        for cls in classes:
            self.classes[f"{cls.namespace}.{cls.name}"] = cls

        self._extract_db_references(content, filepath, classes)
        self._extract_file_io(content, filepath, classes)

    def _extract_usings(self, content: str) -> List[str]:
        return re.findall(r'^\s*using\s+([\w.]+)\s*;', content, re.MULTILINE)

    def _extract_namespace(self, content: str) -> Optional[str]:
        m = re.search(r'namespace\s+([\w.]+)', content)
        return m.group(1) if m else "Global"

    def _extract_classes(self, content: str, namespace: str, filepath: str, usings: List[str]) -> List[CSharpClass]:
        classes = []
        pattern = re.compile(
            r'(?P<attrs>(?:\s*\[[\w\s\(\),".]+\]\s*)*)'
            r'(?P<access>public|internal|protected|private)?\s*'
            r'(?P<mods>(?:abstract|static|sealed|partial)\s*)*'
            r'(?P<type>class|interface|struct|record)\s+'
            r'(?P<name>\w+)'
            r'(?:<[^>]+>)?'
            r'(?:\s*:\s*(?P<base>[^{]+))?'
            r'\s*\{',
            re.MULTILINE
        )
        for m in pattern.finditer(content):
            name = m.group("name")
            is_interface = m.group("type") == "interface"
            mods = m.group("mods") or ""
            is_abstract = "abstract" in mods
            is_static = "static" in mods

            base_class = None
            interfaces = []
            if m.group("base"):
                parts = [p.strip() for p in m.group("base").split(",")]
                for part in parts:
                    part = re.sub(r'<[^>]+>', '', part).strip()
                    if part and not part.startswith("I") and base_class is None and not is_interface:
                        base_class = part
                    elif part:
                        interfaces.append(part)

            attrs_text = m.group("attrs") or ""
            attributes = re.findall(r'\[(\w+)', attrs_text)

            # Extract class body
            start = m.end() - 1
            body = self._extract_block(content, start)

            properties = self._extract_properties(body)
            methods = self._extract_methods(body)

            cls = CSharpClass(
                name=name,
                namespace=namespace,
                file_path=filepath,
                base_class=base_class,
                interfaces=interfaces,
                properties=properties,
                methods=methods,
                usings=usings,
                is_interface=is_interface,
                is_abstract=is_abstract,
                is_static=is_static,
                attributes=attributes,
            )
            classes.append(cls)
        return classes

    def _extract_block(self, content: str, start: int) -> str:
        depth = 0
        i = start
        result = []
        while i < len(content):
            ch = content[i]
            if ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    break
            result.append(ch)
            i += 1
        return ''.join(result)

    def _extract_properties(self, body: str) -> List[CSharpProperty]:
        props = []
        pattern = re.compile(
            r'(?P<access>public|private|protected|internal)\s+'
            r'(?P<mods>(?:static|readonly|virtual|override|abstract)\s+)*'
            r'(?P<type>[\w<>\[\],\s?]+?)\s+'
            r'(?P<name>\w+)\s*'
            r'(?:\{[^}]*\}|=>|;)',
        )
        for m in pattern.finditer(body):
            type_name = m.group("type").strip()
            if type_name in ("class", "interface", "void", "return", "new"):
                continue
            prop = CSharpProperty(
                name=m.group("name"),
                type=type_name,
                access=m.group("access"),
                is_static="static" in (m.group("mods") or ""),
            )
            props.append(prop)
        return props

    def _extract_methods(self, body: str) -> List[CSharpMethod]:
        methods = []
        pattern = re.compile(
            r'(?P<access>public|private|protected|internal)\s+'
            r'(?P<mods>(?:static|virtual|override|abstract|async|sealed)\s+)*'
            r'(?P<ret>[\w<>\[\],\s?]+?)\s+'
            r'(?P<name>\w+)\s*'
            r'\((?P<params>[^)]*)\)\s*'
            r'(?:where[^{;]+)?'
            r'(?P<body>\{|;)',
        )
        for m in pattern.finditer(body):
            ret = m.group("ret").strip()
            if ret in ("class", "interface", "if", "while", "for", "foreach", "return", "new", "catch"):
                continue
            name = m.group("name")
            if name in ("if", "while", "for", "foreach", "catch", "switch"):
                continue

            params_raw = m.group("params").strip()
            params = []
            if params_raw:
                for p in params_raw.split(","):
                    p = p.strip()
                    if p:
                        params.append(p)

            method_body = ""
            if m.group("body") == "{":
                start = m.start("body")
                method_body = self._extract_block(body, start)

            calls = self._extract_method_calls(method_body)

            method = CSharpMethod(
                name=name,
                return_type=ret,
                parameters=params,
                access=m.group("access"),
                is_static="static" in (m.group("mods") or ""),
                calls=calls,
                body=method_body,
            )
            methods.append(method)
        return methods

    def _extract_method_calls(self, body: str) -> List[str]:
        calls = re.findall(r'(\w+)\s*\(', body)
        skip = {"if", "for", "foreach", "while", "switch", "catch", "using", "return", "new", "throw", "await"}
        return [c for c in calls if c not in skip and not c[0].isupper() or c[0].isupper()]

    def _resolve_dependencies(self):
        class_names = {cls.name for cls in self.classes.values()}
        for cls in self.classes.values():
            for prop in cls.properties:
                for name in class_names:
                    if name in prop.type:
                        cls.dependencies.add(name)
            for method in cls.methods:
                for param in method.parameters:
                    for name in class_names:
                        if name in param:
                            cls.dependencies.add(name)

    def _extract_db_references(self, content: str, filepath: str, classes: List[CSharpClass]):
        lines = content.split("\n")
        table_patterns = [
            r'"(\w+)"\s*,\s*"(\w+)"',
            r'FromSqlRaw\s*\(\s*"[^"]*FROM\s+(\w+)',
            r'\.Table\s*\(\s*"(\w+)"',
            r'DbSet<(\w+)>',
            r'@"\s*SELECT[^"]*FROM\s+(\w+)',
            r'"SELECT[^"]*FROM\s+(\w+)',
            r'INSERT\s+INTO\s+(\w+)',
            r'UPDATE\s+(\w+)\s+SET',
            r'\[Table\s*\(\s*"(\w+)"\s*\)\]',
            r'\[Column\s*\(\s*"(\w+)"\s*\)\]',
        ]
        current_class = classes[0].name if classes else "Unknown"
        current_method = "Unknown"
        for i, line in enumerate(lines):
            for pattern in table_patterns:
                for m in re.finditer(pattern, line, re.IGNORECASE):
                    groups = m.groups()
                    table = groups[0] if groups else ""
                    field_name = groups[1] if len(groups) > 1 else ""
                    if table:
                        self.db_references.append(DatabaseReference(
                            table_name=table,
                            field_name=field_name,
                            file_path=filepath,
                            class_name=current_class,
                            method_name=current_method,
                            context=line.strip(),
                            line_number=i + 1,
                        ))

    def _extract_file_io(self, content: str, filepath: str, classes: List[CSharpClass]):
        lines = content.split("\n")
        current_class = classes[0].name if classes else "Unknown"
        current_method = "Unknown"

        sftp_patterns = [
            (r'sftp|SftpClient|WinSCP|Renci\.SshNet', True),
            (r'FtpClient|FtpWebRequest|FTP', False),
            (r'File\.ReadAll|StreamReader|File\.Open|FileStream', False),
            (r'\.GetFiles|Directory\.GetFiles|Directory\.EnumerateFiles', False),
            (r'feed|Feed|inbound|Inbound|incoming|Incoming', False),
            (r'\.csv|\.txt|\.xml|\.json|\.dat', False),
        ]

        for i, line in enumerate(lines):
            for pattern, is_sftp in sftp_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    op = "Read"
                    if re.search(r'Write|Save|Upload|Put|Create', line, re.IGNORECASE):
                        op = "Write"
                    elif re.search(r'Download|Get|Read|Open', line, re.IGNORECASE):
                        op = "Read"

                    is_feed = bool(re.search(r'feed|Feed|inbound|Inbound|incoming|Incoming', line, re.IGNORECASE))
                    self.file_io_references.append(FileIOReference(
                        file_path_code=line.strip(),
                        operation=op,
                        source_file=filepath,
                        class_name=current_class,
                        method_name=current_method,
                        context=line.strip(),
                        is_sftp=is_sftp,
                        is_feed=is_feed,
                    ))
                    break

    def get_modules(self) -> List[str]:
        """Return list of unique namespaces/modules."""
        return sorted(self.namespaces)

    def get_classes_in_module(self, namespace: str) -> List[CSharpClass]:
        return [c for c in self.classes.values() if c.namespace == namespace]

    def get_all_classes(self) -> List[CSharpClass]:
        return list(self.classes.values())

    def get_project_folders(self) -> List[str]:
        folders = set()
        for f in self.all_files:
            parts = f.replace("\\", "/").split("/")
            if len(parts) > 1:
                folders.add(parts[0])
            else:
                folders.add("Root")
        return sorted(folders)

    def search_field_table(self, search_term: str) -> List[Dict]:
        results = []
        term_lower = search_term.lower()

        for ref in self.db_references:
            if (term_lower in ref.table_name.lower() or
                    term_lower in ref.field_name.lower() or
                    term_lower in ref.context.lower()):
                results.append({
                    "type": "Database Reference",
                    "table": ref.table_name,
                    "field": ref.field_name,
                    "file": ref.file_path,
                    "class": ref.class_name,
                    "method": ref.method_name,
                    "context": ref.context,
                    "line": ref.line_number,
                })

        for cls in self.classes.values():
            for prop in cls.properties:
                if term_lower in prop.name.lower() or term_lower in prop.type.lower():
                    results.append({
                        "type": "Property",
                        "table": cls.name,
                        "field": prop.name,
                        "file": cls.file_path,
                        "class": cls.name,
                        "method": "",
                        "context": f"{prop.access} {prop.type} {prop.name}",
                        "line": 0,
                    })
            for method in cls.methods:
                if term_lower in method.name.lower():
                    results.append({
                        "type": "Method",
                        "table": cls.name,
                        "field": method.name,
                        "file": cls.file_path,
                        "class": cls.name,
                        "method": method.name,
                        "context": f"{method.access} {method.return_type} {method.name}()",
                        "line": 0,
                    })

        return results

    def find_feed_table_mappings(self) -> List[Dict]:
        """
        Detect mappings between feed file fields/columns and database tables/columns.

        Strategies:
        1. Classes that have BOTH file IO refs AND DB refs — inferred bridge classes.
        2. Explicit field-access patterns inside method bodies (reader["col"], GetField, etc.)
        3. ORM/Fluent API mapping declarations (HasColumnName, [Column(…)]).
        4. Variable assignment patterns that bridge a file value to a named field.
        """
        results = []

        file_cls_names = set(r.class_name for r in self.file_io_references)
        db_cls_names   = set(r.class_name for r in self.db_references)
        bridge_classes = file_cls_names & db_cls_names

        # ── Pattern 1 & 2: method bodies in bridge classes ────────────────────
        FIELD_PATTERNS = [
            (r'\[\"(\w+)\"\]',                        "Indexer [\"field\"]"),
            (r'GetField(?:<[^>]+>)?\(\"(\w+)\"\)',    "GetField(\"field\")"),
            (r'GetValue\(\"(\w+)\"\)',                 "GetValue(\"field\")"),
            (r'\.Field<[^>]+>\(\"(\w+)\"\)',           "Field<T>(\"field\")"),
            (r'HasColumnName\(\"(\w+)\"\)',            "HasColumnName"),
            (r'\[Column\(\"(\w+)\"',                   "Column Attribute"),
            (r'MapFrom\(\"(\w+)\"\)',                  "MapFrom"),
            (r'ForMember\([^,]+,\s*\w+\s*=>\s*\w+\.(\w+)', "ForMember"),
            (r'\.(\w+)\s*=\s*\w+\[\"(\w+)\"\]',       "Assignment from indexer"),
            (r'\.(\w+)\s*=\s*(?:row|reader|record|line|csv)\.\w*[Ff]ield', "Reader assignment"),
            (r'(?:row|reader|record|line|csv)\[\"(\w+)\"\]\s*=',          "Write to reader key"),
        ]

        for cls in self.classes.values():
            if cls.name not in bridge_classes:
                continue

            cls_db_refs  = [r for r in self.db_references   if r.class_name == cls.name]
            db_tables    = sorted(set(r.table_name for r in cls_db_refs if r.table_name))
            if not db_tables:
                db_tables = ["(inferred)"]

            cls_file_refs = [r for r in self.file_io_references if r.class_name == cls.name]
            file_ops      = sorted(set(r.operation for r in cls_file_refs))

            for method in cls.methods:
                if not method.body:
                    continue

                # Skip methods with no file-related keywords
                if not any(kw in method.body.lower() for kw in
                           ["file", "stream", "reader", "csv", "xml", "feed",
                            "inbound", "row", "record", "line", "field", "column"]):
                    continue

                seen_fields: set = set()
                for pattern, mapping_type in FIELD_PATTERNS:
                    for m in re.finditer(pattern, method.body, re.IGNORECASE):
                        # Group(1) is the field name; group(2) for assignment pattern
                        groups = m.groups()
                        if mapping_type == "Assignment from indexer":
                            prop_name  = groups[0] if groups[0] else ""
                            field_name = groups[1] if len(groups) > 1 else groups[0]
                        else:
                            field_name = groups[0] if groups else ""
                            prop_name  = field_name

                        if not field_name or field_name in seen_fields:
                            continue
                        seen_fields.add(field_name)

                        start   = max(0, m.start() - 80)
                        end     = min(len(method.body), m.end() + 80)
                        context = " ".join(method.body[start:end].split())

                        for table in db_tables:
                            results.append({
                                "Class":        cls.name,
                                "Namespace":    cls.namespace,
                                "Method":       method.name,
                                "Feed Field":   field_name,
                                "DB Table":     table,
                                "DB Column":    prop_name if prop_name != field_name else field_name,
                                "Mapping Type": mapping_type,
                                "File Op":      ", ".join(file_ops),
                                "Context":      context[:150],
                            })

        # ── Pattern 3: ORM entity classes with [Table] / [Column] attributes ──
        ORM_TABLE_ATTR = re.compile(r'\[Table\(\"(\w+)\"', re.IGNORECASE)
        ORM_COL_ATTR   = re.compile(r'\[Column\(\"(\w+)\"', re.IGNORECASE)

        for cls in self.classes.values():
            # Look for [Table] attribute in class attributes list
            table_names_from_attr = [a for a in cls.attributes if a.lower() == "table"]
            if not table_names_from_attr:
                continue

            # Find table name from DB refs for this class
            db_tables = sorted(set(
                r.table_name for r in self.db_references
                if r.class_name == cls.name and r.table_name
            ))
            if not db_tables:
                db_tables = [cls.name]

            for prop in cls.properties:
                results.append({
                    "Class":        cls.name,
                    "Namespace":    cls.namespace,
                    "Method":       "(entity property)",
                    "Feed Field":   prop.name,
                    "DB Table":     db_tables[0] if db_tables else cls.name,
                    "DB Column":    prop.name,
                    "Mapping Type": "ORM Entity Property",
                    "File Op":      "Model",
                    "Context":      f"{prop.access} {prop.type} {prop.name}",
                })

        # ── Pattern 4: Fluent mapping files (EntityTypeConfiguration pattern) ─
        FLUENT_TABLE = re.compile(r'ToTable\(\"(\w+)\"', re.IGNORECASE)
        FLUENT_COL   = re.compile(r'HasColumnName\(\"(\w+)\"', re.IGNORECASE)
        FLUENT_PROP  = re.compile(r'Property\(p\s*=>\s*p\.(\w+)\)', re.IGNORECASE)

        for cls in self.classes.values():
            for method in cls.methods:
                if not method.body:
                    continue
                table_matches = FLUENT_TABLE.findall(method.body)
                if not table_matches:
                    continue
                col_matches  = FLUENT_COL.findall(method.body)
                prop_matches = FLUENT_PROP.findall(method.body)
                for table in table_matches:
                    for col in col_matches or prop_matches:
                        key = (cls.name, method.name, table, col)
                        if any(
                            r["Class"] == cls.name and r["DB Table"] == table
                            and r["DB Column"] == col for r in results
                        ):
                            continue
                        results.append({
                            "Class":        cls.name,
                            "Namespace":    cls.namespace,
                            "Method":       method.name,
                            "Feed Field":   col,
                            "DB Table":     table,
                            "DB Column":    col,
                            "Mapping Type": "Fluent API",
                            "File Op":      "Config",
                            "Context":      f"ToTable(\"{table}\") + HasColumnName(\"{col}\")",
                        })

        return results
