import graphviz
import re
from typing import List, Dict, Optional
from csharp_parser import CSharpClass, CSharpMethod, DatabaseReference, FileIOReference


COLORS = {
    "bg": "#FFFFFF",
    "surface": "#F6F8FA",
    "surface2": "#EAECEF",
    "border": "#C8D0DA",
    "accent_blue": "#0969DA",
    "accent_green": "#1A7F37",
    "accent_purple": "#6639BA",
    "accent_orange": "#BC4C00",
    "accent_red": "#CF222E",
    "accent_cyan": "#0A6976",
    "accent_yellow": "#9A6700",
    "text_primary": "#1F2328",
    "text_secondary": "#57606A",
    "interface_color": "#6639BA",
    "abstract_color": "#BC4C00",
    "class_color": "#0969DA",
    "struct_color": "#1A7F37",
    "db_color": "#9A6700",
    "sftp_color": "#CF222E",
    "feed_color": "#0A6976",
}


def _base_graph(name: str, direction: str = "TB") -> graphviz.Digraph:
    g = graphviz.Digraph(name=name)
    g.attr(
        rankdir=direction,
        bgcolor=COLORS["bg"],
        fontname="Helvetica Neue,Arial,sans-serif",
        fontcolor=COLORS["text_primary"],
        fontsize="12",
        pad="0.6",
        nodesep="0.5",
        ranksep="0.8",
        splines="ortho",
        concentrate="false",
    )
    g.attr("node",
        fontname="Helvetica Neue,Arial,sans-serif",
        fontsize="10",
        fontcolor=COLORS["text_primary"],
        margin="0.15,0.08",
    )
    g.attr("edge",
        fontname="Helvetica Neue,Arial,sans-serif",
        fontsize="9",
        fontcolor=COLORS["text_secondary"],
        color=COLORS["border"],
        penwidth="1.2",
        arrowsize="0.7",
    )
    return g


def _safe_id(name: str) -> str:
    return re.sub(r'[^a-zA-Z0-9_]', '_', name)


def generate_class_diagram(classes: List[CSharpClass], title: str = "Class Diagram") -> graphviz.Digraph:
    g = _base_graph(f"class_{_safe_id(title)}", direction="TB")

    g.attr(label=f"<<B>{title}</B>>", labelloc="t", labeljust="l",
           fontsize="14", fontcolor=COLORS["text_primary"])

    for cls in classes:
        cid = _safe_id(f"{cls.namespace}_{cls.name}")

        if cls.is_interface:
            header_bg = "#EDE9F8"
            header_color = COLORS["interface_color"]
            stereotype = "«interface»"
            border_color = COLORS["interface_color"]
        elif cls.is_abstract:
            header_bg = "#FFF1E5"
            header_color = COLORS["abstract_color"]
            stereotype = "«abstract»"
            border_color = COLORS["abstract_color"]
        else:
            header_bg = "#E8F3FF"
            header_color = COLORS["class_color"]
            stereotype = "«class»"
            border_color = COLORS["class_color"]

        props_rows = ""
        for p in cls.properties[:8]:
            icon = "⬤" if p.access == "public" else "◯"
            icon_color = COLORS["accent_green"] if p.access == "public" else COLORS["text_secondary"]
            props_rows += (
                f'<TR><TD ALIGN="LEFT" BGCOLOR="{COLORS["surface2"]}" '
                f'BORDER="0" CELLPADDING="3">'
                f'<FONT COLOR="{icon_color}">{icon} </FONT>'
                f'<FONT COLOR="{COLORS["text_secondary"]}">{_esc(p.type)} </FONT>'
                f'<FONT COLOR="{COLORS["text_primary"]}">{_esc(p.name)}</FONT>'
                f'</TD></TR>'
            )
        if len(cls.properties) > 8:
            props_rows += (
                f'<TR><TD ALIGN="LEFT" BGCOLOR="{COLORS["surface2"]}" BORDER="0" CELLPADDING="3">'
                f'<FONT COLOR="{COLORS["text_secondary"]}">  ... +{len(cls.properties) - 8} more</FONT>'
                f'</TD></TR>'
            )

        method_rows = ""
        for m in cls.methods[:6]:
            icon = "▶" if m.access == "public" else "▷"
            icon_color = COLORS["accent_blue"] if m.access == "public" else COLORS["text_secondary"]
            params_short = ", ".join(p.split()[-1] if " " in p else p for p in m.parameters[:3])
            if len(m.parameters) > 3:
                params_short += ", ..."
            method_rows += (
                f'<TR><TD ALIGN="LEFT" BGCOLOR="{COLORS["surface"]}" '
                f'BORDER="0" CELLPADDING="3">'
                f'<FONT COLOR="{icon_color}">{icon} </FONT>'
                f'<FONT COLOR="{COLORS["text_secondary"]}">{_esc(m.return_type)} </FONT>'
                f'<FONT COLOR="{COLORS["text_primary"]}">{_esc(m.name)}</FONT>'
                f'<FONT COLOR="{COLORS["text_secondary"]}">({_esc(params_short)})</FONT>'
                f'</TD></TR>'
            )
        if len(cls.methods) > 6:
            method_rows += (
                f'<TR><TD ALIGN="LEFT" BGCOLOR="{COLORS["surface"]}" BORDER="0" CELLPADDING="3">'
                f'<FONT COLOR="{COLORS["text_secondary"]}">  ... +{len(cls.methods) - 6} more</FONT>'
                f'</TD></TR>'
            )

        label = (
            f'<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="0" '
            f'BGCOLOR="{COLORS["surface"]}" COLOR="{border_color}" STYLE="ROUNDED">'
            # Header
            f'<TR><TD BGCOLOR="{header_bg}" ALIGN="CENTER" CELLPADDING="6">'
            f'<FONT COLOR="{header_color}" POINT-SIZE="8">{stereotype}</FONT><BR/>'
            f'<FONT COLOR="{header_color}" POINT-SIZE="12"><B>{_esc(cls.name)}</B></FONT>'
            f'</TD></TR>'
        )

        if props_rows:
            label += (
                f'<TR><TD BGCOLOR="{COLORS["border"]}" HEIGHT="1" CELLPADDING="0"></TD></TR>'
                + props_rows
            )

        if method_rows:
            label += (
                f'<TR><TD BGCOLOR="{COLORS["border"]}" HEIGHT="1" CELLPADDING="0"></TD></TR>'
                + method_rows
            )

        label += "</TABLE>>"

        g.node(cid, label=label, shape="none", margin="0")

    class_map = {cls.name: _safe_id(f"{cls.namespace}_{cls.name}") for cls in classes}
    drawn_edges = set()

    for cls in classes:
        cid = _safe_id(f"{cls.namespace}_{cls.name}")

        if cls.base_class and cls.base_class in class_map:
            edge = (cid, class_map[cls.base_class])
            if edge not in drawn_edges:
                g.edge(cid, class_map[cls.base_class],
                       arrowhead="empty", arrowsize="1.0",
                       color=COLORS["accent_orange"], penwidth="1.5",
                       label="extends", fontcolor=COLORS["accent_orange"])
                drawn_edges.add(edge)

        for iface in cls.interfaces:
            if iface in class_map:
                edge = (cid, class_map[iface])
                if edge not in drawn_edges:
                    g.edge(cid, class_map[iface],
                           arrowhead="empty", style="dashed",
                           color=COLORS["interface_color"], penwidth="1.2",
                           label="implements", fontcolor=COLORS["interface_color"])
                    drawn_edges.add(edge)

        for dep in cls.dependencies:
            if dep in class_map and dep != cls.name:
                edge = (cid, class_map[dep])
                if edge not in drawn_edges:
                    g.edge(cid, class_map[dep],
                           arrowhead="open", style="dashed",
                           color=COLORS["border"], penwidth="0.8")
                    drawn_edges.add(edge)

    return g


def generate_flow_diagram(cls: CSharpClass) -> graphviz.Digraph:
    g = _base_graph(f"flow_{_safe_id(cls.name)}", direction="TB")
    g.attr(label=f"<<B>Flow Diagram — {cls.name}</B>>",
           labelloc="t", labeljust="l",
           fontsize="14", fontcolor=COLORS["text_primary"])

    # Class entry node
    class_id = _safe_id(cls.name)
    g.node(class_id,
           label=f"<<B>{cls.name}</B>>",
           shape="box", style="filled,rounded",
           fillcolor="#E8F3FF", color=COLORS["accent_blue"],
           fontcolor=COLORS["accent_blue"], penwidth="2")

    for method in cls.methods:
        mid = _safe_id(f"{cls.name}_{method.name}")
        params_str = _esc(", ".join(
            p.split()[-1] if " " in p else p for p in method.parameters[:3]
        ))
        if len(method.parameters) > 3:
            params_str += ", ..."

        is_async = "async" in method.return_type.lower() or any(
            "await" in c.lower() for c in method.calls
        )
        bg = "#F0FFF4" if is_async else COLORS["surface2"]
        border = COLORS["accent_green"] if is_async else COLORS["accent_blue"]
        async_tag = " [async]" if is_async else ""

        g.node(mid,
               label=f'<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="2" CELLPADDING="4" BGCOLOR="{bg}">'
                     f'<TR><TD><FONT COLOR="{border}" POINT-SIZE="10"><B>{_esc(method.name)}{async_tag}</B></FONT></TD></TR>'
                     f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">({params_str})</FONT></TD></TR>'
                     f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">→ {_esc(method.return_type)}</FONT></TD></TR>'
                     f'</TABLE>>',
               shape="none", margin="0")
        g.edge(class_id, mid, color=COLORS["accent_blue"], penwidth="1.2", arrowsize="0.7")

        # Show internal calls
        unique_calls = list(dict.fromkeys(method.calls))
        for i, call in enumerate(unique_calls[:6]):
            call_id = _safe_id(f"{cls.name}_{method.name}_call_{call}_{i}")
            g.node(call_id,
                   label=f"<<FONT COLOR=\"{COLORS['text_secondary']}\" POINT-SIZE=\"9\">{_esc(call)}()</FONT>>",
                   shape="box", style="filled,rounded",
                   fillcolor=COLORS["surface"], color=COLORS["border"],
                   fontcolor=COLORS["text_secondary"], penwidth="0.8")
            g.edge(mid, call_id,
                   style="dashed", color=COLORS["border"],
                   arrowsize="0.6", penwidth="0.8")

    return g


def generate_architecture_diagram(classes: List[CSharpClass], title: str = "Architecture") -> graphviz.Digraph:
    g = _base_graph(f"arch_{_safe_id(title)}", direction="LR")
    g.attr(label=f"<<B>{title} — Architecture Overview</B>>",
           labelloc="t", labeljust="l",
           fontsize="14", fontcolor=COLORS["text_primary"])

    ns_map: Dict[str, List[CSharpClass]] = {}
    for cls in classes:
        ns_map.setdefault(cls.namespace, []).append(cls)

    ns_colors = [
        ("#E8F3FF", COLORS["accent_blue"]),
        ("#FFF1E5", COLORS["accent_orange"]),
        ("#F0FFF4", COLORS["accent_green"]),
        ("#EDE9F8", COLORS["interface_color"]),
        ("#FFF0F0", COLORS["accent_red"]),
        ("#E8FAFA", COLORS["accent_cyan"]),
    ]

    for i, (ns, ns_classes) in enumerate(ns_map.items()):
        bg, border = ns_colors[i % len(ns_colors)]
        sub_id = _safe_id(f"cluster_{ns}")
        with g.subgraph(name=f"cluster_{sub_id}") as sub:
            sub.attr(
                label=f"<<B>{_esc(ns)}</B>>",
                style="filled,rounded",
                color=border,
                fillcolor=bg,
                fontcolor=border,
                fontsize="11",
                penwidth="1.5",
                margin="12",
            )
            for cls in ns_classes:
                cid = _safe_id(f"{cls.namespace}_{cls.name}")
                if cls.is_interface:
                    shape, fill, color = "ellipse", "#EDE9F8", COLORS["interface_color"]
                elif cls.is_abstract:
                    shape, fill, color = "diamond", "#FFF1E5", COLORS["abstract_color"]
                else:
                    shape, fill, color = "box", COLORS["surface2"], border

                method_count = len(cls.methods)
                prop_count = len(cls.properties)
                sub.node(cid,
                         label=f'<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="1" CELLPADDING="3">'
                               f'<TR><TD><FONT COLOR="{color}" POINT-SIZE="11"><B>{_esc(cls.name)}</B></FONT></TD></TR>'
                               f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">'
                               f'{method_count} methods · {prop_count} props</FONT></TD></TR>'
                               f'</TABLE>>',
                         shape="none", margin="0")

    drawn = set()
    class_map = {cls.name: _safe_id(f"{cls.namespace}_{cls.name}") for cls in classes}
    for cls in classes:
        cid = _safe_id(f"{cls.namespace}_{cls.name}")
        if cls.base_class and cls.base_class in class_map:
            edge = (cid, class_map[cls.base_class])
            if edge not in drawn:
                g.edge(cid, class_map[cls.base_class],
                       arrowhead="empty", color=COLORS["accent_orange"],
                       penwidth="1.5", style="solid")
                drawn.add(edge)
        for dep in cls.dependencies:
            if dep in class_map and dep != cls.name:
                edge = (cid, class_map[dep])
                if edge not in drawn:
                    g.edge(cid, class_map[dep],
                           arrowhead="open", style="dashed",
                           color=COLORS["border"], penwidth="0.8")
                    drawn.add(edge)

    return g


def generate_sftp_feed_diagram(
    classes: List[CSharpClass],
    file_io_refs: List[FileIOReference],
    title: str = "SFTP / Feed File Flow"
) -> graphviz.Digraph:
    g = _base_graph(f"sftp_{_safe_id(title)}", direction="LR")
    g.attr(label=f"<<B>{title}</B>>",
           labelloc="t", labeljust="l",
           fontsize="14", fontcolor=COLORS["text_primary"])

    # External source node
    g.node("__sftp_server__",
           label='<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="3" CELLPADDING="6" '
                 f'BGCOLOR="#FFF0F0" COLOR="{COLORS["accent_red"]}" STYLE="ROUNDED">'
                 f'<TR><TD><FONT COLOR="{COLORS["accent_red"]}" POINT-SIZE="8">«external»</FONT></TD></TR>'
                 f'<TR><TD><FONT COLOR="{COLORS["accent_red"]}" POINT-SIZE="12"><B>SFTP Server</B></FONT></TD></TR>'
                 f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">Remote File Storage</FONT></TD></TR>'
                 f'</TABLE>>',
           shape="none", margin="0")

    g.node("__feed_files__",
           label='<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="3" CELLPADDING="6" '
                 f'BGCOLOR="#F0FFF4" COLOR="{COLORS["accent_green"]}" STYLE="ROUNDED">'
                 f'<TR><TD><FONT COLOR="{COLORS["accent_green"]}" POINT-SIZE="8">«files»</FONT></TD></TR>'
                 f'<TR><TD><FONT COLOR="{COLORS["accent_green"]}" POINT-SIZE="12"><B>Feed / Inbound Files</B></FONT></TD></TR>'
                 f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">.csv / .xml / .dat / .txt</FONT></TD></TR>'
                 f'</TABLE>>',
           shape="none", margin="0")

    g.edge("__sftp_server__", "__feed_files__",
           label="download", color=COLORS["accent_red"],
           penwidth="1.5", fontcolor=COLORS["accent_red"])

    involved_classes = set()
    for ref in file_io_refs:
        involved_classes.add(ref.class_name)

    for cls in classes:
        if cls.name not in involved_classes:
            continue
        cid = _safe_id(f"cls_{cls.name}")
        refs_for_cls = [r for r in file_io_refs if r.class_name == cls.name]
        ops = set(r.operation for r in refs_for_cls)
        ops_str = " / ".join(ops)

        g.node(cid,
               label=f'<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="3" CELLPADDING="6" '
                     f'BGCOLOR="{COLORS["surface2"]}" COLOR="{COLORS["accent_blue"]}" STYLE="ROUNDED">'
                     f'<TR><TD><FONT COLOR="{COLORS["accent_blue"]}" POINT-SIZE="8">«handler»</FONT></TD></TR>'
                     f'<TR><TD><FONT COLOR="{COLORS["accent_blue"]}" POINT-SIZE="12"><B>{_esc(cls.name)}</B></FONT></TD></TR>'
                     f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">{_esc(cls.namespace)}</FONT></TD></TR>'
                     f'<TR><TD><FONT COLOR="{COLORS["accent_cyan"]}" POINT-SIZE="8">ops: {_esc(ops_str)}</FONT></TD></TR>'
                     f'</TABLE>>',
               shape="none", margin="0")

        g.edge("__feed_files__", cid,
               label="reads", color=COLORS["accent_green"],
               penwidth="1.5", fontcolor=COLORS["accent_green"])

        for method in cls.methods:
            if not method.body:
                continue
            if not any(kw in method.body.lower() for kw in
                       ["file", "stream", "read", "sftp", "ftp", "feed", "csv", "xml", "download"]):
                continue
            mid = _safe_id(f"cls_{cls.name}_m_{method.name}")
            g.node(mid,
                   label=f'<<FONT COLOR="{COLORS["accent_blue"]}" POINT-SIZE="10"><B>{_esc(method.name)}()</B></FONT>>',
                   shape="box", style="filled,rounded",
                   fillcolor=COLORS["surface"], color=COLORS["border"],
                   penwidth="0.8")
            g.edge(cid, mid, color=COLORS["accent_blue"],
                   penwidth="1.0", arrowsize="0.7")

    if not involved_classes:
        g.node("__no_io__",
               label=f'<<FONT COLOR="{COLORS["text_secondary"]}">No SFTP/Feed file patterns detected</FONT>>',
               shape="box", style="filled", fillcolor=COLORS["surface2"],
               color=COLORS["border"])

    g.node("__processor__",
           label='<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="3" CELLPADDING="6" '
                 f'BGCOLOR="#E8FAFA" COLOR="{COLORS["accent_cyan"]}" STYLE="ROUNDED">'
                 f'<TR><TD><FONT COLOR="{COLORS["accent_cyan"]}" POINT-SIZE="12"><B>Data Processing</B></FONT></TD></TR>'
                 f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">Transform / Validate / Persist</FONT></TD></TR>'
                 f'</TABLE>>',
           shape="none", margin="0")

    g.node("__database__",
           label='<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="3" CELLPADDING="6" '
                 f'BGCOLOR="#FFFCE8" COLOR="{COLORS["db_color"]}" STYLE="ROUNDED">'
                 f'<TR><TD><FONT COLOR="{COLORS["db_color"]}" POINT-SIZE="8">«database»</FONT></TD></TR>'
                 f'<TR><TD><FONT COLOR="{COLORS["db_color"]}" POINT-SIZE="12"><B>Database</B></FONT></TD></TR>'
                 f'</TABLE>>',
           shape="none", margin="0")

    for cls_name in involved_classes:
        g.edge(_safe_id(f"cls_{cls_name}"), "__processor__",
               label="processes", color=COLORS["accent_cyan"],
               penwidth="1.2", fontcolor=COLORS["accent_cyan"])

    g.edge("__processor__", "__database__",
           label="persists", color=COLORS["db_color"],
           penwidth="1.5", fontcolor=COLORS["db_color"])

    return g


def generate_sftp_folder_flow_diagram(
    classes: List[CSharpClass],
    file_io_refs: List[FileIOReference],
    title: str = "SFTP Folder File Processing Flow"
) -> graphviz.Digraph:
    """Detailed step-by-step flow showing which modules primarily process SFTP folder files."""
    g = _base_graph(f"sftp_folder_{_safe_id(title)}", direction="TB")
    g.attr(label=f"<<B>{title}</B>>",
           labelloc="t", labeljust="l",
           fontsize="14", fontcolor=COLORS["text_primary"],
           splines="ortho", nodesep="0.6", ranksep="0.8")

    sftp_refs = [r for r in file_io_refs if r.is_sftp or any(
        kw in r.context.lower() for kw in ["getfiles", "directory", "listdirectory", "listfiles",
                                            "folder", "sftp", "ftp", "download", "pickup"]
    )]
    all_refs_to_use = sftp_refs if sftp_refs else file_io_refs

    ns_ref_count: Dict[str, int] = {}
    cls_ref_count: Dict[str, int] = {}
    cls_methods_involved: Dict[str, set] = {}

    for ref in all_refs_to_use:
        cls_ref_count[ref.class_name] = cls_ref_count.get(ref.class_name, 0) + 1
        if ref.method_name and ref.method_name != "Unknown":
            cls_methods_involved.setdefault(ref.class_name, set()).add(ref.method_name)

    cls_to_ns: Dict[str, str] = {cls.name: cls.namespace for cls in classes}
    for cls_name, count in cls_ref_count.items():
        ns = cls_to_ns.get(cls_name, "Unknown")
        ns_ref_count[ns] = ns_ref_count.get(ns, 0) + count

    ranked_ns = sorted(ns_ref_count.items(), key=lambda x: x[1], reverse=True)
    ranked_cls = sorted(cls_ref_count.items(), key=lambda x: x[1], reverse=True)
    primary_ns = ranked_ns[0][0] if ranked_ns else None
    primary_cls = ranked_cls[0][0] if ranked_cls else None

    g.node("__sftp_folder__",
           label='<<TABLE BORDER="2" CELLBORDER="0" CELLSPACING="4" CELLPADDING="8" '
                 f'BGCOLOR="#FFF0F0" COLOR="{COLORS["accent_red"]}" STYLE="ROUNDED">'
                 f'<TR><TD><FONT COLOR="{COLORS["accent_red"]}" POINT-SIZE="9">«source»</FONT></TD></TR>'
                 f'<TR><TD><FONT COLOR="{COLORS["accent_red"]}" POINT-SIZE="13"><B>SFTP Folder</B></FONT></TD></TR>'
                 f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">Remote directory / pickup</FONT></TD></TR>'
                 f'</TABLE>>',
           shape="none", margin="0")

    folder_ops = set()
    for ref in all_refs_to_use:
        if any(kw in ref.context.lower() for kw in ["getfiles", "listdirectory", "listfiles",
                                                      "enumeratefiles", "directory.get"]):
            folder_ops.add(ref.class_name)

    detect_label_detail = _esc(", ".join(sorted(folder_ops)[:3])) if folder_ops else "Automatic detection"
    g.node("__file_detect__",
           label='<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="3" CELLPADDING="6" '
                 f'BGCOLOR="#E8FAFA" COLOR="{COLORS["accent_cyan"]}" STYLE="ROUNDED">'
                 f'<TR><TD><FONT COLOR="{COLORS["accent_cyan"]}" POINT-SIZE="9">«step 1»</FONT></TD></TR>'
                 f'<TR><TD><FONT COLOR="{COLORS["accent_cyan"]}" POINT-SIZE="11"><B>Detect / List Files</B></FONT></TD></TR>'
                 f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">{detect_label_detail}</FONT></TD></TR>'
                 f'</TABLE>>',
           shape="none", margin="0")

    g.edge("__sftp_folder__", "__file_detect__",
           label="scan", color=COLORS["accent_red"], penwidth="2",
           fontcolor=COLORS["accent_red"])

    prev_nodes: List[str] = ["__file_detect__"]

    cls_map: Dict[str, CSharpClass] = {c.name: c for c in classes}
    step = 2
    for cls_name, ref_count in ranked_cls[:8]:
        cls_obj = cls_map.get(cls_name)
        ns = cls_to_ns.get(cls_name, "Unknown")
        is_primary = (cls_name == primary_cls)

        border_col = COLORS["accent_blue"] if is_primary else COLORS["border"]
        bg_col = "#E8F3FF" if is_primary else COLORS["surface2"]
        badge = "«primary handler»" if is_primary else "«handler»"
        border_w = "2" if is_primary else "1"

        cid = _safe_id(f"sftp_cls_{cls_name}")
        methods_shown = sorted(cls_methods_involved.get(cls_name, set()))[:4]
        method_str = " · ".join(f"{m}()" for m in methods_shown) if methods_shown else "–"

        g.node(cid,
               label=f'<<TABLE BORDER="{border_w}" CELLBORDER="0" CELLSPACING="3" CELLPADDING="6" '
                     f'BGCOLOR="{bg_col}" COLOR="{border_col}" STYLE="ROUNDED">'
                     f'<TR><TD ALIGN="LEFT"><FONT COLOR="{border_col}" POINT-SIZE="8">«step {step}» {badge}</FONT></TD></TR>'
                     f'<TR><TD ALIGN="LEFT"><FONT COLOR="{border_col}" POINT-SIZE="12"><B>{_esc(cls_name)}</B></FONT></TD></TR>'
                     f'<TR><TD ALIGN="LEFT"><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">{_esc(ns)}</FONT></TD></TR>'
                     f'<TR><TD ALIGN="LEFT"><FONT COLOR="{COLORS["accent_cyan"]}" POINT-SIZE="8">refs: {ref_count}</FONT></TD></TR>'
                     f'<TR><TD ALIGN="LEFT"><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">{_esc(method_str)}</FONT></TD></TR>'
                     f'</TABLE>>',
               shape="none", margin="0")

        for prev in prev_nodes:
            edge_col = COLORS["accent_blue"] if is_primary else COLORS["border"]
            edge_lbl = "download / read" if step == 2 else "passes to"
            g.edge(prev, cid, label=edge_lbl, color=edge_col,
                   penwidth="1.5" if is_primary else "1.0",
                   fontcolor=edge_col)

        if cls_obj and is_primary:
            file_methods = [
                m for m in cls_obj.methods
                if any(kw in (m.name + m.body).lower()
                       for kw in ["file", "stream", "read", "sftp", "ftp",
                                  "download", "process", "parse", "import", "load"])
            ]
            for fm in file_methods[:5]:
                fid = _safe_id(f"sftp_m_{cls_name}_{fm.name}")
                is_async = "async" in fm.return_type.lower()
                async_tag = " [async]" if is_async else ""
                m_bg = "#F0FFF4" if is_async else COLORS["surface"]
                m_col = COLORS["accent_green"] if is_async else COLORS["accent_blue"]
                g.node(fid,
                       label=f'<<FONT COLOR="{m_col}" POINT-SIZE="10"><B>{_esc(fm.name)}{async_tag}()</B></FONT>>',
                       shape="box", style="filled,rounded",
                       fillcolor=m_bg, color=m_col, penwidth="0.8")
                g.edge(cid, fid, color=m_col, arrowsize="0.7",
                       penwidth="0.8", style="dashed")

        prev_nodes = [cid]
        step += 1

    if not ranked_cls:
        g.node("__no_sftp__",
               label=f'<<FONT COLOR="{COLORS["text_secondary"]}">No SFTP/folder patterns detected</FONT>>',
               shape="box", style="filled", fillcolor=COLORS["surface2"],
               color=COLORS["border"])
        g.edge("__file_detect__", "__no_sftp__", color=COLORS["border"])
    else:
        g.node("__output__",
               label='<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="3" CELLPADDING="6" '
                     f'BGCOLOR="#FFFCE8" COLOR="{COLORS["db_color"]}" STYLE="ROUNDED">'
                     f'<TR><TD><FONT COLOR="{COLORS["db_color"]}" POINT-SIZE="9">«output»</FONT></TD></TR>'
                     f'<TR><TD><FONT COLOR="{COLORS["db_color"]}" POINT-SIZE="11"><B>Database / Downstream</B></FONT></TD></TR>'
                     f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">Persist / Forward / Archive</FONT></TD></TR>'
                     f'</TABLE>>',
               shape="none", margin="0")
        for prev in prev_nodes:
            g.edge(prev, "__output__", label="persists",
                   color=COLORS["db_color"], penwidth="1.5",
                   fontcolor=COLORS["db_color"])

    return g


def generate_field_usage_diagram(
    search_term: str,
    results: List[Dict],
    classes_map: Dict
) -> graphviz.Digraph:
    g = _base_graph(f"field_{_safe_id(search_term)}", direction="TB")
    g.attr(label=f'<<B>Usage Diagram — "{search_term}"</B>>',
           labelloc="t", labeljust="l",
           fontsize="14", fontcolor=COLORS["text_primary"])

    # Central field node
    field_id = _safe_id(f"field_{search_term}")
    g.node(field_id,
           label=f'<<TABLE BORDER="2" CELLBORDER="0" CELLSPACING="4" CELLPADDING="8" '
                 f'BGCOLOR="#FFFCE8" COLOR="{COLORS["accent_yellow"]}" STYLE="ROUNDED">'
                 f'<TR><TD><FONT COLOR="{COLORS["accent_yellow"]}" POINT-SIZE="8">«search target»</FONT></TD></TR>'
                 f'<TR><TD><FONT COLOR="{COLORS["accent_yellow"]}" POINT-SIZE="14"><B>{_esc(search_term)}</B></FONT></TD></TR>'
                 f'</TABLE>>',
           shape="none", margin="0")

    seen_classes = {}
    seen_files = {}
    for r in results:
        cls_name = r.get("class", "Unknown")
        file_path = r.get("file", "")
        rtype = r.get("type", "")
        short_file = file_path.replace("\\", "/").split("/")[-1] if file_path else "Unknown"

        if cls_name not in seen_classes:
            cid = _safe_id(f"usage_cls_{cls_name}")
            seen_classes[cls_name] = cid
            color = {
                "Database Reference": COLORS["db_color"],
                "Property": COLORS["accent_green"],
                "Method": COLORS["accent_blue"],
            }.get(rtype, COLORS["accent_blue"])

            g.node(cid,
                   label=f'<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="2" CELLPADDING="5" '
                         f'BGCOLOR="{COLORS["surface2"]}" COLOR="{color}" STYLE="ROUNDED">'
                         f'<TR><TD><FONT COLOR="{color}" POINT-SIZE="8">«{_esc(rtype)}»</FONT></TD></TR>'
                         f'<TR><TD><FONT COLOR="{COLORS["text_primary"]}" POINT-SIZE="11"><B>{_esc(cls_name)}</B></FONT></TD></TR>'
                         f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">{_esc(short_file)}</FONT></TD></TR>'
                         f'</TABLE>>',
                   shape="none", margin="0")

            g.edge(field_id, cid, color=color, penwidth="1.2",
                   label=rtype, fontcolor=color)

        if file_path and short_file not in seen_files:
            fid = _safe_id(f"usage_file_{short_file}")
            seen_files[short_file] = fid
            g.node(fid,
                   label=f'<<FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="9">{_esc(short_file)}</FONT>>',
                   shape="note", style="filled",
                   fillcolor=COLORS["surface"], color=COLORS["border"],
                   fontcolor=COLORS["text_secondary"])
            if cls_name in seen_classes:
                g.edge(seen_classes[cls_name], fid,
                       style="dashed", color=COLORS["border"],
                       arrowsize="0.5", penwidth="0.7")

    if not results:
        g.node("__no_results__",
               label=f'<<FONT COLOR="{COLORS["text_secondary"]}">No usages found for "{_esc(search_term)}"</FONT>>',
               shape="box", style="filled",
               fillcolor=COLORS["surface2"], color=COLORS["border"])
        g.edge(field_id, "__no_results__", style="dashed", color=COLORS["border"])

    return g


def generate_module_overview_diagram(
    all_classes: List[CSharpClass],
    title: str = "Module Overview"
) -> graphviz.Digraph:
    g = _base_graph(f"overview_{_safe_id(title)}", direction="TB")
    g.attr(label=f"<<B>{title}</B>>",
           labelloc="t", labeljust="l",
           fontsize="14", fontcolor=COLORS["text_primary"])

    ns_map: Dict[str, List[CSharpClass]] = {}
    for cls in all_classes:
        ns_map.setdefault(cls.namespace, []).append(cls)

    colors_list = [
        COLORS["accent_blue"], COLORS["accent_orange"], COLORS["accent_green"],
        COLORS["interface_color"], COLORS["accent_red"], COLORS["accent_cyan"],
        COLORS["accent_yellow"],
    ]

    ns_nodes = {}
    for i, (ns, ns_classes) in enumerate(ns_map.items()):
        color = colors_list[i % len(colors_list)]
        nid = _safe_id(f"ns_{ns}")
        ns_nodes[ns] = (nid, color)

        interfaces = sum(1 for c in ns_classes if c.is_interface)
        abstracts = sum(1 for c in ns_classes if c.is_abstract)
        concrete = len(ns_classes) - interfaces - abstracts

        g.node(nid,
               label=f'<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="3" CELLPADDING="8" '
                     f'BGCOLOR="{COLORS["surface2"]}" COLOR="{color}" STYLE="ROUNDED">'
                     f'<TR><TD><FONT COLOR="{color}" POINT-SIZE="8">«namespace»</FONT></TD></TR>'
                     f'<TR><TD><FONT COLOR="{COLORS["text_primary"]}" POINT-SIZE="12"><B>{_esc(ns)}</B></FONT></TD></TR>'
                     f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">'
                     f'{concrete} classes · {interfaces} interfaces · {abstracts} abstract'
                     f'</FONT></TD></TR>'
                     f'<TR><TD><FONT COLOR="{COLORS["text_secondary"]}" POINT-SIZE="8">'
                     f'{len(ns_classes)} total types'
                     f'</FONT></TD></TR>'
                     f'</TABLE>>',
               shape="none", margin="0")

    drawn = set()
    ns_of = {cls.name: cls.namespace for cls in all_classes}

    for cls in all_classes:
        if cls.base_class and cls.base_class in ns_of:
            src_ns = cls.namespace
            dst_ns = ns_of[cls.base_class]
            if src_ns != dst_ns and (src_ns, dst_ns) not in drawn:
                if src_ns in ns_nodes and dst_ns in ns_nodes:
                    g.edge(ns_nodes[src_ns][0], ns_nodes[dst_ns][0],
                           label="extends", style="solid",
                           color=COLORS["accent_orange"], penwidth="1.5",
                           fontcolor=COLORS["accent_orange"])
                    drawn.add((src_ns, dst_ns))

        for dep in cls.dependencies:
            dep_ns = ns_of.get(dep)
            if dep_ns and dep_ns != cls.namespace:
                edge = (cls.namespace, dep_ns)
                if edge not in drawn and cls.namespace in ns_nodes and dep_ns in ns_nodes:
                    g.edge(ns_nodes[cls.namespace][0], ns_nodes[dep_ns][0],
                           label="uses", style="dashed",
                           color=COLORS["border"], penwidth="0.8",
                           fontcolor=COLORS["text_secondary"])
                    drawn.add(edge)

    return g


def _esc(text: str) -> str:
    if not text:
        return ""
    text = str(text)[:60]
    return (text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;"))


# ── Export helpers ──────────────────────────────────────────────────────────

def render_to_png(graph: graphviz.Digraph) -> bytes:
    """Render a Graphviz diagram to PNG bytes."""
    return graph.pipe(format="png")


def render_to_svg(graph: graphviz.Digraph) -> bytes:
    """Render a Graphviz diagram to SVG bytes."""
    return graph.pipe(format="svg")


def render_to_dot(graph: graphviz.Digraph) -> str:
    """Return the DOT source string."""
    return graph.source
