# C# Repository Analyser

A Python Streamlit application that scans a C# repository and generates professional diagrams including class diagrams, flow diagrams, architecture diagrams, SFTP/feed file flow, and field/table usage tracing.

---

## Requirements

| Requirement | Version |
|-------------|---------|
| Python | 3.10 or 3.11 (recommended) |
| Graphviz (system) | 2.40+ |
| pip | Latest |

---

## Step 1 — Install Graphviz (System Package)

Graphviz must be installed at the OS level before the Python packages.

**Windows:**
1. Download the installer from https://graphviz.org/download/
2. Run the `.exe` installer
3. During install, tick **"Add Graphviz to the system PATH for all users"**
4. Restart your terminal after installation
5. Verify: open a new terminal and run `dot -V`

**macOS:**
```bash
brew install graphviz
```

**Ubuntu / Debian Linux:**
```bash
sudo apt-get update && sudo apt-get install -y graphviz
```

**Fedora / RHEL / CentOS:**
```bash
sudo dnf install graphviz
```

---

## Step 2 — Create a Python Virtual Environment (Recommended)

```bash
# Navigate to the app folder
cd csharp-analyser

# Create virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate
# macOS / Linux:
source venv/bin/activate
```

---

## Step 3 — Install Python Dependencies

```bash
pip install -r requirements.txt
```

---

## Step 4 — Run the Application

```bash
streamlit run app.py
```

The app will open automatically in your browser at **http://localhost:8501**

---

## How to Use

1. **Upload your C# repository** — Click "Browse files" in the sidebar and upload a `.zip` file of your C# project. All `.cs` files inside will be scanned automatically.

2. **Choose a scope** — Select "All modules" to analyse the entire repo, or pick a specific namespace from the dropdown.

3. **Explore the tabs:**

| Tab | What it shows |
|-----|---------------|
| 🗺 Overview | Namespace-level map with type counts and cross-module relationships |
| 🏛 Class Diagram | UML-style classes with properties, methods, inheritance, interfaces |
| 🔄 Flow Diagram | Per-class method call chains with async detection |
| 🏗 Architecture | Namespace clusters with dependency arrows across modules |
| 📡 SFTP / Feed | Data flow from SFTP → feed files → handler classes → database |
| 🔎 Field & Table Search | Trace any field, table, column, or method name across the codebase |

4. **Export diagrams** — Each diagram has three export buttons beneath it:
   - **PNG** — high-resolution image (for documents, Confluence, Word)
   - **SVG** — scalable vector graphic (zoomable, for presentations)
   - **DOT** — Graphviz source file (editable in any Graphviz tool such as https://dreampuf.github.io/GraphvizOnline/)

---

## Project Structure

```
csharp-analyser/
├── app.py                  # Main Streamlit application
├── csharp_parser.py        # C# source code parser (regex-based)
├── diagram_generator.py    # Professional Graphviz diagram builder
├── requirements.txt        # Python dependencies
├── .streamlit/
│   └── config.toml         # Streamlit server configuration
└── README.md               # This file
```

---

## Troubleshooting

**"ExecutableNotFound: failed to execute 'dot'" error**
- Graphviz is not on your PATH. Re-run the system install in Step 1 and open a new terminal.
- On Windows, ensure you ticked "Add to PATH" during the Graphviz installer.

**Blank / empty diagrams**
- The ZIP may not contain `.cs` files at the expected paths. Make sure your ZIP contains the source `.cs` files (not just project files).

**Port already in use**
```bash
streamlit run app.py --server.port 8502
```

**Slow on large repos**
- Use the "Select module" option in the sidebar to scope the analysis to a single namespace. This significantly reduces diagram complexity.

---

## Supported C# Patterns

- `class`, `interface`, `abstract class`, `struct`, `record`
- Inheritance (`extends`) and interface implementation
- Properties with access modifiers
- Methods with parameters and return types
- EF Core `DbSet<T>`, `FromSqlRaw`, `[Table]`, `[Column]` attributes
- Raw SQL strings (`SELECT ... FROM`, `INSERT INTO`, `UPDATE ... SET`)
- SFTP clients: `SftpClient`, `WinSCP`, `Renci.SshNet`
- FTP: `FtpClient`, `FtpWebRequest`
- File I/O: `File.ReadAll`, `StreamReader`, `FileStream`, `Directory.GetFiles`
- Feed / inbound file keywords: `feed`, `inbound`, `incoming`, `.csv`, `.xml`, `.dat`
