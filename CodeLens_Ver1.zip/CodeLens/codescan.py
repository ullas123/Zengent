import os
import re
import json
from typing import Dict, List, Set
from pathlib import Path
import logging
from dataclasses import dataclass
from datetime import datetime
import pandas as pd
import math

@dataclass
class IntegrationPattern:
    pattern_type: str
    file_path: str
    line_number: int
    code_snippet: str
    data_fields: Set[str]

@dataclass
class DemographicData:
    field_name: str
    data_type: str
    occurrences: List[Dict]

class CodeAnalyzer:
    def __init__(self, repo_path: str, app_name: str):
        self.repo_path = Path(repo_path)
        self.app_name = app_name
        self.setup_logging()

        self.demographic_patterns = {
            'id': r'\b(customerId|cm_15|gov_ids?|government_id)\b',
            'name': r'\b(embossed_name|embossed_company_name|primary_name|secondary_name|legal_name|dba_name|double_byte_name|first_name|last_name|full_name|name|amount)\b',
            'address': r'\b(home_address|business_address|alternate_address|temporary_address|other_address|additional_addresses|address|street|city|state|zip|postal_code)\b',
            'phone': r'\b(home_phone|alternate_home_phone|business_phone|alternate_business_phone|mobile_phone|alternate_mobile_phone|attorney_phone|fax|ani_phone|other_phone|additional_phone|phone|contact)\b',
            'email': r'\b(servicing_email|estatement_email|business_email|other_email_address|email)\b',
            'identity': r'\b(ssn|social_security|tax_id|passport|gov_ids?|government_id)\b',
            'demographics': r'\b(gender|dob|date_of_birth|age|nationality|ethnicity|preference_language_cd|member_since_date)\b'
        }

        self.integration_patterns = {
            'rest_api': {
                'http_methods': r'\b(get|post|put|delete|patch)\b.*\b(api|endpoint)\b',
                'url_patterns': r'https?://[^\s<>"]+|www\.[^\s<>"]+',
                'api_endpoints': r'@RequestMapping|@GetMapping|@PostMapping|@PutMapping|@DeleteMapping'
            },
            'soap_services': {
                'soap_components': r'\b(soap|wsdl|xml)\b',
                'wsdl': r'wsdl|WSDL|\.wsdl|getWSDL|WebService[Client]?',
                'soap_operations': r'SOAPMessage|SOAPEnvelope|SOAPBody|SOAPHeader|SoapClient|SoapBinding',
                'xml_namespaces': r'xmlns[:=]|namespace|schemaLocation',
                'soap_annotations': r'@WebService|@WebMethod|@SOAPBinding|@WebResult|@WebParam',
                'soap_endpoints': r'endpoint[_\s]?url|service[_\s]?url|wsdl[_\s]?url'
            },
            'database': {
                'sql_operations': r'\b(select|insert|update|delete)\s+from|into\b',
                'db_connections': r'jdbc:|connection[_\s]?string|database[_\s]?url'
            },
            'messaging': {
                'kafka': r'kafka|producer|consumer|topic',
                'rabbitmq': r'rabbitmq|amqp',
                'jms': r'jms|queue|topic'
            },
            'file': {
                'file_operations': r'\b(csv|excel|xlsx|json|properties).*(read|write|load|save)\b'
            }
        }

        self.supported_extensions = {
            '.py': 'Python',
            '.java': 'Java',
            '.js': 'JavaScript',
            '.ts': 'TypeScript',
            '.cs': 'C#',
            '.php': 'PHP',
            '.rb': 'Ruby',
            '.xsd': 'XSD'
        }

    def setup_logging(self):
        log_dir = os.path.dirname(os.path.abspath(__file__))
        log_file = os.path.join(log_dir, 'code_analysis.log')
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def scan_repository(self) -> Dict:
        results = {
            'metadata': {
                'application_name': self.app_name,
                'scan_timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'repository_path': str(self.repo_path)
            },
            'demographic_data': {},
            'integration_patterns': [],
            'summary': {
                'files_analyzed': 0,
                'unique_demographic_fields': set(),
                'demographic_fields_found': 0,
                'integration_patterns_found': 0,
                'file_details': []
            }
        }

        try:
            for file_path in self.get_code_files():
                self.logger.info(f"Analyzing file: {file_path}")
                file_results = self.analyze_file(file_path)
                self.update_results(results, file_results, file_path)
                results['summary']['files_analyzed'] += 1

            self.generate_report(results)
            return results

        except Exception as e:
            self.logger.error(f"Error during repository scan: {str(e)}")
            raise

    def get_code_files(self) -> List[Path]:
        code_files = []
        for root, _, files in os.walk(self.repo_path):
            for file in files:
                file_path = Path(root) / file
                if file_path.suffix in self.supported_extensions:
                    code_files.append(file_path)
        return code_files

    def analyze_file(self, file_path: Path) -> Dict:
        results = {
            'demographic_data': {},
            'integration_patterns': []
        }

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.readlines()

            for line_num, line in enumerate(content, 1):
                for data_type, pattern in self.demographic_patterns.items():
                    matches = re.finditer(pattern, line, re.IGNORECASE)
                    for match in matches:
                        field_name = match.group(0)
                        if str(file_path) not in results['demographic_data']:
                            results['demographic_data'][str(file_path)] = {}
                        if field_name not in results['demographic_data'][str(file_path)]:
                            results['demographic_data'][str(file_path)][field_name] = {
                                'data_type': data_type,
                                'occurrences': []
                            }
                        results['demographic_data'][str(file_path)][field_name]['occurrences'].append({
                            'line_number': line_num,
                            'code_snippet': line.strip()
                        })

                for pattern_category, sub_patterns in self.integration_patterns.items():
                    for sub_type, pattern in sub_patterns.items():
                        if re.search(pattern, line, re.IGNORECASE):
                            results['integration_patterns'].append({
                                'pattern_type': pattern_category,
                                'sub_type': sub_type,
                                'file_path': str(file_path),
                                'line_number': line_num,
                                'code_snippet': line.strip()
                            })

        except Exception as e:
            self.logger.error(f"Error analyzing file {file_path}: {str(e)}")

        return results

    def update_results(self, main_results: Dict, file_results: Dict, file_path: Path):
        demographic_fields_count = 0
        for file, fields in file_results['demographic_data'].items():
            if file not in main_results['demographic_data']:
                main_results['demographic_data'][file] = fields
            else:
                for field_name, data in fields.items():
                    if field_name not in main_results['demographic_data'][file]:
                        main_results['demographic_data'][file][field_name] = data
                    else:
                        main_results['demographic_data'][file][field_name]['occurrences'].extend(data['occurrences'])
            demographic_fields_count += sum(len(data['occurrences']) for data in fields.values())
            main_results['summary']['unique_demographic_fields'].update(fields.keys())

        integration_patterns_count = len(file_results['integration_patterns'])
        main_results['integration_patterns'].extend(file_results['integration_patterns'])

        main_results['summary']['demographic_fields_found'] = sum(
            sum(len(data['occurrences']) for data in fields.values())
            for fields in main_results['demographic_data'].values()
        )
        main_results['summary']['integration_patterns_found'] = len(main_results['integration_patterns'])

        main_results['summary']['file_details'].append({
            'file_path': str(file_path),
            'demographic_fields_found': demographic_fields_count,
            'integration_patterns_found': integration_patterns_count
        })

    def analyze_excel_demographic_data(self, excel_file_path: str) -> Dict:
        results = {
            'metadata': {
                'application_name': self.app_name,
                'scan_timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'excel_file': excel_file_path
            },
            'demographic_data': {},
            'summary': {
                'total_records': 0,
                'demographic_fields_found': 0,
                'exported_files': []
            }
        }

        demographic_keywords = [
            'embossed name', 'embossed company name', 'primary name', 'secondary name',
            'legal name', 'dba name', 'double byte name', 'gender', 'dob', 'gov ids',
            'home address', 'business address', 'alternate address', 'temporary address',
            'other address', 'additional addresses', 'home phone', 'alternate home phone',
            'business phone', 'alternate business phone', 'mobile phone', 'alternate mobile phone',
            'attorney phone', 'fax', 'ani phone', 'other phone', 'additional phone',
            'servicing email', 'estatement email', 'business email', 'other email address',
            'preference language cd', 'member since date', 'name', 'address', 'phone', 'email'
        ]

        try:
            df = pd.read_excel(excel_file_path)
            results['summary']['total_records'] = len(df)

            attr_desc_col = None
            for col in df.columns:
                if 'attr_description' in col.lower():
                    attr_desc_col = col
                    break

            if not attr_desc_col:
                for col in df.columns:
                    if 'description' in col.lower():
                        attr_desc_col = col
                        break

            if not attr_desc_col:
                raise ValueError("No 'attr_description' or 'description' column found in the Excel file")

            demographic_data = []
            for idx, row in df.iterrows():
                if pd.notna(row[attr_desc_col]):
                    description = str(row[attr_desc_col]).lower()
                    if any(keyword in description for keyword in demographic_keywords):
                        record = {}
                        for col in df.columns:
                            if pd.notna(row[col]):
                                record[col] = row[col]
                        demographic_data.append(record)

            results['demographic_data'] = demographic_data
            results['summary']['demographic_fields_found'] = len(demographic_data)

            if demographic_data:
                self.export_demographic_to_files(demographic_data, 20)
                results['summary']['exported_files'] = [f'{self.app_name}_demographic_data_{i+1}.xlsx' for i in range(20)]

            return results

        except Exception as e:
            self.logger.error(f"Error analyzing Excel file: {str(e)}")
            raise

    def export_demographic_to_files(self, data: List[Dict], num_files: int = 20):
        if not data:
            return

        records_per_file = math.ceil(len(data) / num_files)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_dir = os.path.dirname(os.path.abspath(__file__))

        for i in range(num_files):
            start_idx = i * records_per_file
            end_idx = min((i + 1) * records_per_file, len(data))

            if start_idx < len(data):
                chunk_data = data[start_idx:end_idx]
                df_chunk = pd.DataFrame(chunk_data)

                filename = os.path.join(output_dir, f'{self.app_name}_demographic_data_{i+1}_{timestamp}.xlsx')
                df_chunk.to_excel(filename, index=False)
                self.logger.info(f"Exported demographic data to: {filename}")

    def generate_report(self, results: Dict):
        results['summary']['unique_demographic_fields'] = list(results['summary']['unique_demographic_fields'])

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_dir = os.path.dirname(os.path.abspath(__file__))
        html_report = os.path.join(output_dir, f'{self.app_name}_CodeLens_{timestamp}.html')
        self.generate_html_report(results, html_report)
        self.logger.info(f"Analysis report generated: {html_report}")

    def generate_html_report(self, results: Dict, filename: str):
        import json as _json
        from collections import Counter as _Counter
        self.results = results
        unique_fields = list(results['summary']['unique_demographic_fields'])

        # ── Compute chart data ─────────────────────────────────────
        field_frequencies: Dict = {}
        field_types: Dict = {}
        type_counter: Dict = {}
        for file_data in results['demographic_data'].values():
            for fname, data in file_data.items():
                field_frequencies[fname] = field_frequencies.get(fname, 0) + len(data['occurrences'])
                field_types[fname] = data['data_type']
        for ft in field_types.values():
            type_counter[ft] = type_counter.get(ft, 0) + 1

        sorted_fields = sorted(field_frequencies.items(), key=lambda x: x[1], reverse=True)[:15]
        field_labels  = _json.dumps([f[0] for f in sorted_fields])
        field_values  = _json.dumps([f[1] for f in sorted_fields])
        type_labels   = _json.dumps(list(type_counter.keys()))
        type_values   = _json.dumps(list(type_counter.values()))

        file_exts   = _Counter(Path(f['file_path']).suffix for f in results['summary']['file_details'])
        lang_labels = _json.dumps(list(file_exts.keys()))
        lang_values = _json.dumps(list(file_exts.values()))

        pattern_ctr = _Counter(p['pattern_type'] for p in results['integration_patterns'])
        pat_labels  = _json.dumps(list(pattern_ctr.keys()))
        pat_values  = _json.dumps(list(pattern_ctr.values()))

        file_names_js = _json.dumps([os.path.basename(d['file_path']) for d in results['summary']['file_details']])
        demo_per_file = _json.dumps([d['demographic_fields_found']   for d in results['summary']['file_details']])
        intg_per_file = _json.dumps([d['integration_patterns_found'] for d in results['summary']['file_details']])

        total_files = results['summary']['files_analyzed']
        files_with_d = len([f for f in results['summary']['file_details'] if f['demographic_fields_found'] > 0])

        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <title>{self.app_name} - Code Analysis Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #fff; color: #222; }}
        h1 {{ color: #0066cc; }}
        h2 {{ color: #0055aa; border-bottom: 2px solid #cce0ff; padding-bottom: 6px; margin-top: 30px; }}
        h3 {{ color: #333; margin-top: 18px; }}
        .section {{ margin-bottom: 30px; }}
        .pattern {{ margin-bottom: 20px; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }}
        .code {{ background-color: #f5f5f5; padding: 10px; font-family: monospace; font-size: 0.85rem;
                 border-left: 4px solid #0066cc; margin: 6px 0; }}
        table {{ width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 0.88rem; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #0066cc; color: white; }}
        tr:nth-child(even) td {{ background-color: #f7faff; }}
        .metadata {{ background-color: #e9ecef; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
        /* ── Quick Dashboard ── */
        .dashboard {{ background: #f0f6ff; border: 1px solid #cce0ff; border-radius: 8px;
                      padding: 20px; margin-bottom: 30px; }}
        .dashboard h2 {{ color: #0066cc; border-color: #0066cc; }}
        .kpi-row {{ display: flex; gap: 14px; flex-wrap: wrap; margin-bottom: 20px; }}
        .kpi {{ background: white; border-top: 4px solid #0066cc; border-radius: 8px;
                padding: 14px 18px; min-width: 130px; flex: 1; text-align: center;
                box-shadow: 0 2px 6px rgba(0,0,0,.08); }}
        .kpi .val {{ font-size: 1.6rem; font-weight: 700; color: #0066cc; }}
        .kpi .lbl {{ font-size: 0.75rem; color: #555; margin-top: 4px; }}
        .chart-row {{ display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 20px; }}
        .chart-box {{ flex: 1; min-width: 280px; background: white; border-radius: 8px;
                      padding: 14px; box-shadow: 0 1px 4px rgba(0,0,0,.07); }}
        .chart-full {{ background: white; border-radius: 8px; padding: 14px;
                       box-shadow: 0 1px 4px rgba(0,0,0,.07); margin-bottom: 16px; }}
        canvas {{ max-height: 300px; }}
        canvas.tall {{ max-height: 380px; }}
    </style>
</head>
<body>
    <h1>{self.app_name} - Code Analysis Report</h1>
    <div class="metadata">
        <p><strong>Application Name:</strong> {results['metadata']['application_name']}</p>
        <p><strong>Generated:</strong> {results['metadata']['scan_timestamp']}</p>
        <p><strong>Repository Path:</strong> {results['metadata']['repository_path']}</p>
    </div>

    <!-- ═══════════════ QUICK DASHBOARD ═══════════════ -->
    <div class="dashboard">
        <h2>📊 Quick Analysis Dashboard</h2>

        <!-- KPI strip -->
        <div class="kpi-row">
            <div class="kpi"><div class="val">{total_files}</div><div class="lbl">Files Analyzed</div></div>
            <div class="kpi"><div class="val">{results['summary']['demographic_fields_found']}</div><div class="lbl">Demographic Hits</div></div>
            <div class="kpi"><div class="val">{len(unique_fields)}</div><div class="lbl">Unique Fields</div></div>
            <div class="kpi"><div class="val">{results['summary']['integration_patterns_found']}</div><div class="lbl">Integration Patterns</div></div>
            <div class="kpi"><div class="val">{files_with_d}/{total_files}</div><div class="lbl">Files with Demographics</div></div>
        </div>

        <!-- Row 1: Pie + Donut -->
        <div class="chart-row">
            <div class="chart-box"><canvas id="pieChart"></canvas></div>
            <div class="chart-box"><canvas id="donutChart"></canvas></div>
        </div>

        <!-- Row 2: Horizontal bar — field frequencies -->
        <div class="chart-full"><canvas id="hbarChart" class="tall"></canvas></div>

        <!-- Row 3: Language bar + Integration line -->
        <div class="chart-row">
            <div class="chart-box"><canvas id="langChart"></canvas></div>
            <div class="chart-box"><canvas id="lineChart"></canvas></div>
        </div>

        <!-- Row 4: Grouped bar — per file -->
        <div class="chart-full"><canvas id="corrChart"></canvas></div>
    </div>
    <!-- ═══════════════ END DASHBOARD ═══════════════ -->

    <div class="section">
        <h2>Summary</h2>
        <p>Files Analyzed: {results['summary']['files_analyzed']}</p>
        <p>Unique Demographic Fields: {len(unique_fields)} [{', '.join(unique_fields)}]</p>
        <p>Demographic Fields Occurrences Found: {results['summary']['demographic_fields_found']}</p>
        <p>Integration Patterns Found: {results['summary']['integration_patterns_found']}</p>

        {self._generate_field_frequency_html(results)}
        {self._generate_demographic_summary_html(results['summary']['file_details'])}
        {self._generate_integration_summary_html(results['summary']['file_details'])}
    </div>

    <div class="section">
        <h2>Demographic Data Fields by File</h2>
        {self._generate_demographic_html(results['demographic_data'])}
    </div>

    <div class="section">
        <h2>Integration Patterns</h2>
        {self._generate_integration_html(results['integration_patterns'])}
    </div>

<script>
const p12 = ["#8dd3c7","#ffffb3","#bebada","#fb8072","#80b1d3","#fdb462","#b3de69","#fccde5","#d9d9d9","#bc80bd","#ccebc5","#ffed6f"];
const p6  = ["#0066cc","#90EE90","#ffb347","#ff6b6b","#a78bfa","#34d399"];

new Chart(document.getElementById('pieChart'), {{
  type: 'pie',
  data: {{ labels: {field_labels}, datasets: [{{ data: {field_values}, backgroundColor: p12 }}] }},
  options: {{ plugins: {{ title: {{ display:true, text:'Demographic Fields Distribution' }}, legend:{{position:'right'}} }} }}
}});

new Chart(document.getElementById('donutChart'), {{
  type: 'doughnut',
  data: {{ labels: {type_labels}, datasets: [{{ data: {type_values}, backgroundColor: p6 }}] }},
  options: {{ plugins: {{ title: {{ display:true, text:'Fields by Data Type Category' }}, legend:{{position:'right'}} }} }}
}});

new Chart(document.getElementById('hbarChart'), {{
  type: 'bar',
  data: {{ labels: {field_labels}, datasets: [{{ label:'Occurrences', data:{field_values}, backgroundColor:'#0066cc' }}] }},
  options: {{
    indexAxis:'y',
    plugins: {{ title:{{display:true,text:'Top Demographic Fields by Frequency'}}, legend:{{display:false}} }},
    scales: {{ x:{{beginAtZero:true}}, y:{{ticks:{{font:{{size:11}}}}}} }}
  }}
}});

new Chart(document.getElementById('langChart'), {{
  type: 'bar',
  data: {{ labels:{lang_labels}, datasets:[{{ label:'Files', data:{lang_values}, backgroundColor:p12 }}] }},
  options: {{
    plugins: {{ title:{{display:true,text:'Files by Language'}}, legend:{{display:false}} }},
    scales: {{ y:{{beginAtZero:true}} }}
  }}
}});

new Chart(document.getElementById('lineChart'), {{
  type: 'line',
  data: {{ labels:{pat_labels}, datasets:[{{ label:'Count', data:{pat_values}, borderColor:'#0066cc',
           backgroundColor:'rgba(0,102,204,0.12)', borderWidth:2, pointRadius:6, fill:true, tension:0.3 }}] }},
  options: {{
    plugins: {{ title:{{display:true,text:'Integration Pattern Types'}}, legend:{{display:false}} }},
    scales: {{ y:{{beginAtZero:true}} }}
  }}
}});

new Chart(document.getElementById('corrChart'), {{
  type: 'bar',
  data: {{
    labels: {file_names_js},
    datasets: [
      {{ label:'Demographic Fields',   data:{demo_per_file}, backgroundColor:'#0066cc' }},
      {{ label:'Integration Patterns', data:{intg_per_file}, backgroundColor:'#90EE90' }}
    ]
  }},
  options: {{
    plugins: {{ title:{{display:true,text:'Fields & Patterns per File'}}, legend:{{position:'top'}} }},
    scales: {{ y:{{beginAtZero:true}} }}
  }}
}});
</script>
</body>
</html>"""

        with open(filename, 'w', encoding='utf-8') as f:
            f.write(html_content)

    def _generate_demographic_summary_html(self, file_details: List[Dict]) -> str:
        demographic_files = [f for f in file_details if f['demographic_fields_found'] > 0]

        if not demographic_files:
            return ""

        html = """
        <h3>Demographic Fields Summary</h3>
        <table>
            <tr>
                <th>#</th>
                <th>File Analyzed</th>
                <th>Demographic Fields Occurrences</th>
                <th>Fields</th>
            </tr>
        """

        for index, file_detail in enumerate(demographic_files, 1):
            file_path = file_detail['file_path']
            unique_fields = []
            if file_path in self.results['demographic_data']:
                unique_fields = list(self.results['demographic_data'][file_path].keys())

            html += f"""
            <tr>
                <td>{index}</td>
                <td>{file_path}</td>
                <td>{file_detail['demographic_fields_found']}</td>
                <td>{', '.join(unique_fields)}</td>
            </tr>
            """
        return html + "</table>"

    def _generate_integration_summary_html(self, file_details: List[Dict]) -> str:
        integration_files = [f for f in file_details if f['integration_patterns_found'] > 0]

        if not integration_files:
            return ""

        html = """
        <h3>Integration Patterns Summary</h3>
        <table>
            <tr>
                <th>#</th>
                <th>File Name</th>
                <th>Integration Patterns Found</th>
                <th>Patterns Found Details</th>
            </tr>
        """

        for index, file_detail in enumerate(integration_files, 1):
            file_path = file_detail['file_path']
            pattern_details = set()
            for pattern in self.results['integration_patterns']:
                if pattern['file_path'] == file_path:
                    pattern_details.add(f"{pattern['pattern_type']}: {pattern['sub_type']}")

            html += f"""
            <tr>
                <td>{index}</td>
                <td>{file_detail['file_path']}</td>
                <td>{file_detail['integration_patterns_found']}</td>
                <td>{', '.join(pattern_details)}</td>
            </tr>
            """
        return html + "</table>"

    def _generate_demographic_html(self, demographic_data: Dict) -> str:
        html = ""
        for file_path, fields in demographic_data.items():
            html += f"<h3>File: {file_path}</h3>"
            for field_name, data in fields.items():
                html += f"""
                <div class="pattern">
                    <h4>Field: {field_name} (Type: {data['data_type']})</h4>
                    """
                for occurrence in data['occurrences']:
                    html += f"""
                    <div class="code">
                        <p>Line {occurrence['line_number']}: {occurrence['code_snippet']}</p>
                    </div>
                    """
                html += "</div>"
        return html

    def _generate_integration_html(self, integration_patterns: List) -> str:
        html = ""
        for pattern in integration_patterns:
            html += f"""
            <div class="pattern">
                <h3>Pattern Type: {pattern['pattern_type']}</h3>
                <p>Sub Type: {pattern['sub_type']}</p>
                <p>File: {pattern['file_path']}</p>
                <p>Line: {pattern['line_number']}</p>
                <div class="code">
                    <p>{pattern['code_snippet']}</p>
                </div>
            </div>
            """
        return html

    def _generate_field_frequency_html(self, results: Dict) -> str:
        field_frequencies = {}
        for file_data in results['demographic_data'].values():
            for field_name, data in file_data.items():
                if field_name not in field_frequencies:
                    field_frequencies[field_name] = {
                        'count': len(data['occurrences']),
                        'type': data['data_type']
                    }
                else:
                    field_frequencies[field_name]['count'] += len(data['occurrences'])

        html = """
        <div class="section">
            <h3>Field Frequency Analysis</h3>
            <p>Below table shows how many times each demographic field appears across all analyzed files:</p>
            <table>
                <tr>
                    <th style="width: 5%;">#</th>
                    <th style="width: 35%;">Field Name</th>
                    <th style="width: 30%;">Field Type</th>
                    <th style="width: 30%;">Total Occurrences</th>
                </tr>
        """

        for idx, (field_name, data) in enumerate(sorted(field_frequencies.items(), key=lambda x: x[1]['count'], reverse=True), 1):
            html += f"""
                <tr>
                    <td>{idx}</td>
                    <td>{field_name}</td>
                    <td>{data['type']}</td>
                    <td>{data['count']}</td>
                </tr>
            """

        html += """
            </table>
        </div>
        <br>
        """
        return html
