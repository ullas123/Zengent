import streamlit as st
import tempfile
import os
import io
from pathlib import Path
import time
from datetime import datetime
from codescan import CodeAnalyzer
from utils import display_code_with_highlights, create_file_tree
from styles import apply_custom_styles
import base64
import plotly.express as px
import plotly.graph_objects as go
from collections import Counter
import pandas as pd
import zipfile

st.set_page_config(
    page_title="Code Lens Ver 1",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

apply_custom_styles()

st.sidebar.markdown("""
### Created by:
**Zensar Project Diamond Team**
""")

def get_file_download_link(file_path):
    with open(file_path, 'r') as f:
        data = f.read()
    b64 = base64.b64encode(data.encode()).decode()
    return f'<a href="data:text/html;base64,{b64}" download="{os.path.basename(file_path)}" class="download-button">Download</a>'

def parse_timestamp_from_filename(filename):
    try:
        date_time_str = filename.split('_')[-2] + '_' + filename.split('_')[-1].split('.')[0]
        return datetime.strptime(date_time_str, '%Y%m%d_%H%M%S')
    except:
        return datetime.min

def create_local_package_zip():
    """Build an in-memory ZIP containing all files needed to run locally."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    files_to_include = [
        ("app.py",                        "app.py"),
        ("codescan.py",                   "codescan.py"),
        ("utils.py",                      "utils.py"),
        ("styles.py",                     "styles.py"),
        ("requirements.txt",              "requirements.txt"),
        ("README.md",                     "README.md"),
        ("run.bat",                       "run.bat"),
        ("run.sh",                        "run.sh"),
        (".streamlit/config.toml",        ".streamlit/config.toml"),
    ]

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for src_rel, arc_name in files_to_include:
            src_path = os.path.join(base_dir, src_rel)
            if os.path.exists(src_path):
                zf.write(src_path, arcname=f"CodeLens/{arc_name}")
    buf.seek(0)
    return buf.read()

def create_dashboard_charts(results):
    # ── Compute shared data ────────────────────────────────────────
    total_files      = results['summary']['files_analyzed']
    demo_fields      = results['summary']['demographic_fields_found']
    integ_patterns   = results['summary']['integration_patterns_found']
    unique_fields    = len(results['summary']['unique_demographic_fields'])
    files_with_demo  = len([f for f in results['summary']['file_details'] if f['demographic_fields_found'] > 0])
    coverage_pct     = round((files_with_demo / total_files * 100) if total_files > 0 else 0, 1)

    field_frequencies = {}
    field_types       = {}
    type_counter      = {}
    for file_data in results['demographic_data'].values():
        for field_name, data in file_data.items():
            field_frequencies[field_name] = field_frequencies.get(field_name, 0) + len(data['occurrences'])
            field_types[field_name] = data['data_type']
    for ft in field_types.values():
        type_counter[ft] = type_counter.get(ft, 0) + 1
    most_common_type = max(type_counter, key=type_counter.get) if type_counter else "N/A"

    # ── KPI Row ────────────────────────────────────────────────────
    st.subheader("📊 Key Performance Indicators")
    k1, k2, k3, k4, k5, k6 = st.columns(6)
    k1.metric("📁 Files Analyzed",       total_files)
    k2.metric("🔍 Demographic Hits",     demo_fields)
    k3.metric("🔑 Unique Fields",        unique_fields)
    k4.metric("🔗 Integration Patterns", integ_patterns)
    k5.metric("📊 Demo Coverage",        f"{files_with_demo}/{total_files} ({coverage_pct}%)")
    k6.metric("🏷️ Top Data Category",    most_common_type)
    st.markdown("---")

    # ── Demographic Analysis ───────────────────────────────────────
    st.subheader("👤 Demographic Field Analysis")

    if field_frequencies:
        col1, col2 = st.columns(2)

        # Pie — top fields
        sorted_fields = sorted(field_frequencies.items(), key=lambda x: x[1], reverse=True)[:14]
        with col1:
            fig_pie = go.Figure(data=[go.Pie(
                labels=[f[0] for f in sorted_fields],
                values=[f[1] for f in sorted_fields],
                hole=0.3,
                textinfo='label+percent',
                marker=dict(colors=px.colors.qualitative.Set3)
            )])
            fig_pie.update_layout(title="Top Demographic Fields — Distribution", height=430, showlegend=True)
            st.plotly_chart(fig_pie, use_container_width=True)

        # Donut — data-type categories
        with col2:
            if type_counter:
                fig_donut = go.Figure(data=[go.Pie(
                    labels=list(type_counter.keys()),
                    values=list(type_counter.values()),
                    hole=0.55,
                    textinfo='label+value',
                    marker=dict(colors=px.colors.qualitative.Pastel)
                )])
                fig_donut.update_layout(
                    title="Fields by Data Type Category",
                    height=430,
                    annotations=[dict(text='Categories', x=0.5, y=0.5, font_size=13, showarrow=False)]
                )
                st.plotly_chart(fig_donut, use_container_width=True)

        # Horizontal bar — top fields by frequency (full width)
        sorted_all = sorted(field_frequencies.items(), key=lambda x: x[1], reverse=True)[:20]
        bar_colors = [px.colors.qualitative.Set2[i % len(px.colors.qualitative.Set2)] for i in range(len(sorted_all))]
        fig_hbar = go.Figure(go.Bar(
            x=[f[1] for f in sorted_all],
            y=[f[0] for f in sorted_all],
            orientation='h',
            marker_color=bar_colors,
            text=[f[1] for f in sorted_all],
            textposition='outside'
        ))
        fig_hbar.update_layout(
            title="Top Demographic Fields by Frequency",
            xaxis_title="Total Occurrences",
            yaxis_title="Field Name",
            height=max(420, len(sorted_all) * 26),
            yaxis=dict(autorange='reversed'),
            margin=dict(l=170),
            showlegend=False
        )
        st.plotly_chart(fig_hbar, use_container_width=True)

        # Treemap — data type → field name hierarchy
        t_labels, t_parents, t_values = [], [], []
        for dtype in set(field_types.values()):
            t_labels.append(dtype)
            t_parents.append("")
            t_values.append(sum(field_frequencies[f] for f, tp in field_types.items() if tp == dtype))
        for fname, freq in field_frequencies.items():
            t_labels.append(fname)
            t_parents.append(field_types.get(fname, "other"))
            t_values.append(freq)
        fig_tree = go.Figure(go.Treemap(
            labels=t_labels, parents=t_parents, values=t_values,
            textinfo='label+value',
            marker_colorscale='Blues'
        ))
        fig_tree.update_layout(
            title="Demographic Fields Hierarchy — Data Type → Field Name",
            height=500,
            margin=dict(t=50, l=25, r=25, b=25)
        )
        st.plotly_chart(fig_tree, use_container_width=True)

        # Grouped bar — field frequency grouped by data type
        type_field_map = {}
        for fname, freq in field_frequencies.items():
            dt = field_types.get(fname, "other")
            type_field_map.setdefault(dt, {'fields': [], 'counts': []})
            type_field_map[dt]['fields'].append(fname)
            type_field_map[dt]['counts'].append(freq)

        palette = px.colors.qualitative.Set1
        fig_grouped = go.Figure()
        for i, (dtype, info) in enumerate(type_field_map.items()):
            fig_grouped.add_trace(go.Bar(
                name=dtype,
                x=info['fields'],
                y=info['counts'],
                marker_color=palette[i % len(palette)]
            ))
        fig_grouped.update_layout(
            title="Demographic Fields Grouped by Data Type",
            xaxis_title="Field Name",
            yaxis_title="Occurrences",
            barmode='group',
            height=450,
            xaxis=dict(tickangle=-35),
            legend=dict(title="Data Type")
        )
        st.plotly_chart(fig_grouped, use_container_width=True)

    st.markdown("---")

    # ── File & Language Analysis ───────────────────────────────────
    st.subheader("📂 File & Language Analysis")
    file_exts   = [Path(file['file_path']).suffix for file in results['summary']['file_details']]
    file_counts = Counter(file_exts)
    col3, col4  = st.columns(2)

    with col3:
        if file_counts:
            ext_list   = list(file_counts.keys())
            cnt_list   = list(file_counts.values())
            fig_lang = go.Figure(go.Bar(
                x=ext_list,
                y=cnt_list,
                marker_color=px.colors.qualitative.Set2[:len(ext_list)],
                text=cnt_list,
                textposition='outside'
            ))
            fig_lang.update_layout(
                title="Files by Language / Extension",
                xaxis_title="Extension",
                yaxis_title="Count",
                height=380,
                showlegend=False
            )
            st.plotly_chart(fig_lang, use_container_width=True)

    with col4:
        file_names_list  = [os.path.basename(d['file_path']) for d in results['summary']['file_details']]
        demo_counts_list = [d['demographic_fields_found']   for d in results['summary']['file_details']]
        intg_counts_list = [d['integration_patterns_found'] for d in results['summary']['file_details']]
        if file_names_list:
            fig_corr = go.Figure()
            fig_corr.add_trace(go.Bar(name='Demographic Fields',   x=file_names_list, y=demo_counts_list, marker_color='#0066cc'))
            fig_corr.add_trace(go.Bar(name='Integration Patterns', x=file_names_list, y=intg_counts_list, marker_color='#90EE90'))
            fig_corr.update_layout(
                title="Fields & Patterns per File",
                xaxis_title="File",
                yaxis_title="Count",
                barmode='group',
                height=380,
                xaxis=dict(tickangle=-30)
            )
            st.plotly_chart(fig_corr, use_container_width=True)

    st.markdown("---")

    # ── Integration Pattern Analysis ───────────────────────────────
    st.subheader("🔗 Integration Pattern Analysis")
    pattern_types = Counter(p['pattern_type'] for p in results['integration_patterns'])
    sub_types     = Counter(f"{p['pattern_type']}: {p['sub_type']}" for p in results['integration_patterns'])

    if pattern_types:
        sorted_pt = sorted(pattern_types.items(), key=lambda x: x[1], reverse=True)
        fig_line = go.Figure()
        fig_line.add_trace(go.Scatter(
            x=[p[0] for p in sorted_pt],
            y=[p[1] for p in sorted_pt],
            mode='lines+markers+text',
            line=dict(color='#0066cc', width=3),
            marker=dict(size=14, color='#0066cc', line=dict(color='white', width=2)),
            text=[p[1] for p in sorted_pt],
            textposition='top center',
            fill='tozeroy',
            fillcolor='rgba(0,102,204,0.10)'
        ))
        fig_line.update_layout(
            title="Integration Pattern Types — Occurrence Distribution",
            xaxis_title="Pattern Category",
            yaxis_title="Total Occurrences",
            height=440,
            showlegend=False,
            xaxis=dict(showgrid=True),
            yaxis=dict(showgrid=True, zeroline=True)
        )
        st.plotly_chart(fig_line, use_container_width=True)

    if sub_types:
        sorted_subs = sorted(sub_types.items(), key=lambda x: x[1], reverse=True)[:20]
        sub_colors  = ['#0066cc' if i % 2 == 0 else '#4da6ff' for i in range(len(sorted_subs))]
        fig_sub = go.Figure(go.Bar(
            x=[s[1] for s in sorted_subs],
            y=[s[0] for s in sorted_subs],
            orientation='h',
            marker_color=sub_colors,
            text=[s[1] for s in sorted_subs],
            textposition='outside'
        ))
        fig_sub.update_layout(
            title="Integration Pattern Sub-Type Breakdown",
            xaxis_title="Count",
            yaxis_title="Pattern: Sub-Type",
            height=max(400, len(sorted_subs) * 30),
            yaxis=dict(autorange='reversed'),
            margin=dict(l=280),
            showlegend=False
        )
        st.plotly_chart(fig_sub, use_container_width=True)

def main():
    st.title("🔍 Code Lens Ver 1")
    st.markdown("### Code Analysis Utility- Demographic Scan")

    st.sidebar.header("Navigation")
    page = st.sidebar.selectbox(
        "Select Page",
        ["Code Analysis", "Excel Demographic Analysis", "Documentation"]
    )

    st.sidebar.markdown("---")
    zip_bytes = create_local_package_zip()
    st.sidebar.download_button(
        label="📦 Download Local Package",
        data=zip_bytes,
        file_name="CodeLens_Ver1.zip",
        mime="application/zip",
        help="Download all files needed to run Code Lens Ver 1 on your local computer"
    )
    st.sidebar.markdown("---")

    if page == "Code Analysis":
        st.sidebar.header("Analysis Settings")
        input_method = st.sidebar.radio(
            "Choose Input Method",
            ["Upload Files", "Repository Path"]
        )

    elif page == "Excel Demographic Analysis":
        st.header("📊 Excel Demographic Data Analysis")
        st.markdown("Upload an Excel file to analyze demographic data based on attr_description and export to 20 files.")

        st.subheader("📋 Sample Excel Format")
        st.markdown("""
        **Required Columns:** `table_name`, `attr_name`, `business_name`, `attr_description`

        Download the sample Excel file to understand the expected format:
        """)

        if os.path.exists('sample_demographic_data.xlsx'):
            with open('sample_demographic_data.xlsx', 'rb') as f:
                st.download_button(
                    label="📥 Download Sample Excel Format",
                    data=f.read(),
                    file_name="sample_demographic_data.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
        else:
            st.info("Sample file not found. Please create it first by running the application setup.")

        st.markdown("---")

        excel_app_name = st.sidebar.text_input("Application Name for Excel Analysis", "C360_Demographics")

        uploaded_excel = st.sidebar.file_uploader(
            "Upload Excel File",
            type=['xlsx', 'xls'],
            help="Upload an Excel file containing demographic data with attr_description column"
        )

        if uploaded_excel and st.sidebar.button("Analyze Excel Data"):
            try:
                temp_excel_path = f"temp_{uploaded_excel.name}"
                with open(temp_excel_path, 'wb') as f:
                    f.write(uploaded_excel.getbuffer())

                with st.spinner("Analyzing Excel demographic data..."):
                    analyzer = CodeAnalyzer(".", excel_app_name)
                    excel_results = analyzer.analyze_excel_demographic_data(temp_excel_path)

                    st.subheader("Excel Analysis Results")

                    col1, col2, col3 = st.columns(3)
                    col1.metric("Total Records", excel_results['summary']['total_records'])
                    col2.metric("Demographic Records", excel_results['summary']['demographic_fields_found'])
                    col3.metric("Files Exported", len(excel_results['summary']['exported_files']))

                    if excel_results['demographic_data']:
                        st.subheader("Sample Demographic Data")
                        sample_data = excel_results['demographic_data'][:10]
                        df_sample = pd.DataFrame(sample_data)
                        st.dataframe(df_sample)

                        st.subheader("Exported Files")
                        st.success(f"Successfully exported demographic data to {len(excel_results['summary']['exported_files'])} files:")
                        for i, filename in enumerate(excel_results['summary']['exported_files'], 1):
                            st.text(f"{i}. {filename}")
                    else:
                        st.warning("No demographic data found in the uploaded Excel file.")

                os.remove(temp_excel_path)

            except Exception as e:
                st.error(f"Error analyzing Excel file: {str(e)}")
                if os.path.exists(temp_excel_path):
                    os.remove(temp_excel_path)

        return

    elif page == "Documentation":
        st.header("📖 Documentation")

        doc_section = st.sidebar.radio(
            "Select Section",
            ["Overview", "README File", "Installation Steps", "Features", "AI & ML Libraries"]
        )

        if doc_section == "Overview":
            st.subheader("Code Lens Ver 1 - Advanced Code Analysis Utility- Demographic Scan")
            st.markdown("""
            ### Key Features
            - Demographic data detection in source code
            - Integration pattern analysis
            - ZIP folder upload support for bulk file analysis
            - Excel demographic data analysis with attr_description
            - Export to multiple files (20 files for Excel analysis)
            - Interactive dashboards
            - Detailed reports generation
            - Multi-language support (Java, Python, JavaScript, TypeScript, C#, PHP, Ruby, XSD)
            - Advanced pattern recognition with fuzzy matching algorithms

            ### Built by Zensar Project Diamond Team
            A comprehensive web-based source code analysis tool designed to extract demographic data and integration patterns across multiple programming languages.
            """)

        elif doc_section == "README File":
            st.subheader("📄 Complete README Documentation")

            readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
            try:
                with open(readme_path, 'r', encoding='utf-8') as f:
                    readme_content = f.read()
                st.markdown(readme_content)
            except FileNotFoundError:
                st.error("README.md file not found")
            except Exception as e:
                st.error(f"Error reading README.md: {str(e)}")

        elif doc_section == "Installation Steps":
            st.subheader("🛠 Installation & Setup Guide")

            st.markdown("""
            ### Prerequisites
            - **Python 3.11+** installed on your system
            - **Web Browser** with JavaScript enabled

            ### Installation Steps
            1. **Download/Clone** the project files to your local machine
            2. **Install Dependencies**:
               ```bash
               pip install streamlit plotly pandas openpyxl pygments fuzzywuzzy python-levenshtein
               ```
            3. **Run the Application**:
               ```bash
               streamlit run app.py --server.address 0.0.0.0 --server.port 5000
               ```
            4. **Access**: Navigate to `http://localhost:5000` in your browser

            ### Alternative Installation
            You can also install dependencies using pip with the following packages:
            - streamlit - Web application framework
            - plotly - Interactive visualizations
            - pandas - Data manipulation and analysis
            - openpyxl - Excel file handling
            - pygments - Code syntax highlighting
            - fuzzywuzzy - Fuzzy string matching
            - python-levenshtein - String distance calculations

            ### Quick Start Guide
            This application is designed to run seamlessly on any Python environment. Simply:
            1. **Download the project** files to your system
            2. **Install dependencies** using pip as shown above
            3. **Run the application** using the streamlit command
            4. **Access your application** at `http://0.0.0.0:5000`

            ### Dependencies
            The following packages are automatically installed:
            - `streamlit` - Web application framework
            - `plotly` - Interactive visualizations
            - `pandas` - Data manipulation and analysis
            - `openpyxl` - Excel file handling
            - `pygments` - Code syntax highlighting
            - `fuzzywuzzy` - Fuzzy string matching
            - `python-levenshtein` - String distance calculations
            """)

        elif doc_section == "Features":
            st.subheader("🚀 Detailed Features Overview")

            st.markdown("""
            ### Core Analysis Capabilities
            - **Multi-Language Support**: Analyzes code across 8+ programming languages
              - Java, Python, JavaScript, TypeScript, C#, PHP, Ruby, XSD
            - **Demographic Data Detection**: Advanced pattern recognition for personal information
            - **Integration Pattern Analysis**: Identifies REST APIs, SOAP services, database operations, messaging systems
            - **ZIP File Support**: Upload entire project folders as ZIP files for bulk analysis
            - **Excel Analysis**: Demographic data extraction from Excel files using fuzzy matching algorithms

            ### Data Types Detected

            #### Personal Information
            - **Names**: Embossed Name, Primary Name, Secondary Name, Legal Name, DBA Name, Double Byte Name
            - **Identity**: Gender, Date of Birth (DOB), Government IDs, SSN, Tax ID, Passport
            - **Contact Information**: Multiple phone types, email addresses, preference language

            #### Address Information
            - **Multiple Address Types**: Home, Business, Alternate, Temporary, Other
            - **Address Arrays**: Support for multiple address entries

            #### Advanced Analysis
            - **Fuzzy Matching Algorithm**: Identifies demographic data with variations in naming
            - **Pattern Confidence Scoring**: Provides match reliability metrics
            - **Export Capabilities**: Generate reports in multiple formats (HTML, JSON, Excel)

            ### Interactive Dashboard
            - **Visual Analytics**: Pie charts, bar graphs, line charts for data distribution
            - **File Statistics**: Language distribution and analysis metrics
            - **Integration Patterns**: Visual representation of detected patterns
            - **Real-time Analysis**: Live progress tracking during code scanning

            ### Export & Reporting
            - **Multi-Format Export**: HTML, JSON, Excel support
            - **Batch Processing**: Handle multiple files simultaneously
            - **Historical Reports**: Timestamped report management
            - **Download Management**: Organized file download system
            """)

            st.markdown("---")
            st.subheader("📥 Download Documentation")
            readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
            try:
                with open(readme_path, 'rb') as f:
                    st.download_button(
                        label="Download Complete README.md",
                        data=f.read(),
                        file_name="CodeLens_README.md",
                        mime="text/markdown"
                    )
            except FileNotFoundError:
                st.info("README.md file not available for download")

        elif doc_section == "AI & ML Libraries":
            st.subheader("🤖 AI & Machine Learning Libraries")
            st.markdown("""
            Code Lens Ver 1 uses a combination of **traditional AI / NLP techniques** and
            **rule-based machine learning** algorithms to detect demographic data and integration
            patterns across source code.

            ---

            ### 🧠 Traditional AI / NLP Libraries Used

            | Library | Category | Purpose in Code Lens |
            |---|---|---|
            | **FuzzyWuzzy** | Traditional ML / NLP | Fuzzy string matching to detect demographic fields even when field names are slightly misspelled or abbreviated |
            | **python-Levenshtein** | String Distance Algorithm | Computes edit distance between strings — accelerates FuzzyWuzzy matching by 4–10x |
            | **Pygments** | NLP / Lexical Analysis | Detects programming language from file content and syntax; powers code highlighting in the UI |
            | **re (Regex Engine)** | Rule-Based AI / Pattern Matching | Core pattern recognition engine for all demographic and integration pattern detection |
            | **pandas** | Statistical Analysis | Data manipulation, aggregation, and statistical summaries for Excel demographic analysis |

            ---

            ### 🔍 How the AI Works

            #### 1. Rule-Based Pattern Matching (Regex Engine)
            The core detection system uses over **50 carefully crafted regular expressions** grouped
            into 7 demographic categories and 5 integration pattern categories.

            ```
            Demographic Categories Detected:
              ├── id         → customerId, gov_ids, government_id
              ├── name       → first_name, last_name, embossed_name, legal_name ...
              ├── address    → home_address, street, city, state, zip ...
              ├── phone      → home_phone, mobile_phone, business_phone ...
              ├── email      → servicing_email, business_email ...
              ├── identity   → ssn, tax_id, passport ...
              └── demographics → gender, dob, nationality ...

            Integration Categories Detected:
              ├── rest_api   → HTTP methods, API endpoints, annotations
              ├── soap_services → WSDL, SOAP envelopes, XML namespaces
              ├── database   → SQL operations, connection strings
              ├── messaging  → Kafka, RabbitMQ, JMS
              └── file       → CSV, Excel, JSON file operations
            ```

            #### 2. Fuzzy Matching (FuzzyWuzzy + Levenshtein Distance)
            Used in the **Excel Demographic Analysis** module to identify demographic fields
            even when their descriptions use alternate spellings, abbreviations, or paraphrased
            language. For example:
            - `"emb name"` → matches `"embossed name"` (high similarity score)
            - `"biz email"` → matches `"business email"`
            - `"mob ph"` → matches `"mobile phone"`

            #### 3. Language Detection (Pygments Lexer)
            Pygments uses a **probabilistic lexer analysis** to auto-detect the programming
            language of each file from both file extension and content tokens, enabling accurate
            syntax highlighting across all 8 supported languages.

            #### 4. Statistical Analysis (pandas)
            Excel analysis uses pandas for:
            - Vectorised keyword matching across thousands of rows
            - Record grouping by demographic category
            - Statistical distribution of field types

            ---

            ### 📦 Dependency Summary

            ```
            streamlit>=1.28.0          # Web UI framework
            plotly>=5.18.0             # Interactive charts & dashboards
            pandas>=2.0.0              # Data analysis & manipulation
            openpyxl>=3.1.0            # Excel file I/O
            pygments>=2.16.0           # Code lexer / language detection (NLP)
            fuzzywuzzy>=0.18.0         # Fuzzy string matching (Traditional ML)
            python-Levenshtein>=0.21.0 # Edit-distance acceleration (String AI)
            ```

            ---

            ### 🔮 Future AI Enhancements (Roadmap)
            - **spaCy / NLTK** — Named Entity Recognition (NER) for deeper field detection
            - **scikit-learn** — ML classifiers to score demographic field confidence
            - **Transformers (BERT)** — Semantic code understanding for ambiguous fields
            - **OpenAI / Anthropic API** — LLM-powered code explanation and risk scoring
            """)
        return

    app_name = st.sidebar.text_input("Application Name", "MyApp")

    analysis_triggered = False
    temp_dir = None
    repo_path = None

    if input_method == "Upload Files":
        uploaded_files = st.sidebar.file_uploader(
            "Upload Code Files or ZIP Folder",
            accept_multiple_files=True,
            type=['py', 'java', 'js', 'ts', 'cs', 'php', 'rb', 'xsd', 'zip']
        )

        if uploaded_files:
            temp_dir = tempfile.mkdtemp()
            for uploaded_file in uploaded_files:
                if uploaded_file.name.endswith('.zip'):
                    zip_path = os.path.join(temp_dir, uploaded_file.name)
                    with open(zip_path, 'wb') as f:
                        f.write(uploaded_file.getbuffer())

                    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                        zip_ref.extractall(temp_dir)

                    os.remove(zip_path)
                else:
                    file_path = os.path.join(temp_dir, uploaded_file.name)
                    with open(file_path, 'wb') as f:
                        f.write(uploaded_file.getbuffer())

            if st.sidebar.button("Run Analysis"):
                analysis_triggered = True
                repo_path = temp_dir

    else:
        repo_path = st.sidebar.text_input("Enter Repository Path")
        if repo_path and st.sidebar.button("Run Analysis"):
            analysis_triggered = True

    if analysis_triggered:
        try:
            with st.spinner("Analyzing code..."):
                analyzer = CodeAnalyzer(repo_path, app_name)
                progress_bar = st.progress(0)

                results = analyzer.scan_repository()
                progress_bar.progress(100)

                tab1, tab2, tab3 = st.tabs(["Dashboard", "Analysis Results", "Export Reports"])

                with tab1:
                    st.header("Analysis Dashboard")
                    st.markdown("""
                    This dashboard provides visual insights into the code analysis results,
                    showing distributions of files, demographic fields, and integration patterns.
                    """)
                    create_dashboard_charts(results)

                with tab2:
                    st.subheader("Summary")
                    stats_cols = st.columns(4)
                    stats_cols[0].metric("Files Analyzed", results['summary']['files_analyzed'])
                    stats_cols[1].metric("Demographic Fields", results['summary']['demographic_fields_found'])
                    stats_cols[2].metric("Integration Patterns", results['summary']['integration_patterns_found'])
                    stats_cols[3].metric("Unique Fields", len(results['summary']['unique_demographic_fields']))

                    st.subheader("Demographic Fields Summary")
                    demographic_files = [f for f in results['summary']['file_details'] if f['demographic_fields_found'] > 0]
                    if demographic_files:
                        cols = st.columns([0.5, 2, 1, 2])
                        cols[0].markdown("**#**")
                        cols[1].markdown("**File Analyzed**")
                        cols[2].markdown("**Fields Found**")
                        cols[3].markdown("**Fields**")

                        for idx, file_detail in enumerate(demographic_files, 1):
                            file_path = file_detail['file_path']
                            unique_fields = []
                            if file_path in results['demographic_data']:
                                unique_fields = list(results['demographic_data'][file_path].keys())

                            cols = st.columns([0.5, 2, 1, 2])
                            cols[0].text(str(idx))
                            cols[1].text(os.path.basename(file_path))
                            cols[2].text(str(file_detail['demographic_fields_found']))
                            cols[3].text(', '.join(unique_fields))

                    st.subheader("Integration Patterns Summary")
                    integration_files = [f for f in results['summary']['file_details'] if f['integration_patterns_found'] > 0]
                    if integration_files:
                        cols = st.columns([0.5, 2, 1, 2])
                        cols[0].markdown("**#**")
                        cols[1].markdown("**File Name**")
                        cols[2].markdown("**Patterns Found**")
                        cols[3].markdown("**Pattern Details**")

                        for idx, file_detail in enumerate(integration_files, 1):
                            file_path = file_detail['file_path']
                            pattern_details = set()
                            for pattern in results['integration_patterns']:
                                if pattern['file_path'] == file_path:
                                    pattern_details.add(f"{pattern['pattern_type']}: {pattern['sub_type']}")

                            cols = st.columns([0.5, 2, 1, 2])
                            cols[0].text(str(idx))
                            cols[1].text(os.path.basename(file_path))
                            cols[2].text(str(file_detail['integration_patterns_found']))
                            cols[3].text(', '.join(pattern_details))

                with tab3:
                    st.header("Available Reports")

                    report_dir = os.path.dirname(__file__)
                    report_files = [
                        f for f in os.listdir(report_dir)
                        if f.endswith('.html')
                        and 'CodeLens' in f
                        and f.startswith(app_name)
                    ]

                    report_files.sort(key=parse_timestamp_from_filename, reverse=True)

                    if report_files:
                        cols = st.columns([1, 3, 2, 2, 2])
                        cols[0].markdown("**S.No**")
                        cols[1].markdown("**File Name**")
                        cols[2].markdown("**Date**")
                        cols[3].markdown("**Time**")
                        cols[4].markdown("**Download**")

                        for idx, report_file in enumerate(report_files, 1):
                            cols = st.columns([1, 3, 2, 2, 2])
                            cols[0].text(f"{idx}")
                            display_name = report_file.replace('.html', '')
                            cols[1].text(display_name)
                            timestamp = parse_timestamp_from_filename(report_file)
                            cols[2].text(timestamp.strftime('%d-%b-%Y'))
                            cols[3].text(timestamp.strftime('%I:%M:%S %p'))
                            full_report_path = os.path.join(report_dir, report_file)
                            cols[4].markdown(
                                get_file_download_link(full_report_path),
                                unsafe_allow_html=True
                            )
                    else:
                        st.info("No reports available for this application.")

        except Exception as e:
            st.error(f"Error during analysis: {str(e)}")

        finally:
            if temp_dir:
                import shutil
                shutil.rmtree(temp_dir)

if __name__ == "__main__":
    main()
