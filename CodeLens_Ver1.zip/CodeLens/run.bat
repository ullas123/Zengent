@echo off
echo Starting Code Lens Ver 1...
pip install -r requirements.txt
streamlit run app.py --server.address 0.0.0.0 --server.port 5000
pause
