# Code Lens Ver 1 - Advanced Code Analysis Utility

A comprehensive web-based source code analysis tool designed to extract demographic data and integration patterns across multiple programming languages.

**Built by the Zensar Project Diamond Team**

---

## Quick Start Guide

1. **Extract** the ZIP file to a folder on your computer
2. **Install Python 3.11+** if not already installed — https://www.python.org/downloads/
3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
4. **Run the application**:
   - **Windows**: Double-click `run.bat`
   - **Mac / Linux**: Run `bash run.sh` in terminal
   - **Manual**: `streamlit run app.py --server.address 0.0.0.0 --server.port 5000`
5. **Open** your browser and go to `http://localhost:5000`

---

## Features

### Core Analysis Capabilities
- **Multi-Language Support**: Analyzes code across 8+ programming languages
  - Java, Python, JavaScript, TypeScript, C#, PHP, Ruby, XSD
- **Demographic Data Detection**: Advanced pattern recognition for personal information
- **Integration Pattern Analysis**: Identifies REST APIs, SOAP services, database operations, messaging systems
- **ZIP File Support**: Upload entire project folders as ZIP files for bulk analysis
- **Excel Analysis**: Demographic data extraction from Excel files using fuzzy matching algorithms

### Data Types Detected

#### Personal Information
- **Names**: Embossed Name, Primary Name, Secondary Name, Legal Name, DBA Name, Double Byte Name
- **Identity**: Gender, Date of Birth (DOB), Government IDs, SSN, Tax ID, Passport
- **Contact Information**: Multiple phone types, email addresses, preference language

#### Address Information
- **Multiple Address Types**: Home, Business, Alternate, Temporary, Other
- **Address Arrays**: Support for multiple address entries

#### Advanced Analysis
- **Fuzzy Matching Algorithm**: Identifies demographic data with variations in naming
- **Pattern Confidence Scoring**: Provides match reliability metrics
- **Export Capabilities**: Generate reports in multiple formats (HTML, JSON, Excel)

### Interactive Dashboard
- **Visual Analytics**: Pie charts, bar graphs, line charts for data distribution
- **File Statistics**: Language distribution and analysis metrics
- **Integration Patterns**: Visual representation of detected patterns
- **Real-time Analysis**: Live progress tracking during code scanning

---

## File Structure

```
CodeLens/
├── .streamlit/
│   └── config.toml          # Streamlit configuration (port, theme)
├── app.py                   # Main application
├── codescan.py              # Core analysis engine
├── utils.py                 # Utility functions
├── styles.py                # Custom CSS styling
├── requirements.txt         # Python dependencies
├── run.bat                  # Windows startup script
├── run.sh                   # Mac/Linux startup script
└── README.md                # This documentation
```

---

## Usage Guide

### Code Analysis
1. Select **Code Analysis** in the sidebar navigation
2. Choose input method: **Upload Files** or **Repository Path**
3. Enter an application name
4. Upload your code files (.py, .java, .js, .ts, .cs, .php, .rb, .xsd) or a ZIP folder
5. Click **Run Analysis**
6. View results across three tabs: Dashboard, Analysis Results, Export Reports

### Excel Demographic Analysis
1. Select **Excel Demographic Analysis** in the sidebar
2. Upload an Excel file containing an `attr_description` column
   - Required columns: `table_name`, `attr_name`, `business_name`, `attr_description`
3. Click **Analyze Excel Data**
4. Demographic records are automatically exported to up to 20 files

### Report Generation
- HTML reports are automatically generated after each code analysis
- Access them in the **Export Reports** tab
- Download any report using the Download button

---

## Dependencies

| Package | Purpose |
|---|---|
| streamlit | Web application framework |
| plotly | Interactive visualizations |
| pandas | Data manipulation and analysis |
| openpyxl | Excel file handling |
| pygments | Code syntax highlighting |
| fuzzywuzzy | Fuzzy string matching |
| python-Levenshtein | String distance calculations |

---

## Troubleshooting

| Issue | Solution |
|---|---|
| Port already in use | Change port in `.streamlit/config.toml` |
| File upload errors | Ensure files are in supported formats |
| ZIP extraction issues | Verify ZIP file integrity |
| Excel analysis errors | Ensure `attr_description` column exists |
| `pip` not found | Use `pip3` instead |

---

**Created by Zensar Project Diamond Team**
This project is licensed for use in the AMEX Environment only.
