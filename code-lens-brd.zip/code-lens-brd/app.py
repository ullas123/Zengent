import streamlit as st
import graphviz
import ast
import re
import base64
import textwrap
import os
from typing import Optional

st.set_page_config(
    page_title="Code Lens - BRD",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

    /* Force light mode — override any OS dark-mode preference */
    :root { color-scheme: light only !important; }

    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
        color: #1e293b !important;
        background-color: #ffffff !important;
    }

    .stApp {
        background: #ffffff !important;
        min-height: 100vh;
    }

    /* force all Streamlit default text to dark */
    .stApp p, .stApp span, .stApp div, .stApp label { color: #1e293b !important; }

    /* override any Streamlit dark-mode injection */
    [data-theme="dark"] .stApp,
    .stApp[data-theme="dark"] {
        background: #ffffff !important;
        color: #1e293b !important;
    }

    .main-header {
        text-align: center;
        padding: 2rem 0 1rem 0;
        background: linear-gradient(135deg, rgba(99,102,241,0.08) 0%, rgba(168,85,247,0.08) 100%);
        border-radius: 16px;
        border: 1px solid rgba(99,102,241,0.25);
        margin-bottom: 2rem;
    }
    .main-header h1 {
        font-size: 2.8rem;
        font-weight: 700;
        background: linear-gradient(135deg, #6366f1, #8b5cf6, #3b82f6);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin: 0;
        letter-spacing: -0.5px;
    }
    .main-header p { color: #64748b; font-size: 1.1rem; margin: 0.5rem 0 0 0; }

    .badge {
        display: inline-block;
        background: rgba(99,102,241,0.1);
        border: 1px solid rgba(99,102,241,0.35);
        color: #4f46e5;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 600;
        letter-spacing: 0.5px;
        margin: 4px;
    }
    .sql-badge {
        display: inline-block;
        background: rgba(245,158,11,0.1);
        border: 1px solid rgba(245,158,11,0.35);
        color: #d97706;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 600;
        margin: 4px;
    }

    .stTextArea textarea {
        background: #f8fafc !important;
        border: 1px solid #cbd5e1 !important;
        border-radius: 10px !important;
        color: #1e293b !important;
        font-family: 'JetBrains Mono', monospace !important;
        font-size: 0.875rem !important;
    }
    .stTextArea textarea:focus {
        border-color: #6366f1 !important;
        box-shadow: 0 0 0 2px rgba(99,102,241,0.15) !important;
    }
    .stTextArea textarea::placeholder { color: #94a3b8 !important; }

    .stButton > button {
        background: linear-gradient(135deg, #6366f1, #8b5cf6) !important;
        border: none !important;
        border-radius: 10px !important;
        color: white !important;
        font-weight: 600 !important;
        font-size: 0.95rem !important;
        padding: 0.65rem 1.5rem !important;
        transition: all 0.2s !important;
        box-shadow: 0 4px 15px rgba(99,102,241,0.25) !important;
    }
    .stButton > button:hover {
        transform: translateY(-1px) !important;
        box-shadow: 0 6px 20px rgba(99,102,241,0.4) !important;
    }
    .stDownloadButton > button {
        background: linear-gradient(135deg, #10b981, #059669) !important;
        border: none !important;
        border-radius: 8px !important;
        color: white !important;
        font-weight: 600 !important;
        box-shadow: 0 4px 12px rgba(16,185,129,0.25) !important;
    }

    h3 { color: #1e293b !important; font-weight: 600 !important; }
    h2 { color: #1e293b !important; }

    .stRadio > div > label { color: #374151 !important; }
    .stRadio > label { color: #374151 !important; }

    div[data-testid="stSidebar"] {
        background: #f8fafc !important;
        border-right: 1px solid #e2e8f0 !important;
    }
    div[data-testid="stSidebar"] label,
    div[data-testid="stSidebar"] p { color: #374151 !important; }
    div[data-testid="stSidebar"] h2 { color: #1e293b !important; }
    div[data-testid="stSidebar"] .stSelectbox label { color: #374151 !important; }

    /* selectbox */
    div[data-baseweb="select"] > div {
        background: #ffffff !important;
        border: 1px solid #cbd5e1 !important;
        color: #1e293b !important;
    }

    /* metric numbers */
    div[data-testid="stMetricValue"] { color: #4f46e5 !important; }
    div[data-testid="stMetricLabel"] { color: #64748b !important; }

    .svg-container {
        background: #ffffff;
        border-radius: 10px;
        padding: 2rem;
        text-align: center;
        border: 1px solid #e2e8f0;
        box-shadow: 0 1px 6px rgba(0,0,0,0.06);
        width: 100%;
        overflow-x: auto;
    }
    .svg-container svg {
        width: 100% !important;
        height: auto !important;
        min-height: 500px;
        max-width: 100%;
    }

    .upload-zone {
        border: 2px dashed #c7d2fe;
        border-radius: 12px;
        padding: 1rem;
        margin-bottom: 0.75rem;
        background: #f5f3ff;
    }
    .file-info {
        background: #f0fdf4;
        border: 1px solid #bbf7d0;
        border-radius: 8px;
        padding: 0.5rem 0.75rem;
        color: #166534;
        font-size: 0.85rem;
        margin: 0.5rem 0;
    }
    .sql-info {
        background: #fffbeb;
        border: 1px solid #fde68a;
        border-radius: 8px;
        padding: 0.5rem 0.75rem;
        color: #92400e;
        font-size: 0.85rem;
        margin: 0.5rem 0;
    }

    /* horizontal rule */
    hr { border-color: #e2e8f0 !important; }
</style>
""", unsafe_allow_html=True)


# ─── EXAMPLE DATA ────────────────────────────────────────────────────────────

TEXT_EXAMPLES = {
    "E-Commerce System": """\
User visits website and browses products.
User adds items to cart and proceeds to checkout.
System validates cart and checks inventory.
Payment gateway processes credit card payment.
Order management system creates order record.
Warehouse receives order and prepares shipment.
Shipping service delivers package to customer.
Notification service sends email confirmation.""",

    "Authentication Flow": """\
Client sends login request with username and password.
API Gateway receives request and routes to Auth Service.
Auth Service validates credentials against User Database.
User Database returns user record with hashed password.
Auth Service verifies password hash and generates JWT token.
Token Service signs JWT with private key and sets expiry.
Auth Service returns access token and refresh token to client.
Client stores tokens and includes access token in subsequent requests.""",

    "Microservices Architecture": """\
API Gateway receives all client requests.
Load Balancer distributes traffic across service instances.
User Service handles authentication and user management.
Product Service manages product catalog and search.
Order Service processes orders and manages order lifecycle.
Payment Service integrates with external payment providers.
Notification Service sends emails, SMS, and push notifications.
Database Layer stores data in separate databases per service.
Message Queue enables async communication between services.
Monitoring Service collects metrics and logs from all services.""",

    "CI/CD Pipeline": """\
Developer commits code to feature branch in Git repository.
GitHub Actions triggers automated build pipeline.
Code Quality tool runs linting and static analysis checks.
Test Runner executes unit tests and integration tests.
Build Service compiles application and creates Docker image.
Security Scanner checks image for vulnerabilities.
Container Registry stores approved Docker image.
Staging deployment updates staging environment automatically.
QA team runs manual testing on staging environment.
Approval gate requires team lead sign-off for production.
Production deployment rolls out new version with blue-green strategy.
Health Check monitors deployment and rolls back if errors detected.""",
}

PYTHON_EXAMPLES = {
    "FastAPI App": '''\
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy.orm import Session
from database import get_db
from models import User, Product, Order

app = FastAPI()

@app.post("/users/register")
def register_user(user_data: dict, db: Session = Depends(get_db)):
    user = User(**user_data)
    db.add(user)
    db.commit()
    return user

@app.get("/products")
def list_products(db: Session = Depends(get_db)):
    return db.query(Product).all()

@app.post("/orders")
def create_order(order_data: dict, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == order_data["product_id"]).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    order = Order(**order_data)
    db.add(order)
    db.commit()
    return order

@app.put("/orders/{order_id}/status")
def update_order_status(order_id: int, status: str, db: Session = Depends(get_db)):
    order = db.query(Order).filter(Order.id == order_id).first()
    order.status = status
    db.commit()
    return order''',

    "ML Pipeline": '''\
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib

def load_data(filepath):
    data = pd.read_csv(filepath)
    return data

def preprocess(data):
    features = data.drop("target", axis=1)
    labels = data["target"]
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(features)
    return features_scaled, labels, scaler

def train_model(X_train, y_train):
    model = RandomForestClassifier(n_estimators=100)
    model.fit(X_train, y_train)
    return model

def evaluate_model(model, X_test, y_test):
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    return accuracy

def save_model(model, scaler, path):
    joblib.dump({"model": model, "scaler": scaler}, path)

def run_pipeline(filepath, model_path):
    data = load_data(filepath)
    X, y, scaler = preprocess(data)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    model = train_model(X_train, y_train)
    accuracy = evaluate_model(model, X_test, y_test)
    save_model(model, scaler, model_path)
    return accuracy''',
}

COBOL_EXAMPLES = {
    "Payroll Processing": """\
       IDENTIFICATION DIVISION.
       PROGRAM-ID. PAYROLL.
       AUTHOR. EXAMPLE.

       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT EMPLOYEE-FILE ASSIGN TO 'EMP.DAT'.
           SELECT PAYROLL-FILE  ASSIGN TO 'PAY.DAT'.
           SELECT REPORT-FILE   ASSIGN TO 'RPT.TXT'.

       DATA DIVISION.
       FILE SECTION.
       FD  EMPLOYEE-FILE.
       01  EMPLOYEE-RECORD.
           05  EMP-ID          PIC 9(6).
           05  EMP-NAME        PIC X(30).
           05  EMP-DEPT        PIC X(10).
           05  EMP-SALARY      PIC 9(7)V99.

       WORKING-STORAGE SECTION.
       01  WS-FLAGS.
           05  WS-EOF          PIC X VALUE 'N'.
           05  WS-ERROR        PIC X VALUE 'N'.
       01  WS-TOTALS.
           05  WS-TOTAL-PAY    PIC 9(9)V99 VALUE ZEROS.
           05  WS-EMP-COUNT    PIC 9(5)    VALUE ZEROS.
       01  WS-CALC.
           05  WS-GROSS-PAY    PIC 9(7)V99.
           05  WS-TAX-AMOUNT   PIC 9(6)V99.
           05  WS-NET-PAY      PIC 9(7)V99.

       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 1000-INITIALIZE
           PERFORM 2000-PROCESS-EMPLOYEES
               UNTIL WS-EOF = 'Y'
           PERFORM 3000-FINALIZE
           STOP RUN.

       1000-INITIALIZE.
           OPEN INPUT  EMPLOYEE-FILE
           OPEN OUTPUT PAYROLL-FILE
           OPEN OUTPUT REPORT-FILE
           PERFORM 1100-READ-EMPLOYEE
           MOVE ZEROS TO WS-TOTALS.

       1100-READ-EMPLOYEE.
           READ EMPLOYEE-FILE
               AT END MOVE 'Y' TO WS-EOF
           END-READ.

       2000-PROCESS-EMPLOYEES.
           PERFORM 2100-CALC-GROSS-PAY
           PERFORM 2200-CALC-TAX
           PERFORM 2300-CALC-NET-PAY
           PERFORM 2400-WRITE-PAYROLL
           PERFORM 2500-UPDATE-TOTALS
           PERFORM 1100-READ-EMPLOYEE.

       2100-CALC-GROSS-PAY.
           MOVE EMP-SALARY TO WS-GROSS-PAY.

       2200-CALC-TAX.
           COMPUTE WS-TAX-AMOUNT = WS-GROSS-PAY * 0.20.

       2300-CALC-NET-PAY.
           COMPUTE WS-NET-PAY = WS-GROSS-PAY - WS-TAX-AMOUNT.

       2400-WRITE-PAYROLL.
           WRITE PAYROLL-FILE FROM WS-CALC.

       2500-UPDATE-TOTALS.
           ADD WS-NET-PAY TO WS-TOTAL-PAY
           ADD 1          TO WS-EMP-COUNT.

       3000-FINALIZE.
           PERFORM 3100-WRITE-REPORT
           CLOSE EMPLOYEE-FILE
           CLOSE PAYROLL-FILE
           CLOSE REPORT-FILE.

       3100-WRITE-REPORT.
           WRITE REPORT-FILE FROM WS-TOTALS.""",

    "Bank Account System": """\
       IDENTIFICATION DIVISION.
       PROGRAM-ID. BANKACCT.

       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT ACCOUNT-FILE  ASSIGN TO 'ACCT.DAT'.
           SELECT TRANS-FILE    ASSIGN TO 'TRANS.DAT'.
           SELECT AUDIT-FILE    ASSIGN TO 'AUDIT.TXT'.

       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-ACCOUNT.
           05  WS-ACCT-NUM     PIC 9(10).
           05  WS-ACCT-BAL     PIC S9(9)V99.
           05  WS-ACCT-TYPE    PIC X(10).
       01  WS-TRANSACTION.
           05  WS-TRANS-TYPE   PIC X(1).
           05  WS-TRANS-AMT    PIC 9(7)V99.
       01  WS-FLAGS.
           05  WS-EOF          PIC X VALUE 'N'.
           05  WS-VALID        PIC X VALUE 'Y'.
       01  WS-RESULT.
           05  WS-NEW-BAL      PIC S9(9)V99.
           05  WS-FEE          PIC 9(5)V99.

       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 1000-OPEN-FILES
           PERFORM 2000-PROCESS-TRANSACTIONS
               UNTIL WS-EOF = 'Y'
           PERFORM 9000-CLOSE-FILES
           STOP RUN.

       1000-OPEN-FILES.
           OPEN INPUT  ACCOUNT-FILE
           OPEN INPUT  TRANS-FILE
           OPEN OUTPUT AUDIT-FILE
           PERFORM 1100-READ-TRANSACTION.

       1100-READ-TRANSACTION.
           READ TRANS-FILE
               AT END MOVE 'Y' TO WS-EOF
           END-READ.

       2000-PROCESS-TRANSACTIONS.
           PERFORM 2100-VALIDATE-TRANS
           IF WS-VALID = 'Y'
               PERFORM 2200-APPLY-TRANSACTION
               PERFORM 2300-CALC-FEES
               PERFORM 2400-UPDATE-ACCOUNT
               PERFORM 2500-WRITE-AUDIT
           END-IF
           PERFORM 1100-READ-TRANSACTION.

       2100-VALIDATE-TRANS.
           IF WS-TRANS-AMT <= ZEROS
               MOVE 'N' TO WS-VALID
           ELSE
               MOVE 'Y' TO WS-VALID
           END-IF.

       2200-APPLY-TRANSACTION.
           IF WS-TRANS-TYPE = 'D'
               ADD WS-TRANS-AMT TO WS-ACCT-BAL
           ELSE
               SUBTRACT WS-TRANS-AMT FROM WS-ACCT-BAL
           END-IF.

       2300-CALC-FEES.
           IF WS-ACCT-TYPE = 'CHECKING'
               COMPUTE WS-FEE = WS-TRANS-AMT * 0.01
           ELSE
               MOVE ZEROS TO WS-FEE
           END-IF.

       2400-UPDATE-ACCOUNT.
           SUBTRACT WS-FEE FROM WS-ACCT-BAL
           REWRITE ACCOUNT-FILE FROM WS-ACCOUNT.

       2500-WRITE-AUDIT.
           WRITE AUDIT-FILE FROM WS-TRANSACTION.

       9000-CLOSE-FILES.
           CLOSE ACCOUNT-FILE
           CLOSE TRANS-FILE
           CLOSE AUDIT-FILE.""",

    "Inventory Control": """\
       IDENTIFICATION DIVISION.
       PROGRAM-ID. INVENTORY.

       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-ITEM.
           05  WS-ITEM-CODE    PIC X(10).
           05  WS-ITEM-DESC    PIC X(40).
           05  WS-ITEM-QTY     PIC 9(6).
           05  WS-ITEM-PRICE   PIC 9(5)V99.
           05  WS-REORDER-PT   PIC 9(4).
       01  WS-WORK.
           05  WS-TOTAL-VALUE  PIC 9(9)V99 VALUE ZEROS.
           05  WS-REORDER-CNT  PIC 9(4)    VALUE ZEROS.
           05  WS-EOF          PIC X       VALUE 'N'.

       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 1000-INITIALIZE
           PERFORM 2000-PROCESS-ITEMS UNTIL WS-EOF = 'Y'
           PERFORM 3000-GENERATE-REPORT
           STOP RUN.

       1000-INITIALIZE.
           OPEN INPUT  INVENTORY-FILE
           OPEN OUTPUT REPORT-FILE
           OPEN OUTPUT ORDER-FILE
           PERFORM 1100-READ-ITEM.

       1100-READ-ITEM.
           READ INVENTORY-FILE
               AT END MOVE 'Y' TO WS-EOF
           END-READ.

       2000-PROCESS-ITEMS.
           PERFORM 2100-CALC-ITEM-VALUE
           PERFORM 2200-CHECK-REORDER
           PERFORM 1100-READ-ITEM.

       2100-CALC-ITEM-VALUE.
           COMPUTE WS-TOTAL-VALUE = WS-TOTAL-VALUE +
               (WS-ITEM-QTY * WS-ITEM-PRICE).

       2200-CHECK-REORDER.
           IF WS-ITEM-QTY < WS-REORDER-PT
               PERFORM 2210-GENERATE-ORDER
               ADD 1 TO WS-REORDER-CNT
           END-IF.

       2210-GENERATE-ORDER.
           WRITE ORDER-FILE FROM WS-ITEM.

       3000-GENERATE-REPORT.
           PERFORM 3100-WRITE-SUMMARY
           CLOSE INVENTORY-FILE
           CLOSE REPORT-FILE
           CLOSE ORDER-FILE.

       3100-WRITE-SUMMARY.
           WRITE REPORT-FILE FROM WS-WORK.""",
}

SQL_EXAMPLES = {
    "E-Commerce Schema": """\
CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE products (
    product_id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10,2),
    stock_qty INT DEFAULT 0,
    category_id INT REFERENCES categories(category_id)
);

CREATE TABLE orders (
    order_id SERIAL PRIMARY KEY,
    customer_id INT REFERENCES customers(customer_id),
    status VARCHAR(50) DEFAULT 'pending',
    total DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE order_items (
    item_id SERIAL PRIMARY KEY,
    order_id INT REFERENCES orders(order_id),
    product_id INT REFERENCES products(product_id),
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2)
);

CREATE TABLE categories (
    category_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    parent_id INT REFERENCES categories(category_id)
);

SELECT c.name, COUNT(o.order_id) as order_count, SUM(o.total) as revenue
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.status = 'completed'
GROUP BY c.customer_id, c.name
ORDER BY revenue DESC;""",

    "HR System Queries": """\
CREATE TABLE departments (
    dept_id SERIAL PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL,
    manager_id INT
);

CREATE TABLE employees (
    emp_id SERIAL PRIMARY KEY,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    dept_id INT REFERENCES departments(dept_id),
    manager_id INT REFERENCES employees(emp_id),
    salary DECIMAL(10,2),
    hire_date DATE
);

CREATE TABLE payroll (
    payroll_id SERIAL PRIMARY KEY,
    emp_id INT REFERENCES employees(emp_id),
    pay_period DATE,
    gross_pay DECIMAL(10,2),
    deductions DECIMAL(10,2),
    net_pay DECIMAL(10,2)
);

INSERT INTO departments (dept_name) VALUES ('Engineering'), ('Marketing'), ('HR');

UPDATE employees SET salary = salary * 1.10
WHERE dept_id = (SELECT dept_id FROM departments WHERE dept_name = 'Engineering');

SELECT d.dept_name, AVG(e.salary) as avg_salary, COUNT(*) as headcount
FROM departments d
LEFT JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_id, d.dept_name
ORDER BY avg_salary DESC;

DELETE FROM payroll WHERE pay_period < '2022-01-01';""",
}


# ─── PARSERS ─────────────────────────────────────────────────────────────────

def parse_python_to_entities(code: str):
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return None, None, str(e)

    classes, functions, calls, imports = [], [], [], []

    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            methods = [n.name for n in ast.walk(node) if isinstance(n, ast.FunctionDef)]
            classes.append({"name": node.name, "methods": methods})
        elif isinstance(node, ast.FunctionDef):
            is_method = any(
                isinstance(item, ast.FunctionDef) and item.name == node.name
                for cls_node in ast.walk(tree)
                if isinstance(cls_node, ast.ClassDef)
                for item in cls_node.body
            )
            if not is_method:
                functions.append(node.name)
                for child in ast.walk(node):
                    if isinstance(child, ast.Call):
                        if isinstance(child.func, ast.Name):
                            calls.append((node.name, child.func.id))
                        elif isinstance(child.func, ast.Attribute):
                            calls.append((node.name, child.func.attr))
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            if isinstance(node, ast.ImportFrom) and node.module:
                imports.append(node.module)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)

    return {"classes": classes, "functions": functions, "calls": calls, "imports": imports}, None, None


def parse_sql_to_entities(sql: str):
    """Parse SQL to extract tables, columns, joins, operations and relationships."""
    sql_upper = sql.upper()
    sql_clean = re.sub(r'--[^\n]*', '', sql)          # strip line comments
    sql_clean = re.sub(r'/\*.*?\*/', '', sql_clean, flags=re.DOTALL)  # block comments

    tables = {}       # {name: {columns, pk, fk}}
    joins = []        # [(left_table, right_table, join_type, condition)]
    operations = []   # [(op_type, table, detail)]
    views = []
    procedures = []
    subqueries = []

    # ── CREATE TABLE ──
    create_pattern = re.compile(
        r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)\s*\((.*?)\)',
        re.IGNORECASE | re.DOTALL
    )
    for m in create_pattern.finditer(sql_clean):
        tname = m.group(1).upper()
        body = m.group(2)
        columns = []
        pk_cols = []
        fk_refs = []

        for line in body.split(','):
            line = line.strip()
            if not line:
                continue
            col_m = re.match(r'(\w+)\s+(\w+(?:\s*\([^)]*\))?)', line, re.IGNORECASE)
            if col_m and col_m.group(1).upper() not in (
                'PRIMARY', 'FOREIGN', 'UNIQUE', 'INDEX', 'KEY', 'CHECK', 'CONSTRAINT'
            ):
                col_name = col_m.group(1)
                col_type = col_m.group(2)
                is_pk = 'PRIMARY KEY' in line.upper()
                columns.append({"name": col_name, "type": col_type, "pk": is_pk})
                if is_pk:
                    pk_cols.append(col_name)

            fk_m = re.search(
                r'REFERENCES\s+(\w+)\s*\(\s*(\w+)\s*\)',
                line, re.IGNORECASE
            )
            if fk_m:
                fk_refs.append({"ref_table": fk_m.group(1).upper(), "ref_col": fk_m.group(2)})
                joins.append((tname, fk_m.group(1).upper(), "FK", f"→ {fk_m.group(2)}"))

        tables[tname] = {"columns": columns[:8], "pk": pk_cols, "fk": fk_refs}

    # ── CREATE VIEW ──
    view_pat = re.compile(r'CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+(\w+)', re.IGNORECASE)
    for m in view_pat.finditer(sql_clean):
        views.append(m.group(1).upper())

    # ── CREATE PROCEDURE / FUNCTION ──
    proc_pat = re.compile(r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:PROCEDURE|FUNCTION)\s+(\w+)', re.IGNORECASE)
    for m in proc_pat.finditer(sql_clean):
        procedures.append(m.group(1).upper())

    # ── DML Operations ──
    for op, kw in [('SELECT', r'SELECT\b'), ('INSERT', r'INSERT\s+INTO\s+(\w+)'),
                   ('UPDATE', r'UPDATE\s+(\w+)'), ('DELETE', r'DELETE\s+FROM\s+(\w+)'),
                   ('MERGE',  r'MERGE\s+INTO\s+(\w+)')]:
        for m in re.finditer(kw, sql_clean, re.IGNORECASE):
            tbl = m.group(1).upper() if m.lastindex else ''
            operations.append((op, tbl))

    # ── JOINs in SELECT statements ──
    join_pat = re.compile(
        r'(INNER|LEFT|RIGHT|FULL|CROSS)?\s*(?:OUTER\s+)?JOIN\s+(\w+)\s+(?:\w+\s+)?ON\s+([^\n]+)',
        re.IGNORECASE
    )
    # Find FROM tables
    from_pat = re.compile(r'\bFROM\s+(\w+)', re.IGNORECASE)
    from_tables = [m.group(1).upper() for m in from_pat.finditer(sql_clean)]

    for m in join_pat.finditer(sql_clean):
        join_type = (m.group(1) or 'INNER').upper()
        right_tbl = m.group(2).upper()
        condition = m.group(3).strip()[:60]
        if from_tables:
            left_tbl = from_tables[0]
            joins.append((left_tbl, right_tbl, join_type, condition))

    # ── Subqueries ──
    sub_pat = re.compile(r'\(\s*SELECT\b', re.IGNORECASE)
    subqueries = [f"Subquery_{i+1}" for i, _ in enumerate(sub_pat.finditer(sql_clean))]

    return {
        "tables": tables,
        "joins": joins,
        "operations": operations,
        "views": views,
        "procedures": procedures,
        "subqueries": subqueries,
    }


def parse_cobol_to_entities(code: str) -> dict:
    """Parse COBOL source code and extract structural and flow information."""
    lines = code.split('\n')

    # Strip fixed-format sequence numbers / indicators and handle free-format
    cleaned = []
    for raw in lines:
        if len(raw) >= 7:
            indicator = raw[6] if len(raw) > 6 else ' '
            if indicator in ('*', '/', 'D'):
                continue                        # comment / debug line
            content = raw[7:72] if len(raw) > 7 else ''
        else:
            content = raw
        content = content.strip()
        if content:
            cleaned.append(content)

    # ── Patterns ──
    div_pat    = re.compile(r'^([A-Z][\w-]+)\s+DIVISION', re.IGNORECASE)
    sec_pat    = re.compile(r'^([A-Z][\w-]+)\s+SECTION\.?$', re.IGNORECASE)
    para_pat   = re.compile(r'^([A-Z0-9][\w-]+)\.\s*$', re.IGNORECASE)
    perform_pat= re.compile(r'\bPERFORM\s+([\w-]+)', re.IGNORECASE)
    thru_pat   = re.compile(r'\bPERFORM\s+([\w-]+)\s+(?:THROUGH|THRU)\s+([\w-]+)', re.IGNORECASE)
    call_pat   = re.compile(r"\bCALL\s+['\"]?([\w-]+)['\"]?", re.IGNORECASE)
    ws_pat     = re.compile(r'^(\d{2})\s+([\w-]+)\s+PIC(?:TURE)?(?:IS)?\s+([\w()V.Z9X+\-/]+)', re.IGNORECASE)
    level_pat  = re.compile(r'^(01|77)\s+([\w-]+)', re.IGNORECASE)
    select_pat = re.compile(r'\bSELECT\s+([\w-]+)', re.IGNORECASE)
    fop_pat    = re.compile(r'\b(READ|WRITE|OPEN|CLOSE|REWRITE|DELETE|START)\s+([\w-]+)', re.IGNORECASE)
    pid_pat    = re.compile(r'PROGRAM-ID\.?\s+([\w-]+)', re.IGNORECASE)
    if_pat     = re.compile(r'\bIF\b', re.IGNORECASE)
    eval_pat   = re.compile(r'\bEVALUATE\b', re.IGNORECASE)
    compute_pat= re.compile(r'\bCOMPUTE\b', re.IGNORECASE)
    move_pat   = re.compile(r'\bMOVE\s+\S+\s+TO\s+([\w-]+)', re.IGNORECASE)

    # Skip keywords that look like paragraphs
    COBOL_KEYWORDS = {
        'IDENTIFICATION','ENVIRONMENT','DATA','PROCEDURE','FILE','WORKING-STORAGE',
        'LINKAGE','LOCAL-STORAGE','REPORT','SCREEN','END','STOP','EXIT',
        'CONFIGURATION','INPUT-OUTPUT','FILE-CONTROL','I-O-CONTROL',
    }

    program_id        = 'PROGRAM'
    divisions         = []            # ordered list
    div_sections      = {}            # div -> [sections]
    section_paras     = {}            # section -> [paras]
    para_div          = {}            # para -> division
    para_sec          = {}            # para -> section
    para_order        = []            # ordered paragraph names
    para_set          = set()
    perform_edges     = []            # (caller, callee, edge_type, thru_end)
    call_edges        = []            # (caller, ext_program)
    working_storage   = []
    select_files      = []
    file_ops          = []
    if_count          = 0
    evaluate_count    = 0
    compute_count     = 0
    moves             = []

    current_div  = None
    current_sec  = None
    current_para = None
    in_procedure = False
    in_ws        = False

    for line in cleaned:
        lu = line.upper()

        # PROGRAM-ID
        pid_m = pid_pat.search(lu)
        if pid_m:
            program_id = pid_m.group(1)

        # DIVISION
        dm = div_pat.match(lu)
        if dm:
            current_div = dm.group(1).upper()
            current_sec = None
            current_para = None
            in_procedure = (current_div == 'PROCEDURE')
            in_ws = False
            if current_div not in div_sections:
                divisions.append(current_div)
                div_sections[current_div] = []
            continue

        # SECTION
        sm = sec_pat.match(lu)
        if sm:
            sec_name = sm.group(1).upper()
            current_sec  = sec_name
            current_para = None
            in_ws = (sec_name == 'WORKING-STORAGE')
            if current_div:
                if sec_name not in div_sections.get(current_div, []):
                    div_sections.setdefault(current_div, []).append(sec_name)
            section_paras.setdefault(sec_name, [])
            continue

        # PARAGRAPH (procedure division only)
        if in_procedure:
            pm = para_pat.match(lu)
            if pm:
                pname = pm.group(1).upper().rstrip('.')
                if pname not in COBOL_KEYWORDS and not pname.endswith('SECTION'):
                    current_para = pname
                    if pname not in para_set:
                        para_set.add(pname)
                        para_order.append(pname)
                        para_div[pname] = current_div
                        para_sec[pname] = current_sec or 'PROCEDURE'
                        section_paras.setdefault(current_sec or 'PROCEDURE', []).append(pname)
                    continue

        # Working-storage vars
        if in_ws or (current_div == 'DATA' and current_sec in (None, 'WORKING-STORAGE', 'FILE')):
            wm = ws_pat.match(lu)
            if wm:
                working_storage.append({'level': wm.group(1), 'name': wm.group(2), 'pic': wm.group(3)})
            else:
                lm = level_pat.match(lu)
                if lm and lm.group(2).upper() != 'FILLER':
                    working_storage.append({'level': lm.group(1), 'name': lm.group(2), 'pic': ''})

        # SELECT files
        sel_m = select_pat.search(lu)
        if sel_m and current_div in ('ENVIRONMENT', None):
            fname = sel_m.group(1)
            if fname not in select_files:
                select_files.append(fname)

        # File operations
        for fom in fop_pat.finditer(lu):
            op, fname = fom.group(1).upper(), fom.group(2)
            if fname.upper() not in ('INPUT', 'OUTPUT', 'I-O', 'EXTEND'):
                file_ops.append((op, fname))

        # PERFORM / CALL inside procedure
        if in_procedure and current_para:
            thru_m = thru_pat.search(lu)
            if thru_m:
                perform_edges.append((current_para, thru_m.group(1).upper(), 'THRU', thru_m.group(2).upper()))
            else:
                for pm in perform_pat.finditer(lu):
                    target = pm.group(1).upper()
                    skip_kw = {'UNTIL','VARYING','TIMES','WITH','TEST','INLINE','FOREVER','THROUGH','THRU'}
                    if target not in skip_kw:
                        perform_edges.append((current_para, target, 'PERFORM', None))

            for cm in call_pat.finditer(lu):
                call_edges.append((current_para, cm.group(1)))

        # Metrics
        if if_pat.search(lu):
            if_count += 1
        if eval_pat.search(lu):
            evaluate_count += 1
        if compute_pat.search(lu):
            compute_count += 1
        for mm in move_pat.finditer(lu):
            moves.append(mm.group(1))

    return {
        'program_id':    program_id,
        'divisions':     divisions,
        'div_sections':  div_sections,
        'section_paras': section_paras,
        'para_order':    para_order,
        'para_sec':      para_sec,
        'perform_edges': perform_edges,
        'call_edges':    call_edges,
        'working_storage': working_storage[:25],
        'select_files':  select_files,
        'file_ops':      file_ops[:20],
        'if_count':      if_count,
        'evaluate_count':evaluate_count,
        'compute_count': compute_count,
        'moves':         list(set(moves))[:15],
    }


def extract_entities_from_text(text: str):
    lines = [l.strip() for l in text.strip().split('\n') if l.strip()]
    actors, systems, processes = set(), set(), []
    actor_kw = ['user', 'client', 'customer', 'admin', 'developer', 'team', 'operator', 'manager', 'qa']
    system_kw = ['service', 'api', 'gateway', 'database', 'db', 'server', 'system', 'engine',
                 'queue', 'registry', 'runner', 'scanner', 'monitor', 'cache', 'store', 'repo']

    for i, line in enumerate(lines):
        processes.append(line)
        for w in re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', line):
            wl = w.lower()
            if any(p in wl for p in actor_kw):
                actors.add(w)
            elif any(p in wl for p in system_kw):
                systems.add(w)

    return {
        "processes": processes,
        "actors": list(actors) or ["User"],
        "systems": list(systems) or ["System"],
    }


# ─── SQL DIAGRAM GENERATORS ──────────────────────────────────────────────────

def generate_sql_er_diagram(entities: dict) -> graphviz.Digraph:
    """Generate an Entity-Relationship diagram from SQL."""
    dot = graphviz.Digraph(
        name='ER',
        comment='Entity-Relationship Diagram',
        graph_attr={
            'bgcolor': 'white',
            'fontname': 'Helvetica',
            'rankdir': 'LR',
            'splines': 'curved',
            'pad': '1.0',
            'nodesep': '1.2',
            'ranksep': '2.0',
            'compound': 'true',
        }
    )

    tables = entities.get("tables", {})
    joins = entities.get("joins", [])
    views = entities.get("views", [])
    procedures = entities.get("procedures", [])

    # header color per table, body stays white
    header_colors = ['#4f46e5', '#7c3aed', '#0891b2', '#d97706', '#dc2626', '#059669']

    for i, (tname, tdata) in enumerate(tables.items()):
        hdr = header_colors[i % len(header_colors)]

        col_rows = ""
        for col in tdata.get("columns", [])[:8]:
            icon = "PK" if col.get("pk") else "  "
            col_rows += (
                f'<TR>'
                f'<TD ALIGN="LEFT" BGCOLOR="white"><FONT COLOR="#374151"><B>{icon}</B> {col["name"]}</FONT></TD>'
                f'<TD ALIGN="LEFT" BGCOLOR="white"><FONT COLOR="#6b7280">{col["type"]}</FONT></TD>'
                f'</TR>'
            )
        if not tdata.get("columns"):
            col_rows = '<TR><TD ALIGN="LEFT" BGCOLOR="white" COLSPAN="2"><FONT COLOR="#9ca3af"><I>No columns detected</I></FONT></TD></TR>'

        label = (
            f'<<TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0" BGCOLOR="white" COLOR="{hdr}">'
            f'<TR><TD COLSPAN="2" BGCOLOR="{hdr}" ALIGN="CENTER"><FONT COLOR="white"><B> {tname} </B></FONT></TD></TR>'
            f'{col_rows}'
            f'</TABLE>>'
        )
        dot.node(tname, label=label, shape='none', margin='0')

    for vname in views:
        dot.node(
            f'view_{vname}', label=vname,
            shape='rectangle', style='filled,dashed',
            fillcolor='#f0fdf4', fontcolor='#166534',
            color='#16a34a', fontname='Helvetica-Oblique', fontsize='11'
        )

    for pname in procedures:
        dot.node(
            f'proc_{pname}', label=f'fn: {pname}',
            shape='rectangle', style='filled,rounded',
            fillcolor='#f5f3ff', fontcolor='#4c1d95',
            color='#7c3aed', fontname='Helvetica', fontsize='11'
        )

    drawn = set()
    for left, right, jtype, condition in joins:
        key = (left, right)
        if key in drawn:
            continue
        drawn.add(key)
        if left in tables and right in tables:
            style_map = {
                'FK':    ('#d97706', 'normal', 'solid',  '1→N'),
                'INNER': ('#4f46e5', 'normal', 'solid',  'JOIN'),
                'LEFT':  ('#059669', 'normal', 'dashed', 'LEFT'),
                'RIGHT': ('#db2777', 'normal', 'dashed', 'RIGHT'),
                'FULL':  ('#0891b2', 'normal', 'dotted', 'FULL'),
                'CROSS': ('#ea580c', 'normal', 'dotted', 'CROSS'),
            }
            color, arrow, lstyle, lbl = style_map.get(jtype, ('#6b7280', 'normal', 'solid', jtype))
            dot.edge(left, right, label=lbl, color=color, fontcolor=color,
                     fontsize='9', penwidth='2', style=lstyle, arrowhead=arrow)

    return dot


def generate_sql_query_flow(entities: dict) -> graphviz.Digraph:
    """Generate a query execution / data flow diagram from SQL operations."""
    dot = graphviz.Digraph(
        name='QueryFlow',
        comment='SQL Query Flow',
        graph_attr={
            'bgcolor': 'white',
            'fontname': 'Helvetica',
            'rankdir': 'TB',
            'splines': 'ortho',
            'pad': '0.8',
            'nodesep': '0.9',
            'ranksep': '1.0',
        }
    )

    tables = entities.get("tables", {})
    operations = entities.get("operations", [])
    joins = entities.get("joins", [])
    subqueries = entities.get("subqueries", [])

    with dot.subgraph(name='cluster_sources') as c:
        c.attr(label='Source Tables', style='rounded,filled',
               fillcolor='#eff6ff', color='#3b82f6',
               fontcolor='#1d4ed8', fontname='Helvetica-Bold', fontsize='12')
        for tname in list(tables.keys())[:8]:
            c.node(f'tbl_{tname}', label=f'{tname}',
                   shape='cylinder', style='filled',
                   fillcolor='#dbeafe', fontcolor='#1e3a8a',
                   color='#3b82f6', fontname='Helvetica', fontsize='11')

    op_styles = {
        'SELECT': ('#eff6ff', '#3b82f6', '#1e3a8a', 'ellipse'),
        'INSERT': ('#f0fdf4', '#16a34a', '#14532d', 'rectangle'),
        'UPDATE': ('#fffbeb', '#d97706', '#78350f', 'rectangle'),
        'DELETE': ('#fef2f2', '#dc2626', '#7f1d1d', 'rectangle'),
        'MERGE':  ('#f5f3ff', '#7c3aed', '#3b0764', 'rectangle'),
    }

    for i, (op, tbl) in enumerate(operations[:12]):
        node_id = f'op_{op}_{i}'
        bg, border, text, shape = op_styles.get(op, ('#f8fafc', '#6366f1', '#1e293b', 'ellipse'))
        lbl = f'{op}' + (f'\n→ {tbl}' if tbl else '')
        dot.node(node_id, label=lbl, shape=shape, style='filled,rounded',
                 fillcolor=bg, fontcolor=text, color=border,
                 fontname='Helvetica-Bold', fontsize='11', width='1.8')

        if tbl and tbl in tables:
            if op == 'SELECT':
                dot.edge(f'tbl_{tbl}', node_id, color='#3b82f6', penwidth='1.5', style='dashed')
            else:
                dot.edge(node_id, f'tbl_{tbl}', color=border, penwidth='1.5', style='solid')

        if i > 0:
            prev_id = f'op_{operations[i-1][0]}_{i-1}'
            dot.edge(prev_id, node_id, color='#a5b4fc', penwidth='1.5', style='dotted', arrowsize='0.7')

    for i, (left, right, jtype, cond) in enumerate(joins[:6]):
        jnode = f'join_{i}'
        dot.node(jnode, label=f'{jtype} JOIN\n{left} ↔ {right}',
                 shape='diamond', style='filled',
                 fillcolor='#f5f3ff', fontcolor='#4c1d95',
                 color='#7c3aed', fontname='Helvetica', fontsize='10',
                 width='2.2', height='0.9')
        if left in tables:
            dot.edge(f'tbl_{left}', jnode, color='#7c3aed', penwidth='1.5', style='dashed')
        if right in tables:
            dot.edge(f'tbl_{right}', jnode, color='#7c3aed', penwidth='1.5', style='dashed')

    for sq in subqueries[:4]:
        dot.node(sq, label=f'({sq})', shape='ellipse', style='filled,dashed',
                 fillcolor='#f0fdf4', fontcolor='#166534',
                 color='#16a34a', fontname='Helvetica-Oblique', fontsize='10')

    if operations:
        dot.node('RESULT', label='Result Set\n/ Output',
                 shape='rectangle', style='filled,rounded',
                 fillcolor='#f8fafc', fontcolor='#1e293b',
                 color='#475569', fontname='Helvetica-Bold', fontsize='12', width='2')
        last_op = f'op_{operations[-1][0]}_{len(operations)-1}'
        dot.edge(last_op, 'RESULT', color='#16a34a', penwidth='2.5')

    return dot


# ─── GENERAL DIAGRAM GENERATORS ──────────────────────────────────────────────

def generate_dfd(entities: dict, is_code: bool = False, is_sql: bool = False) -> graphviz.Digraph:
    dot = graphviz.Digraph(
        name='DFD',
        graph_attr={'bgcolor': 'white', 'fontname': 'Helvetica',
                    'rankdir': 'LR', 'splines': 'ortho', 'pad': '0.5',
                    'nodesep': '0.8', 'ranksep': '1.2', 'compound': 'true'}
    )

    if is_sql:
        tables = entities.get("tables", {})
        joins = entities.get("joins", [])
        ops = entities.get("operations", [])
        for tname in list(tables.keys())[:8]:
            dot.node(f'tbl_{tname}', label=f'{tname}',
                     shape='cylinder', style='filled',
                     fillcolor='#dbeafe', fontcolor='#1e3a8a',
                     color='#3b82f6', fontname='Helvetica', fontsize='11')
        op_fill = {'SELECT': '#eff6ff', 'INSERT': '#f0fdf4', 'UPDATE': '#fffbeb',
                   'DELETE': '#fef2f2', 'MERGE': '#f5f3ff'}
        op_border = {'SELECT': '#3b82f6', 'INSERT': '#16a34a', 'UPDATE': '#d97706',
                     'DELETE': '#dc2626', 'MERGE': '#7c3aed'}
        op_text = {'SELECT': '#1e3a8a', 'INSERT': '#14532d', 'UPDATE': '#78350f',
                   'DELETE': '#7f1d1d', 'MERGE': '#3b0764'}
        for i, (op, tbl) in enumerate(ops[:8]):
            f = op_fill.get(op, '#f8fafc')
            b = op_border.get(op, '#6366f1')
            t = op_text.get(op, '#1e293b')
            dot.node(f'op_{i}', label=f'{op}', shape='ellipse', style='filled',
                     fillcolor=f, fontcolor=t, color=b,
                     fontname='Helvetica-Bold', fontsize='11')
            if tbl and tbl in tables:
                dot.edge(f'tbl_{tbl}', f'op_{i}', color=b, penwidth='1.5')
        for left, right, jtype, _ in joins[:6]:
            if left in tables and right in tables:
                dot.edge(f'tbl_{left}', f'tbl_{right}',
                         label=jtype, color='#d97706', penwidth='1.5',
                         fontcolor='#92400e', fontsize='9', style='dashed')
        return dot

    if is_code and entities.get("classes"):
        for cls in entities["classes"]:
            with dot.subgraph(name=f'cluster_{cls["name"]}') as c:
                c.attr(label=cls["name"], style='rounded,filled',
                       fillcolor='#eff6ff', color='#3b82f6',
                       fontcolor='#1e3a8a', fontname='Helvetica-Bold', fontsize='13')
                for method in cls["methods"]:
                    c.node(f'{cls["name"]}.{method}',
                           label=f'method: {method}()',
                           shape='ellipse', style='filled',
                           fillcolor='#dbeafe', fontcolor='#1e3a8a',
                           fontname='Helvetica', fontsize='11', color='#3b82f6')
        for func in entities.get("functions", []):
            dot.node(func, label=f'fn: {func}()',
                     shape='ellipse', style='filled',
                     fillcolor='#f5f3ff', fontcolor='#4c1d95',
                     fontname='Helvetica', fontsize='11', color='#7c3aed')
        for caller, callee in entities.get("calls", []):
            dot.edge(caller, callee, color='#7c3aed', penwidth='2', arrowsize='0.8')
        for imp in entities.get("imports", [])[:5]:
            dot.node(f'import_{imp}', label=f'pkg: {imp}',
                     shape='rectangle', style='filled,dashed',
                     fillcolor='#faf5ff', fontcolor='#6d28d9',
                     fontname='Helvetica', fontsize='10', color='#7c3aed')
        return dot

    processes = entities.get("processes", [])
    actors = entities.get("actors", [])
    systems = entities.get("systems", [])
    step_fills   = ['#eff6ff', '#f5f3ff', '#fdf2f8', '#f0fdf4', '#fffbeb']
    step_borders = ['#3b82f6', '#7c3aed', '#db2777', '#16a34a', '#d97706']
    step_texts   = ['#1e3a8a', '#4c1d95', '#831843', '#14532d', '#78350f']

    for actor in actors[:4]:
        safe = re.sub(r'[^a-zA-Z0-9]', '_', actor)
        dot.node(f'actor_{safe}', label=actor, shape='rectangle', style='filled',
                 fillcolor='#f0fdf4', fontcolor='#14532d', fontname='Helvetica-Bold',
                 fontsize='12', color='#16a34a', width='1.5')
    for i, process in enumerate(processes[:12]):
        label = textwrap.fill(process[:60], width=30)
        fi = step_fills[i % len(step_fills)]
        bo = step_borders[i % len(step_borders)]
        te = step_texts[i % len(step_texts)]
        dot.node(f'proc_{i}', label=label, shape='ellipse', style='filled',
                 fillcolor=fi, fontcolor=te, color=bo,
                 fontname='Helvetica', fontsize='10', width='2.2', height='0.9')
    for sys_name in systems[:4]:
        safe = re.sub(r'[^a-zA-Z0-9]', '_', sys_name)
        dot.node(f'sys_{safe}', label=f'{sys_name}', shape='cylinder', style='filled',
                 fillcolor='#f8fafc', fontcolor='#374151',
                 fontname='Helvetica', fontsize='11', color='#6b7280', width='1.8')
    for i in range(min(len(processes) - 1, 11)):
        dot.edge(f'proc_{i}', f'proc_{i+1}', color='#6366f1', penwidth='2', arrowsize='0.9')
    if actors and processes:
        safe_actor = re.sub(r'[^a-zA-Z0-9]', '_', actors[0])
        dot.edge(f'actor_{safe_actor}', 'proc_0', color='#16a34a', penwidth='2', style='dashed')
    if systems and processes:
        mid = len(processes) // 2
        safe_sys = re.sub(r'[^a-zA-Z0-9]', '_', systems[0])
        dot.edge(f'proc_{mid}', f'sys_{safe_sys}', color='#d97706', penwidth='1.5',
                 style='dotted', label='stores', fontcolor='#92400e', fontsize='9')
    return dot


def generate_sequence_diagram(entities: dict, is_code: bool = False, is_sql: bool = False) -> graphviz.Digraph:
    dot = graphviz.Digraph(
        name='Sequence',
        graph_attr={'bgcolor': 'white', 'fontname': 'Helvetica',
                    'rankdir': 'TB', 'splines': 'ortho', 'pad': '0.8',
                    'nodesep': '1.5', 'ranksep': '0.6'}
    )

    if is_sql:
        tables = list(entities.get("tables", {}).keys())
        ops = entities.get("operations", [])
        participants = ['Application'] + tables[:4] + ['Database']
        steps = [f'{op} on {tbl}' if tbl else op for op, tbl in ops[:10]]
    elif is_code:
        participants = ['Client'] + [cls["name"] for cls in entities.get("classes", [])[:3]] \
                       + entities.get("functions", [])[:2]
        steps = ([f'call {cls["name"]}()' for cls in entities.get("classes", [])[:3]]
                 + [f'{f}()' for f in entities.get("functions", [])[:4]])
    else:
        processes = entities.get("processes", [])
        seen, participants = set(), []
        for line in processes:
            for w in re.findall(r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b', line):
                if w not in seen and len(participants) < 6:
                    seen.add(w); participants.append(w)
        if not participants:
            participants = ['Client', 'API Gateway', 'Service', 'Database']
        steps = processes[:10]

    part_fills   = ['#eff6ff', '#f5f3ff', '#f0fdf4', '#fdf2f8', '#ecfeff', '#fffbeb']
    part_borders = ['#3b82f6', '#7c3aed', '#16a34a', '#db2777', '#0891b2', '#d97706']
    part_texts   = ['#1e3a8a', '#4c1d95', '#14532d', '#831843', '#164e63', '#78350f']
    msg_colors   = ['#6366f1', '#7c3aed', '#16a34a', '#d97706', '#db2777', '#0891b2']

    for i, part in enumerate(participants[:6]):
        dot.node(f'part_{i}', label=part, shape='rectangle', style='filled,rounded',
                 fillcolor=part_fills[i % len(part_fills)],
                 fontcolor=part_texts[i % len(part_texts)],
                 fontname='Helvetica-Bold', fontsize='12',
                 color=part_borders[i % len(part_borders)],
                 width='1.6', height='0.5')

    for i, step in enumerate(steps[:10]):
        src = i % len(participants)
        dst = (i + 1) % len(participants)
        label = textwrap.fill(step[:50], width=28)
        snode = f'step_{i}'
        dot.node(snode, label=f'{i+1}. {label}', shape='note', style='filled',
                 fillcolor='#f8fafc', fontcolor='#1e293b',
                 fontname='Helvetica', fontsize='10',
                 color=msg_colors[i % len(msg_colors)], width='3')
        dot.edge(f'part_{src}', snode, color=msg_colors[i % len(msg_colors)],
                 penwidth='1.5', style='dashed')
        dot.edge(snode, f'part_{dst}', color=msg_colors[i % len(msg_colors)],
                 penwidth='1.5', arrowsize='0.8')
    return dot


def generate_logical_diagram(entities: dict, is_code: bool = False, is_sql: bool = False) -> graphviz.Digraph:
    dot = graphviz.Digraph(
        name='Architecture',
        graph_attr={'bgcolor': 'white', 'fontname': 'Helvetica',
                    'rankdir': 'TB', 'splines': 'curved', 'pad': '1.0',
                    'nodesep': '1.0', 'ranksep': '1.5', 'compound': 'true'}
    )

    if is_sql:
        tables = entities.get("tables", {})
        views = entities.get("views", [])
        procedures = entities.get("procedures", [])
        ops = entities.get("operations", [])

        with dot.subgraph(name='cluster_app') as c:
            c.attr(label='Application Layer', style='rounded,filled',
                   fillcolor='#eff6ff', color='#3b82f6',
                   fontcolor='#1e3a8a', fontname='Helvetica-Bold', fontsize='13')
            c.node('app_client', label='Client App', shape='rectangle',
                   style='filled,rounded', fillcolor='#dbeafe',
                   fontcolor='#1e3a8a', color='#3b82f6', fontname='Helvetica', fontsize='11')
            for op, tbl in list(dict.fromkeys(ops))[:3]:
                c.node(f'dml_{op}', label=f'{op} Ops', shape='ellipse', style='filled',
                       fillcolor='#e0e7ff', fontcolor='#312e81',
                       color='#6366f1', fontname='Helvetica', fontsize='10')
            dot.edge('app_client',
                     'dml_SELECT' if any(o == 'SELECT' for o, _ in ops) else 'app_client',
                     color='#3b82f6', penwidth='2', style='solid')

        with dot.subgraph(name='cluster_db') as c:
            c.attr(label='Database Layer', style='rounded,filled',
                   fillcolor='#f5f3ff', color='#7c3aed',
                   fontcolor='#4c1d95', fontname='Helvetica-Bold', fontsize='13')
            for tname in list(tables.keys())[:6]:
                c.node(tname, label=f'{tname}', shape='cylinder', style='filled',
                       fillcolor='#ede9fe', fontcolor='#4c1d95',
                       color='#7c3aed', fontname='Helvetica', fontsize='11')
            for vname in views[:2]:
                c.node(f'view_{vname}', label=f'view: {vname}', shape='rectangle',
                       style='filled,dashed', fillcolor='#f0fdf4',
                       fontcolor='#166534', color='#16a34a', fontname='Helvetica-Oblique', fontsize='10')

        if procedures:
            with dot.subgraph(name='cluster_procs') as c:
                c.attr(label='Stored Procedures / Functions', style='rounded,filled',
                       fillcolor='#faf5ff', color='#6d28d9',
                       fontcolor='#4c1d95', fontname='Helvetica-Bold', fontsize='13')
                for pname in procedures[:4]:
                    c.node(f'proc_{pname}', label=f'fn: {pname}', shape='rectangle',
                           style='filled,rounded', fillcolor='#ede9fe',
                           fontcolor='#4c1d95', color='#7c3aed', fontname='Helvetica', fontsize='11')
        return dot

    if is_code:
        with dot.subgraph(name='cluster_presentation') as c:
            c.attr(label='Presentation Layer', style='rounded,filled',
                   fillcolor='#eff6ff', color='#3b82f6',
                   fontcolor='#1e3a8a', fontname='Helvetica-Bold', fontsize='13')
            for cls in entities.get("classes", [])[:3]:
                c.node(cls["name"], shape='rectangle', style='filled,rounded',
                       fillcolor='#dbeafe', fontcolor='#1e3a8a', color='#3b82f6',
                       fontname='Helvetica-Bold', fontsize='11')
        with dot.subgraph(name='cluster_logic') as c:
            c.attr(label='Business Logic Layer', style='rounded,filled',
                   fillcolor='#f5f3ff', color='#7c3aed',
                   fontcolor='#4c1d95', fontname='Helvetica-Bold', fontsize='13')
            for func in entities.get("functions", [])[:4]:
                c.node(func, shape='ellipse', style='filled',
                       fillcolor='#ede9fe', fontcolor='#4c1d95', color='#7c3aed',
                       fontname='Helvetica', fontsize='11')
        with dot.subgraph(name='cluster_data') as c:
            c.attr(label='Data / External Layer', style='rounded,filled',
                   fillcolor='#f8fafc', color='#64748b',
                   fontcolor='#374151', fontname='Helvetica-Bold', fontsize='13')
            for imp in entities.get("imports", [])[:4]:
                c.node(f'dep_{imp}', label=imp, shape='cylinder', style='filled',
                       fillcolor='#f1f5f9', fontcolor='#374151', color='#64748b',
                       fontname='Helvetica', fontsize='10')
        for caller, callee in entities.get("calls", [])[:8]:
            dot.edge(caller, callee, color='#6366f1', penwidth='2', arrowsize='0.8')
        return dot

    processes = entities.get("processes", [])
    layers = {'Client Layer': [], 'API / Gateway Layer': [], 'Business Logic Layer': [], 'Data Layer': []}
    for proc in processes[:12]:
        pl = proc.lower()
        if any(k in pl for k in ['user', 'client', 'customer', 'browser', 'frontend']):
            layers['Client Layer'].append(proc)
        elif any(k in pl for k in ['api', 'gateway', 'router', 'load balancer', 'proxy']):
            layers['API / Gateway Layer'].append(proc)
        elif any(k in pl for k in ['database', 'db', 'storage', 'queue', 'cache', 'store']):
            layers['Data Layer'].append(proc)
        else:
            layers['Business Logic Layer'].append(proc)

    layer_styles = {
        'Client Layer':         ('#eff6ff', '#3b82f6', '#dbeafe', '#1e3a8a'),
        'API / Gateway Layer':  ('#f5f3ff', '#7c3aed', '#ede9fe', '#4c1d95'),
        'Business Logic Layer': ('#f0fdf4', '#16a34a', '#dcfce7', '#14532d'),
        'Data Layer':           ('#f8fafc', '#64748b', '#f1f5f9', '#374151'),
    }
    prev = None
    for layer_name, items in layers.items():
        if not items:
            continue
        safe_layer = re.sub(r'[^a-zA-Z0-9]', '_', layer_name)
        cluster_fill, border_c, node_fill, text_c = layer_styles[layer_name]
        with dot.subgraph(name=f'cluster_{safe_layer}') as c:
            c.attr(label=layer_name, style='rounded,filled',
                   fillcolor=cluster_fill, color=border_c,
                   fontcolor=text_c, fontname='Helvetica-Bold', fontsize='13')
            first = None
            for j, item in enumerate(items[:4]):
                nid = f'{safe_layer}_{j}'
                if j == 0: first = nid
                c.node(nid, label=textwrap.fill(item[:50], width=25),
                       shape='rectangle', style='filled,rounded',
                       fillcolor=node_fill, fontcolor=text_c, color=border_c,
                       fontname='Helvetica', fontsize='10', width='2.2')
                if j > 0:
                    c.edge(f'{safe_layer}_{j-1}', nid, color=border_c, penwidth='1.5', style='dashed')
            if prev and first:
                dot.edge(prev, first, color='#6366f1', penwidth='2.5',
                         style='solid', arrowsize='1', lhead=f'cluster_{safe_layer}')
            if first: prev = first
    return dot


def generate_flowchart(entities: dict, is_code: bool = False, is_sql: bool = False) -> graphviz.Digraph:
    dot = graphviz.Digraph(
        name='Flowchart',
        graph_attr={'bgcolor': 'white', 'fontname': 'Helvetica',
                    'rankdir': 'TB', 'splines': 'ortho', 'pad': '0.8',
                    'nodesep': '0.7', 'ranksep': '0.8'}
    )
    dot.node('START', 'START', shape='oval', style='filled', fillcolor='#dcfce7',
             fontcolor='#14532d', fontname='Helvetica-Bold', fontsize='13', color='#16a34a')

    if is_sql:
        processes = [f'{op} on {tbl}' if tbl else op
                     for op, tbl in entities.get("operations", [])]
        processes = processes or [f'Access {t}' for t in list(entities.get("tables", {}).keys())[:6]]
    elif is_code:
        processes = [f'{cls["name"]} class' for cls in entities.get("classes", [])] \
                    + entities.get("functions", [])
    else:
        processes = entities.get("processes", [])

    decision_kw = ['validate', 'check', 'verify', 'if', 'whether', 'valid', 'exists',
                   'success', 'error', 'fail', 'approve', 'reject', 'available', 'where']
    step_fills   = ['#eff6ff', '#f5f3ff', '#f0fdf4', '#ecfeff', '#fffbeb']
    step_borders = ['#3b82f6', '#7c3aed', '#16a34a', '#0891b2', '#d97706']
    step_texts   = ['#1e3a8a', '#4c1d95', '#14532d', '#164e63', '#78350f']

    prev, dec_count = 'START', 0
    for i, proc in enumerate(processes[:12]):
        label = textwrap.fill(proc[:55], width=28)
        pid = f'proc_{i}'
        if any(kw in proc.lower() for kw in decision_kw):
            dot.node(pid, label=label + '?', shape='diamond', style='filled',
                     fillcolor='#fdf2f8', fontcolor='#831843',
                     color='#db2777', fontname='Helvetica', fontsize='10',
                     width='2.5', height='1.2')
            dot.edge(prev, pid, color='#6366f1', penwidth='2')
            if i + 1 < len(processes):
                dot.edge(pid, f'proc_{i+1}', color='#16a34a', penwidth='1.5',
                         label='Yes', fontcolor='#14532d', fontsize='9')
            fid = f'fail_{dec_count}'
            dot.node(fid, 'Error /\nRollback', shape='rectangle', style='filled,rounded',
                     fillcolor='#fef2f2', fontcolor='#7f1d1d',
                     color='#dc2626', fontname='Helvetica', fontsize='10')
            dot.edge(pid, fid, color='#dc2626', penwidth='1.5',
                     label='No', fontcolor='#7f1d1d', fontsize='9', style='dashed')
            dec_count += 1
        else:
            fi = step_fills[i % len(step_fills)]
            bo = step_borders[i % len(step_borders)]
            te = step_texts[i % len(step_texts)]
            dot.node(pid, label=label, shape='rectangle', style='filled,rounded',
                     fillcolor=fi, fontcolor=te, color=bo,
                     fontname='Helvetica', fontsize='11', width='2.8')
            dot.edge(prev, pid, color='#6366f1', penwidth='2', arrowsize='0.9')
        prev = pid

    dot.node('END', 'END', shape='oval', style='filled', fillcolor='#ede9fe',
             fontcolor='#4c1d95', fontname='Helvetica-Bold', fontsize='13', color='#7c3aed')
    dot.edge(prev, 'END', color='#7c3aed', penwidth='2.5')
    return dot


def generate_cobol_structure_diagram(entities: dict) -> graphviz.Digraph:
    """Hierarchical program structure: Program → Divisions → Sections → Paragraphs."""
    dot = graphviz.Digraph(
        name='COBOLStruct',
        graph_attr={
            'bgcolor':   'white',
            'fontname':  'Helvetica',
            'rankdir':   'TB',
            'splines':   'ortho',
            'pad':       '0.8',
            'nodesep':   '0.5',
            'ranksep':   '0.8',
        }
    )

    prog = entities.get('program_id', 'PROGRAM')
    div_sections  = entities.get('div_sections', {})
    section_paras = entities.get('section_paras', {})
    select_files  = entities.get('select_files', [])
    call_edges    = entities.get('call_edges', [])

    # ── Division colour palette ──
    div_colors = {
        'IDENTIFICATION': ('#4f46e5', '#eff6ff'),
        'ENVIRONMENT':    ('#0891b2', '#ecfeff'),
        'DATA':           ('#d97706', '#fffbeb'),
        'PROCEDURE':      ('#059669', '#f0fdf4'),
    }
    default_dc = ('#6366f1', '#f5f3ff')

    # Programme root node
    dot.node(
        'PROG_ROOT',
        label=f'<<B>{prog}</B>>',
        shape='rectangle', style='filled,rounded',
        fillcolor='#1e293b', fontcolor='white',
        fontname='Helvetica-Bold', fontsize='14', color='#0f172a',
        width='2.5', height='0.6'
    )

    for div in entities.get('divisions', []):
        border, bg = div_colors.get(div, default_dc)
        div_id = f'DIV_{div}'
        dot.node(
            div_id,
            label=f'{div} DIVISION',
            shape='rectangle', style='filled',
            fillcolor=bg, fontcolor=border,
            fontname='Helvetica-Bold', fontsize='11',
            color=border, penwidth='2'
        )
        dot.edge('PROG_ROOT', div_id, color=border, penwidth='2', arrowhead='open')

        secs = div_sections.get(div, [])
        if not secs:
            continue
        for sec in secs:
            sec_id = f'SEC_{div}_{sec}'
            dot.node(
                sec_id,
                label=sec,
                shape='rectangle', style='filled,rounded',
                fillcolor='#ffffff', fontcolor='#374151',
                fontname='Helvetica', fontsize='10',
                color=border, penwidth='1.5'
            )
            dot.edge(div_id, sec_id, color='#94a3b8', penwidth='1.5', arrowhead='open')

            paras = section_paras.get(sec, [])[:12]
            for para in paras:
                para_id = f'PARA_{para}'
                dot.node(
                    para_id,
                    label=para,
                    shape='rectangle', style='filled,rounded',
                    fillcolor='#f8fafc', fontcolor='#1e293b',
                    fontname='Helvetica', fontsize='9',
                    color='#cbd5e1', penwidth='1'
                )
                dot.edge(sec_id, para_id, color='#cbd5e1', penwidth='1', arrowhead='open')

        # If PROCEDURE div has paragraphs not under any section
        if div == 'PROCEDURE':
            direct_paras = section_paras.get('PROCEDURE', [])[:10]
            for para in direct_paras:
                para_id = f'PARA_{para}'
                dot.node(
                    para_id,
                    label=para,
                    shape='rectangle', style='filled,rounded',
                    fillcolor='#f0fdf4', fontcolor='#065f46',
                    fontname='Helvetica', fontsize='9',
                    color='#6ee7b7', penwidth='1'
                )
                dot.edge(div_id, para_id, color='#6ee7b7', penwidth='1', arrowhead='open')

    # File nodes (ENVIRONMENT)
    if select_files:
        with dot.subgraph(name='cluster_files') as cf:
            cf.attr(label='Files', style='filled', fillcolor='#fffbeb', color='#d97706')
            for fname in select_files[:8]:
                fid = f'FILE_{fname}'
                cf.node(
                    fid, label=fname,
                    shape='cylinder', style='filled',
                    fillcolor='#fef3c7', fontcolor='#92400e',
                    color='#d97706', fontsize='9', fontname='Helvetica'
                )
                env_id = 'DIV_ENVIRONMENT'
                if 'ENVIRONMENT' in entities.get('divisions', []):
                    dot.edge(env_id, fid, color='#d97706', style='dashed', arrowhead='none')

    # External CALL nodes
    ext_progs = list({callee for _, callee in call_edges})
    if ext_progs:
        with dot.subgraph(name='cluster_ext') as ce:
            ce.attr(label='External Calls', style='filled', fillcolor='#fdf4ff', color='#9333ea')
            for ep in ext_progs[:6]:
                ce.node(
                    f'EXT_{ep}', label=ep,
                    shape='rectangle', style='filled,rounded',
                    fillcolor='#fae8ff', fontcolor='#6b21a8',
                    color='#9333ea', fontsize='9', fontname='Helvetica-Oblique'
                )

    return dot


def generate_cobol_flow_diagram(entities: dict) -> graphviz.Digraph:
    """Paragraph-level control flow driven by PERFORM statements."""
    dot = graphviz.Digraph(
        name='COBOLFlow',
        graph_attr={
            'bgcolor':  'white',
            'fontname': 'Helvetica',
            'rankdir':  'TB',
            'splines':  'curved',
            'pad':      '0.8',
            'nodesep':  '0.7',
            'ranksep':  '1.0',
        }
    )

    para_order    = entities.get('para_order', [])
    perform_edges = entities.get('perform_edges', [])
    call_edges    = entities.get('call_edges', [])
    prog          = entities.get('program_id', 'PROGRAM')
    para_sec      = entities.get('para_sec', {})
    select_files  = entities.get('select_files', [])

    if not para_order:
        dot.node('EMPTY', 'No paragraphs found', shape='note',
                 fillcolor='#fef9c3', style='filled', fontcolor='#92400e')
        return dot

    # Colour per section prefix (0000-, 1000-, 2000-, …)
    def para_color(pname):
        prefix_colors = [
            ('#dbeafe', '#1d4ed8'), ('#dcfce7', '#15803d'),
            ('#fef3c7', '#b45309'), ('#fce7f3', '#9d174d'),
            ('#ede9fe', '#5b21b6'), ('#ecfeff', '#0e7490'),
            ('#fff7ed', '#c2410c'), ('#f0fdf4', '#166534'),
        ]
        try:
            digit = int(pname[0])
            return prefix_colors[digit % len(prefix_colors)]
        except (ValueError, IndexError):
            return ('#f8fafc', '#334155')

    # Group paragraphs into subgraphs by section
    sec_groups: dict[str, list] = {}
    for p in para_order:
        sec = para_sec.get(p, 'PROCEDURE')
        sec_groups.setdefault(sec, []).append(p)

    rendered_paras = set()
    for sec, paras in sec_groups.items():
        with dot.subgraph(name=f'cluster_{sec}') as sg:
            sg.attr(
                label=sec, style='filled',
                fillcolor='#f8fafc', color='#e2e8f0',
                fontname='Helvetica-Bold', fontsize='10', fontcolor='#475569'
            )
            for p in paras[:20]:
                bg, fg = para_color(p)
                sg.node(
                    p, label=p,
                    shape='rectangle', style='filled,rounded',
                    fillcolor=bg, fontcolor=fg,
                    fontname='Helvetica', fontsize='10',
                    color=fg, penwidth='1.5'
                )
                rendered_paras.add(p)

    # Add any paragraphs not in a section group
    for p in para_order:
        if p not in rendered_paras:
            bg, fg = para_color(p)
            dot.node(
                p, label=p,
                shape='rectangle', style='filled,rounded',
                fillcolor=bg, fontcolor=fg,
                fontname='Helvetica', fontsize='10',
                color=fg, penwidth='1.5'
            )
            rendered_paras.add(p)

    # PERFORM edges
    drawn_edges = set()
    for caller, callee, etype, thru_end in perform_edges:
        if callee not in rendered_paras:
            bg, fg = para_color(callee)
            dot.node(
                callee, label=callee,
                shape='rectangle', style='filled,rounded,dashed',
                fillcolor='#f1f5f9', fontcolor='#64748b',
                fontname='Helvetica', fontsize='9', color='#94a3b8'
            )
            rendered_paras.add(callee)

        key = (caller, callee, etype)
        if key in drawn_edges:
            continue
        drawn_edges.add(key)

        if etype == 'THRU':
            lbl = f'THRU {thru_end}' if thru_end else 'THRU'
            dot.edge(caller, callee, label=lbl,
                     color='#7c3aed', fontcolor='#7c3aed', fontsize='8',
                     penwidth='2', style='dashed', arrowhead='normal')
        else:
            dot.edge(caller, callee,
                     color='#2563eb', penwidth='1.8', arrowhead='normal')

    # External CALL edges
    for caller, ext_prog in call_edges:
        ext_id = f'EXT_{ext_prog}'
        if ext_id not in rendered_paras:
            dot.node(
                ext_id, label=f'CALL\n{ext_prog}',
                shape='rectangle', style='filled,rounded',
                fillcolor='#fae8ff', fontcolor='#6b21a8',
                fontname='Helvetica-Oblique', fontsize='9',
                color='#9333ea', penwidth='1.5'
            )
            rendered_paras.add(ext_id)
        dot.edge(caller, ext_id,
                 color='#9333ea', style='dotted', penwidth='2', arrowhead='normal',
                 label='CALL', fontcolor='#9333ea', fontsize='8')

    # File I/O nodes
    file_paras: dict[str, set] = {}
    for op, fname in entities.get('file_ops', []):
        fname_u = fname.upper()
        if fname_u not in ('INPUT', 'OUTPUT', 'I-O', 'EXTEND'):
            file_paras.setdefault(fname_u, set()).add(op)

    for fname, ops in list(file_paras.items())[:6]:
        fid = f'FILE_{fname}'
        op_str = '/'.join(sorted(ops)[:3])
        dot.node(
            fid, label=f'{fname}\n[{op_str}]',
            shape='cylinder', style='filled',
            fillcolor='#fef9c3', fontcolor='#92400e',
            fontname='Helvetica', fontsize='9', color='#d97706', penwidth='1.5'
        )

    return dot


def generate_cobol_block_diagram(entities: dict) -> graphviz.Digraph:
    """Nested block diagram: Program → Divisions (clusters) → Sections → Paragraphs."""
    dot = graphviz.Digraph(
        name='COBOLBlock',
        graph_attr={
            'bgcolor':   'white',
            'fontname':  'Helvetica',
            'rankdir':   'LR',
            'compound':  'true',
            'splines':   'ortho',
            'pad':       '0.6',
            'nodesep':   '0.4',
            'ranksep':   '1.0',
            'newrank':   'true',
        }
    )

    prog          = entities.get('program_id', 'PROGRAM')
    div_sections  = entities.get('div_sections', {})
    section_paras = entities.get('section_paras', {})
    divisions     = entities.get('divisions', [])
    select_files  = entities.get('select_files', [])
    call_edges    = entities.get('call_edges', [])
    working_storage = entities.get('working_storage', [])

    div_cfg = {
        'IDENTIFICATION': ('#4f46e5', '#eff6ff', '#c7d2fe'),
        'ENVIRONMENT':    ('#0891b2', '#ecfeff', '#a5f3fc'),
        'DATA':           ('#d97706', '#fffbeb', '#fde68a'),
        'PROCEDURE':      ('#059669', '#f0fdf4', '#a7f3d0'),
    }
    default_cfg = ('#6366f1', '#f5f3ff', '#c4b5fd')

    # Root program block
    dot.node(
        '__ROOT__', label=f'PROGRAM\n{prog}',
        shape='rectangle', style='filled,rounded',
        fillcolor='#1e293b', fontcolor='white',
        fontname='Helvetica-Bold', fontsize='13',
        color='#0f172a', width='2.2', height='0.7'
    )

    for div in divisions:
        fg, bg, border_fill = div_cfg.get(div, default_cfg)
        with dot.subgraph(name=f'cluster_{div}') as cd:
            cd.attr(
                label=f'{div} DIVISION',
                style='filled', fillcolor=bg,
                color=fg, fontcolor=fg,
                fontname='Helvetica-Bold', fontsize='11',
                penwidth='2'
            )
            # Invisible anchor node for the cluster
            anchor = f'_anchor_{div}'
            cd.node(anchor, label='', shape='point', width='0', style='invis')

            secs = div_sections.get(div, [])
            if secs:
                for sec in secs:
                    with cd.subgraph(name=f'cluster_{div}_{sec}') as cs:
                        cs.attr(
                            label=sec, style='filled',
                            fillcolor='white', color=fg,
                            fontname='Helvetica', fontsize='10',
                            fontcolor='#374151', penwidth='1.5'
                        )
                        # Show paragraphs (max 10 per section)
                        paras = section_paras.get(sec, [])[:10]
                        if paras:
                            for p in paras:
                                cs.node(
                                    f'blk_{p}', label=p,
                                    shape='rectangle', style='filled,rounded',
                                    fillcolor=border_fill, fontcolor='#1e293b',
                                    fontname='Helvetica', fontsize='9',
                                    color=fg, penwidth='1'
                                )
                        else:
                            cs.node(f'_sec_{div}_{sec}', label='(no paragraphs)',
                                    shape='note', style='filled', fillcolor='#f8fafc',
                                    fontcolor='#94a3b8', fontsize='8', color='#e2e8f0')

                    # Direct PROCEDURE paras (no section)
            if div == 'PROCEDURE':
                direct = section_paras.get('PROCEDURE', [])[:10]
                for p in direct:
                    pid = f'blk_{p}'
                    if pid not in [n for n in dot.body]:
                        cd.node(
                            pid, label=p,
                            shape='rectangle', style='filled,rounded',
                            fillcolor=border_fill, fontcolor='#1e293b',
                            fontname='Helvetica', fontsize='9',
                            color=fg, penwidth='1'
                        )

            # DATA div: show top Working-Storage items
            if div == 'DATA':
                ws_01 = [v for v in working_storage if v['level'] in ('01', '77')][:8]
                for v in ws_01:
                    lbl = f'{v["name"]}\nPIC {v["pic"]}' if v.get("pic") else v["name"]
                    cd.node(
                        f'ws_{v["name"]}', label=lbl,
                        shape='rectangle', style='filled',
                        fillcolor='#fef3c7', fontcolor='#92400e',
                        fontname='Helvetica', fontsize='8',
                        color='#d97706', penwidth='1'
                    )

            # ENVIRONMENT div: show files
            if div == 'ENVIRONMENT':
                for fname in select_files[:6]:
                    cd.node(
                        f'env_{fname}', label=fname,
                        shape='cylinder', style='filled',
                        fillcolor='#cffafe', fontcolor='#164e63',
                        fontname='Helvetica', fontsize='9',
                        color='#0891b2', penwidth='1'
                    )

        dot.edge('__ROOT__', anchor,
                 color=fg, penwidth='1.5',
                 lhead=f'cluster_{div}', arrowhead='open')

    # External programs
    ext_progs = list({c for _, c in call_edges})[:5]
    if ext_progs:
        with dot.subgraph(name='cluster_ext') as ce:
            ce.attr(label='External Programs', style='filled',
                    fillcolor='#fdf4ff', color='#9333ea',
                    fontname='Helvetica', fontsize='10', fontcolor='#6b21a8')
            for ep in ext_progs:
                ce.node(f'ext_{ep}', label=ep,
                        shape='rectangle', style='filled,rounded',
                        fillcolor='#fae8ff', fontcolor='#6b21a8',
                        fontname='Helvetica-Oblique', fontsize='9',
                        color='#9333ea', penwidth='1')

    return dot


def generate_cobol_functional_tree(entities: dict) -> graphviz.Digraph:
    """Functional decomposition tree — PERFORM call hierarchy from root."""
    dot = graphviz.Digraph(
        name='COBOLFuncTree',
        graph_attr={
            'bgcolor':  'white',
            'fontname': 'Helvetica',
            'rankdir':  'TB',
            'splines':  'polyline',
            'pad':      '0.8',
            'nodesep':  '0.6',
            'ranksep':  '1.2',
        }
    )

    para_order    = entities.get('para_order', [])
    perform_edges = entities.get('perform_edges', [])
    call_edges    = entities.get('call_edges', [])
    prog          = entities.get('program_id', 'PROGRAM')

    if not para_order:
        dot.node('E', 'No paragraphs found', shape='note',
                 fillcolor='#fef9c3', style='filled', fontcolor='#92400e')
        return dot

    # Build caller → [callees] map
    call_map: dict[str, list] = {}
    for caller, callee, etype, _ in perform_edges:
        call_map.setdefault(caller, [])
        if callee not in call_map[caller]:
            call_map[caller].append(callee)

    # Root = first paragraph (usually 0000-MAIN or similar)
    root = para_order[0]

    # BFS to determine tree levels (limit depth to avoid infinite loops)
    levels: dict[str, int] = {root: 0}
    queue = [root]
    visited = {root}
    while queue:
        node = queue.pop(0)
        for child in call_map.get(node, []):
            if child not in visited and child in set(para_order):
                visited.add(child)
                levels[child] = levels[node] + 1
                queue.append(child)

    # Add orphan paragraphs (not reachable from root) at depth 1
    for p in para_order:
        if p not in levels:
            levels[p] = 1

    # Colour by depth
    depth_colors = [
        ('#1e293b', 'white'),    # 0 — root
        ('#1d4ed8', '#dbeafe'),  # 1
        ('#15803d', '#dcfce7'),  # 2
        ('#b45309', '#fef3c7'),  # 3
        ('#9d174d', '#fce7f3'),  # 4
        ('#5b21b6', '#ede9fe'),  # 5+
    ]

    def depth_color(d):
        return depth_colors[min(d, len(depth_colors) - 1)]

    # Program root node
    dot.node(
        '__PROG__', label=f'⬛  {prog}',
        shape='rectangle', style='filled,rounded',
        fillcolor='#0f172a', fontcolor='white',
        fontname='Helvetica-Bold', fontsize='14',
        color='#0f172a', width='2.5', height='0.65'
    )
    dot.edge('__PROG__', root, color='#334155', penwidth='2.5', arrowhead='open')

    for p in para_order:
        d = levels.get(p, 99)
        fg, bg = depth_color(d)
        is_root = (p == root)
        dot.node(
            p,
            label=p,
            shape='rectangle',
            style='filled,rounded' + (',bold' if is_root else ''),
            fillcolor=fg if is_root else bg,
            fontcolor=('white' if is_root else fg),
            fontname='Helvetica-Bold' if d <= 1 else 'Helvetica',
            fontsize='11' if d <= 1 else '10',
            color=fg, penwidth='2' if d <= 1 else '1.5'
        )

    # Edges (PERFORM hierarchy)
    drawn = set()
    for caller, callee, etype, thru_end in perform_edges:
        key = (caller, callee)
        if key in drawn:
            continue
        drawn.add(key)
        c_fg, _ = depth_color(levels.get(caller, 0))
        if etype == 'THRU':
            dot.edge(caller, callee,
                     label=f'THRU\n{thru_end}' if thru_end else 'THRU',
                     color='#7c3aed', fontcolor='#7c3aed',
                     style='dashed', penwidth='1.8',
                     fontsize='8', arrowhead='normal')
        else:
            dot.edge(caller, callee, color=c_fg, penwidth='1.5', arrowhead='normal')

    # CALLs to external programs
    for caller, ext in call_edges:
        ext_id = f'EXT_{ext}'
        dot.node(ext_id, label=f'CALL\n{ext}',
                 shape='rectangle', style='filled,rounded',
                 fillcolor='#fae8ff', fontcolor='#6b21a8',
                 fontname='Helvetica-Oblique', fontsize='9',
                 color='#9333ea', penwidth='1.5')
        dot.edge(caller, ext_id, color='#9333ea', style='dotted',
                 penwidth='1.5', arrowhead='open', label='CALL',
                 fontcolor='#9333ea', fontsize='8')

    return dot


def generate_cobol_file_io_diagram(entities: dict) -> graphviz.Digraph:
    """File I/O diagram — shows which paragraphs interact with which files and how."""
    dot = graphviz.Digraph(
        name='COBOLFileIO',
        graph_attr={
            'bgcolor':  'white',
            'fontname': 'Helvetica',
            'rankdir':  'LR',
            'splines':  'curved',
            'pad':      '1.0',
            'nodesep':  '0.8',
            'ranksep':  '2.0',
        }
    )

    prog         = entities.get('program_id', 'PROGRAM')
    select_files = entities.get('select_files', [])
    file_ops     = entities.get('file_ops', [])
    para_order   = entities.get('para_order', [])
    para_sec     = entities.get('para_sec', {})

    # Map: para → {file → [ops]}
    para_file_ops: dict[str, dict[str, list]] = {}
    for op, fname in file_ops:
        fname_u = fname.upper()
        if fname_u in ('INPUT', 'OUTPUT', 'I-O', 'EXTEND'):
            continue
        # We don't have per-paragraph breakdown from parser, so group generically
        para_file_ops.setdefault('_ALL_', {}).setdefault(fname_u, set()).add(op)

    # Rebuild: use perform_edges info to infer which para does which op.
    # Since the parser stores file_ops as (op, file) without paragraph context,
    # we'll group operations by type and show them on a central "Procedure" node.
    # For a richer view, split ops by READ/WRITE vs OPEN/CLOSE.

    op_colors = {
        'READ':    ('#2563eb', '#dbeafe', '→'),
        'WRITE':   ('#dc2626', '#fee2e2', '←'),
        'REWRITE': ('#d97706', '#fef3c7', '↕'),
        'OPEN':    ('#059669', '#d1fae5', '▷'),
        'CLOSE':   ('#6b7280', '#f3f4f6', '▣'),
        'DELETE':  ('#9333ea', '#fae8ff', '✕'),
        'START':   ('#0891b2', '#ecfeff', '▶'),
    }

    # Program / procedure box
    dot.node(
        '__PROC__',
        label=f'<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="2">'
              f'<TR><TD><FONT POINT-SIZE="13"><B>{prog}</B></FONT></TD></TR>'
              f'<TR><TD><FONT COLOR="#475569" POINT-SIZE="9">PROCEDURE DIVISION</FONT></TD></TR>'
              f'</TABLE>>',
        shape='rectangle', style='filled,rounded',
        fillcolor='#f0fdf4', fontcolor='#065f46',
        color='#059669', penwidth='2', fontname='Helvetica'
    )

    # Paragraph nodes (active ones — those that interact with files, or all if none known)
    active_paras = para_order[:15]
    if active_paras:
        for p in active_paras:
            dot.node(
                f'para_{p}', label=p,
                shape='rectangle', style='filled,rounded',
                fillcolor='#f0fdf4', fontcolor='#065f46',
                fontname='Helvetica', fontsize='9',
                color='#6ee7b7', penwidth='1'
            )
            dot.edge('__PROC__', f'para_{p}', color='#a7f3d0',
                     penwidth='1', arrowhead='none', style='dotted')

    # File nodes on the right
    if not select_files:
        # Derive from file_ops
        select_files = list({f.upper() for _, f in file_ops
                             if f.upper() not in ('INPUT','OUTPUT','I-O','EXTEND')})

    for fname in select_files[:10]:
        dot.node(
            f'file_{fname}', label=fname,
            shape='cylinder', style='filled',
            fillcolor='#fffbeb', fontcolor='#92400e',
            fontname='Helvetica-Bold', fontsize='11',
            color='#d97706', penwidth='2', width='1.5'
        )

    # Gather unique (op, file) combos and draw edges
    op_file_set: dict[str, set] = {}
    for op, fname in file_ops:
        fname_u = fname.upper()
        if fname_u in ('INPUT', 'OUTPUT', 'I-O', 'EXTEND'):
            continue
        op_file_set.setdefault(fname_u, set()).add(op.upper())

    for fname_u, ops in op_file_set.items():
        file_node = f'file_{fname_u}'
        # Make sure file node exists even if not in SELECT list
        if f'file_{fname_u}' not in []:
            dot.node(
                file_node, label=fname_u,
                shape='cylinder', style='filled',
                fillcolor='#fffbeb', fontcolor='#92400e',
                fontname='Helvetica-Bold', fontsize='11',
                color='#d97706', penwidth='2', width='1.5'
            )

        for op in sorted(ops):
            fg, bg, sym = op_colors.get(op, ('#475569', '#f8fafc', '→'))
            is_read = op in ('READ', 'START')
            dot.edge(
                (file_node if is_read else '__PROC__'),
                ('__PROC__' if is_read else file_node),
                label=f' {sym} {op} ',
                color=fg, fontcolor=fg,
                fontname='Helvetica-Bold', fontsize='10',
                penwidth='2.5', arrowhead='normal',
                style='solid'
            )

    # If no file ops at all, show a hint
    if not file_ops and not select_files:
        dot.node('HINT', 'No file operations found\nin this COBOL program',
                 shape='note', style='filled',
                 fillcolor='#fef9c3', fontcolor='#92400e',
                 fontsize='10', color='#d97706')

    return dot


def generate_cobol_flowchart(entities: dict) -> graphviz.Digraph:
    """Detailed flowchart: execution path through paragraphs with decision points."""
    dot = graphviz.Digraph(
        name='COBOLFlowchart',
        graph_attr={
            'bgcolor':  'white',
            'fontname': 'Helvetica',
            'rankdir':  'TB',
            'splines':  'ortho',
            'pad':      '0.8',
            'nodesep':  '0.5',
            'ranksep':  '0.9',
        }
    )

    para_order    = entities.get('para_order', [])
    perform_edges = entities.get('perform_edges', [])
    call_edges    = entities.get('call_edges', [])
    if_count      = entities.get('if_count', 0)
    evaluate_count= entities.get('evaluate_count', 0)
    file_ops      = entities.get('file_ops', [])
    prog          = entities.get('program_id', 'PROGRAM')
    select_files  = entities.get('select_files', [])

    if not para_order:
        dot.node('E', 'No paragraphs found', shape='note',
                 fillcolor='#fef9c3', style='filled', fontcolor='#92400e')
        return dot

    # START terminal
    dot.node('__START__', f'START\n{prog}',
             shape='oval', style='filled',
             fillcolor='#1e293b', fontcolor='white',
             fontname='Helvetica-Bold', fontsize='12',
             color='#0f172a', width='2.0')

    # Build a set of "called" paragraphs (appear as PERFORM targets)
    called_set = {callee for _, callee, _, _ in perform_edges}

    # Build caller→callees map
    call_map: dict[str, list] = {}
    for caller, callee, etype, thru in perform_edges:
        call_map.setdefault(caller, []).append((callee, etype, thru))

    # Categorise each paragraph
    def para_kind(p):
        """open/close=I/O, calc=compute/math, read/write=file, cond=if/eval, else=process"""
        pu = p.upper()
        if any(k in pu for k in ('INIT', 'OPEN', 'START', 'SETUP')):
            return 'init'
        if any(k in pu for k in ('READ', 'GET', 'INPUT', 'LOAD')):
            return 'io_in'
        if any(k in pu for k in ('WRITE', 'PRINT', 'OUTPUT', 'REPORT', 'SAVE')):
            return 'io_out'
        if any(k in pu for k in ('CALC', 'COMPUTE', 'MATH', 'SUM', 'TAX', 'NET', 'GROSS', 'PAY')):
            return 'calc'
        if any(k in pu for k in ('VALID', 'CHECK', 'VERIFY', 'TEST')):
            return 'decision'
        if any(k in pu for k in ('CLOSE', 'FINAL', 'END', 'TERMINAT', 'FINISH')):
            return 'final'
        if any(k in pu for k in ('UPDATE', 'PROCESS', 'MAIN')):
            return 'process'
        return 'process'

    kind_style = {
        'init':     ('#dbeafe', '#1d4ed8', 'rectangle'),
        'io_in':    ('#d1fae5', '#065f46', 'parallelogram'),
        'io_out':   ('#fef3c7', '#92400e', 'parallelogram'),
        'calc':     ('#ede9fe', '#5b21b6', 'rectangle'),
        'decision': ('#fce7f3', '#9d174d', 'diamond'),
        'final':    ('#f1f5f9', '#334155', 'rectangle'),
        'process':  ('#f0fdf4', '#065f46', 'rectangle'),
    }

    # Render each paragraph
    para_nodes = set()
    for p in para_order[:30]:
        kind = para_kind(p)
        bg, fg, shape = kind_style.get(kind, ('#f8fafc', '#1e293b', 'rectangle'))
        is_root = (p == para_order[0])
        dot.node(
            p, label=p,
            shape=shape, style='filled,rounded' if shape == 'rectangle' else 'filled',
            fillcolor='#1e293b' if is_root else bg,
            fontcolor='white' if is_root else fg,
            fontname='Helvetica-Bold' if is_root else 'Helvetica',
            fontsize='11', color=fg, penwidth='2' if is_root else '1.5'
        )
        para_nodes.add(p)

    # Main execution chain: START → root para
    root = para_order[0]
    dot.edge('__START__', root, color='#334155', penwidth='2.5', arrowhead='normal')

    # Sequential links between consecutive "top-level" paragraphs
    # (those that are directly called from root, or are roots themselves)
    top_level = [root]
    for callee, etype, thru in call_map.get(root, []):
        if callee in para_nodes and callee not in top_level:
            top_level.append(callee)

    for i in range(len(top_level) - 1):
        dot.edge(top_level[i], top_level[i+1],
                 color='#94a3b8', penwidth='1.2',
                 style='dashed', arrowhead='open')

    # PERFORM edges with decision diamonds for conditional performs
    drawn = set()
    for caller, callee, etype, thru in perform_edges:
        key = (caller, callee, etype)
        if key in drawn or callee not in para_nodes:
            continue
        drawn.add(key)
        if etype == 'THRU':
            dot.edge(caller, callee,
                     label=f'PERFORM\nTHRU {thru}' if thru else 'PERFORM THRU',
                     color='#7c3aed', fontcolor='#7c3aed',
                     fontsize='8', penwidth='2', style='dashed',
                     arrowhead='normal')
        else:
            dot.edge(caller, callee,
                     label='PERFORM',
                     color='#2563eb', fontcolor='#2563eb',
                     fontsize='8', penwidth='1.8', arrowhead='normal')

    # IF / EVALUATE summary node if count > 0
    if if_count + evaluate_count > 0:
        cond_label = []
        if if_count:
            cond_label.append(f'{if_count} IF condition{"s" if if_count > 1 else ""}')
        if evaluate_count:
            cond_label.append(f'{evaluate_count} EVALUATE block{"s" if evaluate_count > 1 else ""}')
        dot.node(
            '__COND_SUMMARY__',
            label='\n'.join(cond_label),
            shape='diamond', style='filled',
            fillcolor='#fce7f3', fontcolor='#9d174d',
            fontname='Helvetica', fontsize='9',
            color='#db2777', penwidth='1.5'
        )

    # STOP RUN / END terminal
    dot.node('__END__', 'STOP RUN',
             shape='oval', style='filled',
             fillcolor='#450a0a', fontcolor='white',
             fontname='Helvetica-Bold', fontsize='12',
             color='#991b1b', width='2.0')

    # Connect last paragraph to END
    if len(para_order) > 0:
        # Find "final" paragraphs (CLOSE/FINALIZE)
        final_paras = [p for p in para_order if para_kind(p) == 'final']
        connect_to_end = final_paras[:1] or [para_order[-1]]
        for p in connect_to_end:
            if p in para_nodes:
                dot.edge(p, '__END__', color='#991b1b', penwidth='2', arrowhead='normal')

    # CALL edges
    for caller, ext in call_edges:
        ext_id = f'EXT_{ext}'
        dot.node(ext_id, label=f'CALL\n{ext}',
                 shape='rectangle', style='filled,rounded',
                 fillcolor='#fae8ff', fontcolor='#6b21a8',
                 fontname='Helvetica-Oblique', fontsize='9',
                 color='#9333ea', penwidth='1.5')
        if caller in para_nodes:
            dot.edge(caller, ext_id, color='#9333ea', style='dotted',
                     penwidth='1.5', arrowhead='normal')

    return dot


def generate_cobol_data_structure(entities: dict) -> graphviz.Digraph:
    """Working-Storage data structure diagram — level hierarchy with PIC types."""
    dot = graphviz.Digraph(
        name='COBOLData',
        graph_attr={
            'bgcolor':  'white',
            'fontname': 'Helvetica',
            'rankdir':  'LR',
            'splines':  'ortho',
            'pad':      '0.8',
            'nodesep':  '0.4',
            'ranksep':  '1.6',
        }
    )

    ws        = entities.get('working_storage', [])
    prog      = entities.get('program_id', 'PROGRAM')
    files     = entities.get('select_files', [])
    file_ops  = entities.get('file_ops', [])

    if not ws:
        dot.node('EMPTY', 'No Working-Storage variables found\nin this COBOL program',
                 shape='note', style='filled',
                 fillcolor='#fef9c3', fontcolor='#92400e',
                 fontsize='10', color='#d97706')
        return dot

    # Root node
    dot.node(
        '__WS_ROOT__', label=f'WORKING-STORAGE\n{prog}',
        shape='rectangle', style='filled,rounded',
        fillcolor='#1e293b', fontcolor='white',
        fontname='Helvetica-Bold', fontsize='12',
        color='#0f172a', width='2.5'
    )

    # Colour by data type
    def pic_color(pic):
        if not pic:
            return ('#dbeafe', '#1d4ed8')  # group
        p = pic.upper()
        if '9' in p and 'V' in p:
            return ('#d1fae5', '#065f46')  # decimal
        if '9' in p:
            return ('#fef3c7', '#92400e')  # numeric
        if 'X' in p:
            return ('#ede9fe', '#5b21b6')  # alphanumeric
        if 'A' in p:
            return ('#fce7f3', '#9d174d')  # alphabetic
        return ('#f8fafc', '#334155')

    # Build HTML record nodes for 01-level groups with their children
    group_items: dict[str, list] = {}
    current_01 = None
    orphans = []

    for v in ws:
        lv = v['level']
        if lv in ('01', '77'):
            current_01 = v['name']
            group_items[current_01] = []
        elif current_01:
            group_items[current_01].append(v)
        else:
            orphans.append(v)

    # Render each 01-level group as an HTML table node
    for g_name, children in list(group_items.items())[:15]:
        rows = ''
        header_bg = '#4f46e5'
        rows += (f'<TR><TD COLSPAN="2" BGCOLOR="{header_bg}" ALIGN="CENTER">'
                 f'<FONT COLOR="white"><B> 01  {g_name} </B></FONT></TD></TR>')

        if children:
            for child in children[:10]:
                bg, fg = pic_color(child.get('pic', ''))
                pic_str = f'PIC {child["pic"]}' if child.get('pic') else '(group)'
                rows += (f'<TR>'
                         f'<TD ALIGN="LEFT" BGCOLOR="{bg}"><FONT COLOR="{fg}">'
                         f'{child["level"]}  {child["name"]}</FONT></TD>'
                         f'<TD ALIGN="LEFT" BGCOLOR="white"><FONT COLOR="#6b7280" POINT-SIZE="9">'
                         f'{pic_str}</FONT></TD>'
                         f'</TR>')
            if len(children) > 10:
                rows += (f'<TR><TD COLSPAN="2" BGCOLOR="#f8fafc" ALIGN="CENTER">'
                         f'<FONT COLOR="#94a3b8" POINT-SIZE="8">...{len(children)-10} more fields</FONT>'
                         f'</TD></TR>')
        else:
            rows += ('<TR><TD COLSPAN="2" BGCOLOR="#f8fafc" ALIGN="LEFT">'
                     '<FONT COLOR="#94a3b8" POINT-SIZE="9">  (elementary)</FONT></TD></TR>')

        label = f'<<TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0" BGCOLOR="white" COLOR="#4f46e5">{rows}</TABLE>>'
        dot.node(f'group_{g_name}', label=label, shape='none', margin='0')
        dot.edge('__WS_ROOT__', f'group_{g_name}',
                 color='#6366f1', penwidth='1.5', arrowhead='open')

    # File section (SELECT files)
    if files or file_ops:
        with dot.subgraph(name='cluster_files') as cf:
            cf.attr(label='FILE SECTION', style='filled',
                    fillcolor='#fffbeb', color='#d97706',
                    fontname='Helvetica-Bold', fontsize='10')
            all_files = list({f.upper() for f in files} |
                             {f.upper() for _, f in file_ops
                              if f.upper() not in ('INPUT','OUTPUT','I-O','EXTEND')})
            for fname in all_files[:8]:
                ops_for_file = [op for op, fn in file_ops if fn.upper() == fname][:4]
                op_str = ' · '.join(sorted(set(ops_for_file))) or 'SELECT'
                cf.node(
                    f'fs_{fname}', label=f'{fname}\n{op_str}',
                    shape='cylinder', style='filled',
                    fillcolor='#fef3c7', fontcolor='#92400e',
                    fontname='Helvetica', fontsize='9',
                    color='#d97706', penwidth='1.5'
                )
            cf.node('_fs_anchor', label='', shape='point', width='0', style='invis')
        dot.edge('__WS_ROOT__', '_fs_anchor',
                 color='#d97706', penwidth='1.5',
                 lhead='cluster_files', arrowhead='open')

    return dot


def build_analysis_report_pdf(entities: dict) -> bytes:
    """Generate a PDF analysis report for a COBOL program using fpdf2."""
    from fpdf import FPDF, XPos, YPos

    prog          = entities.get('program_id', 'PROGRAM')
    divisions     = entities.get('divisions', [])
    div_sections  = entities.get('div_sections', {})
    section_paras = entities.get('section_paras', {})
    para_order    = entities.get('para_order', [])
    para_sec      = entities.get('para_sec', {})
    perform_edges = entities.get('perform_edges', [])
    call_edges    = entities.get('call_edges', [])
    working_storage = entities.get('working_storage', [])
    select_files  = entities.get('select_files', [])
    file_ops      = entities.get('file_ops', [])
    if_count      = entities.get('if_count', 0)
    evaluate_count= entities.get('evaluate_count', 0)
    compute_count = entities.get('compute_count', 0)

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # ── Helpers ──────────────────────────────────────────────────────────────
    def section_title(txt, r=30, g=41, b=59):
        pdf.set_fill_color(r, g, b)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font('Helvetica', 'B', 12)
        pdf.cell(0, 8, txt, new_x=XPos.LMARGIN, new_y=YPos.NEXT, fill=True)
        pdf.set_text_color(30, 41, 59)
        pdf.ln(2)

    def sub_title(txt):
        pdf.set_font('Helvetica', 'B', 10)
        pdf.set_text_color(79, 70, 229)
        pdf.cell(0, 7, txt, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.set_text_color(30, 41, 59)

    def body(txt, size=9):
        pdf.set_font('Helvetica', '', size)
        pdf.set_text_color(55, 65, 81)
        pdf.multi_cell(0, 5, str(txt))

    def kv_row(k, v, even=False):
        pdf.set_fill_color(248, 250, 252) if even else pdf.set_fill_color(255, 255, 255)
        pdf.set_font('Helvetica', 'B', 9)
        pdf.set_text_color(30, 41, 59)
        pdf.cell(70, 6, str(k), fill=True)
        pdf.set_font('Helvetica', '', 9)
        pdf.set_text_color(55, 65, 81)
        pdf.cell(0, 6, str(v), new_x=XPos.LMARGIN, new_y=YPos.NEXT, fill=even)

    def hr():
        pdf.set_draw_color(226, 232, 240)
        pdf.line(pdf.l_margin, pdf.get_y(), pdf.w - pdf.r_margin, pdf.get_y())
        pdf.ln(3)

    # ── Cover / header ────────────────────────────────────────────────────────
    pdf.set_fill_color(30, 41, 59)
    pdf.rect(0, 0, 210, 40, 'F')
    pdf.set_text_color(255, 255, 255)
    pdf.set_font('Helvetica', 'B', 20)
    pdf.set_y(10)
    pdf.cell(0, 10, 'Code Lens - BRD', align='C',
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font('Helvetica', '', 11)
    pdf.cell(0, 7, f'COBOL Analysis Report — {prog}', align='C',
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_y(45)
    pdf.set_text_color(30, 41, 59)

    # ── Summary metrics ───────────────────────────────────────────────────────
    section_title('  Summary Metrics')
    metrics = [
        ('Program ID',          prog),
        ('Divisions',           len(divisions)),
        ('Sections',            sum(len(s) for s in div_sections.values())),
        ('Paragraphs',          len(para_order)),
        ('PERFORM statements',  len(perform_edges)),
        ('External CALLs',      len(call_edges)),
        ('IF conditions',       if_count),
        ('EVALUATE blocks',     evaluate_count),
        ('COMPUTE statements',  compute_count),
        ('Working-Storage items', len(working_storage)),
        ('SELECT files',        len(select_files)),
        ('File operations',     len(file_ops)),
    ]
    for i, (k, v) in enumerate(metrics):
        kv_row(k, v, even=(i % 2 == 0))
    pdf.ln(4)

    # ── Program Structure ─────────────────────────────────────────────────────
    section_title('  Program Structure')
    for div in divisions:
        sub_title(f'{div} DIVISION')
        secs = div_sections.get(div, [])
        if not secs:
            body('  (no sections)')
        for sec in secs:
            paras = section_paras.get(sec, [])
            pdf.set_font('Helvetica', 'BI', 9)
            pdf.set_text_color(8, 145, 178)
            pdf.cell(0, 5, f'  {sec} ({len(paras)} paragraphs)',
                     new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            pdf.set_text_color(30, 41, 59)
            for p in paras[:15]:
                pdf.set_font('Courier', '', 8)
                pdf.set_text_color(55, 65, 81)
                pdf.cell(10)
                pdf.cell(0, 4, f'• {p}',
                         new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            if len(paras) > 15:
                pdf.set_font('Helvetica', 'I', 8)
                pdf.set_text_color(148, 163, 184)
                pdf.cell(10)
                pdf.cell(0, 4, f'  ... {len(paras)-15} more paragraphs',
                         new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(2)
    hr()

    # ── Paragraph Index ───────────────────────────────────────────────────────
    if para_order:
        section_title('  Paragraph Index')
        callee_set = {callee for _, callee, _, _ in perform_edges}
        caller_set = {caller for caller, _, _, _ in perform_edges}
        # Table header
        pdf.set_fill_color(99, 102, 241)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font('Helvetica', 'B', 8)
        pdf.cell(10, 6, '#',     fill=True)
        pdf.cell(65, 6, 'Paragraph', fill=True)
        pdf.cell(45, 6, 'Section',   fill=True)
        pdf.cell(20, 6, 'Calls',     fill=True)
        pdf.cell(20, 6, 'Called',    fill=True)
        pdf.cell(0,  6, 'Role',      fill=True,
                 new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.set_text_color(30, 41, 59)
        for i, p in enumerate(para_order[:40]):
            pdf.set_fill_color(248, 250, 252 if i % 2 == 0 else 255)
            pdf.set_font('Courier', '', 7)
            role = ('Entry' if i == 0 else
                    'Caller' if p in caller_set else
                    ('Called' if p in callee_set else 'Standalone'))
            calls_n  = len([c for c2, c, _, _ in perform_edges if c2 == p])
            called_n = len([c for _, c, _, _ in perform_edges if c == p])
            even = i % 2 == 0
            pdf.set_fill_color(248, 250, 252 if even else 255)
            pdf.cell(10, 5, str(i+1),                     fill=even)
            pdf.cell(65, 5, p[:28],                        fill=even)
            pdf.cell(45, 5, (para_sec.get(p) or '—')[:22], fill=even)
            pdf.cell(20, 5, str(calls_n),                  fill=even)
            pdf.cell(20, 5, str(called_n),                 fill=even)
            pdf.cell(0,  5, role, fill=even,
                     new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        if len(para_order) > 40:
            pdf.set_font('Helvetica', 'I', 8)
            pdf.set_text_color(148, 163, 184)
            pdf.cell(0, 5, f'  ... {len(para_order)-40} more paragraphs',
                     new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(4)

    # ── Control Flow (PERFORM) ────────────────────────────────────────────────
    if perform_edges:
        section_title('  Control Flow — PERFORM Statements')
        pdf.set_fill_color(99, 102, 241)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font('Helvetica', 'B', 8)
        pdf.cell(65, 6, 'Caller',    fill=True)
        pdf.cell(65, 6, 'Calls',     fill=True)
        pdf.cell(0,  6, 'Type',      fill=True,
                 new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.set_text_color(30, 41, 59)
        for i, (caller, callee, etype, thru) in enumerate(perform_edges[:30]):
            edge_lbl = (f'PERFORM THRU {thru}' if etype == 'THRU' and thru else etype)
            even = i % 2 == 0
            pdf.set_fill_color(248, 250, 252 if even else 255)
            pdf.set_font('Courier', '', 7)
            pdf.cell(65, 5, caller[:30], fill=even)
            pdf.cell(65, 5, callee[:30], fill=even)
            pdf.cell(0,  5, edge_lbl,    fill=even,
                     new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(4)

    # ── Working-Storage ───────────────────────────────────────────────────────
    if working_storage:
        section_title('  Working-Storage Data Items')
        pdf.set_fill_color(99, 102, 241)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font('Helvetica', 'B', 8)
        pdf.cell(15, 6, 'Level', fill=True)
        pdf.cell(80, 6, 'Name',  fill=True)
        pdf.cell(0,  6, 'PIC',   fill=True,
                 new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.set_text_color(30, 41, 59)
        for i, v in enumerate(working_storage[:25]):
            even = i % 2 == 0
            pdf.set_fill_color(248, 250, 252 if even else 255)
            pdf.set_font('Courier', '', 7)
            pdf.cell(15, 5, v['level'],            fill=even)
            pdf.cell(80, 5, v['name'][:38],         fill=even)
            pdf.cell(0,  5, v.get('pic', '')[:30], fill=even,
                     new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(4)

    # ── File I/O ──────────────────────────────────────────────────────────────
    all_files = list({f.upper() for f in select_files} |
                     {f.upper() for _, f in file_ops
                      if f.upper() not in ('INPUT','OUTPUT','I-O','EXTEND')})
    if all_files:
        section_title('  File I/O Summary')
        for fname in all_files[:10]:
            ops = sorted({op for op, fn in file_ops if fn.upper() == fname})
            op_str = ' · '.join(ops) if ops else '(declared only)'
            pdf.set_font('Helvetica', 'B', 9)
            pdf.set_text_color(180, 83, 9)
            pdf.cell(0, 5, f'  {fname}',
                     new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            pdf.set_font('Helvetica', '', 8)
            pdf.set_text_color(55, 65, 81)
            pdf.cell(0, 4, f'    Operations: {op_str}',
                     new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(4)

    # ── External CALLs ────────────────────────────────────────────────────────
    if call_edges:
        section_title('  External CALL Statements')
        for caller, ext in call_edges[:15]:
            pdf.set_font('Courier', '', 9)
            pdf.set_text_color(107, 33, 168)
            pdf.cell(0, 5, f'  {caller}  →  CALL "{ext}"',
                     new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    # ── Footer ────────────────────────────────────────────────────────────────
    pdf.set_y(-20)
    hr()
    pdf.set_font('Helvetica', 'I', 8)
    pdf.set_text_color(148, 163, 184)
    pdf.cell(0, 5, 'Generated by Code Lens - BRD  •  Powered by Graphviz & fpdf2', align='C')

    return pdf.output()


def render_cobol_analysis_report(entities: dict, export_format: str = "SVG"):
    """Render a comprehensive COBOL analysis report using Streamlit components."""
    prog          = entities.get('program_id', 'PROGRAM')
    divisions     = entities.get('divisions', [])
    div_sections  = entities.get('div_sections', {})
    section_paras = entities.get('section_paras', {})
    para_order    = entities.get('para_order', [])
    para_sec      = entities.get('para_sec', {})
    perform_edges = entities.get('perform_edges', [])
    call_edges    = entities.get('call_edges', [])
    working_storage = entities.get('working_storage', [])
    select_files  = entities.get('select_files', [])
    file_ops      = entities.get('file_ops', [])
    if_count      = entities.get('if_count', 0)
    evaluate_count= entities.get('evaluate_count', 0)
    compute_count = entities.get('compute_count', 0)

    # ── PDF download button (top of report) ──
    if export_format in ["PDF", "All Formats"]:
        try:
            pdf_bytes = build_analysis_report_pdf(entities)
            st.download_button(
                label=f"⬇️ Download Analysis Report PDF",
                data=bytes(pdf_bytes),
                file_name=f"{prog.lower()}_analysis_report.pdf",
                mime="application/pdf",
                use_container_width=True,
            )
        except Exception as _pdf_err:
            st.warning(f"PDF generation failed: {_pdf_err}")

    # ── Top metric row ──
    st.markdown(f"#### 📊 Program: `{prog}` — Full Analysis Report")
    c1, c2, c3, c4, c5, c6 = st.columns(6)
    c1.metric("Divisions",    len(divisions))
    c2.metric("Sections",     sum(len(s) for s in div_sections.values()))
    c3.metric("Paragraphs",   len(para_order))
    c4.metric("PERFORMs",     len(perform_edges))
    c5.metric("Files",        len(select_files) or len({f for _,f in file_ops if f.upper() not in ('INPUT','OUTPUT','I-O','EXTEND')}))
    c6.metric("CALL stmts",   len(call_edges))

    st.markdown("---")

    left, right = st.columns(2)

    # ── Program Structure ──
    with left:
        st.markdown("##### 🏗️ Program Structure")
        for div in divisions:
            div_emoji = {'IDENTIFICATION': '🪪', 'ENVIRONMENT': '⚙️', 'DATA': '🗃️', 'PROCEDURE': '⚡'}.get(div, '📦')
            secs = div_sections.get(div, [])
            with st.expander(f"{div_emoji} {div} DIVISION ({len(secs)} sections)", expanded=(div == 'PROCEDURE')):
                if not secs:
                    st.caption("No sections detected")
                for sec in secs:
                    paras = section_paras.get(sec, [])
                    st.markdown(f"**{sec}** — {len(paras)} paragraph(s)")
                    if paras:
                        st.code('\n'.join(paras[:15]) + ('\n...' if len(paras) > 15 else ''), language=None)

    # ── Control Flow Summary ──
    with right:
        st.markdown("##### ⚡ Control Flow")
        # PERFORM table
        if perform_edges:
            import pandas as pd
            rows = []
            for caller, callee, etype, thru in perform_edges[:25]:
                edge_type = f'PERFORM THRU {thru}' if etype == 'THRU' and thru else etype
                rows.append({'Caller': caller, 'Calls': callee, 'Type': edge_type})
            df = pd.DataFrame(rows)
            st.dataframe(df, use_container_width=True, hide_index=True)
        else:
            st.caption("No PERFORM statements detected")

        if call_edges:
            st.markdown("**External CALL statements:**")
            for caller, ext in call_edges[:10]:
                st.markdown(f"- `{caller}` → CALL `{ext}`")

    st.markdown("---")
    left2, right2 = st.columns(2)

    # ── Complexity Metrics ──
    with left2:
        st.markdown("##### 📐 Complexity Metrics")
        import pandas as pd
        metrics_data = {
            'Metric': [
                'Total Paragraphs',
                'PERFORM statements',
                'External CALLs',
                'IF conditions',
                'EVALUATE blocks',
                'COMPUTE statements',
                'Working-Storage items',
                'File operations',
                'SELECT files',
            ],
            'Count': [
                len(para_order),
                len(perform_edges),
                len(call_edges),
                if_count,
                evaluate_count,
                compute_count,
                len(working_storage),
                len(file_ops),
                len(select_files),
            ]
        }
        st.dataframe(pd.DataFrame(metrics_data), use_container_width=True, hide_index=True)

    # ── Working-Storage Summary ──
    with right2:
        st.markdown("##### 🗃️ Working-Storage Data Items")
        if working_storage:
            import pandas as pd
            ws_rows = []
            for v in working_storage[:20]:
                def type_label(pic):
                    if not pic: return 'Group'
                    p = pic.upper()
                    if '9' in p and 'V' in p: return 'Decimal'
                    if '9' in p: return 'Numeric'
                    if 'X' in p: return 'Alphanum'
                    if 'A' in p: return 'Alpha'
                    return 'Other'
                ws_rows.append({
                    'Level': v['level'],
                    'Name':  v['name'],
                    'PIC':   v.get('pic', ''),
                    'Type':  type_label(v.get('pic', ''))
                })
            st.dataframe(pd.DataFrame(ws_rows), use_container_width=True, hide_index=True)
        else:
            st.caption("No Working-Storage variables detected")

    st.markdown("---")

    # ── File I/O Summary ──
    st.markdown("##### 📁 File I/O Summary")
    if file_ops or select_files:
        all_files = list({f.upper() for f in select_files} |
                         {f.upper() for _, f in file_ops
                          if f.upper() not in ('INPUT','OUTPUT','I-O','EXTEND')})
        for fname in all_files[:10]:
            ops = [op for op, fn in file_ops if fn.upper() == fname]
            op_counts = {}
            for op in ops:
                op_counts[op] = op_counts.get(op, 0) + 1
            op_str = ' · '.join(f'**{k}** ×{v}' for k, v in sorted(op_counts.items()))
            st.markdown(f"📄 `{fname}` — {op_str or '(no operations)'}")
    else:
        st.caption("No file I/O detected in this program")

    # ── Paragraph index ──
    st.markdown("---")
    st.markdown("##### 📋 Paragraph Index")
    if para_order:
        import pandas as pd
        para_rows = []
        callee_set = {callee for _, callee, _, _ in perform_edges}
        caller_set = {caller for caller, _, _, _ in perform_edges}
        for i, p in enumerate(para_order):
            para_rows.append({
                '#':       i + 1,
                'Paragraph': p,
                'Section': para_sec.get(p, '—'),
                'Calls':   len([c for caller, c, _, _ in perform_edges if caller == p]),
                'Called by': len([c for c, callee, _, _ in perform_edges if callee == p]),
                'Role':    'Entry' if i == 0 else ('Caller' if p in caller_set else ('Called' if p in callee_set else 'Standalone')),
            })
        st.dataframe(pd.DataFrame(para_rows), use_container_width=True, hide_index=True)


def render_diagram_to_svg(dot: graphviz.Digraph) -> Optional[str]:
    try:
        return dot.pipe(format='svg').decode('utf-8')
    except Exception:
        return None


# ─── MAIN APP ────────────────────────────────────────────────────────────────

def main():
    st.markdown("""
    <div class="main-header">
        <h1>🔍 Code Lens - BRD</h1>
        <p>Business Requirements Document Generator — Transform text, code, SQL or COBOL into professional diagrams</p>
        <div style="margin-top:0.75rem;">
            <span class="badge">DFD</span>
            <span class="badge">Sequence</span>
            <span class="badge">Architecture</span>
            <span class="badge">Flowchart</span>
            <span class="sql-badge">ER Diagram</span>
            <span class="sql-badge">Query Flow</span>
            <span class="badge" style="background:rgba(5,150,105,0.1);border-color:rgba(5,150,105,0.35);color:#065f46;">COBOL Structure</span>
            <span class="badge" style="background:rgba(5,150,105,0.1);border-color:rgba(5,150,105,0.35);color:#065f46;">COBOL Flow</span>
            <span class="badge">SVG Export</span>
            <span class="badge">PNG Export</span>
            <span class="badge" style="background:rgba(220,38,38,0.1);border-color:rgba(220,38,38,0.35);color:#b91c1c;">PDF Export</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ── SIDEBAR ──
    with st.sidebar:
        st.markdown("## ⚙️ Settings")

        input_type = st.radio(
            "Input Type",
            ["Natural Language / Text", "Python Source Code", "SQL Query / Schema", "COBOL Source Code"],
            help="Choose your input format"
        )

        st.markdown("---")
        st.markdown("## 📊 Diagram Type")

        if input_type == "SQL Query / Schema":
            diagram_type = st.selectbox(
                "Select Diagram",
                [
                    "ER Diagram (Entity-Relationship)",
                    "SQL Query Flow",
                    "Data Flow Diagram (DFD)",
                    "Flowchart",
                    "All SQL Diagrams",
                ]
            )
        elif input_type == "COBOL Source Code":
            diagram_type = st.selectbox(
                "Select Diagram",
                [
                    "COBOL Program Structure",
                    "COBOL Paragraph Flow",
                    "COBOL Block Diagram",
                    "COBOL Functional Tree",
                    "COBOL File I/O Diagram",
                    "COBOL Flowchart",
                    "COBOL Data Structure",
                    "COBOL Analysis Report",
                    "All COBOL Diagrams",
                ]
            )
        else:
            diagram_type = st.selectbox(
                "Select Diagram",
                [
                    "Data Flow Diagram (DFD)",
                    "Sequence Diagram",
                    "Logic / Architecture Diagram",
                    "Flowchart",
                    "All Diagrams",
                ]
            )

        st.markdown("---")
        st.markdown("## 📐 Layout")
        layout_engine = st.selectbox(
            "Graphviz Engine",
            ["dot", "neato", "fdp", "sfdp", "circo", "twopi"],
            help="Different engines produce different graph layouts"
        )

        st.markdown("---")
        st.markdown("## 💾 Export Format")
        export_format = st.radio("Format", ["SVG", "PNG", "PDF", "All Formats"])

        st.markdown("---")
        st.markdown("## 📖 Examples")
        if input_type == "Natural Language / Text":
            example_choice = st.selectbox("Load Example", ["None"] + list(TEXT_EXAMPLES.keys()))
        elif input_type == "Python Source Code":
            example_choice = st.selectbox("Load Example", ["None"] + list(PYTHON_EXAMPLES.keys()))
        elif input_type == "COBOL Source Code":
            example_choice = st.selectbox("Load Example", ["None"] + list(COBOL_EXAMPLES.keys()))
        else:
            example_choice = st.selectbox("Load Example", ["None"] + list(SQL_EXAMPLES.keys()))

    # ── MAIN COLUMNS ──
    col1, col2 = st.columns([2, 3], gap="large")

    input_text = ""

    with col1:
        st.markdown("### 📝 Input")

        # ── FILE UPLOAD SECTION ──
        is_sql  = input_type == "SQL Query / Schema"
        is_code = input_type == "Python Source Code"
        is_cobol = input_type == "COBOL Source Code"

        if is_code:
            st.markdown('<div class="upload-zone">', unsafe_allow_html=True)
            uploaded_file = st.file_uploader(
                "Upload a Python file (.py)",
                type=["py"],
                help="Upload a .py file to analyse automatically",
                key="py_uploader"
            )
            st.markdown('</div>', unsafe_allow_html=True)
            if uploaded_file is not None:
                file_content = uploaded_file.read().decode("utf-8", errors="replace")
                st.markdown(
                    f'<div class="file-info">📄 Loaded: <strong>{uploaded_file.name}</strong>'
                    f' ({len(file_content):,} chars)</div>',
                    unsafe_allow_html=True
                )

        elif is_sql:
            st.markdown('<div class="upload-zone">', unsafe_allow_html=True)
            uploaded_file = st.file_uploader(
                "Upload a SQL file (.sql)",
                type=["sql", "txt"],
                help="Upload a .sql file — DDL, DML, or a mix of both",
                key="sql_uploader"
            )
            st.markdown('</div>', unsafe_allow_html=True)
            if uploaded_file is not None:
                file_content = uploaded_file.read().decode("utf-8", errors="replace")
                st.markdown(
                    f'<div class="sql-info">🗄️ Loaded: <strong>{uploaded_file.name}</strong>'
                    f' ({len(file_content):,} chars)</div>',
                    unsafe_allow_html=True
                )

        elif is_cobol:
            st.markdown('<div class="upload-zone">', unsafe_allow_html=True)
            uploaded_file = st.file_uploader(
                "Upload a COBOL file (.cob, .cbl, .cobol)",
                type=["cob", "cbl", "cobol", "txt"],
                help="Upload a COBOL source file — fixed or free format",
                key="cobol_uploader"
            )
            st.markdown('</div>', unsafe_allow_html=True)
            if uploaded_file is not None:
                file_content = uploaded_file.read().decode("utf-8", errors="replace")
                st.markdown(
                    f'<div class="file-info">🖥️ Loaded: <strong>{uploaded_file.name}</strong>'
                    f' ({len(file_content):,} chars)</div>',
                    unsafe_allow_html=True
                )
            else:
                file_content = None

        else:
            uploaded_file = None
            file_content = None

        # ── TEXT / CODE AREA ──
        if is_code:
            default_code = ""
            if example_choice and example_choice != "None":
                default_code = PYTHON_EXAMPLES.get(example_choice, "")
            elif 'file_content' in dir() and file_content:
                default_code = file_content

            pasted = st.text_area(
                "Or paste Python code directly:",
                value=default_code,
                height=280,
                placeholder="def process_order(order_id):\n    order = get_order(order_id)\n    ...",
                help="Paste Python code or upload a .py file above"
            )
            input_text = file_content if (uploaded_file and file_content and not pasted.strip()) else pasted

        elif is_sql:
            default_sql = ""
            if example_choice and example_choice != "None":
                default_sql = SQL_EXAMPLES.get(example_choice, "")
            elif 'file_content' in dir() and file_content:
                default_sql = file_content

            pasted = st.text_area(
                "Or paste SQL directly:",
                value=default_sql,
                height=280,
                placeholder="CREATE TABLE users (...)\nSELECT * FROM users JOIN orders ON ...",
                help="Paste SQL DDL/DML or upload a .sql file above"
            )
            input_text = file_content if (uploaded_file and file_content and not pasted.strip()) else pasted

        elif is_cobol:
            default_cobol = ""
            if example_choice and example_choice != "None":
                default_cobol = COBOL_EXAMPLES.get(example_choice, "")
            elif file_content:
                default_cobol = file_content

            pasted = st.text_area(
                "Or paste COBOL source directly:",
                value=default_cobol,
                height=320,
                placeholder=(
                    "       IDENTIFICATION DIVISION.\n"
                    "       PROGRAM-ID. MYPROG.\n"
                    "       PROCEDURE DIVISION.\n"
                    "       0000-MAIN.\n"
                    "           PERFORM 1000-INIT\n"
                    "           STOP RUN.\n"
                    "       1000-INIT.\n"
                    "           MOVE ZEROS TO WS-FLAG."
                ),
                help="Paste COBOL source (fixed or free format) or upload a .cob/.cbl file above"
            )
            input_text = file_content if (uploaded_file and file_content and not pasted.strip()) else pasted

        else:
            default_text = ""
            if example_choice and example_choice != "None":
                default_text = TEXT_EXAMPLES.get(example_choice, "")

            input_text = st.text_area(
                "Describe your system, process or architecture:",
                value=default_text,
                height=340,
                placeholder="User sends login request to API Gateway.\nAPI Gateway routes to Auth Service.\n...",
                help="Describe each step on a new line. Capitalize component names for better detection."
            )

        generate_btn = st.button("🚀 Generate Diagram", use_container_width=True)

        # ── ANALYSIS PREVIEW ──
        if input_text and input_text.strip():
            st.markdown("### 📋 Analysis Preview")
            if is_code:
                ents, _, err = parse_python_to_entities(input_text)
                if err:
                    st.error(f"Python parse error: {err}")
                elif ents:
                    c1, c2, c3 = st.columns(3)
                    c1.metric("Classes", len(ents.get("classes", [])))
                    c2.metric("Functions", len(ents.get("functions", [])))
                    c3.metric("Imports", len(ents.get("imports", [])))
            elif is_sql:
                ents = parse_sql_to_entities(input_text)
                c1, c2, c3, c4 = st.columns(4)
                c1.metric("Tables", len(ents.get("tables", {})))
                c2.metric("Joins", len(ents.get("joins", [])))
                c3.metric("Operations", len(ents.get("operations", [])))
                c4.metric("Views", len(ents.get("views", [])))
                if ents.get("tables"):
                    st.markdown(
                        "**Tables detected:** " +
                        ", ".join(f"`{t}`" for t in list(ents["tables"].keys())[:10])
                    )
            elif is_cobol:
                ents = parse_cobol_to_entities(input_text)
                c1, c2, c3, c4 = st.columns(4)
                c1.metric("Divisions", len(ents.get("divisions", [])))
                c2.metric("Paragraphs", len(ents.get("para_order", [])))
                c3.metric("PERFORMs", len(ents.get("perform_edges", [])))
                c4.metric("Files", len(ents.get("select_files", [])))
                if ents.get("para_order"):
                    st.markdown(
                        "**Program:** `" + ents.get("program_id", "?") + "` · "
                        "**Paragraphs:** " +
                        ", ".join(f"`{p}`" for p in ents["para_order"][:8]) +
                        ("…" if len(ents["para_order"]) > 8 else "")
                    )
                if ents.get("working_storage"):
                    ws_names = [v['name'] for v in ents['working_storage'][:6]]
                    st.markdown("**Working-Storage:** " + ", ".join(f"`{n}`" for n in ws_names))
            else:
                ents = extract_entities_from_text(input_text)
                c1, c2, c3 = st.columns(3)
                c1.metric("Steps", len(ents.get("processes", [])))
                c2.metric("Actors", len(ents.get("actors", [])))
                c3.metric("Systems", len(ents.get("systems", [])))

    # ── OUTPUT COLUMN ──
    with col2:
        st.markdown("### 🎨 Diagram Output")

        if generate_btn and input_text and input_text.strip():

            # Build entities
            if is_code:
                entities, _, error = parse_python_to_entities(input_text)
                if error:
                    st.error(f"Python parsing failed: {error}")
                    st.stop()
                if not entities:
                    st.warning("No parseable entities found.")
                    st.stop()
            elif is_sql:
                entities = parse_sql_to_entities(input_text)
                if not entities.get("tables") and not entities.get("operations"):
                    st.warning("No SQL tables or operations detected. Check the input.")
            elif is_cobol:
                entities = parse_cobol_to_entities(input_text)
                if not entities.get("para_order") and not entities.get("divisions"):
                    st.warning("No COBOL structure detected. Check that this is valid COBOL source code.")
            else:
                entities = extract_entities_from_text(input_text)

            # Build diagram map for this input type
            if is_sql:
                diagram_map = {
                    "ER Diagram (Entity-Relationship)": ("er",      lambda e, **kw: generate_sql_er_diagram(e)),
                    "SQL Query Flow":                   ("qflow",   lambda e, **kw: generate_sql_query_flow(e)),
                    "Data Flow Diagram (DFD)":          ("dfd",     lambda e, **kw: generate_dfd(e, is_sql=True)),
                    "Flowchart":                        ("flow",    lambda e, **kw: generate_flowchart(e, is_sql=True)),
                }
                all_key = "All SQL Diagrams"
            elif is_cobol:
                diagram_map = {
                    "COBOL Program Structure": ("cobol_struct", lambda e, **kw: generate_cobol_structure_diagram(e)),
                    "COBOL Paragraph Flow":    ("cobol_flow",   lambda e, **kw: generate_cobol_flow_diagram(e)),
                    "COBOL Block Diagram":     ("cobol_block",  lambda e, **kw: generate_cobol_block_diagram(e)),
                    "COBOL Functional Tree":   ("cobol_tree",   lambda e, **kw: generate_cobol_functional_tree(e)),
                    "COBOL File I/O Diagram":  ("cobol_fileio", lambda e, **kw: generate_cobol_file_io_diagram(e)),
                    "COBOL Flowchart":         ("cobol_fc",     lambda e, **kw: generate_cobol_flowchart(e)),
                    "COBOL Data Structure":    ("cobol_data",   lambda e, **kw: generate_cobol_data_structure(e)),
                }
                all_key = "All COBOL Diagrams"
            else:
                diagram_map = {
                    "Data Flow Diagram (DFD)":         ("dfd",  lambda e, **kw: generate_dfd(e, is_code=is_code)),
                    "Sequence Diagram":                ("seq",  lambda e, **kw: generate_sequence_diagram(e, is_code=is_code)),
                    "Logic / Architecture Diagram":    ("arch", lambda e, **kw: generate_logical_diagram(e, is_code=is_code)),
                    "Flowchart":                       ("flow", lambda e, **kw: generate_flowchart(e, is_code=is_code)),
                }
                all_key = "All Diagrams"

            # Handle COBOL Analysis Report (pure Streamlit widgets, not graphviz)
            if is_cobol and diagram_type == "COBOL Analysis Report":
                render_cobol_analysis_report(entities, export_format=export_format)
                st.stop()

            to_generate = (
                list(diagram_map.items()) if diagram_type == all_key
                else [(diagram_type, diagram_map[diagram_type])]
            )

            for d_name, (d_key, d_func) in to_generate:
                if d_name not in diagram_map:
                    continue
                with st.spinner(f"Generating {d_name}..."):
                    try:
                        dot = d_func(entities)
                        dot.engine = layout_engine
                        svg_str = render_diagram_to_svg(dot)

                        if svg_str:
                            if diagram_type == all_key:
                                st.markdown(f"#### {d_name}")
                            st.markdown(
                                f'<div class="svg-container">{svg_str}</div>',
                                unsafe_allow_html=True
                            )
                            svg_bytes = svg_str.encode('utf-8')
                            dl_cols = st.columns(3)
                            if export_format in ["SVG", "All Formats"]:
                                with dl_cols[0]:
                                    st.download_button(
                                        label=f"⬇️ {d_key.upper()} SVG",
                                        data=svg_bytes,
                                        file_name=f"{d_key}_diagram.svg",
                                        mime="image/svg+xml",
                                        use_container_width=True
                                    )
                            if export_format in ["PNG", "All Formats"]:
                                with dl_cols[1]:
                                    try:
                                        png_bytes = dot.pipe(format='png')
                                        st.download_button(
                                            label=f"⬇️ {d_key.upper()} PNG",
                                            data=png_bytes,
                                            file_name=f"{d_key}_diagram.png",
                                            mime="image/png",
                                            use_container_width=True
                                        )
                                    except Exception:
                                        st.info("PNG needs graphviz PNG support.")
                            if export_format in ["PDF", "All Formats"]:
                                with dl_cols[2]:
                                    try:
                                        pdf_bytes = dot.pipe(format='pdf')
                                        st.download_button(
                                            label=f"⬇️ {d_key.upper()} PDF",
                                            data=pdf_bytes,
                                            file_name=f"{d_key}_diagram.pdf",
                                            mime="application/pdf",
                                            use_container_width=True
                                        )
                                    except Exception:
                                        st.info("PDF needs graphviz PDF support.")
                        else:
                            st.error(f"Failed to render {d_name}")
                    except Exception as e:
                        st.error(f"Error generating {d_name}: {e}")

            # After all COBOL diagrams, append analysis report
            if is_cobol and diagram_type == "All COBOL Diagrams":
                st.markdown("#### COBOL Analysis Report")
                render_cobol_analysis_report(entities, export_format=export_format)

        elif generate_btn and not (input_text and input_text.strip()):
            st.warning("Please enter some content first (or upload a file).")
        else:
            st.markdown("""
            <div style="text-align:center; padding:3rem 2rem; background:#f8fafc; border-radius:12px; border:1px dashed #cbd5e1;">
                <div style="font-size:3rem; margin-bottom:1rem;">📊</div>
                <p style="font-size:1.1rem; color:#64748b; margin:0 0 0.5rem 0;">Your diagram will appear here</p>
                <p style="font-size:0.875rem; color:#94a3b8; margin:0;">
                    Enter text, code or SQL on the left — or upload a .py / .sql file<br>
                    then click <strong style="color:#6366f1;">Generate Diagram</strong>
                </p>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("""
    <div style="text-align:center; padding:1rem; color:#94a3b8; font-size:0.8rem; border-top:1px solid #e2e8f0; margin-top:0.5rem;">
        <strong style="color:#6366f1;">Code Lens - BRD</strong> &nbsp;•&nbsp;
        Powered by Graphviz &nbsp;•&nbsp;
        DFD · Sequence · Architecture · Flowchart · ER · Query Flow · COBOL Structure · COBOL Flow &nbsp;•&nbsp;
        Upload .py · .sql · .cob/.cbl files &nbsp;•&nbsp; Export SVG / PNG / PDF
    </div>
    """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()
