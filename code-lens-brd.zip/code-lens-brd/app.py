import streamlit as st
import graphviz
import ast
import re
import base64
import textwrap
import os
from typing import Optional

st.set_page_config(
    page_title="Code Lens - BRD",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

    html, body, [class*="css"] { font-family: 'Inter', sans-serif; color: #1e293b; }

    .stApp {
        background: #ffffff;
        min-height: 100vh;
    }

    /* force all Streamlit default text to dark */
    .stApp p, .stApp span, .stApp div, .stApp label { color: #1e293b; }

    .main-header {
        text-align: center;
        padding: 2rem 0 1rem 0;
        background: linear-gradient(135deg, rgba(99,102,241,0.08) 0%, rgba(168,85,247,0.08) 100%);
        border-radius: 16px;
        border: 1px solid rgba(99,102,241,0.25);
        margin-bottom: 2rem;
    }
    .main-header h1 {
        font-size: 2.8rem;
        font-weight: 700;
        background: linear-gradient(135deg, #6366f1, #8b5cf6, #3b82f6);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin: 0;
        letter-spacing: -0.5px;
    }
    .main-header p { color: #64748b; font-size: 1.1rem; margin: 0.5rem 0 0 0; }

    .badge {
        display: inline-block;
        background: rgba(99,102,241,0.1);
        border: 1px solid rgba(99,102,241,0.35);
        color: #4f46e5;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 600;
        letter-spacing: 0.5px;
        margin: 4px;
    }
    .sql-badge {
        display: inline-block;
        background: rgba(245,158,11,0.1);
        border: 1px solid rgba(245,158,11,0.35);
        color: #d97706;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 600;
        margin: 4px;
    }

    .stTextArea textarea {
        background: #f8fafc !important;
        border: 1px solid #cbd5e1 !important;
        border-radius: 10px !important;
        color: #1e293b !important;
        font-family: 'JetBrains Mono', monospace !important;
        font-size: 0.875rem !important;
    }
    .stTextArea textarea:focus {
        border-color: #6366f1 !important;
        box-shadow: 0 0 0 2px rgba(99,102,241,0.15) !important;
    }
    .stTextArea textarea::placeholder { color: #94a3b8 !important; }

    .stButton > button {
        background: linear-gradient(135deg, #6366f1, #8b5cf6) !important;
        border: none !important;
        border-radius: 10px !important;
        color: white !important;
        font-weight: 600 !important;
        font-size: 0.95rem !important;
        padding: 0.65rem 1.5rem !important;
        transition: all 0.2s !important;
        box-shadow: 0 4px 15px rgba(99,102,241,0.25) !important;
    }
    .stButton > button:hover {
        transform: translateY(-1px) !important;
        box-shadow: 0 6px 20px rgba(99,102,241,0.4) !important;
    }
    .stDownloadButton > button {
        background: linear-gradient(135deg, #10b981, #059669) !important;
        border: none !important;
        border-radius: 8px !important;
        color: white !important;
        font-weight: 600 !important;
        box-shadow: 0 4px 12px rgba(16,185,129,0.25) !important;
    }

    h3 { color: #1e293b !important; font-weight: 600 !important; }
    h2 { color: #1e293b !important; }

    .stRadio > div > label { color: #374151 !important; }
    .stRadio > label { color: #374151 !important; }

    div[data-testid="stSidebar"] {
        background: #f8fafc !important;
        border-right: 1px solid #e2e8f0 !important;
    }
    div[data-testid="stSidebar"] label,
    div[data-testid="stSidebar"] p { color: #374151 !important; }
    div[data-testid="stSidebar"] h2 { color: #1e293b !important; }
    div[data-testid="stSidebar"] .stSelectbox label { color: #374151 !important; }

    /* selectbox */
    div[data-baseweb="select"] > div {
        background: #ffffff !important;
        border: 1px solid #cbd5e1 !important;
        color: #1e293b !important;
    }

    /* metric numbers */
    div[data-testid="stMetricValue"] { color: #4f46e5 !important; }
    div[data-testid="stMetricLabel"] { color: #64748b !important; }

    .svg-container {
        background: #ffffff;
        border-radius: 10px;
        padding: 2rem;
        text-align: center;
        border: 1px solid #e2e8f0;
        box-shadow: 0 1px 6px rgba(0,0,0,0.06);
        width: 100%;
        overflow-x: auto;
    }
    .svg-container svg {
        width: 100% !important;
        height: auto !important;
        min-height: 500px;
        max-width: 100%;
    }

    .upload-zone {
        border: 2px dashed #c7d2fe;
        border-radius: 12px;
        padding: 1rem;
        margin-bottom: 0.75rem;
        background: #f5f3ff;
    }
    .file-info {
        background: #f0fdf4;
        border: 1px solid #bbf7d0;
        border-radius: 8px;
        padding: 0.5rem 0.75rem;
        color: #166534;
        font-size: 0.85rem;
        margin: 0.5rem 0;
    }
    .sql-info {
        background: #fffbeb;
        border: 1px solid #fde68a;
        border-radius: 8px;
        padding: 0.5rem 0.75rem;
        color: #92400e;
        font-size: 0.85rem;
        margin: 0.5rem 0;
    }

    /* horizontal rule */
    hr { border-color: #e2e8f0 !important; }
</style>
""", unsafe_allow_html=True)


# ─── EXAMPLE DATA ────────────────────────────────────────────────────────────

TEXT_EXAMPLES = {
    "E-Commerce System": """\
User visits website and browses products.
User adds items to cart and proceeds to checkout.
System validates cart and checks inventory.
Payment gateway processes credit card payment.
Order management system creates order record.
Warehouse receives order and prepares shipment.
Shipping service delivers package to customer.
Notification service sends email confirmation.""",

    "Authentication Flow": """\
Client sends login request with username and password.
API Gateway receives request and routes to Auth Service.
Auth Service validates credentials against User Database.
User Database returns user record with hashed password.
Auth Service verifies password hash and generates JWT token.
Token Service signs JWT with private key and sets expiry.
Auth Service returns access token and refresh token to client.
Client stores tokens and includes access token in subsequent requests.""",

    "Microservices Architecture": """\
API Gateway receives all client requests.
Load Balancer distributes traffic across service instances.
User Service handles authentication and user management.
Product Service manages product catalog and search.
Order Service processes orders and manages order lifecycle.
Payment Service integrates with external payment providers.
Notification Service sends emails, SMS, and push notifications.
Database Layer stores data in separate databases per service.
Message Queue enables async communication between services.
Monitoring Service collects metrics and logs from all services.""",

    "CI/CD Pipeline": """\
Developer commits code to feature branch in Git repository.
GitHub Actions triggers automated build pipeline.
Code Quality tool runs linting and static analysis checks.
Test Runner executes unit tests and integration tests.
Build Service compiles application and creates Docker image.
Security Scanner checks image for vulnerabilities.
Container Registry stores approved Docker image.
Staging deployment updates staging environment automatically.
QA team runs manual testing on staging environment.
Approval gate requires team lead sign-off for production.
Production deployment rolls out new version with blue-green strategy.
Health Check monitors deployment and rolls back if errors detected.""",
}

PYTHON_EXAMPLES = {
    "FastAPI App": '''\
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy.orm import Session
from database import get_db
from models import User, Product, Order

app = FastAPI()

@app.post("/users/register")
def register_user(user_data: dict, db: Session = Depends(get_db)):
    user = User(**user_data)
    db.add(user)
    db.commit()
    return user

@app.get("/products")
def list_products(db: Session = Depends(get_db)):
    return db.query(Product).all()

@app.post("/orders")
def create_order(order_data: dict, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == order_data["product_id"]).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    order = Order(**order_data)
    db.add(order)
    db.commit()
    return order

@app.put("/orders/{order_id}/status")
def update_order_status(order_id: int, status: str, db: Session = Depends(get_db)):
    order = db.query(Order).filter(Order.id == order_id).first()
    order.status = status
    db.commit()
    return order''',

    "ML Pipeline": '''\
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib

def load_data(filepath):
    data = pd.read_csv(filepath)
    return data

def preprocess(data):
    features = data.drop("target", axis=1)
    labels = data["target"]
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(features)
    return features_scaled, labels, scaler

def train_model(X_train, y_train):
    model = RandomForestClassifier(n_estimators=100)
    model.fit(X_train, y_train)
    return model

def evaluate_model(model, X_test, y_test):
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    return accuracy

def save_model(model, scaler, path):
    joblib.dump({"model": model, "scaler": scaler}, path)

def run_pipeline(filepath, model_path):
    data = load_data(filepath)
    X, y, scaler = preprocess(data)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    model = train_model(X_train, y_train)
    accuracy = evaluate_model(model, X_test, y_test)
    save_model(model, scaler, model_path)
    return accuracy''',
}

SQL_EXAMPLES = {
    "E-Commerce Schema": """\
CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE products (
    product_id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10,2),
    stock_qty INT DEFAULT 0,
    category_id INT REFERENCES categories(category_id)
);

CREATE TABLE orders (
    order_id SERIAL PRIMARY KEY,
    customer_id INT REFERENCES customers(customer_id),
    status VARCHAR(50) DEFAULT 'pending',
    total DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE order_items (
    item_id SERIAL PRIMARY KEY,
    order_id INT REFERENCES orders(order_id),
    product_id INT REFERENCES products(product_id),
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2)
);

CREATE TABLE categories (
    category_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    parent_id INT REFERENCES categories(category_id)
);

SELECT c.name, COUNT(o.order_id) as order_count, SUM(o.total) as revenue
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.status = 'completed'
GROUP BY c.customer_id, c.name
ORDER BY revenue DESC;""",

    "HR System Queries": """\
CREATE TABLE departments (
    dept_id SERIAL PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL,
    manager_id INT
);

CREATE TABLE employees (
    emp_id SERIAL PRIMARY KEY,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    dept_id INT REFERENCES departments(dept_id),
    manager_id INT REFERENCES employees(emp_id),
    salary DECIMAL(10,2),
    hire_date DATE
);

CREATE TABLE payroll (
    payroll_id SERIAL PRIMARY KEY,
    emp_id INT REFERENCES employees(emp_id),
    pay_period DATE,
    gross_pay DECIMAL(10,2),
    deductions DECIMAL(10,2),
    net_pay DECIMAL(10,2)
);

INSERT INTO departments (dept_name) VALUES ('Engineering'), ('Marketing'), ('HR');

UPDATE employees SET salary = salary * 1.10
WHERE dept_id = (SELECT dept_id FROM departments WHERE dept_name = 'Engineering');

SELECT d.dept_name, AVG(e.salary) as avg_salary, COUNT(*) as headcount
FROM departments d
LEFT JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_id, d.dept_name
ORDER BY avg_salary DESC;

DELETE FROM payroll WHERE pay_period < '2022-01-01';""",
}


# ─── PARSERS ─────────────────────────────────────────────────────────────────

def parse_python_to_entities(code: str):
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return None, None, str(e)

    classes, functions, calls, imports = [], [], [], []

    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            methods = [n.name for n in ast.walk(node) if isinstance(n, ast.FunctionDef)]
            classes.append({"name": node.name, "methods": methods})
        elif isinstance(node, ast.FunctionDef):
            is_method = any(
                isinstance(item, ast.FunctionDef) and item.name == node.name
                for cls_node in ast.walk(tree)
                if isinstance(cls_node, ast.ClassDef)
                for item in cls_node.body
            )
            if not is_method:
                functions.append(node.name)
                for child in ast.walk(node):
                    if isinstance(child, ast.Call):
                        if isinstance(child.func, ast.Name):
                            calls.append((node.name, child.func.id))
                        elif isinstance(child.func, ast.Attribute):
                            calls.append((node.name, child.func.attr))
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            if isinstance(node, ast.ImportFrom) and node.module:
                imports.append(node.module)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)

    return {"classes": classes, "functions": functions, "calls": calls, "imports": imports}, None, None


def parse_sql_to_entities(sql: str):
    """Parse SQL to extract tables, columns, joins, operations and relationships."""
    sql_upper = sql.upper()
    sql_clean = re.sub(r'--[^\n]*', '', sql)          # strip line comments
    sql_clean = re.sub(r'/\*.*?\*/', '', sql_clean, flags=re.DOTALL)  # block comments

    tables = {}       # {name: {columns, pk, fk}}
    joins = []        # [(left_table, right_table, join_type, condition)]
    operations = []   # [(op_type, table, detail)]
    views = []
    procedures = []
    subqueries = []

    # ── CREATE TABLE ──
    create_pattern = re.compile(
        r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)\s*\((.*?)\)',
        re.IGNORECASE | re.DOTALL
    )
    for m in create_pattern.finditer(sql_clean):
        tname = m.group(1).upper()
        body = m.group(2)
        columns = []
        pk_cols = []
        fk_refs = []

        for line in body.split(','):
            line = line.strip()
            if not line:
                continue
            col_m = re.match(r'(\w+)\s+(\w+(?:\s*\([^)]*\))?)', line, re.IGNORECASE)
            if col_m and col_m.group(1).upper() not in (
                'PRIMARY', 'FOREIGN', 'UNIQUE', 'INDEX', 'KEY', 'CHECK', 'CONSTRAINT'
            ):
                col_name = col_m.group(1)
                col_type = col_m.group(2)
                is_pk = 'PRIMARY KEY' in line.upper()
                columns.append({"name": col_name, "type": col_type, "pk": is_pk})
                if is_pk:
                    pk_cols.append(col_name)

            fk_m = re.search(
                r'REFERENCES\s+(\w+)\s*\(\s*(\w+)\s*\)',
                line, re.IGNORECASE
            )
            if fk_m:
                fk_refs.append({"ref_table": fk_m.group(1).upper(), "ref_col": fk_m.group(2)})
                joins.append((tname, fk_m.group(1).upper(), "FK", f"→ {fk_m.group(2)}"))

        tables[tname] = {"columns": columns[:8], "pk": pk_cols, "fk": fk_refs}

    # ── CREATE VIEW ──
    view_pat = re.compile(r'CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+(\w+)', re.IGNORECASE)
    for m in view_pat.finditer(sql_clean):
        views.append(m.group(1).upper())

    # ── CREATE PROCEDURE / FUNCTION ──
    proc_pat = re.compile(r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:PROCEDURE|FUNCTION)\s+(\w+)', re.IGNORECASE)
    for m in proc_pat.finditer(sql_clean):
        procedures.append(m.group(1).upper())

    # ── DML Operations ──
    for op, kw in [('SELECT', r'SELECT\b'), ('INSERT', r'INSERT\s+INTO\s+(\w+)'),
                   ('UPDATE', r'UPDATE\s+(\w+)'), ('DELETE', r'DELETE\s+FROM\s+(\w+)'),
                   ('MERGE',  r'MERGE\s+INTO\s+(\w+)')]:
        for m in re.finditer(kw, sql_clean, re.IGNORECASE):
            tbl = m.group(1).upper() if m.lastindex else ''
            operations.append((op, tbl))

    # ── JOINs in SELECT statements ──
    join_pat = re.compile(
        r'(INNER|LEFT|RIGHT|FULL|CROSS)?\s*(?:OUTER\s+)?JOIN\s+(\w+)\s+(?:\w+\s+)?ON\s+([^\n]+)',
        re.IGNORECASE
    )
    # Find FROM tables
    from_pat = re.compile(r'\bFROM\s+(\w+)', re.IGNORECASE)
    from_tables = [m.group(1).upper() for m in from_pat.finditer(sql_clean)]

    for m in join_pat.finditer(sql_clean):
        join_type = (m.group(1) or 'INNER').upper()
        right_tbl = m.group(2).upper()
        condition = m.group(3).strip()[:60]
        if from_tables:
            left_tbl = from_tables[0]
            joins.append((left_tbl, right_tbl, join_type, condition))

    # ── Subqueries ──
    sub_pat = re.compile(r'\(\s*SELECT\b', re.IGNORECASE)
    subqueries = [f"Subquery_{i+1}" for i, _ in enumerate(sub_pat.finditer(sql_clean))]

    return {
        "tables": tables,
        "joins": joins,
        "operations": operations,
        "views": views,
        "procedures": procedures,
        "subqueries": subqueries,
    }


def extract_entities_from_text(text: str):
    lines = [l.strip() for l in text.strip().split('\n') if l.strip()]
    actors, systems, processes = set(), set(), []
    actor_kw = ['user', 'client', 'customer', 'admin', 'developer', 'team', 'operator', 'manager', 'qa']
    system_kw = ['service', 'api', 'gateway', 'database', 'db', 'server', 'system', 'engine',
                 'queue', 'registry', 'runner', 'scanner', 'monitor', 'cache', 'store', 'repo']

    for i, line in enumerate(lines):
        processes.append(line)
        for w in re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', line):
            wl = w.lower()
            if any(p in wl for p in actor_kw):
                actors.add(w)
            elif any(p in wl for p in system_kw):
                systems.add(w)

    return {
        "processes": processes,
        "actors": list(actors) or ["User"],
        "systems": list(systems) or ["System"],
    }


# ─── SQL DIAGRAM GENERATORS ──────────────────────────────────────────────────

def generate_sql_er_diagram(entities: dict) -> graphviz.Digraph:
    """Generate an Entity-Relationship diagram from SQL."""
    dot = graphviz.Digraph(
        name='ER',
        comment='Entity-Relationship Diagram',
        graph_attr={
            'bgcolor': 'transparent',
            'fontname': 'Helvetica',
            'rankdir': 'LR',
            'splines': 'curved',
            'pad': '1.0',
            'nodesep': '1.2',
            'ranksep': '2.0',
            'compound': 'true',
        }
    )

    tables = entities.get("tables", {})
    joins = entities.get("joins", [])
    views = entities.get("views", [])
    procedures = entities.get("procedures", [])

    table_colors = [
        ('#0f2942', '#1d4ed8', '#93c5fd'),
        ('#1a0f42', '#7c3aed', '#c4b5fd'),
        ('#0f2920', '#065f46', '#6ee7b7'),
        ('#2d1a0f', '#b45309', '#fcd34d'),
        ('#2d0f1a', '#9f1239', '#fda4af'),
        ('#0f2d2d', '#0e7490', '#67e8f9'),
    ]

    for i, (tname, tdata) in enumerate(tables.items()):
        color_set = table_colors[i % len(table_colors)]
        bg, border, text_light = color_set

        col_rows = ""
        for col in tdata.get("columns", [])[:8]:
            icon = "🔑" if col.get("pk") else "  "
            col_rows += f'<TR><TD ALIGN="LEFT" BGCOLOR="{bg}">{icon} {col["name"]}</TD><TD ALIGN="LEFT" BGCOLOR="{bg}" COLOR="{text_light}"><FONT COLOR="{text_light}">{col["type"]}</FONT></TD></TR>'

        if not tdata.get("columns"):
            col_rows = f'<TR><TD ALIGN="LEFT" BGCOLOR="{bg}" COLSPAN="2"><I>No columns detected</I></TD></TR>'

        label = f'''<<TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0" BGCOLOR="{bg}" COLOR="{border}">
  <TR><TD COLSPAN="2" BGCOLOR="{border}" ALIGN="CENTER"><FONT COLOR="white"><B> {tname} </B></FONT></TD></TR>
  {col_rows}
</TABLE>>'''

        dot.node(tname, label=label, shape='none', margin='0')

    for vname in views:
        dot.node(
            f'view_{vname}', label=vname,
            shape='rectangle', style='filled,dashed',
            fillcolor='#1f2937', fontcolor='#34d399',
            color='#059669', fontname='Helvetica-Oblique', fontsize='11'
        )

    for pname in procedures:
        dot.node(
            f'proc_{pname}', label=f'⚙ {pname}',
            shape='rectangle', style='filled,rounded',
            fillcolor='#2d1f4e', fontcolor='#a78bfa',
            color='#7c3aed', fontname='Helvetica', fontsize='11'
        )

    drawn = set()
    for left, right, jtype, condition in joins:
        key = (left, right)
        if key in drawn:
            continue
        drawn.add(key)
        if left in tables and right in tables:
            style_map = {
                'FK': ('#f59e0b', 'normal', 'solid', '1→N'),
                'INNER': ('#6366f1', 'normal', 'solid', 'JOIN'),
                'LEFT': ('#10b981', 'normal', 'dashed', 'LEFT'),
                'RIGHT': ('#ec4899', 'normal', 'dashed', 'RIGHT'),
                'FULL': ('#06b6d4', 'normal', 'dotted', 'FULL'),
                'CROSS': ('#f97316', 'normal', 'dotted', 'CROSS'),
            }
            color, arrow, lstyle, lbl = style_map.get(jtype, ('#94a3b8', 'normal', 'solid', jtype))
            dot.edge(left, right,
                     label=lbl,
                     color=color,
                     fontcolor=color,
                     fontsize='9',
                     penwidth='2',
                     style=lstyle,
                     arrowhead=arrow)

    return dot


def generate_sql_query_flow(entities: dict) -> graphviz.Digraph:
    """Generate a query execution / data flow diagram from SQL operations."""
    dot = graphviz.Digraph(
        name='QueryFlow',
        comment='SQL Query Flow',
        graph_attr={
            'bgcolor': 'transparent',
            'fontname': 'Helvetica',
            'rankdir': 'TB',
            'splines': 'ortho',
            'pad': '0.8',
            'nodesep': '0.9',
            'ranksep': '1.0',
        }
    )

    tables = entities.get("tables", {})
    operations = entities.get("operations", [])
    joins = entities.get("joins", [])
    subqueries = entities.get("subqueries", [])

    # Source tables cluster
    with dot.subgraph(name='cluster_sources') as c:
        c.attr(label='Source Tables', style='rounded,filled',
               fillcolor='#0f1a2e', color='#1d4ed8',
               fontcolor='#93c5fd', fontname='Helvetica-Bold', fontsize='12')
        for tname in list(tables.keys())[:8]:
            c.node(f'tbl_{tname}', label=f'▣ {tname}',
                   shape='cylinder', style='filled',
                   fillcolor='#0f2942', fontcolor='#93c5fd',
                   color='#1d4ed8', fontname='Helvetica', fontsize='11')

    # Operation nodes
    op_styles = {
        'SELECT': ('#1e3a5f', '#3b82f6', '#ffffff', 'ellipse'),
        'INSERT': ('#1e4a3a', '#059669', '#ffffff', 'rectangle'),
        'UPDATE': ('#3d3a1f', '#b45309', '#ffffff', 'rectangle'),
        'DELETE': ('#3d1a1a', '#dc2626', '#ffffff', 'rectangle'),
        'MERGE':  ('#2d1f4e', '#7c3aed', '#ffffff', 'rectangle'),
    }

    for i, (op, tbl) in enumerate(operations[:12]):
        node_id = f'op_{op}_{i}'
        bg, border, text, shape = op_styles.get(op, ('#1e1e2e', '#6366f1', '#ffffff', 'ellipse'))
        lbl = f'{op}' + (f'\n→ {tbl}' if tbl else '')
        dot.node(node_id, label=lbl, shape=shape, style='filled,rounded',
                 fillcolor=bg, fontcolor=text, color=border,
                 fontname='Helvetica-Bold', fontsize='11', width='1.8')

        if tbl and f'tbl_{tbl}' in [f'tbl_{t}' for t in tables]:
            if op == 'SELECT':
                dot.edge(f'tbl_{tbl}', node_id, color='#3b82f6', penwidth='1.5', style='dashed')
            else:
                dot.edge(node_id, f'tbl_{tbl}', color=border, penwidth='1.5', style='solid')

        if i > 0:
            prev_id = f'op_{operations[i-1][0]}_{i-1}'
            dot.edge(prev_id, node_id, color='#6366f1', penwidth='1.5', style='dotted', arrowsize='0.7')

    # JOIN nodes
    for i, (left, right, jtype, cond) in enumerate(joins[:6]):
        jnode = f'join_{i}'
        dot.node(jnode, label=f'{jtype} JOIN\n{left} ↔ {right}',
                 shape='diamond', style='filled',
                 fillcolor='#2d1f4e', fontcolor='#c4b5fd',
                 color='#7c3aed', fontname='Helvetica', fontsize='10',
                 width='2.2', height='0.9')
        if f'tbl_{left}' in [f'tbl_{t}' for t in tables]:
            dot.edge(f'tbl_{left}', jnode, color='#7c3aed', penwidth='1.5', style='dashed')
        if f'tbl_{right}' in [f'tbl_{t}' for t in tables]:
            dot.edge(f'tbl_{right}', jnode, color='#7c3aed', penwidth='1.5', style='dashed')

    # Subquery nodes
    for sq in subqueries[:4]:
        dot.node(sq, label=f'({sq})', shape='ellipse', style='filled,dashed',
                 fillcolor='#1a2d1a', fontcolor='#6ee7b7',
                 color='#059669', fontname='Helvetica-Oblique', fontsize='10')

    # Result node
    if operations:
        dot.node('RESULT', label='Result Set\n/ Output',
                 shape='rectangle', style='filled,rounded',
                 fillcolor='#1f2937', fontcolor='#f9fafb',
                 color='#374151', fontname='Helvetica-Bold', fontsize='12',
                 width='2')
        last_op = f'op_{operations[-1][0]}_{len(operations)-1}'
        dot.edge(last_op, 'RESULT', color='#10b981', penwidth='2.5')

    return dot


# ─── GENERAL DIAGRAM GENERATORS ──────────────────────────────────────────────

def generate_dfd(entities: dict, is_code: bool = False, is_sql: bool = False) -> graphviz.Digraph:
    dot = graphviz.Digraph(
        name='DFD',
        graph_attr={'bgcolor': 'transparent', 'fontname': 'Helvetica',
                    'rankdir': 'LR', 'splines': 'ortho', 'pad': '0.5',
                    'nodesep': '0.8', 'ranksep': '1.2', 'compound': 'true'}
    )

    if is_sql:
        tables = entities.get("tables", {})
        joins = entities.get("joins", [])
        ops = entities.get("operations", [])

        for tname in list(tables.keys())[:8]:
            dot.node(f'tbl_{tname}', label=f'▣ {tname}',
                     shape='cylinder', style='filled',
                     fillcolor='#0f2942', fontcolor='#93c5fd',
                     color='#1d4ed8', fontname='Helvetica', fontsize='11')

        for i, (op, tbl) in enumerate(ops[:8]):
            colors = {'SELECT': '#3b82f6', 'INSERT': '#10b981', 'UPDATE': '#f59e0b',
                      'DELETE': '#ef4444', 'MERGE': '#8b5cf6'}
            c = colors.get(op, '#6366f1')
            dot.node(f'op_{i}', label=f'{op}', shape='ellipse', style='filled',
                     fillcolor='#1e293b', fontcolor=c, color=c,
                     fontname='Helvetica-Bold', fontsize='11')
            if tbl and tbl in tables:
                dot.edge(f'tbl_{tbl}', f'op_{i}', color=c, penwidth='1.5')

        for left, right, jtype, _ in joins[:6]:
            if left in tables and right in tables:
                dot.edge(f'tbl_{left}', f'tbl_{right}',
                         label=jtype, color='#f59e0b', penwidth='1.5',
                         fontcolor='#fbbf24', fontsize='9', style='dashed')
        return dot

    if is_code and entities.get("classes"):
        for cls in entities["classes"]:
            with dot.subgraph(name=f'cluster_{cls["name"]}') as c:
                c.attr(label=cls["name"], style='rounded,filled',
                       fillcolor='#1e3a5f', color='#4a9eff',
                       fontcolor='#ffffff', fontname='Helvetica-Bold', fontsize='13')
                for method in cls["methods"]:
                    c.node(f'{cls["name"]}.{method}',
                           label=f'«method»\n{method}()',
                           shape='ellipse', style='filled',
                           fillcolor='#2d5986', fontcolor='#ffffff',
                           fontname='Helvetica', fontsize='11', color='#4a9eff')
        for func in entities.get("functions", []):
            dot.node(func, label=f'«function»\n{func}()',
                     shape='ellipse', style='filled',
                     fillcolor='#1e3a5f', fontcolor='#ffffff',
                     fontname='Helvetica', fontsize='11', color='#4a9eff')
        for caller, callee in entities.get("calls", []):
            dot.edge(caller, callee, color='#7c3aed', penwidth='2', arrowsize='0.8')
        for imp in entities.get("imports", [])[:5]:
            dot.node(f'import_{imp}', label=f'pkg: {imp}',
                     shape='rectangle', style='filled,dashed',
                     fillcolor='#2d1f4e', fontcolor='#c4b5fd',
                     fontname='Helvetica', fontsize='10', color='#7c3aed')
        return dot

    # Text mode
    processes = entities.get("processes", [])
    actors = entities.get("actors", [])
    systems = entities.get("systems", [])
    step_colors = [
        ('#1e3a5f', '#60a5fa', '#ffffff'), ('#2d1f4e', '#a78bfa', '#ffffff'),
        ('#3d1f2f', '#f472b6', '#ffffff'), ('#1f3d2d', '#34d399', '#ffffff'),
        ('#3d3a1f', '#fbbf24', '#000000'),
    ]
    for i, actor in enumerate(actors[:4]):
        safe = re.sub(r'[^a-zA-Z0-9]', '_', actor)
        dot.node(f'actor_{safe}', label=actor, shape='rectangle', style='filled',
                 fillcolor='#1e4a3a', fontcolor='#6ee7b7', fontname='Helvetica-Bold',
                 fontsize='12', color='#10b981', width='1.5')
    for i, process in enumerate(processes[:12]):
        label = textwrap.fill(process[:60], width=30)
        bg, border, text = step_colors[i % len(step_colors)]
        dot.node(f'proc_{i}', label=label, shape='ellipse', style='filled',
                 fillcolor=bg, fontcolor=text, color=border,
                 fontname='Helvetica', fontsize='10', width='2.2', height='0.9')
    for i, sys_name in enumerate(systems[:4]):
        safe = re.sub(r'[^a-zA-Z0-9]', '_', sys_name)
        dot.node(f'sys_{safe}', label=f'▣ {sys_name}', shape='cylinder', style='filled',
                 fillcolor='#1a1a2e', fontcolor='#94a3b8',
                 fontname='Helvetica', fontsize='11', color='#475569', width='1.8')
    for i in range(min(len(processes) - 1, 11)):
        dot.edge(f'proc_{i}', f'proc_{i+1}', color='#6366f1', penwidth='2', arrowsize='0.9')
    if actors and processes:
        safe_actor = re.sub(r'[^a-zA-Z0-9]', '_', actors[0])
        dot.edge(f'actor_{safe_actor}', 'proc_0', color='#10b981', penwidth='2', style='dashed')
    if systems and processes:
        mid = len(processes) // 2
        safe_sys = re.sub(r'[^a-zA-Z0-9]', '_', systems[0])
        dot.edge(f'proc_{mid}', f'sys_{safe_sys}', color='#f59e0b', penwidth='1.5',
                 style='dotted', label='stores')
    return dot


def generate_sequence_diagram(entities: dict, is_code: bool = False, is_sql: bool = False) -> graphviz.Digraph:
    dot = graphviz.Digraph(
        name='Sequence',
        graph_attr={'bgcolor': 'transparent', 'fontname': 'Helvetica',
                    'rankdir': 'TB', 'splines': 'ortho', 'pad': '0.8',
                    'nodesep': '1.5', 'ranksep': '0.6'}
    )

    if is_sql:
        tables = list(entities.get("tables", {}).keys())
        ops = entities.get("operations", [])
        participants = ['Application'] + tables[:4] + ['Database']
        steps = [f'{op} on {tbl}' if tbl else op for op, tbl in ops[:10]]
    elif is_code:
        participants = ['Client'] + [cls["name"] for cls in entities.get("classes", [])[:3]] \
                       + entities.get("functions", [])[:2]
        steps = ([f'call {cls["name"]}()' for cls in entities.get("classes", [])[:3]]
                 + [f'{f}()' for f in entities.get("functions", [])[:4]])
    else:
        processes = entities.get("processes", [])
        seen, participants = set(), []
        for line in processes:
            for w in re.findall(r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b', line):
                if w not in seen and len(participants) < 6:
                    seen.add(w); participants.append(w)
        if not participants:
            participants = ['Client', 'API Gateway', 'Service', 'Database']
        steps = processes[:10]

    part_colors = ['#1e3a5f', '#2d1f4e', '#1e4a3a', '#3d1f2f', '#1f3a3d', '#3d3a1f']
    part_text  = ['#60a5fa', '#a78bfa', '#34d399', '#f472b6', '#22d3ee', '#fbbf24']
    msg_colors = ['#6366f1', '#8b5cf6', '#10b981', '#f59e0b', '#ec4899', '#06b6d4']

    for i, part in enumerate(participants[:6]):
        dot.node(f'part_{i}', label=part, shape='rectangle', style='filled,rounded',
                 fillcolor=part_colors[i % len(part_colors)],
                 fontcolor=part_text[i % len(part_text)],
                 fontname='Helvetica-Bold', fontsize='12',
                 color=part_text[i % len(part_text)],
                 width='1.6', height='0.5')

    for i, step in enumerate(steps[:10]):
        src = i % len(participants)
        dst = (i + 1) % len(participants)
        label = textwrap.fill(step[:50], width=28)
        snode = f'step_{i}'
        dot.node(snode, label=f'{i+1}. {label}', shape='note', style='filled',
                 fillcolor='#1e293b', fontcolor='#e2e8f0',
                 fontname='Helvetica', fontsize='10',
                 color=msg_colors[i % len(msg_colors)], width='3')
        dot.edge(f'part_{src}', snode, color=msg_colors[i % len(msg_colors)],
                 penwidth='1.5', style='dashed')
        dot.edge(snode, f'part_{dst}', color=msg_colors[i % len(msg_colors)],
                 penwidth='1.5', arrowsize='0.8')
    return dot


def generate_logical_diagram(entities: dict, is_code: bool = False, is_sql: bool = False) -> graphviz.Digraph:
    dot = graphviz.Digraph(
        name='Architecture',
        graph_attr={'bgcolor': 'transparent', 'fontname': 'Helvetica',
                    'rankdir': 'TB', 'splines': 'curved', 'pad': '1.0',
                    'nodesep': '1.0', 'ranksep': '1.5', 'compound': 'true'}
    )

    if is_sql:
        tables = entities.get("tables", {})
        views = entities.get("views", [])
        procedures = entities.get("procedures", [])
        ops = entities.get("operations", [])

        with dot.subgraph(name='cluster_app') as c:
            c.attr(label='Application Layer', style='rounded,filled',
                   fillcolor='#0f1a2e', color='#1d4ed8',
                   fontcolor='#93c5fd', fontname='Helvetica-Bold', fontsize='13')
            c.node('app_client', label='Client App', shape='rectangle',
                   style='filled,rounded', fillcolor='#1e3a5f',
                   fontcolor='#60a5fa', color='#3b82f6', fontname='Helvetica', fontsize='11')
            for op, tbl in list(dict.fromkeys(ops))[:3]:
                c.node(f'dml_{op}', label=f'{op} Ops', shape='ellipse', style='filled',
                       fillcolor='#1e293b', fontcolor='#94a3b8',
                       color='#475569', fontname='Helvetica', fontsize='10')
            dot.edge('app_client', 'dml_SELECT' if ('SELECT', '') in ops or any(o == 'SELECT' for o, _ in ops) else 'app_client',
                     color='#3b82f6', penwidth='2', style='solid')

        with dot.subgraph(name='cluster_db') as c:
            c.attr(label='Database Layer', style='rounded,filled',
                   fillcolor='#1a0f2e', color='#7c3aed',
                   fontcolor='#c4b5fd', fontname='Helvetica-Bold', fontsize='13')
            for tname in list(tables.keys())[:6]:
                c.node(tname, label=f'▣ {tname}', shape='cylinder', style='filled',
                       fillcolor='#0f2942', fontcolor='#93c5fd',
                       color='#1d4ed8', fontname='Helvetica', fontsize='11')
            for vname in views[:2]:
                c.node(f'view_{vname}', label=f'⊞ {vname}', shape='rectangle',
                       style='filled,dashed', fillcolor='#1f2d1f',
                       fontcolor='#6ee7b7', color='#059669', fontname='Helvetica-Oblique', fontsize='10')

        if procedures:
            with dot.subgraph(name='cluster_procs') as c:
                c.attr(label='Stored Procedures / Functions', style='rounded,filled',
                       fillcolor='#1f1a2e', color='#6d28d9',
                       fontcolor='#ddd6fe', fontname='Helvetica-Bold', fontsize='13')
                for pname in procedures[:4]:
                    c.node(f'proc_{pname}', label=f'⚙ {pname}', shape='rectangle',
                           style='filled,rounded', fillcolor='#2d1f4e',
                           fontcolor='#a78bfa', color='#7c3aed', fontname='Helvetica', fontsize='11')
        return dot

    if is_code:
        with dot.subgraph(name='cluster_presentation') as c:
            c.attr(label='Presentation Layer', style='rounded,filled',
                   fillcolor='rgba(30,58,95,0.5)', color='#3b82f6',
                   fontcolor='#93c5fd', fontname='Helvetica-Bold', fontsize='13')
            for cls in entities.get("classes", [])[:3]:
                c.node(cls["name"], shape='rectangle', style='filled,rounded',
                       fillcolor='#1e3a5f', fontcolor='#60a5fa', color='#3b82f6',
                       fontname='Helvetica-Bold', fontsize='11')
        with dot.subgraph(name='cluster_logic') as c:
            c.attr(label='Business Logic Layer', style='rounded,filled',
                   fillcolor='rgba(45,31,78,0.5)', color='#7c3aed',
                   fontcolor='#c4b5fd', fontname='Helvetica-Bold', fontsize='13')
            for func in entities.get("functions", [])[:4]:
                c.node(func, shape='ellipse', style='filled',
                       fillcolor='#2d1f4e', fontcolor='#a78bfa', color='#7c3aed',
                       fontname='Helvetica', fontsize='11')
        with dot.subgraph(name='cluster_data') as c:
            c.attr(label='Data / External Layer', style='rounded,filled',
                   fillcolor='rgba(26,26,46,0.5)', color='#475569',
                   fontcolor='#94a3b8', fontname='Helvetica-Bold', fontsize='13')
            for imp in entities.get("imports", [])[:4]:
                c.node(f'dep_{imp}', label=imp, shape='cylinder', style='filled',
                       fillcolor='#1a1a2e', fontcolor='#94a3b8', color='#475569',
                       fontname='Helvetica', fontsize='10')
        for caller, callee in entities.get("calls", [])[:8]:
            dot.edge(caller, callee, color='#6366f1', penwidth='2', arrowsize='0.8')
        return dot

    # Text mode — layer separation
    processes = entities.get("processes", [])
    layers = {'Client Layer': [], 'API / Gateway Layer': [], 'Business Logic Layer': [], 'Data Layer': []}
    for proc in processes[:12]:
        pl = proc.lower()
        if any(k in pl for k in ['user', 'client', 'customer', 'browser', 'frontend']):
            layers['Client Layer'].append(proc)
        elif any(k in pl for k in ['api', 'gateway', 'router', 'load balancer', 'proxy']):
            layers['API / Gateway Layer'].append(proc)
        elif any(k in pl for k in ['database', 'db', 'storage', 'queue', 'cache', 'store']):
            layers['Data Layer'].append(proc)
        else:
            layers['Business Logic Layer'].append(proc)

    layer_styles = {
        'Client Layer':          ('#1e3a5f', '#3b82f6', '#60a5fa', '#93c5fd'),
        'API / Gateway Layer':   ('#2d1f4e', '#7c3aed', '#a78bfa', '#c4b5fd'),
        'Business Logic Layer':  ('#1e4a3a', '#059669', '#34d399', '#6ee7b7'),
        'Data Layer':            ('#1a1a2e', '#475569', '#94a3b8', '#cbd5e1'),
    }
    prev = None
    for layer_name, items in layers.items():
        if not items:
            continue
        safe_layer = re.sub(r'[^a-zA-Z0-9]', '_', layer_name)
        fill_c, border_c, node_c, text_c = layer_styles[layer_name]
        with dot.subgraph(name=f'cluster_{safe_layer}') as c:
            c.attr(label=layer_name, style='rounded,filled',
                   fillcolor=f'{fill_c}80', color=border_c,
                   fontcolor=text_c, fontname='Helvetica-Bold', fontsize='13')
            first = None
            for j, item in enumerate(items[:4]):
                nid = f'{safe_layer}_{j}'
                if j == 0: first = nid
                c.node(nid, label=textwrap.fill(item[:50], width=25),
                       shape='rectangle', style='filled,rounded',
                       fillcolor=fill_c, fontcolor='#ffffff', color=node_c,
                       fontname='Helvetica', fontsize='10', width='2.2')
                if j > 0:
                    c.edge(f'{safe_layer}_{j-1}', nid, color=node_c, penwidth='1.5', style='dashed')
            if prev and first:
                dot.edge(prev, first, color='#6366f1', penwidth='2.5',
                         style='solid', arrowsize='1', lhead=f'cluster_{safe_layer}')
            if first: prev = first
    return dot


def generate_flowchart(entities: dict, is_code: bool = False, is_sql: bool = False) -> graphviz.Digraph:
    dot = graphviz.Digraph(
        name='Flowchart',
        graph_attr={'bgcolor': 'transparent', 'fontname': 'Helvetica',
                    'rankdir': 'TB', 'splines': 'ortho', 'pad': '0.8',
                    'nodesep': '0.7', 'ranksep': '0.8'}
    )
    dot.node('START', 'START', shape='oval', style='filled', fillcolor='#065f46',
             fontcolor='#6ee7b7', fontname='Helvetica-Bold', fontsize='13', color='#10b981')

    if is_sql:
        processes = [f'{op} on {tbl}' if tbl else op
                     for op, tbl in entities.get("operations", [])]
        processes = processes or [f'Access {t}' for t in list(entities.get("tables", {}).keys())[:6]]
    elif is_code:
        processes = [f'{cls["name"]} class' for cls in entities.get("classes", [])] \
                    + entities.get("functions", [])
    else:
        processes = entities.get("processes", [])

    decision_kw = ['validate', 'check', 'verify', 'if', 'whether', 'valid', 'exists',
                   'success', 'error', 'fail', 'approve', 'reject', 'available', 'where']
    step_colors = [
        ('#1e3a5f', '#3b82f6', '#ffffff'), ('#2d1f4e', '#7c3aed', '#ffffff'),
        ('#1e4a3a', '#059669', '#ffffff'), ('#1f3a3d', '#0e7490', '#ffffff'),
        ('#3d3a1f', '#b45309', '#000000'),
    ]
    prev, dec_count = 'START', 0
    for i, proc in enumerate(processes[:12]):
        label = textwrap.fill(proc[:55], width=28)
        pid = f'proc_{i}'
        if any(kw in proc.lower() for kw in decision_kw):
            dot.node(pid, label=label + '?', shape='diamond', style='filled',
                     fillcolor='#3d1f2f', fontcolor='#f9a8d4',
                     color='#ec4899', fontname='Helvetica', fontsize='10',
                     width='2.5', height='1.2')
            dot.edge(prev, pid, color='#6366f1', penwidth='2')
            if i + 1 < len(processes):
                dot.edge(pid, f'proc_{i+1}', color='#10b981', penwidth='1.5',
                         label='Yes', fontcolor='#6ee7b7', fontsize='9')
            fid = f'fail_{dec_count}'
            dot.node(fid, 'Error /\nRollback', shape='rectangle', style='filled,rounded',
                     fillcolor='#7f1d1d', fontcolor='#fca5a5',
                     color='#ef4444', fontname='Helvetica', fontsize='10')
            dot.edge(pid, fid, color='#ef4444', penwidth='1.5',
                     label='No', fontcolor='#fca5a5', fontsize='9', style='dashed')
            dec_count += 1
        else:
            bg, border, text = step_colors[i % len(step_colors)]
            dot.node(pid, label=label, shape='rectangle', style='filled,rounded',
                     fillcolor=bg, fontcolor=text, color=border,
                     fontname='Helvetica', fontsize='11', width='2.8')
            dot.edge(prev, pid, color='#6366f1', penwidth='2', arrowsize='0.9')
        prev = pid

    dot.node('END', 'END', shape='oval', style='filled', fillcolor='#7c3aed',
             fontcolor='#ede9fe', fontname='Helvetica-Bold', fontsize='13', color='#8b5cf6')
    dot.edge(prev, 'END', color='#8b5cf6', penwidth='2.5')
    return dot


def render_diagram_to_svg(dot: graphviz.Digraph) -> Optional[str]:
    try:
        return dot.pipe(format='svg').decode('utf-8')
    except Exception:
        return None


# ─── MAIN APP ────────────────────────────────────────────────────────────────

def main():
    st.markdown("""
    <div class="main-header">
        <h1>🔍 Code Lens - BRD</h1>
        <p>Business Requirements Document Generator — Transform text, code or SQL into professional diagrams</p>
        <div style="margin-top:0.75rem;">
            <span class="badge">DFD</span>
            <span class="badge">Sequence</span>
            <span class="badge">Architecture</span>
            <span class="badge">Flowchart</span>
            <span class="sql-badge">ER Diagram</span>
            <span class="sql-badge">Query Flow</span>
            <span class="badge">SVG Export</span>
            <span class="badge">PNG Export</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ── SIDEBAR ──
    with st.sidebar:
        st.markdown("## ⚙️ Settings")

        input_type = st.radio(
            "Input Type",
            ["Natural Language / Text", "Python Source Code", "SQL Query / Schema"],
            help="Choose your input format"
        )

        st.markdown("---")
        st.markdown("## 📊 Diagram Type")

        if input_type == "SQL Query / Schema":
            diagram_type = st.selectbox(
                "Select Diagram",
                [
                    "ER Diagram (Entity-Relationship)",
                    "SQL Query Flow",
                    "Data Flow Diagram (DFD)",
                    "Flowchart",
                    "All SQL Diagrams",
                ]
            )
        else:
            diagram_type = st.selectbox(
                "Select Diagram",
                [
                    "Data Flow Diagram (DFD)",
                    "Sequence Diagram",
                    "Logic / Architecture Diagram",
                    "Flowchart",
                    "All Diagrams",
                ]
            )

        st.markdown("---")
        st.markdown("## 📐 Layout")
        layout_engine = st.selectbox(
            "Graphviz Engine",
            ["dot", "neato", "fdp", "sfdp", "circo", "twopi"],
            help="Different engines produce different graph layouts"
        )

        st.markdown("---")
        st.markdown("## 💾 Export Format")
        export_format = st.radio("Format", ["SVG", "PNG", "Both"])

        st.markdown("---")
        st.markdown("## 📖 Examples")
        if input_type == "Natural Language / Text":
            example_choice = st.selectbox("Load Example", ["None"] + list(TEXT_EXAMPLES.keys()))
        elif input_type == "Python Source Code":
            example_choice = st.selectbox("Load Example", ["None"] + list(PYTHON_EXAMPLES.keys()))
        else:
            example_choice = st.selectbox("Load Example", ["None"] + list(SQL_EXAMPLES.keys()))

    # ── MAIN COLUMNS ──
    col1, col2 = st.columns([2, 3], gap="large")

    input_text = ""

    with col1:
        st.markdown("### 📝 Input")

        # ── FILE UPLOAD SECTION ──
        is_sql = input_type == "SQL Query / Schema"
        is_code = input_type == "Python Source Code"

        if is_code:
            st.markdown('<div class="upload-zone">', unsafe_allow_html=True)
            uploaded_file = st.file_uploader(
                "Upload a Python file (.py)",
                type=["py"],
                help="Upload a .py file to analyse automatically",
                key="py_uploader"
            )
            st.markdown('</div>', unsafe_allow_html=True)
            if uploaded_file is not None:
                file_content = uploaded_file.read().decode("utf-8", errors="replace")
                st.markdown(
                    f'<div class="file-info">📄 Loaded: <strong>{uploaded_file.name}</strong>'
                    f' ({len(file_content):,} chars)</div>',
                    unsafe_allow_html=True
                )

        elif is_sql:
            st.markdown('<div class="upload-zone">', unsafe_allow_html=True)
            uploaded_file = st.file_uploader(
                "Upload a SQL file (.sql)",
                type=["sql", "txt"],
                help="Upload a .sql file — DDL, DML, or a mix of both",
                key="sql_uploader"
            )
            st.markdown('</div>', unsafe_allow_html=True)
            if uploaded_file is not None:
                file_content = uploaded_file.read().decode("utf-8", errors="replace")
                st.markdown(
                    f'<div class="sql-info">🗄️ Loaded: <strong>{uploaded_file.name}</strong>'
                    f' ({len(file_content):,} chars)</div>',
                    unsafe_allow_html=True
                )
        else:
            uploaded_file = None
            file_content = None

        # ── TEXT / CODE AREA ──
        if is_code:
            default_code = ""
            if example_choice and example_choice != "None":
                default_code = PYTHON_EXAMPLES.get(example_choice, "")
            elif 'file_content' in dir() and file_content:
                default_code = file_content

            pasted = st.text_area(
                "Or paste Python code directly:",
                value=default_code,
                height=280,
                placeholder="def process_order(order_id):\n    order = get_order(order_id)\n    ...",
                help="Paste Python code or upload a .py file above"
            )
            input_text = file_content if (uploaded_file and file_content and not pasted.strip()) else pasted

        elif is_sql:
            default_sql = ""
            if example_choice and example_choice != "None":
                default_sql = SQL_EXAMPLES.get(example_choice, "")
            elif 'file_content' in dir() and file_content:
                default_sql = file_content

            pasted = st.text_area(
                "Or paste SQL directly:",
                value=default_sql,
                height=280,
                placeholder="CREATE TABLE users (...)\nSELECT * FROM users JOIN orders ON ...",
                help="Paste SQL DDL/DML or upload a .sql file above"
            )
            input_text = file_content if (uploaded_file and file_content and not pasted.strip()) else pasted

        else:
            default_text = ""
            if example_choice and example_choice != "None":
                default_text = TEXT_EXAMPLES.get(example_choice, "")

            input_text = st.text_area(
                "Describe your system, process or architecture:",
                value=default_text,
                height=340,
                placeholder="User sends login request to API Gateway.\nAPI Gateway routes to Auth Service.\n...",
                help="Describe each step on a new line. Capitalize component names for better detection."
            )

        generate_btn = st.button("🚀 Generate Diagram", use_container_width=True)

        # ── ANALYSIS PREVIEW ──
        if input_text and input_text.strip():
            st.markdown("### 📋 Analysis Preview")
            if is_code:
                ents, _, err = parse_python_to_entities(input_text)
                if err:
                    st.error(f"Python parse error: {err}")
                elif ents:
                    c1, c2, c3 = st.columns(3)
                    c1.metric("Classes", len(ents.get("classes", [])))
                    c2.metric("Functions", len(ents.get("functions", [])))
                    c3.metric("Imports", len(ents.get("imports", [])))
            elif is_sql:
                ents = parse_sql_to_entities(input_text)
                c1, c2, c3, c4 = st.columns(4)
                c1.metric("Tables", len(ents.get("tables", {})))
                c2.metric("Joins", len(ents.get("joins", [])))
                c3.metric("Operations", len(ents.get("operations", [])))
                c4.metric("Views", len(ents.get("views", [])))
                if ents.get("tables"):
                    st.markdown(
                        "**Tables detected:** " +
                        ", ".join(f"`{t}`" for t in list(ents["tables"].keys())[:10])
                    )
            else:
                ents = extract_entities_from_text(input_text)
                c1, c2, c3 = st.columns(3)
                c1.metric("Steps", len(ents.get("processes", [])))
                c2.metric("Actors", len(ents.get("actors", [])))
                c3.metric("Systems", len(ents.get("systems", [])))

    # ── OUTPUT COLUMN ──
    with col2:
        st.markdown("### 🎨 Diagram Output")

        if generate_btn and input_text and input_text.strip():

            # Build entities
            if is_code:
                entities, _, error = parse_python_to_entities(input_text)
                if error:
                    st.error(f"Python parsing failed: {error}")
                    st.stop()
                if not entities:
                    st.warning("No parseable entities found.")
                    st.stop()
            elif is_sql:
                entities = parse_sql_to_entities(input_text)
                if not entities.get("tables") and not entities.get("operations"):
                    st.warning("No SQL tables or operations detected. Check the input.")
            else:
                entities = extract_entities_from_text(input_text)

            # Build diagram map for this input type
            if is_sql:
                diagram_map = {
                    "ER Diagram (Entity-Relationship)": ("er",      lambda e, **kw: generate_sql_er_diagram(e)),
                    "SQL Query Flow":                   ("qflow",   lambda e, **kw: generate_sql_query_flow(e)),
                    "Data Flow Diagram (DFD)":          ("dfd",     lambda e, **kw: generate_dfd(e, is_sql=True)),
                    "Flowchart":                        ("flow",    lambda e, **kw: generate_flowchart(e, is_sql=True)),
                }
                all_key = "All SQL Diagrams"
            else:
                diagram_map = {
                    "Data Flow Diagram (DFD)":         ("dfd",  lambda e, **kw: generate_dfd(e, is_code=is_code)),
                    "Sequence Diagram":                ("seq",  lambda e, **kw: generate_sequence_diagram(e, is_code=is_code)),
                    "Logic / Architecture Diagram":    ("arch", lambda e, **kw: generate_logical_diagram(e, is_code=is_code)),
                    "Flowchart":                       ("flow", lambda e, **kw: generate_flowchart(e, is_code=is_code)),
                }
                all_key = "All Diagrams"

            to_generate = (
                list(diagram_map.items()) if diagram_type == all_key
                else [(diagram_type, diagram_map[diagram_type])]
            )

            for d_name, (d_key, d_func) in to_generate:
                if d_name not in diagram_map:
                    continue
                with st.spinner(f"Generating {d_name}..."):
                    try:
                        dot = d_func(entities)
                        dot.engine = layout_engine
                        svg_str = render_diagram_to_svg(dot)

                        if svg_str:
                            if diagram_type == all_key:
                                st.markdown(f"#### {d_name}")
                            st.markdown(
                                f'<div class="svg-container">{svg_str}</div>',
                                unsafe_allow_html=True
                            )
                            svg_bytes = svg_str.encode('utf-8')
                            dl_cols = st.columns(2)
                            if export_format in ["SVG", "Both"]:
                                with dl_cols[0]:
                                    st.download_button(
                                        label=f"⬇️ {d_key.upper()} SVG",
                                        data=svg_bytes,
                                        file_name=f"{d_key}_diagram.svg",
                                        mime="image/svg+xml",
                                        use_container_width=True
                                    )
                            if export_format in ["PNG", "Both"]:
                                with dl_cols[1]:
                                    try:
                                        png_bytes = dot.pipe(format='png')
                                        st.download_button(
                                            label=f"⬇️ {d_key.upper()} PNG",
                                            data=png_bytes,
                                            file_name=f"{d_key}_diagram.png",
                                            mime="image/png",
                                            use_container_width=True
                                        )
                                    except Exception:
                                        st.info("PNG needs graphviz PNG support.")
                        else:
                            st.error(f"Failed to render {d_name}")
                    except Exception as e:
                        st.error(f"Error generating {d_name}: {e}")

        elif generate_btn and not (input_text and input_text.strip()):
            st.warning("Please enter some content first (or upload a file).")
        else:
            st.markdown("""
            <div style="text-align:center; padding:3rem 2rem; background:#f8fafc; border-radius:12px; border:1px dashed #cbd5e1;">
                <div style="font-size:3rem; margin-bottom:1rem;">📊</div>
                <p style="font-size:1.1rem; color:#64748b; margin:0 0 0.5rem 0;">Your diagram will appear here</p>
                <p style="font-size:0.875rem; color:#94a3b8; margin:0;">
                    Enter text, code or SQL on the left — or upload a .py / .sql file<br>
                    then click <strong style="color:#6366f1;">Generate Diagram</strong>
                </p>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("""
    <div style="text-align:center; padding:1rem; color:#94a3b8; font-size:0.8rem; border-top:1px solid #e2e8f0; margin-top:0.5rem;">
        <strong style="color:#6366f1;">Code Lens - BRD</strong> &nbsp;•&nbsp;
        Powered by Graphviz &nbsp;•&nbsp;
        DFD · Sequence · Architecture · Flowchart · ER · Query Flow &nbsp;•&nbsp;
        Upload .py and .sql files &nbsp;•&nbsp; Export SVG / PNG
    </div>
    """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()
