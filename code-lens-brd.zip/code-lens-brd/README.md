# Code Lens - BRD

A diagram generator that transforms natural language text, Python source code, and SQL queries/schemas into professional architecture diagrams. Supports DFD, Sequence, Logic/Architecture, Flowchart, ER, and Query Flow diagrams with SVG and PNG export.

---

## Requirements

- Python 3.9 or higher
- Graphviz system binary (required for diagram rendering)

---

## Installation

### 1. Install Graphviz (system binary)

**macOS (Homebrew)**
```bash
brew install graphviz
```

**Ubuntu / Debian**
```bash
sudo apt-get update && sudo apt-get install -y graphviz
```

**Windows**
Download the installer from https://graphviz.org/download/ and add it to your PATH.

**Fedora / RHEL**
```bash
sudo dnf install graphviz
```

---

### 2. Clone or extract the project

If you downloaded the ZIP:
```bash
unzip code-lens-brd.zip
cd code-lens-brd
```

---

### 3. Create a virtual environment (recommended)

```bash
python -m venv venv
```

Activate it:

- **macOS / Linux:** `source venv/bin/activate`
- **Windows:** `venv\Scripts\activate`

---

### 4. Install Python dependencies

```bash
pip install -r requirements.txt
```

---

### 5. Run the application

```bash
streamlit run app.py
```

The app will open automatically in your browser at `http://localhost:8501`.

To use a different port:
```bash
streamlit run app.py --server.port 8080
```

---

## Usage

1. **Select Input Type** in the left sidebar:
   - *Natural Language / Text* — describe your system step by step
   - *Python Source Code* — paste or upload a `.py` file
   - *SQL Query / Schema* — paste or upload a `.sql` file

2. **Choose a Diagram Type**:
   - Data Flow Diagram (DFD)
   - Sequence Diagram
   - Logic / Architecture Diagram
   - Flowchart
   - ER Diagram *(SQL only)*
   - SQL Query Flow *(SQL only)*
   - All Diagrams

3. **Select a Layout Engine** (dot, neato, fdp, sfdp, circo, twopi)

4. **Click Generate Diagram**

5. **Download** the result as SVG or PNG

---

## File Upload

- Upload `.py` files when using Python Source Code mode
- Upload `.sql` or `.txt` files when using SQL mode

---

## Project Structure

```
code-lens-brd/
├── app.py              # Main Streamlit application
├── requirements.txt    # Python dependencies
└── README.md           # This file
```

---

## Dependencies

| Package     | Purpose                        |
|-------------|--------------------------------|
| streamlit   | Web UI framework               |
| graphviz    | Python bindings for Graphviz   |

---

## Uninstalling

```bash
deactivate           # exit the virtual environment
rm -rf venv          # remove the virtual environment
```

To remove Graphviz:
- **macOS:** `brew uninstall graphviz`
- **Ubuntu:** `sudo apt-get remove graphviz`

---

## Troubleshooting

**`ExecutableNotFound: failed to execute ['dot']`**
Graphviz system binary is not installed or not in PATH. Follow step 1 above.

**Port already in use**
Run with a different port: `streamlit run app.py --server.port 8502`

**Blank diagram / no output**
Try a different Layout Engine in the sidebar (e.g. switch from `dot` to `fdp`).
